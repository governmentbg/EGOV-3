package com.egov.workflow.service;


import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentLibrary;
import com.ibm.workplace.wcm.api.DocumentTypes;
import com.ibm.workplace.wcm.api.Repository;
import com.ibm.workplace.wcm.api.SiteArea;
import com.ibm.workplace.wcm.api.VirtualPortalScopedAction;
import com.ibm.workplace.wcm.api.WCM_API;
import com.ibm.workplace.wcm.api.Workspace;
import com.ibm.workplace.wcm.api.exceptions.WCMException;

public class VPMoveContent implements VirtualPortalScopedAction {

	// class level variables
	// private Content returnedValue = null;
	private Content content = null;
	private String libraryName = null;

	
	// public constructor
	public VPMoveContent(Content content, String libraryName) {
		this.content = content;
		this.libraryName = libraryName;		
	}

	// overwritten method
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public void run() throws WCMException {

		Repository repository = WCM_API.getRepository();
		Workspace workspace = repository.getSystemWorkspace();
		workspace.login();
		DocumentLibrary docLib = workspace.getDocumentLibrary(libraryName);
		workspace.setCurrentDocumentLibrary(docLib);
		System.out.println("inside vp scoped VPMoveContent");
		DocumentId parentId = content.getParentId();
		String parentSA = parentId.getName();
		String destinationSAArchive = parentSA + "_archive";
		System.out.println("destination: " + destinationSAArchive);
		DocumentIdIterator siteAreaIds = workspace.findByName(DocumentTypes.SiteArea, destinationSAArchive);
		SiteArea siteAreaArchive = null;
		if (siteAreaIds.hasNext()) {
	  		  siteAreaArchive = (SiteArea) workspace.getById(siteAreaIds.next());
	  		 System.out.println("Found site area of name: "+ siteAreaArchive.getTitle());	  		
	  	}
		DocumentId destinationDocId = workspace.createDocumentId(siteAreaArchive.getId().getId());		
		DocumentId docId = content.getId();
		//touch the content
		String title = content.getTitle();
		content.setTitle(title + ";");
		content.setEffectiveDate(content.getEffectiveDate());
		if (workspace.isLocked(docId)) {
			//System.out.println("------------------CONTENT IS LOCKED, so try to unlock it.");
			workspace.unlock(docId);
		}	
		
		workspace.move(docId, destinationDocId);
		
		try {
			save(workspace, content);
		} catch (Exception e1) {
			System.err.println("Could not save content after updating category! " + e1);
			e1.printStackTrace();
		}
		if (workspace != null) {
			try {
				workspace.logout();
				repository.endWorkspace();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	

	public static synchronized void save(Workspace workspace, com.ibm.workplace.wcm.api.Document doc) throws Exception {		
		System.out.println("saving Document " + doc.getName() + " " + doc.getTitle());
		String[] save = workspace.save(doc);
		for (String string : save) { 
			System.out.println("message from WCM after saving " + string);
		}
		System.out.println("saving Document " + doc.getName() + " " + doc.getTitle());		
	} 		
}