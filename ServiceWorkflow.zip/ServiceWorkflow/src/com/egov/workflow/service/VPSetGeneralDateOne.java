package com.egov.workflow.service;


import java.util.Date;

import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.ContentComponent;
import com.ibm.workplace.wcm.api.DateComponent;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentLibrary;
import com.ibm.workplace.wcm.api.NumericComponent;
import com.ibm.workplace.wcm.api.OptionSelectionComponent;
import com.ibm.workplace.wcm.api.Repository;
import com.ibm.workplace.wcm.api.VirtualPortalScopedAction;
import com.ibm.workplace.wcm.api.WCM_API;
import com.ibm.workplace.wcm.api.Workspace;
import com.ibm.workplace.wcm.api.exceptions.ComponentNotFoundException;
import com.ibm.workplace.wcm.api.exceptions.IllegalTypeChangeException;
import com.ibm.workplace.wcm.api.exceptions.OperationFailedException;
import com.ibm.workplace.wcm.api.exceptions.WCMException;


public class VPSetGeneralDateOne implements VirtualPortalScopedAction {

	// class level variables
	private Content content = null;
	private String libraryName = null;
	//private String action = null;
	

	// public constructor
	public VPSetGeneralDateOne(Content content, String libraryName) {
		this.content = content;
		this.libraryName = libraryName;
	}

	// overwritten method
	@Override
	public void run() throws WCMException {

		Repository repository = WCM_API.getRepository();
		Workspace workspace = repository.getSystemWorkspace();
		workspace.login();
		DocumentLibrary docLib = workspace.getDocumentLibrary(libraryName);
		workspace.setCurrentDocumentLibrary(docLib);		
		System.out.println("inside vp scoped");		
		Date expireDate = getContentField(content, "expireDate");
		System.out.println("expire Date: " + expireDate);
		if (expireDate != null) {
			content.setGeneralDateOne(expireDate);
		}
		
		
		if (workspace != null) {
			try {
				workspace.logout();
				repository.endWorkspace();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public static Date getContentField(Content content, String componentName)  throws OperationFailedException, ComponentNotFoundException, IllegalTypeChangeException {
		ContentComponent contentComponent = content.getComponent(componentName);
		System.out.println("get contentComponent " + contentComponent.getName());
		if (contentComponent instanceof DateComponent) {			
			DateComponent component = (DateComponent) content.getComponent(componentName);
			System.out.println("component " + component.getName());
			Date expireDate = component.getDate();							
			return expireDate;			
		} 
		return null;
	}
	
	@SuppressWarnings("rawtypes")
	public static void updateContentField(Content content, String componentName) throws OperationFailedException, ComponentNotFoundException, IllegalTypeChangeException {		
		ContentComponent contentComponent = content.getComponent(componentName);
		System.out.println("contentComponent " + contentComponent.getName());
		if (contentComponent instanceof NumericComponent) {			
			NumericComponent component = (NumericComponent) content.getComponent(componentName);
			System.out.println("component " + component.getName());
			int oldImpressions = component.getNumber().intValue();							
			component.setNumber(oldImpressions + 1);	
			content.setComponent(componentName, component);			
		} 	
		if (contentComponent instanceof OptionSelectionComponent) {
			System.out.println("option selection");
			OptionSelectionComponent component = (OptionSelectionComponent) content.getComponent(componentName);
			String parentName = content.getParentId().getName();			
			DocumentId [] availableSelections = component.getAvailableCategorySelectionValues();
			DocumentId [] chosenCategories = component.getCategorySelections();
			if (chosenCategories.length == 0) {
				System.out.println("no chosen category : parentName " + parentName);
				if (availableSelections != null) {
					for (int i = 0; i < availableSelections.length; i ++) {
						if (availableSelections[i].getName().equals(parentName)) {
							System.out.println("found category " + availableSelections[i].getName());						
							component.setCategorySelections(new DocumentId [] { availableSelections[i] });
							content.setComponent(componentName, component);	
						}
						System.out.println("selections : " + availableSelections[i].getName());
					}
				}
			}
			
			
			
		}
		
	}

	public static synchronized void save(Workspace workspace, com.ibm.workplace.wcm.api.Document doc) throws Exception {		
		System.out.println("saving Document " + doc.getName() + " " + doc.getTitle());
		String[] save = workspace.save(doc);
		for (String string : save) { 
			System.out.println("message from WCM after saving " + string);
		}
		System.out.println("saving Document " + doc.getName() + " " + doc.getTitle());		
	} 		
}