package com.egov.workflow.service;

import java.util.Locale;

import com.ibm.workplace.wcm.api.Document;
import com.ibm.workplace.wcm.api.custom.CustomWorkflowAction;
import com.ibm.workplace.wcm.api.custom.CustomWorkflowActionFactory;

public class EmailWorkFlowActionFactory implements CustomWorkflowActionFactory {

	// sendEmailToOwners is left out
	@Override
	public String[] getActionNames() {
		String names[] = { "sendEmailToApprovers", "sendEmailToAuthors", "populateServiceEkatteNumber", "setGeneralDateOne", "setGeneralDateTwo", "moveContent" };
		return names;
	}

	@Override
	public String getActionTitle(Locale arg0, String arg1) {
		if (arg1.equalsIgnoreCase("sendEmailToApprovers")) {
			return "\u0418\u0437\u043F\u0440\u0430\u0449\u0430\u043D\u0435 \u043D\u0430 " +
					"\u0441\u044A\u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u0434\u043E " +
					"\u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440 " +
					"\u043D\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430\u043D\u0438\u0435";
		} else if (arg1.equalsIgnoreCase("sendEmailToAuthors")) {
			return "\u0418\u0437\u043F\u0440\u0430\u0449\u0430\u043D\u0435 \u043D\u0430 " +
					"\u0441\u044A\u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u0434\u043E " +
					"\u0430\u0432\u0442\u043E\u0440 \u043D\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430\u043D\u0438\u0435";
		}
		// else if (arg1.equalsIgnoreCase("sendEmailToOwners")) {
		// return "sendEmailToOwners"; }
		else if (arg1.equalsIgnoreCase("populateServiceEkatteNumber")) {
			return "\u041F\u043E\u043F\u0443\u043B\u0438\u0440\u0430\u043D\u0435 \u043D\u0430 " +
					"\u0415\u041A\u0410\u0422\u0422\u0415 \u0437\u0430 \u043F\u0440\u043E\u0446\u0435\u0441 " +
					"\u0423\u0441\u043B\u0443\u0433\u0430";
		} else if (arg1.equalsIgnoreCase("setGeneralDateOne")) {
			return "\u041f\u043e\u043f\u044a\u043b\u0432\u0430\u043d\u0435 \u043d\u0430 \u043f\u0440\u043e\u043f\u044a\u0440\u0442\u0438 \u0067\u0065\u006e\u0065\u0072\u0061\u006c \u0064\u0061\u0074\u0065 \u006f\u006e\u0065 \u0438\u0437\u043f\u043e\u043b\u0437\u0432\u0430\u0439\u043a\u0438 \u043f\u043e\u043b\u0435 \u0065\u0078\u0070\u0069\u0072\u0065\u0044\u0061\u0074\u0065";
		} else if (arg1.equalsIgnoreCase("setGeneralDateTwo")) {
			return "\u041f\u043e\u043f\u044a\u043b\u0432\u0430\u043d\u0435 \u043d\u0430 \u043f\u0440\u043e\u043f\u044a\u0440\u0442\u0438 \u0067\u0065\u006e\u0065\u0072\u0061\u006c \u0064\u0061\u0074\u0065 \u0074\u0077\u006f \u0438\u0437\u043f\u043e\u043b\u0437\u0432\u0430\u0439\u043a\u0438 \u043f\u043e\u043b\u0435 \u0066\u0075\u0074\u0075\u0072\u0065\u0050\u0075\u0062\u006c\u0069\u0073\u0068\u0044\u0061\u0074\u0065";
		} else if (arg1.equalsIgnoreCase("moveContent")) {
			return "\u041f\u0440\u0435\u043c\u0435\u0441\u0442\u0432\u0430\u043d\u0435 \u043d\u0430 \u0441\u044a\u0434\u044a\u0440\u0436\u0430\u043d\u0438\u0435 \u0432 \u0430\u0440\u0445\u0438\u0432";
		}
		return null;
	}

	@Override
	public String getActionDescription(Locale arg0, String arg1) {

		if (arg1.equalsIgnoreCase("sendEmailToApprovers")) {
			return "\u0418\u0437\u043F\u0440\u0430\u0449\u0430\u043D\u0435 \u043D\u0430 " +
					"\u0441\u044A\u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u0434\u043E " +
					"\u0430\u0434\u043C\u0438\u043D\u0438\u0441\u0442\u0440\u0430\u0442\u043E\u0440 " +
					"\u043D\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430\u043D\u0438\u0435";
		} else if (arg1.equalsIgnoreCase("sendEmailToAuthors")) {
			return "\u0418\u0437\u043F\u0440\u0430\u0449\u0430\u043D\u0435 \u043D\u0430 " +
					"\u0441\u044A\u043E\u0431\u0449\u0435\u043D\u0438\u0435 \u0434\u043E " +
					"\u0430\u0432\u0442\u043E\u0440 \u043D\u0430 \u0441\u044A\u0434\u044A\u0440\u0436\u0430\u043D\u0438\u0435";
		}
		// else if (arg1.equalsIgnoreCase("sendEmailToOwners")) {
		// return "Send Email To Owners with custom Body"; }
		else if (arg1.equalsIgnoreCase("populateServiceEkatteNumber")) {
			return "\u041F\u043E\u043F\u0443\u043B\u0438\u0440\u0430\u043D\u0435 \u043D\u0430 " +
					"\u0415\u041A\u0410\u0422\u0422\u0415 \u0437\u0430 \u043F\u0440\u043E\u0446\u0435\u0441 " +
					"\u0423\u0441\u043B\u0443\u0433\u0430";			
		}
		else if (arg1.equalsIgnoreCase("setGeneralDateOne")) {
			return "\u041f\u043e\u043f\u044a\u043b\u0432\u0430\u043d\u0435 \u043d\u0430 \u043f\u0440\u043e\u043f\u044a\u0440\u0442\u0438 \u0067\u0065\u006e\u0065\u0072\u0061\u006c \u0064\u0061\u0074\u0065 \u006f\u006e\u0065 \u0438\u0437\u043f\u043e\u043b\u0437\u0432\u0430\u0439\u043a\u0438 \u043f\u043e\u043b\u0435\u0442\u043e \u0065\u0078\u0070\u0069\u0072\u0065\u0044\u0061\u0074\u0065";
		} else if (arg1.equalsIgnoreCase("setGeneralDateTwo")) {
			return "\u041f\u043e\u043f\u044a\u043b\u0432\u0430\u043d\u0435 \u043d\u0430 \u043f\u0440\u043e\u043f\u044a\u0440\u0442\u0438 \u0067\u0065\u006e\u0065\u0072\u0061\u006c \u0064\u0061\u0074\u0065 \u0074\u0077\u006f" + 
					"\u0438\u0437\u043f\u043e\u043b\u0437\u0432\u0430\u0439\u043a\u0438 \u043f\u043e\u043b\u0435\u0442\u043e \u0066\u0075\u0074\u0075\u0072\u0065\u0050\u0075\u0062\u006c\u0069\u0073\u0068\u0044\u0061\u0074\u0065";
		} else if (arg1.equalsIgnoreCase("moveContent")) {
			return "\u041f\u0440\u0435\u043c\u0435\u0441\u0442\u0432\u0430\u043d\u0435 \u043d\u0430 \u0441\u044a\u0434\u044a\u0440\u0436\u0430\u043d\u0438\u0435 \u0432 \u0441\u044a\u043e\u0442\u0432\u0435\u0442\u043d\u0430\u0442\u0430 \u0430\u0440\u0445\u0438\u0432 \u0441\u0430\u0439\u0442 \u043e\u0431\u043b\u0430\u0441\u0442";
		}
		return "";
	}

	@Override
	public CustomWorkflowAction getAction(String arg0, Document arg1) {

		if (arg0.equalsIgnoreCase("sendEmailToApprovers")) {
			return new SendEmailToApprovers();
		} else if (arg0.equalsIgnoreCase("sendEmailToAuthors")) {
			return new SendEmailToAuthors();
		}
		// else if (arg0.equalsIgnoreCase("sendEmailToOwners")) {
		// return new SendEmailToOwners();
		// }
		else if (arg0.equalsIgnoreCase("populateServiceEkatteNumber")) {
			return new PopulateServiceEkatte();
		}
		else if (arg0.equalsIgnoreCase("setGeneralDateOne")) {
			return new GeneralDateOneAction();
		} else if (arg0.equalsIgnoreCase("setGeneralDateTwo")) {
			return new GeneralDateTwoAction();
		} 
		else if (arg0.equalsIgnoreCase("moveContent")) {
			return new MoveContentAction();
		}
		return null;
	}

	@Override
	public String getName() {
		return "CustomWcmEmailBodyWorkFlowActionFactory";
	}

	@Override
	public String getTitle(Locale arg0) {
		return "\u0420\u0430\u0431\u043E\u0442\u0435\u043D \u043F\u0440\u043E\u0446\u0435\u0441 (\u0423\u0441\u043B\u0443\u0433\u0430)";
	}

}
