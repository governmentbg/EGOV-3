package com.egov.workflow.service;

import java.util.ArrayList;
import java.util.Date;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.Document;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.WcmCustomWorkflowService;
import com.ibm.workplace.wcm.api.Workspace;
import com.ibm.workplace.wcm.api.custom.CustomWorkflowAction;
import com.ibm.workplace.wcm.api.custom.CustomWorkflowActionResult;
import com.ibm.workplace.wcm.api.custom.Directive;
import com.ibm.workplace.wcm.api.custom.Directives;
import com.ibm.workplace.wcm.api.exceptions.ComponentNotFoundException;

public class PopulateServiceEkatte implements CustomWorkflowAction {

	InitialContext initContext = null;
	WcmCustomWorkflowService wcmCustomWorkflowService = null;
	CustomWorkflowActionResult result = null;
	// pay attention to set EKATTE name to be the same as Service AT
	public static final String COMPONENT_EKATTE_NUMBER = "serviceSupplierEkatteNumber";

	Content content = null;
	String message = null;

	public PopulateServiceEkatte() {
		System.out.println("WorkFlowAction has been invoked ...");
	}

	public CustomWorkflowActionResult execute(Document arg0) {

		System.out.println("Executing EKATTE Service.... ");
		Directive directive = Directives.CONTINUE;

		if (arg0 instanceof Content) {

			content = (Content) arg0;
			Workspace ws = content.getSourceWorkspace();
			ws.useDistinguishedNames(true);

			try {
				populateKeywords(ws, content);

			} catch (ComponentNotFoundException e) {
				message = "An exception has occured " + e.getMessage();
				directive = Directives.ROLLBACK_DOCUMENT;
			}

			try {
				initContext = new InitialContext();
				wcmCustomWorkflowService = (WcmCustomWorkflowService) initContext
						.lookup("portal:service/wcm/WcmCustomWorkflowService");
			} catch (NamingException e) {
				message = "An exception has occured in ex " + e.getMessage();
				directive = Directives.ROLLBACK_DOCUMENT;
			}

			result = wcmCustomWorkflowService.createResult(directive, message);
		}

		return result;
	}

	public static void populateKeywords(Workspace resourcesWorkspace, Content content) throws ComponentNotFoundException {
		System.out.println("populate ekatte");
		java.util.ArrayList<String> keyWords = new ArrayList<>();				
		String[] currentKeywords = content.getKeywords();
		if (currentKeywords != null && currentKeywords.length > 0) {
			for (int i = 0; i < currentKeywords.length; i++) {
				System.out.println("currentKeywords " +currentKeywords[i] );
				if (EgovWCMCache.getEkattesHm().get(currentKeywords[i].trim()) == null) {
					keyWords.add(currentKeywords[i].trim());
				}					
			}								
		}
		if (content.getComponent(COMPONENT_EKATTE_NUMBER) != null) {
			System.out.println("ekatte number " + content.getComponent(COMPONENT_EKATTE_NUMBER));
			ShortTextComponent ekatteComponent = (ShortTextComponent) content.getComponent(COMPONENT_EKATTE_NUMBER);
			if (ekatteComponent.getText() != null && ekatteComponent.getText().trim().length() > 0) {
				System.out.println("ekatte " + ekatteComponent.getText());
				keyWords.add(ekatteComponent.getText());
			}			
		} 
		content.setKeywords(keyWords.toArray(new String[keyWords.size()]));
	}

	public Date getExecuteDate(Document arg0) {
		return DATE_EXECUTE_NOW;
	}
}