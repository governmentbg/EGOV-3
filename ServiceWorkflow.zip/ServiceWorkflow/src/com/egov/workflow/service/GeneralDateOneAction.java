package com.egov.workflow.service;


import java.util.Date;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.ContentComponent;
import com.ibm.workplace.wcm.api.Document;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.Repository;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.SiteArea;
import com.ibm.workplace.wcm.api.VirtualPortalContext;
import com.ibm.workplace.wcm.api.WCM_API;
import com.ibm.workplace.wcm.api.WcmCustomWorkflowService;
import com.ibm.workplace.wcm.api.Workspace;
import com.ibm.workplace.wcm.api.custom.CustomWorkflowAction;
import com.ibm.workplace.wcm.api.custom.CustomWorkflowActionResult;
import com.ibm.workplace.wcm.api.custom.Directive;
import com.ibm.workplace.wcm.api.custom.Directives;

/*
 * This Action will be executed ONLY on staging environment.
 */
public class GeneralDateOneAction implements CustomWorkflowAction {

	InitialContext initContext = null;
	WcmCustomWorkflowService wcmCustomWorkflowService = null;
	CustomWorkflowActionResult result = null;
	private static Repository repository = null;
	public static Workspace workspace = null;
	Content content = null;
	String message = null;
	//customs.bg28892 or customs
	private String currentLibraryName = "agency"; //default
	private String context = "customs.bg28892"; //default
	
	public GeneralDateOneAction() {
		System.out.println("GeneralDateOneAction has been invoked ...");
		try {
			initContext = new InitialContext();
			wcmCustomWorkflowService = (WcmCustomWorkflowService) initContext.lookup("portal:service/wcm/WcmCustomWorkflowService");			
		} catch (NamingException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();			
		}
		
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public CustomWorkflowActionResult execute(Document arg0) {
		
		Directive directive = Directives.CONTINUE;		
		if (wcmCustomWorkflowService == null) {
			try {
				initContext = new InitialContext();
				wcmCustomWorkflowService = (WcmCustomWorkflowService) initContext.lookup("portal:service/wcm/WcmCustomWorkflowService");
			} catch (NamingException e) {
				System.out.println(e.getMessage());
				message = "An exception has occured in ex " + e.getMessage();
				directive = Directives.ROLLBACK_DOCUMENT;
			}				
		}
		
		String env = System.getProperty("environment");
		System.out.println("env:" + env);
		if (directive.toString().equals(Directives.ROLLBACK_DOCUMENT.toString()) || (env != null && env.equals("PROD"))) {			
			System.out.println("GeneralDateOneAction action, exiting [" + env + "][" + directive.toString() + "]");
			return wcmCustomWorkflowService.createResult(directive, message);
		}
		
		if (repository == null) {			
			repository = WCM_API.getRepository();
		} 
		
		content = (Content) arg0;
		try {
			workspace = repository.getSystemWorkspace();
						
			//method 2 -> get elements of root site area:
			//try to iterate all parents until we hit root SA
			DocumentId tempDoc = content.getParentId();
			SiteArea tempSA = (SiteArea) workspace.getById(tempDoc, true);
			String path = "";
			String parentName = "";
			while (!tempSA.getName().equals("site")) { //usually "site" is the root
				path = parentName + "/" + path;
				tempDoc = tempSA.getParentId();				
				System.out.println("path " + path + ", tempDoc: " + tempDoc);
				System.out.println("tempSA: " + tempSA.getName());
				
				tempSA = (SiteArea) workspace.getById(tempDoc, true);
				parentName = tempSA.getName();
				if (parentName.equals("site")) {					
					break;
				}					
			}
			ContentComponent cmpnt = null;
			
			
			if (env != null && env.equals("STAGING")) {
				if (tempSA.hasComponent("stagingContext")) {
					cmpnt = tempSA.getComponent("stagingContext");
					System.out.println("found stagingContex component.");
				} else {
					context = "";//base portal
				}				
			}			
			
			if (cmpnt != null && cmpnt instanceof ShortTextComponent) {
				context = ((ShortTextComponent)cmpnt).getText();
				System.out.println("context = " + context);
			}
			//now get name of library
			if (tempSA.hasComponent("libraryName")) {
				cmpnt = tempSA.getComponent("libraryName");
				if (cmpnt != null && cmpnt instanceof ShortTextComponent) {
					currentLibraryName = ((ShortTextComponent)cmpnt).getText();					
				}
			}						
			System.out.println("currentLibraryName: " + currentLibraryName + " context: " + context);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		
		System.out.println("Executing GeneralDateOneAction.... for context " + context);		
		if (arg0 instanceof Content) {
			VirtualPortalContext vctx;
			
			try {								
				// Create VP Scoped Action object
				System.out.println("before entering vp");
				VPSetGeneralDateOne vpA = new VPSetGeneralDateOne(content, currentLibraryName);				
				content.getParents();
				vctx = repository.generateVPContextFromContextPath(context);
				repository.executeInVP(vctx, vpA);
				System.out.println("after executeInVP");
			} catch (Exception e) {
				e.printStackTrace();
			}			
						
			result = wcmCustomWorkflowService.createResult(directive, message);
		}
		destroy();
		return result;
	}


	public Date getExecuteDate(Document arg0) {
		return DATE_EXECUTE_NOW;
	}
	
	public void destroy() {
		if (workspace != null) {
			try {
				workspace.logout();
				repository.endWorkspace();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	
}