package com.ibm.pollmanager;

public class PollConstants {
	public static final String MESSAGE_TYPE_INFORMATION = "I";
	public static final String MESSAGE_TYPE_WARNING = "W";
	public static final String MESSAGE_TYPE_ERROR = "E";
	
	public static final String POLL_STATUS_ACTIVE = "1";
	public static final String POLL_STATUS_INACTIVE = "0";
	public static final String POLL_SHOW_TITLE = "1";
	public static final String POLL_HIDE_TITLE = "0";
	public static final String POLL_SHOW_DESCRIPTION = "1";
	public static final String POLL_HIDE_DESCRIPTION = "0";
	public static final String POLL_SHOW_RESULT = "1";
	public static final String POLL_HIDE_RESULTS = "0";

	public static final String STEP_SHOW_TITLE = "1";
	public static final String STEP_HIDE_TITLE = "0";

	public static final String QUESTION_TYPE_SIMPLE_ONE = "1";
	public static final String QUESTION_TYPE_SIMPLE_MULTIPLE = "2";
	public static final String QUESTION_TYPE_MATRIX_ONE = "3";
	public static final String QUESTION_TYPE_MATRIX_MULTIPLE = "4";
	
	public static final String LANGUAGE_BG = "bg";
	public static final String LANGUAGE_EN = "en";
	
	public static final String QUESTION_IS_COMPULSORY = "1";
	public static final String QUESTION_IS_NOT_COMPULSORY = "0";
	public static final String QUESTION_HAS_COMMENT = "1";
	public static final short MAX_TEXT_LENGTH = 250;
	
	public static String _PRODUCT_NAME = "PollManager";
	public static String _PRODUCT_VERSION = "1.0";
	public static String _OFFICIALMAILSENDER = null;
	
	public static final boolean ISDEBUG = true;

}
