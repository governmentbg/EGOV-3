package com.ibm.pollmanager;

import java.io.IOException;
import java.util.Iterator;
import java.util.Locale;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.GenericPortlet;
import javax.portlet.PortletException;
import javax.portlet.PortletMode;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequest;
import javax.portlet.PortletRequestDispatcher;
import javax.portlet.PortletSession;
import javax.portlet.ReadOnlyException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ValidatorException;
import javax.portlet.WindowState;

import com.ibm.poll.bean.Container;
import com.ibm.poll.bean.Message;
import com.ibm.poll.db.DBPool;
import com.ibm.poll.db.DBResources;
import com.ibm.poll.utils.PollUtils;
import com.ibm.portal.um.PumaHome;
import com.ibm.portal.um.exceptions.PumaException;

public class PollManagerPortlet extends GenericPortlet {

	public static final String JSP_FOLDER = "/_PollManager/jsp/"; // JSP folder name

	public static final String INDEX_PAGE = "index";
	public static final String POLL_FORM_PAGE = "pollForm";
	public static final String POLL_RESULTS_PAGE = "pollResults";
	public static final String STEP_LIST_PAGE = "steps";
	public static final String STEP_FORM_PAGE = "stepForm";
	public static final String QUESTION_LIST_PAGE = "questions";
	public static final String QUESTION_FORM_PAGE = "questionForm";
	public static final String ERROR_PAGE = "errorPage";

	public static final String VIEW_JSP = "PollManagerPortletView"; // JSP file name to be rendered on the view mode
	public static final String CONFIG_JSP = "PollManagerPortletConfig"; // JSP file name to be rendered on the configure mode
	public static final String EDIT_DEFAULTS_JSP = "PollManagerPortletEditDefaults"; // JSP file name to be rendered on the configure mode

	public static final String PARAMETER_SOURCE = "source";
	public static final String PARAMETER_ACTION = "action";
	public static final String PARAMETER_VALUE = "value";
	public static final String PARAMETER_ID = "id";
	public static final String PARAMETER_OPERATION = "operation";
	public static final String PARAMETER_MODE = "mode";
	
	public static final String ACTION_NAVIGATE_TO_PAGE = "changePage";
	public static final String ACTION_NAVIGATOR = "navigator";
	public static final String ACTION_CHANGE_SEARCH_CRITERIA = "searchCriteria";
	public static final String ACTION_NEW = "new";
	public static final String ACTION_ADD = "add";
	public static final String ACTION_EDIT = "edit";
	public static final String ACTION_DELETE = "delete";
	public static final String ACTION_SWITCH_STATUS = "switchStatus";
	public static final String ACTION_SWITCH_COMPULSORY = "switchCompulsory";
	public static final String ACTION_MOVEUP = "moveup";
	public static final String ACTION_MOVEDOWN = "movedown";
	public static final String MODE_PREVIEW = "preview";

	public static final String SOURCE_BREADCRUMB = "breadcrumb";

	public static final String NAVIGATOR_OPERATION_FIRST = "1";
	public static final String NAVIGATOR_OPERATION_PREVIOUS = "2";
	public static final String NAVIGATOR_OPERATION_NEXT = "3";
	public static final String NAVIGATOR_OPERATION_LAST = "4";
	public static final String NAVIGATOR_OPERATION_GOTO = "5";

	public static final String SESSION_BEAN = "PollManagerPortletSessionBean"; // Bean name for the portlet session
	public static final String MESSAGE = "PollMessage";
	public static final String MESSAGE_TYPE = "PollMessageType";

	public static final String CONFIG_SUBMIT = "PollManagerPortletConfigSubmit"; // Action name for submit form
	public static final String CONFIG_CANCEL = "PollManagerPortletConfigCancel"; 
	public static final String EDIT_DEFAULTS_SUBMIT = "PollManagerPortletEditDefaultsSubmit"; // Action name for submit form
	public static final String EDIT_DEFAULTS_CANCEL = "PollManagerPortletEditDefaultsCancel"; 

	public static final String ERROR_MESSAGE = "PollManagerPortletErrorMessage"; // Parameter name for the validation error message
	public static final String ERROR_KEYS = "PollManagerPortletErrorKeys"; // Parameter name for the validation failed keys

	public static final String SETTING_PARAMETER_RESULTS_PER_PAGE = "wps.results.per.page";
	public static final String SETTING_PARAMETER_MAX_ITEMS = "wps.max.items";
	public static final String SETTING_PARAMETER_LANGUAGE = "wps.poll.language";
	public static final String SETTING_PARAMETER_VP = "wps.vp";
	public static final String SETTING_PARAMETER_THEME = "wps.poll.theme";
	
	public static final String THEME_NAME_IBM = "ibm";
	public static final String THEME_NAME_AGENCY = "agency";
	public static final String THEME_NAME_TEMPLATE = "template";

	public static String maxItems = null;
	public static int resultsPerPage = 10;
	public static String language = PollConstants.LANGUAGE_BG;
	public static String vp = null;
	public static String theme = "ibm";
	private static PumaHome pumaHome = null;
	public static boolean preferencesLoaded = false;
	public static boolean userLoggedIn = false;
	public static com.ibm.portal.um.User currentUser = null;
	public static String currentUserDN = null;
	private static final PortletMode CUSTOM_CONFIG_MODE = new PortletMode("config");
	private static final PortletMode CUSTOM_EDIT_DEFAULTS_MODE = new PortletMode("edit_defaults");

	public void init() throws PortletException {
		super.init();
		InitialContext initialcontext;
		try {
			initialcontext = new InitialContext();
			try {
				initialcontext.lookup("portletservice/com.ibm.portal.state.service.PortletStateManagerService");
			} catch (Exception exception) {
				System.out.println(exception.getMessage());
				exception.printStackTrace();
			}
		} catch (NamingException e) {
			System.out.println(e.getMessage());
		}
		try {
			initialcontext = new InitialContext();
			pumaHome = (PumaHome) initialcontext.lookup("portal:service/usermanagement/Puma");
		} catch (NamingException namingexception) {
			namingexception.printStackTrace();
		}
		String realPath = getPortletContext().getRealPath("/");
		if (DBResources.loadProps(realPath)) {
			System.out.print("------ APPLICATION STARTED NORMALLY: [ OK ]");
		}
	}

	/**
	 * Serve up the <code>view</code> mode.
	 * 
	 * @see javax.portlet.GenericPortlet#doView(javax.portlet.RenderRequest, javax.portlet.RenderResponse)
	 */
	public void doView(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		// Set the MIME type for the render response
		response.setContentType(request.getResponseContentType());

		// Check if portlet session exists
		PollManagerPortletSessionBean sessionBean = getSessionBean(request);
		if (sessionBean == null) {
			response.getWriter().println("<b>NO PORTLET SESSION YET</b>");
			return;
		}
		PortletRequestDispatcher rd = null;
		Locale locale = new Locale(language);
		PollContainerManager.process(request, response, getPortletConfig().getResourceBundle(locale), sessionBean);
		PollBreadCrumbManager.buildBreadCrumb(request, response, getPortletConfig().getResourceBundle(locale), sessionBean);
		PollNavigatorManager.buildNavigator(request, response, getPortletConfig().getResourceBundle(locale), sessionBean);
		populateRequest(request, sessionBean);
		rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, sessionBean.getCurrentPage()));
		rd.include(request, response);
	}

	protected void doDispatch(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		if (!WindowState.MINIMIZED.equals(request.getWindowState())) {
			PollUtils.loadPreferences(request);
			userLoggedIn = false;
			if (getPumaHome() != null) {
				com.ibm.portal.um.PumaProfile pumaProfile = getPumaHome().getProfile();
				if (pumaProfile != null) {
					try {
						com.ibm.portal.um.User user = pumaProfile.getCurrentUser();
						if (user != null) {
							userLoggedIn = true;
							currentUser = user;
							currentUserDN = pumaProfile.getIdentifier(user);
							System.out.println("userDN = " + currentUserDN);
						}
					} catch (PumaException e) {
						System.out.println(e.getMessage());
						e.printStackTrace();
					}
				}
			}
			PortletMode mode = request.getPortletMode();
			if (CUSTOM_CONFIG_MODE.equals(mode)) {
				doCustomConfigure(request, response);
				return;
			} else if (CUSTOM_EDIT_DEFAULTS_MODE.equals(mode)) {
				doCustomEditDefaults(request, response);
				return;
			}
		}
		super.doDispatch(request, response);
	}

	/**
	 * Process an action request.
	 * 
	 * @see javax.portlet.Portlet#processAction(javax.portlet.ActionRequest, javax.portlet.ActionResponse)
	 */
	public void processAction(ActionRequest request, ActionResponse response) throws PortletException, java.io.IOException {
		String action = request.getParameter(PARAMETER_ACTION);
		String value = request.getParameter(PARAMETER_VALUE);
		String id = request.getParameter(PARAMETER_ID);
		Locale locale = new Locale(language);
		PollManagerPortletSessionBean sessionBean = getSessionBean(request);
		sessionBean.setMessage(null);
		Container container = sessionBean.getContainer().get(sessionBean.getCurrentPage());
		if (container == null) {
			container = new Container();
		}
		// SET PARAMETERS TO BE VISIBILE FOR doView()...
		response.setRenderParameters(request.getParameterMap());
		PollActionManager pollActionManager = new PollActionManager();
		if (ACTION_NAVIGATE_TO_PAGE.equals(action)) {
			sessionBean.setCurrentPage(value);
			container = sessionBean.getContainer().get(value);
			if (container == null) {
				container = new Container();
			}
			if (id != null && id.trim().length() > 0) {
				container.setId(id);
			} else {
				container.setId(null);
			}
			sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
		} else if (ACTION_NAVIGATOR.equals(action)) {
			pollActionManager.processNavigator(sessionBean, request);
		} else if (ACTION_CHANGE_SEARCH_CRITERIA.equals(action)) {
			container.setFilterCriteria(request.getParameter("filterCriteria"));
			container.setFilterType(request.getParameter("filterType"));
			container.setFilterValue(request.getParameter("filterValue"));
			container.setFilterValue2(request.getParameter("filterValue2"));
			container.setNavigatorPage(1);
			container.setNavigatorTotalPages(1);
			sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
		} else if (ACTION_DELETE.equals(action)) {
			pollActionManager.processDelete(sessionBean, request, getPortletConfig().getResourceBundle(locale));
		} else if (ACTION_ADD.equals(action)) {
			pollActionManager.processAdd(sessionBean, request, getPortletConfig().getResourceBundle(locale));
		} else if (ACTION_EDIT.equals(action)) {
			pollActionManager.processEdit(sessionBean, request, getPortletConfig().getResourceBundle(locale));
		} else if (ACTION_SWITCH_STATUS.equals(action)) {
			pollActionManager.processSwitchStatus(sessionBean, request, getPortletConfig().getResourceBundle(locale));
		} else if (ACTION_MOVEUP.equals(action)) {
			pollActionManager.processMoveUp(sessionBean, request, getPortletConfig().getResourceBundle(locale));
		} else if (ACTION_MOVEDOWN.equals(action)) {
			pollActionManager.processMoveDown(sessionBean, request, getPortletConfig().getResourceBundle(locale));
		} else if (ACTION_SWITCH_COMPULSORY.equals(action)) {
			pollActionManager.processSwitchCompulsory(sessionBean, request, getPortletConfig().getResourceBundle(locale));
		}

		if (request.getParameter(CONFIG_SUBMIT) != null) {
			String resultsPerPage = request.getParameter(SETTING_PARAMETER_RESULTS_PER_PAGE);
			String maxItems = request.getParameter(SETTING_PARAMETER_MAX_ITEMS);
			PortletPreferences prefs = request.getPreferences();
			try {
				prefs.setValue(SETTING_PARAMETER_RESULTS_PER_PAGE, resultsPerPage);
				prefs.setValue(SETTING_PARAMETER_MAX_ITEMS, maxItems);
				prefs.store();
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("settings.were.saved")));
				response.setPortletMode(PortletMode.VIEW);
				response.setWindowState(WindowState.NORMAL);
			} catch (ReadOnlyException roe) {
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, roe.getMessage()));
			} catch (ValidatorException ve) {
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, ve.getMessage()));
			}
		} else if (request.getParameter(CONFIG_CANCEL) != null) {
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);
		}
		if (request.getParameter(EDIT_DEFAULTS_SUBMIT) != null) {
			String resultsPerPage = request.getParameter(SETTING_PARAMETER_RESULTS_PER_PAGE);
			String maxItems = request.getParameter(SETTING_PARAMETER_MAX_ITEMS);
			String language = request.getParameter(SETTING_PARAMETER_LANGUAGE);
			String vp = request.getParameter(SETTING_PARAMETER_VP);
			String theme = request.getParameter(SETTING_PARAMETER_THEME);
			PortletPreferences prefs = request.getPreferences();
			try {
				prefs.setValue(SETTING_PARAMETER_RESULTS_PER_PAGE, resultsPerPage);
				prefs.setValue(SETTING_PARAMETER_MAX_ITEMS, maxItems);
				prefs.setValue(SETTING_PARAMETER_LANGUAGE, language);
				prefs.setValue(SETTING_PARAMETER_VP, vp);
				prefs.setValue(SETTING_PARAMETER_THEME, theme);
				prefs.store();
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("settings.were.saved")));
				response.setPortletMode(PortletMode.VIEW);
				response.setWindowState(WindowState.NORMAL);
			} catch (ReadOnlyException roe) {
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, roe.getMessage()));
			} catch (ValidatorException ve) {
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, ve.getMessage()));
			}
		} else if (request.getParameter(EDIT_DEFAULTS_CANCEL) != null) {
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);
		}
	}

	protected void doCustomConfigure(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		// Set the MIME type for the render response
		response.setContentType(request.getResponseContentType());
		// Invoke the JSP to render
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, CONFIG_JSP));
		rd.include(request, response);
	}

	protected void doCustomEditDefaults(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		// Set the MIME type for the render response
		response.setContentType(request.getResponseContentType());
		// Invoke the JSP to render
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, EDIT_DEFAULTS_JSP));
		rd.include(request, response);
	}

	public void destroy() {
		System.out.println("STOPPING THREADS STARTED");
		DBPool.shutdownDataSource();
		System.out.println("STOPPING THREADS FINISHED");
	}
	
	private static PollManagerPortletSessionBean getSessionBean(PortletRequest request) {
		PortletSession session = request.getPortletSession();
		if (session == null)
			return null;
		PollManagerPortletSessionBean sessionBean = (PollManagerPortletSessionBean) session.getAttribute(SESSION_BEAN);
		if (sessionBean == null) {
			sessionBean = new PollManagerPortletSessionBean();
			session.setAttribute(SESSION_BEAN, sessionBean);
		}
		return sessionBean;
	}

	private static String getJspFilePath(RenderRequest request, String jspFile) {
		String markup = request.getProperty("wps.markup");
		if (markup == null)
			markup = getMarkup(request.getResponseContentType());
		return JSP_FOLDER + markup + "/" + jspFile + "." + getJspExtension(markup);
	}

	/**
	 * Convert MIME type to markup name.
	 * 
	 * @param contentType
	 *            MIME type
	 * @return Markup name
	 */
	private static String getMarkup(String contentType) {
		if ("text/vnd.wap.wml".equals(contentType))
			return "wml";
		else
			return "html";
	}

	/**
	 * Returns the file extension for the JSP file
	 * 
	 * @param markupName
	 *            Markup name
	 * @return JSP extension
	 */
	private static String getJspExtension(String markupName) {
		return "jsp";
	}

	private static void populateRequest(RenderRequest request, PollManagerPortletSessionBean sessionBean) {
		if (sessionBean != null && sessionBean.getParameterMap() != null && sessionBean.getParameterMap().size() > 0) {
			java.util.Map<String, String[]> map = sessionBean.getParameterMap();
			Iterator<String> it = map.keySet().iterator();
			String paramName = null;
			String[] paramValues = null;
			while (it.hasNext()) {
				paramName = (String) it.next();
				paramValues = map.get(paramName);
				if (paramValues != null) {
					if (paramValues.length > 1) {
						request.setAttribute(paramName, paramValues);
					} else {
						request.setAttribute(paramName, paramValues[0]);
					}
				}
				// System.out.println(paramName + "=" + paramValues[0]);
			}
		}
	}

	public static PumaHome getPumaHome() {
		return pumaHome;
	}
}
