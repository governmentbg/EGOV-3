package com.ibm.pollmanager;

import java.util.ResourceBundle;

import javax.portlet.ActionRequest;

import com.ibm.poll.bean.Container;
import com.ibm.poll.bean.Message;
import com.ibm.poll.management.PollManagement;
import com.ibm.poll.management.QuestionManagement;
import com.ibm.poll.management.StepManagement;

public class PollActionManager {

	public boolean processDelete(PollManagerPortletSessionBean sessionBean, ActionRequest request, ResourceBundle bundle) {
		String value = request.getParameter(PollManagerPortlet.PARAMETER_VALUE);
		if (PollManagerPortlet.INDEX_PAGE.equals(sessionBean.getCurrentPage())) {
			PollManagement pollManagement = new PollManagement();
			return (1 == pollManagement.removePoll(value, sessionBean, bundle));
		}
		if (PollManagerPortlet.STEP_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			StepManagement stepManagement = new StepManagement();
			return (1 == stepManagement.removeStep(value, sessionBean, bundle));
		}
		if (PollManagerPortlet.QUESTION_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			QuestionManagement questionManagement = new QuestionManagement();
			return (1 == questionManagement.removeQuestion(value, sessionBean, bundle));
		}
		return false;
	}

	public boolean processAdd(PollManagerPortletSessionBean sessionBean, ActionRequest request, ResourceBundle bundle) {
		sessionBean.setParameterMap(null);
		if (PollManagerPortlet.POLL_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
			String title = request.getParameter("title");
			String description = request.getParameter("description");
			String appendix = request.getParameter("appendix");
			String startDate = request.getParameter("startDate").trim();
			String endDate = request.getParameter("endDate").trim();
			String status = request.getParameter("status");
			String introMsg = request.getParameter("introMsg");
			String completionMessage = request.getParameter("completionMessage");
			String showResult = request.getParameter("showResult");
			String showTitle = request.getParameter("showTitle");
			String language = request.getParameter("language");

			if (title != null && title.trim().length() > 0 && startDate != null && startDate.trim().length() > 0 && endDate != null && endDate.trim().length() > 0 && status != null && status.trim().length() > 0) {
				if (description != null && description.trim().length() > PollConstants.MAX_TEXT_LENGTH) {
					sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("poll.description.too.long")));
				} else {
					PollManagement pollManagement = new PollManagement();
					if (pollManagement.createPoll(title, description, appendix, PollManagerPortlet.currentUserDN, startDate, endDate, status, introMsg, completionMessage, showResult, showTitle, language, PollManagerPortlet.vp, sessionBean, bundle) == 1) {
						sessionBean.setCurrentPage(PollManagerPortlet.INDEX_PAGE);
						sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_INFORMATION, "\"" + title.trim() + "\" " + bundle.getString("added.successfully.f")));
						return true;
					} else {
						sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
					}
				}
				sessionBean.setParameterMap(request.getParameterMap());
			} else {
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("invalid.parameters")));
			}
		} else if (PollManagerPortlet.STEP_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
			String title = request.getParameter("title");
			String description = request.getParameter("description");
			String showTitle = request.getParameter("showTitle");
			if (title != null && title.trim().length() > 0) {
				Container container = sessionBean.getContainer().get(PollManagerPortlet.STEP_LIST_PAGE);
				StepManagement stepManagement = new StepManagement();
				if (stepManagement.createStep(container.getId(), title, description, showTitle, sessionBean, bundle) == 1) {
					sessionBean.setCurrentPage(PollManagerPortlet.STEP_LIST_PAGE);
					sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_INFORMATION, "\"" + title.trim() + "\" " + bundle.getString("added.successfully.f")));
					return true;
				} else {
					sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
				}
				sessionBean.setParameterMap(request.getParameterMap());
			} else {
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("invalid.parameters")));
			}
		} else if (PollManagerPortlet.QUESTION_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
			Container container = sessionBean.getContainer().get(PollManagerPortlet.QUESTION_LIST_PAGE);
			String type = request.getParameter("type");
			String title = request.getParameter("title");			
			String isCompulsory = request.getParameter("isCompulsory");
			String commentLabel = request.getParameter("commentLabel");			
			String rowChoices = request.getParameter("rowChoices");
			String columnChoices = request.getParameter("columnChoices");
			if (container.getId() == null || type == null || type.trim().length() == 0 || title == null || title.trim().length() == 0 || rowChoices == null || rowChoices.trim().length() == 0 || ((PollConstants.QUESTION_TYPE_MATRIX_ONE.equals(type) || PollConstants.QUESTION_TYPE_MATRIX_MULTIPLE.equals(type)) && (columnChoices == null || columnChoices.trim().length() == 0))) {
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("invalid.parameters")));
			} else {
				QuestionManagement questionManagement = new QuestionManagement();
				if (questionManagement.createQuestion(container.getId(), type, title, isCompulsory, commentLabel, rowChoices, columnChoices, sessionBean, bundle) == 1) {
					sessionBean.setCurrentPage(PollManagerPortlet.QUESTION_LIST_PAGE);
					sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_INFORMATION, "\"" + title.trim() + "\" " + bundle.getString("added.successfully")));
					return true;
				} else {
					sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
				}
				sessionBean.setParameterMap(request.getParameterMap());
			}
		}
		return false;
	}

	public boolean processEdit(PollManagerPortletSessionBean sessionBean, ActionRequest request, ResourceBundle bundle) {
		sessionBean.setParameterMap(null);
		if (PollManagerPortlet.POLL_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
			String pollId = request.getParameter(PollManagerPortlet.PARAMETER_ID);
			String title = request.getParameter("title");
			String description = request.getParameter("description");
			String appendix = request.getParameter("appendix");
			String startDate = request.getParameter("startDate");
			String endDate = request.getParameter("endDate");
			String status = request.getParameter("status");
			String introMsg = request.getParameter("introMsg");
			String completionMessage = request.getParameter("completionMessage");
			String showResult = request.getParameter("showResult");
			String showTitle = request.getParameter("showTitle");
			String language = request.getParameter("language");
			
			if (pollId != null && pollId.trim().length() > 0 && title != null && title.trim().length() > 0 && startDate != null & startDate.trim().length() > 0 
					&& endDate != null && endDate.trim().length() > 0 && status != null & status.trim().length() > 0) {				
				PollManagement pollManagement = new PollManagement();
				if (pollManagement.updatePoll(pollId, title, description, appendix, startDate, endDate, status, introMsg, completionMessage, showResult, showTitle, language, sessionBean, bundle) == 1) {
					sessionBean.setCurrentPage(PollManagerPortlet.INDEX_PAGE);
					sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_INFORMATION, "\"" + title.trim() + "\" " + bundle.getString("edited.successfully.f")));
					return true;
				} else {
					sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
				}
				sessionBean.setParameterMap(request.getParameterMap());
			} else {
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("invalid.parameters")));
			}
		} else if (PollManagerPortlet.STEP_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
			String pollStepId = request.getParameter(PollManagerPortlet.PARAMETER_ID);
			String title = request.getParameter("title");
			String description = request.getParameter("description"); 
			String showTitle = request.getParameter("showTitle");
			if (pollStepId != null && pollStepId.trim().length() > 0 && title != null && title.trim().length() > 0) {
				StepManagement stepManagement = new StepManagement();
				if (stepManagement.updateStep(pollStepId, title, description, showTitle, sessionBean, bundle) == 1) {
					sessionBean.setCurrentPage(PollManagerPortlet.STEP_LIST_PAGE);
					sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_INFORMATION, "\"" + title.trim() + "\" " + bundle.getString("edited.successfully.f")));
					return true;
				} else {
					sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
				}
				sessionBean.setParameterMap(request.getParameterMap());
			} else {
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("invalid.parameters")));
			}
		} else if (PollManagerPortlet.QUESTION_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
			String pollQuestionId = request.getParameter(PollManagerPortlet.PARAMETER_ID);
			String type = request.getParameter("type");
			String title = request.getParameter("title");			
			String isCompulsory = request.getParameter("isCompulsory");
			String commentLabel = request.getParameter("commentLabel");			
			String rowChoices = request.getParameter("rowChoices");
			String columnChoices = request.getParameter("columnChoices");
			if (pollQuestionId == null || type == null || type.trim().length() == 0 || title == null || title.trim().length() == 0 || rowChoices == null || rowChoices.trim().length() == 0 || ((PollConstants.QUESTION_TYPE_MATRIX_ONE.equals(type) || PollConstants.QUESTION_TYPE_MATRIX_MULTIPLE.equals(type)) && (columnChoices == null || columnChoices.trim().length() == 0))) {
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("invalid.parameters")));
			} else {
				QuestionManagement questionManagement = new QuestionManagement();
				if (questionManagement.updateQuestion(pollQuestionId, type, title, isCompulsory, commentLabel, rowChoices, columnChoices, sessionBean, bundle) == 1) {
					sessionBean.setCurrentPage(PollManagerPortlet.QUESTION_LIST_PAGE);
					sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_INFORMATION, "\"" + title.trim() + "\" " + bundle.getString("edited.successfully")));
					return true;
				} else if (questionManagement.updateQuestion(pollQuestionId, type, title, isCompulsory, commentLabel, rowChoices, columnChoices, sessionBean, bundle) == 0) {
					sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("existing.results")));
				} else {
					sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
				}
				sessionBean.setParameterMap(request.getParameterMap());
			}			
		}
		return false;
	}

	public boolean processSwitchStatus(PollManagerPortletSessionBean sessionBean, ActionRequest request, ResourceBundle bundle) {
		String value = request.getParameter(PollManagerPortlet.PARAMETER_VALUE);
		if (PollManagerPortlet.INDEX_PAGE.equals(sessionBean.getCurrentPage())) {
			if (value != null && value.trim().length() > 0) {
				PollManagement pollManagement = new PollManagement();
				if (pollManagement.reversePollStatus(value, sessionBean, bundle) != 1) {
					sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
				}
			} else {
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("invalid.parameters")));
			}
		}
		return false;
	}

	public boolean processSwitchCompulsory(PollManagerPortletSessionBean sessionBean, ActionRequest request, ResourceBundle bundle) {
		String value = request.getParameter(PollManagerPortlet.PARAMETER_VALUE);
		if (PollManagerPortlet.QUESTION_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			QuestionManagement questionManagement = new QuestionManagement();
			if (questionManagement.reverseQuestionCompulsory(value, sessionBean, bundle) != 1) {
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
			}
		}
		return false;
	}

	public boolean processMoveUp(PollManagerPortletSessionBean sessionBean, ActionRequest request, ResourceBundle bundle) {
		String value = request.getParameter(PollManagerPortlet.PARAMETER_VALUE);
		if (PollManagerPortlet.STEP_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			Container container = sessionBean.getContainer().get(sessionBean.getCurrentPage());
			StepManagement stepManagement = new StepManagement();
			if (stepManagement.moveStepUp(value, container.getId(), sessionBean, bundle) != 1) {
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
			}
		} else if (PollManagerPortlet.QUESTION_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			Container container = sessionBean.getContainer().get(sessionBean.getCurrentPage());
			QuestionManagement questionManagement = new QuestionManagement();
			questionManagement.moveQuestionUp(value, container.getId(), sessionBean, bundle);
		}
		return false;
	}

	public boolean processMoveDown(PollManagerPortletSessionBean sessionBean, ActionRequest request, ResourceBundle bundle) {
		String value = request.getParameter(PollManagerPortlet.PARAMETER_VALUE);
		if (PollManagerPortlet.STEP_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			Container container = sessionBean.getContainer().get(sessionBean.getCurrentPage());
			StepManagement stepManagement = new StepManagement();
			if (stepManagement.moveStepDown(value, container.getId(), sessionBean, bundle) != 1) {
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
			}
		} else if (PollManagerPortlet.QUESTION_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			Container container = sessionBean.getContainer().get(sessionBean.getCurrentPage());
			QuestionManagement questionManagement = new QuestionManagement();
			questionManagement.moveQuestionDown(value, container.getId(), sessionBean, bundle);
		}
		return false;
	}

	public void processNavigator(PollManagerPortletSessionBean sessionBean, ActionRequest request) {
		Container container = sessionBean.getContainer().get(sessionBean.getCurrentPage());
		if (container != null) {
			String operation = request.getParameter(PollManagerPortlet.PARAMETER_OPERATION);
			String value = request.getParameter(PollManagerPortlet.PARAMETER_VALUE);
			int navigatorPage = container.getNavigatorPage();
			int navigatorTotalPages = container.getNavigatorTotalPages();
			if (operation != null && operation.trim().length() > 0) {
				if (PollManagerPortlet.NAVIGATOR_OPERATION_FIRST.equals(operation)) {
					container.setNavigatorPage(1);
				} else if (PollManagerPortlet.NAVIGATOR_OPERATION_PREVIOUS.equals(operation)) {
					if (navigatorPage > 1) {
						container.setNavigatorPage(navigatorPage - 1);
					}
				} else if (PollManagerPortlet.NAVIGATOR_OPERATION_NEXT.equals(operation)) {
					if (navigatorPage < navigatorTotalPages) {
						container.setNavigatorPage(navigatorPage + 1);
					}
				} else if (PollManagerPortlet.NAVIGATOR_OPERATION_LAST.equals(operation)) {
					container.setNavigatorPage(navigatorTotalPages);
				} else if (PollManagerPortlet.NAVIGATOR_OPERATION_GOTO.equals(operation) && value != null && value.trim().length() > 0) {
					try {
						if (Integer.parseInt(value) > navigatorTotalPages) {
							container.setNavigatorPage(navigatorTotalPages);
						} else if (Integer.parseInt(value) < 1) {
							container.setNavigatorPage(1);
						} else {
							container.setNavigatorPage(Integer.parseInt(value));
						}
					} catch (NumberFormatException e) {
						e.printStackTrace();
					}
				}
				sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
			}
		}
	}

}
