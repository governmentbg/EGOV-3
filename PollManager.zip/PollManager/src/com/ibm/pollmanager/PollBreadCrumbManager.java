package com.ibm.pollmanager;

import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import com.ibm.poll.bean.BreadCrumbNode;
import com.ibm.poll.bean.Container;
import com.ibm.poll.dbo.Poll;
import com.ibm.poll.management.StepManagement;

public class PollBreadCrumbManager {

	public static void buildBreadCrumb(RenderRequest request, RenderResponse response, ResourceBundle bundle, PollManagerPortletSessionBean sessionBean) {
		if (PollManagerPortlet.POLL_FORM_PAGE.equals(sessionBean.getCurrentPage()))
			return;
		if (PollManagerPortlet.STEP_FORM_PAGE.equals(sessionBean.getCurrentPage()))
			return;
		if (PollManagerPortlet.QUESTION_FORM_PAGE.equals(sessionBean.getCurrentPage()))
			return;

		ArrayList<BreadCrumbNode> breadCrumb = new ArrayList<BreadCrumbNode>();
		breadCrumb.add(getNode(response, bundle.getString("breadcrumb.root"), PollManagerPortlet.INDEX_PAGE, null, null));
		if (PollManagerPortlet.STEP_LIST_PAGE.equals(sessionBean.getCurrentPage()) || PollManagerPortlet.QUESTION_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			Container container = sessionBean.getContainer().get(PollManagerPortlet.STEP_LIST_PAGE);
			if (container != null && container.getId() != null) {
				ArrayList<String> extraParametersNames = new ArrayList<String>();
				ArrayList<String> extraParametersValues = new ArrayList<String>();
				extraParametersNames.add(PollManagerPortlet.PARAMETER_ID);
				extraParametersValues.add(container.getId());
				breadCrumb.add(getNode(response, ((Poll) container.getObject()).getTitle(), PollManagerPortlet.STEP_LIST_PAGE, extraParametersNames, extraParametersValues));
				if (PollManagerPortlet.QUESTION_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
					container = sessionBean.getContainer().get(PollManagerPortlet.QUESTION_LIST_PAGE);
					if (container != null && container.getId() != null) {
						System.out.println("ID = " + container.getId() + " PAGE " + sessionBean.getCurrentPage());
						StepManagement stepManagement = new StepManagement();
						if (stepManagement.loadStepById(container.getId(), null) == 1) {
							extraParametersNames = new ArrayList<String>();
							extraParametersValues = new ArrayList<String>();
							extraParametersNames.add(PollManagerPortlet.PARAMETER_ID);
							extraParametersValues.add(container.getId());
							breadCrumb.add(getNode(response, stepManagement.getCurrentStep().getTitle(), PollManagerPortlet.QUESTION_LIST_PAGE, null, null));
						}
					}
				}
			} else {
				breadCrumb.add(getNode(response, bundle.getString("breadcrumb.steps"), PollManagerPortlet.STEP_LIST_PAGE, null, null));
			}
		} else if (PollManagerPortlet.QUESTION_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			breadCrumb.add(getNode(response, bundle.getString("breadcrumb.questions"), PollManagerPortlet.QUESTION_LIST_PAGE, null, null));
		} else if (PollManagerPortlet.POLL_RESULTS_PAGE.equals(sessionBean.getCurrentPage())) {
			Container container = sessionBean.getContainer().get(sessionBean.getCurrentPage());
			if (container != null && container.getId() != null) {
				ArrayList<String> extraParametersNames = new ArrayList<String>();
				ArrayList<String> extraParametersValues = new ArrayList<String>();
				extraParametersNames.add(PollManagerPortlet.PARAMETER_ID);
				extraParametersValues.add(container.getId());
				breadCrumb.add(getNode(response, ((Poll) container.getObject()).getTitle(), PollManagerPortlet.INDEX_PAGE, extraParametersNames, extraParametersValues));
			} 
		}
		sessionBean.setBreadCrumb(breadCrumb);
	}

	private static BreadCrumbNode getNode(RenderResponse response, String nodeName, String nodePage, ArrayList<String> extraParametersNames, ArrayList<String> extraParametersValues) {
		BreadCrumbNode breadCrumbNode = new BreadCrumbNode();
		breadCrumbNode.setName(nodeName);
		PortletURL breadCrumbActionUrl = response.createActionURL();
		breadCrumbActionUrl.setParameter(PollManagerPortlet.PARAMETER_ACTION, PollManagerPortlet.ACTION_NAVIGATE_TO_PAGE);
		breadCrumbActionUrl.setParameter(PollManagerPortlet.PARAMETER_VALUE, nodePage);
		breadCrumbActionUrl.setParameter(PollManagerPortlet.PARAMETER_SOURCE, PollManagerPortlet.SOURCE_BREADCRUMB);
		if (extraParametersNames != null && extraParametersValues != null && extraParametersNames.size() == extraParametersValues.size()) {
			for (int i = 0; i < extraParametersNames.size(); i++) {
				breadCrumbActionUrl.setParameter(extraParametersNames.get(i), extraParametersValues.get(i));
			}
		}
		breadCrumbNode.setUrl(breadCrumbActionUrl.toString());
		return breadCrumbNode;
	}

}
