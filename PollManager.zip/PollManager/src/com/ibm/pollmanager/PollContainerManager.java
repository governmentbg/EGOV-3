package com.ibm.pollmanager;

import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import com.ibm.poll.bean.Container;
import com.ibm.poll.bean.Message;
import com.ibm.poll.dbo.Poll;
import com.ibm.poll.dbo.PollQuestion;
import com.ibm.poll.dbo.PollStep;
import com.ibm.poll.management.PollManagement;
import com.ibm.poll.management.QuestionManagement;
import com.ibm.poll.management.StepManagement;
import com.ibm.poll.utils.PollUtils;

public class PollContainerManager {
		
		public static void process(RenderRequest request, RenderResponse response, ResourceBundle bundle, PollManagerPortletSessionBean sessionBean) {
			Container container = sessionBean.getContainer().get(sessionBean.getCurrentPage());
			if (container == null) container = new Container();
			if (PollManagerPortlet.INDEX_PAGE.equals(sessionBean.getCurrentPage())) {
				processIndexPage(container, sessionBean);
			} else if (PollManagerPortlet.STEP_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
				processStepListPage(container, sessionBean, bundle);
			} else if (PollManagerPortlet.QUESTION_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
				processQuestionListPage(container, sessionBean, bundle);							
			} else if (PollManagerPortlet.POLL_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
				processPollFormPage(container, sessionBean, bundle);
			} else if (PollManagerPortlet.POLL_RESULTS_PAGE.equals(sessionBean.getCurrentPage())) {
				processPollResultsPage(container, sessionBean, bundle);
			} else if (PollManagerPortlet.STEP_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
				processStepFormPage(container, sessionBean, bundle);
			} else if (PollManagerPortlet.QUESTION_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
				processQuestionFormPage(container, sessionBean, bundle);
			} 
			if (PollManagerPortlet.MODE_PREVIEW.equals(request.getParameter(PollManagerPortlet.PARAMETER_MODE))) {
				request.setAttribute(PollManagerPortlet.PARAMETER_MODE, request.getParameter(PollManagerPortlet.PARAMETER_MODE));
			}
		}	
		
		private static void processIndexPage(Container container, PollManagerPortletSessionBean sessionBean) {
			int navigatorPage = container.getNavigatorPage();
			int totalPages = container.getNavigatorTotalPages();
			container.clearObject();
			PollManagement pollManagement = new PollManagement();
			if (pollManagement.loadAllPolls(PollManagerPortlet.vp) > 0) {
				Poll[] polls = pollManagement.getPolls();
				navigatorPage = PollUtils.getCurrentPageNumber(polls.length, navigatorPage, PollManagerPortlet.resultsPerPage);
				totalPages = PollUtils.getTotalPages(polls.length, PollManagerPortlet.resultsPerPage);
				ArrayList<Object> filteredPolls = PollNavigatorManager.filterResults(polls, PollManagerPortlet.resultsPerPage, navigatorPage);
				container.setResults((Poll[])filteredPolls.toArray(new Poll[filteredPolls.size()]));
			} else {
				navigatorPage = 1;
				totalPages = 1;
			}
			container.setNavigatorPage(navigatorPage);
			container.setNavigatorTotalPages(totalPages);
			sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
		}
		
		private static void processQuestionListPage(Container container, PollManagerPortletSessionBean sessionBean, ResourceBundle bundle) {
			int navigatorPage = container.getNavigatorPage();
			int totalPages = container.getNavigatorTotalPages();
			String stepId = container.getId();
			container.clearObject(); 
			QuestionManagement questionManagement = new QuestionManagement();
			if (questionManagement.loadAllPollQuestionsByStepId(stepId) > 0) {
				PollQuestion[] pollQuestions = questionManagement.getQuestions();
				navigatorPage = PollUtils.getCurrentPageNumber(pollQuestions.length, navigatorPage, PollManagerPortlet.resultsPerPage);
				totalPages = PollUtils.getTotalPages(pollQuestions.length, PollManagerPortlet.resultsPerPage);
				ArrayList<Object> filteredQuestions = PollNavigatorManager.filterResults(pollQuestions, PollManagerPortlet.resultsPerPage, navigatorPage);
				container.setResults((PollQuestion[])filteredQuestions.toArray(new PollQuestion[filteredQuestions.size()]));
			} else { 
				navigatorPage = 1;
				totalPages = 1;
			}
			container.setNavigatorPage(navigatorPage);
			container.setNavigatorTotalPages(totalPages);
			sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
		}
		
		private static void processStepListPage(Container container, PollManagerPortletSessionBean sessionBean, ResourceBundle bundle) {
			int navigatorPage = container.getNavigatorPage();
			int totalPages = container.getNavigatorTotalPages();
			container.clearObject();
			StepManagement stepManagement = new StepManagement();
			if (stepManagement.loadAllPollStepsByPollId(container.getId()) > 0) {
				PollStep[] steps = stepManagement.getSteps();
				navigatorPage = PollUtils.getCurrentPageNumber(steps.length, navigatorPage, PollManagerPortlet.resultsPerPage);
				totalPages = PollUtils.getTotalPages(steps.length, PollManagerPortlet.resultsPerPage);
				ArrayList<Object> filteredSteps = PollNavigatorManager.filterResults(steps, PollManagerPortlet.resultsPerPage, navigatorPage);
				container.setResults((PollStep[])filteredSteps.toArray(new PollStep[filteredSteps.size()]));				
			} else {
				navigatorPage = 1;
				totalPages = 1;
			}
			PollManagement pollManagement = new PollManagement();
			if (pollManagement.loadPollById(container.getId(), null) > 0) {
				container.setObject(pollManagement.getCurrentPoll());
			}
			container.setNavigatorPage(navigatorPage);
			container.setNavigatorTotalPages(totalPages);
			sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
		}

		private static void processPollFormPage(Container container, PollManagerPortletSessionBean sessionBean, ResourceBundle bundle) {
			if (container == null) container = new Container();
			container.clearObject();
			String pollId = container.getId();
			if (pollId != null && pollId.trim().length() > 0) {
				PollManagement pollManagement = new PollManagement();
				if (pollManagement.loadPollById(pollId, null) == 1) {
					container.setObject(pollManagement.getCurrentPoll());
				} else {
					sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("poll.with.id.not.found") + pollId));
					sessionBean.setCurrentPage(PollManagerPortlet.INDEX_PAGE);
				}
			}			
			sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
		}
		
		private static void processPollResultsPage(Container container, PollManagerPortletSessionBean sessionBean, ResourceBundle bundle) {
			int navigatorPage = container.getNavigatorPage();
			int totalPages = container.getNavigatorTotalPages();
			container.clearObject();
			PollManagement pollManagement = new PollManagement();
			if (pollManagement.loadActivePollByIdWithAllRelative(container.getId()) == 1) {
				container.setObject(pollManagement.getCurrentPoll());
				container.setNavigatorPage(navigatorPage);
				container.setNavigatorTotalPages(totalPages);
				sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
			} else {
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("poll.create.complete.structure")));
				sessionBean.setCurrentPage(PollManagerPortlet.INDEX_PAGE);
			}
		}
		
		private static void processStepFormPage(Container container, PollManagerPortletSessionBean sessionBean, ResourceBundle bundle) {
			if (container == null) container = new Container();
			container.clearObject();
			String stepId = container.getId();
			if (stepId != null && stepId.trim().length() > 0) {
				StepManagement stepManagement = new StepManagement();
				if (stepManagement.loadStepById(stepId, null) == 1) {
					container.setObject(stepManagement.getCurrentStep());
				} else {
					sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("step.with.id.not.found") + stepId));
					sessionBean.setCurrentPage(PollManagerPortlet.STEP_LIST_PAGE);
				}
			}
			sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
		}
		
		private static void processQuestionFormPage(Container container, PollManagerPortletSessionBean sessionBean, ResourceBundle bundle) {
			if (container == null) container = new Container();
			container.clearObject();
			String questionId = container.getId();
			if (questionId != null && questionId.trim().length() > 0) {
				QuestionManagement questionManagement = new QuestionManagement();
				if (questionManagement.loadQuestionWithOptionsById(questionId, null) == 1) {
					container.setObject(questionManagement.getCurrentQuestion());
				} else {
					sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("question.with.id.not.found") + questionId));
					sessionBean.setCurrentPage(PollManagerPortlet.QUESTION_LIST_PAGE);
				}
			}
			sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
		}
	}
