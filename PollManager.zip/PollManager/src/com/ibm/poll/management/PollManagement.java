package com.ibm.poll.management;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.ResourceBundle;

import com.ibm.poll.bean.Message;
import com.ibm.poll.bean.PollResult;
import com.ibm.poll.db.DBResources;
import com.ibm.poll.db.DBTransaction;
import com.ibm.poll.db.FinderException;
import com.ibm.poll.db.QueryExecution;
import com.ibm.poll.dbo.Poll;
import com.ibm.poll.dbo.PollQuestion;
import com.ibm.poll.dbo.PollQuestionLabel;
import com.ibm.poll.dbo.PollQuestionOption;
import com.ibm.poll.dbo.PollQuestionResult;
import com.ibm.poll.dbo.PollStep;
import com.ibm.poll.utils.PollUtils;
import com.ibm.pollmanager.PollConstants;
import com.ibm.pollmanager.PollManagerPortletSessionBean;

public class PollManagement {

	private Poll[] polls = null;
	private int pollCounter = 0;
	private Poll currentPoll = null;

	public Poll[] getPolls() {
		return polls;
	}

	public void setPolls(Poll[] polls) {
		this.polls = polls;
	}

	public int getPollCounter() {
		return pollCounter;
	}

	public void setPollCounter(int pollCounter) {
		this.pollCounter = pollCounter;
	}

	public Poll getCurrentPoll() {
		if (currentPoll == null)
			currentPoll = new Poll();
		return currentPoll;
	}

	public void setCurrentPoll(Poll currentPoll) {
		this.currentPoll = currentPoll;
	}

	public boolean selectNextPoll() {
		if (polls != null) {
			if (pollCounter < polls.length) {
				setCurrentPoll(polls[pollCounter++]);
				return true;
			}
		}
		return false;
	}

	public int loadPollById(String id, DBTransaction transaction) {
		try {
			Poll tmpPoll = Poll.findById(id, transaction);
			if (tmpPoll != null) {
				setCurrentPoll(tmpPoll);
				return 1;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			System.out.println("PollManagement : loadPollById : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

	public int loadAllPolls(String vp) {
		try {
			pollCounter = 0;
			polls = null;
			polls = Poll.findAllByVP(vp, null);
			if (polls != null) {
				pollCounter = 0;
				return polls.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("PollManagement : loadAllPolls : " + e.getMessage());

		}
		return -1;
	}
	
	public int loadActivePollByIdWithAllRelative(String pollId) {
		DBTransaction transaction = null;
		int result = -1;
		try {
			transaction = new DBTransaction();
			if (PollConstants._DB_ORACLE.equalsIgnoreCase(DBResources._DB)) {
				QueryExecution.setSessionTimestampFormat(transaction);
			}
			Poll poll = Poll.findByIdActivePoll(pollId, transaction);
			if (poll != null) {
				PollStep[] pollSteps = null;
				try {
					pollSteps = PollStep.findAllStepsByPollId(pollId, transaction);
				} catch (FinderException e) {
				}
				if (pollSteps != null && pollSteps.length > 0) {
					StringBuffer pollStepsIds = new StringBuffer();
					for (int i = 0; i < pollSteps.length; i++) {
						if (pollStepsIds.toString().length() > 0) {
							pollStepsIds.append(",");
						}
						pollStepsIds.append(pollSteps[i].getId());
					}
					PollQuestion[] pollQuestions = null;
					try {
						pollQuestions = PollQuestion.findAllQuestionsByStepIds(pollStepsIds.toString(), transaction);
					} catch (FinderException e) {
					}
					if (pollQuestions != null && pollQuestions.length > 0) {
						StringBuffer pollQuestionsIds = new StringBuffer();
						for (int i = 0; i < pollQuestions.length; i++) {
							if (pollQuestionsIds.toString().length() > 0) {
								pollQuestionsIds.append(",");
							}
							pollQuestionsIds.append(pollQuestions[i].getId());
						}
						PollQuestionOption[] pollQuestionOptions = null;
						try { 
							pollQuestionOptions = PollQuestionOption.findAllOptionsByQuestionIds(pollQuestionsIds.toString(), transaction);
						} catch (FinderException e) {
						}
						PollQuestionLabel[] pollQuestionLabels = null;
						try {
							pollQuestionLabels = PollQuestionLabel.findAllLabelsByQuestionIds(pollQuestionsIds.toString(), transaction);
						} catch (FinderException e) {
						}
						// SORT ALL OPTIONS PER QUESTION
						HashMap<String, ArrayList<PollQuestionOption>> pollQuestionOptionsHm = new HashMap<String, ArrayList<PollQuestionOption>>();
						ArrayList<PollQuestionOption> tmpPollQuestionOptionArr = null;
						if (pollQuestionOptions != null && pollQuestionOptions.length > 0) {
							tmpPollQuestionOptionArr = new ArrayList<PollQuestionOption>();
							for (int i = 0; i < pollQuestionOptions.length; i++) {
								tmpPollQuestionOptionArr = pollQuestionOptionsHm.get(pollQuestionOptions[i].getPollQuestionId());
								if (tmpPollQuestionOptionArr == null) {
									tmpPollQuestionOptionArr = new ArrayList<PollQuestionOption>();
								}
								tmpPollQuestionOptionArr.add(pollQuestionOptions[i]);
								pollQuestionOptionsHm.put(pollQuestionOptions[i].getPollQuestionId(), tmpPollQuestionOptionArr);
							}
						}
						// SORT ALL LABELS PER QUESTION
						HashMap<String, ArrayList<PollQuestionLabel>> pollQuestionLabelsHm = new HashMap<String, ArrayList<PollQuestionLabel>>();
						ArrayList<PollQuestionLabel> tmpPollQuestionLabelArr = null;
						if (pollQuestionLabels != null && pollQuestionLabels.length > 0) {
							tmpPollQuestionLabelArr = new ArrayList<PollQuestionLabel>();
							for (int i = 0; i < pollQuestionLabels.length; i++) {
								tmpPollQuestionLabelArr = pollQuestionLabelsHm.get(pollQuestionLabels[i].getPollQuestionId());
								if (tmpPollQuestionLabelArr == null) {
									tmpPollQuestionLabelArr = new ArrayList<PollQuestionLabel>();
								}
								tmpPollQuestionLabelArr.add(pollQuestionLabels[i]);
								pollQuestionLabelsHm.put(pollQuestionLabels[i].getPollQuestionId(), tmpPollQuestionLabelArr);
							}
						}
						// SORT ALL QUESTION PER STEP
						HashMap<String, ArrayList<PollQuestion>> pollQuestionsHm = new HashMap<String, ArrayList<PollQuestion>>();
						ArrayList<PollQuestion> tmpPollQuestionArr = new ArrayList<PollQuestion>();
						for (int i = 0; i < pollQuestions.length; i++) {
							tmpPollQuestionArr = pollQuestionsHm.get(pollQuestions[i].getPollStepId());
							if (tmpPollQuestionArr == null) {
								tmpPollQuestionArr = new ArrayList<PollQuestion>();
							}
							tmpPollQuestionArr.add(pollQuestions[i]);
							pollQuestionsHm.put(pollQuestions[i].getPollStepId(), tmpPollQuestionArr);
						}
						// POPULATE EACH STEP WITH RELATIVE DATA IF NO QUESTION FOUND IN STEP -> SKIP IT...
						ArrayList<PollStep> filteredPollSteps = new ArrayList<PollStep>();
						PollStep tmpStep = null;
						PollQuestion tmpPollQuestion = null;
						for (int i = 0; i < pollSteps.length; i++) {
							tmpStep = pollSteps[i];
							tmpPollQuestionArr = pollQuestionsHm.get(tmpStep.getId());
							if (tmpPollQuestionArr != null && tmpPollQuestionArr.size() > 0) {
								for (int j = 0; j < tmpPollQuestionArr.size(); j++) {
									tmpPollQuestion = tmpPollQuestionArr.get(j);
									tmpPollQuestionOptionArr = pollQuestionOptionsHm.get(tmpPollQuestion.getId());
									if (tmpPollQuestionOptionArr != null) {
										tmpPollQuestion.setPollQuestionOptions((PollQuestionOption[]) tmpPollQuestionOptionArr.toArray(new PollQuestionOption[tmpPollQuestionOptionArr.size()]));
									}
									tmpPollQuestionLabelArr = pollQuestionLabelsHm.get(tmpPollQuestion.getId());
									if (tmpPollQuestionLabelArr != null) {
										tmpPollQuestion.setPollQuestionLabels((PollQuestionLabel[]) tmpPollQuestionLabelArr.toArray(new PollQuestionLabel[tmpPollQuestionLabelArr.size()]));
									}
								}
								// Sort questions by sequence.
								tmpPollQuestionArr = orderQuestionsBySequence(tmpPollQuestionArr);
								tmpStep.setPollQuestions((PollQuestion[]) tmpPollQuestionArr.toArray(new PollQuestion[tmpPollQuestionArr.size()]));
								filteredPollSteps.add(tmpStep);
							}
						}
						poll.setPollSteps((PollStep[]) filteredPollSteps.toArray(new PollStep[filteredPollSteps.size()]));
						setCurrentPoll(poll);
						result = 1;
						tmpPollQuestion = null;
						tmpPollQuestionArr = null;
						tmpPollQuestionLabelArr = null;
						tmpPollQuestionOptionArr = null;
						pollQuestionsHm = null;
						pollQuestionOptionsHm = null;
						pollQuestionLabelsHm = null;
					}
				}
			}
			transaction.commit();
		} catch (Exception e) {
			System.out.println("PollManagement : loadActivePollByIdWithAllRelative : " + e.getMessage());
			e.printStackTrace();
			if (transaction != null) {
				try {
					transaction.commit();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			result = -1;
		}
		return result;
	}
	
	private ArrayList<PollQuestion> orderQuestionsBySequence(ArrayList<PollQuestion> pollQuestionArr) {
		if (pollQuestionArr == null || pollQuestionArr.size() == 0) {
			return pollQuestionArr;
		}
		ArrayList<PollQuestion> orderedResults = new ArrayList<PollQuestion>();
		PollQuestion pollQuestion = null;
		ArrayList<Integer> sequences = new ArrayList<Integer>();
		Integer sequence = null;
		ArrayList<PollQuestion> pollQuestions = null;
		HashMap<Integer, ArrayList<PollQuestion>> pollQuestionBySequence = new HashMap<Integer, ArrayList<PollQuestion>>();
		for (int i = 0; i < pollQuestionArr.size(); i++) {
			pollQuestion = pollQuestionArr.get(i);
			sequence = Integer.parseInt(pollQuestion.getSequence());
			if (!sequences.contains(sequence)) {
				sequences.add(sequence);
			}
			pollQuestions = pollQuestionBySequence.get(sequence);
			if (pollQuestions == null) {
				pollQuestions = new ArrayList<PollQuestion>();
			}
			pollQuestions.add(pollQuestion);
			pollQuestionBySequence.put(sequence, pollQuestions);
		}
		Integer[] allSequences = (Integer[])sequences.toArray(new Integer[sequences.size()]); 
		Arrays.sort(allSequences);
		for (int i = 0; i < allSequences.length; i++) {
			pollQuestions = pollQuestionBySequence.get(allSequences[i]);
			if (pollQuestions != null && pollQuestions.size() > 0) {
				for (int j = 0; j < pollQuestions.size(); j++) {
					orderedResults.add(pollQuestions.get(j));
				}
			}
		}
		return orderedResults;
	}

	public PollResult getAllPollResultsByFilter(String pollId, String startDate, String endDate) {
		PollResult pollResult = new PollResult();
		HashMap<String, String> results = new HashMap<String, String>();
		HashMap<String, ArrayList<String>> comments = new HashMap<String, ArrayList<String>>();		
		try {
			com.ibm.poll.dbo.PollResult[] pollResults = null;
			try {
				pollResults = com.ibm.poll.dbo.PollResult.findAllByPollId(pollId, null);
				// TODO replace with filter
//				pollResults = com.ibm.poll.dbo.PollResult.findAllByPollIdAndPeriod(pollId, startDate, endDate, null);
			} catch (FinderException e) {
				
			}
			if (pollResults != null && pollResults.length > 0) {
				pollResult.setTotal(pollResults.length);
				pollResult.setFrom(pollResults[0].getCreationDate().getTime());
				pollResult.setTo(pollResults[pollResults.length - 1].getCreationDate().getTime());
				String pollResultIds = "";
				for (int i = 0; i < pollResults.length; i++) {
					if (pollResultIds.trim().length() > 0) {
						pollResultIds += ",";
					}
					pollResultIds += pollResults[i].getId();
				}
				
				// Load all question results for founded poll results.
				PollQuestionResult[] pollQuestionResults = null;
				try {
					pollQuestionResults = PollQuestionResult.findAllQuestionResultsByPollResultIds(pollResultIds, null);
				} catch (FinderException e) {
				}	
				if (pollQuestionResults != null && pollQuestionResults.length > 0) {								
					String count = null;
					ArrayList<String> tmp = null;
					ArrayList<String> pollResultComments = new ArrayList<String>();
					for (int i = 0; i < pollQuestionResults.length; i++) {
						count = results.get(pollQuestionResults[i].getPollQuestionOptionId() + "_" + pollQuestionResults[i].getPollQuestionLabelId());
						if (count == null) {
							count = "0";
						}
						try {
							count = String.valueOf(Integer.parseInt(count) + 1);
	 					} catch (NumberFormatException e) {
							e.printStackTrace();
						}
						results.put(pollQuestionResults[i].getPollQuestionOptionId() + "_" + pollQuestionResults[i].getPollQuestionLabelId(), count);
						if (pollQuestionResults[i].getQuestionComment() != null && pollQuestionResults[i].getQuestionComment().trim().length() > 0) {
							// Each Comments is added to each answer to the same question, so in order to prevent duplication we render only the first one.
							if (!pollResultComments.contains(pollQuestionResults[i].getPollResultId() + "_" + pollQuestionResults[i].getPollQuestionId())) {
								tmp = comments.get(pollQuestionResults[i].getPollQuestionId());
								if (tmp == null) {
									tmp = new ArrayList<String>();
								}
								tmp.add(pollQuestionResults[i].getQuestionComment());
								comments.put(pollQuestionResults[i].getPollQuestionId(), tmp);
								pollResultComments.add(pollQuestionResults[i].getPollResultId() + "_" + pollQuestionResults[i].getPollQuestionId());
							}
						}
					}				
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("PollManagement : getAllPollResultsByFilter : " + e.getMessage());
		}
		pollResult.setResults(results);
		pollResult.setComments(comments);		
		return pollResult;
	}
		
	/**
	 * @deprecated
	 * @param pollId
	 * @return
	 */
	public PollResult getAllPollQuestionResultsByPollId(String pollId) {	
		PollResult pollResult = new PollResult();
		HashMap<String, String> results = new HashMap<String, String>();
		HashMap<String, ArrayList<String>> comments = new HashMap<String, ArrayList<String>>();		
		try {
			PollQuestionResult[] pollQuestionResults = null;
			try {
				pollQuestionResults = PollQuestionResult.findAllQuestionResultsByPollId(pollId, null);
			} catch (FinderException e) {
			}	
			if (pollQuestionResults != null && pollQuestionResults.length > 0) {								
				String count = null;
				ArrayList<String> tmp = null;
				ArrayList<String> pollResults = new ArrayList<String>();
				for (int i = 0; i < pollQuestionResults.length; i++) {
					count = results.get(pollQuestionResults[i].getPollQuestionOptionId() + "_" + pollQuestionResults[i].getPollQuestionLabelId());
					if (count == null) {
						count = "0";
					}
					try {
						count = String.valueOf(Integer.parseInt(count) + 1);
 					} catch (NumberFormatException e) {
						e.printStackTrace();
					}
					results.put(pollQuestionResults[i].getPollQuestionOptionId() + "_" + pollQuestionResults[i].getPollQuestionLabelId(), count);
					if (pollQuestionResults[i].getQuestionComment() != null && pollQuestionResults[i].getQuestionComment().trim().length() > 0) {
						// Each Comments is added to each answer to the same question, so in order to prevent duplication we render only the first one.
						if (!pollResults.contains(pollQuestionResults[i].getPollResultId() + "_" + pollQuestionResults[i].getPollQuestionId())) {
							tmp = comments.get(pollQuestionResults[i].getPollQuestionId());
							if (tmp == null) {
								tmp = new ArrayList<String>();
							}
							tmp.add(pollQuestionResults[i].getQuestionComment());
							comments.put(pollQuestionResults[i].getPollQuestionId(), tmp);
							pollResults.add(pollQuestionResults[i].getPollResultId() + "_" + pollQuestionResults[i].getPollQuestionId());
						}
					}
				}				
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("PollManagement : getAllPollQuestionResultsByPollId : " + e.getMessage());
		}
		pollResult.setResults(results);
		pollResult.setComments(comments);		
		return pollResult;
	}

	public int createPoll(String title, String description, String appendix, String userDN, String startDate, String endDate, String status, String introMsg, String completionMessage, String showResult, String showTitle, String language, String vp, PollManagerPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		long currentTime = System.currentTimeMillis();
		try {
			transaction = new DBTransaction();
			Poll poll = new Poll();
			poll.setTitle(title.trim());
			poll.setDescription((description != null) ? description.trim() : null);
			poll.setAppendix((appendix != null) ? appendix.trim() : null);
			poll.setUserDN(userDN);
			poll.setStartDate(PollUtils.timeMillisToTimestamp(PollUtils.date_yyyy_MM_dd_ToTimeMillis(startDate.trim(), true)));
			poll.setEndDate(PollUtils.timeMillisToTimestamp(PollUtils.date_yyyy_MM_dd_ToTimeMillis(endDate.trim(), false)));
			poll.setStatus(status);
			poll.setIntroMsg((introMsg != null) ? introMsg.trim() : null);
			poll.setCompletionMessage((completionMessage != null) ? completionMessage.trim() : null);
			poll.setShowResult((PollConstants.POLL_SHOW_RESULT.equals(showResult)) ? PollConstants.POLL_SHOW_RESULT : PollConstants.POLL_HIDE_RESULTS);
			poll.setShowTitle((PollConstants.POLL_SHOW_TITLE.equals(showTitle)) ? PollConstants.POLL_SHOW_TITLE : PollConstants.POLL_HIDE_TITLE);
			poll.setLanguage((language != null) ? language.trim() : null);
			poll.setVp((vp != null) ? vp.trim() : null);
			poll.setCreationDate(PollUtils.timeMillisToTimestamp(currentTime));
			poll.create(transaction);
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println("PollManagement : createPoll : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("PollManagement : createPoll : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
		}
		return -1;
	}

	public int updatePoll(String pollId, String title, String description, String appendix, String startDate, String endDate, String status, String introMsg, String completionMessage, String showResult, String showTitle, String language, PollManagerPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		int result = -1;
		try {
			transaction = new DBTransaction();
			Poll poll = null;
			try {
				poll = Poll.findById(pollId, transaction);
			} catch (FinderException e) {
			}
			if (poll == null) {
				throw new Exception(bundle.getString("poll.with.id.not.found") + " " + pollId + "!");
			}
			poll.setTitle(title.trim());
			poll.setDescription((description != null) ? description.trim() : null);
			poll.setAppendix((appendix != null) ? appendix.trim() : null);
			poll.setStartDate(PollUtils.timeMillisToTimestamp(PollUtils.date_yyyy_MM_dd_ToTimeMillis(startDate.trim(), true)));
			poll.setEndDate(PollUtils.timeMillisToTimestamp(PollUtils.date_yyyy_MM_dd_ToTimeMillis(endDate.trim(), false)));
			poll.setStatus(status);
			poll.setIntroMsg((introMsg != null) ? introMsg.trim() : null);
			poll.setCompletionMessage((completionMessage != null) ? completionMessage.trim() : null);
			poll.setShowResult((PollConstants.POLL_SHOW_RESULT.equals(showResult)) ? PollConstants.POLL_SHOW_RESULT : PollConstants.POLL_HIDE_RESULTS);
			poll.setShowTitle((PollConstants.POLL_SHOW_TITLE.equals(showTitle)) ? PollConstants.POLL_SHOW_TITLE : PollConstants.POLL_HIDE_TITLE);			
			poll.setLanguage((language != null) ? language.trim() : null);
			poll.store(transaction);
			transaction.commit();
			result = 1;
		} catch (Exception e) {
			System.out.println("PollManagement : updatePoll : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("PollManagement : updatePoll : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
		}
		return result;
	}

	public int reversePollStatus(String pollId, PollManagerPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		int result = -1;
		try {
			transaction = new DBTransaction();
			Poll poll = null;
			try {
				poll = Poll.findById(pollId, transaction);
			} catch (FinderException e) {
			}
			if (poll == null) {
				throw new Exception(bundle.getString("poll.with.id.not.found") + " " + pollId + "!");
			}
			poll.setStatus(PollConstants.POLL_STATUS_ACTIVE.equals(poll.getStatus()) ? PollConstants.POLL_STATUS_INACTIVE : PollConstants.POLL_STATUS_ACTIVE);
			poll.store(transaction);
			transaction.commit();
			sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_INFORMATION, poll.getTitle() + " " + bundle.getString("switched.successfully") + (PollConstants.POLL_STATUS_ACTIVE.equals(poll.getStatus()) ? bundle.getString("active") : bundle.getString("inactive"))));
			result = 1;
		} catch (Exception e) {
			System.out.println("PollManagement : updatePollStatus : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("PollManagement : updatePollStatus : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
		}
		return result;
	}

	public int removePoll(String pollId, PollManagerPortletSessionBean sessionBean, ResourceBundle bundle) {
		System.out.println("inside remove poll");
		DBTransaction transaction = null;
		int result = -1;
		try {
			transaction = new DBTransaction();
			Poll tmpPoll = null;
			PollStep[] pollSteps = null;
			PollQuestion[] pollQuestions = null;
//			PollQuestionOption[] pollQuestionOptions = null;
			try {
				tmpPoll = Poll.findById(pollId, transaction);
			} catch (FinderException e) {
			}
			if (tmpPoll != null) {
				System.out.println("poll not null");
				try {
					pollSteps = PollStep.findAllStepsByPollId(pollId, transaction);
				} catch (FinderException e) {
					System.err.println("FinderException! " + e);
				}
				if (pollSteps != null && pollSteps.length > 0) {
					System.out.println("pollSteps " + pollSteps.length);
					StringBuffer stepIds = new StringBuffer();
					for (int i = 0; i < pollSteps.length; i++) {
						if (stepIds.toString().length() > 0) {
							stepIds.append(",");
						}
						stepIds.append(pollSteps[i].getId());
					}
					try {
						pollQuestions = PollQuestion.findAllQuestionsByStepIds(stepIds.toString(), transaction);
						//
					} catch (FinderException e) {
						System.err.println("FinderException! " + e);
					}
					if (pollQuestions != null && pollQuestions.length > 0) {
						StringBuffer pollQuestionIds = new StringBuffer();
						for (int i = 0; i < pollQuestions.length; i++) {
							if (pollQuestionIds.length() > 0) {
								pollQuestionIds.append(",");
							}
							pollQuestionIds.append(pollQuestions[i].getId());
						}
						//pollQuestionOptions = PollQuestionOption.findAllOptionsByQuestionIds(pollQuestionIds.toString(), transaction);
						//System.out.println("pollQuestionIds " + pollQuestionIds.toString());
						// DELETE ALL POLLQUESTIONSLABEL FOR CURRENT FOUND POLLQUESTIONIDS...
						PollQuestionLabel pollQuestionLabel = new PollQuestionLabel();
						pollQuestionLabel.removeConditional("POLLQUESTIONID IN (" + pollQuestionIds.toString() + ")", transaction);
						System.out.println("removed pollquenstionid");
						// DELETE ALL POLLQUESTIONRESULT FOR POLLQUESTIONID...
						PollQuestionResult pollQuestionResult = new PollQuestionResult();
						pollQuestionResult.removeConditional("POLLQUESTIONID IN (" + pollQuestionIds.toString() + ")", transaction);
						System.out.println("removed pollQuestionResult");
						// DELETE ALL POLLQUESTIONOPTION FOR CURRENT FOUND POLLQUESTIONIDS...
						PollQuestionOption pollQuestionOption = new PollQuestionOption();
						pollQuestionOption.removeConditional("POLLQUESTIONID IN (" + pollQuestionIds.toString() + ")", transaction);
						System.out.println("removed PollQuestionOption");
						// DELETE ALL POLLQUESTIONS FOR FOUND POLLSTEPS
						PollQuestion pollQuestion = new PollQuestion();
						pollQuestion.removeConditional("POLLSTEPID IN (" + stepIds.toString() + ")", transaction);
						System.out.println("removed POLLQUESTIONS");
					}
					// DELETE ALL POLLSTEPS...
					PollStep pollStep = new PollStep();
					pollStep.removeConditional("POLLID=" + pollId, transaction);
					System.out.println("remove PollStep");
				}
				// DELETE POLL
				tmpPoll.remove(transaction);
				result = 1;
				System.out.println("poll removed successfully: " + result);
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_INFORMATION, tmpPoll.getTitle() + " " + bundle.getString("deleted.successfully.f")));
			} else {
				result = -1;
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("poll.with.id.not.found") + " " + pollId + "!"));
			}
			transaction.commit();
		} catch (Exception e) {
			System.out.println("exception " + e);
			try {
				result = -1;
				
				if (transaction != null)
					transaction.rollback();
			} catch (SQLException e1) {
				System.out.println("PollManagement : removePoll : " + e1.getMessage());
			}
		}
		return result;
	}

}
