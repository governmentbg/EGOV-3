package com.ibm.poll.management;

import java.sql.SQLException;
import java.util.ResourceBundle;

import com.ibm.poll.bean.Message;
import com.ibm.poll.db.DBTransaction;
import com.ibm.poll.db.FinderException;
import com.ibm.poll.db.QueryExecution;
import com.ibm.poll.dbo.PollQuestion;
import com.ibm.poll.dbo.PollQuestionLabel;
import com.ibm.poll.dbo.PollQuestionOption;
import com.ibm.poll.dbo.PollStep;
import com.ibm.pollmanager.PollConstants;
import com.ibm.pollmanager.PollManagerPortletSessionBean;

public class QuestionManagement {

	private PollQuestion[] questions = null;
	private int questionCounter = 0;
	private PollQuestion currentQuestion = null;

	public PollQuestion[] getQuestions() {
		return questions;
	}

	public void setQuestions(PollQuestion[] questions) {
		this.questions = questions;
	}

	public int getQuestionCounter() {
		return questionCounter;
	}

	public void setQuestionCounter(int questionCounter) {
		this.questionCounter = questionCounter;
	}

	public PollQuestion getCurrentQuestion() {
		return currentQuestion;
	}

	public void setCurrentQuestion(PollQuestion currentQuestion) {
		this.currentQuestion = currentQuestion;
	}

	public boolean selectNextQuestion() {
		if (questions != null) {
			if (questionCounter < questions.length) {
				setCurrentQuestion(questions[questionCounter++]);
				return true;
			}
		}
		return false;
	}

	public int loadQuestionById(String id, DBTransaction transaction) {
		try {
			PollQuestion tmpQuestion = PollQuestion.findById(id, transaction);
			if (tmpQuestion != null) {
				setCurrentQuestion(tmpQuestion);
				return 1;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			System.out.println("QuestionManagement : loadQuestionById : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

	public int loadQuestionWithOptionsById(String pollQuestionId, DBTransaction transaction) {
		try {
			PollQuestion pollQuestion = PollQuestion.findById(pollQuestionId, transaction);
			if (pollQuestion != null) {
				PollQuestionOption[] pollQuestionOptions = null;
				try {
					pollQuestionOptions = PollQuestionOption.findAllOptionsByQuestionId(pollQuestionId, transaction);
				} catch (FinderException e) {
				}
				pollQuestion.setPollQuestionOptions(pollQuestionOptions);
				if (PollConstants.QUESTION_TYPE_MATRIX_ONE.equals(pollQuestion.getType()) || PollConstants.QUESTION_TYPE_MATRIX_MULTIPLE.equals(pollQuestion.getType())) {
					PollQuestionLabel[] pollQuestionLabels = null;
					try {
						pollQuestionLabels = PollQuestionLabel.findAllLabelsByQuestionId(pollQuestionId, transaction);
					} catch (FinderException e) {
					}
					pollQuestion.setPollQuestionLabels(pollQuestionLabels);
				}
				setCurrentQuestion(pollQuestion);
				return 1;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			System.out.println("QuestionManagement : loadQuestionWithOptionsById : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

	public int loadAllQuestions() {
		try {
			questionCounter = 0;
			questions = null;
			questions = PollQuestion.findAll(null);
			if (questions != null) {
				questionCounter = 0;
				return questions.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("QuestionManagement : loadAllQuestions : " + e.getMessage());

		}
		return -1;
	}

	public int loadAllPollQuestionsByStepId(String stepId) {
		try {
			questionCounter = 0;
			questions = null;
			questions = PollQuestion.findAllQuestionsByStepId(stepId, null);
			if (questions != null) {
				questionCounter = 0;
				return questions.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("QuestionManagement : loadAllPollQuestionsByStepId : " + e.getMessage());

		}
		return -1;
	}

	public int createQuestion(String pollStepId, String type, String title, String isCompulsory, String commentLabel, String rowChoices, String columnChoices, PollManagerPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		try {
			PollStep pollStep = null;
			transaction = new DBTransaction();
			try {
				pollStep = PollStep.findById(pollStepId, transaction);
			} catch (FinderException e) {
			}
			if (pollStep == null)
				throw new Exception(bundle.getString("step.with.id.not.found") + " " + pollStepId);

			PollQuestion pollQuestion = new PollQuestion();
			pollQuestion.setPollStepId(pollStepId);
			pollQuestion.setType(type);
			pollQuestion.setTitle(title.trim());
			pollQuestion.setIsCompulsory((PollConstants.QUESTION_IS_COMPULSORY.equals(isCompulsory)) ? PollConstants.QUESTION_IS_COMPULSORY : PollConstants.QUESTION_IS_NOT_COMPULSORY);
			pollQuestion.setCommentLabel(commentLabel != null ? commentLabel.trim() : "");
			pollQuestion.setSequence(((QueryExecution.getMaxQuestionSequenceByStepId(pollStepId, transaction) + 1) + "").trim());
			//if (true) throw new Exception("bla...");
			pollQuestion.create(transaction);

			System.out.println("rowChoices = " + rowChoices);
			String[] rowChoicesList = rowChoices.split("\n");
			System.out.println("rowChoicesList.length = " + rowChoicesList.length);
			PollQuestionOption option = null;
			for (int i = 0, j = 0; i < rowChoicesList.length; i++) {
				if (rowChoicesList[i] == null || rowChoicesList[i].trim().length() == 0) continue;
				System.out.println("opt => " + rowChoicesList[i]);
				option = new PollQuestionOption();
				option.setPollQuestionId(pollQuestion.getId());
				option.setLabelText(rowChoicesList[i].trim());
				j++;
				option.create(transaction);
			}

			System.out.println("columnChoices = > " + columnChoices);
			if (columnChoices != null && columnChoices.trim().length() > 0) {
				String[] columnChoicesList = columnChoices.split("\n");
				PollQuestionLabel label = null;
				for (int i = 0; i < columnChoicesList.length; i++) {
					if (columnChoicesList[i] == null || columnChoicesList[i].trim().length() == 0) continue;
					label = new PollQuestionLabel();
					label.setPollQuestionId(pollQuestion.getId());
					label.setLabelText(columnChoicesList[i].trim());
					label.create(transaction);
				}
			}
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println("QuestionManagement : createQuestion : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("QuestionManagement : createQuestion : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
		}
		return -1;
	}

	public int reverseQuestionCompulsory(String pollQuestionId, PollManagerPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		int result = -1;
		try {
			transaction = new DBTransaction();
			PollQuestion pollQuestion = null;
			try {
				pollQuestion = PollQuestion.findById(pollQuestionId, transaction);
			} catch (FinderException e) {
			}
			if (pollQuestion == null) {
				throw new Exception(bundle.getString("question.with.id.not.found") + " " + pollQuestionId + "!");
			}
			pollQuestion.setIsCompulsory(PollConstants.QUESTION_IS_COMPULSORY.equals(pollQuestion.getIsCompulsory()) ? PollConstants.QUESTION_IS_NOT_COMPULSORY : PollConstants.QUESTION_IS_COMPULSORY);
			pollQuestion.store(transaction);
			transaction.commit();
			sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_INFORMATION, pollQuestion.getTitle() + " " + bundle.getString("compulsory.sucessfully") + (PollConstants.QUESTION_IS_COMPULSORY.equals(pollQuestion.getIsCompulsory()) ? bundle.getString("yes") : bundle.getString("no"))));
			result = 1;
		} catch (Exception e) {
			System.out.println("QuestionManagement : reverseQuestionCompulsory : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("QuestionManagement : reverseQuestionCompulsory : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
		}
		return result;
	}

	public int updateQuestion(String pollQuestionId, String type, String title, String isCompulsory, String commentLabel, String rowChoices, String columnChoices, PollManagerPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		int result = -1;
		try {
			PollQuestion pollQuestion = null;
			transaction = new DBTransaction();
			try {
				pollQuestion = PollQuestion.findById(pollQuestionId, transaction);
			} catch (FinderException e) {
			}
			if (pollQuestion == null) {
				throw new Exception(bundle.getString("question.with.id.not.found") + " " + pollQuestionId);
			}
			
			pollQuestion.setType(type);
			pollQuestion.setTitle(title.trim());
			pollQuestion.setIsCompulsory((PollConstants.QUESTION_IS_COMPULSORY.equals(isCompulsory)) ? PollConstants.QUESTION_IS_COMPULSORY : PollConstants.QUESTION_IS_NOT_COMPULSORY);
			pollQuestion.setCommentLabel(commentLabel != null ? commentLabel.trim() : null);
			//pollQuestion.setDescription(rowChoices != null ? rowChoices.trim() : null);
			pollQuestion.store(transaction);
			
			//System.out.println("updateQuestion 2 before delete");
			
			// DELETE ALL POLLQUESTIONOPTIONS... DB2 SQL Error: SQLCODE=-532, SQLSTATE=23504
			//somebody tries to alter question after some polls have been finished
			PollQuestionOption option = new PollQuestionOption();
			option.removeConditional("pollQuestionId=" + pollQuestionId, transaction);
			System.out.println("updateQuestion 3 after delete POLLQUESTIONOPTIONS");
			
			// DELETE ALL POLLQUESTIONLABELS...
			PollQuestionLabel label = new PollQuestionLabel();
			label.removeConditional("pollQuestionId=" + pollQuestionId, transaction);
			//System.out.println("updateQuestion 4 after delete POLLQUESTIONLABELS");			
					
			if (PollConstants.ISDEBUG) { System.out.println("rowChoices = " + rowChoices); }
			String[] rowChoicesList = rowChoices.split("\n");
			if (PollConstants.ISDEBUG) { System.out.println("rowChoicesList.length = " + rowChoicesList.length); }
			option = null;
			for (int i = 0; i < rowChoicesList.length; i++) {
				System.out.println("opt => " + rowChoicesList[i]);
				option = new PollQuestionOption();
				option.setPollQuestionId(pollQuestion.getId());
				option.setLabelText(rowChoicesList[i].trim());
				option.create(transaction);
			}

			System.out.println("columnChoices = > " + columnChoices);
			if (columnChoices != null && columnChoices.trim().length() > 0) {
				String[] columnChoicesList = columnChoices.split("\n");
				label = null;
				for (int i = 0; i < columnChoicesList.length; i++) {
					label = new PollQuestionLabel();
					label.setPollQuestionId(pollQuestion.getId());
					label.setLabelText(columnChoicesList[i].trim());
					label.create(transaction);					
				}
			}
			transaction.commit();
			return 1;
		} catch (Exception e) {			
			System.out.println("QuestionManagement : updateQuestion : " + e.getMessage());
			if (e.getMessage().indexOf("SQLCODE=-532") != -1) {
				result = 0;
			}
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("QuestionManagement : updateQuestion : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
		}
		return result;
	}


	public int removeQuestion(String pollQuestionId, PollManagerPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		int result = 0;
		try {
			transaction = new DBTransaction();
			PollQuestion pollQuestion = PollQuestion.findById(pollQuestionId, transaction);
			if (pollQuestion != null) {
				// DELETE ALL POLLQUESTIONSLABEL FOR CURRENT POLLQUESTION...
				PollQuestionLabel pollQuestionLabel = new PollQuestionLabel();
				pollQuestionLabel.removeConditional("POLLQUESTIONID=" + pollQuestion.getId(), transaction);
				// DELETE ALL POLLQUESTIONOPTION FOR CURRENT POLLQUESTION...
				PollQuestionOption pollQuestionOption = new PollQuestionOption();
				pollQuestionOption.removeConditional("POLLQUESTIONID=" + pollQuestion.getId(), transaction);
				// DELETE POLLQUESTION...
				pollQuestion.remove(transaction);
				result = 1;
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_INFORMATION, "\"" + pollQuestion.getTitle() + "\" " + bundle.getString("deleted.successfully")));
			} else {
				result = -1;
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("question.with.id.not.found") + " " + pollQuestionId + "!"));
			}
			transaction.commit();
		} catch (Exception e) {
			try {
				result = -1;
				if (transaction != null)
					transaction.rollback();
			} catch (SQLException e1) {
				System.out.println("QuestionManagement : removeQuestion : " + e1.getMessage());
			}
		}
		return result;
	}

	public int moveQuestionUp(String questionId, String stepId, PollManagerPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		try {
			transaction = new DBTransaction();
			PollQuestion question = PollQuestion.findById(questionId, transaction);
			if (question != null) {
				int currentSequence = Integer.parseInt(question.getSequence());
				int newSequence = currentSequence - 1;
				PollQuestion question2 = PollQuestion.findBySequenceAndStepId(String.valueOf(newSequence), stepId, transaction);
				if (question2 != null) {
					question.setSequence(String.valueOf(newSequence));
					question.store(transaction);
					question2.setSequence(String.valueOf(currentSequence));
					question2.store(transaction);
				}
			}
			transaction.commit();
			if (question != null) {
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_INFORMATION, question.getTitle() + " " + bundle.getString("moved.successfully")));
			}
			return 1;
		} catch (Exception e) {
			System.out.println("StepManagement : createStep : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("StepManagement : createStep : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
		}
		sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
		return -1;
	}

	public int moveQuestionDown(String questionId, String stepId, PollManagerPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		try {
			transaction = new DBTransaction();
			PollQuestion question = PollQuestion.findById(questionId, transaction);
			if (question != null) {
				int currentSequence = Integer.parseInt(question.getSequence());
				int newSequence = currentSequence + 1;
				PollQuestion question2 = PollQuestion.findBySequenceAndStepId(String.valueOf(newSequence), stepId, transaction);
				if (question2 != null) {
					question.setSequence(String.valueOf(newSequence));
					question.store(transaction);
					question2.setSequence(String.valueOf(currentSequence));
					question2.store(transaction);
				}
			}
			transaction.commit();
			if (question != null) {
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_INFORMATION, question.getTitle() + " " + bundle.getString("moved.successfully")));
			}
			return 1;
		} catch (Exception e) {
			System.out.println("QuestionManagement : createQuestion : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("QuestionManagement : createQuestion : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
		}
		sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
		return -1;
	}

}
