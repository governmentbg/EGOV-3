package com.ibm.poll.management;

import java.sql.SQLException;
import java.util.ResourceBundle;

import com.ibm.poll.bean.Message;
import com.ibm.poll.db.DBTransaction;
import com.ibm.poll.db.FinderException;
import com.ibm.poll.db.QueryExecution;
import com.ibm.poll.dbo.Poll;
import com.ibm.poll.dbo.PollQuestion;
import com.ibm.poll.dbo.PollQuestionLabel;
import com.ibm.poll.dbo.PollQuestionOption;
import com.ibm.poll.dbo.PollStep;
import com.ibm.pollmanager.PollConstants;
import com.ibm.pollmanager.PollManagerPortletSessionBean;

public class StepManagement {
	
	private PollStep[] steps = null;
	private int stepCounter = 0;
	private PollStep currentStep = null;
	
	public PollStep[] getSteps() {
		return steps;
	}
	public void setSteps(PollStep[] steps) {
		this.steps = steps;
	}
	public int getStepCounter() {
		return stepCounter;
	}
	public void setStepCounter(int stepCounter) {
		this.stepCounter = stepCounter;
	}
	public PollStep getCurrentStep() {
		if (currentStep == null) currentStep = new PollStep();
		return currentStep;
	}
	public void setCurrentStep(PollStep currentStep) {
		this.currentStep = currentStep;
	}
	
	public boolean selectNextStep() {
		if (steps != null) {
			if (stepCounter < steps.length) {
				setCurrentStep(steps[stepCounter++]);
				return true;
			}
		}
		return false;
	}
	
	public int loadStepById(String id, DBTransaction transaction) {
		try {
			PollStep tmpStep = PollStep.findById(id, transaction);
			if (tmpStep != null) {
				setCurrentStep(tmpStep);
				return 1;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			System.out.println("StepManagement : loadStepById : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}
	
	public int loadAllSteps() {
		try {
			stepCounter = 0;
			steps = null;
			steps = PollStep.findAll(null);
			if (steps != null) {
				stepCounter = 0;
				return steps.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("StepManagement : loadAllSteps : " + e.getMessage());
			
		}
		return -1;
	}
		
	public int loadAllPollStepsByPollId(String pollid) {
		try {
			stepCounter = 0;
			steps = null;
			steps = PollStep.findAllStepsByPollId(pollid, null); 
			if (steps != null) {
				stepCounter = 0;
				return steps.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("StepManagement : loadAllPollStepsByPollId : " + e.getMessage());
			
		}
		return -1;
	}
	
	public int moveStepUp(String pollStepId, String pollId, PollManagerPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		int result = -1;
		try {			
			System.out.println("pollStepId = " + pollStepId);
			System.out.println("pollId = " + pollId);
			transaction = new DBTransaction();
			PollStep pollStep = null;
			try {
				pollStep = PollStep.findById(pollStepId, transaction);
			} catch (FinderException e) {
			}
			if (pollStep != null) {
				int currentSequence = Integer.parseInt(pollStep.getSequence());
				int newSequence = currentSequence - 1;
				PollStep pollStep2 = PollStep.findBySequenceAndPollId(String.valueOf(newSequence), pollId, transaction);
				if (pollStep2 != null) {
					pollStep.setSequence(String.valueOf(newSequence));
					pollStep.store(transaction);
					pollStep2.setSequence(String.valueOf(currentSequence));
					pollStep2.store(transaction);					
				}
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_INFORMATION, pollStep.getTitle() + " " + bundle.getString("moved.successfully.f")));
				result = 1; 
			} else {
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("step.with.id.not.found") + " " + pollStepId + "!"));
			}
			transaction.commit();			
		} catch (Exception e) {
			System.out.println("StepManagement : moveStepUp : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("StepManagement : moveStepUp : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			result = -1;
		}
		return result;
	}
	
	public int moveStepDown(String pollStepId, String pollId, PollManagerPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		try {			
			transaction = new DBTransaction();
			PollStep pollStep = PollStep.findById(pollStepId, transaction);
			if (pollStep != null) {
				int currentSequence = Integer.parseInt(pollStep.getSequence());
				int newSequence = currentSequence + 1;
				PollStep pollStep2 = PollStep.findBySequenceAndPollId(String.valueOf(newSequence), pollId, transaction);
				if (pollStep2 != null) {
					pollStep.setSequence(String.valueOf(newSequence));
					pollStep.store(transaction);
					pollStep2.setSequence(String.valueOf(currentSequence));
					pollStep2.store(transaction);					
				}
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_INFORMATION, pollStep.getTitle() + " " + bundle.getString("moved.successfully.f")));
			}
			transaction.commit();			
			return 1;
		} catch (Exception e) {
			System.out.println("StepManagement : moveStepDown : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("StepManagement : moveStepDown : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
		}
		return -1;
	}
	
	public int createStep(String pollId, String title, String description, String showTitle, PollManagerPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		try {			
			transaction = new DBTransaction();
			Poll poll = new Poll();
			try {
				poll = Poll.findById(pollId, transaction);
			} catch (FinderException e) {
			}
			if (poll == null) {
				throw new Exception(bundle.getString("poll.with.id.not.found") + " " + pollId + "!");
			}
			PollStep pollStep = new PollStep();
			pollStep.setPollId(pollId);
			pollStep.setTitle(title.trim());
			pollStep.setDescription((description != null) ? description.trim() : null);
			pollStep.setSequence(((QueryExecution.getMaxSequenceByPollId(pollStep.getPollId(), transaction) + 1) + "").trim());
			pollStep.setShowTitle((PollConstants.STEP_SHOW_TITLE.equals(showTitle)) ? PollConstants.STEP_SHOW_TITLE : PollConstants.STEP_HIDE_TITLE);
			pollStep.create(transaction);
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println("StepManagement : createStep : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("StepManagement : createStep : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
		}
		return -1;
	}
	
	public int updateStep(String pollStepId, String title, String description, String showTitle, PollManagerPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		int result = -1;
		try {			
			transaction = new DBTransaction();
			PollStep pollStep = null;
			try {
				pollStep = PollStep.findById(pollStepId, transaction);
			} catch (FinderException e1) {
			}
			if (pollStep != null) {	
				pollStep.setTitle(title.trim());
				pollStep.setDescription((description != null) ? description.trim() : null);
				pollStep.setShowTitle((PollConstants.STEP_SHOW_TITLE.equals(showTitle)) ? PollConstants.STEP_SHOW_TITLE : PollConstants.STEP_HIDE_TITLE);
				pollStep.store(transaction);				
			} else {
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("step.with.id.not.found") + " " + pollStepId + "!"));
			}
			transaction.commit();			
			result = 1;
		} catch (Exception e) {
			System.out.println("StepManagement : updateStep : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("StepManagement : updateStep : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
		}
		return result;
	}
	
	public int removeStep(String pollStepId, PollManagerPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		int result = 0;
		try {
			transaction = new DBTransaction();
			PollQuestion[] pollQuestions = null;
			PollStep pollStep = null;
			try {
				pollStep = PollStep.findById(pollStepId, transaction);
			} catch (FinderException e1) {
			}
			if (pollStep != null) {								
				try {
					pollQuestions = PollQuestion.findAllQuestionsByStepId(pollStepId, transaction);
				} catch (FinderException e) {					
				}
				if (pollQuestions != null && pollQuestions.length > 0) {
					StringBuffer pollQuestionIds = new StringBuffer();
					for (int i = 0; i < pollQuestions.length; i++) {
						if (pollQuestionIds.length() > 0) {
							pollQuestionIds.append(",");
						}
						pollQuestionIds.append(pollQuestions[i].getId());
					}
					// DELETE ALL POLLQUESTIONSLABEL FOR CURRENT FOUNDED POLLQUESTIONIDS...
					PollQuestionLabel pollQuestionLabel = new PollQuestionLabel();
					pollQuestionLabel.removeConditional("POLLQUESTIONID IN (" + pollQuestionIds.toString() + ")", transaction);
					// DELETE ALL POLLQUESTIONOPTION FOR CURRENT FOUNDED POLLQUESTIONIDS...
					PollQuestionOption pollQuestionOption = new PollQuestionOption();
					pollQuestionOption.removeConditional("POLLQUESTIONID IN (" + pollQuestionIds.toString() + ")", transaction);
					// DELETE ALL POLLQUESTIONS FOR CURRENT POLLSTEP
					PollQuestion pollQuestion = new PollQuestion();
					pollQuestion.removeConditional("POLLSTEPID=" + pollStep.getId(), transaction);
				}
				// DELETE POLLSTEP
				pollStep.remove(transaction);
				// DECREASE OTHER POLLSTEP SEQUENCE WITH 1...
				QueryExecution.decrementPollStepSequence(pollStep.getPollId(), pollStep.getSequence(), transaction);
				result = 1;
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_INFORMATION, pollStep.getTitle() + " " + bundle.getString("deleted.successfully.f")));
			} else {
				result = -1;
				sessionBean.setMessage(new Message(PollConstants.MESSAGE_TYPE_ERROR, bundle.getString("step.with.id.not.found") + " " + pollStepId + "!"));
			}
			transaction.commit();
		} catch (Exception e) {
			try {
				result = -1;
				//logger.debug( e.getMessage(), e);
				if (transaction != null)
					transaction.rollback();
			} catch (SQLException e1) {
				System.out.println("StepManagement : removeStep : " + e1.getMessage());
			}
		}
		return result;
	}
	
}
