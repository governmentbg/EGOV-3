package com.ibm.poll.dbo;

import java.util.Hashtable;

import com.ibm.poll.db.DBTransaction;
import com.ibm.poll.db.FinderException;
import com.ibm.poll.db.PersistentObject;
import com.ibm.poll.db.QueryComposer;
import com.ibm.poll.db.QuerySet;
import com.ibm.pollmanager.PollConstants;

public class PollQuestionOption extends PersistentObject {

	private static String CLASS_NAME = PollQuestionOption.class.getName();
	protected static String schema = PollConstants._SCHEMANAME;
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "POLLQUESTIONOPTION";
        sequenceName = "SEQ_POLLQUESTIONOPTIONID";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "POLLQUESTIONOPTIONID");
        columnMap.put("pollQuestionId", "POLLQUESTIONID");
        columnMap.put("labelText", "LABELTEXT");
        querySet = QueryComposer.composeAll(schema, table, sequenceName, columnMap);
    }
	
    public PollQuestionOption() {
        super(querySet);
    }
    
    private String pollQuestionId = null;
	private String labelText = null;

	public String getPollQuestionId() {
		return pollQuestionId;
	}

	public void setPollQuestionId(String pollQuestionId) {
		this.pollQuestionId = pollQuestionId;
	}

	public String getLabelText() {
		return labelText;
	}

	public void setLabelText(String labelText) {
		this.labelText = labelText;
	}

	public static PollQuestionOption findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
        return (PollQuestionOption) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
    }
	
	public static PollQuestionOption[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllOptions("1=1", transaction);
	}

	public static PollQuestionOption[] findAllOptionsByQuestionId(String questionId, final DBTransaction transaction) throws FinderException, Exception {
		String cond = columnMap.get("pollQuestionId") + " = " + questionId + " ORDER BY " + columnMap.get("id");
		return findAllOptions(cond, transaction);
	}

	public static PollQuestionOption[] findAllOptionsByQuestionIds(String questionIds, final DBTransaction transaction) throws FinderException, Exception {
		String cond = columnMap.get("pollQuestionId") + " IN (" + questionIds + ") ORDER BY " + columnMap.get("id");
		return findAllOptions(cond, transaction);
	}

	public static PollQuestionOption[] findAllOptions(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final PollQuestionOption[] pollQuestionOptions = new PollQuestionOption[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				pollQuestionOptions[i] = (PollQuestionOption) tmp[i];
			}
			return pollQuestionOptions;
		}
		return null;
	}

}
