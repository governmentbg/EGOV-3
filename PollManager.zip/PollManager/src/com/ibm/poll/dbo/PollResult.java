package com.ibm.poll.dbo;

import java.sql.Timestamp;
import java.util.Hashtable;

import com.ibm.poll.db.DBTransaction;
import com.ibm.poll.db.FinderException;
import com.ibm.poll.db.PersistentObject;
import com.ibm.poll.db.QueryComposer;
import com.ibm.poll.db.QuerySet;
import com.ibm.poll.utils.PollUtils;
import com.ibm.pollmanager.PollConstants;

public class PollResult extends PersistentObject {

	private static String CLASS_NAME = PollResult.class.getName();
	protected static String schema = PollConstants._SCHEMANAME;
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "POLLRESULT";
        sequenceName = "SEQ_POLLRESULTID";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "POLLRESULTID");
        columnMap.put("pollId", "POLLID");
        columnMap.put("userDN", "USERDN");        
        columnMap.put("creationDate", "CREATIONDATE");
        querySet = QueryComposer.composeAll(schema, table, sequenceName, columnMap);
    }
	
    public PollResult() {
        super(querySet);
    }
    
    private String pollId = null;
    private String userDN = null;
	private String creationDate = null;
	
	public String getPollId() {
		return pollId;
	}

	public void setPollId(String pollId) {
		this.pollId = pollId;
	}
	
	public String getUserDN() {
		return userDN;
	}
	
	public void setUserDN(String userDN) {
		this.userDN = userDN;
	}
	
	public Timestamp getCreationDate() {
		return (creationDate != null) ? new Timestamp(Long.parseLong(creationDate)) : null;
	}
	
	public void setCreationDate(String creationDate) {
		this.creationDate = (creationDate != null) ? String.valueOf(PollUtils.date_TimestampToTimeMillis(creationDate)) : null;
	}
	
	public static PollResult findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
        return (PollResult) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
    }

	public static PollResult[] findAllByPollId(final String pollId, final DBTransaction transaction) throws FinderException, Exception {
		return findAllPollResults(columnMap.get("pollId") + "=" + pollId + " order by " + columnMap.get("creationDate") + " ASC", transaction);
	}
	
	public static PollResult[] findAllByPollIdAndPeriod(final String pollId, final String startDate, final String endDate, final DBTransaction transaction) throws FinderException, Exception {
		String query = columnMap.get("pollId") + "=" + pollId;
		if (startDate != null && startDate.trim().length() > 0) {
			query += " AND " + columnMap.get("creationDate") + " >= '" + startDate + "'";
		}
		if (endDate != null && endDate.trim().length() > 0) {
			query += " AND " + columnMap.get("creationDate") + " < '" + endDate + "'";
		}
		query += " order by " + columnMap.get("creationDate");
		return findAllPollResults(query, transaction);
	}
	
	public static PollResult[] findAllPollResults(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final PollResult[] pollResults = new PollResult[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				pollResults[i] = (PollResult) tmp[i];
			}
			return pollResults;
		}
		return null;
	}
	
	public static PollResult[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple("1=1", CLASS_NAME, transaction);
		if (tmp != null) {
			final PollResult[] pollResults = new PollResult[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				pollResults[i] = (PollResult) tmp[i];
			}
			return pollResults;
		} 
		return null;
	}
	
}
