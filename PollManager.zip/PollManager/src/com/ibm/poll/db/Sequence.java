package com.ibm.poll.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.ibm.pollmanager.PollConstants;

public class Sequence {

	public synchronized static String getNextVal(String sequenceName, Connection connection) throws SQLException {
		String sequenceValue;
		sequenceValue = "-1";
		Statement st = connection.createStatement();
		String query = "";
		if (PollConstants._DB_DB2.equalsIgnoreCase(DBResources._DB)) {
			query = "select next value for " + PollConstants._SCHEMANAME + sequenceName + " from SYSIBM.SYSDUMMY1";			
		} else {
			query = "select " + PollConstants._SCHEMANAME + sequenceName + ".nextval from dual";
		}
		ResultSet rs = st.executeQuery(query);
		if (rs != null) {
			if (rs.next()) {
				sequenceValue = rs.getString(1);
			}
		} // rs
		rs.close();
		st.close();
		return sequenceValue;
	} // getNextVal
} 