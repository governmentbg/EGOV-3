package com.ibm.poll.db;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

import com.ibm.pollmanager.PollConstants;

public abstract class PersistentObject {

	protected QuerySet querySet;
	private String id;

	public PersistentObject(QuerySet qs) {
		this.querySet = qs;
	}

	public final String getId() {
		return id;
	}

	public final void setId(String id) {
		this.id = id;
	}

	private static Connection getConnection() throws SQLException {

//		Connection con = DBconnection.getConnection();
		Connection con = DBPool.getConnection();
		if (con == null) {
			throw new SQLException("Connection is NULL");
		}
		return con;

	}

	private static void releaseConnection(Connection con) {
		try {
			con.close();
		} catch (Exception e) {
			System.out.println("PersistentObject : releaseConnection : " + e.getMessage());
		}
	}

	protected final long doCreate(DBTransaction transaction) throws Exception {

		Connection con = null;
		String lastInsId = "-1";

		try {
			if (transaction != null) {
				con = transaction.getConnection();
			} else {
				con = PersistentObject.getConnection();
			}

			if (con != null && querySet != null) {
				System.out.println("Query text: " + querySet.createQuery);
				// logger.debug("Query text: " + querySet.createQuery);
				PreparedStatement pst = con.prepareStatement(querySet.createQuery);
				System.out.println("Parameter number: " + querySet.keyArray.length);
				// logger.debug("Parameter number: " + querySet.keyArray.length);

				int j = 0;
				Class[] argArray = null;
				Class retType = null;
				Method method = null;
				String currentElement = null;
				String t_value = null;
				byte[] bytes = null;

				for (int i = 0; i < querySet.keyArray.length; i++) {
					currentElement = querySet.keyArray[i];
					if (currentElement.equals("id")) {
						lastInsId = Sequence.getNextVal(querySet.sequenceName, con);
						setId(lastInsId);
					}
					currentElement = "get" + (currentElement.substring(0, 1)).toUpperCase() + currentElement.substring(1);
					argArray = null;
					method = this.getClass().getMethod(currentElement, argArray);
					retType = method.getReturnType();
					if (retType.getName().equals(String.class.getName())) {
						t_value = (String) method.invoke(this, null);
						if ("".equals(t_value) && t_value.trim().length() == 0) {
							t_value = " ";
						}
						pst.setString(j + 1, t_value);
						System.out.println("Parameter[" + (j + 1) + ": " + currentElement + "] '" + t_value + "'");
						// logger.debug("Parameter[" + (j + 1) + ": " + currentElement + "] '" + t_value + "'");
					} else if (retType.getName().equals(Timestamp.class.getName())) {
						Timestamp timestamp_value = (Timestamp) method.invoke(this, null);
						pst.setTimestamp(j + 1, timestamp_value);
					} else if (retType.getName().equals(Double.class.getName())) {
						Double double_value = (Double) method.invoke(this, null);
						pst.setDouble(j + 1, double_value);
					} else if (retType.getName().equals(long.class.getName())) {
						Long long_value = (Long) method.invoke(this, null);
						pst.setLong(j + 1, long_value.longValue());
						//Logger.log(Logger.DEBUG_LEVEL, "Parameter[" + (j + 1) + ": " + currentElement + "] '" + long_value + "'");
					} else if (retType.getName().equals(int.class.getName())) {
						Integer int_value = (Integer) method.invoke(this, null);
						pst.setInt(j + 1, int_value.intValue());
						//Logger.log(Logger.DEBUG_LEVEL, "Parameter[" + (j + 1) + ": " + currentElement + "] '" + int_value + "'");
					} else if (retType.getName().equals(byte[].class.getName())) {
						bytes = (byte[]) method.invoke(this, null);
						pst.setBytes(j + 1, bytes);
						// logger.debug("Parameter[" + (j + 1) + ": " + currentElement + "] '" + bytes + "'");
					}
					j++;
				}

				int result;

				synchronized (this) {
					result = pst.executeUpdate();
					// lastInsId = ((com.mysql.jdbc.Statement) stm).getLastInsertID(); // good for MySQL RDBMS
				}

				System.out.println("Last Inserted ID: " + lastInsId);

				pst.close();

				if (result != 1)
					throw new Exception("Unable to execute statement.");

				// return lastInsId. Should be greater than zero if ok ;)
				return (long) Integer.parseInt(lastInsId);
				// because DB2 JDBC does not provide any way to get the sequence value before its use
			} else
				throw new Exception("Connection or query set is not initialized.");
		} catch (SQLException e) {
			throw new Exception(e.getMessage());
		} finally {
			if (transaction == null) {
				releaseConnection(con);
			}
		}
	}

	/**
	 * @param conds
	 * @throws java.lang.Exception
	 */
	protected final int doRemove(String conds, DBTransaction transaction) throws Exception {
		return doRemove(conds, null, null, transaction);
	}

	protected final int doRemove(String conds, Object[] persistantParameters, DBTransaction transaction) throws Exception {
		return doRemove(conds, null, persistantParameters, transaction);
	}

	protected final int doRemove(String conds, Object[] queryParameters, Object[] persistantParameters, DBTransaction transaction) throws Exception {
		Connection con = null;
		int result = 0;

		try {
			if (transaction != null) {
				con = transaction.getConnection();
			} else {
				con = PersistentObject.getConnection();
			}

			if (con != null && querySet != null) {
				Statement stm = con.createStatement();
				if (PollConstants.ISDEBUG) { System.out.println("querySet.removeQuery + conds: " + querySet.removeQuery + conds);}
				result = executeUpdate(querySet, querySet.removeQuery + conds, queryParameters, persistantParameters, con);
				stm.close();

				if (result < 0)
					throw new Exception("Unable to remove record.");
			} else
				throw new Exception("Connection or query set is not initialized.");
		} catch (SQLException e) {
			throw new Exception(e.getMessage());
		} finally {
			if (transaction == null) {
				releaseConnection(con);
			}
		}
		return result;
	} // doRemove

	/**
	 * @param conds
	 * @throws java.lang.Exception
	 */
	protected final void doLoad(String conds, DBTransaction transaction) throws Exception {
		doLoad(conds, null, null, transaction);
	}

	protected final void doLoad(String conds, Object[] persistantParameters, DBTransaction transaction) throws Exception {
		doLoad(conds, null, persistantParameters, transaction);
	}

	protected final void doLoad(String conds, Object[] queryParameters, Object[] persistantParameters, DBTransaction transaction) throws Exception {
		Connection con = null;

		try {
			if (transaction != null) {
				con = transaction.getConnection();
			} else {
				con = PersistentObject.getConnection();
			}

			if (con != null && querySet != null) {
				// logger.debug("Query text: " + querySet.loadQuery);
				PreparedStatement stm = prepareQuery(querySet, querySet.loadQuery + conds, queryParameters, persistantParameters, con);
				ResultSet rs = stm.executeQuery();
				if (rs != null && rs.next()) {
					String currentElement = null;
					Method method = null;
					Class[] parTypes = null;
					for (int i = 0; i < querySet.columnMap.size(); i++) {
						currentElement = querySet.keyArray[i];
						currentElement = "set" + (currentElement.substring(0, 1)).toUpperCase() + currentElement.substring(1);
						Class[] argArray = { String.class };
						method = this.getClass().getMethod(currentElement, argArray);

						parTypes = method.getParameterTypes();
						if (parTypes[0].getName().equals(String.class.getName())) {
							Object[] obj = { rs.getString(i + 1) };
							method.invoke(this, obj);
							// System.out.println("***** Load::Name(): " + parTypes[0].getDescription());
						} else if (parTypes[0].getName().equals(byte[].class.getName())) {
							Object[] obj = { getBytes(rs, i + 1) };
							method.invoke(this, obj);
							// System.out.println("----- Load::Name(): " + parTypes[0].getDescription());
						}
					}
					rs.close();
					stm.close();
				} else
					throw new Exception("Unable to load record.");
			} else
				throw new Exception("Connection or query set is not initialized.");
		} catch (SQLException e) {
			throw new Exception(e.getMessage());
		} finally {
			if (transaction == null) {
				releaseConnection(con);
			}
		}
	}

	/**
	 * @param conds
	 * @throws java.lang.Exception
	 */
	protected final void doStore(String conds, DBTransaction transaction) throws Exception {
		doStore(conds, null, transaction);
	}

	protected final void doStore(String conds, Object[] parameters, DBTransaction transaction) throws Exception {
		Connection con = null;

		try {
			if (transaction != null) {
				con = transaction.getConnection();
			} else {
				con = PersistentObject.getConnection();
			}

			if (con != null && querySet != null) {

				System.out.println("doStore Query text: " + querySet.storeQuery + conds);
				PreparedStatement stm = con.prepareStatement(formatQuery(querySet, querySet.storeQuery + conds));

				// set parameter values in query
				// logger.debug("Parameter number: " + querySet.keyArray.length);
				String currentElement = null;
				Method method = null;
				Class retType = null;
				String t_value = null;
				byte[] bytes = null;

				for (int i = 0; i < querySet.columnMap.size(); i++) {
					currentElement = querySet.keyArray[i];
					currentElement = "get" + (currentElement.substring(0, 1)).toUpperCase() + currentElement.substring(1);
					method = this.getClass().getMethod(currentElement, null);
					retType = method.getReturnType();					
					if (retType.getName().equals(String.class.getName())) {
						t_value = (String) method.invoke(this, null);
						if ("".equals(t_value) && t_value.trim().length() == 0) {
							t_value = " ";
						}
						if ("null".equalsIgnoreCase(t_value)) {
							t_value = null;
						}
						stm.setString(i + 1, t_value);
						// logger.debug("Parameter[" + (i + 1) + ": " + currentElement + "] '" + t_value + "'");
					} else if (retType.getName().equals(Timestamp.class.getName())) {
						Timestamp timestamp_value = (Timestamp) method.invoke(this, null);
						stm.setTimestamp(i + 1, timestamp_value);		
					} else if (retType.getName().equals(Double.class.getName())) {
						Double double_value = (Double) method.invoke(this, null);
						stm.setDouble(i + 1, double_value);
					} else if (retType.getName().equals(long.class.getName())) {
						Long long_value = (Long) method.invoke(this, null);
						stm.setLong(i + 1, long_value.longValue());
						//Logger.log(Logger.DEBUG_LEVEL, "Parameter[" + (j + 1) + ": " + currentElement + "] '" + long_value + "'");
					} else if (retType.getName().equals(int.class.getName())) {
						Integer int_value = (Integer) method.invoke(this, null);
						stm.setInt(i + 1, int_value.intValue());
						//Logger.log(Logger.DEBUG_LEVEL, "Parameter[" + (j + 1) + ": " + currentElement + "] '" + int_value + "'");
					} else if (retType.getName().equals(byte[].class.getName())) {
						bytes = (byte[]) method.invoke(this, null);
						stm.setBytes(i + 1, bytes);
						// logger.debug("Parameter[" + (i + 1) + ": " + currentElement + "] '" + bytes + "'");
					}
				}

				// execute query
				int result = stm.executeUpdate();
				// if unable to update
				stm.close();

				if (result != 1)
					throw new Exception("Unable to store record.");
			} else
				throw new Exception("Connection or query set is not initialized.");
		} catch (SQLException e) {
			throw new Exception(e.getMessage());
		} finally {
			if (transaction == null) {
				releaseConnection(con);
			}
		}
	}

	protected static Object findSingle(String conds, String className) throws FinderException, Exception {
		return findSingle(conds, null, null, className, null);
	}

	protected static Object findSingle(String conds, String className, DBTransaction transaction) throws FinderException, Exception {
		return findSingle(conds, null, null, className, transaction);
	}

	protected static Object findSingle(String conds, Object[] persistantParameters, String className, DBTransaction transaction) throws FinderException, Exception {
		return findSingle(conds, null, persistantParameters, className, transaction);
	}

	protected static Object findSingle(String conds, Object[] queryParameters, Object[] persistantParameters, String className, DBTransaction transaction) throws FinderException, Exception {
		Object anc = Class.forName(className).getConstructor(null).newInstance(null);
		Field f = anc.getClass().getField("querySet");
		QuerySet querySet = (QuerySet) f.get(f);

		// Get new database connection
		Connection con = null;

		try {
			if (transaction != null) {
				con = transaction.getConnection();
			} else {
				con = getConnection();
			}
			if (con != null && querySet != null) {

				System.out.println(querySet.findQuery + conds);
				PreparedStatement stm = prepareQuery(querySet, querySet.loadQuery + conds, queryParameters, persistantParameters, con);
				ResultSet rs = stm.executeQuery();
				if (rs != null && rs.next()) {

					Class objectClass = Class.forName(className);
					Object newObject = objectClass.getConstructor(null).newInstance(null);
					String currentElement = null;
					Method method = null;

					for (int i = 0; i < querySet.columnMap.size(); i++) {
						currentElement = querySet.keyArray[i];
						currentElement = "set" + (currentElement.substring(0, 1)).toUpperCase() + currentElement.substring(1);

						method = null;
						try {
							Class[] argArray = { String.class };
							method = objectClass.getMethod(currentElement, argArray);
							if (rs.getMetaData().getColumnType(i + 1) == java.sql.Types.TIMESTAMP) {
								Object[] obj = { rs.getTimestamp(i + 1) + "" };
								method.invoke(newObject, obj);
							} else {
								Object[] obj = { rs.getString(i + 1) };
								method.invoke(newObject, obj);
							}
						} catch (NoSuchMethodException e) {
							Class[] argArray = { byte[].class };
							method = objectClass.getMethod(currentElement, argArray);
							Object[] obj = { getBytes(rs, i + 1) };
							method.invoke(newObject, obj);
						}
					}
					rs.close();
					stm.close();
					return newObject;
				} else
					throw new FinderException("Unable to find object.");
			} else
				throw new Exception("Connection is not initialized.");
		} catch (SQLException e) {
			// System.out.println("e.getMessage() = " + e.getMessage());
			// System.out.println("e.getErrorCode() = " + e.getErrorCode());
			throw new Exception(e.getMessage());
		} finally {
			if (transaction == null) {
				releaseConnection(con);
			}
		}

	}

	protected static Object[] findMultiple(String conds, String className) throws FinderException, Exception {
		return findMultiple(conds, null, null, className, null);
	}

	protected static Object[] findMultiple(String conds, String className, DBTransaction transaction) throws FinderException, Exception {
		return findMultiple(conds, null, null, className, transaction);
	}

	protected static Object[] findMultiple(String conds, Object[] persistantParameters, String className, DBTransaction transaction) throws FinderException, Exception {
		return findMultiple(conds, null, persistantParameters, className, transaction);
	}

	protected static Object[] findMultiple(String conds, Object[] queryParameters, Object[] persistantParameters, String className, DBTransaction transaction) throws FinderException, Exception {
		Object anc = Class.forName(className).getConstructor(null).newInstance(null);
		Field f = anc.getClass().getField("querySet");
		QuerySet querySet = (QuerySet) f.get(f);

		// Get new database connection

		Connection con = null;
		try {
			if (transaction != null) {
				con = transaction.getConnection();
			} else {
				con = getConnection();
			}
			//System.out.println("findMultiple conds: " + conds);
			if (con != null && querySet != null) {
				// create statement object
				//System.out.println("queryParameters: " + queryParameters);
				PreparedStatement stm = con.prepareStatement(formatQuery(querySet, querySet.findQuery + conds, queryParameters),
				// ResultSet.TYPE_SCROLL_SENSITIVE,
						ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
				// PreparedStatement stm =
				// con.prepareStatement(
				// formatQuery(querySet, querySet.findQuery + conds, queryParameters),
				// ResultSet.TYPE_SCROLL_SENSITIVE,
				// ResultSet.CONCUR_READ_ONLY);
				// does not affect DB2 8.1.0 IBM JDBC Driver
				System.out.println( querySet.findQuery + conds);
				// execute query
				if (persistantParameters != null) {
					//System.out.println("persistantParameters: " + persistantParameters);
					setQueryParameters(stm, persistantParameters);
				}
				
				ResultSet rs = stm.executeQuery();

				if (rs != null) {
					//System.out.println("rs not null");
					// get number of rows
					rs.last(); // does not work with IBMDB2 8.1.0 JDBC Driver - db2java.zip
					int number = rs.getRow(); // -||-
					// create array to hold the objects
					Object[] objectArray = new Object[number];
					// Vector objectVector = new Vector(); // -||- implementing vector instead
					int objectCounter = 0; // -||-
					rs.beforeFirst(); // -||-
					// start composing objects from query result
					while (rs.next()) {
						// create objects here .....................
						// get objects' class and create new object - newObject
						Class objectClass = Class.forName(className);
						Object newObject = objectClass.getConstructor(null).newInstance(null);
						// set newObject's properties
						String currentElement = null;
						Method method = null;

						for (int i = 0; i < querySet.keyArray.length; i++) {
							currentElement = querySet.keyArray[i];
							currentElement = "set" + (currentElement.substring(0, 1)).toUpperCase() + currentElement.substring(1);
							System.out.println("in for");
							method = null;
							try {
								Class[] argArray = { String.class };
								method = objectClass.getMethod(currentElement, argArray);
								System.out.println("before times");
								if (java.sql.Types.TIMESTAMP == rs.getMetaData().getColumnType(i + 1)) {
									Object[] obj = { rs.getTimestamp(i + 1) + "" };
									method.invoke(newObject, obj);
								} else {
									Object[] obj = { rs.getString(i + 1) };
									method.invoke(newObject, obj);
								}

							} catch (NoSuchMethodException e) {
								Class[] argArray = { byte[].class };
								method = objectClass.getMethod(currentElement, argArray);
								Object[] obj = { getBytes(rs, i + 1) };
								// BLOB blob = ((OracleResultSet) rs).getBLOB(i + 1);
								method.invoke(newObject, obj);
							}
						}
						// store newObject in object array
						objectArray[objectCounter++] = newObject; // using vector implementation
						// objectVector.addElement(newObject); // DB2 8.1.0 fix
					}
					rs.close();
					stm.close();

					return objectArray;
					// using vector implementation
					// if (objectVector.size() > 0) {
					// return objectVector.toArray();
					// } else {
					// return null;
					// }

				} else
					throw new FinderException("Unable to find object!");
			} else
				throw new Exception("Connection is not initialized!");
		} catch (SQLException e) {
			// logger.error("PersistentObject : findMultiple : " + e.getMessage(), e);
			throw new Exception(e.getMessage());
		} finally {
			if (transaction == null) {
				releaseConnection(con);
			}
		}
	}

	public void store() throws Exception {
		store(null);
	}

	public void create() throws Exception {
		create(null);
	}

	public void load() throws Exception {
		load(null);
	}

	public void remove() throws Exception {
		remove(null);
	}

	public void create(DBTransaction transaction) throws Exception {
		long id = doCreate(transaction);
		setId("" + id);
	}

	public void store(DBTransaction transaction) throws Exception {
		doStore(querySet.columnMap.get("id") + "=" + getId(), transaction);
	}

	public void load(DBTransaction transaction) throws Exception {
		doLoad(querySet.columnMap.get("id") + "=" + getId(), transaction);
	}

	public void remove(DBTransaction transaction) throws Exception {
		doRemove(querySet.columnMap.get("id") + "=" + getId(), transaction);
	}

	public int removeMultiple(String ids, DBTransaction transaction) throws Exception {
		return doRemove(querySet.columnMap.get("id") + " IN (" + ids + ")", transaction);
	}

	public int removeConditional(String cond, DBTransaction transaction) throws Exception {
		return doRemove(cond, transaction);
	}

	public static byte[] getBytes(ResultSet rs, int index) throws SQLException {
		byte[] res = null;
		// try {
		// res = rs.getBytes(index);
		// System.out.println("PersistemtObject: getBytes");
		// } catch (Exception e) {
		try {
			System.out.println("PersistemtObject: getBytes by BinaryStream");
			ByteBuffer bbuffer = new ByteBuffer();
			int bytesread = 0;
			byte[] tmparr = new byte[1024];
			InputStream istream = rs.getBinaryStream(index);
			while (-1 != (bytesread = istream.read(tmparr, 0, 1024)))
				bbuffer.append(tmparr, bytesread);
			res = bbuffer.getBytes();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		// }
		return res;
	}

	public static int toInt(String str) {
		int val = -1;
		try {
			val = Integer.parseInt(str);
		} catch (Exception e) {
		}
		;
		return val;
	}

	public String formatQuery(String query) {
		return formatQuery(query, null);
	}

	public String formatQuery(String query, Object[] params) {
		return formatQuery(querySet, query, params);
	}

	public static String formatQuery(QuerySet querySet, String query) {
		return formatQuery(querySet, query, null);
	}

	public static String formatQuery(QuerySet querySet, String query, Object[] params) {
		int i, length;
		char c;
		if (query == null)
			return null;
		length = query.length();
		StringBuffer result = new StringBuffer();
		for (i = 0; i < length; i++) {
			c = query.charAt(i);
			if (c == '\'') {
				do {
					result.append(c);
					i++;
					if (i < length)
						c = query.charAt(i);
				} while (i < length && (query.charAt(i - 1) == '\\' || query.charAt(i) != '\''));
				if (i < length)
					result.append(c);
			} else if (c == '"') {
				do {
					result.append(c);
					i++;
					if (i < length)
						c = query.charAt(i);
				} while (i < length && (query.charAt(i - 1) == '\\' || query.charAt(i) != '"'));
				if (i < length)
					result.append(c);
			} else if (c == '$') {
				StringBuffer id = new StringBuffer();
				do {
					id.append(c);
					i++;
				} while (i < length && (Character.isUnicodeIdentifierPart(c = query.charAt(i)) || c == '$'));
				if (i < length)
					i--;

				if (id.length() > 1) {
					String id_name = id.substring(1);
					int ix;
					if ("$table".equals(id_name))
						result.append(PollConstants._SCHEMANAME + querySet.table);
					else if (null != querySet.columnMap.get(id_name))
						result.append((String) querySet.columnMap.get(id_name));
					else if ((ix = toInt(id_name)) >= 0 && params != null && ix < params.length)
						result.append(params[ix].toString());
					else
						result.append(id);
				} else
					result.append(id);
			} else
				result.append(c);
		}
		String res = result.toString();
		// logger.debug("formatQuery: " + res);
		return res;
	}

	static void setQueryParameters(PreparedStatement statement, Object[] parameters) throws SQLException {
		if (parameters != null)
			for (int i = 0; i < parameters.length; i++) {
				Object parameter = parameters[i];
				// logger.debug("parameter[" + i + "]: " + parameter);
				if (parameter instanceof Integer)
					statement.setInt(i + 1, ((Integer) parameters[i]).intValue());
				else if (parameter instanceof Long)
					statement.setLong(i + 1, ((Long) parameters[i]).longValue());
				else if (parameter instanceof Double)
					statement.setDouble(i + 1, ((Double) parameters[i]).doubleValue());
				else if (parameter instanceof String)
					statement.setString(i + 1, ((String) parameters[i]));
				else if (parameter instanceof byte[])
					statement.setBytes(i + 1, ((byte[]) parameters[i]));
			}
	}

	public PreparedStatement prepareQuery(String query, Object[] queryParameters, Object[] persistantParameters, Connection con) throws SQLException {
		return prepareQuery(querySet, query, queryParameters, persistantParameters, con);
	}

	static PreparedStatement prepareQuery(QuerySet querySet, String query, Object[] queryParameters, Object[] persistantParameters, Connection con) throws SQLException {
		PreparedStatement st = con.prepareStatement(formatQuery(querySet, query, queryParameters));
		if (persistantParameters != null)
			setQueryParameters(st, persistantParameters);
		return st;
	}

	public int executeUpdate(String query, Object[] queryParameters, Object[] persistantParameters, Connection con) throws SQLException {
		return executeUpdate(querySet, query, queryParameters, persistantParameters, con);
	}

	static int executeUpdate(QuerySet querySet, String query, Object[] queryParameters, Object[] persistantParameters, Connection con) throws SQLException {
		PreparedStatement st = con.prepareStatement(formatQuery(querySet, query, queryParameters));
		if (persistantParameters != null)
			setQueryParameters(st, persistantParameters);
		return st.executeUpdate();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PersistentObject other = (PersistentObject) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

}
