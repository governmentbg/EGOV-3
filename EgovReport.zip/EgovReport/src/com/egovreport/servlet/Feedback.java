package com.egovreport.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.egovreport.EgovReportContants;
import com.egovreport.utils.AppUtils;
import com.egovreport.utils.MailMessage;

@WebServlet("/feedback")
public class Feedback extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String PROBLEM_AREA_ALL = "0";
	private static final String PROBLEM_AREA_PAGE = "1";
	private static final String RESPONSE_NO = "0";
	private static final String RESPONSE_YES = "1";
       
    public Feedback() {
        super();
    }	

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().write("Not Supported!");
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setHeader("Cache-Control", "no-cache");
		response.setContentType("application/json; charset=utf-8");
		String problemArea = request.getParameter("pA");		
		String pageURL = request.getParameter("pUrl");
		String description = request.getParameter("desc");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String site = request.getParameter("site");
		if (description != null && description.trim().length() > 0) {
			try {
				String currentTime = AppUtils.timeMillisToTimestamp(System.currentTimeMillis());
				com.egovreport.db.dbo.Feedback feedback = new com.egovreport.db.dbo.Feedback();
				feedback.setProblemArea((PROBLEM_AREA_PAGE.equals(problemArea)) ? PROBLEM_AREA_PAGE : PROBLEM_AREA_ALL);
				feedback.setPageUrl(pageURL.trim());
				feedback.setDescription(description.trim());
				feedback.setResponse((email != null && email.trim().length() > 0) ? RESPONSE_YES :  RESPONSE_NO);
				feedback.setName((name != null && name.trim().length() > 0) ? name.trim() : null);
				feedback.setEmail((email != null && email.trim().length() > 0) ? email.trim() : null);											
				feedback.setIp(request.getRemoteAddr());
				feedback.setSite(site);
				feedback.setOperationTime(currentTime);
				feedback.setMailSent("0");
				feedback.create();			
				//send mail...
				String subject = "EGOV.BG [Feedback]";
				String message = "<table style=\"border:1px solid #000;\">";				
					   	message += "<tr>";
					   		message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;За коя страница става въпрос?&nbsp;&nbsp;</td>";
					   		message += "<td style=\"height:22px; border-bottom:1px solid #000;\">&nbsp;&nbsp;" + ((PROBLEM_AREA_PAGE.equals(problemArea)) ? pageURL : "Целия сайт") + "&nbsp;&nbsp;</td>";				
					   	message += "</tr>";
					   	message += "<tr style=\"\">";
					   		message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;Повече информация&nbsp;&nbsp;</td>";
					   		message += "<td style=\"height:22px; border-bottom:1px solid #000;\">&nbsp;&nbsp;" + description.trim() + "&nbsp;&nbsp;</td>";				
					   	message += "</tr>";
					   	message += "<tr>";
					   		message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;Име&nbsp;&nbsp;</td>";
					   		message += "<td style=\"height:22px; border-bottom:1px solid #000;\">&nbsp;&nbsp;" + name + "&nbsp;&nbsp;</td>";				
					   	message += "</tr>";
					   	message += "<tr>";
					   		message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;Е-поща&nbsp;&nbsp;</td>";
					   		message += "<td style=\"height:22px; border-bottom:1px solid #000;\">&nbsp;&nbsp;" + email + "&nbsp;&nbsp;</td>";				
					   	message += "</tr>";
					   	message += "<tr>";
					   		message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;IP адрес&nbsp;&nbsp;</td>";
					   		message += "<td style=\"height:22px; border-bottom:1px solid #000;\">&nbsp;&nbsp;" + request.getRemoteAddr() + "&nbsp;&nbsp;</td>";				
					   	message += "</tr>";
					   	message += "<tr>";
					   		message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;Сайт&nbsp;&nbsp;</td>";
					   		message += "<td style=\"height:22px; border-bottom:1px solid #000;\">&nbsp;&nbsp;" + site + "&nbsp;&nbsp;</td>";				
					   	message += "</tr>";
					   	message += "<tr>";
					   		message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;Време на операция&nbsp;&nbsp;</td>";
					   		message += "<td style=\"height:22px; border-bottom:1px solid #000;\">&nbsp;&nbsp;" + currentTime + "&nbsp;&nbsp;</td>";				
					   	message += "</tr>";
				message += "</table>";
				try {
					if (MailMessage.sendSingle(EgovReportContants._MAIL_ADDRESS_FROM, EgovReportContants._MAIL_ADDRESS_TO, null, subject, message, false)) {
						feedback.setMailSent("1");
						feedback.store();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}			
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		
		response.getWriter().write("{ \"success\": \"true\"}");
		response.getWriter().flush();
		response.getWriter().close();
	}
}
