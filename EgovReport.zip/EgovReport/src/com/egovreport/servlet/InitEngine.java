package com.egovreport.servlet;

import java.io.File;
import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.egovreport.EgovReportContants;
import com.egovreport.db.DBPool;
import com.egovreport.db.DBResources;
import com.egovreport.utils.Logger;

public class InitEngine extends HttpServlet implements Servlet {

    private static final long serialVersionUID = 1L;

    public void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ServletContext servletContext = getServletContext();
        EgovReportContants.DEPLOYMENT_LOCATION = servletContext.getRealPath("/");
		if (!EgovReportContants.DEPLOYMENT_LOCATION.endsWith("/"))
        DBResources.loadDBProperties();
    }

    public void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }

    public void init() throws ServletException {
        super.init();
        ServletContext servletContext = getServletContext();
        EgovReportContants.DEPLOYMENT_LOCATION = servletContext.getRealPath("/");
		if (!EgovReportContants.DEPLOYMENT_LOCATION.endsWith("/"))
			EgovReportContants.DEPLOYMENT_LOCATION += File.separator;
        if (DBResources.loadDBProperties()) {
            Logger.log(Logger.DEBUG_LEVEL, "------ APPLICATION STARTED NORMALLY: [ OK ]");
        }
    }

    public void destroy() {
        Logger.log(Logger.DEBUG_LEVEL, "STOPPING THREADS STARTED");
        DBPool.shutdownDataSource();
        Logger.log(Logger.DEBUG_LEVEL, "STOPPING THREADS FINISHED");
    }

}