package com.egovreport.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.egovreport.EgovReportContants;
import com.egovreport.db.dbo.PageBugReport;
import com.egovreport.utils.AppUtils;
import com.egovreport.utils.MailMessage;

@WebServlet("/page-bug")
public class Bug extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static boolean isDebug = false;
	private static String debugOutput = "out";
    public Bug() {
        super();
    }	

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String pageTitle = request.getParameter("pT");
		String pageUniqueName = request.getParameter("pUN");
		String pageURL = request.getParameter("pUrl");
		String username = request.getParameter("sn");
		String field1 = request.getParameter("field1");
		String field2 = request.getParameter("field2");
		String field3 = request.getParameter("field3");
		String field4 = request.getParameter("field4");
		String rating = request.getParameter("rating");
		String match = request.getParameter("match");
		String locale = request.getParameter("locale");
		String siteName = request.getParameter("sname");
		String portalReceiverMail = request.getParameter("pMail");//will be used for template administrations
		isDebug = request.getParameter("debug") != null ? true : false;
		debugOutput = request.getParameter("debugOutput") != null ? request.getParameter("debugOutput") : debugOutput;
		logger("in bugreport", "");

		String mailAddressCC = EgovReportContants._MAIL_ADDRESS_CC; //always send mail to Boris, except in customs
		String mailAddressTo = EgovReportContants._MAIL_ADDRESS_TO; // default -> egov helpdesk
		
		if (pageTitle != null && pageTitle.trim().length() > 0 
				&& pageUniqueName != null && pageUniqueName.trim().length() > 0 
				&& pageURL != null && pageURL.trim().length() > 0 
				&& field1 != null && field1.trim().length() > 0) {
			try {
				boolean isProduction = "PROD".equalsIgnoreCase(System.getProperty("environment"));
				boolean isEGOV = "egov".equalsIgnoreCase(siteName);
				String remoteIP = request.getHeader("X-FORWARDED-FOR");
				if (remoteIP == null) {
					remoteIP = request.getRemoteAddr();
				}
				String currentTime = AppUtils.timeMillisToTimestamp(System.currentTimeMillis());
				PageBugReport pageBugReport = new PageBugReport();
				pageBugReport.setPageTitle(pageTitle.trim());
				pageBugReport.setPageUniqueName(pageUniqueName.trim());
				pageBugReport.setPageUrl(pageURL.trim());
				pageBugReport.setUsername(username);
				pageBugReport.setWhatYouWereDoing(field1.trim());
				pageBugReport.setWhatWentWrong(field2.trim());											
				pageBugReport.setIp(remoteIP);			
				pageBugReport.setOperationTime(currentTime);
				pageBugReport.setMailSent("0");
				pageBugReport.setRating(rating);
				pageBugReport.setMatch(match);
				if (locale != null && ("en".equalsIgnoreCase(locale.trim()) || "bg".equalsIgnoreCase(locale.trim()))) {
					pageBugReport.setLocale(locale);
				}
				pageBugReport.setSystemName(siteName);
				if (isProduction) {
					pageBugReport.setEnvironment("1");
				}
				
				
				logger("field4:", field4);
				if (field3 != null && field3.trim().length() > 0) {
					pageBugReport.setSenderName(field3);
				}
				if (field4 != null && field4.trim().length() > 0) {
					pageBugReport.setSenderEmail(field4);
				}
				pageBugReport.create();	
				
				String subjectPortal = "EGOV.BG";
				//customs
				if (pageURL.indexOf("customs.bg") != -1 || pageURL.indexOf("portal/customs") != -1) {
					//isCustoms = true;					
					subjectPortal = "CUSTOMS.BG";
					mailAddressTo = EgovReportContants._MAIL_ADDRESS_CUSTOMS_TO;
					mailAddressCC = EgovReportContants._MAIL_ADDRESS_CUSTOMS_CC;
					logger("customs ", mailAddressTo);
				}
				//banite
				if (pageURL.indexOf("banite.egov.bg") != -1 || pageURL.indexOf("portal/banite") != -1) {
//					isBanite = true;
					subjectPortal = "BANITE.EGOV.BG";
					mailAddressTo = EgovReportContants._MAIL_ADDRESS_BANITE_TO;
					logger("banite", mailAddressTo);
				}
				//petrich
				if (pageURL.indexOf("petrich.bg") != -1 || pageURL.indexOf("portal/petrich") != -1) {
//					isPetrich = true;
					subjectPortal = "PETRICH.BG";					
					mailAddressTo = EgovReportContants._MAIL_ADDRESS_PETRICH_TO;
					logger("petrich", mailAddressTo);
				}
				if (pageURL.indexOf("vidin.bg") != -1 || pageURL.indexOf("portal/vidin") != -1) {
					subjectPortal = "VIDIN.BG";					
					mailAddressTo = EgovReportContants._MAIL_ADDRESS_VIDIN_TO;
					logger("vidin", mailAddressTo);
				}
				if (portalReceiverMail != null && portalReceiverMail.length() > 0) {
					mailAddressTo = portalReceiverMail.trim();
					logger("mail receiver is set from theme", mailAddressTo);
				}
				
				logger("build mail subject mailAddressTo", mailAddressTo);
				//send mail...
				String subject = subjectPortal + " [Page Bug Report]";
				
				String message = "<table style=\"border:1px solid #000;\">";				
					   	message += "<tr>";
					   	message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;Име на страница&nbsp;&nbsp;</td>";
				   		message += "<td style=\"height:22px; border-bottom:1px solid #000;\">&nbsp;&nbsp;" + pageTitle + "&nbsp;&nbsp;</td>";				
				   	message += "</tr>";
				   	message += "<tr style=\"\">";
				   		message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;Уникално име на страница&nbsp;&nbsp;</td>";
				   		message += "<td style=\"height:22px; border-bottom:1px solid #000;\">&nbsp;&nbsp;" + pageUniqueName + "&nbsp;&nbsp;</td>";				
				   	message += "</tr>";
				   	message += "<tr>";
				   		message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;Адрес на страница&nbsp;&nbsp;</td>";
				   		message += "<td style=\"height:22px; border-bottom:1px solid #000;\"><div style=\"padding-left:5px;\"><a href=\"" + pageURL + "\">" + pageURL + "</a></div></td>";				
				   	message += "</tr>";
				   	message += "<tr>";
				   		message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;Потребител&nbsp;&nbsp;</td>";
				   		message += "<td style=\"height:22px; border-bottom:1px solid #000;\">&nbsp;&nbsp;" + username + "&nbsp;&nbsp;</td>";				
				   	message += "</tr>";
				   	if (isEGOV) {
				   	message += "<tr>";
				   		message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;Намерихте ли това, което търсите?&nbsp;&nbsp;</td>";
				   		message += "<td style=\"height:22px; border-bottom:1px solid #000;\">&nbsp;&nbsp;" + ("1".equals(match) ? "Да" : (("2").equals(match) ? "Отчасти" : "Не")) + "&nbsp;&nbsp;</td>";				
				   	message += "</tr>";
				   	message += "<tr>";
				   		message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;Оценете тази страница&nbsp;&nbsp;</td>";
				   		message += "<td style=\"height:22px; border-bottom:1px solid #000;\">&nbsp;&nbsp;" + rating + "/5&nbsp;&nbsp;</td>";				
				   	message += "</tr>";

				   	}
				   	message += "<tr>";
				   		message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;" + (isEGOV ? "Какво търсехте?" : "Каква операция извършвахте?") + "&nbsp;&nbsp;</td>";
				   		message += "<td style=\"height:22px; border-bottom:1px solid #000;\">&nbsp;&nbsp;" + field1 + "&nbsp;&nbsp;</td>";				
				   	message += "</tr>";
				   	if (field2 != null && field2.trim().length() > 0) {				   	
				   	message += "<tr>";
				   		message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;" + (isEGOV ? "Помогнете ни да направим сайта по-добър" : "Какво се обърка?") + "&nbsp;&nbsp;</td>";
				   		message += "<td style=\"height:22px; border-bottom:1px solid #000;\">&nbsp;&nbsp;" + field2 + "&nbsp;&nbsp;</td>";				
				   	message += "</tr>";
				   	}
				   	
				   	if (field3 != null && field3.trim().length() > 0) {
				   		message += "<tr>";
						   	message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;Име&nbsp;&nbsp;</td>";
					   		message += "<td style=\"height:22px; border-bottom:1px solid #000;\">&nbsp;&nbsp;" + field3 + "&nbsp;&nbsp;</td>";				
				   		message += "</tr>";				   		
				   	} if (field4 != null && field4.trim().length() > 0) {
				   		message += "<tr>";
					   		message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;E-mail&nbsp;&nbsp;</td>";
					   		message += "<td style=\"height:22px; border-bottom:1px solid #000;\">&nbsp;&nbsp;" + field4 + "&nbsp;&nbsp;</td>";				
					   	message += "</tr>";					   	
				   	}
				   	message += "<tr>";
					   	message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;IP адрес&nbsp;&nbsp;</td>";
					   	message += "<td style=\"height:22px; border-bottom:1px solid #000;\">&nbsp;&nbsp;" + remoteIP + "&nbsp;&nbsp;</td>";				
				   	message += "</tr>";
				   	if (siteName != null) {
				   	message += "<tr>";
				   		message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;Портал&nbsp;&nbsp;</td>";
				   		message += "<td style=\"height:22px; border-bottom:1px solid #000;\">&nbsp;&nbsp;" + siteName + "&nbsp;&nbsp;</td>";				
				   	message += "</tr>";
				   	}
				   	if (isProduction) {
					message += "<tr>";
				   		message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;Среда&nbsp;&nbsp;</td>";
				   		message += "<td style=\"height:22px; border-bottom:1px solid #000;\">&nbsp;&nbsp;Продуктивна&nbsp;&nbsp;</td>";				
				   	message += "</tr>";				   		
				   	}
					message += "<tr>";
				   		message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;Език&nbsp;&nbsp;</td>";
				   		message += "<td style=\"height:22px; border-bottom:1px solid #000;\">&nbsp;&nbsp;" + locale + "&nbsp;&nbsp;</td>";				
				   	message += "</tr>";				   		
				   	message += "<tr>";
				   		message += "<td nowrap=\"nowrap\" style=\"height:22px; border-right:1px solid #000;border-bottom:1px solid #000;\">&nbsp;&nbsp;Време на операция&nbsp;&nbsp;</td>";
				   		message += "<td style=\"height:22px; border-bottom:1px solid #000;\">&nbsp;&nbsp;" + currentTime + "&nbsp;&nbsp;</td>";				
				   	message += "</tr>";
				message += "</table>";
				logger("build mail message",message);
				try {
					logger("before send mail single", "");
					if (MailMessage.sendSingle(EgovReportContants._MAIL_ADDRESS_FROM, mailAddressTo, mailAddressCC, subject, message, isDebug)) {
						logger("after sendsingle", "");
						pageBugReport.setMailSent("1");
						pageBugReport.store();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}			
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private void logger(String message, String param) {
		if (isDebug) {
			if (debugOutput != null && "out".equalsIgnoreCase(debugOutput.trim())) {
				System.out.println(message + ": " + param);
			} else {
				System.err.println(message + ": " + param);
			}			
		}
	}	
		
}
