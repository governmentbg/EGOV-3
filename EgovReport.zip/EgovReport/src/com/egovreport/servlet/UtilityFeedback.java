package com.egovreport.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.json.Json;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.egovreport.utils.AppUtils;;

@WebServlet("/utilityfeedback")
public class UtilityFeedback extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String NO = "0";
	private static final String YES = "1";
	private static boolean isDebug = false;
       
    public UtilityFeedback() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setHeader("Cache-Control", "no-cache");
		response.setContentType("application/json; charset=UTF-8");
		logger("utilityFeedback query -> doGET(request, response)", "");

		String pTitle = request.getParameter("pTitle");
		String from = request.getParameter("from");
		String to = request.getParameter("to");
		String feedback = request.getParameter("feedback");

		PrintWriter out = response.getWriter();
		String jsonString = "";

		try {
			new com.egovreport.db.dbo.UtilityFeedback();
			com.egovreport.db.dbo.UtilityFeedback[] feedbackResult = 
					com.egovreport.db.dbo.UtilityFeedback.findAllByParameters(pTitle, from, to, feedback, null);

			if (feedbackResult.length > 0) {
				jsonString += "[";
				for (int i = 0; i < feedbackResult.length; i++) {
					com.egovreport.db.dbo.UtilityFeedback result = feedbackResult[i];
					
					String contentUtility = result.getContentUtility();
					String didYouFindInfo = result.getDidYouFindInfo();
					String pageUrl = result.getPageUrl();
					String pageTitle = result.getPageTitle();
					String whatDidYouSearch = result.getWhatDidYouSearch();
					String suggestions = result.getSuggestions();
					String time = result.getOperationTime();	
					
					jsonString += Json.createObjectBuilder()
							.add("contentUtility", contentUtility == null ? "-" : contentUtility)
							.add("didYouFindInfo", didYouFindInfo == null ? "-" : didYouFindInfo)
							.add("pageUrl", pageUrl == null ? "-" : pageUrl)
							.add("pageTitle", pageTitle == null ? "-" : pageTitle)
							.add("whatDidYouSearch", whatDidYouSearch == null ? "-" : whatDidYouSearch)
							.add("suggestions", suggestions == null? "-" : suggestions)
							.add("time", time == null ? "-" : time)
							.build()
							.toString() + (i == feedbackResult.length - 1 ? "" : ",");
				}
				jsonString += "]";
			} else {
				jsonString += Json.createObjectBuilder()
						.add("results", "None")
						.build()
						.toString();
			}

		} catch (Exception e) {
			e.printStackTrace();
			jsonString += Json.createObjectBuilder()
					.add("error", e.getMessage())
					.build()
					.toString();
		}
		
		out.write(jsonString);
		out.flush();
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setHeader("Cache-Control", "no-cache");
		response.setContentType("application/json; charset=utf-8");
		String contentUtility = request.getParameter("contentUtility");
		String didYouFindInfo = request.getParameter("didYouFindInfo");
		String pageURL = request.getParameter("pUrl");
		String pageTitle = request.getParameter("pTitle");
		String whatDidYouSearch = request.getParameter("whatDidYouSearch");
		String suggestions = request.getParameter("suggestions");
		String site = request.getParameter("site");
		isDebug = request.getParameter("debug") != null ? true : false;
		logger("in utilityfeedback", "");

		try {
			String currentTime = AppUtils.timeMillisToTimestamp(System.currentTimeMillis());
			com.egovreport.db.dbo.UtilityFeedback feedback = new com.egovreport.db.dbo.UtilityFeedback();
			feedback.setContentUtility((contentUtility != null && contentUtility.trim().length() > 0 && contentUtility.equals(YES)) ?  YES :  NO);
			feedback.setDidYouFindInfo((didYouFindInfo != null && didYouFindInfo.trim().length() > 0 && didYouFindInfo.equals(YES)) ?  YES :  NO);
			feedback.setPageUrl(pageURL.trim());
			if (whatDidYouSearch != null && whatDidYouSearch.trim().length() > 0) { 
				feedback.setWhatDidYouSearch(whatDidYouSearch);
			}
			if (suggestions != null && suggestions.trim().length() > 0) {
				feedback.setSuggestions(suggestions.trim());
			}
			if (pageTitle != null && pageTitle.trim().length() > 0) {
				feedback.setPageTitle(pageTitle.trim());
			}
			feedback.setIp(request.getRemoteAddr());
			feedback.setSite(site);
			feedback.setOperationTime(currentTime);
			feedback.create();			
					
		} catch (Exception e) {
			e.printStackTrace();
		}
		response.getWriter().write("{ \"success\": \"true\"}");
		response.getWriter().flush();
		response.getWriter().close();
	}
	
	private void logger(String message, String param) {
		if (isDebug) {
			System.out.println(message + ": " + param);
		}
	}
}
