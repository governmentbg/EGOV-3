package com.egovreport.db;


import com.egovreport.utils.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.*;

public abstract class PersistentObject {

	protected QuerySet querySet;
	private String id;

	public PersistentObject(QuerySet qs) {
		this.querySet = qs;
	}

	public final String getId() {
		return id;
	}

	public final void setId(String id) {
		this.id = id;
	}

	private static Connection getConnection() throws SQLException {

		Connection con = DBPool.getConnection();
		if (con == null) {
			Logger.log(Logger.ERROR_LEVEL, "PersistentObject :getConnection : Connection is NULL");
			throw new SQLException("Connection is NULL");
		}
		return con;

	}

	private static void releaseConnection(Connection con) {
		try {
			con.close();
		}
		catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "PersistentObject : releaseConnection : " + e.getMessage());
		}
	}

	protected final long doCreate(DBTransaction trn) throws Exception {

		Connection con = null;
		String lastInsId = "-1";

		try {
			if (trn != null) {
				con = trn.getConnection();
			}
			else {
				con = PersistentObject.getConnection();
			}

			if (con != null && querySet != null) {
				Logger.log(Logger.DEBUG_LEVEL, "Query text: " + querySet.createQuery);
				PreparedStatement pst = con.prepareStatement(querySet.createQuery);

				int j = 0;
				Logger.log(Logger.DEBUG_LEVEL, "Parameter number: " + querySet.keyArray.length);
				for (int i = 0; i < querySet.keyArray.length; i++) {
					String currentElement = querySet.keyArray[i];
					if (currentElement.equals("id")) {
						lastInsId = Sequence.getNextVal(querySet.sequenceName, con);
						setId(lastInsId);
					}
					currentElement = "get" + (currentElement.substring(0, 1)).toUpperCase() + currentElement.substring(1);
					Class[] argArray = null;
					Method method = this.getClass().getMethod(currentElement, argArray);
					Class retType = method.getReturnType();
					if (retType.getName().equals(String.class.getName())) {
						String t_value = (String) method.invoke(this, null);
						pst.setString(j + 1, t_value);
						Logger.log(Logger.DEBUG_LEVEL, "Parameter[" + (j + 1) + ": " + currentElement + "] '" + t_value + "'");
					}
					else if (retType.getName().equals(byte[].class.getName())) {
						byte[] bytes = (byte[]) method.invoke(this, null);
						pst.setBytes(j + 1, bytes);
						Logger.log(Logger.DEBUG_LEVEL, "Parameter[" + (j + 1) + ": " + currentElement + "] '" + bytes + "'");
					}
					j++;
				}

				int result;

				synchronized (this) {
					result = pst.executeUpdate();
					// lastInsId = ((com.mysql.jdbc.Statement) stm).getLastInsertID(); // good for MySQL RDBMS
				}

				Logger.log(Logger.DEBUG_LEVEL, "Last Inserted ID: " + lastInsId);

				pst.close();

				if (result != 1)
					throw new Exception("Unable to execute statement.");

				// return lastInsId. Should be greater than zero if ok ;)
				return (long) Integer.parseInt(lastInsId);
				// because DB2 JDBC does not provide any way to get the sequence value before its use
			}
			else
				throw new Exception("Connection or query set is not initialized.");
		}
		catch (SQLException e) {
			throw new Exception(e.getMessage());
		}
		finally {
			if (trn == null) {
				releaseConnection(con);
			}
		}
	}

	/**
	 * @param conds
	 * @throws java.lang.Exception
	 */
	protected final int doRemove(String conds, DBTransaction trn) throws Exception {
		return doRemove(conds, null, null, trn);
	}
	protected final int doRemove(String conds, Object[] persistantParameters, DBTransaction trn) throws Exception {
		return doRemove(conds, null, persistantParameters, trn);
	}
	protected final int doRemove(String conds, Object[] queryParameters, Object[] persistantParameters, DBTransaction trn)
		throws Exception {
		Connection con = null;
		int result = 0;

		try {
			if (trn != null) {
				con = trn.getConnection();
			}
			else {
				con = PersistentObject.getConnection();
			}

			if (con != null && querySet != null) {
				Statement stm = con.createStatement();
				Logger.log(Logger.DEBUG_LEVEL, querySet.removeQuery + conds);
				result = executeUpdate(querySet, querySet.removeQuery + conds, queryParameters, persistantParameters, con);
				stm.close();

				if (result < 0)
					throw new Exception("Unable to remove record.");
			}
			else
				throw new Exception("Connection or query set is not initialized.");
		}
		catch (SQLException e) {
			throw new Exception(e.getMessage());
		}
		finally {
			if (trn == null) {
				releaseConnection(con);
			}
		}
		return result;
	} // doRemove

	/**
	 * @param conds
	 * @throws java.lang.Exception
	 */
	protected final void doLoad(String conds, DBTransaction trn) throws Exception {
		doLoad(conds, null, null, trn);
	}
	protected final void doLoad(String conds, Object[] persistantParameters, DBTransaction trn) throws Exception {
		doLoad(conds, null, persistantParameters, trn);
	}
	protected final void doLoad(String conds, Object[] queryParameters, Object[] persistantParameters, DBTransaction trn)
		throws Exception {
		Connection con = null;

		try {
			if (trn != null) {
				con = trn.getConnection();
			}
			else {
				con = PersistentObject.getConnection();
			}

			if (con != null && querySet != null) {
				Logger.log(Logger.DEBUG_LEVEL, "Query text: " + querySet.loadQuery);
				PreparedStatement stm =
					prepareQuery(querySet, querySet.loadQuery + conds, queryParameters, persistantParameters, con);
				ResultSet rs = stm.executeQuery();
				if (rs != null && rs.next()) {
					for (int i = 0; i < querySet.columnMap.size(); i++) {
						String currentElement = querySet.keyArray[i];
						currentElement = "set" + (currentElement.substring(0, 1)).toUpperCase() + currentElement.substring(1);
						Class[] argArray = { String.class };
						Method method = this.getClass().getMethod(currentElement, argArray);

						Class[] parTypes = method.getParameterTypes();
						if (parTypes[0].getName().equals(String.class.getName())) {
							Object[] obj = { rs.getString(i + 1)};
							method.invoke(this, obj);
							//                     Logger.log(Logger.DEBUG_LEVEL, "***** Load::Name(): " + parTypes[0].getDescription());
						}
						else if (parTypes[0].getName().equals(byte[].class.getName())) {
							Object[] obj = { getBytes(rs, i + 1)};
							method.invoke(this, obj);
							//                     Logger.log(Logger.DEBUG_LEVEL, "----- Load::Name(): " + parTypes[0].getDescription());
						}
					}
					rs.close();
					stm.close();
				}
				else
					throw new Exception("Unable to load record.");
			}
			else
				throw new Exception("Connection or query set is not initialized.");
		}
		catch (SQLException e) {
			throw new Exception(e.getMessage());
		}
		finally {
			if (trn == null) {
				releaseConnection(con);
			}
		}
	}

	/**
	 * @param conds
	 * @throws java.lang.Exception
	 */
	protected final void doStore(String conds, DBTransaction trn) throws Exception {
		doStore(conds, null, trn);
	}
	protected final void doStore(String conds, Object[] parameters, DBTransaction trn) throws Exception {
		//Get new database connection
		Connection con = null;
		try {
			if (trn != null) {
				con = trn.getConnection();
			}
			else {
				con = PersistentObject.getConnection();
			}

			if (con != null && querySet != null) {

				Logger.log(Logger.DEBUG_LEVEL, "Query text: " + querySet.storeQuery + conds);
				PreparedStatement stm = con.prepareStatement(formatQuery(querySet, querySet.storeQuery + conds));

				//set parameter values in query
				Logger.log(Logger.DEBUG_LEVEL, "Parameter number: " + querySet.keyArray.length);
				for (int i = 0; i < querySet.columnMap.size(); i++) {
					String currentElement = querySet.keyArray[i];
					currentElement = "get" + (currentElement.substring(0, 1)).toUpperCase() + currentElement.substring(1);
					Method method = this.getClass().getMethod(currentElement, null);
					Class retType = method.getReturnType();
					if (retType.getName().equals(String.class.getName())) {
						String t_value = (String) method.invoke(this, null);
						stm.setString(i + 1, t_value);
						Logger.log(Logger.DEBUG_LEVEL, "Parameter[" + (i + 1) + ": " + currentElement + "] '" + t_value + "'");
					}
					else if (retType.getName().equals(byte[].class.getName())) {
						byte[] bytes = (byte[]) method.invoke(this, null);
						stm.setBytes(i + 1, bytes);
						Logger.log(Logger.DEBUG_LEVEL, "Parameter[" + (i + 1) + ": " + currentElement + "] '" + bytes + "'");
					}
				}

				//execute query
				int result = stm.executeUpdate();
				//if unable to update
				stm.close();

				if (result != 1)
					throw new Exception("Unable to store record.");
			}
			else
				throw new Exception("Connection or query set is not initialized.");
		}
		catch (SQLException e) {
			throw new Exception(e.getMessage());
		}
		finally {
			if (trn == null) {
				releaseConnection(con);
			}
		}
	}

	protected static Object findSingle(String conds, String className) throws FinderException, Exception {
		return findSingle(conds, null, null, className, null);
	}
	protected static Object findSingle(String conds, String className, DBTransaction trn) throws FinderException, Exception {
		return findSingle(conds, null, null, className, trn);
	}
	protected static Object findSingle(String conds, Object[] persistantParameters, String className, DBTransaction trn)
		throws FinderException, Exception {
		return findSingle(conds, null, persistantParameters, className, trn);
	}
	protected static Object findSingle(
		String conds,
		Object[] queryParameters,
		Object[] persistantParameters,
		String className,
		DBTransaction trn)
		throws FinderException, Exception {
		Object anc = Class.forName(className).getConstructor(null).newInstance(null);
		Field f = anc.getClass().getField("querySet");
		QuerySet querySet = (QuerySet) f.get(f);

		//Get new database connection
		Connection con = null;

		try {
			if (trn != null) {
				con = trn.getConnection();
			}
			else {
				con = getConnection();
			}
			if (con != null && querySet != null) {

				Logger.log(Logger.DEBUG_LEVEL, querySet.findQuery + conds);
				PreparedStatement stm =
					prepareQuery(querySet, querySet.loadQuery + conds, queryParameters, persistantParameters, con);
				ResultSet rs = stm.executeQuery();
				if (rs != null && rs.next()) {
					Class objectClass = Class.forName(className);
					Object newObject = objectClass.getConstructor(null).newInstance(null);
					for (int i = 0; i < querySet.columnMap.size(); i++) {
						String currentElement = querySet.keyArray[i];
						currentElement = "set" + (currentElement.substring(0, 1)).toUpperCase() + currentElement.substring(1);

						Method method = null;
						try {
							Class[] argArray = { String.class };
							method = objectClass.getMethod(currentElement, argArray);
							Object[] obj = { rs.getString(i + 1)};
							method.invoke(newObject, obj);
						}
						catch (NoSuchMethodException e) {
							Class[] argArray = { byte[].class };
							method = objectClass.getMethod(currentElement, argArray);
							Object[] obj = { getBytes(rs, i + 1)};
							method.invoke(newObject, obj);
						}
					}
					rs.close();
					stm.close();
					return newObject;
				}
				else
					throw new FinderException("Unable to find object.");
			}
			else
				throw new Exception("Connection is not initialized.");
		}
		catch (SQLException e) {
			//            Logger.log(Logger.DEBUG_LEVEL, "e.getMessage() = " + e.getMessage());
			//            Logger.log(Logger.DEBUG_LEVEL, "e.getErrorCode() = " + e.getErrorCode());
			throw new Exception(e.getMessage());
		}
		finally {
			if (trn == null) {
				releaseConnection(con);
			}
		}

	}

	protected static Object[] findMultiple(String conds, String className) throws FinderException, Exception {
		return findMultiple(conds, null, null, className, null);
	}

	protected static Object[] findMultiple(String conds, String className, DBTransaction trn) throws FinderException, Exception {
		return findMultiple(conds, null, null, className, trn);
	}
	protected static Object[] findMultiple(String conds, Object[] persistantParameters, String className, DBTransaction trn)
		throws FinderException, Exception {
		return findMultiple(conds, null, persistantParameters, className, trn);
	}
	protected static Object[] findMultiple(
		String conds,
		Object[] queryParameters,
		Object[] persistantParameters,
		String className,
		DBTransaction trn)
		throws FinderException, Exception {
		Object anc = Class.forName(className).getConstructor(null).newInstance(null);
		Field f = anc.getClass().getField("querySet");
		QuerySet querySet = (QuerySet) f.get(f);

		//Get new database connection

		Connection con = null;
		try {
			if (trn != null) {
				con = trn.getConnection();
			}
			else {
				con = getConnection();
			}

			if (con != null && querySet != null) {
				//create statement object
				PreparedStatement stm =
					con.prepareStatement(
						formatQuery(querySet, querySet.findQuery + conds, queryParameters),
						// ResultSet.TYPE_SCROLL_SENSITIVE,
						ResultSet.TYPE_SCROLL_INSENSITIVE,
						ResultSet.CONCUR_READ_ONLY);
				// does not affect DB2 8.1.0 IBM JDBC Driver
				Logger.log(Logger.DEBUG_LEVEL, querySet.findQuery + conds);
				//execute query
				if (persistantParameters != null)
					setQueryParameters(stm, persistantParameters);
				ResultSet rs = stm.executeQuery();

				if (rs != null) {
					//get number of rows
					rs.last(); // does not work with IBMDB2 8.1.0 JDBC Driver - db2java.zip
					int number = rs.getRow(); // -||-
					//create array to hold the objects
					Object[] objectArray = new Object[number];
					//                    Vector objectVector = new Vector();      // -||- implementing vector instead
					int objectCounter = 0; // -||-
					rs.beforeFirst(); // -||-
					//start composing objects from query result
					while (rs.next()) {
						// create objects here .....................
						//get objects' class and create new object - newObject
						Class objectClass = Class.forName(className);
						Object newObject = objectClass.getConstructor(null).newInstance(null);
						//set newObject's properties
						for (int i = 0; i < querySet.keyArray.length; i++) {
							String currentElement = querySet.keyArray[i];
							currentElement = "set" + (currentElement.substring(0, 1)).toUpperCase() + currentElement.substring(1);

							Method method = null;
							try {
								Class[] argArray = { String.class };
								method = objectClass.getMethod(currentElement, argArray);
								Object[] obj = { rs.getString(i + 1)};
								method.invoke(newObject, obj);
							}
							catch (NoSuchMethodException e) {
								Class[] argArray = { byte[].class };
								method = objectClass.getMethod(currentElement, argArray);
								Object[] obj = { getBytes(rs, i + 1)};
								//                                BLOB blob = ((OracleResultSet) rs).getBLOB(i + 1);
								method.invoke(newObject, obj);
							}
						}
						//store newObject in object array
						objectArray[objectCounter++] = newObject; // using vector implementation
						//                        objectVector.addElement(newObject); // DB2 8.1.0 fix
					}
					rs.close();
					stm.close();

					return objectArray;
					// using vector implementation
					//                    if (objectVector.size() > 0) {
					//                        return objectVector.toArray();
					//                    } else {
					//                        return null;
					//                    }

				}
				else
					throw new FinderException("Unable to find object!");
			}
			else
				throw new Exception("Connection is not initialized!");
		}
		catch (SQLException e) {
			Logger.log(Logger.ERROR_LEVEL, "PersistentObject : findMultiple : " + e.getMessage());
			throw new Exception(e.getMessage());
		}
		finally {
			if (trn == null) {
				releaseConnection(con);
			}
		}
	}

	public void store() throws Exception {
		store(null);
	}

	public void create() throws Exception {
		create(null);
	}

	public void load() throws Exception {
		load(null);
	}

	public void remove() throws Exception {
		remove(null);
	}

	public void create(DBTransaction trn) throws Exception {
		long id = doCreate(trn);
		setId("" + id);
	}

	public void store(DBTransaction trn) throws Exception {
		doStore(querySet.columnMap.get("id") + "=" + getId(), trn);
	}

	public void load(DBTransaction trn) throws Exception {
		doLoad(querySet.columnMap.get("id") + "=" + getId(), trn);
	}

	public void remove(DBTransaction trn) throws Exception {
		doRemove(querySet.columnMap.get("id") + "=" + getId(), trn);
	}

	public int removeMultiple(String ids, DBTransaction trn) throws Exception {
		return doRemove(querySet.columnMap.get("id") + " IN (" + ids + ")", trn);
	}

	public int removeConditional(String cond, DBTransaction trn) throws Exception {
		return doRemove(cond, trn);
	}

	public static byte[] getBytes(ResultSet rs, int index) throws SQLException {
		byte[] res = null;
		//		try {
		//			res = rs.getBytes(index);
		//            Logger.log(Logger.DEBUG_LEVEL, "PersistemtObject: getBytes");
		//		} catch (Exception e) {
		try {
			Logger.log(Logger.DEBUG_LEVEL, "PersistemtObject: getBytes by BinaryStream");
			ByteBuffer bbuffer = new ByteBuffer();
			int bytesread = 0;
			byte[] tmparr = new byte[1024];
			InputStream istream = rs.getBinaryStream(index);
			while (-1 != (bytesread = istream.read(tmparr, 0, 1024)))
				bbuffer.append(tmparr, bytesread);
			res = bbuffer.getBytes();
		}
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
		//		}
		return res;
	}

	public static int toInt(String str) {
		int val = -1;
		try {
			val = Integer.parseInt(str);
		}
		catch (Exception e) {};
		return val;
	}

	public String formatQuery(String query) {
		return formatQuery(query, null);
	}

	public String formatQuery(String query, Object[] params) {
		return formatQuery(querySet, query, params);
	}

	public static String formatQuery(QuerySet querySet, String query) {
		return formatQuery(querySet, query, null);
	}

	public static String formatQuery(QuerySet querySet, String query, Object[] params) {
		int i, length;
		char c;
		if (query == null)
			return null;
		length = query.length();
		StringBuffer result = new StringBuffer();
		for (i = 0; i < length; i++) {
			c = query.charAt(i);
			if (c == '\'') {
				do {
					result.append(c);
					i++;
					if (i < length)
						c = query.charAt(i);
				}
				while (i < length && (query.charAt(i - 1) == '\\' || query.charAt(i) != '\''));
				if (i < length)
					result.append(c);
			}
			else if (c == '"') {
				do {
					result.append(c);
					i++;
					if (i < length)
						c = query.charAt(i);
				}
				while (i < length && (query.charAt(i - 1) == '\\' || query.charAt(i) != '"'));
				if (i < length)
					result.append(c);
			}
			else if (c == '$') {
				StringBuffer id = new StringBuffer();
				do {
					id.append(c);
					i++;
				}
				while (i < length && (Character.isUnicodeIdentifierPart(c = query.charAt(i)) || c=='$'));
				if (i < length)
					i--;

				if (id.length() > 1) {
					String id_name = id.substring(1);
					int ix;
					if("$table".equals(id_name))
						result.append(DBResources._SCHEMANAME + querySet.table);
					else if (null != querySet.columnMap.get(id_name))
						result.append((String) querySet.columnMap.get(id_name));
					else if ((ix = toInt(id_name)) >= 0 && params != null && ix < params.length)
						result.append(params[ix].toString());
					else
						result.append(id);
				}
				else
					result.append(id);
			}
			else
				result.append(c);
		}
		String res = result.toString();
		Logger.log(Logger.DEBUG_LEVEL, "formatQuery: " + res);
		return res;
	}

	static void setQueryParameters(PreparedStatement statement, Object[] parameters) throws SQLException {
		if (parameters != null)
			for (int i = 0; i < parameters.length; i++) {
				Object parameter = parameters[i];
				Logger.log(Logger.DEBUG_LEVEL, "parameter["+i+"]: " + parameter);
				if (parameter instanceof Integer)
					statement.setInt(i + 1, ((Integer) parameters[i]).intValue());
				else if (parameter instanceof Long)
					statement.setLong(i + 1, ((Long) parameters[i]).longValue());
				else if (parameter instanceof Double)
					statement.setDouble(i + 1, ((Double) parameters[i]).doubleValue());
				else if (parameter instanceof String)
					statement.setString(i + 1, ((String) parameters[i]));
				else if (parameter instanceof byte[])
					statement.setBytes(i + 1, ((byte[]) parameters[i]));
			}
	}

	public PreparedStatement prepareQuery(String query, Object[] queryParameters, Object[] persistantParameters, Connection con)
		throws SQLException {
		return prepareQuery(querySet, query, queryParameters, persistantParameters, con);
	}
	static PreparedStatement prepareQuery(
		QuerySet querySet,
		String query,
		Object[] queryParameters,
		Object[] persistantParameters,
		Connection con)
		throws SQLException {
		PreparedStatement st = con.prepareStatement(formatQuery(querySet, query, queryParameters));
		if (persistantParameters != null)
			setQueryParameters(st, persistantParameters);
		return st;
	}

	public int executeUpdate(String query, Object[] queryParameters, Object[] persistantParameters, Connection con)
		throws SQLException {
		return executeUpdate(querySet, query, queryParameters, persistantParameters, con);
	}
	static int executeUpdate(
		QuerySet querySet,
		String query,
		Object[] queryParameters,
		Object[] persistantParameters,
		Connection con)
		throws SQLException {

		PreparedStatement st = con.prepareStatement(formatQuery(querySet, query, queryParameters));
		if (persistantParameters != null)
			setQueryParameters(st, persistantParameters);
		return st.executeUpdate();

	}

	/*

	columnMap.get("id") + "=" + id

	"$id = ? and $direction = ?", new Object[]{id, direction}

	"$id = $0 and $direction = $1", new Object[]{id, direction}

	---------------------------------------------------------------------

	columnMap.get("id") + " > 0 " + " AND NVL(" + columnMap.get("internalCode") + ",0) = 0"
	                + " AND " + columnMap.get("netpId") + " LIKE 'EU100%' "
	                + " AND NVL(" + columnMap.get("lastTransmitDate") + ",'0') < NVL(" + columnMap.get("lastUpdateDate") + "," + columnMap.get("recordCreationDate") + ") "
	                + " ORDER BY " + columnMap.get("netpId")


	" $id > 0 AND NVL( $internalCode,0) = 0 "
	      + " AND $netpId LIKE 'EU100%' "
	      + " AND NVL($lastTransmitDate,'0') < NVL($lastUpdateDate, $recordCreationDate) "
	      + " ORDER BY $netpId "

	---------------------------------------------------------------------
	ex:
	 $id > 0 AND NVL( $internalCode,0) = 0  AND $netpId LIKE 'EU100%'  AND NVL($lastTransmitDate,'0') < NVL($lastUpdateDate, $recordCreationDate)  ORDER BY $netpId
	 ID > 0 AND NVL( INTERNALCODE,0) = 0  AND NETPID LIKE 'EU100%'  AND NVL(LASTTRANSMITDATE,'0') < NVL(LASTUPDATEDATE, RECORDCREATIONDATE)  ORDER BY NETPID

	*/
}