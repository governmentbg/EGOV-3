package com.egovreport.db;

import java.util.Enumeration;
import java.util.Hashtable;

public class QueryComposer {

    public static QuerySet composeAll(String schema, String table, String sequenceName, Hashtable columnMap) {

        String[] keyArray = getKeyArray(columnMap);
        QuerySet qs = new QuerySet(schema, table, columnMap, keyArray);

        qs.createQuery = composeCreateQuery(schema, table, columnMap, keyArray);
        qs.loadQuery = composeLoadQuery(schema, table, columnMap, keyArray);
        qs.storeQuery = composeStoreQuery(schema, table, columnMap, keyArray);
        qs.removeQuery = composeRemoveQuery(schema, table);
        qs.findQuery = composeFindQuery(schema, table, columnMap, keyArray);
        qs.sequenceName = sequenceName;

        return qs;
    }

    public static String[] getKeyArray(Hashtable columnMap) {
        Enumeration keys = columnMap.keys();
        String[] keyArray = new String[columnMap.size()];
        int counter = 0;
        while (keys.hasMoreElements()) {
            keyArray[counter] = (String) keys.nextElement();
            counter++;
        }
        return keyArray;
    }

    public static String composeCreateQuery(String schema, String table, Hashtable columnMap, String[] keyArray) {
        StringBuffer query = new StringBuffer();
        query.append("INSERT INTO " + schema + table + "(");
        for (int i = 0; i < keyArray.length; i++) {
            query.append(columnMap.get(keyArray[i]) + ", ");
        }
        query.deleteCharAt(query.length() - 2);
        query.append(") VALUES(");

        for (int i = 0; i < keyArray.length; i++) {
            query.append("?, ");
        }
        return query.substring(0, query.length() - 2) + ")";
    }

    public static String composeLoadQuery(String schema, String table, Hashtable columnMap, String[] keyArray) {
        StringBuffer query = new StringBuffer();
        query.append("SELECT ");

        for (int i = 0; i < keyArray.length; i++) {
            query.append(columnMap.get(keyArray[i]) + ", ");
        }
        return query.substring(0, query.length() - 2) + " FROM " + schema + table + " WHERE ";
    }

    public static String composeStoreQuery(String schema, String table, Hashtable columnMap, String[] keyArray) {
        //compose store query
        StringBuffer query = new StringBuffer();
        query.append("UPDATE " + schema + table + " SET ");
        //add parameters to query
        for (int i = 0; i < keyArray.length; i++) {
            query.append(columnMap.get(keyArray[i]) + " = ?, ");
        }
        return query.substring(0, query.length() - 2) + " WHERE ";
    }

    public static String composeRemoveQuery(String schema, String table) {
        return "DELETE FROM " + schema + table + " WHERE ";
    }

    public static String composeFindQuery(String schema, String table, Hashtable columnMap, String[] keyArray) {
        StringBuffer query = new StringBuffer();
        query.append("SELECT ");
        for (int i = 0; i < keyArray.length; i++) {
            query.append(columnMap.get(keyArray[i]) + ", ");
        }
        query.deleteCharAt(query.length() - 2);
        query.append(" FROM " + schema + table + " WHERE ");

        return query.toString();
    }

} // class
