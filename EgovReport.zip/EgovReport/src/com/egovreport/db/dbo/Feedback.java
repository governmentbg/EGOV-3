package com.egovreport.db.dbo;

import com.egovreport.EgovReportContants;
import com.egovreport.db.*;

import java.util.Hashtable;

public class Feedback extends PersistentObject {
	private static String CLASS_NAME = Feedback.class.getName();
	protected static String schema =EgovReportContants._SCHEMANAME;

	protected static String table;
	protected static Hashtable<String, String> columnMap;
	protected static String[] keyArray;
	protected static String sequenceName;
	public static QuerySet querySet;

	static {
		Feedback.table = "FEEDBACK";
		Feedback.sequenceName = "SEQ_FEEDBACKID";

		Feedback.columnMap = new Hashtable<>(30);
		Feedback.columnMap.put("id", "FEEDBACKID");
		Feedback.columnMap.put("problemArea", "PROBLEMAREA");
		Feedback.columnMap.put("pageUrl", "PAGEURL");
		Feedback.columnMap.put("description", "DESCRIPTION");
		Feedback.columnMap.put("response", "RESPONSE");
		Feedback.columnMap.put("name", "NAME");
		Feedback.columnMap.put("email", "email");
		Feedback.columnMap.put("ip", "ip");
		Feedback.columnMap.put("site", "site");
		Feedback.columnMap.put("operationTime", "operationtime");
		Feedback.columnMap.put("mailSent", "mailsent");

		Feedback.querySet = QueryComposer.composeAll(schema, table, sequenceName, columnMap);
	}

	private String problemArea;
	private String pageUrl;
	private String description;
	private String response;
	private String name;
	private String email;
	private String ip;
	private String site;
	private String operationTime;
	private String mailSent;

	public Feedback() {
		super(Feedback.querySet);
	}

	public String getProblemArea() {
		return problemArea;
	}

	public void setProblemArea(String problemArea) {
		this.problemArea = problemArea;
	}

	public String getPageUrl() {
		return pageUrl;
	}

	public void setPageUrl(String pageUrl) {
		this.pageUrl = pageUrl;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getSite() {
		return site;
	}

	public void setSite(String site) {
		this.site = site;
	}

	public String getOperationTime() {
		return operationTime;
	}

	public void setOperationTime(String operationTime) {
		this.operationTime = operationTime;
	}

	public String getMailSent() {
		return mailSent;
	}

	public void setMailSent(String mailSent) {
		this.mailSent = mailSent;
	}

	public static Feedback findById(String id, DBTransaction transaction) throws FinderException, Exception {
		final String cond = "$id = " + id;
		return (Feedback) findSingle(cond, CLASS_NAME, transaction);
	}

	public static Feedback[] findAllByName(String name, DBTransaction transaction) throws FinderException, Exception {
		final String cond = "UPPER($name) = '" + name.toUpperCase() + "' ORDER BY OPERATIONTIME DESC";
		return findFeedbacks(cond, transaction);
	}	

	public static Feedback[] findAllByProblemArea(String problemArea, DBTransaction transaction) throws FinderException, Exception {
		final String cond = "$problemArea = '" + problemArea + "' ORDER BY OPERATIONTIME DESC";
		return findFeedbacks(cond, transaction);
	}	
	
	public static Feedback[] findAllByMailSent(String mailSent, DBTransaction transaction) throws FinderException, Exception {
		final String cond = "$mailSent = '" + mailSent + "' ORDER BY OPERATIONTIME DESC";
		return findFeedbacks(cond, transaction);
	}	
	
	public static Feedback[] findAllByIpAddress(String ipAddress, DBTransaction transaction) throws FinderException, Exception {
		final String cond = "$ip = '" + ipAddress + "'";
		return findFeedbacks(cond, transaction);
	}

	public static Feedback[] findAll(DBTransaction transaction) throws FinderException, Exception {
		final String cond = "$id > 0";
		return findFeedbacks(cond, transaction);
	}

	private static Feedback[] findFeedbacks(final String cond, DBTransaction transaction) throws FinderException, Exception {
		return findFeedbacks(cond, null, transaction);
	}

	private static Feedback[] findFeedbacks(final String cond, Object[] parameters, DBTransaction transaction) throws FinderException, Exception {
		Object[] tmp = findMultiple(cond, parameters, CLASS_NAME, transaction);
		if (tmp != null) {
			Feedback[] objects = new Feedback[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				objects[i] = (Feedback) tmp[i];
			}
			return objects;
		} else {
			throw new FinderException("Unable to find object");
		}
	}

}
