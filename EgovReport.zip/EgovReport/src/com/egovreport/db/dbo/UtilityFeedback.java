package com.egovreport.db.dbo;

import com.egovreport.EgovReportContants;
import com.egovreport.db.*;

import java.util.Hashtable;

public class UtilityFeedback extends PersistentObject {
	private static String CLASS_NAME = UtilityFeedback.class.getName();
	protected static String schema =EgovReportContants._SCHEMANAME;

	protected static String table;
	protected static Hashtable<String, String> columnMap;
	protected static String[] keyArray;
	protected static String sequenceName;
	public static QuerySet querySet;

	static {
		UtilityFeedback.table = "UTILITYFEEDBACK";
		UtilityFeedback.sequenceName = "SEQ_UTILITYFEEDBACK";

		UtilityFeedback.columnMap = new Hashtable<>(20);
		UtilityFeedback.columnMap.put("id", "UTILITYFEEDBACKID");
		UtilityFeedback.columnMap.put("contentUtility", "CONTENTUTILITY");
		UtilityFeedback.columnMap.put("didYouFindInfo", "DIDYOUFINDINFO");
		UtilityFeedback.columnMap.put("pageUrl", "PAGEURL");
		UtilityFeedback.columnMap.put("whatDidYouSearch", "WHATDIDYOUSEARCH");
		UtilityFeedback.columnMap.put("suggestions", "SUGGESTIONS");
		UtilityFeedback.columnMap.put("ip", "ip");
		UtilityFeedback.columnMap.put("site", "site");
		UtilityFeedback.columnMap.put("operationTime", "operationtime");
		UtilityFeedback.columnMap.put("pageTitle", "PAGETITLE");

		UtilityFeedback.querySet = QueryComposer.composeAll(schema, table, sequenceName, columnMap);
	}

	private String contentUtility;
	private String didYouFindInfo;
	private String pageUrl;
	private String whatDidYouSearch;
	private String suggestions;
	private String ip;
	private String site;
	private String operationTime;
	private String pageTitle;

	public String getPageTitle() {
		return pageTitle;
	}

	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}

	public UtilityFeedback() {
		super(UtilityFeedback.querySet);
	}
	
	public String getContentUtility() {
		return contentUtility;
	}

	public void setContentUtility(String contentUtility) {
		this.contentUtility = contentUtility;
	}

	public String getDidYouFindInfo() {
		return didYouFindInfo;
	}

	public void setDidYouFindInfo(String didYouFindInfo) {
		this.didYouFindInfo = didYouFindInfo;
	}

	public String getWhatDidYouSearch() {
		return whatDidYouSearch;
	}

	public void setWhatDidYouSearch(String whatDidYouSearch) {
		this.whatDidYouSearch = whatDidYouSearch;
	}

	public String getSuggestions() {
		return suggestions;
	}

	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}

	public String getPageUrl() {
		return pageUrl;
	}

	public void setPageUrl(String pageUrl) {
		this.pageUrl = pageUrl;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getSite() {
		return site;
	}

	public void setSite(String site) {
		this.site = site;
	}

	public String getOperationTime() {
		return operationTime;
	}

	public void setOperationTime(String operationTime) {
		this.operationTime = operationTime;
	}

	
	public static UtilityFeedback findById(String id, DBTransaction transaction) throws FinderException, Exception {
		final String cond = "$id = " + id;
		return (UtilityFeedback) findSingle(cond, CLASS_NAME, transaction);
	}

	public static UtilityFeedback[] findAllByName(String name, DBTransaction transaction) throws FinderException, Exception {
		final String cond = "UPPER($name) = '" + name.toUpperCase() + "' ORDER BY OPERATIONTIME DESC";
		return findFeedbacks(cond, transaction);
	}

	public static UtilityFeedback[] findAllByParameters(String name, String from, String to, String feedback, DBTransaction transaction) throws FinderException, Exception {
		String cond = "";
		boolean nameFlag = false;
		boolean fromFlag = false;
		boolean toFlag = false;
		
		if (!name.equals(null) && name.length() > 0) {
			nameFlag = true;
			cond  = " $pageTitle = '" + name + "'";
		}
		if (from.length() > 0 && from != null) {
			fromFlag = true;
			if (nameFlag) {
				cond += " AND";
			}
			cond += " OPERATIONTIME >= TO_DATE('" + from + "', 'YYYY-MM-DD HH24:MI:SS')";
		}
		if (to.length() > 0 && to != null) {
			toFlag = true;
			if (nameFlag || fromFlag) {
				cond += " AND";
			}
			cond += " OPERATIONTIME <= TO_DATE('" + to + "', 'YYYY-MM-DD HH24:MI:SS')";
		}
		if (feedback.length() > 0 && feedback != null) {
			if (nameFlag || fromFlag || toFlag) {
				cond += " AND";
			}
			cond += " CONTENTUTILITY = '" + feedback + "'";
		}
		cond += " ORDER BY OPERATIONTIME DESC";
		
		return findFeedbacks(cond, transaction);
	}
	
	public static UtilityFeedback[] findAllByIpAddress(String ipAddress, DBTransaction transaction) throws FinderException, Exception {
		final String cond = "$ip = '" + ipAddress + "'";
		return findFeedbacks(cond, transaction);
	}

	public static UtilityFeedback[] findAll(DBTransaction transaction) throws FinderException, Exception {
		final String cond = "$id > 0";
		return findFeedbacks(cond, transaction);
	}

	private static UtilityFeedback[] findFeedbacks(final String cond, DBTransaction transaction) throws FinderException, Exception {
		return findFeedbacks(cond, null, transaction);
	}

	private static UtilityFeedback[] findFeedbacks(final String cond, Object[] parameters, DBTransaction transaction) throws FinderException, Exception {
		Object[] tmp = findMultiple(cond, parameters, CLASS_NAME, transaction);
		if (tmp != null) {
			UtilityFeedback[] objects = new UtilityFeedback[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				objects[i] = (UtilityFeedback) tmp[i];
			}
			return objects;
		} else {
			throw new FinderException("Unable to find object");
		}
	}

}
