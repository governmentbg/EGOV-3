package com.egovreport.db.dbo;

import com.egovreport.EgovReportContants;
import com.egovreport.db.*;

import java.util.Hashtable;

public class PageBugReport extends PersistentObject {
	private static String CLASS_NAME = PageBugReport.class.getName();
	protected static String schema =EgovReportContants._SCHEMANAME;

	protected static String table;
	protected static Hashtable<String, String> columnMap;
	protected static String[] keyArray;
	protected static String sequenceName;
	public static QuerySet querySet;

	static {
		PageBugReport.table = "PAGEBUGREPORT";
		PageBugReport.sequenceName = "SEQ_PAGEBUGREPORTID";

		PageBugReport.columnMap = new Hashtable<>(30);
		PageBugReport.columnMap.put("id", "PAGEBUGREPORTID");
		PageBugReport.columnMap.put("pageTitle", "PAGETITLE");
		PageBugReport.columnMap.put("pageUniqueName", "PAGEUNIQUENAME");
		PageBugReport.columnMap.put("pageUrl", "PAGEURL");
		PageBugReport.columnMap.put("whatYouWereDoing", "WHATYOUWEREDOING");
		PageBugReport.columnMap.put("whatWentWrong", "WHATWENTWRONG");
		PageBugReport.columnMap.put("username", "USERNAME");
		PageBugReport.columnMap.put("ip", "ip");
		PageBugReport.columnMap.put("operationTime", "operationtime");
		PageBugReport.columnMap.put("mailSent", "mailsent");
		PageBugReport.columnMap.put("senderName", "SENDERNAME");
		PageBugReport.columnMap.put("senderEmail", "SENDEREMAIL");
		PageBugReport.columnMap.put("rating", "RATING");
		PageBugReport.columnMap.put("match", "MATCH");		
		PageBugReport.columnMap.put("systemName", "SYSTEMNAME");
		PageBugReport.columnMap.put("environment", "ENVIRONMENT");
		PageBugReport.columnMap.put("locale", "LOCALE");

		PageBugReport.querySet = QueryComposer.composeAll(schema, table, sequenceName, columnMap);
	}

	private String pageTitle;
	private String pageUniqueName;
	private String pageUrl;
	private String whatYouWereDoing;
	private String whatWentWrong;
	private String username;
	private String ip;
	private String operationTime;
	private String mailSent;
	private String senderName;
	private String senderEmail;
	private String rating;
	private String match;
	private String systemName;
	private String environment;
	private String locale;
	
	public PageBugReport() {
		super(PageBugReport.querySet);
	}

	public String getPageTitle() {
		return pageTitle;
	}

	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}

	public String getPageUniqueName() {
		return pageUniqueName;
	}

	public void setPageUniqueName(String pageUniqueName) {
		this.pageUniqueName = pageUniqueName;
	}

	public String getPageUrl() {
		return pageUrl;
	}

	public void setPageUrl(String pageUrl) {
		this.pageUrl = pageUrl;
	}

	public String getWhatYouWereDoing() {
		return whatYouWereDoing;
	}

	public void setWhatYouWereDoing(String whatYouWereDoing) {
		this.whatYouWereDoing = whatYouWereDoing;
	}

	public String getWhatWentWrong() {
		return whatWentWrong;
	}

	public void setWhatWentWrong(String whatWentWrong) {
		this.whatWentWrong = whatWentWrong;
	}
	
	public String getSenderName() {
		return senderName;
	}

	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getOperationTime() {
		return operationTime;
	}

	public void setOperationTime(String operationTime) {
		this.operationTime = operationTime;
	}

	public String getMailSent() {
		return mailSent;
	}

	public void setMailSent(String mailSent) {
		this.mailSent = mailSent;
	}
	
	public String getSenderEmail() {
		return senderEmail;
	}

	public void setSenderEmail(String senderEmail) {
		this.senderEmail = senderEmail;
	}
	
	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public String getMatch() {
		return match;
	}

	public void setMatch(String match) {
		this.match = match;
	}

	public String getSystemName() {
		return systemName;
	}

	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public String getLocale() {
		return locale;
	}

	public void setLocale(String locale) {
		this.locale = locale;
	}

	public static PageBugReport findById(String id, DBTransaction transaction) throws FinderException, Exception {
		final String cond = "$id = " + id;
		return (PageBugReport) findSingle(cond, CLASS_NAME, transaction);
	}

	public static PageBugReport[] findAllByUsername(String username, DBTransaction transaction) throws FinderException, Exception {
		final String cond = "$username = '" + username + "' ORDER BY OPERATIONTIME DESC";
		return findPageBugReports(cond, transaction);
	}	

	public static PageBugReport[] findAllByPageUniqueName(String pageUniqueName, DBTransaction transaction) throws FinderException, Exception {
		final String cond = "$pageUniqueName = '" + pageUniqueName + "' ORDER BY OPERATIONTIME DESC";
		return findPageBugReports(cond, transaction);
	}	
	
	public static PageBugReport[] findAllByMailSent(String mailSent, DBTransaction transaction) throws FinderException, Exception {
		final String cond = "$mailSent = '" + mailSent + "' ORDER BY OPERATIONTIME DESC";
		return findPageBugReports(cond, transaction);
	}	
	
	public static PageBugReport[] findAllByIpAddress(String ipAddress, DBTransaction transaction) throws FinderException, Exception {
		final String cond = "$ip = '" + ipAddress + "'";
		return findPageBugReports(cond, transaction);
	}

	public static PageBugReport[] findAll(DBTransaction transaction) throws FinderException, Exception {
		final String cond = "$id > 0";
		return findPageBugReports(cond, transaction);
	}

	private static PageBugReport[] findPageBugReports(final String cond, DBTransaction transaction) throws FinderException, Exception {
		return findPageBugReports(cond, null, transaction);
	}

	private static PageBugReport[] findPageBugReports(final String cond, Object[] parameters, DBTransaction transaction) throws FinderException, Exception {
		Object[] tmp = findMultiple(cond, parameters, CLASS_NAME, transaction);
		if (tmp != null) {
			PageBugReport[] objects = new PageBugReport[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				objects[i] = (PageBugReport) tmp[i];
			}
			return objects;
		} else {
			throw new FinderException("Unable to find object");
		}
	}

}
