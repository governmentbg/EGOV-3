package com.egovreport.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.egovreport.db.dbo.PageBugReport;
import com.egovreport.utils.Logger;

public class QueryExecution {

	private static synchronized Connection getConnection() throws SQLException {
		Connection con = DBPool.getConnection();		
		if (con == null) {
			throw new SQLException("Connection is NULL");
		}
		con.setAutoCommit(true);
		return con;
	} 

	private static synchronized void releaseConnection(Connection con) throws SQLException {
		try {
			con.close();
		} catch (SQLException e) {
			Logger.log(Logger._LOGLEVEL, "[ERROR OCCURED] IN [QueryExecution] | [releaseConnection] | CALL METHOD -> con.close() : " + e.getMessage());
			throw new SQLException(e.getMessage());
		}
	} 

	static public ArrayList<PageBugReport> findAllPageBugReports() {
		Connection con = null;
		PageBugReport pageBugReport = null;
		ArrayList<PageBugReport> pageBugReportArr = null;
		try {
			con = getConnection();
			if (con != null) {
				Statement stmt = con.createStatement();
				String query = "SELECT PAGEBUGREPORTID, PAGETITLE, PAGEUNIQUENAME, PAGEURL, WHATYOUWEREDOING, WHATWENTWRONG, USERNAME, IP, OPERATIONTIME, MAILSENT, SENDERNAME, SENDEREMAIL, FROM " + DBResources._SCHEMANAME + "PAGEBUGREPORT " + " WHERE 1=1 ORDER BY OPERATIONTIME DESC";
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution: query => " + query);

				ResultSet rs = stmt.executeQuery(query);
				if (rs != null) {
					pageBugReportArr = new ArrayList<>();
					while (rs.next()) {
						pageBugReport = new PageBugReport();
						pageBugReport.setId(rs.getString(1));
						pageBugReport.setPageTitle(rs.getString(2));
						pageBugReport.setPageUniqueName(rs.getString(3));
						pageBugReport.setPageUrl(rs.getString(4));
						pageBugReport.setWhatYouWereDoing(rs.getString(5));
						pageBugReport.setWhatWentWrong(rs.getString(6));
						pageBugReport.setUsername(rs.getString(7));
						pageBugReport.setIp(rs.getString(8));
						pageBugReport.setOperationTime(rs.getString(9));
						pageBugReport.setMailSent(rs.getString(10));
						pageBugReport.setSenderName(rs.getString(11));
						pageBugReport.setSenderEmail(rs.getString(12));						
						pageBugReportArr.add(pageBugReport);
					}
					rs.close();
				}
				stmt.close();
				if (pageBugReportArr != null && pageBugReportArr.size() > 0) {
					return pageBugReportArr;
				}
			} else {
				Logger.log(Logger.ERROR_LEVEL, "QueryExecution : findAllPageBugReports : connection is not initialized.");
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				releaseConnection(con);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return null;
	}
}