package com.egovreport.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Random;
import java.util.StringTokenizer;

public class AppUtils {

	private static SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH);
	private static SimpleDateFormat dateTimeFormatYYYY_MM_dd = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);

	public static long date_yyyy_MM_dd_ToTimeMillis(final String date, final boolean beginDay) {
		try {
			final StringTokenizer st = new StringTokenizer(date, "-");
			if (st.countTokens() != 3) {
				return 0;
			}
			final int year = Integer.parseInt(st.nextToken());
			final int month = Integer.parseInt(st.nextToken());
			final int day = Integer.parseInt(st.nextToken());
			final Calendar cal = Calendar.getInstance();
			cal.set(Calendar.DAY_OF_MONTH, day);
			cal.set(Calendar.MONTH, month - 1);
			cal.set(Calendar.YEAR, year);

			if (beginDay) {
				cal.set(Calendar.HOUR_OF_DAY, 0);
				cal.set(Calendar.MINUTE, 0);
				cal.set(Calendar.SECOND, 0);
				cal.set(Calendar.MILLISECOND, 0);
			} else {
				cal.set(Calendar.HOUR_OF_DAY, 23);
				cal.set(Calendar.MINUTE, 59);
				cal.set(Calendar.SECOND, 59);
				cal.set(Calendar.MILLISECOND, 999);
			}
			return cal.getTime().getTime();
		} catch (final NumberFormatException e) {
			e.printStackTrace();
		}
		return 0;
	}

	public static long date_TimestampToTimeMillis(final String s) {
		if (s != null) {
			try {
				return dateTimeFormat.parse(s).getTime();
			} catch (final Exception e) {
			}
		}
		return 0;
	}

	public static String timeMillisToTimestamp(final String millis) {
		try {
			final long l = Long.parseLong(millis);
			return dateTimeFormat.format(new Date(l));
		} catch (final Exception e) {
			System.out.println("AppUtils : timeMillisToTimestamp : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static String timeMillisToTimestamp(final long millis) {
		try {

			return dateTimeFormat.format(new Date(millis));
		} catch (final Exception e) {
			System.out.println("AppUtils : timeMillisToTimestamp : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static String timeMillisToYYYY_MM_DD_HH_MM_SS(final String timeMillis) {
		try {
			final Date date = new Date(Long.parseLong(timeMillis));
			return dateTimeFormat.format(date);
		} catch (Exception e) {
			System.out.println("AppUtils : timeMillisToYYYY_MM_DD_HH_MM_SS : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static String timeMillisToYYYY_MM_DD_HH_MM_SS(final long timeMillis) {
		try {
			final Date date = new Date(timeMillis);
			return dateTimeFormat.format(date);
		} catch (Exception e) {
			System.out.println("AppUtils : timeMillisToYYYY_MM_DD_HH_MM_SS : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static String timeMillisToYYYY_MM_DD(final long timeMillis) {
		try {
			final Date date = new Date(timeMillis);
			return dateTimeFormatYYYY_MM_dd.format(date);
		} catch (Exception e) {
			System.out.println("AppUtils : timeMillisToYYYY_MM_DD : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static String getFileExtension(String fileName) {
		if (fileName != null && fileName.trim().length() > 0) {
			fileName = fileName.trim();
			int pos = fileName.lastIndexOf('.');
			if (pos != -1) {
				return fileName.substring(pos + 1);
			}
		}
		return fileName;
	}
	
	public static String getRandomNumber() {
		String number = String.valueOf(System.currentTimeMillis());
		Random randomGenerator = new Random();
		for (int i = 0; i < 10; i++){
			number += randomGenerator.nextInt(100);	      
	    }
		return number;
	}
}
