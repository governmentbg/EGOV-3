package com.egovreport;

public class EgovReportContants {
	public static final String _PRODUCT_NAME = "EGOV Report ";
	public static final String _PRODUCT_VERSION = "1.0";
	public static String DEPLOYMENT_LOCATION = "";
	
	public static boolean _DO_POOLING = false;
	public static String _POOLNAME = null;
	public static int _POOLING;
	public static int _INITIALCONNECTIONS;
	public static int _MAXACTIVECONNECTIONS;
	public static int _MINIDLECONNECTIONS;
	public static int _MAXIDLECONNECTIONS;
	public static int _MAXWAITFORPOOLEDCONNECTION;
	public static boolean _TESTBEFORE;
	public static boolean _TESTAFTER;
	public static int _CONNECTIONMONITOR;
	
	public static String _MAIL_SMTP_HOST = null;
	public static String _MAIL_ADDRESS_FROM = null;
	public static String _MAIL_ADDRESS_TO = null;
	public static String _MAIL_ADDRESS_CUSTOMS_TO = null;
	public static String _MAIL_ADDRESS_CUSTOMS_CC = null;
	public static String _MAIL_ADDRESS_CC = null;
	public static String _MAIL_ADDRESS_BANITE_TO = null;
	public static String _MAIL_ADDRESS_PETRICH_TO = null;
	public static String _MAIL_ADDRESS_VIDIN_TO = null;

	public static int _LOGLEVEL = 2;
	public static boolean _SHOWTIMESTAMP = false;
}
