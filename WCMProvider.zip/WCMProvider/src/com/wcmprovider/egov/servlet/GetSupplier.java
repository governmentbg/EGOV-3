package com.wcmprovider.egov.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.json.XML;

import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.Category;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.ContentComponent;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.ImageComponent;
import com.ibm.workplace.wcm.api.OptionSelectionComponent;
import com.ibm.workplace.wcm.api.RichTextComponent;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.TextComponent;
import com.ibm.workplace.wcm.api.exceptions.ComponentNotFoundException;
import com.ibm.workplace.wcm.api.query.ProfileSelectors;
import com.ibm.workplace.wcm.api.query.Query;
import com.ibm.workplace.wcm.api.query.ResultIterator;
import com.ibm.workplace.wcm.api.query.Selectors;
import com.ibm.workplace.wcm.api.query.WorkflowSelectors;
import com.wcmprovider.egov.Constants;
import com.wcmprovider.egov.util.HtmlConverter;


@WebServlet("/get-supplier")
public class GetSupplier extends HttpServlet {
	private static final String PARAMETER_FORMAT = "format";
	private static final String PARAMETER_TYPE_JSON = "json";	
	private static final String PARAMETER_ID = "id";
	private static final String PARAMETER_CODE = "code";
	private static final String PARAMETER_SHOW_INACTIVE = "showInActive";
	private static final String PARAMETER_DEBUG = "debug";
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	private static final long serialVersionUID = 1L;
	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.ENGLISH);
	private static boolean debug = false;
	

	public GetSupplier() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		debug = "true".equalsIgnoreCase(request.getParameter(PARAMETER_DEBUG));
		getContents(request, response);
	}

	@SuppressWarnings({ "rawtypes" })
	private void getContents(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");		
		String id = request.getParameter(PARAMETER_ID);
		String code = request.getParameter(PARAMETER_CODE);
		String format = request.getParameter(PARAMETER_FORMAT);
		boolean showInActive = "true".equalsIgnoreCase(request.getParameter(PARAMETER_SHOW_INACTIVE));
		
		logger("debug=" + debug);
		logger("id=" + id);
		logger("code=" + code);
		logger("format=" + format);
		
		StringBuffer xml = new StringBuffer();
		xml.append("<?xml version=\"1.0\" encoding=\"utf8\" standalone=\"yes\"?>");
		xml.append("<suppliers>");		
	
		String data = id != null && id.trim().length() > 0 ? id.trim() : code;
		boolean modeIsId = id != null && id.trim().length() > 0;
		if (data != null && data.trim().length() > 0) { // id(s), number(s)
			try {
				String[] supplierIds = data.split(",");
				ArrayList<String> filterName = null;
				ArrayList<DocumentId> filterId = null;
				if (!modeIsId) { // we are passing supplier code(s).
					filterName = new ArrayList<String>();
					for (int i = 0; i < supplierIds.length; i++) {
						filterName.add(supplierIds[i]);
					}
				} else {
					filterId = new ArrayList<>();
					DocumentId tmpDocId = null;
					for (int i = 0; i < supplierIds.length; i++) {
						tmpDocId = EgovWCMCache.getWorkspace().createDocumentId(supplierIds[i]);
						if (tmpDocId != null) {
							filterId.add(tmpDocId);
						}
					}	
				}
				Query query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
				// filter by library.
				query.addSelector(Selectors.libraryEquals(EgovWCMCache.getWorkspace().getDocumentLibrary(Constants.EGOV_CONTENT_LIBRARY_NAME)));

				if (modeIsId) {
					// filter by id.				
					query.addSelector(Selectors.idIn(filterId));
				} else {
					// filter by name.				
					query.addSelector(Selectors.nameIn(filterName));					
				}

				// filter by 'Published' only.
				query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
				
				// filter by serice suppliers AT ONLY.
				query.addSelector(
						Selectors.authoringTemplateIn(
							new DocumentId[] {
								EgovWCMCache.getATServiceProviderCentralAdministration().getId(),
								EgovWCMCache.getATServiceProviderTerritorialAdministration().getId(), 					 
								EgovWCMCache.getATServiceProviderInstitutionOther().getId(),
								EgovWCMCache.getATServiceProviderArticle1Paragraph2().getId()
							}
						)
				);
				if (!showInActive) {
					// filter by category 'Active'.
				 	query.addSelector(ProfileSelectors.categoriesContains(EgovWCMCache.getCategoryCommonActive().getId()));
				}
				query.returnObjects();
				ResultIterator resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);
			    if (resultIterator.hasNext()) {
			    	Content service = null;
			    	while (resultIterator.hasNext()) {
						service = (Content) resultIterator.next();
						// Serve content data.
						xml.append(buildSupplierContentData(service, format));						
					}
			    }
			} catch (Exception e) {
				e.printStackTrace();
			}
		} 
		xml.append("</suppliers>");
		String xmlResonseString = xml.toString();
		// Replace all "/myconnect/" references.
		xmlResonseString = xmlResonseString.replaceAll("/wcm/myconnect/", "/wcm/connect/");
		if (PARAMETER_TYPE_JSON.equalsIgnoreCase(request.getParameter(PARAMETER_FORMAT))) {
			response.setContentType("application/json; charset=UTF-8");
			JSONObject xmlJSONObj = XML.toJSONObject(xmlResonseString);
			String jsonPrettyPrintString = xmlJSONObj.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			response.getWriter().print(jsonPrettyPrintString);
		} else {
			response.setContentType("text/xml; charset=UTF-8");
			response.getWriter().print(xmlResonseString);
		}
		response.getWriter().flush();
		response.getWriter().close();
	}
		
	private String buildSupplierContentData (Content content, String format) {
		if (content == null) return "";		
		Category category = null;
		StringBuffer xml = new StringBuffer();
		logger("buildSupplierContentData IN");		
		xml.append("<supplier>");
		xml.append("<id>" + encode(content.getId().getId(), format) + "</id>");
		xml.append("<code>" + encode(content.getName(), format) + "</code>");
		xml.append("<title>" + encode(content.getTitle(), format) + "</title>");
		try {
			xml.append("<eik>" + encode(getTextFromComponent(content, EgovWCMCache.SP_FIELD_EIK_NAME, format), format) + "</eik>");
			if (content.getAuthoringTemplateID().getId().equalsIgnoreCase(EgovWCMCache.getATServiceProviderTerritorialAdministration().getId().getId())
					|| content.getAuthoringTemplateID().getId().equalsIgnoreCase(EgovWCMCache.getATServiceProviderCentralAdministration().getId().getId())) {
				xml.append("<batchId>" + encode(getTextFromComponent(content, EgovWCMCache.SP_FIELD_BATCHID_NAME, format), format) + "</batchId>");
				xml.append("<identificationNumber>" + encode(getTextFromComponent(content, EgovWCMCache.SP_FIELD_IDENTIFICATION_NUMBER_NAME, format), format) + "</identificationNumber>");
				xml.append("<providerFullName>" + encode(getTextFromComponent(content, EgovWCMCache.SP_FIELD_PROVIDER_FULL_NAME_NAME, format), format) + "</providerFullName>");
				xml.append("<providerNameAr>" + encode(getTextFromComponent(content, EgovWCMCache.SP_FIELD_PROVIDER_NAME_AR_NAME, format), format) + "</providerNameAr>");
				category = getCategoryFromComponentOption(content, EgovWCMCache.SP_FIELD_ADM_STRUCTURE_KIND_NAME);
				xml.append("<admStructureKind>" + (category != null ? encode(category.getTitle(), format) : "") + "</admStructureKind>");
			}
			category = getCategoryFromComponentOption(content, EgovWCMCache.SP_FIELD_SERVICE_PROVIDER_TYPE_NAME);
			xml.append("<serviceProviderType>" + (category != null ? encode(category.getTitle(), format) : "") + "</serviceProviderType>");
			category = getCategoryFromComponentOption(content, EgovWCMCache.SP_FIELD_MAIN_CATEGORY);
			xml.append("<mainCategory>" + (category != null ? encode(category.getTitle(), format) : "") + "</mainCategory>");
			
			// For Territorial administrations.
			if (content.getAuthoringTemplateID().getId().equalsIgnoreCase(EgovWCMCache.getATServiceProviderTerritorialAdministration().getId().getId())) {
				String contentUUID = getTextFromComponent(content, EgovWCMCache.SP_FIELD_ADM_TERRITORIAL_KIND, null);
				String territorialAdministrationKindTitle = null;
				if (contentUUID != null) {
					try {
						Content territorialKind = (Content)EgovWCMCache.getWorkspace().getById(EgovWCMCache.getWorkspace().createDocumentId(contentUUID), true);
						if (territorialKind != null) {
							territorialAdministrationKindTitle = territorialKind.getTitle();
						}
					} catch (Exception e) {}					
				}
				xml.append("<admTerritorialKind>" + (territorialAdministrationKindTitle != null ? encode(territorialAdministrationKindTitle, format) : "") + "</admTerritorialKind>");
				xml.append("<customName>" + encode(getTextFromComponent(content, EgovWCMCache.SP_FIELD_CUSTOM_NAME_NAME, format), format) + "</customName>");
				xml.append("<extendGenericName>" + encode(getTextFromComponent(content, EgovWCMCache.SP_FIELD_EXTEND_GENERIC_NAME, format), format) + "</extendGenericName>");
				
			}
			
			xml.append("<providerOID>" + encode(getTextFromComponent(content, EgovWCMCache.SP_FIELD_PROVIDER_OID_NAME, format), format) + "</providerOID>");
			// For Territorial administrations.
			if (content.getAuthoringTemplateID().getId().equalsIgnoreCase(EgovWCMCache.getATServiceProviderTerritorialAdministration().getId().getId())) {
				xml.append("<nameEkatte>" + encode(getTextFromComponent(content, EgovWCMCache.SP_FIELD_NAME_EKATTE_NAME, format), format) + "</nameEkatte>");
			}
			xml.append("<addressEkatte>" + encode(getTextFromComponent(content, EgovWCMCache.SP_FIELD_ADDRESS_EKATTE_NAME, format), format) + "</addressEkatte>");
			xml.append("<address>" + encode(getTextFromComponent(content, EgovWCMCache.SP_FIELD_ADDRESS_NAME, format), format) + "</address>");
			xml.append("<postCode>" + encode(getTextFromComponent(content, EgovWCMCache.SP_FIELD_POST_CODE_NAME, format), format) + "</postCode>");
			xml.append("<url>" + encode(getTextFromComponent(content, EgovWCMCache.SP_FIELD_URL_NAME, format), format) + "</url>");
			xml.append("<contacts>" + encode(getTextFromComponent(content, EgovWCMCache.SP_FIELD_CONTACTS_NAME, format), format) + "</contacts>");
			xml.append("<workingTime>" + encode(getTextFromComponent(content, EgovWCMCache.SP_FIELD_WORKING_TIME_NAME, format), format) + "</workingTime>");
			xml.append("<procedureRules>" + encode(getTextFromComponent(content, EgovWCMCache.SP_FIELD_PROCEDURE_RULES_NAME, format), format) + "</procedureRules>");
			xml.append("<urlArOrganigram>" + encode(getTextFromComponent(content, EgovWCMCache.SP_FIELD_URL_AR_ORGANIGRAM_NAME, format), format) + "</urlArOrganigram>");
			xml.append("<providerResponsibilities>" + encode(getTextFromComponent(content, EgovWCMCache.SP_FIELD_PROVIDER_RESPONSIBILITIES_NAME, format), format) + "</providerResponsibilities>");
			xml.append("<providerDescription>" + encode(getTextFromComponent(content, EgovWCMCache.SP_FIELD_PROVIDER_DESCRIPTION_NAME, format), format) + "</providerDescription>");
			xml.append("<logo>" + encode(geImageUrlFromComponent(content, EgovWCMCache.SP_FIELD_LOGO_NAME, format), format) + "</logo>");
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			Date date = content.getModifiedDate();		
			if (date != null) {
				xml.append("<modifiedDate>" + encode(dateFormat.format(date), format) + "</modifiedDate>");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		xml.append("</supplier>");
		category = null;
		logger("buildSupplierContentData OUT");
		return xml.toString();
	}
	
	private boolean hasComponent(Content content, String elementName) {
		for (int i = 0; i < content.getComponentNames().length; i++) {
			if (content.getComponentNames()[i].equals(elementName))
				return true;
		}
		return false;
	}
	
	private String getTextFromComponent(Content content, String componentName, String format) {
		try {
			if (hasComponent(content, componentName)) {
				ContentComponent contentComponent = content.getComponentByReference(componentName);
				String text = "";
				if (contentComponent instanceof ShortTextComponent) {
					text = ((ShortTextComponent)contentComponent).getText();
				} else if (contentComponent instanceof TextComponent) {
					text = ((TextComponent)contentComponent).getText();
				} else if (contentComponent instanceof RichTextComponent) {
					text = ((RichTextComponent)contentComponent).getRichText();
				}
				return (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ? HtmlConverter.escape(text) : text;
			}
		} catch (ComponentNotFoundException e) {
			e.printStackTrace();
		}
		return "";
	}
	
	private String geImageUrlFromComponent(Content content, String componentName, String format) {
		try {
			if (hasComponent(content, componentName)) {
				ContentComponent contentComponent = content.getComponentByReference(componentName);
				if (contentComponent instanceof ImageComponent) {
					String resourceURL = ((ImageComponent)contentComponent).getResourceURL();
					if (resourceURL != null && resourceURL.trim().length() > 0) {
						boolean isProd = "PROD".equalsIgnoreCase(System.getProperty("environment"));
						return (isProd ? "https://egov.bg" : "https://staging.egov.bg") + resourceURL;
					}
				}
			}
		} catch (ComponentNotFoundException e) {
			e.printStackTrace();
		}
		return "";
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Category getCategoryFromComponentOption(Content content, String componentName) {
		try {
			if (hasComponent(content, componentName)) {
				OptionSelectionComponent contentComponent = (OptionSelectionComponent)content.getComponentByReference(componentName);
				DocumentId[] documentIds = contentComponent.getCategorySelections();
				if (documentIds != null && documentIds.length > 0) {
					return (Category)EgovWCMCache.getWorkspace().getById(documentIds[0]);				
				}			
			}
		} catch (Exception e) {
			if (content != null) {
				System.err.println("error (componentName = " + componentName + "): content id=" + content.getId() + ", name=" + content.getName());
			}
			e.printStackTrace();
		}
		return null;
	}
	
	private String encode(String string, String format) {
		return (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ? (string != null) ? string : "" : "<![CDATA[" + ((string != null) ? string : "") + "]]>";
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	private void logger(String string) {		
		if (debug) {
			System.out.println(string);
		}
	}
}
