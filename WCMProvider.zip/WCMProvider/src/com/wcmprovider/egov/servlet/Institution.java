package com.wcmprovider.egov.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.json.XML;

import com.egov.wcm.cache.EgovServiceProvider;
import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.query.ProfileSelectors;
import com.ibm.workplace.wcm.api.query.Query;
import com.ibm.workplace.wcm.api.query.ResultIterator;
import com.ibm.workplace.wcm.api.query.Selectors;
import com.ibm.workplace.wcm.api.query.WorkflowSelectors;
import com.wcmprovider.egov.Constants;

@WebServlet("/institution")
public class Institution extends HttpServlet {
	private static final String INSTITUTIONS_AT_ID = "a635b8aa-e2de-43f1-ab87-52bd350943a6";	
	@SuppressWarnings("rawtypes")
	private static DocumentId INSTITUTIONS_AT = null;
	private static final String PARAMETER_FORMAT = "format";
	private static final String PARAMETER_TYPE_JSON = "json";
	private static final String PARAMETER_ID = "id";
	private static final String PARAMETER_TYPE = "type";
	private static final String PARAMETER_RENDER = "render";
	private static final String PARAMETER_CONTENT = "content";
	private static final String PARAMETER_DEBUG = "debug";
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	private static final long serialVersionUID = 1L;
	private static boolean debug = false;

	public Institution() {
		super();
		// TODO remove this call.		
		loadPrerequisites();
	}
	
	// TODO remove this function.	
	@SuppressWarnings({ "rawtypes" })
	private void loadPrerequisites() {
		try {
			if (INSTITUTIONS_AT == null) {
				DocumentId institutionId = EgovWCMCache.getWorkspace().createDocumentId(INSTITUTIONS_AT_ID);
				if (institutionId != null) {
					INSTITUTIONS_AT = institutionId; 
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO remove that call.
		loadPrerequisites();
		serveContent(request, response);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void serveContent(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");		
		String id = request.getParameter(PARAMETER_ID);
		String format = request.getParameter(PARAMETER_FORMAT);
		String type = request.getParameter(PARAMETER_TYPE);
		String render = request.getParameter(PARAMETER_RENDER);
		boolean loadContent = "true".equalsIgnoreCase(request.getParameter(PARAMETER_CONTENT));
		debug = "true".equalsIgnoreCase(request.getParameter(PARAMETER_DEBUG));
		
		logger(PARAMETER_ID + "=" + id);
		logger(PARAMETER_FORMAT + "=" + format);
		logger(PARAMETER_TYPE + "=" + type);
		logger(PARAMETER_RENDER + "=" + render);
		logger(PARAMETER_CONTENT + "=" + loadContent);
		String mode = "eform";
		
		StringBuffer xml = new StringBuffer();
		xml.append("<?xml version=\"1.0\" encoding=\"utf8\" standalone=\"yes\"?>");
		xml.append("<institutions>");
		try {
			// Load it from cache.
			List<EgovServiceProvider> serviceProviders = EgovWCMCache.getServiceProviders();
			if (serviceProviders != null && serviceProviders.size() > 0) {
				EgovServiceProvider serviceProvider;
				String spName = null;
				String path = null;
				boolean replacedRegion = false;
				boolean replacedMunicpality = false;
				boolean replacedRegionalnoUpravlenieNaObrazovanieto = false;
				boolean replacedRegionalnaZdravnaInspektsia = false;
				boolean replacedBaseinovaDirektsia = false;
				boolean replacedRegionalnaInspektsiaPoOkolnaSredaIVodite = false;
				boolean replacedOblastnaDirektsiaZemedelie = false;
				boolean replacedRegionalnaDirektsiaPoGorite = false;
				boolean replacedDirektsiaNacionalenPark = false;

				boolean replacedA1P2Universiteti= false;
				for (int i = 0; i < serviceProviders.size(); i++) {
					serviceProvider = serviceProviders.get(i);
					if ("eform".equalsIgnoreCase(mode)) {
						path = serviceProvider.getContentPath();
						logger("path=" + path);
						if (path.indexOf("/oblastni administratsii/") != -1) {
							if (!replacedRegion) {
								replacedRegion = true;
								xml.append("<institution>");
								xml.append("<id>" + encode(Constants.SERVICE_PROVIDER_REGION_ID, format) + "</id>");
								xml.append("<institutionOID>" + encode(Constants.SERVICE_PROVIDER_REGION_OID, format) + "</institutionOID>");
								xml.append("<title>" + encode(Constants.SERVICE_PROVIDER_REGION_TITLE, format) + "</title>");						
								xml.append("</institution>");
							}
							continue;
						} else if (path.indexOf("/obshtinski administratsii/") != -1 || path.indexOf("/obshtinski administratsii na rayoni/") != -1) {
							if (!replacedMunicpality) {
								replacedMunicpality = true;
								xml.append("<institution>");
								xml.append("<id>" + encode(Constants.SERVICE_PROVIDER_MUNICIPALITY_ID, format) + "</id>");
								xml.append("<institutionOID>" + encode(Constants.SERVICE_PROVIDER_MUNICIPALITY_OID, format) + "</institutionOID>");
								xml.append("<title>" + encode(Constants.SERVICE_PROVIDER_MUNICIPALITY_TITLE, format) + "</title>");						
								xml.append("</institution>");
							}
							continue;
						} else if (path.indexOf("/spetsializirani teritorialni administratsii/baseynova direktsia/") != -1) {
							if (!replacedBaseinovaDirektsia) {
								replacedBaseinovaDirektsia = true;
								xml.append("<institution>");
								xml.append("<id>" + encode(Constants.SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_ID, format) + "</id>");
								xml.append("<institutionOID>" + encode(Constants.SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_OID, format) + "</institutionOID>");
								xml.append("<title>" + encode(Constants.SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_TITLE, format) + "</title>");							
								xml.append("</institution>");
							}
							continue;
						} else if (path.indexOf("/spetsializirani teritorialni administratsii/regionalno upravlenie na obrazovanieto/") != -1) {
							if (!replacedRegionalnoUpravlenieNaObrazovanieto) {
								replacedRegionalnoUpravlenieNaObrazovanieto = true;
								xml.append("<institution>");
								xml.append("<id>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_ID, format) + "</id>");
								xml.append("<institutionOID>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_OID, format) + "</institutionOID>");
								xml.append("<title>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_TITLE, format) + "</title>");							
								xml.append("</institution>");
							}
							continue;
						} else if (path.indexOf("/spetsializirani teritorialni administratsii/regionalna zdravna inspektsia/") != -1) {
							if (!replacedRegionalnaZdravnaInspektsia) {
								replacedRegionalnaZdravnaInspektsia = true;
								xml.append("<institution>");
								xml.append("<id>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_ID, format) + "</id>");
								xml.append("<institutionOID>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_OID, format) + "</institutionOID>");
								xml.append("<title>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_TITLE, format) + "</title>");							
								xml.append("</institution>");
							}
							continue;
						} else if (path.indexOf("/spetsializirani teritorialni administratsii/regionalna inspektsia po okolna sreda i vodite/") != -1) {
							if (!replacedRegionalnaInspektsiaPoOkolnaSredaIVodite) {
								replacedRegionalnaInspektsiaPoOkolnaSredaIVodite = true;
								xml.append("<institution>");
								xml.append("<id>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_ID, format) + "</id>");
								xml.append("<institutionOID>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_OID, format) + "</institutionOID>");
								xml.append("<title>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_TITLE, format) + "</title>");							
								xml.append("</institution>");
							}
							continue;
						} else if (path.indexOf("/spetsializirani teritorialni administratsii/oblastna direktsia zemedelie/") != -1) {
							if (!replacedOblastnaDirektsiaZemedelie) {
								replacedOblastnaDirektsiaZemedelie = true;
								xml.append("<institution>");
								xml.append("<id>" + encode(Constants.SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_ID, format) + "</id>");
								xml.append("<institutionOID>" + encode(Constants.SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_OID, format) + "</institutionOID>");
								xml.append("<title>" + encode(Constants.SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_TITLE, format) + "</title>");							
								xml.append("</institution>");
							}
							continue;
						} else if (path.indexOf("/spetsializirani teritorialni administratsii/regionalna direktsia po gorite/") != -1) {
							if (!replacedRegionalnaDirektsiaPoGorite) {
								replacedRegionalnaDirektsiaPoGorite = true;
								xml.append("<institution>");
								xml.append("<id>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_ID, format) + "</id>");
								xml.append("<institutionOID>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_OID, format) + "</institutionOID>");
								xml.append("<title>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_TITLE, format) + "</title>");							
								xml.append("</institution>");
							}
							continue;
						} else if (path.indexOf("/spetsializirani teritorialni administratsii/direktsia natsionalen park/") != -1) {
							if (!replacedDirektsiaNacionalenPark) {
								replacedDirektsiaNacionalenPark = true;
								xml.append("<institution>");
								xml.append("<id>" + encode(Constants.SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_ID, format) + "</id>");
								xml.append("<institutionOID>" + encode(Constants.SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_OID, format) + "</institutionOID>");
								xml.append("<title>" + encode(Constants.SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_TITLE, format) + "</title>");							
								xml.append("</institution>");
							}
							continue;
						} else if (path.indexOf("/spetsializirani teritorialni administratsii/") != -1) {
							logger("SKIP path=" + path);
							continue;
						} else if (path.indexOf("/organizatsii i litsa, predostavyashti obshtestveni uslugi/universiteti/") != -1) {
							if (!replacedA1P2Universiteti) {
								replacedA1P2Universiteti = true;
								xml.append("<institution>");
								xml.append("<id>" + encode(Constants.SERVICE_PROVIDER_A1_P2_UNIVERSITETI_ID, format) + "</id>");
								xml.append("<institutionOID>" + encode(Constants.SERVICE_PROVIDER_A1_P2_UNIVERSITETI_OID, format) + "</institutionOID>");
								xml.append("<title>" + encode(Constants.SERVICE_PROVIDER_A1_P2_UNIVERSITETI_TITLE, format) + "</title>");							
								xml.append("</institution>");
							}
							continue;
						} 
					}
					spName = serviceProvider.getName();
					if ("1377".equals(serviceProvider.getName())) {
						spName = Constants.SERVICE_PROVIDER_E_MEDIA_CONCIL_OID;
					}
					xml.append("<institution>");
					xml.append("<id>" + encode(serviceProvider.getId(), format) + "</id>");
					xml.append("<institutionOID>" + encode(spName, format) + "</institutionOID>");
					xml.append("<title>" + encode(serviceProvider.getTitle(), format) + "</title>");						
					xml.append("</institution>");
				}
			} else {
				Query query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
				// filter by library.
				query.addSelector(Selectors.libraryEquals(EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)));
				// filter by serviceProvider ATs ONLY.
			 	query.addSelector(
						Selectors.authoringTemplateIn(
							new DocumentId[] {
								EgovWCMCache.getATServiceProviderCentralAdministration().getId(),
								EgovWCMCache.getATServiceProviderTerritorialAdministration().getId(),
								EgovWCMCache.getATServiceProviderInstitutionOther().getId(),
								EgovWCMCache.getATServiceProviderArticle1Paragraph2().getId()
							}
						)
				);
			 	// filter by category 'Active'.
			 	query.addSelector(ProfileSelectors.categoriesContains(EgovWCMCache.getCategoryCommonActive().getId()));
				// filter by published.
				query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
				query.returnObjects();
				ResultIterator resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);			     
				if (resultIterator.hasNext()) {
					logger("Institution :  -> serveContent() query has result!");
					Content serviceProvider = null;
					String path = null;
					boolean replacedRegion = false;
					boolean replacedMunicpality = false;
					boolean replacedRegionalnoUpravlenieNaObrazovanieto = false;
					boolean replacedRegionalnaZdravnaInspektsia = false;
					boolean replacedBaseinovaDirektsia = false;
					boolean replacedRegionalnaInspektsiaPoOkolnaSredaIVodite = false;
					boolean replacedOblastnaDirektsiaZemedelie = false;
					boolean replacedRegionalnaDirektsiaPoGorite = false;
					boolean replacedDirektsiaNacionalenPark = false;
					boolean replacedA1P2Universiteti = false;
					while (resultIterator.hasNext()) {
						serviceProvider = (Content) resultIterator.next();
						if (serviceProvider != null) {
							if ("eform".equalsIgnoreCase(mode)) {
								path = EgovWCMCache.getWorkspace().getPathById(serviceProvider.getId(), false, true);
								if (path.indexOf("/oblastni administratsii/") != -1) {
									if (!replacedRegion) {
										replacedRegion = true;
										xml.append("<institution>");
										xml.append("<id>" + encode(Constants.SERVICE_PROVIDER_REGION_ID, format) + "</id>");
										xml.append("<institutionOID>" + encode(Constants.SERVICE_PROVIDER_REGION_OID, format) + "</institutionOID>");
										xml.append("<title>" + encode(Constants.SERVICE_PROVIDER_REGION_TITLE, format) + "</title>");						
										xml.append("</institution>");
									}
									continue;
								} else if (path.indexOf("/obshtinski administratsii/") != -1) {
									if (!replacedMunicpality) {
										replacedMunicpality = true;
										xml.append("<institution>");
										xml.append("<id>" + encode(Constants.SERVICE_PROVIDER_MUNICIPALITY_ID, format) + "</id>");
										xml.append("<institutionOID>" + encode(Constants.SERVICE_PROVIDER_MUNICIPALITY_OID, format) + "</institutionOID>");
										xml.append("<title>" + encode(Constants.SERVICE_PROVIDER_MUNICIPALITY_TITLE, format) + "</title>");						
										xml.append("</institution>");
									}
									continue;
								} else if (path.indexOf("/spetsializirani teritorialni administratsii/baseynova direktsia/") != -1) {
									if (!replacedBaseinovaDirektsia) {
										replacedBaseinovaDirektsia = true;
										xml.append("<institution>");
										xml.append("<id>" + encode(Constants.SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_ID, format) + "</id>");
										xml.append("<institutionOID>" + encode(Constants.SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_OID, format) + "</institutionOID>");
										xml.append("<title>" + encode(Constants.SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_TITLE, format) + "</title>");							
										xml.append("</institution>");
									}
									continue;
								} else if (path.indexOf("/spetsializirani teritorialni administratsii/regionalno upravlenie na obrazovanieto/") != -1) {
									if (!replacedRegionalnoUpravlenieNaObrazovanieto) {
										replacedRegionalnoUpravlenieNaObrazovanieto = true;
										xml.append("<institution>");
										xml.append("<id>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_ID, format) + "</id>");
										xml.append("<institutionOID>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_OID, format) + "</institutionOID>");
										xml.append("<title>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_TITLE, format) + "</title>");							
										xml.append("</institution>");
									}
									continue;
								} else if (path.indexOf("/spetsializirani teritorialni administratsii/regionalna zdravna inspektsia/") != -1) {
									if (!replacedRegionalnaZdravnaInspektsia) {
										replacedRegionalnaZdravnaInspektsia = true;
										xml.append("<institution>");
										xml.append("<id>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_ID, format) + "</id>");
										xml.append("<institutionOID>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_OID, format) + "</institutionOID>");
										xml.append("<title>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_TITLE, format) + "</title>");							
										xml.append("</institution>");
									}
									continue;
								} else if (path.indexOf("/spetsializirani teritorialni administratsii/regionalna inspektsia po okolna sreda i vodite/") != -1) {
									if (!replacedRegionalnaInspektsiaPoOkolnaSredaIVodite) {
										replacedRegionalnaInspektsiaPoOkolnaSredaIVodite = true;
										xml.append("<institution>");
										xml.append("<id>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_ID, format) + "</id>");
										xml.append("<institutionOID>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_OID, format) + "</institutionOID>");
										xml.append("<title>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_TITLE, format) + "</title>");							
										xml.append("</institution>");
									}
									continue;
								} else if (path.indexOf("/spetsializirani teritorialni administratsii/oblastna direktsia zemedelie/") != -1) {
									if (!replacedOblastnaDirektsiaZemedelie) {
										replacedOblastnaDirektsiaZemedelie = true;
										xml.append("<institution>");
										xml.append("<id>" + encode(Constants.SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_ID, format) + "</id>");
										xml.append("<institutionOID>" + encode(Constants.SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_OID, format) + "</institutionOID>");
										xml.append("<title>" + encode(Constants.SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_TITLE, format) + "</title>");							
										xml.append("</institution>");
									}
									continue;
								} else if (path.indexOf("/spetsializirani teritorialni administratsii/regionalna direktsia po gorite/") != -1) {
									if (!replacedRegionalnaDirektsiaPoGorite) {
										replacedRegionalnaDirektsiaPoGorite = true;
										xml.append("<institution>");
										xml.append("<id>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_ID, format) + "</id>");
										xml.append("<institutionOID>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_OID, format) + "</institutionOID>");
										xml.append("<title>" + encode(Constants.SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_TITLE, format) + "</title>");							
										xml.append("</institution>");
									}
									continue;									
								} else if (path.indexOf("/spetsializirani teritorialni administratsii/direktsia natsionalen park/") != -1) {
									if (!replacedDirektsiaNacionalenPark) {
										replacedDirektsiaNacionalenPark = true;
										xml.append("<institution>");
										xml.append("<id>" + encode(Constants.SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_ID, format) + "</id>");
										xml.append("<institutionOID>" + encode(Constants.SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_OID, format) + "</institutionOID>");
										xml.append("<title>" + encode(Constants.SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_TITLE, format) + "</title>");							
										xml.append("</institution>");
									}
									continue;									
								} else if (path.indexOf("/spetsializirani teritorialni administratsii/") != -1) {
									logger("SKIP path=" + path);
									continue;
								} else if (path.indexOf("/organizatsii i litsa, predostavyashti obshtestveni uslugi/universiteti/") != -1) {
									if (!replacedA1P2Universiteti) {
										replacedA1P2Universiteti = true;
										xml.append("<institution>");
										xml.append("<id>" + encode(Constants.SERVICE_PROVIDER_A1_P2_UNIVERSITETI_ID, format) + "</id>");
										xml.append("<institutionOID>" + encode(Constants.SERVICE_PROVIDER_A1_P2_UNIVERSITETI_OID, format) + "</institutionOID>");
										xml.append("<title>" + encode(Constants.SERVICE_PROVIDER_A1_P2_UNIVERSITETI_ID, format) + "</title>");							
										xml.append("</institution>");
									}
									continue;									
								} 
								System.out.println("path=" + path);
							}
							if ("1377".equals(serviceProvider.getName())) {
								serviceProvider.setName(Constants.SERVICE_PROVIDER_E_MEDIA_CONCIL_OID);
							}
							xml.append("<institution>");
							xml.append("<id>" + encode(serviceProvider.getId().getId(), format) + "</id>");
							xml.append("<institutionOID>" + encode(serviceProvider.getName(), format) + "</institutionOID>");
							xml.append("<title>" + encode(serviceProvider.getTitle(), format) + "</title>");						
							xml.append("</institution>");
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		xml.append("</institutions>");
		if (PARAMETER_TYPE_JSON.equalsIgnoreCase(request.getParameter(PARAMETER_FORMAT))) {
			response.setContentType("application/json; charset=UTF-8");
			logger(xml.toString());
			JSONObject xmlJSONObj = XML.toJSONObject(xml.toString());
			String jsonPrettyPrintString = xmlJSONObj.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			response.getWriter().print(jsonPrettyPrintString);
		} else {
			response.setContentType("text/xml; charset=UTF-8");
			response.getWriter().print(xml.toString());
		}
		response.getWriter().flush();
		response.getWriter().close();
	}
	
	private String encode(String string, String format) {
		return (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ? (string != null) ? string : "" : "<![CDATA[" + ((string != null) ? string : "") + "]]>";
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private void logger(String string) {
		if (debug) {
			System.out.println(string);
		}
	}

}
