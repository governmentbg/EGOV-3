package com.wcmprovider.egov.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.json.XML;

import com.egov.wcm.cache.EgovServiceProvider;
import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.ContentComponent;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.RichTextComponent;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.TextComponent;
import com.ibm.workplace.wcm.api.exceptions.ComponentNotFoundException;
import com.ibm.workplace.wcm.api.query.ProfileSelectors;
import com.ibm.workplace.wcm.api.query.Query;
import com.ibm.workplace.wcm.api.query.ResultIterator;
import com.ibm.workplace.wcm.api.query.Selectors;
import com.ibm.workplace.wcm.api.query.WorkflowSelectors;
import com.wcmprovider.egov.util.HtmlConverter;

@WebServlet("/suppliers")
public class Suppliers extends HttpServlet {
	private static final String PARAMETER_FORMAT = "format";
	private static final String PARAMETER_MODE = "mode";
	private static final String PARAMETER_MODE_CPSV_AP = "cpsv-ap";
	private static final String PARAMETER_TYPE_JSON = "json";
	private static final String PARAMETER_ID = "id";
	private static final String PARAMETER_CODE = "code";
	private static final String PARAMETER_DEBUG = "debug";
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	private static final long serialVersionUID = 1L;
	private boolean debug = false;
	private boolean isCPSVCall = false;

	public Suppliers() {
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		serveContent(request, response);
	}

	@SuppressWarnings({ "rawtypes" })
	private void serveContent(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");		
		String id = request.getParameter(PARAMETER_ID);
		String code = request.getParameter(PARAMETER_CODE);
		String format = request.getParameter(PARAMETER_FORMAT);
		debug = "true".equalsIgnoreCase(request.getParameter(PARAMETER_DEBUG));
		isCPSVCall = PARAMETER_MODE_CPSV_AP.equalsIgnoreCase(request.getParameter(PARAMETER_MODE));
		
		logger(PARAMETER_ID + "=" + id);
		logger(PARAMETER_FORMAT + "=" + format);
		
		StringBuffer xml = new StringBuffer();
		xml.append("<?xml version=\"1.0\" encoding=\"utf8\" standalone=\"yes\"?>");
		if (isCPSVCall) {
			xml.append("<PublicOrganizations>");
		} else {
			xml.append("<suppliers>");
		}
		try {
			// Load it from cache.
			List<EgovServiceProvider> serviceProviders = EgovWCMCache.getServiceProviders();
			if (serviceProviders != null && serviceProviders.size() > 0) {
				EgovServiceProvider serviceProvider;
				for (int i = 0; i < serviceProviders.size(); i++) {
					if (id != null && id.trim().length() > 0 && !id.equalsIgnoreCase(serviceProviders.get(i).getId())) {
						continue;
					} else if (code != null && code.trim().length() > 0 && !code.equalsIgnoreCase(serviceProviders.get(i).getName())) {
						continue;
					}
					serviceProvider = serviceProviders.get(i);
					if (isCPSVCall) {
						xml.append("<PublicOrganization>");
						xml.append("<preferredLabel>" + encode(serviceProvider.getTitle(), format) + "</preferredLabel>");
						xml.append("<spatial>" + encode(serviceProvider.getAddressEkatte(), format) + "</spatial>");
						xml.append("</PublicOrganization>");
					} else {
						xml.append("<supplier>");
						xml.append("<id>" + encode(serviceProvider.getId(), format) + "</id>");
						xml.append("<code>" + encode(serviceProvider.getName(), format) + "</code>");
						xml.append("<title>" + encode(serviceProvider.getTitle(), format) + "</title>");						
						xml.append("<eik>" + encode(serviceProvider.getEik(), format) + "</eik>");						
						xml.append("</supplier>");
					}
					if ((id != null && id.trim().length() > 0) || (code != null && code.trim().length() > 0)) {
						break;
					} 
				}
			} else {
				Query query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
				// filter by library.
				query.addSelector(Selectors.libraryEquals(EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)));
				// filter by serviceProvider ATs ONLY.
			 	query.addSelector(
						Selectors.authoringTemplateIn(
							new DocumentId[] {
								EgovWCMCache.getATServiceProviderCentralAdministration().getId(),
								EgovWCMCache.getATServiceProviderTerritorialAdministration().getId(),
								EgovWCMCache.getATServiceProviderInstitutionOther().getId(),
								EgovWCMCache.getATServiceProviderArticle1Paragraph2().getId()
							}
						)
				);
			 	if (id != null && id.trim().length() > 0) {
			 		// filter by id.
			 		query.addSelector(Selectors.idEquals(EgovWCMCache.getWorkspace().createDocumentId(id)));
			 	} else if (code != null && code.trim().length() > 0) {
			 		// filter by name.
			 		query.addSelector(Selectors.nameEquals(code));
			 	} 
			 	// filter by category 'Active'.
			 	query.addSelector(ProfileSelectors.categoriesContains(EgovWCMCache.getCategoryCommonActive().getId()));
				// filter by published.
				query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
				query.returnObjects();
				ResultIterator resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);			     
				if (resultIterator.hasNext()) {
					logger("supplier :  -> serveContent() query has result!");
					Content serviceProvider = null;
					while (resultIterator.hasNext()) {
						serviceProvider = (Content) resultIterator.next();
						if (serviceProvider != null) {
							if (isCPSVCall) {
								xml.append("<PublicOrganization>");
								xml.append("<preferredLabel>" + encode(serviceProvider.getTitle(), format) + "</preferredLabel>");
								xml.append("<spatial>" + encode(getTextFromComponent(serviceProvider, EgovWCMCache.SP_FIELD_ADDRESS_EKATTE_NAME, format), format) + "</spatial>");
								xml.append("</PublicOrganization>");
							} else {
								xml.append("<supplier>");
								xml.append("<id>" + encode(serviceProvider.getId().getId(), format) + "</id>");
								xml.append("<code>" + encode(serviceProvider.getName(), format) + "</code>");
								xml.append("<title>" + encode(serviceProvider.getTitle(), format) + "</title>");						
								xml.append("<eik>" + encode(getTextFromComponent(serviceProvider, EgovWCMCache.SP_FIELD_EIK_NAME, format), format) + "</eik>");						
								xml.append("</supplier>");
							}
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		if (isCPSVCall) {
			xml.append("</PublicOrganizations>");
		} else {
			xml.append("</suppliers>");
		}
		if (PARAMETER_TYPE_JSON.equalsIgnoreCase(request.getParameter(PARAMETER_FORMAT))) {
			response.setContentType("application/json; charset=UTF-8");
			logger(xml.toString());
			JSONObject xmlJSONObj = XML.toJSONObject(xml.toString());
			String jsonPrettyPrintString = xmlJSONObj.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			response.getWriter().print(jsonPrettyPrintString);
		} else {
			response.setContentType("text/xml; charset=UTF-8");
			response.getWriter().print(xml.toString());
		}
		response.getWriter().flush();
		response.getWriter().close();
	}
	
	private boolean hasComponent(Content content, String elementName) {
		for (int i = 0; i < content.getComponentNames().length; i++) {
			if (content.getComponentNames()[i].equals(elementName))
				return true;
		}
		return false;
	}
	
	private String getTextFromComponent(Content content, String componentName, String format) {
		try {
			if (hasComponent(content, componentName)) {
				ContentComponent contentComponent = content.getComponentByReference(componentName);
				if (contentComponent instanceof ShortTextComponent) {
					return ((ShortTextComponent)contentComponent).getText();
				} else if (contentComponent instanceof TextComponent) {
					return ((TextComponent)contentComponent).getText();
				} else if (contentComponent instanceof RichTextComponent) {
					if (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) {
						return HtmlConverter.escape(((RichTextComponent)contentComponent).getRichText());				
					}
					return ((RichTextComponent)contentComponent).getRichText();
				}
			}
		} catch (ComponentNotFoundException e) {
			e.printStackTrace();
		}
		return "";
	}


	private String encode(String string, String format) {
		return (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ? (string != null) ? string : "" : "<![CDATA[" + ((string != null) ? string : "") + "]]>";
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private void logger(String string) {
		if (debug) {
			System.out.println(string);
		}
	}

}
