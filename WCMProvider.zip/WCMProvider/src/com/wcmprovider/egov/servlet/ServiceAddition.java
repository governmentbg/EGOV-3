package com.wcmprovider.egov.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.json.XML;

import com.egov.wcm.cache.EgovService;
import com.egov.wcm.cache.EgovServiceProvider;
import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.Category;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.ContentComponent;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentTypes;
import com.ibm.workplace.wcm.api.FileComponent;
import com.ibm.workplace.wcm.api.LinkComponent;
import com.ibm.workplace.wcm.api.OptionSelectionComponent;
import com.ibm.workplace.wcm.api.RichTextComponent;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.SiteArea;
import com.ibm.workplace.wcm.api.TextComponent;
import com.ibm.workplace.wcm.api.Workspace;
import com.ibm.workplace.wcm.api.exceptions.ComponentNotFoundException;
import com.ibm.workplace.wcm.api.query.ProfileSelectors;
import com.ibm.workplace.wcm.api.query.Query;
import com.ibm.workplace.wcm.api.query.QueryService;
import com.ibm.workplace.wcm.api.query.ResultIterator;
import com.ibm.workplace.wcm.api.query.Selectors;
import com.ibm.workplace.wcm.api.query.WorkflowSelectors;
import com.wcmprovider.egov.Constants;
import com.wcmprovider.egov.EgovWCMCacheLoaderManagement;
import com.wcmprovider.egov.util.HtmlConverter;

@WebServlet("/service-addition")
public class ServiceAddition extends HttpServlet {
	private static final String PARAMETER_FORMAT = "format";
	private static final String PARAMETER_TYPE_JSON = "json";
	private static final String PARAMETER_ID = "arId";	
	private static final String PARAMETER_INSTITUTION_OID = "institutionOID";
	private static final String PARAMETER_KEYWORD = "keyword";
	private static final String PARAMETER_DEBUG = "debug";	 
	private static final String PARAMETER_DEBUG_OUTPUT = "debugOutput";	 
	
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	private static final String URL_PREFIX = "https://egov.bg";
	private static final long serialVersionUID = 1L;
	private static boolean debug = false;
	private static String debugOutput = "out";

	public ServiceAddition() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		debug = "true".equalsIgnoreCase(request.getParameter(PARAMETER_DEBUG));		
		debugOutput = "err".equalsIgnoreCase(request.getParameter(PARAMETER_DEBUG_OUTPUT)) ? "err" : "out";
		serveContent(request, response);
	}

	@SuppressWarnings({ "rawtypes", "unchecked"})
	private void serveContent(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");		
		String id = request.getParameter(PARAMETER_ID);		
		String format = request.getParameter(PARAMETER_FORMAT);
		String institutionOID = request.getParameter(PARAMETER_INSTITUTION_OID);	
		String keyword = request.getParameter(PARAMETER_KEYWORD);
		long time = System.currentTimeMillis();
			
		logger(PARAMETER_ID + "=" + id);
		logger(PARAMETER_FORMAT + "=" + format);	
		logger(PARAMETER_INSTITUTION_OID + "=" + institutionOID);
		logger(PARAMETER_KEYWORD + "=" + keyword);
		
		StringBuffer xml = new StringBuffer();
		xml.append("<?xml version=\"1.0\" encoding=\"utf8\" standalone=\"yes\"?>");
		xml.append("<serviceAddition>");
		if (id != null && id.trim().length() > 0
				&& institutionOID != null && institutionOID.trim().length() > 0) {								
			Query query = null;
			ResultIterator resultIterator = null;
			EgovService egovService = null;
			boolean serviceProviderLoaded = false;
			// Load service by name (arId).
			try {
				// Handle hard-coded service providers OIDs.
				if (Constants.SERVICE_PROVIDER_REGION_OID.equalsIgnoreCase(institutionOID) 
						|| Constants.SERVICE_PROVIDER_MUNICIPALITY_OID.equalsIgnoreCase(institutionOID)) {
					EgovServiceProvider serviceProvider = new EgovServiceProvider();
					if (Constants.SERVICE_PROVIDER_REGION_OID.equalsIgnoreCase(institutionOID)) {
						serviceProvider.setId(Constants.SERVICE_PROVIDER_REGION_ID);
						serviceProvider.setOid(Constants.SERVICE_PROVIDER_REGION_OID);
						serviceProvider.setName(Constants.SERVICE_PROVIDER_REGION_ID);
						serviceProvider.setTitle(Constants.SERVICE_PROVIDER_REGION_TITLE);
					} else {
						serviceProvider.setId(Constants.SERVICE_PROVIDER_MUNICIPALITY_ID);
						serviceProvider.setOid(Constants.SERVICE_PROVIDER_MUNICIPALITY_OID);
						serviceProvider.setName(Constants.SERVICE_PROVIDER_MUNICIPALITY_ID);
						serviceProvider.setTitle(Constants.SERVICE_PROVIDER_MUNICIPALITY_TITLE);
					}
					xml.append(buildServiceProviderData(serviceProvider, format));
					serviceProviderLoaded = true;
				} else if (Constants.SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_OID.equalsIgnoreCase(institutionOID) 
						|| Constants.SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_OID.equalsIgnoreCase(institutionOID)
						|| Constants.SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_OID.equalsIgnoreCase(institutionOID)
						|| Constants.SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_OID.equalsIgnoreCase(institutionOID)
						|| Constants.SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_OID.equalsIgnoreCase(institutionOID)
						|| Constants.SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_OID.equalsIgnoreCase(institutionOID) 
						|| Constants.SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_OID.equalsIgnoreCase(institutionOID)) {
					EgovServiceProvider serviceProvider = new EgovServiceProvider();
					if (Constants.SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_OID.equalsIgnoreCase(institutionOID)) {
						serviceProvider.setId(Constants.SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_ID);
						serviceProvider.setOid(Constants.SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_OID);
						serviceProvider.setName(Constants.SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_ID);
						serviceProvider.setTitle(Constants.SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_TITLE);
					} else if (Constants.SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_OID.equalsIgnoreCase(institutionOID)) {
						serviceProvider.setId(Constants.SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_ID);
						serviceProvider.setOid(Constants.SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_OID);
						serviceProvider.setName(Constants.SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_ID);
						serviceProvider.setTitle(Constants.SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_TITLE);
					} else if (Constants.SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_OID.equalsIgnoreCase(institutionOID)) {
						serviceProvider.setId(Constants.SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_ID);
						serviceProvider.setOid(Constants.SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_OID);
						serviceProvider.setName(Constants.SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_ID);
						serviceProvider.setTitle(Constants.SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_TITLE);
					} else if (Constants.SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_OID.equalsIgnoreCase(institutionOID)) {
						serviceProvider.setId(Constants.SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_ID);
						serviceProvider.setOid(Constants.SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_OID);
						serviceProvider.setName(Constants.SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_ID);
						serviceProvider.setTitle(Constants.SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_TITLE);
					} else if (Constants.SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_OID.equalsIgnoreCase(institutionOID)) {
						serviceProvider.setId(Constants.SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_ID);
						serviceProvider.setOid(Constants.SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_OID);
						serviceProvider.setName(Constants.SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_ID);
						serviceProvider.setTitle(Constants.SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_TITLE);
					} else if (Constants.SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_OID.equalsIgnoreCase(institutionOID)) {
						serviceProvider.setId(Constants.SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_ID);
						serviceProvider.setOid(Constants.SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_OID);
						serviceProvider.setName(Constants.SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_ID);
						serviceProvider.setTitle(Constants.SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_TITLE);
					} else if (Constants.SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_OID.equalsIgnoreCase(institutionOID)) {
						serviceProvider.setId(Constants.SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_ID);
						serviceProvider.setOid(Constants.SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_OID);
						serviceProvider.setName(Constants.SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_ID);
						serviceProvider.setTitle(Constants.SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_TITLE);
					}
					xml.append(buildServiceProviderData(serviceProvider, format));
					serviceProviderLoaded = true;
				} 
				
				// Load service from cache.
				egovService = EgovWCMCache.getServiceByName(id);
				if (egovService != null) {
					xml.append(buildServiceData(egovService, format));
					List<EgovServiceProvider> serviceProviders = EgovWCMCache.getServiceProviders();
					for (int i = 0; i < serviceProviders.size(); i++) {
						if (institutionOID.equalsIgnoreCase(serviceProviders.get(i).getName())) {
							xml.append(buildServiceProviderData(serviceProviders.get(i), format));
							break;
						}
					}
				} else {
					query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
					
					// filter by library.
					query.addSelector(Selectors.libraryEquals(EgovWCMCache.getWorkspace().getDocumentLibrary(Constants.EGOV_CONTENT_LIBRARY_NAME)));
					
					// filter by name.
					query.addSelector(Selectors.nameEquals(id));

					// filter by 'Published' only.
					query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
					
					// filter by serviceSuppliers AT ONLY.
					query.addSelector(
						Selectors.authoringTemplateIn(
							new DocumentId[] {
								EgovWCMCache.getATServiceProvidedBySupplier().getId(),
								EgovWCMCache.getATUnifiedService().getId() 
							}
						)
					);
					query.returnObjects();
				    resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);
				    if (resultIterator.hasNext()) {
				    	Content service = (Content) resultIterator.next();	
				    	if (service != null) {
				    		xml.append(buildServiceData(service, format));
				    		
				    		if (!serviceProviderLoaded) {
					    		// Load serviceProvider by name (institutionOID).
					    		query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
								
								// filter by library.
								query.addSelector(Selectors.libraryEquals(EgovWCMCache.getWorkspace().getDocumentLibrary(Constants.EGOV_CONTENT_LIBRARY_NAME)));
								
								// filter by name.
								query.addSelector(Selectors.nameEquals(institutionOID));
	
								// filter by 'Published' only.
								query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
								
								// filter by serviceSuppliers AT ONLY.
								query.addSelector(
									Selectors.authoringTemplateIn(
										new DocumentId[] {
											EgovWCMCache.getATServiceProviderCentralAdministration().getId(),
											EgovWCMCache.getATServiceProviderTerritorialAdministration().getId(), 
											EgovWCMCache.getATServiceProviderInstitutionOther().getId(),
											EgovWCMCache.getATServiceProviderArticle1Paragraph2().getId()
										}
									)
								);
								query.returnObjects();	 
								resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);
							    if (resultIterator.hasNext()) {
							    	Content serviceProvider = (Content) resultIterator.next();
							    	if (serviceProvider != null) {
							    		xml.append(buildServiceProviderData(serviceProvider, format));
							    	}
							    }
				    		}
				    	}
				    }
				}
					    
			    // Load eForms data.
			 	// load service additions...
				query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
				query.addSelector(Selectors.libraryEquals(EgovWCMCache.getWorkspace().getDocumentLibrary(Constants.EFORMS_CONTENT_LIBRARY_NAME)));				
				query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));								
				query.addSelector(Selectors.titleEquals(id));
				// search for eForm data.
				resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);	
				if (resultIterator != null && resultIterator.hasNext()) { 		
					logger("Result found for loading eform.");
					Content content = null;
					String link = null;
					while (resultIterator.hasNext()) {
						content = (Content) resultIterator.next();
						if (content == null) {
							continue;
						}
						link = getTextFromComponentLink(content, Constants.EFORM_CONTENT_FIELD_NAME_EFORM_LINK, format);
						if (link != null && link.trim().length() > 0 && link.startsWith("/wps/wcm/")) {						
							// Move to anonymous resourceURL.
							link = URL_PREFIX + link.replaceAll("/myconnect/", "/connect/");						
						}					
						xml.append("<link>" + encode(link, format) + "</link>");		
						//xml.append("<link>" + getTextFromComponentLink(content, Constants.EFORM_CONTENT_FIELD_NAME_EFORM_LINK, format) + "</link>");
						SiteArea siteArea = (SiteArea)EgovWCMCache.getWorkspace().getById(content.getParentId());
						if (siteArea != null) {
							logger("siteArea founded -> " + siteArea.getName() +"," + siteArea.getTitle());
							DocumentIdIterator iterator = siteArea.getDirectChildren(Workspace.WORKFLOWSTATUS_PUBLISHED);
							DocumentId tmpDocId = null;
							ArrayList<Content> documents = new ArrayList<>();
							ArrayList<Content> files = new ArrayList<>();
							if (iterator.hasNext()) {
								logger("children founded.");
								while (iterator.hasNext()) {
									tmpDocId = (DocumentId)iterator.next();												
									if (tmpDocId.getType().isOfType(DocumentTypes.Content)) {
										content = (Content)EgovWCMCache.getWorkspace().getById(tmpDocId);
										if (Constants.EFORMS_AUTHORING_TEMPLATE_NAME_EFORM_DOCS.equalsIgnoreCase(content.getAuthoringTemplateID().getName())) {
											documents.add((Content)EgovWCMCache.getWorkspace().getById(tmpDocId));
										} else if (Constants.EFORMS_AUTHORING_TEMPLATE_NAME_EFORM_FILES.equalsIgnoreCase(content.getAuthoringTemplateID().getName())) {
											files.add((Content)EgovWCMCache.getWorkspace().getById(tmpDocId));
										}
									}
								}
							}
							if (documents != null && documents.size() > 0) {
								logger("Documents -> " + documents.size());
								xml.append("<documents>");
								xml.append(buildDocumentsData(documents, format));
								xml.append("</documents>");
							}
							if (files != null && files.size() > 0) {
								logger("Files -> " + files.size());
								xml.append("<files>");
								xml.append(buildFilesData(files, format));
								xml.append("</files>");
							}	
						}
						break;
					}
				} else {
					xml.append("<link></link>");
					xml.append("<documents></documents>");
					xml.append("<files></files>");
				}
		  } catch (Exception e) {
		     e.printStackTrace();
		  } 
		}
		xml.append("</serviceAddition>");
		if (PARAMETER_TYPE_JSON.equalsIgnoreCase(request.getParameter(PARAMETER_FORMAT))) {
			response.setContentType("application/json; charset=UTF-8");
			logger(xml.toString());
			JSONObject xmlJSONObj = XML.toJSONObject(xml.toString());
			String jsonPrettyPrintString = xmlJSONObj.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			response.getWriter().print(jsonPrettyPrintString);
		} else {
			response.setContentType("text/xml; charset=UTF-8");
			response.getWriter().print(xml.toString());
		}
		response.getWriter().flush();
		response.getWriter().close();
		//return;
	
		if (true) {
			return;
		}
		
		// TODO delete below after 01.07.2021.
		
		xml = new StringBuffer();
		xml.append("<?xml version=\"1.0\" encoding=\"utf8\" standalone=\"yes\"?>");
		xml.append("<serviceAddition>");		
	
		if (id != null && id.trim().length() > 0) { // arId
			logger("id= " + id);
			DocumentId institutionCategorySunauId = null;
			try {
				EgovWCMCache.getServiceAuthoringTemplate();
			} catch (Exception e) {
				System.out.println("EXCEPTION IN EgovWCMCache.getServiceAuthoringTemplate()!");
				EgovWCMCacheLoaderManagement cacheManagement = new EgovWCMCacheLoaderManagement();
				cacheManagement.reloadCache(getServletContext());				
			}	
			if (institutionOID != null && institutionOID.trim().length() > 0) {
				logger("institutionOID= " + institutionOID);
				
				ArrayList<DocumentId> catIds = null;
				try {
					// No cache for now, we always reload here, but ONLY for "supplier sunau taxonomy"!					
					EgovWCMCacheLoaderManagement cacheManagement = new EgovWCMCacheLoaderManagement();
					cacheManagement.populateCacheWithWCMSupplierSunauTaxonomyData(true);
					catIds = EgovWCMCache.getServicesSupplierSunauTaxonomyChildren();
				} catch (Exception e) {
					System.out.println("EXCEPTION IN EgovWCMCache.getServicesSupplierSunauTaxonomyChildren()!");
					EgovWCMCacheLoaderManagement cacheManagement = new EgovWCMCacheLoaderManagement();
					cacheManagement.reloadCache(getServletContext());
					try {
						catIds = EgovWCMCache.getServicesSupplierSunauTaxonomyChildren();
					} catch (Exception e2) {
						System.out.println(e2.getMessage());
						e2.printStackTrace();
					}
				}					
				if (catIds != null && catIds.size() > 0) {
					logger("has categoies");
					Category tmpCategory = null;				
					for (int i = 0; i < catIds.size(); i++) {
						try {
							tmpCategory = (Category)EgovWCMCache.getWorkspace().getById(catIds.get(i));
							if (institutionOID.equalsIgnoreCase(tmpCategory.getName())) {
								logger("category with " + institutionOID + " founded!");
								institutionCategorySunauId = tmpCategory.getId();
								break;
							}						
						} catch (Exception e) {
							System.out.println(e.getMessage());					
							e.printStackTrace();
						}
					}
				}	
			}
			try {
				DocumentId[] serviceATs = new DocumentId[] {EgovWCMCache.getServiceAuthoringTemplate(), EgovWCMCache.getServiceStateAuthoringTemplate()};
				//DocumentId[] serviceATs = new DocumentId[] {EgovWCMCache.getServiceStateAuthoringTemplate()};
				QueryService queryService = EgovWCMCache.getWorkspace().getQueryService(); 
				Query query = queryService.createQuery(Content.class);				
				query.addSelector(Selectors.libraryEquals(EgovWCMCache.getWorkspace().getDocumentLibrary(Constants.EGOV_CONTENT_LIBRARY_NAME)));				
				query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));								
				query.addSelector(Selectors.authoringTemplateIn(serviceATs));
				if (institutionCategorySunauId != null) {
					query.addSelector(ProfileSelectors.categoriesContains(institutionCategorySunauId));
				}
				if (keyword != null && keyword.trim().length() > 0) {					
					String [] keywords = new String[]{keyword};
					query.addSelector(ProfileSelectors.keywordIn(Arrays.asList(keywords)));
				}
				try {
					ResultIterator resultIter = queryService.execute(query);	
					if (resultIter != null && resultIter.hasNext()) { 	
						logger("Result found for loading services.");
						Content content = null;						
						boolean founded = false;
						while (resultIter.hasNext()) {
							content = (Content) resultIter.next();	
							if (content == null) {
								continue;
							}
							// Compare content arId match the Id from the request.
							if (id.equalsIgnoreCase(getTextFromComponent(content, Constants.SERVICE_CONTENT_FIELD_NAME_AR_ID, null))) {
								founded = true;
								logger("Founded service match - " + content.getId() + "," + content.getName());
								break;
							}							
						}
						if (founded) {
							xml.append(buildServiceContentData(content, format));
							// load service additions...
							query = queryService.createQuery(Content.class);
							query.addSelector(Selectors.libraryEquals(EgovWCMCache.getWorkspace().getDocumentLibrary(Constants.EFORMS_CONTENT_LIBRARY_NAME)));				
							query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));								
							query.addSelector(Selectors.titleEquals(id));
							// search for eForm data.
							resultIter = queryService.execute(query);	
							if (resultIter != null && resultIter.hasNext()) { 		
								logger("Result found for loading eform.");
								content = null;
								String link = null;
								while (resultIter.hasNext()) {
									content = (Content) resultIter.next();
									if (content == null) {
										continue;
									}
									link = getTextFromComponentLink(content, Constants.EFORM_CONTENT_FIELD_NAME_EFORM_LINK, format);
									if (link != null && link.trim().length() > 0 && link.startsWith("/wps/wcm/")) {						
										// Move to anonymous resourceURL.
										link = URL_PREFIX + link.replaceAll("/myconnect/", "/connect/");						
									}					
									xml.append("<link>" + encode(link, format) + "</link>");		
									//xml.append("<link>" + getTextFromComponentLink(content, Constants.EFORM_CONTENT_FIELD_NAME_EFORM_LINK, format) + "</link>");
									SiteArea siteArea = (SiteArea)EgovWCMCache.getWorkspace().getById(content.getParentId());
									if (siteArea != null) {
										logger("siteArea founded -> " + siteArea.getName() +"," + siteArea.getTitle());
										DocumentIdIterator iterator = siteArea.getDirectChildren(Workspace.WORKFLOWSTATUS_PUBLISHED);
										DocumentId tmpDocId = null;
										ArrayList<Content> documents = new ArrayList<>();
										ArrayList<Content> files = new ArrayList<>();
										if (iterator.hasNext()) {
											logger("children founded.");
											while (iterator.hasNext()) {
												tmpDocId = (DocumentId)iterator.next();												
												if (tmpDocId.getType().isOfType(DocumentTypes.Content)) {
													content = (Content)EgovWCMCache.getWorkspace().getById(tmpDocId);
													if (Constants.EFORMS_AUTHORING_TEMPLATE_NAME_EFORM_DOCS.equalsIgnoreCase(content.getAuthoringTemplateID().getName())) {
														documents.add((Content)EgovWCMCache.getWorkspace().getById(tmpDocId));
													} else if (Constants.EFORMS_AUTHORING_TEMPLATE_NAME_EFORM_FILES.equalsIgnoreCase(content.getAuthoringTemplateID().getName())) {
														files.add((Content)EgovWCMCache.getWorkspace().getById(tmpDocId));
													}
												}
											}
										}
										if (documents != null && documents.size() > 0) {
											logger("Documents -> " + documents.size());
											xml.append("<documents>");
											xml.append(buildDocumentsData(documents, format));
											xml.append("</documents>");
	 									}
										if (files != null && files.size() > 0) {
											logger("Files -> " + files.size());
											xml.append("<files>");
											xml.append(buildFilesData(files, format));
											xml.append("</files>");
	 									}	
									}
									break;
								}
							} else {
								xml.append("<link></link>");
								xml.append("<documents></documents>");
								xml.append("<files></files>");
							}
						}
					}
				} catch (Exception e) {
					System.out.println(e.getMessage());
					e.printStackTrace();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} 
		xml.append("</serviceAddition>");
		if (PARAMETER_TYPE_JSON.equalsIgnoreCase(request.getParameter(PARAMETER_FORMAT))) {
			response.setContentType("application/json; charset=UTF-8");
			logger(xml.toString());
			JSONObject xmlJSONObj = XML.toJSONObject(xml.toString());
			String jsonPrettyPrintString = xmlJSONObj.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			response.getWriter().print(jsonPrettyPrintString);
		} else {
			response.setContentType("text/xml; charset=UTF-8");
			response.getWriter().print(xml.toString());
		}
		response.getWriter().flush();
		response.getWriter().close();
		logger((System.currentTimeMillis() - time) + "");
	}
	
	
	private String buildServiceData(Content service, String format) {
		logger("buildServiceData IN");
		if (service == null) return "";
		EgovService egovService = new EgovService();
		egovService.setName(service.getName());
		egovService.setTitle(service.getTitle());
		egovService.setOid(getTextFromComponent(service, EgovWCMCache.SERVICE_FIELD_OID_NAME, format));
		egovService.setServiceName(getTextFromComponent(service, EgovWCMCache.SERVICE_FIELD_SERVICE_NAME_NAME, format));
		return buildServiceData(egovService, format);
	}
	
	private String buildServiceData(EgovService service, String format) {
		logger("buildServiceData IN");
		if (service == null) return "";						
		StringBuffer xml = new StringBuffer();
		xml.append("<arId>" + encode(service.getName(), format) + "</arId>");
		xml.append("<serviceOID>" + encode(service.getOid(), format) + "</serviceOID>");
		xml.append("<shortName>" + encode(service.getTitle(), format) + "</shortName>");
		xml.append("<serviceName>" + encode(service.getServiceName(), format) + "</serviceName>");		
		logger("buildServiceData OUT");
		return xml.toString();
	}
	
	private String buildServiceProviderData(Content serviceProvider, String format) {
		logger("buildServiceProviderData IN (content)");
		if (serviceProvider == null) return "";		
		EgovServiceProvider egovServiceProvider = new EgovServiceProvider();
		egovServiceProvider.setTitle(serviceProvider.getTitle());
		egovServiceProvider.setOid(getTextFromComponent(serviceProvider, EgovWCMCache.SP_FIELD_PROVIDER_OID_NAME, format));
		egovServiceProvider.setEik(getTextFromComponent(serviceProvider, EgovWCMCache.SP_FIELD_EIK_NAME, format));		
		logger("buildServiceProviderData OUT (content)");
		return buildServiceProviderData(egovServiceProvider, format);
	}
	
	private String buildServiceProviderData(EgovServiceProvider serviceProvider, String format) {
		logger("buildServiceProviderData IN");
		if (serviceProvider == null) return "";						
		StringBuffer xml = new StringBuffer();
		xml.append("<supplier>" + encode(serviceProvider.getTitle(), format) + "</supplier>");
		xml.append("<supplierOID>" + encode(serviceProvider.getOid(), format) + "</supplierOID>");		
		xml.append("<supplierEIK>" + encode(serviceProvider.getEik(), format) + "</supplierEIK>");
		logger("buildServiceProviderData OUT");
		return xml.toString();
	}
	
	
	private String buildServiceContentData(Content content, String format) {
		logger("buildServiceContentData IN");
		if (content == null) return "";				
		try {			
			logger("buildServiceContentData AT = [" + content.getAuthoringTemplateID().getName() + "]");
			if (content.getAuthoringTemplateID().getId().equals(EgovWCMCache.getServiceStateAuthoringTemplate().getId())) {
				logger("buildServiceContentData STATE");
				return buildServiceStateContentData(content, format);
			} else if (content.getAuthoringTemplateID().getId().equals(EgovWCMCache.getServiceAuthoringTemplate().getId())) {
				logger("buildServiceContentData DEFAULT");
				return buildServiceDefaultContentData(content, format);
			} 							
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			return "";
		}
		return "";
	}	
	
	private String buildServiceStateContentData(Content content, String format) {
		logger("buildServiceStateContentData IN");
		if (content == null) return "";						
		StringBuffer xml = new StringBuffer();							
		xml.append("<arId>" + encode(getTextFromComponent(content, Constants.SERVICE_CONTENT_FIELD_NAME_AR_ID, format), format) + "</arId>");		
		xml.append("<serviceOID>" + encode(getTextFromComponent(content, Constants.SERVICE_CONTENT_FIELD_NAME_OID, format), format) + "</serviceOID>");
		xml.append("<shortName>" + encode(content.getTitle(), format) + "</shortName>");
		xml.append("<serviceName>" + encode(getTextFromComponent(content, Constants.SERVICE_STATE_CONTENT_FIELD_NAME_SERVICE_NAME, format), format) + "</serviceName>");								
		String serviceSupplierText = getTextFromComponent(content, Constants.SERVICE_CONTENT_FIELD_NAME_SERVICE_SUPPLIER_TEXT, format);
		if (serviceSupplierText != null && serviceSupplierText.trim().length() > 0) {
			xml.append("<supplier>" + encode(serviceSupplierText, format) + "</supplier>");
		} else {
			Category serviceSupplier = getCategoryFromComponentOption(content, Constants.SERVICE_STATE_CONTENT_FIELD_NAME_SERVICE_SUPPLIER);
			if (serviceSupplier == null) return "";
			xml.append("<supplier>" + encode(serviceSupplier.getTitle(), format) + "</supplier>");
		}
		xml.append("<supplierOID>" + encode(getTextFromComponent(content, Constants.SERVICE_CONTENT_FIELD_NAME_SUPPLIER_OID, format), format) + "</supplierOID>");
		xml.append("<supplierEIK>" + encode(getTextFromComponent(content, Constants.SERVICE_CONTENT_FIELD_NAME_SUPPLIER_EIK, format), format) + "</supplierEIK>");		
		return xml.toString();
	}
	
	private String buildServiceDefaultContentData(Content content, String format) {
		logger("buildServiceDefaultContentData IN");
		StringBuffer xml = new StringBuffer();		
		xml.append("<arId>" + encode(getTextFromComponent(content, Constants.SERVICE_CONTENT_FIELD_NAME_AR_ID, format), format) + "</arId>");
		xml.append("<serviceOID>" + encode(getTextFromComponent(content, Constants.SERVICE_CONTENT_FIELD_NAME_OID, format), format) + "</serviceOID>");
		xml.append("<shortName>" + encode(content.getTitle(), format) + "</shortName>");							
		Category serviceInSunau = getCategoryFromComponentOption(content, Constants.SERVICE_CONTENT_FIELD_NAME_SERVICE_IN_SUNAU);
		int serviceInSunauInt = -1;		
		if (serviceInSunau != null) {
			if ("1".equals(serviceInSunau.getName())) serviceInSunauInt = 1;
			else serviceInSunauInt = 0;
		}				
		if (serviceInSunauInt == 0) {
			xml.append("<serviceName>" + encode(getTextFromComponent(content, Constants.SERVICE_CONTENT_FIELD_NAME_SERVICE_NAME_TEXT, format), format) + "</serviceName>");			
		} else {
			Category serviceNameSunau = getCategoryFromComponentOption(content, Constants.SERVICE_CONTENT_FIELD_NAME_SERVICE_NAME_SUNAU);
			if (serviceNameSunau != null) {
				xml.append("<serviceName>" + encode(serviceNameSunau.getTitle(), format) + "</serviceName>");
			} else {
				xml.append("<serviceName>" + encode(content.getTitle(), format) + "</serviceName>");
			}
		}		
		Category supplierType = getCategoryFromComponentOption(content, Constants.SERVICE_CONTENT_FIELD_NAME_SUPPLIER_TYPE);
		int supplierTypeInt = -1;
		if (supplierType != null) {
			if ("2".equals(supplierType.getName())) supplierTypeInt = 2;
			else if ("3".equals(supplierType.getName())) supplierTypeInt = 3;
			else if ("4".equals(supplierType.getName())) supplierTypeInt = 4;
			else supplierTypeInt = 5;
		}								
		if (supplierTypeInt == 5) {
			xml.append("<supplier>" + encode(getTextFromComponent(content, Constants.SERVICE_CONTENT_FIELD_NAME_SERVICE_SUPPLIER_TEXT, format), format) + "</supplier>");
		} else {
			xml.append("<supplier>" + encode(getTextFromComponent(content, Constants.SERVICE_CONTENT_FIELD_NAME_SERVICE_SUPPLIER_EKATTE, format), format) + "</supplier>");
		}
		xml.append("<supplierOID>" + encode(getTextFromComponent(content, Constants.SERVICE_CONTENT_FIELD_NAME_SUPPLIER_OID, format), format) + "</supplierOID>");
		xml.append("<supplierEIK>" + encode(getTextFromComponent(content, Constants.SERVICE_CONTENT_FIELD_NAME_SUPPLIER_EIK, format), format) + "</supplierEIK>");						
		return xml.toString();
	}	
	
	private String buildDocumentsData(ArrayList<Content> documents, String format) {	
		logger("buildDocumentsData IN");
		if (documents == null || documents.size() == 0) return "";
		StringBuffer xml = new StringBuffer();
		try {			
			Content content = null;
			String url = "";			
			for (int i = 0; i < documents.size(); i++) {
				content = documents.get(i);				
				xml.append("<document>");
					xml.append("<name>" + encode(content.getTitle(), format) + "</name>");
					xml.append("<description>" + encode(getTextFromComponent(content, Constants.EFORM_CONTENT_FIELD_NAME_DOCUMENT_DESCRIPTION, format), format) + "</description>");
					url = getTextFromComponentLink(content, Constants.EFORM_CONTENT_FIELD_NAME_DOCUMENT_LINK, format);
					if (url != null && url.trim().length() > 0 && url.startsWith("/wps/wcm/")) {						
						// Move to anonymous resourceURL.
						url = URL_PREFIX + url.replaceAll("/myconnect/", "/connect/");						
					}					
					xml.append("<link>" + encode(url, format) + "</link>");				
				xml.append("</document>");
			}				
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			return "";
		}
		return xml.toString();
	}	
	
	private String buildFilesData(ArrayList<Content> files, String format) {		
		logger("buildFilesData IN");
		if (files == null || files.size() == 0) return "";
		StringBuffer xml = new StringBuffer();
		try {			
			Content content = null;
//			String name = "";
			String url = "";
//			String size = "";
//			String mimeType = "";			
//			FileComponent component = null;
			for (int i = 0; i < files.size(); i++) {				
				content = files.get(i);
				xml.append("<file>");
					xml.append("<name>" + encode(content.getTitle(), format) + "</name>");					
					url = getTextFromComponentLink(content, Constants.EFORM_CONTENT_FIELD_NAME_FILES_LINK, format);
					if (url != null && url.trim().length() > 0 && url.startsWith("/wps/wcm/")) {						
						// Move to anonymous resourceURL.
						url = URL_PREFIX + url.replaceAll("/myconnect/", "/connect/");						
					}					
					xml.append("<link>" + encode(url, format) + "</link>");				
				xml.append("</file>");
//				name = "";
//				url = "";
//				size = "";
//				mimeType = "";
//				xml.append("<file>");					
//					component = getObjectFromComponentFile(content, Constants.EFORM_CONTENT_FIELD_NAME_FILES_FILE);
//					if (component != null) {						
//						url = (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ? HtmlConverter.escape(component.getResourceURL()) : component.getResourceURL();						
//						if (url != null && url.trim().length() > 0 && url.startsWith("/wps/wcm/")) {
//							// Move to anonymous resourceURL.
//							url = URL_PREFIX + url.replaceAll("/myconnect/", "/connect/");
//							name = component.getResourceName();
//							size = component.getSize() + ""; 
//							mimeType = component.getMimeType();
//						}
//					}										
//					xml.append("<name>" + encode(name, format) + "</name>");
//					xml.append("<description>" + encode(content.getTitle(), format) + "</description>");
//					xml.append("<url>" + encode(url, format) + "</url>");
//					xml.append("<size>" + encode(size, format) + "</size>");
//					xml.append("<mimeType>" + encode(mimeType, format) + "</mimeType>");
//				xml.append("</file>");
			}							
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			return "";
		}
		return xml.toString();
	}	
	
	private String getTextFromComponent(Content content, String componentName, String format) {
		String data = "";
		try {
			ContentComponent contentComponent = content.getComponentByReference(componentName);
			if (contentComponent instanceof ShortTextComponent) {
				data = ((ShortTextComponent)contentComponent).getText();						
			} else if (contentComponent instanceof TextComponent) {
				data = ((TextComponent)contentComponent).getText();						
			} else if (contentComponent instanceof RichTextComponent) {
				data = ((RichTextComponent)contentComponent).getRichText();				
			}
		} catch (ComponentNotFoundException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ? HtmlConverter.escape(data) : data;
	}
		
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Category getCategoryFromComponentOption(Content content, String componentName) {
		try {
			OptionSelectionComponent contentComponent = (OptionSelectionComponent)content.getComponentByReference(componentName);
			DocumentId[] documentIds = contentComponent.getCategorySelections();
			if (documentIds != null && documentIds.length > 0) {
				return (Category)EgovWCMCache.getWorkspace().getById(documentIds[0]);				
			}			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	private String getTextFromComponentLink(Content content, String componentName, String format) {
		String data = "";
		try {			
			LinkComponent component = (LinkComponent)content.getComponentByReference(componentName);
			data = component.getURL();
		} catch (ComponentNotFoundException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ? HtmlConverter.escape(data) : data;
	}	
	
	@SuppressWarnings("unused")
	private FileComponent getObjectFromComponentFile(Content content, String componentName) {			
		try {			
			return (FileComponent)content.getComponentByReference(componentName);					
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}				 
		return null;
	}	
				
	private String encode(String string, String format) {
		return (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ? (string != null) ? string : "" : "<![CDATA[" + ((string != null) ? string : "") + "]]>";
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private void logger(String string) {
		if (debug) {
			if ("err".equalsIgnoreCase(debugOutput)) {
				System.err.println(string);
			}	else {
				System.out.println(string);
			}
		}
	}

}
