package com.wcmprovider.egov.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.ContentComponent;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentIterator;
import com.ibm.workplace.wcm.api.DocumentTypes;
import com.ibm.workplace.wcm.api.RichTextComponent;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.SiteArea;
import com.ibm.workplace.wcm.api.TextComponent;
import com.ibm.workplace.wcm.api.exceptions.ComponentNotFoundException;
import com.ibm.workplace.wcm.api.exceptions.QueryServiceException;
import com.ibm.workplace.wcm.api.query.Disjunction;
import com.ibm.workplace.wcm.api.query.PageIterator;
import com.ibm.workplace.wcm.api.query.ProfileSelectors;
import com.ibm.workplace.wcm.api.query.Query;
import com.ibm.workplace.wcm.api.query.QueryDepth;
import com.ibm.workplace.wcm.api.query.ResultIterator;
import com.ibm.workplace.wcm.api.query.Selectors;
import com.ibm.workplace.wcm.api.query.SortDirection;
import com.ibm.workplace.wcm.api.query.Sorts;
import com.ibm.workplace.wcm.api.query.WorkflowSelectors;
import com.wcmprovider.egov.Constants;

@WebServlet("/uslugi")
public class Uslugi extends HttpServlet {	
	
	private static SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.ENGLISH);

	private static final String PARAMETER_SUPPLIER_BATCH_ID = "supplierBatchId";
	private static final String PARAMETER_UNIFIED_SERVICE = "unified";
	private static final String PARAMETER_RESULTS_PER_PAGE = "rPP";
	private static final String PARAMETER_CURRENT_PAGE = "cP";
	private static final String PARAMETER_QUERY = "q";	
	private static final int RESULTS_PER_PAGE = 10;
	private static final int CURRENT_PAGE = 1;
	private static final String PARAMETER_DEBUG = "debug";
	private static final String PARAMETER_DESCRIPTION_MAX_LENGTH = "descriptionMaxLength";
	private static final String PARAMETER_DESCRIPTION_SUFFIX = "descriptionSuffix";
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	private static final long serialVersionUID = 1L;
	private boolean debug = false;
	private static final String ALL_ADMINISTRATIONS_SA_ID = "9cc4d851-7f56-40d3-a42a-f6fc9ff54611";

	public Uslugi() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		debug = "true".equalsIgnoreCase(request.getParameter(PARAMETER_DEBUG));		
		serveContent(request, response);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void serveContent(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");		
		response.setContentType("application/json; charset=UTF-8");
		String q = request.getParameter(PARAMETER_QUERY);	
		String supplierBatchId = request.getParameter(PARAMETER_SUPPLIER_BATCH_ID);
		boolean isUnified = "true".equalsIgnoreCase(request.getParameter(PARAMETER_UNIFIED_SERVICE));
		String descriptionMaxLength = request.getParameter(PARAMETER_DESCRIPTION_MAX_LENGTH);
		String descriptionSuffix = request.getParameter(PARAMETER_DESCRIPTION_SUFFIX);
		int resultsPerPage = RESULTS_PER_PAGE;
		int currentPage = CURRENT_PAGE;
		
		try {
			if (request.getParameter(PARAMETER_RESULTS_PER_PAGE) != null) {
				resultsPerPage = Integer.parseInt(request.getParameter(PARAMETER_RESULTS_PER_PAGE));
			}
		} catch (Exception e) {}
		try {
			if (request.getParameter(PARAMETER_CURRENT_PAGE) != null) {
				currentPage = Integer.parseInt(request.getParameter(PARAMETER_CURRENT_PAGE));
			}
		} catch (Exception e) {}
		
		logger("Uslugi -> getContents() -> supplierBatchId=" + supplierBatchId);
		logger("Uslugi -> getContents() -> isUnified=" + isUnified);
		logger("Uslugi -> getContents() -> q=" + q);
		if (q != null) {
			logger("Uslugi -> getContents() -> q (ISO-8859-1 -> UTF-8)=" + (new String(q.getBytes("ISO-8859-1"), "UTF-8")));
		}
		logger("Uslugi -> getContents() -> resultsPerPage=" + resultsPerPage);
		logger("Uslugi -> getContents() -> currentPage=" + currentPage);
		logger("Uslugi -> getContents() -> descriptionMaxLength=" + descriptionMaxLength);
		logger("Uslugi -> getContents() -> descriptionSuffix=" + descriptionSuffix);
		logger("Uslugi -> getContents() -> debug=" + request.getParameter(PARAMETER_DEBUG));
			
		JSONObject json = new JSONObject();
		JSONArray ja = new JSONArray(); 	
		if (supplierBatchId == null) {
			json.put("data", ja);
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
			response.getWriter().print(jsonPrettyPrintString);
			response.getWriter().flush();
			response.getWriter().close();	
			return;
		}
		
		int totalPages = 0;	
		int totalResults = 0;
		try {
			if (supplierBatchId != null && supplierBatchId.trim().length() > 0) {
							
				if (isUnified) { // for municipalities.
					Query query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
					query.addSelector(Selectors.nameEquals(supplierBatchId));
					// By default, all of them are published.
					query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
					// Load only others templates.
					query.addSelector(
						Selectors.authoringTemplateIn(
							new DocumentId[] {
								EgovWCMCache.getATAdditionalDataOfServiceProvidedBySupplier().getId()
							}
						)
					);
					query.returnObjects();
					try {
						ResultIterator resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);
			    		if (resultIterator.hasNext()) {
			    			List<String> names = new ArrayList<String>();
			    			Content content = null;
			    			while (resultIterator.hasNext()) {
			    				content = (Content)resultIterator.next();
			    				names.add(content.getParentId().getName().replace(EgovWCMCache.SERVICES_SITE_AREA_NAME_UNIFIED_SERVICE_SUFFIX, ""));
			    			}
			    			query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
			    			query.addSelector(Selectors.nameIn(names));
			    			// By default, all of them are published.
							query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
							// Load only others templates.
							query.addSelector(
								Selectors.authoringTemplateIn(
									new DocumentId[] {
										EgovWCMCache.getATUnifiedService().getId()
									}
								)
							);
							// load only 'active' services.
							query.addSelector(ProfileSelectors.categoriesContains(EgovWCMCache.getCategoryServiceStatusActive().getId()));
							if (q != null && q.trim().length() > 0) {
								String searchTerm = q;
								if (searchTerm != null && searchTerm.trim().length() > 0) {
									// Stupid IBM function does not support case insensitive!
									Disjunction or = new Disjunction();
									or.add(Selectors.titleLike("%" + searchTerm + "%"));
									or.add(Selectors.titleLike("%" + searchTerm.toLowerCase() + "%"));
									or.add(Selectors.titleLike("%" + searchTerm.toUpperCase() + "%"));
									if (searchTerm.trim().length() > 1) {
										if (!Character.isUpperCase(searchTerm.charAt(0))) {
											or.add(Selectors.titleLike("%" + searchTerm.substring(0, 1).toUpperCase() + searchTerm.substring(1) + "%"));
										}
										or.add(Selectors.titleLike("%" + capitalizeString(searchTerm.trim()) + "%"));
									}
									or.add(Selectors.nameLike("%" + searchTerm + "%"));
									query.addSelector(or);
								}
							} else {
								query.addSort(Sorts.byTitle(SortDirection.ASCENDING));
							}
							query.returnIds();
							PageIterator pageIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query, resultsPerPage, currentPage);	
							ArrayList<DocumentId> tmpIdArr = new ArrayList<>();
							JSONArray tmpJA = null; 
							if (pageIterator != null && pageIterator.hasNext()) {				
								content = null;
								ResultIterator docIterator = null;
								DocumentId contentDocId = null;
								int page = 0;
								docIterator = (ResultIterator) pageIterator.next();								
								while (docIterator.hasNext()) {
									contentDocId = (DocumentId)docIterator.next();
									tmpIdArr.add(contentDocId);
								}
								DocumentId[] docIds = tmpIdArr.toArray(new DocumentId[tmpIdArr.size()]);
								DocumentIdIterator documentIdIterator = EgovWCMCache.getWorkspace().createDocumentIdIterator(docIds);
								DocumentIterator documentIterator = EgovWCMCache.getWorkspace().getByIds(documentIdIterator, true, false);
								int contents = 0;
								String path = "";
								while (documentIterator.hasNext()) {
									content = (Content) documentIterator.next();
									tmpJA = new JSONArray();
									tmpJA.put(content.getId().getID());
									tmpJA.put(content.getName());
									tmpJA.put(content.getTitle());
									tmpJA.put(trimText(getTextFromComponent(content, Constants.SERVICE_CONTENT_FIELD_NAME_SERVICE_DESCRIPTION), descriptionMaxLength, descriptionSuffix));
									tmpJA.put((content.getPublishedDate() != null) ? timeMillisToDate(content.getPublishedDate().getTime()) : "");
									path = EgovWCMCache.getWorkspace().getPathById(content.getId(), false, true);
									if (path.toLowerCase().startsWith(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME.toLowerCase())) {
										path = path.substring(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME.length());
									}
									tmpJA.put(path);
									ja.put(tmpJA);
									contents++;
								}
								if (pageIterator.hasNext()) {
									contents = 0;
									while (pageIterator.hasNext()) {
										docIterator = (ResultIterator) pageIterator.next();
										page++;
									}
									while (docIterator.hasNext()) {
										docIterator.next();
										contents++;
									}					
								} 
								totalPages = currentPage + page;
								totalResults = ((totalPages * resultsPerPage) - resultsPerPage) + contents;
							}						
			    		}    		
					 } catch (QueryServiceException e) {
					 	System.out.println("WCMProvider -> supplierBatchId !=  null && isUnified - error: " + e.getMessage());
					    e.printStackTrace();
					 }
				} else { // for central administrations.
					// All Administrations
					
					SiteArea allAdminsSA = (SiteArea)EgovWCMCache.getWorkspace().getById(EgovWCMCache.getWorkspace().createDocumentId(ALL_ADMINISTRATIONS_SA_ID));
					DocumentIdIterator iterator = EgovWCMCache.getWorkspace().findByName(DocumentTypes.SiteArea, "uslugi-" + supplierBatchId);
					if (allAdminsSA != null || (iterator != null && iterator.hasNext())) {
						DocumentId saId = iterator.next();
						Query query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
						query.addParentId(saId, QueryDepth.CHILDREN);
						// By default, all of them are published.
						query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
						// Load only services.
						query.addSelector(
							Selectors.authoringTemplateIn(
								new DocumentId[] {
									EgovWCMCache.getATUnifiedService().getId(),
									EgovWCMCache.getATServiceProvidedBySupplier().getId()
								}
							)
						);
						// load only 'active' services.
						query.addSelector(ProfileSelectors.categoriesContains(EgovWCMCache.getCategoryServiceStatusActive().getId()));
						if (q != null && q.trim().length() > 0) {
							String searchTerm = q;
							if (searchTerm != null && searchTerm.trim().length() > 0) {
								// Stupid IBM function does not support case insensitive!
								Disjunction or = new Disjunction();
								or.add(Selectors.titleLike("%" + searchTerm + "%"));
								or.add(Selectors.titleLike("%" + searchTerm.toLowerCase() + "%"));
								or.add(Selectors.titleLike("%" + searchTerm.toUpperCase() + "%"));
								if (searchTerm.trim().length() > 1) {
									if (!Character.isUpperCase(searchTerm.charAt(0))) {
										or.add(Selectors.titleLike("%" + searchTerm.substring(0, 1).toUpperCase() + searchTerm.substring(1) + "%"));
									}
									or.add(Selectors.titleLike("%" + capitalizeString(searchTerm.trim()) + "%"));
								}
								or.add(Selectors.nameLike("%" + searchTerm + "%"));
								query.addSelector(or);
							}
						} else {
							query.addSort(Sorts.byTitle(SortDirection.ASCENDING));
						}
						query.returnIds(); 
						PageIterator pageIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query, resultsPerPage, currentPage);			
						ArrayList<DocumentId> tmpIdArr = new ArrayList<>();
						JSONArray tmpJA = null; 
						if (pageIterator != null && pageIterator.hasNext()) {				
							Content content = null;
							ResultIterator docIterator = null;
							DocumentId contentDocId = null;
							int page = 0;
							docIterator = (ResultIterator) pageIterator.next();								
							while (docIterator.hasNext()) {
								contentDocId = (DocumentId)docIterator.next();
								tmpIdArr.add(contentDocId);
							}
							DocumentId[] docIds = tmpIdArr.toArray(new DocumentId[tmpIdArr.size()]);
							DocumentIdIterator documentIdIterator = EgovWCMCache.getWorkspace().createDocumentIdIterator(docIds);
							DocumentIterator documentIterator = EgovWCMCache.getWorkspace().getByIds(documentIdIterator, true, false);
							int contents = 0;
							String path = "";
							while (documentIterator.hasNext()) {
								content = (Content) documentIterator.next();
								tmpJA = new JSONArray();
								tmpJA.put(content.getId().getID());
								tmpJA.put(content.getName());
								tmpJA.put(content.getTitle());
								tmpJA.put(trimText(getTextFromComponent(content, Constants.SERVICE_CONTENT_FIELD_NAME_SERVICE_DESCRIPTION), descriptionMaxLength, descriptionSuffix));
								tmpJA.put((content.getPublishedDate() != null) ? timeMillisToDate(content.getPublishedDate().getTime()) : "");
								path = EgovWCMCache.getWorkspace().getPathById(content.getId(), false, true);
								if (path.toLowerCase().startsWith(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME.toLowerCase())) {
									path = path.substring(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME.length());
								}
								tmpJA.put(path);
								ja.put(tmpJA);
								contents++;
							}
							if (pageIterator.hasNext()) {
								contents = 0;
								while (pageIterator.hasNext()) {
									docIterator = (ResultIterator) pageIterator.next();
									page++;
								}
								while (docIterator.hasNext()) {
									docIterator.next();
									contents++;
								}					
							} 
							totalPages = currentPage + page;
							totalResults = ((totalPages * resultsPerPage) - resultsPerPage) + contents;
						}
					}
				}				
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}
		json.put("totalPages", totalPages);
		json.put("totalResults", totalResults);
		json.put("data", ja);
		
		String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
		response.getWriter().print(jsonPrettyPrintString);
		response.getWriter().flush();
		response.getWriter().close();	
	}
	
	private String clearHTMLTags(String text) {
		logger("function clearHTMLTags");
		String output = text;
		if (text != null && text.trim().length() > 0) {
			logger("clearHTMLTags: text before ->" + text);
			text = text.trim();
			// remove html tags...
			text = text.replaceAll("\\<.*?>", "");			
			// Remove Carriage return from java String
			text = text.replaceAll("\r", " ");
			// Remove New line from java string and replace html break
			text = text.replaceAll("\n", " ");
			// Remove New line from java string and replace html break
			text = text.replaceAll("\t", " ");
			// Decode HTML tags
			text = text.replaceAll("&nbsp;", " ");
		}
		logger("clearHTMLTags: output =" + output);
		return output;
	}
			
	
	private String trimText(String text, String descriptionMaxLength, String descriptionSuffix) {
		logger("function trimText");
		String output = text;
		if (text != null && text.trim().length() > 0) {
			logger("trimText: text before ->" + text);
			text = text.trim();
			// remove html tags...
			text = text.replaceAll("\\<.*?>", "");			
			// Remove Carriage return from java String
			text = text.replaceAll("\r", " ");
			// Remove New line from java string and replace html break
			text = text.replaceAll("\n", " ");
			// Remove New line from java string and replace html break
			text = text.replaceAll("\t", " ");
			// Decode HTML tags
			text = text.replaceAll("&nbsp;", " ");	
			// Remove extra spaces
			text = text.replaceAll("\\s+", " ");
//			text = text.replaceAll("�", "\"");
//			text = text.replaceAll("�", "\"");
//			text = text.replaceAll("&quot;", "\"");
//			text = text.replaceAll("&bdquo;", "\"");
//			text = text.replaceAll("&ldquo;", "\"");
//			text = text.replaceAll("&rdquo;", "\"");
			text = text.replaceAll("&#39;", "'");
			text = text.replaceAll("&amp;", "&");	
			text = text.replaceAll("&ndash;", "-");
			output = text;
			logger("trimText: text after ->" + text);
			if (descriptionMaxLength != null) {
				int descriptionMaxLengthInt = -1;				
				try {
					descriptionMaxLengthInt = Integer.parseInt(descriptionMaxLength.trim());	
				} catch (Exception e) {
					logger(e.getMessage());
				}
				if (descriptionMaxLengthInt > 0) {
					String suffix = (descriptionSuffix != null) ? descriptionSuffix : "";
					if (descriptionMaxLengthInt + suffix.trim().length() < text.trim().length()) {
						int lastSpace = text.indexOf(" ", descriptionMaxLengthInt);
						if (lastSpace != -1) {
							output = text.substring(0, lastSpace) + suffix;
						} else {
							if (descriptionMaxLengthInt + 15 < text.trim().length()) {
								output = text.substring(0, descriptionMaxLengthInt) + suffix;
							}
						}
					}
				}
			} 
		}
		logger("trimText: output =" + output);
		return output;
	}
	

	
	private String getTextFromComponent(Content content, String componentName) {
		String data = "";
		try {
			ContentComponent contentComponent = content.getComponentByReference(componentName);
			if (contentComponent instanceof ShortTextComponent) {
				data = ((ShortTextComponent)contentComponent).getText();								
			} else if (contentComponent instanceof TextComponent) {
				data = ((TextComponent)contentComponent).getText();								
			} else if (contentComponent instanceof RichTextComponent) {
				data = ((RichTextComponent)contentComponent).getRichText();
			}
		} catch (ComponentNotFoundException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		//return HtmlConverter.escapeJSON(clearHTMLTags(data));
		return clearHTMLTags(data);
	}

	public static String capitalizeString(String string) {
		char[] chars = string.toLowerCase().toCharArray();
		boolean found = false;
		for (int i = 0; i < chars.length; i++) {
			if (!found && Character.isLetter(chars[i])) {
				chars[i] = Character.toUpperCase(chars[i]);
				found = true;
			} else if (Character.isWhitespace(chars[i]) || chars[i] == '.' || chars[i] == '\'') { // You can add other
																									// chars here
				found = false;
			}
		}
		return String.valueOf(chars);
	}
	
	public static String timeMillisToDate(final long millis) {
		try { 
			return dateFormat.format(new Date(millis));
		} catch (final Exception e) {
			System.out.println("Utils : timeMillisToDate : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private void logger(String string) {		
		if (debug) {
			System.out.println(string);
		}
	}

}
