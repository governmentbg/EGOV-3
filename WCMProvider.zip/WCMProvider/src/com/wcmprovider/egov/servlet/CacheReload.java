package com.wcmprovider.egov.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wcmprovider.egov.EgovWCMCacheLoaderManagement;

/*
 * Used for cache rebuild
 */
@WebServlet("/cache-reload")
public class CacheReload extends HttpServlet {
	private static final String PARAMETER_OPERATION = "op";
	private static final String PARAMETER_PASSSWORD = "pass";
	private static final String PARAMETER_ALL = "all";
	private static final String PARAMETER_AUTHORING_TEMPLATES = "at";
	private static final String PARAMETER_SERVICE_TAXONOMY = "service-taxonomy";
	private static final String PARAMETER_SUPPLIER_SUNAU_TAXONOMY = "supplier-sunau-taxonomy";
	private static final String PARAMETER_PASSWORD_ALL = "Egov34vvAll!_pass";
	private static final String PARAMETER_PASSWORD_TEMPLATES = "tempEgo33TT^pas";
	private static final String PARAMETER_PASSWORD_SERVICE_TAXONOMY = "servTaxEgoON$$pas_";
	private static final String PARAMETER_PASSWORD_SUPPLIER_SUNAU_TAXONOMY = "EgoSupSuna33TT@PPasss";
	private static final String PARAMETER_DEBUG = "debug";
	private static boolean debug = false;
	private static final long serialVersionUID = 1L;

	public CacheReload() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		response.setContentType("text/plain; charset=UTF-8");
		request.setCharacterEncoding("utf8");		
		
		String operation = request.getParameter(PARAMETER_OPERATION);
		String password = request.getParameter(PARAMETER_PASSSWORD);
		debug = "true".equalsIgnoreCase(request.getParameter(PARAMETER_DEBUG));
		
		logger("operation=" + operation + ",password=" + (password != null && password.trim().length() > 0 ? "******" : "NULL") + ",debug=" + request.getParameter(PARAMETER_DEBUG));

		if (operation != null && operation.trim().length() > 0 
				&& password != null && password.trim().length() > 0) {
			EgovWCMCacheLoaderManagement cacheManagement = new EgovWCMCacheLoaderManagement();
			if (PARAMETER_ALL.equals(operation) && PARAMETER_PASSWORD_ALL.equals(password)) {
				logger("op=" + PARAMETER_ALL + ",pass=OK");
				cacheManagement.reloadCache(getServletContext());
				response.getWriter().print("Успешна преинициализация на кеш!");
			} else if (PARAMETER_AUTHORING_TEMPLATES.equals(operation) && PARAMETER_PASSWORD_TEMPLATES.equals(password)) {
				logger("op=" + PARAMETER_AUTHORING_TEMPLATES + ",pass=OK");
				cacheManagement.populateCacheWithWCMAuthoringTemplatesData(true);
				response.getWriter().print("Успешна преинициализация на кеш!");
			} else if (PARAMETER_SERVICE_TAXONOMY.equals(operation) && PARAMETER_PASSWORD_SERVICE_TAXONOMY.equals(password)) {
				logger("op=" + PARAMETER_SERVICE_TAXONOMY + ",pass=OK");
				cacheManagement.populateCacheWithWCMServiceTaxonomyData(true);
				response.getWriter().print("Успешна преинициализация на кеш!");
			} else if (PARAMETER_SUPPLIER_SUNAU_TAXONOMY.equals(operation) && PARAMETER_PASSWORD_SUPPLIER_SUNAU_TAXONOMY.equals(password)) {
				logger("op=" + PARAMETER_SUPPLIER_SUNAU_TAXONOMY + ",pass=OK");
				cacheManagement.populateCacheWithWCMSupplierSunauTaxonomyData(true);
				response.getWriter().print("Успешна преинициализация на кеш!");
			} else {
				response.getWriter().print("Невалидни параметри!");
			}
		} else {
			response.getWriter().print("Невалидни параметри!");
		}
		response.getWriter().flush();
		response.getWriter().close();
		StringBuffer xml = new StringBuffer();
		xml.append("<?xml version=\"1.0\" encoding=\"utf8\" standalone=\"yes\"?>");
		xml.append("<services>");		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private void logger(String string) {		
		if (debug) {
			System.out.println(string);
		}
	}

}
