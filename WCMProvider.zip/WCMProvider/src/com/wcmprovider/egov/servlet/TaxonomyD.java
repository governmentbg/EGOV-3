package com.wcmprovider.egov.servlet;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.json.XML;

import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.Category;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;

/*
 * THIS CLASS IS USED FOR DIRECT WCM ACCESS, NO CACHE
 */

@WebServlet("/taxonomyd")
public class TaxonomyD extends HttpServlet {
	private static final String PARAMETER_FORMAT = "format";
	private static final String PARAMETER_DATA = "data";
	private static final String PARAMETER_TYPE_TREE = "tree";
	private static final String PARAMETER_TYPE_JSON = "json";
	private static final String PARAMETER_TYPE_SEPARATOR = "separator";
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	private static final long serialVersionUID = 1L;

	public TaxonomyD() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		long currentTime = System.currentTimeMillis();
		System.out.println("START");
		String data = request.getParameter(PARAMETER_DATA);
		
		// DELETE CATEGORIES...
		/*if (request.getParameter("delete") != null) {
			DocumentIdIterator dIterator = null;
			ArrayList<EgovEkatte> arr = EgovWCMCache.getEkattes();
			System.out.println("TOTAL TO DELETE -> " + arr.size());
			for (int i = 0; i < arr.size(); i++) {				
				//if (arr.get(i).getLevel().trim().equalsIgnoreCase("НАСЕЛЕНО МЯСТО")) {
				if (arr.get(i).getLevel().trim().equalsIgnoreCase("ОБЩИНА")) {
					System.out.println("->" + arr.get(i).getCode());
					dIterator = EgovWCMCache.getWorkspace().findByName(DocumentTypes.Category, String.valueOf(arr.get(i).getCode().trim()));
					if (dIterator.hasNext()) { 
						System.out.println("FIND IT [" + arr.get(i).getName() + "/" + arr.get(i).getCode() + "]");
						try {
							EgovWCMCache.getWorkspace().delete(dIterator.next());					
							System.out.println("DELETE IT [" + i + "]");
							Thread.sleep(1000);
							System.out.println("AFTER SLEEP");
						} catch (Exception e) {
							e.printStackTrace();
						}				
					}
				}
			} 
			System.out.println("END [" + ((float)((System.currentTimeMillis() - currentTime)/1000)) + "s]");
			response.getWriter().print("TIME = [" + ((float)((System.currentTimeMillis() - currentTime)/1000)) + "s]");
			response.getWriter().flush();
			response.getWriter().close();
			return;
		} */
		
		if (PARAMETER_TYPE_TREE.equalsIgnoreCase(data)) {
			serveTree(request, response);
		} else {
			servePlain(request, response);
		}
		System.out.println("END [" + ((float)((System.currentTimeMillis() - currentTime)/1000)) + "s]");
	}

	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void servePlain(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");
		StringBuffer xml = new StringBuffer();
		xml.append("<?xml version=\"1.0\" encoding=\"utf8\" standalone=\"yes\"?>");
		xml.append("<taxonomy>");

		String separator = request.getParameter(PARAMETER_TYPE_SEPARATOR);
		String format = request.getParameter(PARAMETER_FORMAT);

		DocumentId rootTaxonomy = EgovWCMCache.getServicesTaxonomy();
		if (rootTaxonomy != null) {
			try {
				HashMap<String, Category> categoryNameByDocId = new HashMap<>();
				com.ibm.workplace.wcm.api.Taxonomy taxonomy = (com.ibm.workplace.wcm.api.Taxonomy)EgovWCMCache.getWorkspace().getById(rootTaxonomy);
				if (taxonomy != null) {
					xml.append("<category>" + taxonomy.getTitle() + "</category>");
					DocumentIdIterator catIds = taxonomy.getAllChildren();
					Category childCategory = null;
					String categoryPath = "";
					while (catIds.hasNext()) {
						childCategory = (Category) EgovWCMCache.getWorkspace().getById(catIds.next());
						if (childCategory != null) {
							categoryPath = getCategoryPath(childCategory, categoryNameByDocId, taxonomy, separator);
							xml.append("<category>" + categoryPath + "</category>");
							categoryNameByDocId.put(childCategory.getId().toString(), childCategory);
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		xml.append("</taxonomy>");
		if (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) {
			response.setContentType("application/json; charset=UTF-8");
			JSONObject xmlJSONObj = XML.toJSONObject(xml.toString());
			String jsonPrettyPrintString = xmlJSONObj.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			response.getWriter().print(jsonPrettyPrintString);
		} else {
			response.setContentType("text/xml; charset=UTF-8");
			response.getWriter().print(xml.toString());
		}
		response.getWriter().flush();
		response.getWriter().close();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void serveTree(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");
		StringBuffer xml = new StringBuffer();
		xml.append("<?xml version=\"1.0\" encoding=\"utf8\" standalone=\"yes\"?>");
		xml.append("<taxonomy>");

		String format = request.getParameter(PARAMETER_FORMAT);
		DocumentId rootTaxonomy = EgovWCMCache.getServicesTaxonomy();
		if (rootTaxonomy != null) {
			try {
				com.ibm.workplace.wcm.api.Taxonomy taxonomy = (com.ibm.workplace.wcm.api.Taxonomy)EgovWCMCache.getWorkspace().getById(rootTaxonomy);
				if (taxonomy != null) {
					xml.append("<category>");
					xml.append("<title>" + encode(taxonomy.getTitle(), format) + "</title>");
					DocumentIdIterator catIds = taxonomy.getChildren();
					Category childCategory = null;
					while (catIds.hasNext()) {
						childCategory = (Category) EgovWCMCache.getWorkspace().getById(catIds.next());
						xml.append("<category>");
						xml.append("<title>" + encode(childCategory.getTitle(), format) + "</title>");
						xml.append(getAllChildren("", childCategory, null, null, format));
						xml.append("</category>");
					}
					xml.append("</category>");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		xml.append("</taxonomy>");
		if (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) {
			response.setContentType("application/json; charset=UTF-8");
			JSONObject xmlJSONObj = XML.toJSONObject(xml.toString());
			String jsonPrettyPrintString = xmlJSONObj.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			response.getWriter().print(jsonPrettyPrintString);
		} else {
			response.setContentType("text/xml; charset=UTF-8");
			response.getWriter().print(xml.toString());
		}
		response.getWriter().flush();
		response.getWriter().close();
	}

	private String getCategoryPath(Category category, HashMap<String, Category> categoryNameByDocId, com.ibm.workplace.wcm.api.Taxonomy rootTaxonomy, String separator) {
		String categoryPath = "";
		Category tmpCategory = categoryNameByDocId.get(category.getParentId().toString());
		if (tmpCategory != null) {
			while (tmpCategory != null) {
				categoryPath = ((separator != null) ? separator : "/") + tmpCategory.getTitle() + categoryPath;
				tmpCategory = categoryNameByDocId.get(tmpCategory.getParentId().toString());
			}
		}
		return rootTaxonomy.getTitle() + categoryPath + ((separator != null) ? separator : "/") + category.getTitle();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private String getAllChildren(String xml, Category childCategory, DocumentIdIterator categoriesIds, Category subChildCategory, String format) {
		categoriesIds = childCategory.getChildren();
		subChildCategory = null;
		while (categoriesIds.hasNext()) {
			try {
				subChildCategory = (Category) EgovWCMCache.getWorkspace().getById(categoriesIds.next());
				xml += "<category>";
				xml += "<title>" + encode(subChildCategory.getTitle(), format) + "</title>";
				xml = getAllChildren(xml, subChildCategory, null, null, format);
				xml += "</category>";
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return xml;
	}

	private String encode(String string, String format) {
		// return (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ? JSONObject.quote(string) : "<![CDATA[" + string + "]]>";
		return (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ? string : "<![CDATA[" + string + "]]>";
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
