package com.wcmprovider.egov.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.json.XML;

import com.egov.wcm.cache.EgovEkatte;
import com.egov.wcm.cache.EgovWCMCache;
import com.wcmprovider.egov.EgovWCMCacheLoaderManagement;

@WebServlet("/ekatte")
public class Ekatte extends HttpServlet {

	private static final String EKATTELEVEL_REGION_EN = "REGION";
	private static final String EKATTELEVEL_DISTRICT_EN = "OBLAST";
	private static final String EKATTELEVEL_MUNICIPALITY_EN = "OBSHTINA";
	private static final String EKATTELEVEL_LIVING_PLACE_EN = "NASELENO MYASTO";
	private static final String EKATTELEVEL_AREA_EN = "RAYON";
	
	private static final String PARAMETER_FORMAT = "format";
	private static final String PARAMETER_DATA = "data";
	private static final String PARAMETER_CODE = "code";
	private static final String PARAMETER_TITLE = "title";
	private static final String PARAMETER_SKIP_CURRENT = "skipcurrent";
	private static final String PARAMETER_MODE = "mode";
	private static final String PARAMETER_MODE_FULL = "full";
	private static final String PARAMETER_MODE_PARENT = "parent";
	private static final String PARAMETER_MODE_ALL_CHILDREN = "allchildren";
	private static final String PARAMETER_MODE_DIRECT_CHILDREN = "directchildren";	
	private static final String PARAMETER_DATA_PLAIN = "plain";
	private static final String PARAMETER_FORMAT_JSON = "json";
	private static final String PARAMETER_SEPARATOR = "separator";
	private static final String PARAMETER_TYPE = "type";
	private static final String PARAMETER_TYPE_SECTORS = "sectors"; //regions
	private static final String PARAMETER_TYPE_REGIONS = "regions";//districts
	private static final String PARAMETER_TYPE_MUNICIPALITIES = "municipalities";
	private static final String PARAMETER_TYPE_LOCATION = "location";//settlements
	private static final String PARAMETER_TYPE_DISTRICTS = "districts";//areas
	private static final String PARAMETER_LOCALE = "locale";
	private static final String PARAMETER_DUPLICATES_ATTACH_PARENT_NAME = "dupAPN";
	private static final String PARAMETER_DEBUG = "debug";
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	private static final String LOCALE_EN = "en";	
	private static final long serialVersionUID = 1L;
	private static boolean debug = false;

	public Ekatte() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		long currentTime = System.currentTimeMillis();
//		System.out.println("START");
		String data = request.getParameter(PARAMETER_DATA);		
		debug = "true".equalsIgnoreCase(request.getParameter(PARAMETER_DEBUG));
		if (PARAMETER_DATA_PLAIN.equals(data)) {
			servePlain(request, response);
		} else {
			serveTree(request, response);
		}
//		System.out.println("END [" + ((float) ((System.currentTimeMillis() - currentTime) / 1000)) + "s]");
	}

	private void servePlain(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");
		StringBuffer xml = new StringBuffer();
		xml.append("<?xml version=\"1.0\" encoding=\"utf8\" standalone=\"yes\"?>");
		xml.append("<ekatte>");

		String code = request.getParameter(PARAMETER_CODE);
		String separator = request.getParameter(PARAMETER_SEPARATOR);
		String format = request.getParameter(PARAMETER_FORMAT);	
		String locale = request.getParameter(PARAMETER_LOCALE);		

		ArrayList<EgovEkatte> ekattes = null;
		try {
			ekattes = EgovWCMCache.getEkattes();
		} catch (Exception e) {
			logger("EXCEPTION IN EgovWCMCache.getEkattes()!");
			EgovWCMCacheLoaderManagement cacheManagement = new EgovWCMCacheLoaderManagement();
			cacheManagement.reloadCache(getServletContext());
			try {
				ekattes = EgovWCMCache.getEkattes();
			} catch (Exception e2) {
				logger(e2.getMessage());
				e2.printStackTrace();
			}
		}	
				
		if (ekattes != null) {
			try {
				if (code != null && code.trim().length() > 0) {
					EgovEkatte ekatte = EgovWCMCache.getEkattesHm().get(code.trim());
					if (ekatte != null) {
						xml.append("<ekatte>" + getEkattePath(ekatte, separator, format, locale) + "</ekatte>");
					}
				} else {
					ArrayList<EgovEkatte> ekatteRegions = EgovWCMCache.getEkattesParentHm().get(null);
					if (ekatteRegions == null) {
						ekatteRegions = EgovWCMCache.getEkattesParentHm().get("(null)");//db fix
					}
					if (ekatteRegions != null) {
						for (int i = 0; i < ekatteRegions.size(); i++) {
							xml.append(getEkatteWithAllChildrenWithPath("", ekatteRegions.get(i), null, format, separator, locale));
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		xml.append("</ekatte>");
		if (PARAMETER_FORMAT_JSON.equalsIgnoreCase(format)) {
			response.setContentType("application/json; charset=UTF-8");
			JSONObject xmlJSONObj = XML.toJSONObject(xml.toString());
			String jsonPrettyPrintString = xmlJSONObj.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			response.getWriter().print(jsonPrettyPrintString);
		} else {
			response.setContentType("text/xml; charset=UTF-8");
			response.getWriter().print(xml.toString());
		}
		response.getWriter().flush();
		response.getWriter().close();
	}

	private void serveTree(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");
		StringBuffer xml = new StringBuffer();
		xml.append("<?xml version=\"1.0\" encoding=\"utf8\" standalone=\"yes\"?>");
		xml.append("<ekattes>");

		String format = request.getParameter(PARAMETER_FORMAT);
		String code = request.getParameter(PARAMETER_CODE);
		String title = request.getParameter(PARAMETER_TITLE);
		String type = request.getParameter(PARAMETER_TYPE);
		String mode = request.getParameter(PARAMETER_MODE);
		String locale = request.getParameter(PARAMETER_LOCALE);		
		boolean skipCurrent = "true".equalsIgnoreCase(request.getParameter(PARAMETER_SKIP_CURRENT));
		boolean duplicatesAttachParentName = !"false".equalsIgnoreCase(request.getParameter(PARAMETER_DUPLICATES_ATTACH_PARENT_NAME));		
		if (debug) {
			System.out.println("format=" + format);
			System.out.println("code=" + code);
			System.out.println("title=" + title);
			System.out.println("type=" + type);
			System.out.println("mode=" + mode);
			System.out.println("locale=" + locale);
			System.out.println("skipCurrent=" + skipCurrent);
			System.out.println("duplicatesAttachParentName=" + duplicatesAttachParentName);
		}
		
		ArrayList<EgovEkatte> ekattes = null;
		try {
			ekattes = EgovWCMCache.getEkattes();
		} catch (Exception e) {
			logger("EXCEPTION IN EgovWCMCache.getEkattes()!");
			EgovWCMCacheLoaderManagement cacheManagement = new EgovWCMCacheLoaderManagement();
			cacheManagement.reloadCache(getServletContext());
			try {
				ekattes = EgovWCMCache.getEkattes();
			} catch (Exception e2) {
				logger(e2.getMessage());
				e2.printStackTrace();
			}
		}							
		if (ekattes != null) {
			if (debug) {
				System.out.println("ekattes.size=" + ekattes.size());
			}
			try {
				if (code != null && code.trim().length() > 0) {
					EgovEkatte ekatte = EgovWCMCache.getEkattesHm().get(code.trim());
					if (ekatte != null) {
						EgovEkatte tmpEkatte = null;
						if (PARAMETER_MODE_FULL.equalsIgnoreCase(mode) || PARAMETER_MODE_PARENT.equalsIgnoreCase(mode)) {
							tmpEkatte = ekatte;
							String parents = "";
							if (tmpEkatte.getParentCode() != null) {
								while (tmpEkatte != null && tmpEkatte.getParentCode() != null) {
									if (parents.trim().length() > 0) {
										parents += ",";
									}
									parents += tmpEkatte.getParentCode();
									tmpEkatte = EgovWCMCache.getEkattesHm().get(tmpEkatte.getParentCode());
								}
							}
							if (parents.trim().length() > 0) {
								String[] parentsArr = parents.split(",");
								for (int i = parentsArr.length - 1; i >= 0; i--) {
									tmpEkatte = EgovWCMCache.getEkattesHm().get(parentsArr[i]);
									xml.append("<ekatte>");
									xml.append("<code>" + tmpEkatte.getCode() + "</code>");
									if (LOCALE_EN.equalsIgnoreCase(locale)) {
										xml.append("<name>" + encode(tmpEkatte.getNameEn(), format) + "</name>");
										xml.append("<level>" + tmpEkatte.getLevelEn() + "</level>");
									} else {
										xml.append("<name>" + encode(tmpEkatte.getName(), format) + "</name>");
										xml.append("<level>" + tmpEkatte.getLevel() + "</level>");
									}
									xml.append("</ekatte>");
								}
							}
						}
						if (PARAMETER_MODE_FULL.equalsIgnoreCase(mode) || PARAMETER_MODE_ALL_CHILDREN.equalsIgnoreCase(mode) || PARAMETER_MODE_DIRECT_CHILDREN.equalsIgnoreCase(mode)) {
							if (PARAMETER_MODE_DIRECT_CHILDREN.equalsIgnoreCase(mode)) {
								xml.append(getDirectChildren("", ekatte, null, format, 0, skipCurrent, locale));
							} else {
								xml.append(getAllChildren("", ekatte, null, format, 0, skipCurrent, locale));
							}
						} else {
							xml.append("<ekatte>");
							xml.append("<code>" + ekatte.getCode() + "</code>");
							if (LOCALE_EN.equalsIgnoreCase(locale)) {
								xml.append("<name>" + encode(ekatte.getNameEn(), format) + "</name>");
								xml.append("<level>" + ekatte.getLevelEn() + "</level>");
							} else {
								xml.append("<name>" + encode(ekatte.getName(), format) + "</name>");
								xml.append("<level>" + ekatte.getLevel() + "</level>");								
							}
							xml.append("</ekatte>");
						}
					}
				} else if (title != null && title.trim().length() > 0 && type != null && type.trim().length() > 0) {					
					EgovEkatte ekatte = null;	
					boolean founded = false;					
					for (int i = 0; i < ekattes.size(); i++) {
						ekatte = ekattes.get(i);			
						if (LOCALE_EN.equalsIgnoreCase(locale)) {
							if (PARAMETER_TYPE_SECTORS.equalsIgnoreCase(type) && ekatte.getLevelEn().equalsIgnoreCase(EKATTELEVEL_REGION_EN)) {
								System.out.println("REGION OK");
								System.out.println(ekatte.getNameEn() + "|" + title);
							}
							if (PARAMETER_TYPE_SECTORS.equalsIgnoreCase(type) && ekatte.getLevelEn().equalsIgnoreCase(EKATTELEVEL_REGION_EN) && title.equalsIgnoreCase(ekatte.getNameEn())) {
								founded = true;
								break;
							} else if (PARAMETER_TYPE_REGIONS.equalsIgnoreCase(type) && ekatte.getLevelEn().equalsIgnoreCase(EKATTELEVEL_DISTRICT_EN) && title.equalsIgnoreCase(ekatte.getNameEn())) {
								founded = true;
								break;
							} else if (PARAMETER_TYPE_MUNICIPALITIES.equalsIgnoreCase(type) && ekatte.getLevelEn().equalsIgnoreCase(EKATTELEVEL_MUNICIPALITY_EN) && title.equalsIgnoreCase(ekatte.getNameEn())) {
								founded = true;
								break;
							} else if (PARAMETER_TYPE_LOCATION.equalsIgnoreCase(type) && ekatte.getLevelEn().equalsIgnoreCase(EKATTELEVEL_LIVING_PLACE_EN) && title.equalsIgnoreCase(ekatte.getNameEn())) {
								founded = true;
								break;
							} else if (PARAMETER_TYPE_DISTRICTS.equalsIgnoreCase(type) && ekatte.getLevelEn().equalsIgnoreCase(EKATTELEVEL_AREA_EN) && title.equalsIgnoreCase(ekatte.getNameEn())) {
								founded = true;
								break;
							}		
						} else {
							if (PARAMETER_TYPE_SECTORS.equalsIgnoreCase(type) && ekatte.getLevel().equalsIgnoreCase(EgovWCMCache.EKATTE_LEVEL_REGION)) {
								System.out.println("REGION OK");
								System.out.println(ekatte.getName() + "|" + title);
							}
							if (PARAMETER_TYPE_SECTORS.equalsIgnoreCase(type) && ekatte.getLevel().equalsIgnoreCase(EgovWCMCache.EKATTE_LEVEL_REGION) && title.equalsIgnoreCase(ekatte.getName())) {
								founded = true;
								break;
							} else if (PARAMETER_TYPE_REGIONS.equalsIgnoreCase(type) && ekatte.getLevel().equalsIgnoreCase(EgovWCMCache.EKATTE_LEVEL_DISTRICT) && title.equalsIgnoreCase(ekatte.getName())) {
								founded = true;
								break;
							} else if (PARAMETER_TYPE_MUNICIPALITIES.equalsIgnoreCase(type) && ekatte.getLevel().equalsIgnoreCase(EgovWCMCache.EKATTE_LEVEL_MUNICIPALITY) && title.equalsIgnoreCase(ekatte.getName())) {
								founded = true;
								break;
							} else if (PARAMETER_TYPE_LOCATION.equalsIgnoreCase(type) && ekatte.getLevel().equalsIgnoreCase(EgovWCMCache.EKATTE_LEVEL_SETTLEMENT) && title.equalsIgnoreCase(ekatte.getName())) {
								founded = true;
								break;
							} else if (PARAMETER_TYPE_DISTRICTS.equalsIgnoreCase(type) && ekatte.getLevel().equalsIgnoreCase(EgovWCMCache.EKATTE_LEVEL_AREA) && title.equalsIgnoreCase(ekatte.getName())) {
								founded = true;
								break;
							}		
						}
					}	
					if (founded) {
						xml.append("<ekatte>");
							xml.append("<code>" + ekatte.getCode() + "</code>");
							xml.append("<parentCode>" + ekatte.getParentCode() + "</parentCode>");
							if (LOCALE_EN.equalsIgnoreCase(locale)) {
								xml.append("<name>" + encode(ekatte.getNameEn(), format) + "</name>");
								xml.append("<level>" + ekatte.getLevelEn() + "</level>");								
							} else {
								xml.append("<name>" + encode(ekatte.getName(), format) + "</name>");
								xml.append("<level>" + ekatte.getLevel() + "</level>");
							}
						xml.append("</ekatte>");
					}
				} else if (PARAMETER_TYPE_SECTORS.equalsIgnoreCase(type) || PARAMETER_TYPE_REGIONS.equalsIgnoreCase(type)) {
					if (debug) {
						System.out.println("IF (PARAMETER_TYPE_SECTORS || PARAMETER_TYPE_REGIONS)");
					}
					ArrayList<EgovEkatte> ekatteRegions = EgovWCMCache.getEkattesParentHm().get(null);
					if (ekatteRegions == null) {
						ekatteRegions = EgovWCMCache.getEkattesParentHm().get("(null)");//db fix
					}
					if (ekatteRegions != null) {
						if (debug) {
							System.out.println("REGIONS.size=" + ekatteRegions.size());
						}
						ArrayList<String> names = new ArrayList<>();
						HashMap<String, EgovEkatte> ekatteByNameHm = new HashMap<>();
						ArrayList<EgovEkatte> ekatteChildren = null;
						for (int i = 0; i < ekatteRegions.size(); i++) {
							if (PARAMETER_TYPE_SECTORS.equalsIgnoreCase(type)) { // load regions
								xml.append("<ekatte>");
									xml.append("<code>" + ekatteRegions.get(i).getCode() + "</code>");
									if (LOCALE_EN.equalsIgnoreCase(locale)) {
										xml.append("<name>" + encode(ekatteRegions.get(i).getNameEn(), format) + "</name>");
										xml.append("<level>" + ekatteRegions.get(i).getLevelEn() + "</level>");
									} else {
										xml.append("<name>" + encode(ekatteRegions.get(i).getName(), format) + "</name>");
										xml.append("<level>" + ekatteRegions.get(i).getLevel() + "</level>");
									}
								xml.append("</ekatte>");
							} else if (PARAMETER_TYPE_REGIONS.equalsIgnoreCase(type)) { // load districts								
								ekatteChildren = EgovWCMCache.getEkattesParentHm().get(ekatteRegions.get(i).getCode());
								if (ekatteChildren != null && ekatteChildren.size() > 0) {
									for (int j = 0; j < ekatteChildren.size(); j++) {
										names.add(ekatteChildren.get(j).getName());
										ekatteByNameHm.put(ekatteChildren.get(j).getName(), ekatteChildren.get(j));
									}									
								}								
							}
						}
						if (names.size() > 0) {
							// sort by name
							Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
							EgovEkatte ekatte = null;
							for (int i = 0; i < names.size(); i++) {
								ekatte = ekatteByNameHm.get(names.get(i));
								xml.append("<ekatte>");
									xml.append("<code>" + ekatte.getCode() + "</code>");
									if (LOCALE_EN.equalsIgnoreCase(locale)) {
										xml.append("<name>" + encode(ekatte.getNameEn(), format) + "</name>");
										xml.append("<level>" + ekatte.getLevelEn() + "</level>");
									} else {
										xml.append("<name>" + encode(ekatte.getName(), format) + "</name>");
										xml.append("<level>" + ekatte.getLevel() + "</level>");
									}
								xml.append("</ekatte>");
							}							
						}
					}
				} else if (PARAMETER_TYPE_MUNICIPALITIES.equalsIgnoreCase(type) 
						|| PARAMETER_TYPE_LOCATION.equalsIgnoreCase(type)
						|| PARAMETER_TYPE_DISTRICTS.equalsIgnoreCase(type)) {
					if (debug) {
						System.out.println("IF (PARAMETER_TYPE_MUNICIPALITIES || PARAMETER_TYPE_LOCATION || PARAMETER_TYPE_DISTRICTS)");
					}
					ArrayList<EgovEkatte> allEkattes = EgovWCMCache.getEkattes();
					if (allEkattes != null && allEkattes.size() > 0) {
						List<String> names = new ArrayList<>();
						HashMap<String, List<EgovEkatte>> ekatteByNameHm = new HashMap<>();
						List<EgovEkatte> tmpArrList = null;
						EgovEkatte ekatte = null;
						for (int i = 0; i < allEkattes.size(); i++) {
							ekatte = null;
							if (PARAMETER_TYPE_MUNICIPALITIES.equalsIgnoreCase(type) 
									&& EgovWCMCache.EKATTE_LEVEL_MUNICIPALITY.equalsIgnoreCase(allEkattes.get(i).getLevel()) ) {
								ekatte = allEkattes.get(i);
							} else if (PARAMETER_TYPE_LOCATION.equalsIgnoreCase(type) 
									&& EgovWCMCache.EKATTE_LEVEL_SETTLEMENT.equalsIgnoreCase(allEkattes.get(i).getLevel()) ) {
								ekatte = allEkattes.get(i);
							} else if (PARAMETER_TYPE_DISTRICTS.equalsIgnoreCase(type) 
									&& EgovWCMCache.EKATTE_LEVEL_AREA.equalsIgnoreCase(allEkattes.get(i).getLevel()) ) {
								ekatte = allEkattes.get(i);
							}
							if (ekatte != null) {
								if (!names.contains(allEkattes.get(i).getName())) {
									names.add(allEkattes.get(i).getName());
								}
								tmpArrList = ekatteByNameHm.get(allEkattes.get(i).getName());
								if (tmpArrList == null) {
									tmpArrList = new ArrayList<EgovEkatte>();
								}
								tmpArrList.add(allEkattes.get(i));
								ekatteByNameHm.put(allEkattes.get(i).getName(), tmpArrList);
							}
						}
						if (names.size() > 0) {
							// sort by name
							Collections.sort(names, String.CASE_INSENSITIVE_ORDER);
							ekatte = null;
							boolean multiple = false;
							EgovEkatte parent = null;
							String parentName = "";
							for (int i = 0; i < names.size(); i++) {
								tmpArrList = ekatteByNameHm.get(names.get(i));
								if (tmpArrList != null) {
									multiple = tmpArrList.size() > 1;
									for (int j = 0; j < tmpArrList.size(); j++) {
										parentName = "";
										ekatte = tmpArrList.get(j);
										if (multiple && duplicatesAttachParentName) {
											parent = EgovWCMCache.getEkattesHm().get(ekatte.getParentCode());
											if (parent != null) {
												parentName = " (" + encode(parent.getName(), format) + ")";
												if (LOCALE_EN.equalsIgnoreCase(locale)) {
													parentName = " (" + encode(parent.getNameEn(), format) + ")";
												}
											}
										}
										xml.append("<ekatte>");
											xml.append("<code>" + ekatte.getCode() + "</code>");
											if (LOCALE_EN.equalsIgnoreCase(locale)) {
												xml.append("<name>" + encode(ekatte.getNameEn(), format) + parentName + "</name>");
												xml.append("<level>" + ekatte.getLevelEn() + "</level>");
											} else {
												xml.append("<name>" + encode(ekatte.getName(), format) + parentName + "</name>");
												xml.append("<level>" + ekatte.getLevel() + "</level>");
											}
										xml.append("</ekatte>");
									}
								}
							}							
						}
					}
					
				} else {
					ArrayList<EgovEkatte> ekatteRegions = EgovWCMCache.getEkattesParentHm().get(null);
					if (ekatteRegions == null) {
						ekatteRegions = EgovWCMCache.getEkattesParentHm().get("(null)");//db fix
					}
					if (ekatteRegions != null) {
						for (int i = 0; i < ekatteRegions.size(); i++) {
							xml.append(getAllChildren("", ekatteRegions.get(i), null, format, 0, false, locale));
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		xml.append("</ekattes>");
		if (PARAMETER_FORMAT_JSON.equalsIgnoreCase(format)) {
			response.setContentType("application/json; charset=UTF-8");
			JSONObject xmlJSONObj = XML.toJSONObject(xml.toString());
			String jsonPrettyPrintString = xmlJSONObj.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			response.getWriter().print(jsonPrettyPrintString);
		} else {
			response.setContentType("text/xml; charset=UTF-8");
			response.getWriter().print(xml.toString());
		}
		response.getWriter().flush();
		response.getWriter().close();
	}

	private String getAllChildren(String xml, EgovEkatte ekatte, ArrayList<EgovEkatte> ekatteChildren, String format, int level, boolean skipCurrent, String locale) {
		if (!skipCurrent) {
			xml += "<ekatte>";
			xml += "<code>" + ekatte.getCode() + "</code>";
			if (LOCALE_EN.equalsIgnoreCase(locale)) {
				xml += "<name>" + encode(ekatte.getNameEn(), format) + "</name>";
				xml += "<level>" + ekatte.getLevelEn() + "</level>";
			} else {
				xml += "<name>" + encode(ekatte.getName(), format) + "</name>";
				xml += "<level>" + ekatte.getLevel() + "</level>";	
			}
		}
		ekatteChildren = EgovWCMCache.getEkattesParentHm().get(ekatte.getCode());
		if (ekatteChildren != null && ekatteChildren.size() > 0) {
			for (int i = 0; i < ekatteChildren.size(); i++) {
				xml = getAllChildren(xml, ekatteChildren.get(i), null, format, level++, false, locale);
			}
		}
		if (!skipCurrent) {
			xml += "</ekatte>";
		}
		return xml;
	}

	private String getDirectChildren(String xml, EgovEkatte ekatte, ArrayList<EgovEkatte> ekatteChildren, String format, int level, boolean skipCurrent, String locale) {
		if (!skipCurrent) {
			xml += "<ekatte>";
			xml += "<code>" + ekatte.getCode() + "</code>";
			if (LOCALE_EN.equalsIgnoreCase(locale)) {
				xml += "<name>" + encode(ekatte.getNameEn(), format) + "</name>";
				xml += "<level>" + ekatte.getLevelEn() + "</level>";
			} else {
				xml += "<name>" + encode(ekatte.getName(), format) + "</name>";
				xml += "<level>" + ekatte.getLevel() + "</level>";
			}						
		}
		ekatteChildren = EgovWCMCache.getEkattesParentHm().get(ekatte.getCode());
		if (ekatteChildren != null && ekatteChildren.size() > 0) {
			for (int i = 0; i < ekatteChildren.size(); i++) {
				xml += "<ekatte>";
					xml += "<code>" + ekatteChildren.get(i).getCode() + "</code>";
					if (LOCALE_EN.equalsIgnoreCase(locale)) {
						xml += "<name>" + encode(ekatteChildren.get(i).getNameEn(), format) + "</name>";
						xml += "<level>" + ekatteChildren.get(i).getLevelEn() + "</level>";
					} else {
						xml += "<name>" + encode(ekatteChildren.get(i).getName(), format) + "</name>";
						xml += "<level>" + ekatteChildren.get(i).getLevel() + "</level>";
					}
				xml += "</ekatte>";
			}
		}
		if (!skipCurrent) {
			xml += "</ekatte>";
		}
		return xml;
	}

	private String getEkatteWithAllChildrenWithPath(String xml, EgovEkatte ekatte, ArrayList<EgovEkatte> ekatteChildren, String format, String separator, String locale) {
		xml += "<ekatte>" + getEkattePath(ekatte, separator, format, locale) + "</ekatte>";
		ekatteChildren = EgovWCMCache.getEkattesParentHm().get(ekatte.getCode());
		if (ekatteChildren != null && ekatteChildren.size() > 0) {
			for (int i = 0; i < ekatteChildren.size(); i++) {
				xml = getEkatteWithAllChildrenWithPath(xml, ekatteChildren.get(i), null, format, separator, locale);
			}
		}
		return xml;
	}
	
	private String getEkattePath(EgovEkatte ekatte, String separator, String format, String locale) {
		String path = "";
		if (ekatte.getParentCode() == null) {
			if (LOCALE_EN.equalsIgnoreCase(locale)) {
				return encode(ekatte.getNameEn(), format); 
			} else {
				return encode(ekatte.getName(), format);
			}
		}
		path = ekatte.getName();
		EgovEkatte tmpEkatte = EgovWCMCache.getEkattesHm().get(ekatte.getParentCode());
		if (tmpEkatte != null) {
			while (tmpEkatte != null) {			
				path = tmpEkatte.getName() + ((separator != null) ? separator : "/") + path;				
				tmpEkatte = EgovWCMCache.getEkattesHm().get(tmpEkatte.getParentCode());
			}
		}
		return encode(path, format);
	}

	private String encode(String string, String format) {
		String[] spl = string.split(" ");
		String beautify = "";
		// capitalize each first letter
		for (int i = 0; i < spl.length; i++) {
			if (i > 0) {
				beautify += " ";
			}
			beautify += Character.toUpperCase(spl[i].charAt(0)) + spl[i].substring(1).toLowerCase();			
		}		
		return (PARAMETER_FORMAT_JSON.equalsIgnoreCase(format)) ? beautify : "<![CDATA[" + beautify + "]]>";
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private void logger(String string) {
		if (debug) {
			System.out.println(string);
		}
	}

}
