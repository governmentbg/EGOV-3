package com.wcmprovider.egov.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.json.XML;

import com.egov.wcm.cache.EgovSearch;
import com.egov.wcm.cache.EgovService;
import com.egov.wcm.cache.EgovServiceProvider;
import com.egov.wcm.cache.EgovWCMCache;

@WebServlet("/services")
public class Services extends HttpServlet {	
	
	private static final String PARAMETER_FORMAT = "format";
	private static final String PARAMETER_TYPE_JSON = "json";
	private static final String PARAMETER_MODE = "mode";
	private static final String PARAMETER_MODE_CPSV_AP = "cpsv-ap";
	private static final String PARAMETER_DEBUG = "debug";
	private static final String PARAMETER_DESCRIPTION_MAX_LENGTH = "descriptionMaxLength";
	private static final String PARAMETER_DESCRIPTION_SUFFIX = "descriptionSuffix";
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	private static final long serialVersionUID = 1L;
	private boolean debug = false;
	private boolean isCPSVCall = false;
	private static String descriptionMaxLength = null;
	private static String descriptionSuffix = null;

	public Services() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		debug = "true".equalsIgnoreCase(request.getParameter(PARAMETER_DEBUG));
		descriptionMaxLength = request.getParameter(PARAMETER_DESCRIPTION_MAX_LENGTH);
		descriptionSuffix = request.getParameter(PARAMETER_DESCRIPTION_SUFFIX);
		serveContent(request, response);
	}

	private void serveContent(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");	
		
		isCPSVCall = PARAMETER_MODE_CPSV_AP.equalsIgnoreCase(request.getParameter(PARAMETER_MODE));		
		// Optional parameters.
		String format = request.getParameter(PARAMETER_FORMAT);
										
		logger(PARAMETER_FORMAT + "=" + format);
		logger(PARAMETER_MODE + "=" + request.getParameter(PARAMETER_MODE));
		logger(PARAMETER_DESCRIPTION_MAX_LENGTH + "=" + descriptionMaxLength);
		logger(PARAMETER_DESCRIPTION_SUFFIX + "=" + descriptionSuffix);
		
		StringBuffer xml = new StringBuffer();
		xml.append("<?xml version=\"1.0\" encoding=\"utf8\" standalone=\"yes\"?>");
		xml.append("<PublicServices>");				
		try {
			if (isCPSVCall) {
				// Load it from cache.
				EgovServiceProvider serviceProvider = null;
				EgovSearch search = new EgovSearch();
				List<EgovService> services = search.searchAllServices(); 
				if (services != null && services.size() > 0) {
					for (int i = 0; i < services.size(); i++) {
						serviceProvider = EgovWCMCache.getServiceProviderById(services.get(i).getSupplierUUID());
						xml.append(buildServiceData(services.get(i), serviceProvider, format));
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		xml.append("</PublicServices>");
		if (PARAMETER_TYPE_JSON.equalsIgnoreCase(request.getParameter(PARAMETER_FORMAT))) {
			response.setContentType("application/json; charset=UTF-8");
			logger(xml.toString());
			JSONObject xmlJSONObj = XML.toJSONObject(xml.toString());
			String jsonPrettyPrintString = xmlJSONObj.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			response.getWriter().print(jsonPrettyPrintString);
		} else {
			response.setContentType("text/xml; charset=UTF-8");
			response.getWriter().print(xml.toString());
		}
		response.getWriter().flush();
		response.getWriter().close();
	}
	
	private String buildServiceData(EgovService service, EgovServiceProvider serviceProvider, String format) {
		logger("buildServiceData IN");
		if (service == null) return "";	
		String[] classifications = service.getClassification();
		StringBuffer xml = new StringBuffer();
		xml.append("<PublicService>");
		xml.append("<identifier>" + encode("BG" + service.getName() + (serviceProvider != null ? serviceProvider.getName() : ""), format) + "</identifier>");				
		xml.append("<name>" + encode(service.getServiceName(), format) + "</name>");		
		xml.append("<description>" + encode(service.getServiceDescription() != null && service.getServiceDescription().trim().length() > 0 ? service.getServiceDescription() : service.getDescription(), format) + "</description>");
		xml.append("<language>BG</language>");
		xml.append("<status>1</status>");
		if (classifications != null && classifications.length > 0) {
			for (int i = 0; i < classifications.length; i++) {
				xml.append("<thematicArea>" + encode(classifications[i], format) + "</thematicArea>");
			}
		}
		xml.append("</PublicService>");
		logger("buildServiceData OUT");
		return xml.toString();
	}
	
	private String encode(String string, String format) {
		return (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ? (string != null) ? string : "" : "<![CDATA[" + ((string != null) ? string : "") + "]]>";
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private void logger(String string) {		
		if (debug) {
			System.out.println(string);
		}
	}

}
