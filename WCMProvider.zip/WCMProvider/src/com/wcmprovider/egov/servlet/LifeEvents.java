package com.wcmprovider.egov.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.json.XML;

import com.egov.wcm.cache.EgovLifeEvent;
import com.egov.wcm.cache.EgovSearch;
import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.ContentComponent;
import com.ibm.workplace.wcm.api.Identity;
import com.ibm.workplace.wcm.api.RichTextComponent;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.SiteArea;
import com.ibm.workplace.wcm.api.TextComponent;
import com.ibm.workplace.wcm.api.exceptions.ComponentNotFoundException;
import com.ibm.workplace.wcm.api.exceptions.QueryServiceException;
import com.ibm.workplace.wcm.api.query.Query;
import com.ibm.workplace.wcm.api.query.ResultIterator;
import com.ibm.workplace.wcm.api.query.Selectors;
import com.wcmprovider.egov.util.HtmlConverter;

@WebServlet("/life-events")
public class LifeEvents extends HttpServlet {	
	
	private static final String PARAMETER_FORMAT = "format";
	private static final String PARAMETER_TYPE_JSON = "json";
	private static final String PARAMETER_MODE = "mode";
	private static final String PARAMETER_MODE_CPSV_AP = "cpsv-ap";
	private static final String PARAMETER_DEBUG = "debug";
	private static final String PARAMETER_DESCRIPTION_MAX_LENGTH = "descriptionMaxLength";
	private static final String PARAMETER_DESCRIPTION_SUFFIX = "descriptionSuffix";
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	private static final long serialVersionUID = 1L;
	private boolean debug = false;
	private boolean isCPSVCall = false;
	private static String descriptionMaxLength = null;
	private static String descriptionSuffix = null;

	public LifeEvents() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		debug = "true".equalsIgnoreCase(request.getParameter(PARAMETER_DEBUG));
		descriptionMaxLength = request.getParameter(PARAMETER_DESCRIPTION_MAX_LENGTH);
		descriptionSuffix = request.getParameter(PARAMETER_DESCRIPTION_SUFFIX);
		serveContent(request, response);
	}

	@SuppressWarnings("rawtypes")
	private void serveContent(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");	
		
		isCPSVCall = PARAMETER_MODE_CPSV_AP.equalsIgnoreCase(request.getParameter(PARAMETER_MODE));		
		// Optional parameters.
		String format = request.getParameter(PARAMETER_FORMAT);
										
		logger(PARAMETER_FORMAT + "=" + format);
		logger(PARAMETER_MODE + "=" + request.getParameter(PARAMETER_MODE));
		logger(PARAMETER_DESCRIPTION_MAX_LENGTH + "=" + descriptionMaxLength);
		logger(PARAMETER_DESCRIPTION_SUFFIX + "=" + descriptionSuffix);
		
		StringBuffer xml = new StringBuffer();
		xml.append("<?xml version=\"1.0\" encoding=\"utf8\" standalone=\"yes\"?>");
		xml.append("<Events>");				
		try {
			if (isCPSVCall) {
				// Load it from cache.
				EgovSearch search = new EgovSearch();
				List<EgovLifeEvent> lifeEvents = search.searchAllLifeEvents(); 				
				if (lifeEvents != null && lifeEvents.size() > 0) {
					logger("LifeEvents -> serveContent -> lifeEvents.size() = " + lifeEvents.size());				
					List<Identity> eventsList = new ArrayList<Identity>();
					List<Identity> parentList = new ArrayList<Identity>();
					List<Content> events = new ArrayList<Content>();
					List<SiteArea> parents = new ArrayList<SiteArea>();
					String[] contentUUIDs = new String[lifeEvents.size()];
					for (int i = 0; i < lifeEvents.size(); i++) {
						contentUUIDs[i] = lifeEvents.get(i).getId();
					}					
			    	for (int i = 0; i < contentUUIDs.length; i++) {
			    		try {
			    			eventsList.add(EgovWCMCache.getWorkspace().createDocumentId(contentUUIDs[i].split("===")[0]));
			    		} catch (Exception e) {
			    		    e.printStackTrace();
			    		}
					}
			    	logger("LifeEvents -> serveContent -> eventsList.size() = " + eventsList.size());
			    	// Load life events.
			    	Query query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);		
					// filter by library.
					query.addSelector(Selectors.libraryEquals(EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)));		
					// filter by published.
					query.addSelector(Selectors.idIn(eventsList));
					// filter by sectionServices AT ONLY.
					query.returnObjects();
					try {
						ResultIterator resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);
			    		if (resultIterator.hasNext()) {		
			    			Content event = null;
			    			while (resultIterator.hasNext()) {
			    				try {
			    					event = (Content)resultIterator.next();
			    					events.add(event);
			    					parentList.add(event.getParentId());
					    		} catch (Exception e) {
					    		    e.printStackTrace();
					    		}
			    			}
			    		}    		
					} catch (QueryServiceException e) {
					    e.printStackTrace();
					}
								
					if (parentList != null && parentList.size() > 0) {
						logger("LifeEvents -> serveContent -> parentList.size() = " + parentList.size());
						// Load parents.					
						query = EgovWCMCache.getWorkspace().getQueryService().createQuery(SiteArea.class);		
						// filter by library.
						query.addSelector(Selectors.libraryEquals(EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)));		
						// filter by published.
						query.addSelector(Selectors.idIn(parentList));
						// filter by sectionServices AT ONLY.
						query.returnObjects();
						try {
							ResultIterator resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);
				    		if (resultIterator.hasNext()) {			    			
				    			while (resultIterator.hasNext()) {
				    				try {
				    					parents.add((SiteArea)resultIterator.next());
						    		} catch (Exception e) {
						    		    e.printStackTrace();
						    		}
				    			}
				    			logger("LifeEvents -> serveContent -> parents.size() = " + parents.size());
				    		}    		
						} catch (QueryServiceException e) {
						    e.printStackTrace();
						}
					}															
					for (int i = 0; i < lifeEvents.size(); i++) {
						xml.append(buildLifeEventData(lifeEvents.get(i), events, parents, format));
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		xml.append("</Events>");
		if (PARAMETER_TYPE_JSON.equalsIgnoreCase(request.getParameter(PARAMETER_FORMAT))) {
			response.setContentType("application/json; charset=UTF-8");
			logger(xml.toString());
			JSONObject xmlJSONObj = XML.toJSONObject(xml.toString());
			String jsonPrettyPrintString = xmlJSONObj.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			response.getWriter().print(jsonPrettyPrintString);
		} else {
			response.setContentType("text/xml; charset=UTF-8");
			response.getWriter().print(xml.toString());
		}
		response.getWriter().flush();
		response.getWriter().close();
	}
	
	private String buildLifeEventData(EgovLifeEvent lifeEvent, List<Content> events, List<SiteArea> parents, String format) {
		logger("buildLifeEventData IN");
		if (lifeEvent == null) return "";	
		String[] categories = lifeEvent.getCategories();
		StringBuffer xml = new StringBuffer();
		xml.append("<Event>");
		xml.append("<identifier>" + encode(lifeEvent.getName(), format) + "</identifier>");				
		xml.append("<name>" + encode(lifeEvent.getTitle(), format) + "</name>");
		if (events != null && events.size() > 0) {
			for (int i = 0; i < events.size(); i++) {
				if (events.get(i).getId().getId().equalsIgnoreCase(lifeEvent.getId())) { 
					xml.append("<description>" + encode(getRichTextFromComponent(events.get(i), EgovWCMCache.LIFE_EVENT_FIELD_EVENT_DESCRIPTION, format), format) + "</description>");
					break;
				}
			}
		}
		if (parents != null && parents.size() > 0) {
			for (int i = 0; i < parents.size(); i++) {
				if (parents.get(i).getName().equalsIgnoreCase(lifeEvent.getParentName())) {
					xml.append("<type>" + encode(parents.get(i).getTitle(), format) + "</type>");
					break;
				}
			}
		}
		xml.append("<status>1</status>");
		if (categories != null && categories.length > 0) {
			for (int i = 0; i < categories.length; i++) {
				if ("Житейско".equalsIgnoreCase(categories[i])) {
					xml.append("<specialization>Life Event</specialization>");
					break;
				} else if ("Бизнес".equalsIgnoreCase(categories[i])) {
					xml.append("<specialization>Business Event</specialization>");
					break;
				}
			}
		}
		xml.append("</Event>");
		logger("buildLifeEventData OUT");
		return xml.toString();
	}
	
	@SuppressWarnings("unused")
	private String getTextFromComponent(Content content, String componentName, String format) {
		String data = "";
		try {
			ContentComponent contentComponent = content.getComponentByReference(componentName);
			if (contentComponent instanceof ShortTextComponent) {
				data = ((ShortTextComponent)contentComponent).getText();								
			} else if (contentComponent instanceof TextComponent) {
				data = ((TextComponent)contentComponent).getText();								
			} 
		} catch (ComponentNotFoundException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ? HtmlConverter.escapeJSON(replaceHTMLOpenCloseTags(clearHTMLTags(data))) : data;
	}
	
	private String getRichTextFromComponent(Content content, String componentName, String format) {
		String data = "";
		try {
			ContentComponent contentComponent = content.getComponentByReference(componentName);
			if (contentComponent instanceof RichTextComponent) {
				data = ((RichTextComponent)contentComponent).getRichText();
			}
		} catch (ComponentNotFoundException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		// We call ONLY RichText component which has already been escaped!
		return (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ? replaceHTMLOpenCloseTags(clearHTMLTags(data)) : data;
	}
	
	private String clearHTMLTags(String text) {
		logger("function clearHTMLTags");
		String output = text;
		if (text != null && text.trim().length() > 0) {
			logger("clearHTMLTags: text before ->" + text);
			text = text.trim();
			// remove html tags...
			text = text.replaceAll("\\<.*?>", "");			
			// Remove Carriage return from java String
			text = text.replaceAll("\r", " ");
			// Remove New line from java string and replace html break
			text = text.replaceAll("\n", " ");
			// Remove New line from java string and replace html break
			text = text.replaceAll("\t", " ");
			// Decode HTML tags
			text = text.replaceAll("&nbsp;", " ");
		}
		logger("clearHTMLTags: output =" + output);
		return output;
	}
	
	private String replaceHTMLOpenCloseTags(String text) {
		if (text != null && text.trim().length() > 0) {
			text = text.replaceAll("<", "&lt;");
			text = text.replaceAll(">", "&gt;");
		}
		return text;
	}
			
	
	private String encode(String string, String format) {
		return (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ? (string != null) ? string : "" : "<![CDATA[" + ((string != null) ? string : "") + "]]>";
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private void logger(String string) {		
		if (debug) {
			System.out.println(string);
		}
	}
	
	public static void main(String[] args) {
		String desc = "<p dir=\"ltr\"><strong>Стартиране на стопанска дейност</strong></p>";
		desc = desc.replaceAll("<", "&lt;");
		desc = desc.replaceAll(">", "&gt;");
		String xml = "<?xml version=\"1.0\" encoding=\"utf8\" standalone=\"yes\"?><Events><Event><identifier>zapochvane, izvarshvane i priklyuchvane na stopanska deynost</identifier><name>Започване, извършване и приключване на стопанска дейност</name><description>" + desc + "</description></Event></Events>";
		JSONObject xmlJSONObj = XML.toJSONObject(xml.toString());
		String jsonPrettyPrintString = xmlJSONObj.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
		System.out.println(jsonPrettyPrintString);
	}

}
