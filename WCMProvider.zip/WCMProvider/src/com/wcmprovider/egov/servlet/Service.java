package com.wcmprovider.egov.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.json.XML;

import com.egov.wcm.cache.EgovService;
import com.egov.wcm.cache.EgovServiceProvider;
import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.ContentComponent;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentLibrary;
import com.ibm.workplace.wcm.api.DocumentTypes;
import com.ibm.workplace.wcm.api.RichTextComponent;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.TextComponent;
import com.ibm.workplace.wcm.api.Workspace;
import com.ibm.workplace.wcm.api.exceptions.ComponentNotFoundException;
import com.ibm.workplace.wcm.api.query.Conjunction;
import com.ibm.workplace.wcm.api.query.Disjunction;
import com.ibm.workplace.wcm.api.query.ProfileSelectors;
import com.ibm.workplace.wcm.api.query.Query;
import com.ibm.workplace.wcm.api.query.QueryDepth;
import com.ibm.workplace.wcm.api.query.ResultIterator;
import com.ibm.workplace.wcm.api.query.Selectors;
import com.ibm.workplace.wcm.api.query.SortDirection;
import com.ibm.workplace.wcm.api.query.Sorts;
import com.ibm.workplace.wcm.api.query.WorkflowSelectors;
import com.wcmprovider.egov.Constants;
import com.wcmprovider.egov.util.HtmlConverter;

@WebServlet("/service")
public class Service extends HttpServlet {	
	
	private static final String PARAMETER_FORMAT = "format";
	private static final String PARAMETER_TYPE_JSON = "json";
	private static final String PARAMETER_INSTITUTION_OID = "institutionOID";
	private static final String PARAMETER_SUPPLIER_CODE = "supplierCode";
	private static final String PARAMETER_SUPPLIER_ID = "supplierId";
	private static final String PARAMETER_SUPPLIER_EIK = "supplierEIK";
	private static final String PARAMETER_KEYWORD = "keyword";
	private static final String PARAMETER_DEBUG = "debug";
	private static final String PARAMETER_DESCRIPTION_MAX_LENGTH = "descriptionMaxLength";
	private static final String PARAMETER_DESCRIPTION_SUFFIX = "descriptionSuffix";
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	private static final long serialVersionUID = 1L;
	private static boolean debug = false;
	private static boolean eform = false;
	private static String descriptionMaxLength = null;
	private static String descriptionSuffix = null;

	public Service() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		debug = "true".equalsIgnoreCase(request.getParameter(PARAMETER_DEBUG));
		descriptionMaxLength = request.getParameter(PARAMETER_DESCRIPTION_MAX_LENGTH);
		descriptionSuffix = request.getParameter(PARAMETER_DESCRIPTION_SUFFIX);
		serveContent(request, response);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void serveContent(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");		
		// Required parameters.
		String supplierId = request.getParameter(PARAMETER_SUPPLIER_ID);
		String supplierCode = request.getParameter(PARAMETER_SUPPLIER_CODE);		
		String supplierEIK = request.getParameter(PARAMETER_SUPPLIER_EIK);
		// Optional parameters.
		String format = request.getParameter(PARAMETER_FORMAT);
		String keyword = request.getParameter(PARAMETER_KEYWORD);
		// USED ONLY FROM BUL SI.
		String institutionOID = request.getParameter(PARAMETER_INSTITUTION_OID);		

		eform = "eform".equalsIgnoreCase(keyword);
								
		logger(PARAMETER_FORMAT + "=" + format);
		logger(PARAMETER_INSTITUTION_OID + "=" + institutionOID);
		logger(PARAMETER_KEYWORD + "=" + keyword);
		logger(PARAMETER_DESCRIPTION_MAX_LENGTH + "=" + descriptionMaxLength);
		logger(PARAMETER_DESCRIPTION_SUFFIX + "=" + descriptionSuffix);
		logger(PARAMETER_SUPPLIER_ID + "=" + supplierId);
		logger(PARAMETER_SUPPLIER_CODE + "=" + supplierCode);
		logger(PARAMETER_SUPPLIER_EIK + "=" + supplierEIK);

		// USED ONLY FROM BUL SI.
		if (institutionOID != null && institutionOID.trim().length() > 0) {
			supplierCode = institutionOID;
		}
		
		StringBuffer xml = new StringBuffer();
		xml.append("<?xml version=\"1.0\" encoding=\"utf8\" standalone=\"yes\"?>");
		xml.append("<services>");		
		if ((supplierId != null && supplierId.trim().length() > 0)
				|| (supplierCode != null && supplierCode.trim().length() > 0)
				|| (supplierEIK != null && supplierEIK.trim().length() > 0)) {
			try {
				EgovServiceProvider serviceProvider = null;
				Query query = null;
				ResultIterator resultIterator = null;
				String parentId = null;
				
				if (supplierId != null && supplierId.trim().length() > 0) {
					// Load it from cache.
					List<EgovServiceProvider> serviceProviders = EgovWCMCache.getServiceProviders();
					if (serviceProviders != null && serviceProviders.size() > 0) {
						for (int i = 0; i < serviceProviders.size(); i++) {							
							if (supplierId.equalsIgnoreCase(serviceProviders.get(i).getId())) {
								serviceProvider = serviceProviders.get(i);
								logger("serviceProvider founded!");
								break;
							}								
						}		
					} else {
						query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
						// filter by library.
						query.addSelector(Selectors.libraryEquals(EgovWCMCache.getWorkspace().getDocumentLibrary(Constants.EGOV_CONTENT_LIBRARY_NAME)));
						
						// filter by id.
						query.addSelector(Selectors.idEquals(EgovWCMCache.getWorkspace().createDocumentId(supplierId)));
	
						// filter by 'Published' only.
						query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
						
						// filter by serviceSuppliers AT ONLY.
						query.addSelector(
								Selectors.authoringTemplateIn(
									new DocumentId[] {
										EgovWCMCache.getATServiceProviderCentralAdministration().getId(),
										EgovWCMCache.getATServiceProviderTerritorialAdministration().getId(), 
										EgovWCMCache.getATServiceProviderInstitutionOther().getId(),
										EgovWCMCache.getATServiceProviderArticle1Paragraph2().getId()
									}
								)
						);
						query.returnObjects();
					    resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);
					    if (resultIterator.hasNext()) {
					    	Content serviceProviderContent = (Content) resultIterator.next();	
					    	if (serviceProviderContent != null) {
					    		serviceProvider = new EgovServiceProvider();
					    		serviceProvider.setAuthoringTemplateName(serviceProviderContent.getAuthoringTemplateID().getName());
					    		serviceProvider.setTitle(serviceProviderContent.getTitle());
					    		serviceProvider.setOid(getTextFromComponent(serviceProviderContent, EgovWCMCache.SP_FIELD_PROVIDER_OID_NAME, format));
					    		serviceProvider.setEik(getTextFromComponent(serviceProviderContent, EgovWCMCache.SP_FIELD_EIK_NAME, format));
					    		serviceProvider.setParentName(serviceProviderContent.getParentId().getName());
					    		parentId = serviceProviderContent.getParentId().getId();
					    	}
					    }
					}
				} else if (supplierEIK != null && supplierEIK.trim().length() > 0) {
					// Load it from cache.
					List<EgovServiceProvider> serviceProviders = EgovWCMCache.getServiceProviders();
					if (serviceProviders != null && serviceProviders.size() > 0) {
						for (int i = 0; i < serviceProviders.size(); i++) {							
							if (supplierEIK.equalsIgnoreCase(serviceProviders.get(i).getEik())) {
								serviceProvider = serviceProviders.get(i);
								logger("serviceProvider founded!");
								break;
							}								
						}		
					}
				} else {
					if (Constants.SERVICE_PROVIDER_REGION_OID.equalsIgnoreCase(supplierCode) 
							|| Constants.SERVICE_PROVIDER_MUNICIPALITY_OID.equalsIgnoreCase(supplierCode)) {
						serviceProvider = new EgovServiceProvider();
						if (Constants.SERVICE_PROVIDER_REGION_OID.equalsIgnoreCase(supplierCode)) {
							serviceProvider.setId(Constants.SERVICE_PROVIDER_REGION_ID);
							serviceProvider.setOid(Constants.SERVICE_PROVIDER_REGION_OID);
							serviceProvider.setName(Constants.SERVICE_PROVIDER_REGION_ID);
							serviceProvider.setTitle(Constants.SERVICE_PROVIDER_REGION_TITLE);
						} else {
							serviceProvider.setId(Constants.SERVICE_PROVIDER_MUNICIPALITY_ID);
							serviceProvider.setOid(Constants.SERVICE_PROVIDER_MUNICIPALITY_OID);
							serviceProvider.setName(Constants.SERVICE_PROVIDER_MUNICIPALITY_ID);
							serviceProvider.setTitle(Constants.SERVICE_PROVIDER_MUNICIPALITY_TITLE);
						}
					} else if (Constants.SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_OID.equalsIgnoreCase(supplierCode) 
							|| Constants.SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_OID.equalsIgnoreCase(supplierCode)
							|| Constants.SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_OID.equalsIgnoreCase(supplierCode)
							|| Constants.SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_OID.equalsIgnoreCase(supplierCode)
							|| Constants.SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_OID.equalsIgnoreCase(supplierCode)
							|| Constants.SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_OID.equalsIgnoreCase(supplierCode)
							|| Constants.SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_OID.equalsIgnoreCase(supplierCode)) {
						serviceProvider = new EgovServiceProvider();
						if (Constants.SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_OID.equalsIgnoreCase(supplierCode)) {
							serviceProvider.setId(Constants.SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_ID);
							serviceProvider.setOid(Constants.SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_OID);
							serviceProvider.setName(Constants.SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_ID);
							serviceProvider.setTitle(Constants.SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_TITLE);
						} else if (Constants.SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_OID.equalsIgnoreCase(supplierCode)) {
							serviceProvider.setId(Constants.SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_ID);
							serviceProvider.setOid(Constants.SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_OID);
							serviceProvider.setName(Constants.SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_ID);
							serviceProvider.setTitle(Constants.SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_TITLE);
						} else if (Constants.SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_OID.equalsIgnoreCase(supplierCode)) {
							serviceProvider.setId(Constants.SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_ID);
							serviceProvider.setOid(Constants.SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_OID);
							serviceProvider.setName(Constants.SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_ID);
							serviceProvider.setTitle(Constants.SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_TITLE);
						} else if (Constants.SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_OID.equalsIgnoreCase(supplierCode)) {
							serviceProvider.setId(Constants.SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_ID);
							serviceProvider.setOid(Constants.SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_OID);
							serviceProvider.setName(Constants.SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_ID);
							serviceProvider.setTitle(Constants.SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_TITLE);
						} else if (Constants.SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_OID.equalsIgnoreCase(supplierCode)) {
							serviceProvider.setId(Constants.SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_ID);
							serviceProvider.setOid(Constants.SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_OID);
							serviceProvider.setName(Constants.SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_ID);
							serviceProvider.setTitle(Constants.SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_TITLE);
						} else if (Constants.SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_OID.equalsIgnoreCase(supplierCode)) {
							serviceProvider.setId(Constants.SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_ID);
							serviceProvider.setOid(Constants.SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_OID);
							serviceProvider.setName(Constants.SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_ID);
							serviceProvider.setTitle(Constants.SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_TITLE);
						} else if (Constants.SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_OID.equalsIgnoreCase(supplierCode)) {
							serviceProvider.setId(Constants.SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_ID);
							serviceProvider.setOid(Constants.SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_OID);
							serviceProvider.setName(Constants.SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_ID);
							serviceProvider.setTitle(Constants.SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_TITLE);
						}
					} else {
						// Load it from cache.
						List<EgovServiceProvider> serviceProviders = EgovWCMCache.getServiceProviders();
						if (serviceProviders != null && serviceProviders.size() > 0) {
							for (int i = 0; i < serviceProviders.size(); i++) {							
								if (supplierCode.equalsIgnoreCase(serviceProviders.get(i).getName())) {
									serviceProvider = serviceProviders.get(i);
									break;
								}								
							}		
						} else {
							query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
							// filter by library.
							query.addSelector(Selectors.libraryEquals(EgovWCMCache.getWorkspace().getDocumentLibrary(Constants.EGOV_CONTENT_LIBRARY_NAME)));
							// filter by name.
							query.addSelector(Selectors.nameEquals(supplierCode));
		
							// filter by 'Published' only.
							query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
							
							// filter by serviceSuppliers AT ONLY.
							query.addSelector(
									Selectors.authoringTemplateIn(
										new DocumentId[] {
											EgovWCMCache.getATServiceProviderCentralAdministration().getId(),
											EgovWCMCache.getATServiceProviderTerritorialAdministration().getId(), 
											EgovWCMCache.getATServiceProviderInstitutionOther().getId(),
											EgovWCMCache.getATServiceProviderArticle1Paragraph2().getId()
										}
									)
							);
							query.returnObjects();
						    resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);
						    if (resultIterator.hasNext()) {
						    	Content serviceProviderContent = (Content) resultIterator.next();	
						    	if (serviceProviderContent != null) {
						    		serviceProvider = new EgovServiceProvider();
						    		serviceProvider.setAuthoringTemplateName(serviceProviderContent.getAuthoringTemplateID().getName());
						    		serviceProvider.setTitle(serviceProviderContent.getTitle());
						    		serviceProvider.setOid(getTextFromComponent(serviceProviderContent, EgovWCMCache.SP_FIELD_PROVIDER_OID_NAME, format));
						    		serviceProvider.setEik(getTextFromComponent(serviceProviderContent, EgovWCMCache.SP_FIELD_EIK_NAME, format));
						    		serviceProvider.setParentName(serviceProviderContent.getParentId().getName());
						    		parentId = serviceProviderContent.getParentId().getId();
						    	}
						    }
						}
					}
				}
				
				if (serviceProvider != null) {	
					if (Constants.SERVICE_PROVIDER_REGION_OID.equalsIgnoreCase(supplierCode) 
						|| Constants.SERVICE_PROVIDER_MUNICIPALITY_OID.equalsIgnoreCase(supplierCode)) {
						// Check we have data in cache.
						List<EgovService> services = EgovWCMCache.getUnifiedServices();
						if (services != null && services.size() > 0) {
							EgovService service = null;
							for (int i = 0; i < services.size(); i++) {
								service = services.get(i);
								if (Constants.SERVICE_PROVIDER_REGION_OID.equalsIgnoreCase(supplierCode)
										&& EgovWCMCache.CATEGORY_PROVIDER_TYPE_REGIONAL_NAME.equalsIgnoreCase(service.getType())) {
									if (keyword != null && keyword.trim().length() > 0 && !service.hasKeyword(keyword, false)) {
    									continue;
    								}
									xml.append(buildServiceData(service, serviceProvider, format));
								} else 	if (Constants.SERVICE_PROVIDER_MUNICIPALITY_OID.equalsIgnoreCase(supplierCode)
										// For municipalities provider, we also include the areamunicipalities too.
										&& (EgovWCMCache.CATEGORY_PROVIDER_TYPE_MUNICIPAL_NAME.equalsIgnoreCase(service.getType()) || EgovWCMCache.CATEGORY_PROVIDER_TYPE_AREA_MUNICIPAL_NAME.equalsIgnoreCase(service.getType()))) {									
									if (keyword != null && keyword.trim().length() > 0 && !service.hasKeyword(keyword, false)) {
    									continue;
    								}
									xml.append(buildServiceData(service, serviceProvider, format));
								} 								
							}
						}
					} else if (Constants.SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_OID.equalsIgnoreCase(supplierCode) 
						|| Constants.SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_OID.equalsIgnoreCase(supplierCode)
						|| Constants.SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_OID.equalsIgnoreCase(supplierCode)
						|| Constants.SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_OID.equalsIgnoreCase(supplierCode)
						|| Constants.SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_OID.equalsIgnoreCase(supplierCode)
						|| Constants.SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_OID.equalsIgnoreCase(supplierCode)
						|| Constants.SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_OID.equalsIgnoreCase(supplierCode)) {
						// Check we have data in cache.
						List<EgovService> services = EgovWCMCache.getUnifiedServices();
						if (services != null && services.size() > 0) {
							EgovService service = null;
							String staPath = Constants.SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_ID;
							if (Constants.SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_OID.equalsIgnoreCase(supplierCode)) {
								staPath = Constants.SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_ID;
							} else if (Constants.SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_OID.equalsIgnoreCase(supplierCode)) {
								staPath = Constants.SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_ID;
							} else if (Constants.SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_OID.equalsIgnoreCase(supplierCode)) {
								staPath = Constants.SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_ID;
							} else if (Constants.SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_OID.equalsIgnoreCase(supplierCode)) {
								staPath = Constants.SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_ID;
							} else if (Constants.SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_OID.equalsIgnoreCase(supplierCode)) {
								staPath = Constants.SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_ID;
							} else if (Constants.SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_OID.equalsIgnoreCase(supplierCode)) {
								staPath = Constants.SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_ID;
							}
							for (int i = 0; i < services.size(); i++) {
								service = services.get(i);
								System.out.println("path=" + service.getContentPath() + ",type=" + service.getType());
								if (EgovWCMCache.CATEGORY_PROVIDER_TYPE_SPECIALIZED_LOCAL_NAME.equalsIgnoreCase(service.getType())) {
									System.out.println("INSIDE!!!");
									if (keyword != null && keyword.trim().length() > 0 && !service.hasKeyword(keyword, false)) {
    									continue;
    								}
									if (service.getContentPath() != null && service.getContentPath().indexOf("/" + staPath + "/") != -1) {
										xml.append(buildServiceData(service, serviceProvider, format));
									}
								}
							}
						}
					}
		    		// Central administration.
					else if (serviceProvider.getAuthoringTemplateName().equalsIgnoreCase(EgovWCMCache.getATServiceProviderCentralAdministration().getName())) {
						logger("Service -> Central Administration");
						String serviceProviderPath = null;
						if (serviceProvider.getContentPath() != null) {
							int pos = serviceProvider.getContentPath().lastIndexOf("/");
							if (pos != -1) {
								serviceProviderPath = serviceProvider.getContentPath().substring(0, pos);
							}
						} else if (parentId != null) {
							DocumentId parentDocId = EgovWCMCache.getWorkspace().createDocumentId(parentId);
			    			serviceProviderPath = EgovWCMCache.getWorkspace().getPathById(parentDocId, false, true);
						}
		    			
		    			if (serviceProviderPath != null) {
		    				serviceProviderPath = serviceProviderPath.substring(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME.length() + 1);
		    				String parentPath = serviceProviderPath + "/" + EgovWCMCache.SERVICES_SITE_AREA_NAME_BY_SUPPLIER_PREFIX + serviceProvider.getName();
		    				// Load it from search REST API.
//			    				EgovSearch egovSearch = new EgovSearch();
//			    				ArrayList<EgovService> services = egovSearch.searchServices(EgovWCMCache.getATServiceProvidedBySupplier().getName(), null, null, null, null, serviceProviderPath + "/" + EgovWCMCache.SERVICES_SITE_AREA_NAME_BY_SUPPLIER_PREFIX + serviceProvider.getName());
//			    				if (services != null && services.size() > 0) {
//			    					EgovService service = null;
//			    					for (int i = 0; i < services.size(); i++) {
//			    						// Load it from cache (as the date from search collection is not so detailed.
//			    						service = EgovWCMCache.getServiceByName().get(services.get(i).getName());
//							    		if (service != null) {
//							    			// SERVE CONTENT ELEMENTS...
//							    			xml.append(buildServiceData(service, serviceProvider, format));
//							    		}
//									}
		    				List<EgovService> servicesByProvider = EgovWCMCache.getServicesByProvider();
		    				if (servicesByProvider != null && servicesByProvider.size() > 0) {
		    					String tmpPath = "";
		    					EgovService service = null;
		    					for (int i = 0; i < servicesByProvider.size(); i++) {
		    						service = servicesByProvider.get(i);
		    						tmpPath = service.getContentPath(); 
		    						if (tmpPath != null) {
		    							tmpPath = tmpPath.substring(0, tmpPath.lastIndexOf("/"));
		    							if (tmpPath.indexOf(parentPath) != -1) {
		    								if (keyword != null && keyword.trim().length() > 0 && !service.hasKeyword(keyword, false)) {
		    									continue;
		    								}
		    								xml.append(buildServiceData(service, serviceProvider, format));
		    							}
		    						}
								}
		    				} else {
								// Get services siteArea.
								DocumentId siteArea = null;
								DocumentIdIterator iterator = EgovWCMCache.getWorkspace().findAllByPath(parentPath, DocumentTypes.SiteArea, Workspace.WORKFLOWSTATUS_PUBLISHED, new DocumentLibrary[] { EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)});
								if (iterator.hasNext()) { // Site area found.									
									siteArea = iterator.next();
									if (siteArea != null) {
										query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
										query.addParentId(siteArea, QueryDepth.CHILDREN);
										Conjunction and = new Conjunction();
										// By default, all of them are published.
										and.add(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
										// Load only news.
										and.add(
											Selectors.authoringTemplateIn(
												new DocumentId[] {																
													EgovWCMCache.getATServiceProvidedBySupplier().getId()
												}
											)
										);
										if (keyword != null && keyword.trim().length() > 0) {
											logger("keyword=" + keyword);
											String [] keywords = new String[]{keyword};
											and.add(ProfileSelectors.keywordIn(Arrays.asList(keywords)));
										}
										
										// load only 'active' services.			
										Disjunction or = new Disjunction();
										or.add(ProfileSelectors.categoriesContains(EgovWCMCache.getCategoryCommonActive().getId()));
										or.add(ProfileSelectors.categoriesContains(EgovWCMCache.getCategoryServiceStatusActive().getId()));
										and.add(or);
										query.addSort(Sorts.byTitle(SortDirection.ASCENDING));
										query.addSelector(and);
										query.returnObjects();
										resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);
									    if (resultIterator.hasNext()) {
									    	Content service = null;
									    	while(resultIterator.hasNext()) {
									    		service = (Content) resultIterator.next();
									    		// SERVE CONTENT ELEMENTS...
												xml.append(buildServiceData(service, serviceProvider, format));
									    	}
									    }
									}
								}
							}
		    			 }
		    		}
		    		// Territorial Administration.
		    		else if (serviceProvider.getAuthoringTemplateName().equalsIgnoreCase(EgovWCMCache.getATServiceProviderTerritorialAdministration().getName())) {
		    			logger("Service -> Territorial Administration");
		    			query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
		    			query.addSelector(Selectors.nameEquals(serviceProvider.getName()));
		    			// By default, all of them are published.
		    			query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
		    			// Load only others templates.
		    			query.addSelector(
		    				Selectors.authoringTemplateIn(
		    					new DocumentId[] {
		    						EgovWCMCache.getATAdditionalDataOfServiceProvidedBySupplier().getId()
		    					}
		    				)
		    			);
		    			query.returnObjects();		    			
		    			resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);
		        		if (resultIterator.hasNext()) {    			
		        			List<String> names = new ArrayList<String>();
		        			String name = null;
		        			Content content = null;
		        			while (resultIterator.hasNext()) {
		        				content = (Content)resultIterator.next();
		        				name = content.getParentId().getName().replace(EgovWCMCache.SERVICES_SITE_AREA_NAME_UNIFIED_SERVICE_SUFFIX, "");
		        				names.add(name);
		        			}
		        			// Load it from cache.
		        			List<EgovService> unifiedServices = EgovWCMCache.getUnifiedServices();
		        			if (unifiedServices != null && unifiedServices.size() > 0) {			        			
		    					EgovService service = null;
		    					for (int i = 0; i < names.size(); i++) {			    						
		    						service = EgovWCMCache.getServiceByName(names.get(i));
						    		if (service != null) {
						    			if (keyword != null && keyword.trim().length() > 0 && !service.hasKeyword(keyword, false)) {
	    									continue;
	    								}
						    			// SERVE CONTENT ELEMENTS...
						    			xml.append(buildServiceData(service, serviceProvider, format));
						    		}
								}
		    				} else {			    					
			        			query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
			        			Conjunction and = new Conjunction();
			        			and.add(Selectors.nameIn(names));
			        			// By default, all of them are published.
			        			and.add(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
			    				// Load only others templates.
			        			and.add(
			    					Selectors.authoringTemplateIn(
			    						new DocumentId[] {
			    							EgovWCMCache.getATUnifiedService().getId()
			    						}
			    					)
			    				);
			        			if (keyword != null && keyword.trim().length() > 0) {
									logger("keyword=" + keyword);
									String [] keywords = new String[]{keyword};
									and.add(ProfileSelectors.keywordIn(Arrays.asList(keywords)));
								}
			        			// load only 'active' services.			
								Disjunction or = new Disjunction();
								or.add(ProfileSelectors.categoriesContains(EgovWCMCache.getCategoryCommonActive().getId()));
								or.add(ProfileSelectors.categoriesContains(EgovWCMCache.getCategoryServiceStatusActive().getId()));
								and.add(or);
			    				query.addSort(Sorts.byTitle(SortDirection.ASCENDING));
			    				query.addSelector(and);	
								query.returnObjects();
								resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);
							    if (resultIterator.hasNext()) {
							    	Content service = null;
							    	while(resultIterator.hasNext()) {
							    		service = (Content) resultIterator.next();
							    		// SERVE CONTENT ELEMENTS...
										xml.append(buildServiceData(service, serviceProvider, format));
							    	}
							    }
		    				}
		        		}
			    	 }
				}
			} catch (Exception e) {
			     e.printStackTrace();
			}
		}		
		xml.append("</services>");
		if (PARAMETER_TYPE_JSON.equalsIgnoreCase(request.getParameter(PARAMETER_FORMAT))) {
			response.setContentType("application/json; charset=UTF-8");
			logger(xml.toString());
			JSONObject xmlJSONObj = XML.toJSONObject(xml.toString());
			String jsonPrettyPrintString = xmlJSONObj.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			response.getWriter().print(jsonPrettyPrintString);
		} else {
			response.setContentType("text/xml; charset=UTF-8");
			response.getWriter().print(xml.toString());
		}
		response.getWriter().flush();
		response.getWriter().close();
	}
	
	private String buildServiceData(Content service, EgovServiceProvider serviceProvider, String format) {
		EgovService egovService = new EgovService();
		egovService.setId(service.getId().getId());
		egovService.setTitle(service.getTitle());
		egovService.setName(service.getName());
		egovService.setOid(getTextFromComponent(service, EgovWCMCache.SERVICE_FIELD_OID_NAME, format));
		egovService.setServiceName(getTextFromComponent(service, EgovWCMCache.SERVICE_FIELD_SERVICE_NAME_NAME, format));
		egovService.setServiceDescription(getTextFromComponent(service, EgovWCMCache.SERVICE_FIELD_SERVICE_DESCRIPTION_NAME, format));
		return buildServiceData(egovService, serviceProvider, format);
	}
	
	private String buildServiceData(EgovService service, EgovServiceProvider serviceProvider, String format) {
		logger("buildServiceData IN");
		if (service == null) return "";						
		StringBuffer xml = new StringBuffer();
		xml.append("<service>");
		xml.append("<id>" + encode(service.getId(), format) + "</id>");		
		xml.append("<shortName>" + encode((eform ? service.getName() + " " : "") + service.getTitle(), format) + "</shortName>");	
		xml.append("<arId>" + encode(service.getName(), format) + "</arId>");
		xml.append("<serviceOID>" + encode(service.getOid(), format) + "</serviceOID>");
		xml.append("<serviceName>" + encode((eform ? service.getName() + " " : "") + service.getServiceName(), format) + "</serviceName>");		
		xml.append("<supplierOID>" + encode(serviceProvider.getOid(), format) + "</supplierOID>");
		xml.append("<supplier>" + encode(serviceProvider.getTitle(), format) + "</supplier>");
		xml.append("<supplierEIK>" + encode(serviceProvider.getEik(), format) + "</supplierEIK>");
		xml.append("<serviceDescription>" + encode(service.getServiceDescription(), format) + "</serviceDescription>");
		xml.append("</service>");
		logger("buildServiceData OUT");
		return xml.toString();
	}
	
	private String clearHTMLTags(String text) {
		logger("function clearHTMLTags");
		String output = text;
		if (text != null && text.trim().length() > 0) {
			logger("clearHTMLTags: text before ->" + text);
			text = text.trim();
			// remove html tags...
			text = text.replaceAll("\\<.*?>", "");			
			// Remove Carriage return from java String
			text = text.replaceAll("\r", " ");
			// Remove New line from java string and replace html break
			text = text.replaceAll("\n", " ");
			// Remove New line from java string and replace html break
			text = text.replaceAll("\t", " ");
			// Decode HTML tags
			text = text.replaceAll("&nbsp;", " ");
		}
		logger("clearHTMLTags: output =" + output);
		return output;
	}
			
	
	private String trimText(String text) {
		logger("function trimText");
		String output = text;
		if (text != null && text.trim().length() > 0) {
			logger("trimText: text before ->" + text);
			text = text.trim();
			// remove html tags...
			text = text.replaceAll("\\<.*?>", "");			
			// Remove Carriage return from java String
			text = text.replaceAll("\r", " ");
			// Remove New line from java string and replace html break
			text = text.replaceAll("\n", " ");
			// Remove New line from java string and replace html break
			text = text.replaceAll("\t", " ");
			// Decode HTML tags
			text = text.replaceAll("&nbsp;", " ");	
			// Remove extra spaces
			text = text.replaceAll("\\s+", " ");
			text = text.replaceAll("�", "\"");
			text = text.replaceAll("�", "\"");
			text = text.replaceAll("&quot;", "\"");
			text = text.replaceAll("&bdquo;", "\"");
			text = text.replaceAll("&ldquo;", "\"");
			text = text.replaceAll("&rdquo;", "\"");
			text = text.replaceAll("&#39;", "'");
			text = text.replaceAll("&amp;", "&");	
			text = text.replaceAll("&ndash;", "-");
			output = text;
			logger("trimText: text after ->" + text);
			if (descriptionMaxLength != null) {
				int descriptionMaxLengthInt = -1;				
				try {
					descriptionMaxLengthInt = Integer.parseInt(descriptionMaxLength.trim());	
				} catch (Exception e) {
					logger(e.getMessage());
				}
				if (descriptionMaxLengthInt > 0) {
					String suffix = (descriptionSuffix != null) ? descriptionSuffix : "";
					if (descriptionMaxLengthInt + suffix.trim().length() < text.trim().length()) {
						int lastSpace = text.indexOf(" ", descriptionMaxLengthInt);
						if (lastSpace != -1) {
							output = text.substring(0, lastSpace) + suffix;
						} else {
							if (descriptionMaxLengthInt + 15 < text.trim().length()) {
								output = text.substring(0, descriptionMaxLengthInt) + suffix;
							}
						}
					}
				}
			} 
		}
		logger("trimText: output =" + output);
		return output;
	}
	
	
	private String getTextFromComponent(Content content, String componentName, String format) {
		String data = "";
		try {
			ContentComponent contentComponent = content.getComponentByReference(componentName);
			if (contentComponent instanceof ShortTextComponent) {
				data = ((ShortTextComponent)contentComponent).getText();								
			} else if (contentComponent instanceof TextComponent) {
				data = ((TextComponent)contentComponent).getText();								
			} else if (contentComponent instanceof RichTextComponent) {
				data = ((RichTextComponent)contentComponent).getRichText();
			}
		} catch (ComponentNotFoundException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ? HtmlConverter.escapeJSON(clearHTMLTags(data)) : data;
	}

	
	private String encode(String string, String format) {
//		return (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ? JSONObject.quote(string) : "<![CDATA[" + string + "]]>";
		return (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ? (string != null) ? string : "" : "<![CDATA[" + ((string != null) ? string : "") + "]]>";
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private void logger(String string) {		
		if (debug) {
			System.out.println(string);
		}
	}

}
