package com.wcmprovider.egov.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.json.XML;

import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.Category;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentTypes;
import com.wcmprovider.egov.EgovWCMCacheLoaderManagement;

@WebServlet("/taxonomy")
public class Taxonomy extends HttpServlet {
	private static final String PARAMETER_FORMAT = "format";
	private static final String PARAMETER_DATA = "data";
	private static final String PARAMETER_TYPE_PLAIN = "plain";
	private static final String PARAMETER_TYPE_JSON = "json";
	private static final String PARAMETER_TYPE_SEPARATOR = "separator";
	private static final String PARAMETER_SKIP_CURRENT = "skipcurrent";
	private static final String PARAMETER_PATH = "path";
	private static final String PARAMETER_ID = "id";
	private static final String PARAMETER_MODE = "mode";
	private static final String PARAMETER_MODE_ALL_CHILDREN = "allchildren";
	private static final String PARAMETER_MODE_DIRECT_CHILDREN = "directchildren";
	private static final String PARAMETER_DEBUG = "debug";
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	private static final long serialVersionUID = 1L;
	private static boolean debug = false;

	public Taxonomy() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		long currentTime = System.currentTimeMillis();
		System.out.println("START");
		String data = request.getParameter(PARAMETER_DATA);
		debug = "true".equalsIgnoreCase(request.getParameter(PARAMETER_DEBUG));
		if (PARAMETER_TYPE_PLAIN.equals(data)) {
			servePlain(request, response);
		} else {
			serveTree(request, response);
		}
		System.out.println("END [" + ((float) ((System.currentTimeMillis() - currentTime) / 1000)) + "s]");
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void servePlain(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");
		StringBuffer xml = new StringBuffer();
		xml.append("<?xml version=\"1.0\" encoding=\"utf8\" standalone=\"yes\"?>");
		xml.append("<taxonomy>");

		String separator = request.getParameter(PARAMETER_TYPE_SEPARATOR);
		String format = request.getParameter(PARAMETER_FORMAT);

		if (debug) {
			logger(PARAMETER_TYPE_SEPARATOR + "=" + separator);
			logger(PARAMETER_FORMAT + "=" + format);
		}

		DocumentId rootTaxonomy = null;
		try {
			// No cache for now, we always reload here, but ONLY for "services taxonomy"!
			EgovWCMCacheLoaderManagement cacheManagement = new EgovWCMCacheLoaderManagement();
			cacheManagement.populateCacheWithWCMServiceTaxonomyData(true);
			rootTaxonomy = EgovWCMCache.getServicesTaxonomy();
		} catch (Exception e) {
			logger("EXCEPTION IN EgovWCMCache.getServicesTaxonomy()!");
			EgovWCMCacheLoaderManagement cacheManagement = new EgovWCMCacheLoaderManagement();
			cacheManagement.reloadCache(getServletContext());
			try {
				rootTaxonomy = EgovWCMCache.getServicesTaxonomy();
			} catch (Exception e2) {
				logger(e2.getMessage());
				e2.printStackTrace();
			}
		}
		if (rootTaxonomy != null) {
			try {
				HashMap<String, Category> categoryNameByDocId = new HashMap<>();
				com.ibm.workplace.wcm.api.Taxonomy taxonomy = (com.ibm.workplace.wcm.api.Taxonomy) EgovWCMCache
						.getWorkspace().getById(rootTaxonomy);
				if (taxonomy != null) {
//					MAIN TAXONOMY SHOULD NOT BE OUTPUTED!!!					
//					xml.append("<category>" + taxonomy.getTitle() + "</category>");
					ArrayList<DocumentId> catIds = EgovWCMCache.getServicesTaxonomyChildren();
					Category childCategory = null;
					String categoryPath = "";
					if (catIds != null) {
						for (int i = 0; i < catIds.size(); i++) {
							childCategory = (Category) EgovWCMCache.getWorkspace().getById(catIds.get(i));
							if (childCategory != null) {
								categoryPath = getCategoryPath(childCategory, categoryNameByDocId, taxonomy, separator);
								if (categoryPath.startsWith("/")) {
									categoryPath = categoryPath.substring(1);
								}
								xml.append("<category>" + categoryPath + "</category>");
								categoryNameByDocId.put(childCategory.getId().toString(), childCategory);
							}
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			logger("rootTaxonomy is NULL!");
		}
		xml.append("</taxonomy>");
		if (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) {
			response.setContentType("application/json; charset=UTF-8");
			JSONObject xmlJSONObj = XML.toJSONObject(xml.toString());
			String jsonPrettyPrintString = xmlJSONObj.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			response.getWriter().print(jsonPrettyPrintString);
		} else {
			response.setContentType("text/xml; charset=UTF-8");
			response.getWriter().print(xml.toString());
		}
		response.getWriter().flush();
		response.getWriter().close();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void serveTree(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");
		StringBuffer xml = new StringBuffer();
		xml.append("<?xml version=\"1.0\" encoding=\"utf8\" standalone=\"yes\"?>");
		xml.append("<taxonomy>");

		String format = request.getParameter(PARAMETER_FORMAT);
		String path = request.getParameter(PARAMETER_PATH);
		String id = request.getParameter(PARAMETER_ID);
		String mode = request.getParameter(PARAMETER_MODE);
		boolean skipCurrent = "true".equalsIgnoreCase(request.getParameter(PARAMETER_SKIP_CURRENT));
//		System.out.println("path=" + path);				

		if (debug) {
			logger(PARAMETER_FORMAT + "=" + format);
			logger(PARAMETER_PATH + "=" + path);
			logger(PARAMETER_ID + "=" + id);
			logger(PARAMETER_MODE + "=" + mode);
			logger("skipCurrent=" + skipCurrent);
		}
		try {
			if (id != null && id.trim().length() > 0) {
				logger("id=" + id);
				DocumentId documentId = EgovWCMCache.getWorkspace().createDocumentId(id);
				com.ibm.workplace.wcm.api.Taxonomy taxonomy = null;
				Category category = null;
				if (documentId != null) {
					if ((documentId.getType()).isOfType(DocumentTypes.Taxonomy)) {
						taxonomy = (com.ibm.workplace.wcm.api.Taxonomy) EgovWCMCache.getWorkspace().getById(documentId);
						xml.append(getTaxonomyChildren("", taxonomy, mode, skipCurrent, format));
					} else if ((documentId.getType()).isOfType(DocumentTypes.Category)) {
						category = (Category) EgovWCMCache.getWorkspace().getById(documentId);
						xml.append(getCategoryChildren("", category, mode, skipCurrent, format));
					}
				}
			} else if (path != null && path.trim().length() > 0) {
				logger("path=" + path);
				String[] parts = path.split("/");
				if (parts.length > 0) {
					DocumentIdIterator docIdIter = EgovWCMCache.getWorkspace().findByName(DocumentTypes.Taxonomy,
							parts[0].toLowerCase());
					com.ibm.workplace.wcm.api.Taxonomy taxonomy = null;
					DocumentId docId = null;
					while (docIdIter.hasNext()) {
						docId = docIdIter.next();
						taxonomy = (com.ibm.workplace.wcm.api.Taxonomy) EgovWCMCache.getWorkspace().getById(docId);
						break;
					}
					if (taxonomy != null) {
						com.ibm.workplace.wcm.api.Category category = null;
						if (parts.length > 1) { // search for category
							category = getCategoryByPath(taxonomy, parts);
							if (category != null) {
								xml.append(getCategoryChildren("", category, mode, skipCurrent, format));//
							}
						} else { // search for taxonomy
							xml.append(getTaxonomyChildren("", taxonomy, mode, skipCurrent, format));
						}

					}
				}
			} else {
				logger("else");
				DocumentId rootTaxonomy = null;
				try {
					rootTaxonomy = EgovWCMCache.getServicesTaxonomy();
				} catch (Exception e) {
					logger("EXCEPTION IN EgovWCMCache.getServicesTaxonomy()!");
					EgovWCMCacheLoaderManagement cacheManagement = new EgovWCMCacheLoaderManagement();
					cacheManagement.reloadCache(getServletContext());
					try {
						rootTaxonomy = EgovWCMCache.getServicesTaxonomy();
					} catch (Exception e2) {
						logger(e2.getMessage());
						e2.printStackTrace();
					}
				}
				if (rootTaxonomy != null) {
					com.ibm.workplace.wcm.api.Taxonomy taxonomy = (com.ibm.workplace.wcm.api.Taxonomy) EgovWCMCache
							.getWorkspace().getById(rootTaxonomy);
					if (taxonomy != null) {
//						MAIN TAXONOMY SHOULD NOT BE OUTPUTED!!!
//						xml.append("<category>");
//						xml.append("<id>" + encode(taxonomy.getId().getId(), format) + "</id>");
//						xml.append("<name>" + encode(taxonomy.getName(), format) + "</name>");
//						xml.append("<title>" + encode(taxonomy.getTitle(), format) + "</title>");
						ArrayList<DocumentId> catIds = EgovWCMCache.getServicesTaxonomyChildrenByParentIdHm()
								.get(taxonomy.getId().getId());
						Category childCategory = null;
						if (catIds != null) {
							for (int i = 0; i < catIds.size(); i++) {
								childCategory = (Category) EgovWCMCache.getWorkspace().getById(catIds.get(i));
								xml.append("<category>");
								xml.append("<id>" + encode(childCategory.getId().getId(), format) + "</id>");
								xml.append("<name>" + encode(childCategory.getName(), format) + "</name>");
								xml.append("<title>" + encode(childCategory.getTitle(), format) + "</title>");
								xml.append(getAllChildren("", childCategory, null, null, format));
								xml.append("</category>");
							}
						}
//						xml.append("</category>");
					} else {
						logger("taxonomy is NULL!");
					}
				} else {
					logger("rootTaxonomy is NULL!");
				}
			}
		} catch (Exception e) {
			logger(e.getMessage());
			e.printStackTrace();
		}
		xml.append("</taxonomy>");
		if (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) {
			response.setContentType("application/json; charset=UTF-8");
			JSONObject xmlJSONObj = XML.toJSONObject(xml.toString());
			String jsonPrettyPrintString = xmlJSONObj.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			response.getWriter().print(jsonPrettyPrintString);
		} else {
			response.setContentType("text/xml; charset=UTF-8");
			response.getWriter().print(xml.toString());
		}
		response.getWriter().flush();
		response.getWriter().close();
	}

	private String getCategoryPath(Category category, HashMap<String, Category> categoryNameByDocId,
			com.ibm.workplace.wcm.api.Taxonomy rootTaxonomy, String separator) {
		String categoryPath = "";
		Category tmpCategory = categoryNameByDocId.get(category.getParentId().toString());
		if (tmpCategory != null) {
			while (tmpCategory != null) {
				categoryPath = ((separator != null) ? separator : "/") + tmpCategory.getTitle() + categoryPath;
				tmpCategory = categoryNameByDocId.get(tmpCategory.getParentId().toString());
			}
		}
//		MAIN TAXONOMY SHOULD NOT BE OUTPUTED!!!				
//		return rootTaxonomy.getTitle() + categoryPath + ((separator != null) ? separator : "/") + category.getTitle();		
		return categoryPath + ((separator != null) ? separator : "/") + category.getTitle();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Category getCategoryByPath(com.ibm.workplace.wcm.api.Taxonomy taxonomy, String[] path) {
		Category category = null;
		DocumentIdIterator docIdIter = taxonomy.getChildren();
		int index = 1;
		if (docIdIter.hasNext()) {
			Category tmpCategory = null;
			while (docIdIter.hasNext()) {
				try {
					tmpCategory = (Category) EgovWCMCache.getWorkspace().getById(docIdIter.next());
					if (path.length > index) {
//						System.out.println("tmpCategory.getName()=" + tmpCategory.getName() + " " + path[index]);
						if (tmpCategory.getName().equalsIgnoreCase(path[index])) {
							category = tmpCategory;
							index++;
							if (path.length > index) {
								docIdIter = tmpCategory.getChildren();
							} else {
								break;
							}
						}
					} else {
						break;
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return category;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	private String getAllChildren(String xml, Category childCategory, ArrayList<DocumentId> categoriesIds,
			Category subChildCategory, String format) {
		categoriesIds = EgovWCMCache.getServicesTaxonomyChildrenByParentIdHm().get(childCategory.getId().getId());
		subChildCategory = null;
		if (categoriesIds != null) {
			for (int i = 0; i < categoriesIds.size(); i++) {
				try {
					subChildCategory = (Category) EgovWCMCache.getWorkspace().getById(categoriesIds.get(i));
					xml += "<category>";
					xml += "<id>" + encode(subChildCategory.getId().getId(), format) + "</id>";
					xml += "<name>" + encode(subChildCategory.getName(), format) + "</name>";
					xml += "<title>" + encode(subChildCategory.getTitle(), format) + "</title>";
					xml = getAllChildren(xml, subChildCategory, null, null, format);
					xml += "</category>";
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return xml;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private String getTaxonomyChildren(String xml, com.ibm.workplace.wcm.api.Taxonomy taxonomy, String mode,
			boolean skipCurrent, String format) {
		if (!skipCurrent) {
			xml += "<category>";
			xml += "<id>" + encode(taxonomy.getId().getId(), format) + "</id>";
			xml += "<name>" + encode(taxonomy.getName(), format) + "</name>";
			xml += "<title>" + encode(taxonomy.getTitle(), format) + "</title>";
		}
		if (PARAMETER_MODE_DIRECT_CHILDREN.equals(mode) || PARAMETER_MODE_ALL_CHILDREN.equals(mode)) {
			DocumentIdIterator docIdIter = (PARAMETER_MODE_DIRECT_CHILDREN.equals(mode)) ? taxonomy.getChildren()
					: taxonomy.getAllChildren();
			Category tmpCategory = null;
			while (docIdIter.hasNext()) {
				try {
					tmpCategory = (com.ibm.workplace.wcm.api.Category) EgovWCMCache.getWorkspace()
							.getById(docIdIter.next());
					xml += "<category>";
					xml += "<id>" + encode(tmpCategory.getId().getId(), format) + "</id>";
					xml += "<name>" + encode(tmpCategory.getName(), format) + "</name>";
					xml += "<title>" + encode(tmpCategory.getTitle(), format) + "</title>";
					xml += "</category>";
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		if (!skipCurrent) {
			xml += "</category>";
		}
		return xml;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private String getCategoryChildren(String xml, Category category, String mode, boolean skipCurrent, String format) {
		if (!skipCurrent) {
			xml += "<category>";
			xml += "<id>" + encode(category.getId().getId(), format) + "</id>";
			xml += "<name>" + encode(category.getName(), format) + "</name>";
			xml += "<title>" + encode(category.getTitle(), format) + "</title>";
		}
		if (PARAMETER_MODE_DIRECT_CHILDREN.equals(mode) || PARAMETER_MODE_ALL_CHILDREN.equals(mode)) {
			DocumentIdIterator docIdIter = (PARAMETER_MODE_DIRECT_CHILDREN.equals(mode)) ? category.getChildren()
					: category.getAllChildren();
			Category tmpCategory = null;
			while (docIdIter.hasNext()) {
				try {
					tmpCategory = (com.ibm.workplace.wcm.api.Category) EgovWCMCache.getWorkspace()
							.getById(docIdIter.next());
					xml += "<category>";
					xml += "<id>" + encode(tmpCategory.getId().getId(), format) + "</id>";
					xml += "<name>" + encode(tmpCategory.getName(), format) + "</name>";
					xml += "<title>" + encode(tmpCategory.getTitle(), format) + "</title>";
					xml += "</category>";
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		if (!skipCurrent) {
			xml += "</category>";
		}
		return xml;
	}

	private String encode(String string, String format) {
		// return (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ?
		// JSONObject.quote(string) : "<![CDATA[" + string + "]]>";
		return (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ? string : "<![CDATA[" + string + "]]>";
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	private void logger(String string) {
		if (debug) {
			System.out.println(string);
		}
	}

}
