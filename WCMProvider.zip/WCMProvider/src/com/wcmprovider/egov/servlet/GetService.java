package com.wcmprovider.egov.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.json.XML;

import com.egov.wcm.cache.EgovServiceProvider;
import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.Category;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.ContentComponent;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentLibrary;
import com.ibm.workplace.wcm.api.DocumentTypes;
import com.ibm.workplace.wcm.api.LinkComponent;
import com.ibm.workplace.wcm.api.OptionSelectionComponent;
import com.ibm.workplace.wcm.api.RichTextComponent;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.TextComponent;
import com.ibm.workplace.wcm.api.Workspace;
import com.ibm.workplace.wcm.api.exceptions.ComponentNotFoundException;
import com.ibm.workplace.wcm.api.query.Conjunction;
import com.ibm.workplace.wcm.api.query.Disjunction;
import com.ibm.workplace.wcm.api.query.ProfileSelectors;
import com.ibm.workplace.wcm.api.query.Query;
import com.ibm.workplace.wcm.api.query.QueryDepth;
import com.ibm.workplace.wcm.api.query.ResultIterator;
import com.ibm.workplace.wcm.api.query.Selectors;
import com.ibm.workplace.wcm.api.query.SortDirection;
import com.ibm.workplace.wcm.api.query.Sorts;
import com.ibm.workplace.wcm.api.query.WorkflowSelectors;
import com.wcmprovider.egov.Constants;
import com.wcmprovider.egov.util.HtmlConverter;


@WebServlet("/get-service")
public class GetService extends HttpServlet {
	private static final String PARAMETER_FORMAT = "format";
	private static final String PARAMETER_TYPE_JSON = "json";	
	private static final String PARAMETER_ID = "id";
	private static final String PARAMETER_NUMBER = "number";
	private static final String PARAMETER_SHOW_INACTIVE = "showInActive";
	private static final String PARAMETER_DEBUG = "debug";	
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	private static final long serialVersionUID = 1L;
	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.ENGLISH);
	private static boolean debug = false;

	public GetService() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		debug = "true".equalsIgnoreCase(request.getParameter(PARAMETER_DEBUG));
		
		getContents(request, response);
	}

	@SuppressWarnings({ "rawtypes" })
	private void getContents(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");		
		String id = request.getParameter(PARAMETER_ID);
		String number = request.getParameter(PARAMETER_NUMBER);
		String format = request.getParameter(PARAMETER_FORMAT);
		boolean showInActive = "true".equalsIgnoreCase(request.getParameter(PARAMETER_SHOW_INACTIVE));
		boolean isProd = "PROD".equalsIgnoreCase(System.getProperty("environment"));
		String host = isProd ? "https://egov.bg" : "https://staging.egov.bg";
		
		logger("debug=" + debug);
		logger("id=" + id);
		logger("number=" + number);
		logger("format=" + format);
		
		StringBuffer xml = new StringBuffer();
		xml.append("<?xml version=\"1.0\" encoding=\"utf8\" standalone=\"yes\"?>");
		xml.append("<services>");		
	
		String data = id != null && id.trim().length() > 0 ? id.trim() : number;
		boolean modeIsId = id != null && id.trim().length() > 0;
		if (data != null && data.trim().length() > 0) { // id(s), number(s)
			try {
				String[] sericesIds = data.split(",");
				ArrayList<String> filterName = null;
				ArrayList<DocumentId> filterId = null;
				if (!modeIsId) { // we are passing service number(s).
					filterName = new ArrayList<String>();
					for (int i = 0; i < sericesIds.length; i++) {
						filterName.add(sericesIds[i]);
					}
				} else {
					filterId = new ArrayList<>();
					DocumentId tmpDocId = null;
					for (int i = 0; i < sericesIds.length; i++) {
						tmpDocId = EgovWCMCache.getWorkspace().createDocumentId(sericesIds[i]);
						if (tmpDocId != null) {
							filterId.add(tmpDocId);
						}
					}	
				}
				Query query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
				Conjunction and = new Conjunction();
				// filter by library.
				and.add(Selectors.libraryEquals(EgovWCMCache.getWorkspace().getDocumentLibrary(Constants.EGOV_CONTENT_LIBRARY_NAME)));

				if (modeIsId) {
					// filter by id.				
					and.add(Selectors.idIn(filterId));
				} else {
					// filter by name.				
					and.add(Selectors.nameIn(filterName));					
				}

				// filter by 'Published' only.
				and.add(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
				
				// filter by services AT ONLY.
				and.add(
						Selectors.authoringTemplateIn(
							new DocumentId[] {
								EgovWCMCache.getATServiceProvidedBySupplier().getId(),
								EgovWCMCache.getATUnifiedService().getId()
							}
						)
				);
				if (!showInActive) {
					// Show ONLY 'active'.
					// load only 'active' services.			
					Disjunction or = new Disjunction();
					or.add(ProfileSelectors.categoriesContains(EgovWCMCache.getCategoryCommonActive().getId()));
					or.add(ProfileSelectors.categoriesContains(EgovWCMCache.getCategoryServiceStatusActive().getId()));
					and.add(or);
				}
				query.addSelector(and);	
				query.returnObjects();
				ResultIterator resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);
			    if (resultIterator.hasNext()) {
			    	Content service = null;
			    	while (resultIterator.hasNext()) {
						service = (Content) resultIterator.next();
						// Serve content data.
						xml.append(buildServiceContentData(service, format));						
					}
			    }
			} catch (Exception e) {
				e.printStackTrace();
			}
		} 
		xml.append("</services>");
		String xmlResonseString = xml.toString();
		// Replace all "/myconnect/" references.
		xmlResonseString = xmlResonseString.replaceAll("/wcm/myconnect/", "/wcm/connect/");
		xmlResonseString = xmlResonseString.replaceAll("href=\"/wps/wcm/", "href=\"" + host + "/wps/wcm/");
		
		if (PARAMETER_TYPE_JSON.equalsIgnoreCase(request.getParameter(PARAMETER_FORMAT))) {
			response.setContentType("application/json; charset=UTF-8");
			JSONObject xmlJSONObj = XML.toJSONObject(xmlResonseString);
			String jsonPrettyPrintString = xmlJSONObj.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			response.getWriter().print(jsonPrettyPrintString);
		} else {
			response.setContentType("text/xml; charset=UTF-8");
			response.getWriter().print(xmlResonseString);
		}
		response.getWriter().flush();
		response.getWriter().close();
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private String buildServiceContentData(Content content, String format) {
		logger("buildServiceContentData IN");
		if (content == null) return "";						
		StringBuffer xml = new StringBuffer();
		String field = null;
		xml.append("<service>");
		xml.append("<id>" + encode(content.getId().getId(), format) + "</id>");		
		xml.append("<shortName>" + encode(content.getTitle(), format) + "</shortName>");	
		xml.append("<serviceNumber>" + encode(getTextFromComponent(content, EgovWCMCache.SERVICE_FIELD_SERVICE_NUMBER_NAME, format), format) + "</serviceNumber>");	
		xml.append("<serviceName>" + encode(getTextFromComponent(content, EgovWCMCache.SERVICE_FIELD_SERVICE_NAME_NAME, format), format) + "</serviceName>");
		Category category = getCategoryFromComponentOption(content, EgovWCMCache.SERVICE_FIELD_IS_INTERNAL_ADMIN_SERVICE_NAME);
		if (category != null) {
			xml.append("<isInternalAdminService>" + encode(category.getTitle(), format) + "</isInternalAdminService>");
		}
		category = getCategoryFromComponentOption(content, EgovWCMCache.SERVICE_FIELD_SECURITY_LEVEL_NAME);
		if (category != null) {
			xml.append("<securityLevel>" + encode(category.getTitle(), format) + "</securityLevel>");
		}
		Category[] categories = getCategoriesFromComponentOption(content, EgovWCMCache.SERVICE_FIELD_IDENTIFICATION_METHOD_NAME);
		if (categories != null && categories.length > 0) {
			xml.append("<identificationMethods>");
			for (int i = 0; i < categories.length; i++) {
				xml.append("<identificationMethod>" + encode(categories[i].getTitle(), format) + "</identificationMethod>");
			}
			xml.append("</identificationMethods>");
		}	
		xml.append("<regulatoryAct>" + encode(getTextFromComponent(content, EgovWCMCache.SERVICE_FIELD_REGULATORY_ACT_NAME, format), format) + "</regulatoryAct>");
		category = getCategoryFromComponentOption(content, EgovWCMCache.SERVICE_FIELD_LANGUAGE_NAME);
		if (category != null) {
			xml.append("<language>" + encode(category.getTitle(), format) + "</language>");
		}
		xml.append("<oid>" + encode(getTextFromComponent(content, EgovWCMCache.SERVICE_FIELD_OID_NAME, format), format) + "</oid>");
		xml.append("<serviceDescription>" + encode(getTextFromComponent(content, EgovWCMCache.SERVICE_FIELD_SERVICE_DESCRIPTION_NAME, format), format) + "</serviceDescription>");
		categories = getCategoriesFromComponentOption(content, EgovWCMCache.SERVICE_FIELD_POSSIBLE_WAYS_TO_APPLY_NAME);
		if (categories != null && categories.length > 0) {
			xml.append("<possibleWaysToApply>");
			for (int i = 0; i < categories.length; i++) {
				xml.append("<possibleWay>" + encode(categories[i].getTitle(), format) + "</possibleWay>");
			}
			xml.append("</possibleWaysToApply>");
		}
		xml.append("<onlineApplicationDescription>" + encode(getTextFromComponent(content, EgovWCMCache.SERVICE_FIELD_ONLINE_APPLICATION_DESCRIPTION_NAME, format), format) + "</onlineApplicationDescription>");
		if (hasComponent(content, EgovWCMCache.SERVICE_FIELD_PROVISION_E_ADDRESS_NAME)) { // not for unified services.
			xml.append("<provisionEAddress>" + encode(getTextFromComponent(content, EgovWCMCache.SERVICE_FIELD_PROVISION_E_ADDRESS_NAME, format), format) + "</provisionEAddress>");
		}
		xml.append("<eauApplicationFormLink>" + encode(getTextFromComponentLink(content, EgovWCMCache.SERVICE_FIELD_EAU_APPLICATION_FORM_LINK_NAME, format), format) + "</eauApplicationFormLink>");
		xml.append("<prepareInAdvance>" + encode(getTextFromComponent(content, EgovWCMCache.SERVICE_FIELD_PREPARE_IN_ADVANCE_NAME, format), format) + "</prepareInAdvance>");
		xml.append("<applicationForm>" + encode(getTextFromComponent(content, EgovWCMCache.SERVICE_FIELD_APPLICATION_FORM_NAME, format), format) + "</applicationForm>");
		xml.append("<terms>" + encode(getTextFromComponent(content, EgovWCMCache.SERVICE_FIELD_TERMS_NAME, format), format) + "</terms>");
		if (hasComponent(content, EgovWCMCache.SERVICE_FIELD_PAYMENT_INFO_NAME)) { // not for unified services.
			xml.append("<paymentInfo>" + encode(getTextFromComponent(content, EgovWCMCache.SERVICE_FIELD_PAYMENT_INFO_NAME, format), format) + "</paymentInfo>");
		}
		xml.append("<result>" + encode(getTextFromComponent(content, EgovWCMCache.SERVICE_FIELD_RESULT_NAME, format), format) + "</result>");
		categories = getCategoriesFromComponentOption(content, EgovWCMCache.SERVICE_FIELD_POSSIBLE_WAYS_TO_RECEIVE_NAME);
		if (categories != null && categories.length > 0) {
			xml.append("<possibleWaysToReceive>");
			for (int i = 0; i < categories.length; i++) {
				xml.append("<possibleWay>" + encode(categories[i].getTitle(), format) + "</possibleWay>");
			}
			xml.append("</possibleWaysToReceive>");
		}
		xml.append("<administrationAuthority>" + encode(getTextFromComponent(content, EgovWCMCache.SERVICE_FIELD_ADMINISTRATION_AUTHORITY_NAME, format), format) + "</administrationAuthority>");
		categories = getCategoriesFromComponentOption(content, EgovWCMCache.SERVICE_FIELD_CLASSIFICATION_NAME);
		if (categories != null && categories.length > 0) {
			xml.append("<classification>");
			for (int i = 0; i < categories.length; i++) {
				xml.append("<category>" + encode(categories[i].getTitle(), format) + "</category>");
			}
			xml.append("</classification>");
		}
		if (hasComponent(content, EgovWCMCache.SERVICE_FIELD_SERVICE_SUPPLIER_NAME)) { // not for unified services.
			field = getTextFromComponent(content, EgovWCMCache.SERVICE_FIELD_SERVICE_SUPPLIER_NAME, format);
			if (field != null) {
				EgovServiceProvider serviceProvider = EgovWCMCache.getServiceProviderById(field);
				if (serviceProvider != null) {
					xml.append("<serviceSupplier>" + encode(serviceProvider.getTitle(), format) + "</serviceSupplier>");
				}
			}
		}
		// Comment for now.
		//xml.append("<administrativeSupplyUnitsRT>" + encode(getTextFromComponent(content, EgovWCMCache.SERVICE_FIELD_ADMINISTRATIVE_SUPPLY_UNITS_NAME, format), format) + "</administrativeSupplyUnitsRT>");
		try {
			// Parse data from RT field.
			xml.append("<administrativeSupplyUnits>");
			String administrativeSupplyUnitsRT = getTextFromComponent(content, EgovWCMCache.SERVICE_FIELD_ADMINISTRATIVE_SUPPLY_UNITS_NAME, null);
			if (administrativeSupplyUnitsRT != null && administrativeSupplyUnitsRT.trim().length() > 0) {
				xml.append(buildAdministrativeSupplyUnitsData(administrativeSupplyUnitsRT, format));
			}
			xml.append("</administrativeSupplyUnits>");
		} catch (Exception e) {
			e.printStackTrace();
		}
		xml.append("<administrativeInfoUnits>" + encode(getTextFromComponent(content, EgovWCMCache.SERVICE_FIELD_ADMINISTRATIVE_INFO_UNITS_NAME, format), format) + "</administrativeInfoUnits>");
		category = getCategoryFromComponentOption(content, EgovWCMCache.SERVICE_FIELD_SECTION_NAME_AR_NAME);
		if (category != null) {
			xml.append("<sectionNameAR>" + encode(category.getTitle(), format) + "</sectionNameAR>");
		}
		
		try {
			// Load suppliers for unified services ONLY.
			if (EgovWCMCache.getATUnifiedService().getId().getId().equalsIgnoreCase(content.getAuthoringTemplateID().getId())) {
				category = getCategoryFromComponentOption(content, EgovWCMCache.SERVICE_FIELD_SECTION_NAME_AR_NAME);
				// Render "suppliers", except for services provided by all administrations.
				if (category != null && !EgovWCMCache.CATEGORY_ADM_SECTION_NAME_ALL_ADMINISTRATIONS_NAME.equalsIgnoreCase(category.getName())) {
					Content supplier = null;
			    	DocumentId siteArea = null;
			    	DocumentIdIterator iterator = null;
			    	ResultIterator resultIterator = null;
			    	EgovServiceProvider serviceProvider = null;
			    	List<EgovServiceProvider> serviceProviders = EgovWCMCache.getServiceProviders();
					String path = EgovWCMCache.getWorkspace().getPathById(content.getId(), false, true);
					if (path.toLowerCase().startsWith(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME.toLowerCase())) {
						path = path.substring(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME.length());
					}
					// Get target siteArea.								
					iterator = EgovWCMCache.getWorkspace().findAllByPath(path + EgovWCMCache.SERVICES_SITE_AREA_NAME_UNIFIED_SERVICE_SUFFIX, DocumentTypes.SiteArea, Workspace.WORKFLOWSTATUS_PUBLISHED, new DocumentLibrary[] { EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)});
					if (iterator.hasNext()) { // Site area found.									
						siteArea = iterator.next();
						Query query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
						query.addParentId(siteArea, QueryDepth.CHILDREN);
						query.addSort(Sorts.byTitle(SortDirection.ASCENDING));
						query.returnObjects();
						resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);
						if (resultIterator.hasNext()) {
							xml.append("<suppliers>");
							while (resultIterator.hasNext()) {
								supplier = (Content)resultIterator.next();
								if (supplier != null) {
									serviceProvider = getServiceProvider(serviceProviders, supplier.getName());
									xml.append(buildSupplierContentData(supplier, serviceProvider, format));
								}
							}
							xml.append("</suppliers>");
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			Date date = content.getModifiedDate();		
			if (date != null) {
				xml.append("<modifiedDate>" + encode(dateFormat.format(date), format) + "</modifiedDate>");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		xml.append("</service>");
		logger("buildServiceContentData OUT");
		return xml.toString();
	}
	
	private String buildAdministrativeSupplyUnitsData(String administrativeSupplyUnitsText, String format) {
		if (administrativeSupplyUnitsText == null || administrativeSupplyUnitsText.trim().length() == 0) return null;
		String[] supplyUnits = administrativeSupplyUnitsText.split("<p dir=\"ltr\">&nbsp;</p>");
		if (supplyUnits != null && supplyUnits.length == 1) {
			supplyUnits = administrativeSupplyUnitsText.split("<p>&nbsp;</p>");
		}
		String unit = null;
		String substring = null;
		String name = null;
		String address = null;
		String interSettlementCallingCode = null;
		String[] phones = null;
		String faxNumber = null;
		String email = null;
		String webSiteUrl = null;
		String workingTime = null;
		StringBuffer xml = new StringBuffer();
		StringBuffer xmlUnit = null;
		int pos = -1;
		for (int i = 0; i < supplyUnits.length; i++) {
			unit = supplyUnits[i];
			xmlUnit = new StringBuffer();
			xmlUnit.append("<administrativeSupplyUnit>");
			pos = unit.indexOf("<div class=\"adm-supply-unit-data-name\">");
			if (pos != -1) {
				substring = unit.substring(pos + "<div class=\"adm-supply-unit-data-name\">".length());
				pos = substring.indexOf("</div>");
				if (pos != -1) {
					name = substring.substring(0, pos).trim();
				}
			}
			xmlUnit.append("<name>" + (name != null ? encode(name, format) : "") + "</name>");
			pos = unit.indexOf("data-name=\"address\">Адрес:</span>");
			if (pos != -1) {
				substring = unit.substring(pos + "data-name=\"address\">Адрес:</span>".length());
				pos = substring.indexOf("</div>");
				if (pos != -1) {
					address = convertAddressStringToXML(substring.substring(0, pos), format).trim();
									
				}
			}
			xmlUnit.append("<address>" + (address != null ? address : "") + "</address>");
			pos = unit.indexOf("data-name=\"interSettlementCallingCode\">Код за междуселищно избиране:</span>");
			if (pos != -1) {
				substring = unit.substring(pos + "data-name=\"interSettlementCallingCode\">Код за междуселищно избиране:</span>".length());
				pos = substring.indexOf("</div>");
				if (pos != -1) {
					interSettlementCallingCode = substring.substring(0, pos).trim();
					
				}
			}
			xmlUnit.append("<interSettlementCallingCode>" + (interSettlementCallingCode != null ? encode(interSettlementCallingCode, format) : "") + "</interSettlementCallingCode>");
			pos = unit.indexOf("data-name=\"phone\">Телефон за връзка:</span>");
			if (pos != -1) {
				substring = unit.substring(pos + "data-name=\"phone\">Телефон за връзка:</span>".length());
				pos = substring.indexOf("</div>");
				if (pos != -1) {
					phones = substring.substring(0, pos).trim().split(",");
									
				}
			}
			xmlUnit.append("<phones>");
				if (phones != null && phones.length > 0) {
				for(int z = 0; z < phones.length; z++) {
					xmlUnit.append("<phone>" + encode(phones[z], format) + "</phone>");
				}
			}
			xmlUnit.append("</phones>");
			pos = unit.indexOf("data-name=\"faxNumber\">Факс:</span>");
			if (pos != -1) {
				substring = unit.substring(pos + "data-name=\"faxNumber\">Факс:</span>".length());
				pos = substring.indexOf("</div>");
				if (pos != -1) {
					faxNumber = substring.substring(0, pos).trim();
					
				}
			}
			xmlUnit.append("<faxNumber>" + (faxNumber != null ? encode(faxNumber, format) : "") + "</faxNumber>");
			pos = unit.indexOf("data-name=\"email\">Адрес на електронна поща:</span>");
			if (pos != -1) {
				substring = unit.substring(pos + "data-name=\"email\">Адрес на електронна поща:</span>".length());
				pos = substring.indexOf("</div>");
				if (pos != -1) {
					email = substring.substring(0, pos).trim();
					
				}
			}
			xmlUnit.append("<email>" + (email != null ? encode(email, format) : "") + "</email>");
			pos = unit.indexOf("data-name=\"webSiteUrl\">");
			if (pos != -1) {
				substring = unit.substring(pos + "data-name=\"webSiteUrl\">".length());
				pos = substring.indexOf("</a>");
				if (pos != -1) {
					webSiteUrl = substring.substring(0, pos).trim();
					
				}
			}
			xmlUnit.append("<webSiteUrl>" + (webSiteUrl != null ? encode(webSiteUrl, format) : "") + "</webSiteUrl>");
			pos = unit.indexOf("data-name=\"workingTime\">Работно време:</span>");
			if (pos != -1) {
				substring = unit.substring(pos + "data-name=\"workingTime\">Работно време:</span>".length());
				pos = substring.indexOf("</div>");
				if (pos != -1) {
					workingTime = substring.substring(0, pos).trim();
					
				}
			}
			xmlUnit.append("<workingTime>" + (workingTime != null ? encode(workingTime, format) : "") + "</workingTime>");
			xmlUnit.append("</administrativeSupplyUnit>");
			if (name != null || address != null || interSettlementCallingCode != null 
					|| (phones != null && phones.length > 0) || faxNumber != null 
					|| email != null || webSiteUrl != null || workingTime != null) {
				xml.append(xmlUnit.toString());
			}
		}
		return xml.toString();
	}
	
	private String convertAddressStringToXML(String address, String format) {
		if (address ==  null) return null;
		address = address.trim();
		String xml = "";
		String districtName = "";
		String municipalityName = "";
		String settlementName = "";
		String areaName = "";
		String text = "";
		String postCode = "";
		int pos = -1;
		int pos2 = -1;
		pos = address.lastIndexOf("п.к.");
		if (pos != -1) {
			postCode = address.substring(pos + "п.к.".length()).trim();
			address = address.substring(0, pos).trim();
			if (address.endsWith(",")) {
				address = address.substring(0, address.length() - 1).trim();
			}			
		}
		pos = address.indexOf("обл. ");
		if (pos != -1) {
			pos2 = address.indexOf(", общ.");
			if (pos2 != -1) {
				districtName = address.substring(pos + "обл. ".length(), pos2).trim();
			} else {
				pos2 = address.indexOf(",");
				if (pos2 != -1) {
					districtName = address.substring(pos + "обл. ".length(), pos2).trim();
				} else {
					districtName = address.substring(pos + "обл. ".length()).trim();
				}
			}
			address = address.substring(pos + "обл. ".length() + districtName.length()).trim();
			if (address.startsWith(",")) {
				address = address.substring(1, address.length()).trim();
			}			
		}
		pos = address.indexOf("общ. ");
		if (pos != -1) {
			pos2 = address.indexOf(", гр.");
			if (pos2 != -1) {
				municipalityName = address.substring(pos + "общ. ".length(), pos2).trim();
			} else {
				pos2 = address.indexOf(",");
				if (pos2 != -1) {
					municipalityName = address.substring(pos + "общ. ".length(), pos2).trim();
				} else {
					municipalityName = address.substring(pos + "общ. ".length()).trim();
				}
			}
			address = address.substring(pos + "общ. ".length() + municipalityName.length()).trim();
			if (address.startsWith(",")) {
				address = address.substring(1, address.length()).trim();
			}			
		}
		pos = address.indexOf("гр. ");
		if (pos != -1) {
			pos2 = address.indexOf(", р-н");
			if (pos2 != -1) {
				settlementName = address.substring(pos + "гр. ".length(), pos2).trim();
			} else {
				pos2 = address.indexOf(",");
				if (pos2 != -1) {
					settlementName = address.substring(pos + "гр. ".length(), pos2).trim();
				} else {
					settlementName = address.substring(pos + "гр. ".length()).trim();
				}
			}
			address = address.substring(pos + "гр. ".length() + settlementName.length()).trim();
			if (address.startsWith(",")) {
				address = address.substring(1, address.length()).trim();
			}			
		}
		pos = address.indexOf("р-н ");
		if (pos != -1) {
			pos2 = address.indexOf(",");
			if (pos2 != -1) {
				areaName = address.substring(pos + "р-н ".length(), pos2).trim();			
			} else {
				areaName = address.substring(pos + "р-н ".length()).trim();
				
			}
			address = address.substring(pos + "р-н ".length() + areaName.length()).trim();
			if (address.startsWith(",")) {
				address = address.substring(1, address.length()).trim();
			}			
		}
		if (address.trim().length() > 0) {
			if (address.startsWith(",")) {
				address = address.substring(1, address.length());
			}
			if (address.endsWith(",")) {
				address = address.substring(0, address.length() - 1);
			}
		}
		text = address;
		xml += "<districtName>" + encode(districtName, format) + "</districtName>";
		xml += "<municipalityName>" + encode(municipalityName, format) + "</municipalityName>";
		xml += "<settlementName>" + encode(settlementName, format) + "</settlementName>";
		xml += "<areaName>" + encode(areaName, format) + "</areaName>";
		xml += "<addressText>" + encode(text, format) + "</addressText>";
		xml += "<postCode>" + encode(postCode, format) + "</postCode>";
		return (districtName != null || municipalityName != null || settlementName != null || areaName != null || text != null || postCode != null) ? xml : null;
	}
	
	private EgovServiceProvider getServiceProvider(List<EgovServiceProvider> serviceProviders, String serviceProviderName) {
		if (serviceProviders != null && serviceProviders.size() > 0 && serviceProviderName != null) {
			for (int i = 0; i < serviceProviders.size(); i++) {
				if (serviceProviderName.equalsIgnoreCase(serviceProviders.get(i).getName())) {
					return serviceProviders.get(i);
				}
			}
		}
		return new EgovServiceProvider(); 
	}
	
	private String buildSupplierContentData (Content content, EgovServiceProvider serviceProvider, String format) {
		if (content == null) return "";						
		StringBuffer xml = new StringBuffer();
		logger("buildSupplierContentData IN");
		Category[] paymentMethods = getCategoriesFromComponentOption(content, "paymentMethods");
		xml.append("<supplier>");
		xml.append("<code>" + encode(content.getName(), format) + "</code>");
		xml.append("<eik>" + encode(serviceProvider != null ? serviceProvider.getEik() : "", format) + "</eik>");
		xml.append("<title>" + encode(content.getTitle(), format) + "</title>");
		xml.append("<terms>" + encode(getTextFromComponent(content, "terms", format), format) + "</terms>");
		xml.append("<administrationUnitForInformation>" + encode(getTextFromComponent(content, "administrationUnitForInformation", format), format) + "</administrationUnitForInformation>");
		xml.append("<paymentInfo>" + encode(getTextFromComponent(content, "paymentInfo", format), format) + "</paymentInfo>");
		xml.append("<paymentMethods>");
		if (paymentMethods != null && paymentMethods.length > 0) {
			for (int i = 0; i < paymentMethods.length; i++) {
				xml.append("<paymentMethod>" + encode(paymentMethods[i].getTitle(), format) + "</paymentMethod>");
			}
		}
		xml.append("</paymentMethods>");
		xml.append("<provisionEAddress>" + encode(getTextFromComponent(content, "provisionEAddress", format), format) + "</provisionEAddress>");
		xml.append("</supplier>");
		logger("buildSupplierContentData OUT");
		paymentMethods = null;
		return xml.toString();
	}
	
	private boolean hasComponent(Content content, String elementName) {
		for (int i = 0; i < content.getComponentNames().length; i++) {
			if (content.getComponentNames()[i].equals(elementName))
				return true;
		}
		return false;
	}
	
	private String getTextFromComponent(Content content, String componentName, String format) {
		try {
			if (hasComponent(content, componentName)) {
				ContentComponent contentComponent = content.getComponentByReference(componentName);
				String text = "";
				if (contentComponent instanceof ShortTextComponent) {
					text = ((ShortTextComponent)contentComponent).getText();
				} else if (contentComponent instanceof TextComponent) {
					text = ((TextComponent)contentComponent).getText();
				} else if (contentComponent instanceof RichTextComponent) {
					text = ((RichTextComponent)contentComponent).getRichText();
				}
				return (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ? HtmlConverter.escape(text) : text;
			}
		} catch (ComponentNotFoundException e) {
			e.printStackTrace();
		}
		return "";
	}

	private String getTextFromComponentLink(Content content, String componentName, String format) {
		try {			
			if (hasComponent(content, componentName)) {
				LinkComponent component = (LinkComponent)content.getComponentByReference(componentName);
				if (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) {
					return HtmlConverter.escape(component.getURL());				
				}
				return component.getURL();
			}
		} catch (ComponentNotFoundException e) {
			e.printStackTrace();
		}
		return "";
	}		
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Category getCategoryFromComponentOption(Content content, String componentName) {
		try {
			if (hasComponent(content, componentName)) {
				OptionSelectionComponent contentComponent = (OptionSelectionComponent)content.getComponentByReference(componentName);
				DocumentId[] documentIds = contentComponent.getCategorySelections();
				if (documentIds != null && documentIds.length > 0) {
					return (Category)EgovWCMCache.getWorkspace().getById(documentIds[0]);				
				}			
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Category[] getCategoriesFromComponentOption(Content content, String componentName) {
		try {
			if (hasComponent(content, componentName)) {
				OptionSelectionComponent contentComponent = (OptionSelectionComponent)content.getComponentByReference(componentName);
				DocumentId[] documentIds = contentComponent.getCategorySelections();
				if (documentIds != null && documentIds.length > 0) {
					Category[] categories = new Category[documentIds.length];
					for (int i = 0; i < documentIds.length; i++) {
						categories[i] = (Category)EgovWCMCache.getWorkspace().getById(documentIds[i]); 
					}
					return categories;			
				}			
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private String encode(String string, String format) {
		return (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ? (string != null) ? string : "" : "<![CDATA[" + ((string != null) ? string : "") + "]]>";
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	private void logger(String string) {		
		if (debug) {
			System.out.println(string);
		}
	}
}
