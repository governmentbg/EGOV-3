package com.wcmprovider.egov.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.wcmprovider.egov.util.Logger;

public class QueryExecution {

	private static synchronized Connection getConnection() throws SQLException {
		Connection con = DBPool.getConnection();		
		if (con == null) {
			throw new SQLException("Connection is NULL");
		}
		con.setAutoCommit(true);
		return con;

	} 

	private static synchronized void releaseConnection(Connection con) throws SQLException {
		try {
			con.close();
		} catch (SQLException e) {
			Logger.log(Logger._LOGLEVEL, "[ERROR OCCURED] IN [QueryExecution] | [releaseConnection] | CALL METHOD -> con.close() : " + e.getMessage());
			throw new SQLException(e.getMessage());
		}
	} 

	static public ArrayList<com.egov.wcm.cache.EgovEkatte> findAllEkatte(boolean withRegions) {
		Connection con = null;
		com.egov.wcm.cache.EgovEkatte egovEkatte = null;
		ArrayList<com.egov.wcm.cache.EgovEkatte> ekatteArr = null;
		try {
			con = getConnection();
			if (con != null) {
				Statement stmt = con.createStatement();
				String query = "SELECT EKATTEID, EKATTECODE, EKATTECODEPARENT, EKATTENAME, EKATTELEVEL, SETTLEMENTTYPE, CITYHALLCODE FROM " + DBResources._SCHEMANAME + "EKATTE " + " WHERE " + ((withRegions) ? "1=1" : "EKATTEPARENTCODE IS NOT NULL")  + " ORDER BY EKATTECODEPARENT, EKATTENAME";
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution: query => " + query);

				ResultSet rs = stmt.executeQuery(query);
				if (rs != null) {
					ekatteArr = new ArrayList<>();
					while (rs.next()) {
						egovEkatte = new com.egov.wcm.cache.EgovEkatte();
						egovEkatte.setId(rs.getString(1));
						egovEkatte.setCode(rs.getString(2));
						egovEkatte.setParentCode(rs.getString(3));
						egovEkatte.setName(rs.getString(4));
						egovEkatte.setLevel(rs.getString(5));
						egovEkatte.setSettlementType(rs.getString(6));
						egovEkatte.setCityHallCode(rs.getString(7));
						ekatteArr.add(egovEkatte);
					}
					rs.close();
				}
				stmt.close();
				if (ekatteArr != null && ekatteArr.size() > 0) {
					return ekatteArr;
				}
			} else {
				Logger.log(Logger.ERROR_LEVEL, "QueryExecution : findAllEkatte : connection is not initialized.");
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				releaseConnection(con);
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return null;
	}
}