package com.wcmprovider.egov.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.wcmprovider.egov.db.DBResources;
import com.wcmprovider.egov.util.Logger;

public class Sequence {

    private static java.sql.Connection con;

    /**
     * Method getConnection.
     *
     * @return Connection
     * @throws SQLException
     */
    private static Connection getConnection() throws SQLException {

        con = DBPool.getConnection();

        con.setAutoCommit(true);
        if (con == null) {
            throw new SQLException("Connection is NULL");
        }
        return con;

    } // getConnection

    /**
     * Method releaseConnection.
     *
     * @throws SQLException
     */
    private static void releaseConnection() throws SQLException {
        try {
            con.close();
        } catch (SQLException e) {
        	Logger.log(Logger.ERROR_LEVEL, "Sequence : releaseConnection : " + e.getMessage());
            throw e;
        }
    } // releaseConnection

//    public synchronized static String getNextVal(String sequenceName, Connection connection) throws SQLException {
//        String sequenceValue;
//        sequenceValue = "-1";
//        try {
//            if (connection == null) {
//                if (con == null) {
//                    con = getConnection();
//                }
//                connection = con;
//            }
//            Statement st = connection.createStatement();
//            String query =
//                    "UPDATE "
//                    + DBResources._DB_SCHEMA_NAME + DBResources._SEQUENCES
//                    + " SET SEQUENCEVALUE=SEQUENCEVALUE+1 WHERE SEQUENCENAME='" + sequenceName + "'";
//            EgovWCMCacheLogger.log(EgovWCMCacheLogger.DEBUG_LEVEL, query);
//            int result = st.executeUpdate(query);
//            if (result == 1) {
////                con.commit();
//                query =
//                        "SELECT SEQUENCEVALUE FROM "
//                        + DBResources._DB_SCHEMA_NAME + DBResources._SEQUENCES
//                        + " WHERE SEQUENCENAME='" + sequenceName + "'";
//                EgovWCMCacheLogger.log(EgovWCMCacheLogger.DEBUG_LEVEL, query);
//                ResultSet rs = st.executeQuery(query);
//                if (rs != null) {
//                    if (rs.next()) {
//                        sequenceValue = rs.getString(1);
//                    }
//                } // rs
//                rs.close();
//            } // result
//            st.close();
//        } catch (SQLException e) {
//            EgovWCMCacheLogger.log(EgovWCMCacheLogger.ERROR_LEVEL, "Sequence : getNextVal : " + e.getMessage());
//            throw e;
//        } finally {
//            try {
//                if (connection == null) {
//                    releaseConnection();
//                }
//            } catch (SQLException e) {
//                EgovWCMCacheLogger.log(EgovWCMCacheLogger.ERROR_LEVEL, "Sequence : getNextVal : " + e.getMessage());
//                throw e;
//            }
//        }
//        return sequenceValue;
//    } // getNextVal

    public synchronized static String getNextVal(String sequenceName, Connection connection) throws SQLException {
        String sequenceValue;
        sequenceValue = "-1";
        try {
            if (connection == null) {
                if (con == null) {
                    con = getConnection();
                }
                connection = con;
            }
            Statement st = connection.createStatement();
            // select voes.email.nextval from dual;
            String query =
                    "select next value for " + DBResources._SCHEMANAME + sequenceName + " from SYSIBM.SYSDUMMY1";
            Logger.log(Logger.DEBUG_LEVEL, query);
            ResultSet rs = st.executeQuery(query);
            if (rs != null) {
                if (rs.next()) {
                    sequenceValue = rs.getString(1);
                }
            } // rs
            rs.close();
            st.close();
        } finally {
            try {
                if (connection == null) {
                    releaseConnection();
                }
            } catch (SQLException e) {
            	Logger.log(Logger.ERROR_LEVEL, "Sequence : getNextVal : " + e.getMessage());
                throw e;
            }

        }
        return sequenceValue;
    } // getNextVal

} // class