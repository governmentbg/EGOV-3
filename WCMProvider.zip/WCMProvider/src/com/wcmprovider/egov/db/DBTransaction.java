
package com.wcmprovider.egov.db;

import com.wcmprovider.egov.util.Logger;

import java.sql.Connection;
import java.sql.SQLException;

public class DBTransaction {

    private Connection con;

    public DBTransaction() {
        try {
            con = DBPool.getConnection();
            con.setAutoCommit(false);
        } catch (Exception e) {
        	Logger.log(Logger.ERROR_LEVEL, "DBTransaction : DBTransaction : " + e.getMessage());
        }
    }

    public Connection getConnection() {

        return con;
    }

    private void releaseConnection() throws SQLException {
        try {
            con.close();
        } catch (SQLException e) {
        	Logger.log(Logger.ERROR_LEVEL, "DBTransaction : releaseConnection : " + e.getMessage());
            throw new SQLException(e.getMessage());
        }
    }

    public void rollback() throws SQLException {
        try {
            con.rollback();
            releaseConnection();
        } catch (SQLException e) {
        	Logger.log(Logger.ERROR_LEVEL, "DBTransaction : rollback : " + e.getMessage());
            throw new SQLException();
        }
    }

    public void commit() throws SQLException {
        try {
            con.commit();
            releaseConnection();
        } catch (SQLException e) {
        	Logger.log(Logger.ERROR_LEVEL, "DBTransaction : commit : " + e.getMessage());
            throw new SQLException();
        }
    }

    public void setTransactionIsolation(int level) throws SQLException {
        if (con != null) con.setTransactionIsolation(level);
    }

    public int getTransactionIsolation() throws SQLException {
        if (con != null) return con.getTransactionIsolation();
        return -1;
    }

}
