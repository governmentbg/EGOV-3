package com.wcmprovider.egov.db;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import com.wcmprovider.egov.EgovWCMCacheLoaderConstants;
import com.wcmprovider.egov.util.Logger;

public class DBResources extends EgovWCMCacheLoaderConstants {

    private static final String DEFAULT_PROPERTIES_FILE_NAME = "db.properties";
    private static Properties defaultProps = null;


    private static final int getValue(String field, int defaultValue) {
        try {
            return Integer.parseInt(field.trim());
        } catch (Exception e) {
        }
        return defaultValue;
    }

    private static void getDefaultProperties(String fileName) {
        defaultProps = new Properties();
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(fileName);
            defaultProps.load(fis);
        } catch (Exception e) {
        	Logger.log(Logger.DEBUG_LEVEL, "DBResources: Error loading properties file " + fileName + " !");
            e.printStackTrace();
        }
    } 
    public static String getDefaultDBProperty(String propName) {
        return defaultProps.getProperty(propName);
    } 

    public static boolean loadDBProperties() {
        boolean result = false;
        String configPath = EgovWCMCacheLoaderConstants.DEPLOYMENT_LOCATION + "WEB-INF" + File.separator + "config" + File.separator + DEFAULT_PROPERTIES_FILE_NAME;
        System.err.println("Configuration path is " + configPath);
        File file = new File(configPath);
        if (file.exists()) {
            System.err.println( "Loading Properties from file : " + file.getAbsolutePath() + "... ");
            getDefaultProperties(configPath);
            System.err.println( "OK");
            if (defaultProps != null) {
                _SCHEMANAME = defaultProps.getProperty("schemaName");
                _SEQUENCES = defaultProps.getProperty("sequences");
                _URL = defaultProps.getProperty("url");
                _DRIVERCLASS = defaultProps.getProperty("driverClass");
                _USER = defaultProps.getProperty("user");
                _PASSWORD = defaultProps.getProperty("password");
                _POOLING = getValue(defaultProps.getProperty("pooling"), 0);
                if (_POOLING == 0) {
                    System.err.println( "Connection pooling: SET TO STAY OFF");
                } else {
                    System.err.println( "Connection pooling: SET TO TURN ON");
                    _POOLNAME = defaultProps.getProperty("poolName");
                    if (_POOLNAME == null) {
                        _POOLNAME = "DBCP";
                    }
                    _INITIALCONNECTIONS = getValue(defaultProps.getProperty("initialConnections"), 3);
                    _MINIDLECONNECTIONS = getValue(defaultProps.getProperty("minIdleConnections"), 0);
                    _MAXIDLECONNECTIONS = getValue(defaultProps.getProperty("maxIdleConnections"), 2);
                    _MAXACTIVECONNECTIONS = getValue(defaultProps.getProperty("maxActiveConnections"), 20);
                    _MAXWAITFORPOOLEDCONNECTION = getValue(defaultProps.getProperty("maxWaitForPooledConnecton"), 5000);
                    _TESTBEFORE = "true" == defaultProps.getProperty("testConnectionBefore", "false");
                    _TESTAFTER = "true" == defaultProps.getProperty("testConnectionAfter", "false");
                    _CONNECTIONMONITOR = getValue(defaultProps.getProperty("connectionMonitor"), 30000);
                }
                _LOGLEVEL = getValue(defaultProps.getProperty("logLevel"), 0);
                _SHOWTIMESTAMP = "1".equals(defaultProps.getProperty("showTimeStamp"));

            }
            if (!"".equals(_SCHEMANAME)) {
                _SCHEMANAME = _SCHEMANAME + ".";
            } else {
                _SCHEMANAME = "";
            }
            _DO_POOLING = _POOLING == 1;
            defaultProps.list(System.err);
            result = true;
        }
        return result;
    } 
} 