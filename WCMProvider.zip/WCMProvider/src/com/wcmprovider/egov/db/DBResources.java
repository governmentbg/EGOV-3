package com.wcmprovider.egov.db;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import com.wcmprovider.egov.EgovWCMCacheLoaderConstants;
import com.wcmprovider.egov.util.Logger;

public class DBResources extends EgovWCMCacheLoaderConstants {

    private static final String DEFAULT_PROPERTIES_FILE_NAME = "*";
    private static Properties defaultProps = null;


    private static final int getValue(String field, int defaultValue) {
        try {
            return Integer.parseInt(field.trim());
        } catch (Exception e) {
        }
        return defaultValue;
    }

    private static void getDefaultProperties(String fileName) {
        defaultProps = new Properties();
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(fileName);
            defaultProps.load(fis);
        } catch (Exception e) {
        	Logger.log(Logger.DEBUG_LEVEL, "DBResources: Error loading properties file " + fileName + " !");
            e.printStackTrace();
        }
    } 
    public static String getDefaultDBProperty(String propName) {
        return defaultProps.getProperty(propName);
    } 

    public static boolean loadDBProperties() {       
        return true;
    } 
} 