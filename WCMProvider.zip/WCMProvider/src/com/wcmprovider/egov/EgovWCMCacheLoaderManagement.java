package com.wcmprovider.egov;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

import javax.naming.InitialContext;
import javax.servlet.ServletContext;

import com.egov.wcm.cache.EgovEkatte;
import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.websphere.cache.DistributedMap;
import com.ibm.workplace.wcm.api.Category;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentLibrary;
import com.ibm.workplace.wcm.api.DocumentTypes;
import com.ibm.workplace.wcm.api.Repository;
import com.ibm.workplace.wcm.api.Taxonomy;
import com.ibm.workplace.wcm.api.WCM_API;
import com.ibm.workplace.wcm.api.Workspace;
import com.wcmprovider.egov.db.DBResources;
import com.wcmprovider.egov.db.QueryExecution;
import com.wcmprovider.egov.util.Logger;

public class EgovWCMCacheLoaderManagement {
	private static Repository repository = null;
	private static Workspace workspace = null;
	public static DistributedMap cacheObject = null;
	
	public void reloadCache(ServletContext servletContext) {
		System.out.println("reloadCache called...");
		EgovWCMCacheLoaderConstants.DEPLOYMENT_LOCATION = servletContext.getRealPath("/");
		System.err.println("servletContext.getRealPath(\"/\") = " + servletContext.getRealPath("/"));
		if (!EgovWCMCacheLoaderConstants.DEPLOYMENT_LOCATION.endsWith("/"))
			EgovWCMCacheLoaderConstants.DEPLOYMENT_LOCATION += File.separator;
		if (DBResources.loadDBProperties()) {
			System.out.println("loadDBProperties OK...");
			// load all from WCM...
			this.populateCacheWithWCMData();
			// load all from Ekatte DB...
			this.populateCacheWithEkatte();
			// release resources...
			this.releaseAll();
			// pass the initial context to the shared JAR class
			System.out.println("updating cache OK...");
			EgovWCMCache.cacheObject = cacheObject;
		}
	}
	
	private void init() {
		repository = WCM_API.getRepository();
		try {
			workspace = repository.getSystemWorkspace();
			if (workspace != null) {
				if (workspace.getDocumentLibrary(EgovWCMCacheLoaderConstants.WCM_LIBRARY_NAME) == null) {
					Logger.log(Logger.DEBUG_LEVEL, "[WCM PROVIDER] -> EGOV WCM CACHE ======== LIBRARY NOT FOUND [ " + EgovWCMCacheLoaderConstants.WCM_LIBRARY_NAME + " ] ======================");
				} else {
					workspace.setCurrentDocumentLibrary(workspace.getDocumentLibrary(EgovWCMCacheLoaderConstants.WCM_LIBRARY_NAME));
				}
				InitialContext ctx;
				try {
					ctx = new InitialContext();
					cacheObject = (DistributedMap) ctx.lookup("services/cache/EgovCache");
					cacheObject.put("workspace", workspace);
				} catch (Exception e) {
					e.printStackTrace();
				}					
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public synchronized void populateCacheWithWCMData() {
		init();
		if (workspace.getDocumentLibrary(EgovWCMCacheLoaderConstants.WCM_LIBRARY_NAME) == null) {
			Logger.log(Logger.DEBUG_LEVEL, "[WCM PROVIDER] -> EGOV WCM CACHE ======== LIBRARY NOT FOUND [ " + EgovWCMCacheLoaderConstants.WCM_LIBRARY_NAME + " ] ======================");
			return;
		}
		popuplateWithWCMServicesRootSiteArea();
		populateCacheWithWCMAuthoringTemplatesData(false);
		popuplateWithWCMServicesTaxonomy();
		popuplateWithWCMServicesSupplierSunauTaxonomy();
	}
	
	public synchronized void populateCacheWithWCMAuthoringTemplatesData(boolean init) {
		if (init) {
			init();
		}
		popuplateWithWCMServiceAuthoringTemplate();
		popuplateWithWCMServiceStateAuthoringTemplate();
		popuplateWithWCMServiceMetaAuthoringTemplate();
	}
	
	public synchronized void populateCacheWithWCMServiceTaxonomyData(boolean init) {
		if (init) {
			init();
		}
		popuplateWithWCMServicesTaxonomy();
	}
	
	public synchronized void populateCacheWithWCMSupplierSunauTaxonomyData(boolean init) {
		if (init) {
			init();
		}
		popuplateWithWCMServicesSupplierSunauTaxonomy();
	}

	
	@SuppressWarnings("rawtypes")
	private synchronized void popuplateWithWCMServicesRootSiteArea() {
		//DocumentIdIterator iterator = workspace.findByPath(EgovWCMCacheLoaderConstants.SERVICE_SITE_AREA_PATH, Workspace.WORKFLOWSTATUS_ALL);
		DocumentIdIterator iterator = workspace.findAllByPath(EgovWCMCacheLoaderConstants.SERVICE_SITE_AREA_PATH, DocumentTypes.SiteArea, Workspace.WORKFLOWSTATUS_ALL, new DocumentLibrary[] { workspace.getDocumentLibrary(EgovWCMCacheLoaderConstants.WCM_LIBRARY_NAME)});
		if (iterator.hasNext()) {
			cacheObject.put("serviceRootSiteArea", iterator.next());		
			Logger.log(Logger.DEBUG_LEVEL, "[WCM PROVIDER] -> EGOV WCM CACHE ======== SERVICE SITE AREA PATH [ OK ] ======================");
		}		
	}
	
	@SuppressWarnings("rawtypes")
	private synchronized void popuplateWithWCMServiceAuthoringTemplate() {
		DocumentIdIterator iterator = workspace.findByType(DocumentTypes.AuthoringTemplate);
		DocumentId authoringTemplate;
		while (iterator.hasNext()) {
			authoringTemplate = (DocumentId) iterator.next();
			if (authoringTemplate.getName().equals(EgovWCMCacheLoaderConstants.AUTHORING_TEMPLATE_SERVICE_NAME)) {
				cacheObject.put("serviceAuthoringTemplate", authoringTemplate);	
				Logger.log(Logger.DEBUG_LEVEL, "[WCM PROVIDER] -> EGOV WCM CACHE ======== SERVICE AUTHORING TEMPLATE SERVICE [ OK ] {" + authoringTemplate.getId() + "} ======================");
				break;
			}
		}			
	}
	
	@SuppressWarnings("rawtypes")
	private synchronized void popuplateWithWCMServiceStateAuthoringTemplate() {
		DocumentIdIterator iterator = workspace.findByType(DocumentTypes.AuthoringTemplate);
		DocumentId authoringTemplate;
		while (iterator.hasNext()) {
			authoringTemplate = (DocumentId) iterator.next();
			if (authoringTemplate.getName().equals(EgovWCMCacheLoaderConstants.AUTHORING_TEMPLATE_SERVICE_STATE_NAME)) {
				cacheObject.put("serviceStateAuthoringTemplate", authoringTemplate);	
				Logger.log(Logger.DEBUG_LEVEL, "[WCM PROVIDER] -> EGOV WCM CACHE ======== SERVICE AUTHORING TEMPLATE SERVICE STATE [ OK ] {" + authoringTemplate.getId() + "} ======================");
				break;
			}
		}				
	}
	
	@SuppressWarnings("rawtypes")
	private synchronized void popuplateWithWCMServiceMetaAuthoringTemplate() {
		DocumentIdIterator iterator = workspace.findByType(DocumentTypes.AuthoringTemplate);
		DocumentId authoringTemplate;
		while (iterator.hasNext()) {
			authoringTemplate = (DocumentId) iterator.next();
			if (authoringTemplate.getName().equals(EgovWCMCacheLoaderConstants.AUTHORING_TEMPLATE_SERVICE_META_NAME)) {
				cacheObject.put("serviceMetaAuthoringTemplate", authoringTemplate);	
				Logger.log(Logger.DEBUG_LEVEL, "[WCM PROVIDER] -> EGOV WCM CACHE ======== SERVICE AUTHORING TEMPLATE SERVICE META [ OK ] {" + authoringTemplate.getId() + "} ======================");
				break;
			}
		}	
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private synchronized void popuplateWithWCMServicesTaxonomy() {
		try {
			HashMap<String, ArrayList<DocumentId>> servicesTaxonomyChildrenByParentIdHm = new HashMap<>();
			ArrayList<DocumentId> servicesTaxonomyChildren = new ArrayList<DocumentId>();
			DocumentIdIterator taxonomyIterator = workspace.findByName(DocumentTypes.Taxonomy, EgovWCMCacheLoaderConstants.TAXONOMY_SERVICES_NAME);
			if (taxonomyIterator.hasNext()) {
				DocumentId servicesTaxonomy = taxonomyIterator.next();
				Taxonomy taxonomy = (Taxonomy)workspace.getById(servicesTaxonomy);
				if (taxonomy != null) {
					DocumentIdIterator dIt = taxonomy.getAllChildren();
					if (dIt != null) {
						DocumentId dId = null;
						ArrayList<DocumentId> tmpArr = null;
						Category category = null;
						while (dIt.hasNext()) {
							dId = dIt.next();
							category = (Category) workspace.getById(dId);
							//System.out.println("CATE=" + category.getName());
							servicesTaxonomyChildren.add(dId);
							tmpArr = servicesTaxonomyChildrenByParentIdHm.get(category.getParentId().getId());

							if (tmpArr == null) {
								tmpArr = new ArrayList<DocumentId>();
							}
							tmpArr.add(dId);
							servicesTaxonomyChildrenByParentIdHm.put(category.getParentId().getId(), tmpArr);
						}
					}
					cacheObject.put("servicesTaxonomyChildren", servicesTaxonomyChildren);
					cacheObject.put("servicesTaxonomyChildrenByParentIdHm", servicesTaxonomyChildrenByParentIdHm);
				}
				cacheObject.put("servicesTaxonomy", servicesTaxonomy);
			}
			Logger.log(Logger.DEBUG_LEVEL, "[WCM PROVIDER] -> EGOV WCM CACHE ======== SERVICES TAXONOMY LOADED TO EgovCache [ OK ] {" + servicesTaxonomyChildren.size() + "} =========================");
		} catch (Exception e) {
			Logger.log(Logger.DEBUG_LEVEL, "[WCM PROVIDER] -> EGOV WCM CACHE ======== SERVICES TAXONOMY [ ERROR ] {" + e.getMessage() + "} ======================");
			e.printStackTrace();
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private synchronized void popuplateWithWCMServicesSupplierSunauTaxonomy() {
		try {
			HashMap<String, ArrayList<DocumentId>> servicesSupplierSunauTaxonomyChildrenByParentIdHm = new HashMap<>();
			ArrayList<DocumentId> servicesSupplierSunauTaxonomyChildren = new ArrayList<DocumentId>();
			DocumentIdIterator taxonomyIterator = workspace.findByName(DocumentTypes.Taxonomy, EgovWCMCacheLoaderConstants.TAXONOMY_SERVICES_SUPPLIER_SUNAU_NAME);
			if (taxonomyIterator.hasNext()) {
				DocumentId servicesSupplierSunauTaxonomy = taxonomyIterator.next();
				Taxonomy taxonomy = (Taxonomy)workspace.getById(servicesSupplierSunauTaxonomy);
				if (taxonomy != null) {
					DocumentIdIterator dIt = taxonomy.getAllChildren();
					if (dIt != null) {
						DocumentId dId = null;
						ArrayList<DocumentId> tmpArr = null;
						Category category = null;
						while (dIt.hasNext()) {
							dId = dIt.next();
							category = (Category) workspace.getById(dId);
							//System.out.println("CATE=" + category.getName());
							servicesSupplierSunauTaxonomyChildren.add(dId);
							tmpArr = servicesSupplierSunauTaxonomyChildrenByParentIdHm.get(category.getParentId().getId());
							
							if (tmpArr == null) {
								tmpArr = new ArrayList<DocumentId>();
							}
							tmpArr.add(dId);
							servicesSupplierSunauTaxonomyChildrenByParentIdHm.put(category.getParentId().getId(), tmpArr);
						}
					}
					cacheObject.put("servicesSupplierSunauTaxonomyChildren", servicesSupplierSunauTaxonomyChildren);
					cacheObject.put("servicesSupplierSunauTaxonomyChildrenByParentIdHm", servicesSupplierSunauTaxonomyChildrenByParentIdHm);
				}
				cacheObject.put("servicesSupplierSunauTaxonomy", servicesSupplierSunauTaxonomy);
			}
			Logger.log(Logger.DEBUG_LEVEL, "[WCM PROVIDER] -> EGOV WCM CACHE ======== SERVICES SUPPLIER SUNAU TAXONOMY LOADED TO EgovCache [ OK ] {" + servicesSupplierSunauTaxonomyChildren.size() + "} =========================");
		} catch (Exception e) {
			Logger.log(Logger.DEBUG_LEVEL, "[WCM PROVIDER] -> EGOV WCM CACHE ======== SERVICES SUPPLIER SUNAU TAXONOMY [ ERROR ] {" + e.getMessage() + "} ======================");
			e.printStackTrace();
		}
	}	
	
	public void populateCacheWithEkatte() {
		ArrayList<com.egov.wcm.cache.EgovEkatte> ekatteArr = QueryExecution.findAllEkatte(true);
		if (ekatteArr != null) {			
			HashMap<String, ArrayList<EgovEkatte>> ekatteDistrictsHm = new HashMap<>();
			HashMap<String, EgovEkatte> ekattesHm = new HashMap<>();
			ArrayList<com.egov.wcm.cache.EgovEkatte> tmpArr = null;
			for (int i = 0; i < ekatteArr.size(); i++) {
				ekattesHm.put(ekatteArr.get(i).getCode(), ekatteArr.get(i));
				tmpArr = ekatteDistrictsHm.get(ekatteArr.get(i).getParentCode());
				if (tmpArr == null) {
					tmpArr = new ArrayList<>();
				}
				tmpArr.add(ekatteArr.get(i));
				ekatteDistrictsHm.put(ekatteArr.get(i).getParentCode(), tmpArr);
			}
			cacheObject.put("ekattes", ekatteArr);
			cacheObject.put("ekattesHm", ekattesHm);
			cacheObject.put("ekattesParentHm", ekatteDistrictsHm);
			Logger.log(Logger.DEBUG_LEVEL, "[WCM PROVIDER] -> EGOV WCM CACHE ========  EKATTE LOADED [ OK ] {" + ekatteArr.size() + "}  =========================");
		}
	}
	
	public synchronized void releaseAll() {
		endWorkspace();
	}
	
	public void endWorkspace() {
		Logger.log(Logger.DEBUG_LEVEL, "[WCM PROVIDER] -> EGOV WCM CACHE 'end workspace started...'");
		try {
			if (repository != null) {
				if (workspace != null) {
					try {
						workspace.logout();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				repository.endWorkspace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		Logger.log(Logger.DEBUG_LEVEL, "[WCM PROVIDER] -> EGOV WCM CACHE 'end workspace finished...'");
	}

}
