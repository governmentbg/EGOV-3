package com.wcmprovider.egov;

public class Constants {
	public static final String EGOV_CONTENT_LIBRARY_NAME = "eGovBG";
	public static final String EFORMS_CONTENT_LIBRARY_NAME = "eForms";
	public static final String SERVICE_TAXONOMY_NAME = "servicetaxonomy";
	public static String SERVICE_SITE_AREA_PATH = "/egov/services";
	public static final String EFORMS_SERVICE_SITE_AREA_PATH = "/eForms/";
	public static final String EFORMS_AUTHORING_TEMPLATE_NAME_EFORM_DOCS = "eFormDocs";
	public static final String EFORMS_AUTHORING_TEMPLATE_NAME_EFORM_FILES = "eFormFiles";
	
	public static String CONTENT_ROOT = "contentRoot";
	public static String CONTENT_TITLE = "icm:title";
	public static String CONTENT_TYPE_NAME = "Content";
	public static String CONTENT_ELEMENT_NAME = "ibmcontentwcm:name";
	public static String PROPERTIES_NAME_ELEMENTS = "ibmcontentwcm:elements";
	public static String PROPERTIES_NAME_CLASSIFICATION = "ibmcontentwcm:classification";
	public static String PROPERTIES_NAME_SHORT_TEXT = "ibmcontentwcm:shortText";
	public static String PROPERTIES_NAME_NUMERIC_VALUE = "ibmcontentwcm:numericValue";
	public static String PROPERTIES_NAME_HTML = "ibmcontentwcm:html";
	public static String PROPERTIES_NAME_PUBLISH_DATE = "ibmcontentwcm:actualEffectiveDate";
	public static String PROPERTIES_NAME_EXPIRE_DATE = "ibmcontentwcm:actualExpirationDate";
	public static String PATTERN_ICM_LIBRARIES = "icm:libraries*";

	public static final String CLASSIFICATION_CONTENT = "Content";
	public static final String CLASSIFICATION_SHORT_TEXT_COMPONENT = "Short Text Component";
	public static final String CLASSIFICATION_RICH_TEXT_COMPONENT = "Rich Text Component";
	public static final String CLASSIFICATION_NUMBER_COMPONENT = "Number Component";
	
	public static final String SERVICE_CONTENT_FIELD_NAME_SERVICE_STATUS = "serviceStatus";
	public static final String SERVICE_CONTENT_FIELD_NAME_AR_ID = "arId";		
	public static final String SERVICE_CONTENT_FIELD_NAME_OID = "oid";		
	public static final String SERVICE_CONTENT_FIELD_NAME_SERVICE_IN_SUNAU = "serviceInSunau";	
	public static final String SERVICE_CONTENT_FIELD_NAME_SERVICE_NAME_SUNAU = "serviceNameSunau";
	public static final String SERVICE_CONTENT_FIELD_NAME_SERVICE_NAME_TEXT = "serviceNameText";
	public static final String SERVICE_CONTENT_FIELD_NAME_SUPPLIER_TYPE = "supplierType";
	public static final String SERVICE_CONTENT_FIELD_NAME_SUPPLIER_OID = "supplierOID";
	public static final String SERVICE_CONTENT_FIELD_NAME_SERVICE_SUPPLIER_EKATTE = "serviceSupplierEkatte";
	public static final String SERVICE_CONTENT_FIELD_NAME_SERVICE_SUPPLIER_EKATTE_NUMBER = "serviceSupplierEkatteNumber";
	public static final String SERVICE_CONTENT_FIELD_NAME_SERVICE_SUPPLIER_TEXT = "serviceSupplierText";
	public static final String SERVICE_CONTENT_FIELD_NAME_TAXONOMY = "taxonomy";
	public static final String SERVICE_CONTENT_FIELD_NAME_TAXONOMY_OTHER = "taxonomyOther";
	public static final String SERVICE_CONTENT_FIELD_NAME_SUPPLIER_EIK = "supplierEIK";
	public static final String SERVICE_CONTENT_FIELD_NAME_ADMINISTRATION_AUTHORITY = "administrationAuthority";
	public static final String SERVICE_CONTENT_FIELD_NAME_ADMINISTRATION_UNIT = "administrationUnit";
	public static final String SERVICE_CONTENT_FIELD_NAME_PHONE = "phone";
	public static final String SERVICE_CONTENT_FIELD_NAME_EMAIL = "email";
	public static final String SERVICE_CONTENT_FIELD_NAME_SERVICE_DESCRIPTION = "serviceDescription";	
	public static final String SERVICE_CONTENT_FIELD_NAME_PREPARE_IN_ADVANCE = "prepareInAdvance";
	public static final String SERVICE_CONTENT_FIELD_NAME_HOW_TO_APPLY = "howToApply";
	public static final String SERVICE_CONTENT_FIELD_NAME_AUTHENTICATION_METHOD = "authenticationMethod";
	public static final String SERVICE_CONTENT_FIELD_NAME_ONLINE_APPLICATION_DESCRIPTION = "onlineApplicationDescription";
	public static final String SERVICE_CONTENT_FIELD_NAME_EAU_APPLICATION_FORM_LINK = "eauApplicationFormLink";
	public static final String SERVICE_CONTENT_FIELD_NAME_ON_PLACE_APPLICATION_DESCRIPTION = "onPlaceApplicationDescription";
	public static final String SERVICE_CONTENT_FIELD_NAME_APPLICATION_FORM = "applicationForm";
	public static final String SERVICE_CONTENT_FIELD_NAME_RESULT = "result";
	public static final String SERVICE_CONTENT_FIELD_NAME_TAXES = "taxes";
	
	
	public static final String SERVICE_CONTENT_FIELD_NAME_CATEGORY_NAME_SUNAU = "categoryNameSunau";
	public static final String SERVICE_CONTENT_FIELD_NAME_SUMMARY = "summary";
	
	public static final String EFORM_CONTENT_FIELD_NAME_DOCUMENT_DESCRIPTION = "documentDescription";
	public static final String EFORM_CONTENT_FIELD_NAME_DOCUMENT_LINK = "link";
	public static final String EFORM_CONTENT_FIELD_NAME_FILES_LINK = "link";
//	public static final String EFORM_CONTENT_FIELD_NAME_FILES_FILE = "file";
	public static final String EFORM_CONTENT_FIELD_NAME_EFORM_LINK = "link";
	
	
	public static final String SERVICE_STATE_CONTENT_FIELD_NAME_SERVICE_NAME = "serviceName";
	public static final String SERVICE_STATE_CONTENT_FIELD_NAME_SERVICE_SUPPLIER = "serviceSupplier";
	
	public static final String INSTITUTION_CONTENT_FIELD_NAME_AR_ID = "arId";		
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_TYPE = "institutionType";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_NAME_SUNAU = "institutionNameSunau";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_NAME_EKATTE = "institutionNameEkatte";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_NAME_EKATTE_NUMBER = "institutionNameEkatteNumber";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_NAME_OTHER = "institutionNameOther";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_EIK = "eik";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_ZIP = "institutionZIP";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_ADDRESS_EKATTE = "institutionAddressEkatte";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_STREET = "institutionStreet";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_CONTACTS = "InstitutionContacts";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_MAIL = "institutionMail";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_URL = "institutionUrl";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_DESCRIPTION = "institutionDescription";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_PRAVILNIK = "institutionPravilnik";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_RESPONSIBILITIES = "institutionResponsibilities";
	
	public static final String SERVICE_PROVIDER_REGION_ID = "oblastni administratsii";
	public static final String SERVICE_PROVIDER_REGION_OID = "2.16.100.1.3";
	public static final String SERVICE_PROVIDER_REGION_TITLE = "Областни администрации";
	public static final String SERVICE_PROVIDER_MUNICIPALITY_ID = "obshtinski administratsii";
	public static final String SERVICE_PROVIDER_MUNICIPALITY_OID = "2.16.100.1.1.106";
	public static final String SERVICE_PROVIDER_MUNICIPALITY_TITLE = "Общински администрации";
	
	public static final String SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_ID = "regionalno upravlenie na obrazovanieto";
	public static final String SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_OID = "2.16.100.1.1.424";
	public static final String SERVICE_PROVIDER_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_TITLE = "Регионално управление на образованието";
	public static final String SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_ID = "regionalna zdravna inspektsia";
	public static final String SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_OID = "2.16.100.1.1.379";
	public static final String SERVICE_PROVIDER_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_TITLE = "Регионална здравна инспекция";
	public static final String SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_ID = "baseynova direktsia";
	public static final String SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_OID = "2.16.100.1.1.97";
	public static final String SERVICE_PROVIDER_STA_BASEYNOVA_DIREKTSIA_TITLE = "Басейнови дирекции";
	public static final String SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_ID = "regionalna inspektsia po okolna sreda i vodite";
	public static final String SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_OID = "2.16.100.1.1.504";
	public static final String SERVICE_PROVIDER_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_TITLE = "Регионална инспекция по околна среда и водите";
	public static final String SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_ID = "oblastna direktsia zemedelie";
	public static final String SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_OID = "2.16.100.1.1.20686";
	public static final String SERVICE_PROVIDER_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_TITLE = "Областни дирекции \"Земеделие\"";
	public static final String SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_ID = "regionalna direktsia po gorite";
	public static final String SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_OID = "2.16.100.1.1.208201";
	public static final String SERVICE_PROVIDER_STA_REGIONALNA_DIRETSIA_PO_GORITE_TITLE = "Регионални дирекции по горите";
	public static final String SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_ID = "direktsia natsionalen park";
	public static final String SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_OID = "2.16.100.1.1.331";
	public static final String SERVICE_PROVIDER_STA_DIRETSIA_NATSIONALEN_PARK_TITLE = "Дирекции \"Национален парк\"";

	public static final String SERVICE_PROVIDER_A1_P2_UNIVERSITETI_ID = "universiteti";
	public static final String SERVICE_PROVIDER_A1_P2_UNIVERSITETI_OID = "2.16.100.1.1.208250";
	public static final String SERVICE_PROVIDER_A1_P2_UNIVERSITETI_TITLE = "Университети";
	
	public static final String SERVICE_PROVIDER_E_MEDIA_CONCIL_NAME = "1377";
	public static final String SERVICE_PROVIDER_E_MEDIA_CONCIL_ID = "7b6ce26c-bd16-46ff-a8d3-f5a972765bfd";
	public static final String SERVICE_PROVIDER_E_MEDIA_CONCIL_OID = "2.16.100.1.1.208252";
	public static final String SERVICE_PROVIDER_E_MEDIA_CONCIL_TITLE = "Съвет за електронни медии";
	
	
	public static String _PRODUCT_NAME = "WCM Provider ";
	public static String _PRODUCT_VERSION = "2.0";

	public static int _LOGLEVEL = 2;
	public static boolean _SHOWTIMESTAMP = false;
}
