package com.wcmprovider.egov;

public class Constants {
	
	
	public static String CONTENT_ROOT = "contentRoot";
	public static String CONTENT_TITLE = "icm:title";
	public static String CONTENT_TYPE_NAME = "Content";
	public static String CONTENT_ELEMENT_NAME = "ibmcontentwcm:name";
	public static String PROPERTIES_NAME_ELEMENTS = "ibmcontentwcm:elements";
	public static String PROPERTIES_NAME_CLASSIFICATION = "ibmcontentwcm:classification";
	public static String PROPERTIES_NAME_SHORT_TEXT = "ibmcontentwcm:shortText";
	public static String PROPERTIES_NAME_NUMERIC_VALUE = "ibmcontentwcm:numericValue";
	public static String PROPERTIES_NAME_HTML = "ibmcontentwcm:html";
	public static String PROPERTIES_NAME_PUBLISH_DATE = "ibmcontentwcm:actualEffectiveDate";
	public static String PROPERTIES_NAME_EXPIRE_DATE = "ibmcontentwcm:actualExpirationDate";
	public static String PATTERN_ICM_LIBRARIES = "icm:libraries*";

	public static final String CLASSIFICATION_CONTENT = "Content";
	public static final String CLASSIFICATION_SHORT_TEXT_COMPONENT = "Short Text Component";
	public static final String CLASSIFICATION_RICH_TEXT_COMPONENT = "Rich Text Component";
	public static final String CLASSIFICATION_NUMBER_COMPONENT = "Number Component";
	
	public static final String SERVICE_CONTENT_FIELD_NAME_SERVICE_STATUS = "serviceStatus";
	public static final String SERVICE_CONTENT_FIELD_NAME_AR_ID = "arId";		
	public static final String SERVICE_CONTENT_FIELD_NAME_OID = "oid";		
	public static final String SERVICE_CONTENT_FIELD_NAME_SERVICE_IN_SUNAU = "serviceInSunau";	
	public static final String SERVICE_CONTENT_FIELD_NAME_SERVICE_NAME_SUNAU = "serviceNameSunau";
	public static final String SERVICE_CONTENT_FIELD_NAME_SERVICE_NAME_TEXT = "serviceNameText";
	public static final String SERVICE_CONTENT_FIELD_NAME_SUPPLIER_TYPE = "supplierType";
	public static final String SERVICE_CONTENT_FIELD_NAME_SUPPLIER_OID = "supplierOID";
	public static final String SERVICE_CONTENT_FIELD_NAME_SERVICE_SUPPLIER_EKATTE = "serviceSupplierEkatte";
	public static final String SERVICE_CONTENT_FIELD_NAME_SERVICE_SUPPLIER_EKATTE_NUMBER = "serviceSupplierEkatteNumber";
	public static final String SERVICE_CONTENT_FIELD_NAME_SERVICE_SUPPLIER_TEXT = "serviceSupplierText";
	public static final String SERVICE_CONTENT_FIELD_NAME_TAXONOMY = "taxonomy";
	public static final String SERVICE_CONTENT_FIELD_NAME_TAXONOMY_OTHER = "taxonomyOther";
	public static final String SERVICE_CONTENT_FIELD_NAME_SUPPLIER_EIK = "supplierEIK";
	public static final String SERVICE_CONTENT_FIELD_NAME_ADMINISTRATION_AUTHORITY = "administrationAuthority";
	public static final String SERVICE_CONTENT_FIELD_NAME_ADMINISTRATION_UNIT = "administrationUnit";
	public static final String SERVICE_CONTENT_FIELD_NAME_PHONE = "phone";
	public static final String SERVICE_CONTENT_FIELD_NAME_EMAIL = "email";
	public static final String SERVICE_CONTENT_FIELD_NAME_SERVICE_DESCRIPTION = "serviceDescription";	
	public static final String SERVICE_CONTENT_FIELD_NAME_PREPARE_IN_ADVANCE = "prepareInAdvance";
	public static final String SERVICE_CONTENT_FIELD_NAME_HOW_TO_APPLY = "howToApply";
	public static final String SERVICE_CONTENT_FIELD_NAME_AUTHENTICATION_METHOD = "authenticationMethod";
	public static final String SERVICE_CONTENT_FIELD_NAME_ONLINE_APPLICATION_DESCRIPTION = "onlineApplicationDescription";
	public static final String SERVICE_CONTENT_FIELD_NAME_EAU_APPLICATION_FORM_LINK = "eauApplicationFormLink";
	public static final String SERVICE_CONTENT_FIELD_NAME_ON_PLACE_APPLICATION_DESCRIPTION = "onPlaceApplicationDescription";
	public static final String SERVICE_CONTENT_FIELD_NAME_APPLICATION_FORM = "applicationForm";
	public static final String SERVICE_CONTENT_FIELD_NAME_RESULT = "result";
	public static final String SERVICE_CONTENT_FIELD_NAME_TAXES = "taxes";
	
	
	public static final String SERVICE_CONTENT_FIELD_NAME_CATEGORY_NAME_SUNAU = "categoryNameSunau";
	public static final String SERVICE_CONTENT_FIELD_NAME_SUMMARY = "summary";
	
	public static final String EFORM_CONTENT_FIELD_NAME_DOCUMENT_DESCRIPTION = "documentDescription";
	public static final String EFORM_CONTENT_FIELD_NAME_DOCUMENT_LINK = "link";
	public static final String EFORM_CONTENT_FIELD_NAME_FILES_LINK = "link";

	public static final String EFORM_CONTENT_FIELD_NAME_EFORM_LINK = "link";
	
	
	public static final String SERVICE_STATE_CONTENT_FIELD_NAME_SERVICE_NAME = "serviceName";
	public static final String SERVICE_STATE_CONTENT_FIELD_NAME_SERVICE_SUPPLIER = "serviceSupplier";
	
	public static final String INSTITUTION_CONTENT_FIELD_NAME_AR_ID = "arId";		
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_TYPE = "institutionType";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_NAME_SUNAU = "institutionNameSunau";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_NAME_EKATTE = "institutionNameEkatte";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_NAME_EKATTE_NUMBER = "institutionNameEkatteNumber";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_NAME_OTHER = "institutionNameOther";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_EIK = "eik";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_ZIP = "institutionZIP";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_ADDRESS_EKATTE = "institutionAddressEkatte";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_STREET = "institutionStreet";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_CONTACTS = "InstitutionContacts";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_MAIL = "institutionMail";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_URL = "institutionUrl";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_DESCRIPTION = "institutionDescription";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_PRAVILNIK = "institutionPravilnik";
	public static final String INSTITUTION_CONTENT_FIELD_NAME_INSTITUTION_RESPONSIBILITIES = "institutionResponsibilities";
	

	
	
	public static String _PRODUCT_NAME = "WCM Provider ";
	public static String _PRODUCT_VERSION = "2.0";

	public static int _LOGLEVEL = 2;
	public static boolean _SHOWTIMESTAMP = false;
}
