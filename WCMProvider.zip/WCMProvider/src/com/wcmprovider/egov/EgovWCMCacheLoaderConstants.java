package com.wcmprovider.egov;

public class EgovWCMCacheLoaderConstants {
	public static final String _PRODUCT_NAME = "EGOV WCM Provider ";
	public static final String _PRODUCT_VERSION = "1.0";
	public static String DEPLOYMENT_LOCATION = "";
	
	//WCM
	public static final String WCM_LIBRARY_NAME = "eGovBG";
	public static final String TAXONOMY_EKATTE_NAME = "ekatte";
	public static final String TAXONOMY_SERVICES_NAME = "servicetaxonomy";
	public static final String TAXONOMY_SERVICES_SUPPLIER_SUNAU_NAME = "suppliersunau";
	public static final String SERVICE_SITE_AREA_PATH = "/egov/services";
	public static final String AUTHORING_TEMPLATE_SERVICE_NAME = "service";
	public static final String AUTHORING_TEMPLATE_SERVICE_STATE_NAME = "servicestate";
	public static final String AUTHORING_TEMPLATE_SERVICE_META_NAME = "servicemeta";
	
	public static final String REGION_PARENT_EKATTE_CODE = "(null)";
	public static final String REGION_NW_EKATTE_CODE = "NW";
	public static final String REGION_NC_EKATTE_CODE = "NC";
	public static final String REGION_NE_EKATTE_CODE = "NE";
	public static final String REGION_SE_EKATTE_CODE = "SE";
	public static final String REGION_SC_EKATTE_CODE = "SC";
	public static final String REGION_SW_EKATTE_CODE = "SW";
	
	public static final String CONTENT_ROOT = "contentRoot";
	public static final String CONTENT_TITLE = "icm:title";
	public static final String CONTENT_TYPE_NAME = "Content";
	public static final String CONTENT_ELEMENT_NAME = "ibmcontentwcm:name";
	public static final String PROPERTIES_NAME_ELEMENTS = "ibmcontentwcm:elements";
	public static final String PROPERTIES_NAME_CLASSIFICATION = "ibmcontentwcm:classification";
	public static final String PROPERTIES_NAME_SHORT_TEXT = "ibmcontentwcm:shortText";
	public static final String PROPERTIES_NAME_NUMERIC_VALUE = "ibmcontentwcm:numericValue";
	public static final String PROPERTIES_NAME_HTML = "ibmcontentwcm:html";
	public static final String PROPERTIES_NAME_PUBLISH_DATE = "ibmcontentwcm:actualEffectiveDate";
	public static final String PROPERTIES_NAME_EXPIRE_DATE = "ibmcontentwcm:actualExpirationDate";
	public static final String PATTERN_ICM_LIBRARIES = "icm:libraries*";

	public static final String CLASSIFICATION_CONTENT = "Content";
	public static final String CLASSIFICATION_SHORT_TEXT_COMPONENT = "Short Text Component";
	public static final String CLASSIFICATION_RICH_TEXT_COMPONENT = "Rich Text Component";
	public static final String CLASSIFICATION_NUMBER_COMPONENT = "Number Component";


	public static boolean _DO_POOLING = false;
	public static String _POOLNAME = null;
	public static int _POOLING;
	public static int _INITIALCONNECTIONS;
	public static int _MAXACTIVECONNECTIONS;
	public static int _MINIDLECONNECTIONS;
	public static int _MAXIDLECONNECTIONS;
	public static int _MAXWAITFORPOOLEDCONNECTION;
	public static boolean _TESTBEFORE;
	public static boolean _TESTAFTER;
	public static int _CONNECTIONMONITOR;

	public static int _LOGLEVEL = 2;
	public static boolean _SHOWTIMESTAMP = false;
}
