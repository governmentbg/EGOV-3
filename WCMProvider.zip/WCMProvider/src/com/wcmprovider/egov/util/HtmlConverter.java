﻿package com.wcmprovider.egov.util;

import java.util.StringTokenizer;

public class HtmlConverter extends Object {

    private final static char _DASH = '-';
    private final static String _SPACE = " ";

    private static String[] convertTable = null;
    private static int tableSize = 64 * 1024; // 64K


    static {
        int i = 0;
        char[] charArr = null;
        convertTable = new String[tableSize];
        for (i = 0; i < tableSize; i++) {
            charArr = new char[1];
            charArr[0] = (char) i;
            convertTable[i] = new String(charArr);
        } // for
        convertTable[(int) '"'] = "&quot;";
        convertTable[(int) '\''] = "&apos;";
        convertTable[(int) '&'] = "&amp;";
        convertTable[(int) '>'] = "&gt;";
        convertTable[(int) '<'] = "&lt;";

    } // static


    /**
     * Constructor
     */
    public HtmlConverter() {
    }


    public static String escapeJSON(String inStr) {
    	if (inStr == null || inStr.length() == 0) {
            return "";
        }
        return inStr.replace("\"", "\\\"");
    }
    
    /**
     *  Converts string to HTML ready form( substitutes quotes with '&quot;' and so on)
     */
    public static String escape(String inStr) {
        if (inStr == null || inStr.length() == 0) {
            //return inStr;
            return "";
        }
        int inLen = inStr.length();
        StringBuffer sb = new StringBuffer(inLen);

        char[] chars = inStr.toCharArray();
        for (int i = 0; i < chars.length; i++) {
            switch (chars[i]) {
                case '<':
                    sb.append("&lt;");
                    break;
                case '>':
                    sb.append("&gt;");
                    break;
                case '&':
                    sb.append("&amp;");
                    break;
                case '"':
                    sb.append("&quot;");
                    break;
//				case '\'': sb.append("&apos;"); break;
                default  :
                    sb.append(chars[i]);
                    break;
            }
        } // for
        return sb.toString();
    } // escape


    /**
     * " \t\n\r\f": the space character, the tab character,
     the newline character, the carriage-return character,
     and the form-feed character
     */
    public static String wrapStr(String inStr, int wrapLength) {

        StringTokenizer st = new StringTokenizer(inStr, " \t\n\r\f");
        StringBuffer sb = new StringBuffer();
        String tmpStr = null;
        int pos = 0;
        int tmp = 0;
        while (st.hasMoreTokens()) {
            tmpStr = st.nextToken();
            if (tmpStr.length() > wrapLength) {
                tmp = 0;
                for (pos = 0; pos < tmpStr.length(); pos++) {
                    if (tmpStr.charAt(pos) == _DASH) {
                        sb.append(_SPACE + tmpStr.charAt(pos) + _SPACE);
                        tmp = -1;
                    } else {
                        sb.append(tmpStr.charAt(pos));
                    }
                    if (tmp == wrapLength) {
                        sb.append(_SPACE);
                        tmp = -1;
                    }
                    tmp++;
                }
            } else {//if(tmpStr.length() > wrapLength){
                if (st.hasMoreTokens()) {
                    sb.append(tmpStr + " ");
                } else {
                    sb.append(tmpStr);
                }
            }//if(tmpStr.length() > wrapLength){
        }//while(st.hasMoreTokens()){
        return sb.toString();
    }//wrapStr
//

    /**
     *
     */
    public static String wrapHtmlStr(String inStr, int wrapLength) {
        if (inStr == null || inStr.length() <= wrapLength) {
            return inStr;
        }
        StringBuffer sb = new StringBuffer(150);
        int begPos = 0;
        //int endPos = 0;
        int beginTagPos = 0, endTagPos = 0;
        int inStrLen = inStr.length();

        boolean hasNextHtmlTag = true;
        do {
            beginTagPos = inStr.indexOf("<", begPos);
            if (beginTagPos < 0) {
                hasNextHtmlTag = false;
            } else {
                endTagPos = inStr.indexOf(">", beginTagPos);
                if (endTagPos < 0) {
                    hasNextHtmlTag = false;
                } else {
                    sb.append(wrapStr(inStr.substring(begPos, beginTagPos), wrapLength));
                    sb.append(inStr.substring(beginTagPos, endTagPos + 1));
                    begPos = endTagPos + 1;
                } // else - has ">" to close the tag
            } // else - has openTag ("<")
        } while (hasNextHtmlTag && endTagPos < inStrLen - 1);


        if (endTagPos < inStrLen - 1) {
            // do things from endTagPos Till End
            if (endTagPos == 0) {
                sb.append(wrapStr(inStr.substring(endTagPos, inStrLen), wrapLength));
            } else {
                sb.append(wrapStr(inStr.substring(endTagPos + 1, inStrLen), wrapLength));
            }

        } //
        return sb.toString();
    } //wrapHtmlStr


    public static String wrapAndEscape(String str, int maxLength) {
        if (str != null) {
            return escape(wrapStr(str, maxLength));
        } else {
            return null;
        }
    } //wrapAndEscape()

    public static String truncate(String str, int maxLength) {
        if (str != null) {
            if (str.length() > maxLength) {
                return (str.substring(0, maxLength - 1) + "...");
            } else {
                return str;
            }
        } else {
            return "";
        }
    } //truncate()

    public static String truncateToWholeWord(String str, int maxLength) {
        if (str != null) {
            if (str.length() > maxLength) {
                String tempS = str.substring(0, maxLength - 1);
                int lastSpace = tempS.lastIndexOf(' ');
                if (lastSpace != -1) {
                    return (tempS.substring(0, lastSpace) + "...");
                } else {
                    return (str.substring(0, maxLength - 1) + "...");
                }
            } else {
                return str;
            }
        } else {
            return "";
        }
    } //truncate()

    public static String wrapAndEscapeAndTruncate(String inStr, int wrapLength, int maxLength) {
        if (inStr != null) {
            return wrapAndEscape(truncate(inStr, maxLength), wrapLength);
        }
        return "";
    }

    public static String wrapAndEscapeAndTruncateToWholeWord(String inStr, int wrapLength, int maxLength) {
        if (inStr != null) {
            return wrapAndEscape(truncateToWholeWord(inStr, maxLength), wrapLength);
        }
        return "";
    }

    public static String formatPrint(String inpStr) {
        String text = inpStr;
        if (text == null) text = "";
        String[] search = {"\r\n", "\t", "  "};
        String[] replace = {"<br />", " &nbsp; &nbsp; &nbsp; &nbsp;", " &nbsp;"};
        StringBuffer pre = null;
        int a = 0, i = 0;
        for (int n = 0; n < search.length; n++) {
            pre = new StringBuffer(text.length());
            a = 0;
            i = 0;
            while (i < text.length()) {
                i = text.indexOf(search[n], i);
                if (i == -1) break;
                pre.append(text.substring(a, i));
                pre.append(replace[n]);
                i += search[n].length();
                a = i;
            }
            pre.append(text.substring(a));
            text = pre.toString();
        }
        return pre.toString();
    }//formatPrint

    public static String checkStringForNull(String s) {
        if (s == null)
            return "";
        return s;
    }

} // HtmlConvertor