package com.wcmprovider.egov.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.wcmprovider.egov.Constants;

public class Logger extends Constants {

    public final static int ERROR_LEVEL = 0;
    public final static int WARNING_LEVEL = 1;
    public final static int DEBUG_LEVEL = 2;

    private final static SimpleDateFormat formatter = new SimpleDateFormat("[yyyy-MM-dd HH:mm:ss] ");

    public synchronized static void log(String logMessage) {
        System.err.println(logMessage);
    }

    public synchronized static void log(int logLevel, String logMessage) {

        String message = Constants._PRODUCT_NAME + Constants._PRODUCT_VERSION + " | ";

        if (logLevel <= _LOGLEVEL) {
            if (_SHOWTIMESTAMP) {
                message += formatter.format(new Date(System.currentTimeMillis())) + logMessage;
                System.out.println(message);
            } else {
                message += logMessage;
                System.out.println(message);
            }
        }

        if (logLevel == ERROR_LEVEL) {
//        	 mailError(message);
        }
    }
}
