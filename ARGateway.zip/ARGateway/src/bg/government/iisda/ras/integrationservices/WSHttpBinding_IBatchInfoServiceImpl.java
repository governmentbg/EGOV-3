
/**
 * Please modify this class to meet your needs
 * This class is not complete
 */

package bg.government.iisda.ras.integrationservices;

import java.util.logging.Logger;
//import javax.jws.WebMethod;
//import javax.jws.WebParam;
//import javax.jws.WebResult;
//import javax.jws.WebService;
//import javax.xml.bind.annotation.XmlSeeAlso;
//import javax.xml.ws.Action;
//import javax.xml.ws.RequestWrapper;
//import javax.xml.ws.ResponseWrapper;
//import javax.xml.ws.BindingType;
//import javax.xml.ws.soap.SOAPBinding;


// Not used!
//@WebService(
//                      serviceName = "BatchInfoService",
//                      portName = "WSHttpBinding_IBatchInfoService",
//                      targetNamespace = "http://tempuri.org/",
//                      wsdlLocation = "https://iisda.government.bg/Services/RAS/RAS.Integration.Host/BatchInfoService.svc?wsdl",
//                      endpointInterface = "bg.government.iisda.ras.integrationservices.IBatchInfoService")
public class WSHttpBinding_IBatchInfoServiceImpl implements IBatchInfoService {

    private static final Logger LOG = Logger.getLogger(WSHttpBinding_IBatchInfoServiceImpl.class.getName());

    /* (non-Javadoc)
     * @see bg.government.iisda.ras.integrationservices.IBatchInfoService#getBatchDetailedInfo(bg.government.iisda.ras.integrationservices.ArrayOfString batchIdentificationNumber, javax.xml.datatype.XMLGregorianCalendar dateAt, java.lang.Long versionIDAt)*
     */
    public bg.government.iisda.ras.integrationservices.ArrayOfBatchType getBatchDetailedInfo(bg.government.iisda.ras.integrationservices.ArrayOfString batchIdentificationNumber, javax.xml.datatype.XMLGregorianCalendar dateAt, java.lang.Long versionIDAt) {
        LOG.info("Executing operation getBatchDetailedInfo");
        System.out.println(batchIdentificationNumber);
        System.out.println(dateAt);
        System.out.println(versionIDAt);
        try {
            bg.government.iisda.ras.integrationservices.ArrayOfBatchType _return = new bg.government.iisda.ras.integrationservices.ArrayOfBatchType();
            java.util.List<bg.government.iisda.ras.BatchType> _returnBatchType = new java.util.ArrayList<bg.government.iisda.ras.BatchType>();
            bg.government.iisda.ras.BatchType _returnBatchTypeVal1 = new bg.government.iisda.ras.BatchType();
            bg.government.iisda.ras.AdministrationType _returnBatchTypeVal1Administration = new bg.government.iisda.ras.AdministrationType();
            java.util.List<bg.government.iisda.ras.UnitPositionCommonDataType> _returnBatchTypeVal1AdministrationUnitPositionsSubjectOfHeadOfAdm = new java.util.ArrayList<bg.government.iisda.ras.UnitPositionCommonDataType>();
            _returnBatchTypeVal1Administration.getUnitPositionsSubjectOfHeadOfAdm().addAll(_returnBatchTypeVal1AdministrationUnitPositionsSubjectOfHeadOfAdm);
            java.util.List<bg.government.iisda.ras.UnitPositionCommonDataType> _returnBatchTypeVal1AdministrationUnitPositionsInAdm = new java.util.ArrayList<bg.government.iisda.ras.UnitPositionCommonDataType>();
            _returnBatchTypeVal1Administration.getUnitPositionsInAdm().addAll(_returnBatchTypeVal1AdministrationUnitPositionsInAdm);
            bg.government.iisda.ras.common.CorrespondenceDataType _returnBatchTypeVal1AdministrationCorrespondenceData = new bg.government.iisda.ras.common.CorrespondenceDataType();
            java.util.List<bg.government.iisda.ras.common.CorrespondenceDataPhoneType> _returnBatchTypeVal1AdministrationCorrespondenceDataPhone = new java.util.ArrayList<bg.government.iisda.ras.common.CorrespondenceDataPhoneType>();
            _returnBatchTypeVal1AdministrationCorrespondenceData.getPhone().addAll(_returnBatchTypeVal1AdministrationCorrespondenceDataPhone);
            _returnBatchTypeVal1AdministrationCorrespondenceData.setCorrespDataID(-294174716689856007l);
            _returnBatchTypeVal1AdministrationCorrespondenceData.setVersionID(-3879170855607140273l);
            _returnBatchTypeVal1AdministrationCorrespondenceData.setInterSettlementCallingCode("InterSettlementCallingCode-188326491");
            _returnBatchTypeVal1AdministrationCorrespondenceData.setFaxNumber("FaxNumber-60949503");
            _returnBatchTypeVal1AdministrationCorrespondenceData.setEmail("Email-320703134");
            _returnBatchTypeVal1AdministrationCorrespondenceData.setWebSiteUrl("WebSiteUrl1348432086");
            _returnBatchTypeVal1AdministrationCorrespondenceData.setFaxIncludesSettlementCallCode(Boolean.valueOf(true));
            _returnBatchTypeVal1Administration.setCorrespondenceData(_returnBatchTypeVal1AdministrationCorrespondenceData);
            bg.government.iisda.ras.common.AddressType _returnBatchTypeVal1AdministrationAddress = new bg.government.iisda.ras.common.AddressType();
            bg.government.iisda.ras.common.EkatteAddressType _returnBatchTypeVal1AdministrationAddressEkatteAddress = new bg.government.iisda.ras.common.EkatteAddressType();
            _returnBatchTypeVal1AdministrationAddressEkatteAddress.setDistrictEkatteCode("DistrictEkatteCode1345095723");
            _returnBatchTypeVal1AdministrationAddressEkatteAddress.setDistrictName("DistrictName398910947");
            _returnBatchTypeVal1AdministrationAddressEkatteAddress.setMunicipalityEkatteCode("MunicipalityEkatteCode204676284");
            _returnBatchTypeVal1AdministrationAddressEkatteAddress.setMunicipalityName("MunicipalityName975620256");
            _returnBatchTypeVal1AdministrationAddressEkatteAddress.setSettlementEkatteCode("SettlementEkatteCode1694295891");
            _returnBatchTypeVal1AdministrationAddressEkatteAddress.setSettlementName("SettlementName1219671420");
            _returnBatchTypeVal1AdministrationAddressEkatteAddress.setAreaEkatteCode("AreaEkatteCode728612525");
            _returnBatchTypeVal1AdministrationAddressEkatteAddress.setAreaName("AreaName-925427970");
            _returnBatchTypeVal1AdministrationAddress.setEkatteAddress(_returnBatchTypeVal1AdministrationAddressEkatteAddress);
            _returnBatchTypeVal1AdministrationAddress.setAddressID(-8244179840520825864l);
            _returnBatchTypeVal1AdministrationAddress.setVersionID(-6269954372935270049l);
            _returnBatchTypeVal1AdministrationAddress.setPostCode("PostCode206686213");
            _returnBatchTypeVal1AdministrationAddress.setAddressText("AddressText-758928602");
            _returnBatchTypeVal1Administration.setAddress(_returnBatchTypeVal1AdministrationAddress);
            bg.government.iisda.ras.common.WorkingTimeType _returnBatchTypeVal1AdministrationWorkingTime = new bg.government.iisda.ras.common.WorkingTimeType();
            _returnBatchTypeVal1AdministrationWorkingTime.setWorkingTimeID(-5526114061113939505l);
            _returnBatchTypeVal1AdministrationWorkingTime.setVersionID(-2534000799908637036l);
            bg.government.iisda.ras.common.WorkingTimeTypeEnum _returnBatchTypeVal1AdministrationWorkingTimeType = bg.government.iisda.ras.common.WorkingTimeTypeEnum.FLEXIBLE;
            _returnBatchTypeVal1AdministrationWorkingTime.setType(_returnBatchTypeVal1AdministrationWorkingTimeType);
            _returnBatchTypeVal1AdministrationWorkingTime.setDescription("Description88393300");
            _returnBatchTypeVal1AdministrationWorkingTime.setStartTime("StartTime-1998770029");
            _returnBatchTypeVal1AdministrationWorkingTime.setEndTime("EndTime1073746845");
            _returnBatchTypeVal1AdministrationWorkingTime.setDuration(javax.xml.datatype.DatatypeFactory.newInstance().newDuration("-P45480130Y5M10DT13H18M2.598S"));
            _returnBatchTypeVal1Administration.setWorkingTime(_returnBatchTypeVal1AdministrationWorkingTime);
            java.util.List<bg.government.iisda.ras.common.EkatteAddressType> _returnBatchTypeVal1AdministrationAdmTerritorialRange = new java.util.ArrayList<bg.government.iisda.ras.common.EkatteAddressType>();
            _returnBatchTypeVal1Administration.getAdmTerritorialRange().addAll(_returnBatchTypeVal1AdministrationAdmTerritorialRange);
            _returnBatchTypeVal1Administration.setSecretaryAbsenceReason("SecretaryAbsenceReason1707492773");
            bg.government.iisda.ras.PositionType _returnBatchTypeVal1AdministrationSecretaryPosition = new bg.government.iisda.ras.PositionType();
            bg.government.iisda.ras.common.StaffNumbersType _returnBatchTypeVal1AdministrationSecretaryPositionStaffNumbers = new bg.government.iisda.ras.common.StaffNumbersType();
            _returnBatchTypeVal1AdministrationSecretaryPositionStaffNumbers.setStaffNumbersID(-4706633630815532352l);
            _returnBatchTypeVal1AdministrationSecretaryPositionStaffNumbers.setVersionID(6497682511055169937l);
            _returnBatchTypeVal1AdministrationSecretaryPositionStaffNumbers.setTotalStaffNumbers(Double.valueOf(0.995741530591507));
            _returnBatchTypeVal1AdministrationSecretaryPositionStaffNumbers.setExpertsNumbers(Double.valueOf(0.49239485644067205));
            _returnBatchTypeVal1AdministrationSecretaryPositionStaffNumbers.setAdvisorsNumbers(Double.valueOf(0.975604768993985));
            _returnBatchTypeVal1AdministrationSecretaryPositionStaffNumbers.setCivilServantNumbers(Double.valueOf(0.4438801157856177));
            _returnBatchTypeVal1AdministrationSecretaryPositionStaffNumbers.setEmploymentNumbers(Double.valueOf(0.7510561301184011));
            _returnBatchTypeVal1AdministrationSecretaryPositionStaffNumbers.setBodiesDeputiesNumbers(Double.valueOf(0.2613253921335681));
            _returnBatchTypeVal1AdministrationSecretaryPosition.setStaffNumbers(_returnBatchTypeVal1AdministrationSecretaryPositionStaffNumbers);
            bg.government.iisda.ras.common.VacantPositionsNumbersType _returnBatchTypeVal1AdministrationSecretaryPositionVacantPositionsNumbers = new bg.government.iisda.ras.common.VacantPositionsNumbersType();
            _returnBatchTypeVal1AdministrationSecretaryPositionVacantPositionsNumbers.setVacantPositionsNumbersID(3645553101213247165l);
            _returnBatchTypeVal1AdministrationSecretaryPositionVacantPositionsNumbers.setVersionID(4232326108426249347l);
            _returnBatchTypeVal1AdministrationSecretaryPositionVacantPositionsNumbers.setTotalVacantPositions(Double.valueOf(0.32932894746233266));
            _returnBatchTypeVal1AdministrationSecretaryPositionVacantPositionsNumbers.setCsVacantPosition(Double.valueOf(0.043200917600960786));
            _returnBatchTypeVal1AdministrationSecretaryPositionVacantPositionsNumbers.setEmpltVacantPositions(Double.valueOf(0.058246700767480175));
            _returnBatchTypeVal1AdministrationSecretaryPosition.setVacantPositionsNumbers(_returnBatchTypeVal1AdministrationSecretaryPositionVacantPositionsNumbers);
            java.util.List<bg.government.iisda.ras.common.PowerCompetenceFunctionType> _returnBatchTypeVal1AdministrationSecretaryPositionFunction = new java.util.ArrayList<bg.government.iisda.ras.common.PowerCompetenceFunctionType>();
            _returnBatchTypeVal1AdministrationSecretaryPosition.getFunction().addAll(_returnBatchTypeVal1AdministrationSecretaryPositionFunction);
            java.util.List<bg.government.iisda.ras.UnitPositionCommonDataType> _returnBatchTypeVal1AdministrationSecretaryPositionChildPositionsAndUnit = new java.util.ArrayList<bg.government.iisda.ras.UnitPositionCommonDataType>();
            _returnBatchTypeVal1AdministrationSecretaryPosition.getChildPositionsAndUnit().addAll(_returnBatchTypeVal1AdministrationSecretaryPositionChildPositionsAndUnit);
            java.util.List<bg.government.iisda.ras.UpFunctionCategoryType> _returnBatchTypeVal1AdministrationSecretaryPositionUpFunctionCategory = new java.util.ArrayList<bg.government.iisda.ras.UpFunctionCategoryType>();
            _returnBatchTypeVal1AdministrationSecretaryPosition.getUpFunctionCategory().addAll(_returnBatchTypeVal1AdministrationSecretaryPositionUpFunctionCategory);
            _returnBatchTypeVal1AdministrationSecretaryPosition.setUnitPosID(-7998575849478047618l);
            _returnBatchTypeVal1AdministrationSecretaryPosition.setVersionID(7561188453053768187l);
            _returnBatchTypeVal1AdministrationSecretaryPosition.setName("Name1510164326");
            bg.government.iisda.ras.ObjectKindEnum _returnBatchTypeVal1AdministrationSecretaryPositionKind = bg.government.iisda.ras.ObjectKindEnum.TREASURER;
            _returnBatchTypeVal1AdministrationSecretaryPosition.setKind(_returnBatchTypeVal1AdministrationSecretaryPositionKind);
            _returnBatchTypeVal1AdministrationSecretaryPosition.setParentID(Long.valueOf(1902547089148407876l));
            bg.government.iisda.ras.UnitPositionAdministrationTypeEnum _returnBatchTypeVal1AdministrationSecretaryPositionAdministrationType = bg.government.iisda.ras.UnitPositionAdministrationTypeEnum.TERRITORIAL_SPECIALIZED_ADMINISTRATION;
            _returnBatchTypeVal1AdministrationSecretaryPosition.setAdministrationType(_returnBatchTypeVal1AdministrationSecretaryPositionAdministrationType);
            _returnBatchTypeVal1AdministrationSecretaryPosition.setRank(4278259078479301491l);
            _returnBatchTypeVal1AdministrationSecretaryPosition.setCreationDate(javax.xml.datatype.DatatypeFactory.newInstance().newXMLGregorianCalendar("2020-03-22T14:14:59.213+02:00"));
            _returnBatchTypeVal1AdministrationSecretaryPosition.setClosingDate(javax.xml.datatype.DatatypeFactory.newInstance().newXMLGregorianCalendar("2020-03-22T14:14:59.213+02:00"));
            _returnBatchTypeVal1AdministrationSecretaryPosition.setProvideAccessForPeopleWithDisabilities(false);
            bg.government.iisda.ras.UnitPositionStatusEnum _returnBatchTypeVal1AdministrationSecretaryPositionStatus = bg.government.iisda.ras.UnitPositionStatusEnum.DEACTIVATED;
            _returnBatchTypeVal1AdministrationSecretaryPosition.setStatus(_returnBatchTypeVal1AdministrationSecretaryPositionStatus);
            bg.government.iisda.ras.UpPositionPersonType _returnBatchTypeVal1AdministrationSecretaryPositionPositionPersonData = new bg.government.iisda.ras.UpPositionPersonType();
            bg.government.iisda.ras.common.PersonDataType _returnBatchTypeVal1AdministrationSecretaryPositionPositionPersonDataPersonData = new bg.government.iisda.ras.common.PersonDataType();
            _returnBatchTypeVal1AdministrationSecretaryPositionPositionPersonDataPersonData.setPersonDataID(7128787867280363308l);
            _returnBatchTypeVal1AdministrationSecretaryPositionPositionPersonDataPersonData.setVersionID(7880515004510120485l);
            _returnBatchTypeVal1AdministrationSecretaryPositionPositionPersonDataPersonData.setFirstName("FirstName161224035");
            _returnBatchTypeVal1AdministrationSecretaryPositionPositionPersonDataPersonData.setSecondName("SecondName731841183");
            _returnBatchTypeVal1AdministrationSecretaryPositionPositionPersonDataPersonData.setThirdName("ThirdName-1542161403");
            _returnBatchTypeVal1AdministrationSecretaryPositionPositionPersonDataPersonData.setEmail("Email629012376");
            _returnBatchTypeVal1AdministrationSecretaryPositionPositionPersonData.setPersonData(_returnBatchTypeVal1AdministrationSecretaryPositionPositionPersonDataPersonData);
            _returnBatchTypeVal1AdministrationSecretaryPositionPositionPersonData.setUpPstnPersonID(2141144220744914301l);
            _returnBatchTypeVal1AdministrationSecretaryPositionPositionPersonData.setVersionID(-6893553999838173537l);
            _returnBatchTypeVal1AdministrationSecretaryPositionPositionPersonData.setTakeOfficeDate(javax.xml.datatype.DatatypeFactory.newInstance().newXMLGregorianCalendar("2020-03-22T14:14:59.213+02:00"));
            _returnBatchTypeVal1AdministrationSecretaryPositionPositionPersonData.setLeaveOfficeDate(javax.xml.datatype.DatatypeFactory.newInstance().newXMLGregorianCalendar("2020-03-22T14:14:59.214+02:00"));
            _returnBatchTypeVal1AdministrationSecretaryPosition.setPositionPersonData(_returnBatchTypeVal1AdministrationSecretaryPositionPositionPersonData);
            bg.government.iisda.ras.UpPositionPersonType _returnBatchTypeVal1AdministrationSecretaryPositionPrevPositionPersonData = new bg.government.iisda.ras.UpPositionPersonType();
            bg.government.iisda.ras.common.PersonDataType _returnBatchTypeVal1AdministrationSecretaryPositionPrevPositionPersonDataPersonData = new bg.government.iisda.ras.common.PersonDataType();
            _returnBatchTypeVal1AdministrationSecretaryPositionPrevPositionPersonDataPersonData.setPersonDataID(8122871173068442549l);
            _returnBatchTypeVal1AdministrationSecretaryPositionPrevPositionPersonDataPersonData.setVersionID(-3526039157024851448l);
            _returnBatchTypeVal1AdministrationSecretaryPositionPrevPositionPersonDataPersonData.setFirstName("FirstName1198817899");
            _returnBatchTypeVal1AdministrationSecretaryPositionPrevPositionPersonDataPersonData.setSecondName("SecondName-1197958850");
            _returnBatchTypeVal1AdministrationSecretaryPositionPrevPositionPersonDataPersonData.setThirdName("ThirdName-497687026");
            _returnBatchTypeVal1AdministrationSecretaryPositionPrevPositionPersonDataPersonData.setEmail("Email-1028419360");
            _returnBatchTypeVal1AdministrationSecretaryPositionPrevPositionPersonData.setPersonData(_returnBatchTypeVal1AdministrationSecretaryPositionPrevPositionPersonDataPersonData);
            _returnBatchTypeVal1AdministrationSecretaryPositionPrevPositionPersonData.setUpPstnPersonID(5810975918593586706l);
            _returnBatchTypeVal1AdministrationSecretaryPositionPrevPositionPersonData.setVersionID(-4004899156881652716l);
            _returnBatchTypeVal1AdministrationSecretaryPositionPrevPositionPersonData.setTakeOfficeDate(javax.xml.datatype.DatatypeFactory.newInstance().newXMLGregorianCalendar("2020-03-22T14:14:59.214+02:00"));
            _returnBatchTypeVal1AdministrationSecretaryPositionPrevPositionPersonData.setLeaveOfficeDate(javax.xml.datatype.DatatypeFactory.newInstance().newXMLGregorianCalendar("2020-03-22T14:14:59.214+02:00"));
            _returnBatchTypeVal1AdministrationSecretaryPosition.setPrevPositionPersonData(_returnBatchTypeVal1AdministrationSecretaryPositionPrevPositionPersonData);
            _returnBatchTypeVal1AdministrationSecretaryPosition.setDoesHeadExecutePosition(true);
            _returnBatchTypeVal1Administration.setSecretaryPosition(_returnBatchTypeVal1AdministrationSecretaryPosition);
            _returnBatchTypeVal1Administration.setBatchID(7214184398105707139l);
            _returnBatchTypeVal1Administration.setVersionID(5961000478235105053l);
            _returnBatchTypeVal1Administration.setUIC("UIC1296577431");
            _returnBatchTypeVal1Administration.setHeadPositionID(Long.valueOf(-5965728285349587375l));
            _returnBatchTypeVal1.setAdministration(_returnBatchTypeVal1Administration);
            java.util.List<bg.government.iisda.ras.common.ActType> _returnBatchTypeVal1Act = new java.util.ArrayList<bg.government.iisda.ras.common.ActType>();
            _returnBatchTypeVal1.getAct().addAll(_returnBatchTypeVal1Act);
            java.util.List<bg.government.iisda.ras.common.PolicyAreaType> _returnBatchTypeVal1PolicyArea = new java.util.ArrayList<bg.government.iisda.ras.common.PolicyAreaType>();
            _returnBatchTypeVal1.getPolicyArea().addAll(_returnBatchTypeVal1PolicyArea);
            java.util.List<bg.government.iisda.ras.GoverningBodyType> _returnBatchTypeVal1GoverningBody = new java.util.ArrayList<bg.government.iisda.ras.GoverningBodyType>();
            _returnBatchTypeVal1.getGoverningBody().addAll(_returnBatchTypeVal1GoverningBody);
            bg.government.iisda.ras.GovernmentType _returnBatchTypeVal1Government = new bg.government.iisda.ras.GovernmentType();
            _returnBatchTypeVal1Government.setGovernmentID(39425188850675726l);
            _returnBatchTypeVal1Government.setVersionID(6431876034023776999l);
            bg.government.iisda.ras.GovernmentTypeEnum _returnBatchTypeVal1GovernmentType = bg.government.iisda.ras.GovernmentTypeEnum.REGULAR;
            _returnBatchTypeVal1Government.setType(_returnBatchTypeVal1GovernmentType);
            _returnBatchTypeVal1Government.setCeasePowersDate(javax.xml.datatype.DatatypeFactory.newInstance().newXMLGregorianCalendar("2020-03-22T14:14:59.215+02:00"));
            _returnBatchTypeVal1Government.setFromDate(javax.xml.datatype.DatatypeFactory.newInstance().newXMLGregorianCalendar("2020-03-22T14:14:59.215+02:00"));
            _returnBatchTypeVal1Government.setToDate(javax.xml.datatype.DatatypeFactory.newInstance().newXMLGregorianCalendar("2020-03-22T14:14:59.215+02:00"));
            _returnBatchTypeVal1.setGovernment(_returnBatchTypeVal1Government);
            bg.government.iisda.ras.GovernmentType _returnBatchTypeVal1PrevGovernment = new bg.government.iisda.ras.GovernmentType();
            _returnBatchTypeVal1PrevGovernment.setGovernmentID(-9110389347138334912l);
            _returnBatchTypeVal1PrevGovernment.setVersionID(4933308535692856232l);
            bg.government.iisda.ras.GovernmentTypeEnum _returnBatchTypeVal1PrevGovernmentType = bg.government.iisda.ras.GovernmentTypeEnum.REGULAR;
            _returnBatchTypeVal1PrevGovernment.setType(_returnBatchTypeVal1PrevGovernmentType);
            _returnBatchTypeVal1PrevGovernment.setCeasePowersDate(javax.xml.datatype.DatatypeFactory.newInstance().newXMLGregorianCalendar("2020-03-22T14:14:59.216+02:00"));
            _returnBatchTypeVal1PrevGovernment.setFromDate(javax.xml.datatype.DatatypeFactory.newInstance().newXMLGregorianCalendar("2020-03-22T14:14:59.216+02:00"));
            _returnBatchTypeVal1PrevGovernment.setToDate(javax.xml.datatype.DatatypeFactory.newInstance().newXMLGregorianCalendar("2020-03-22T14:14:59.216+02:00"));
            _returnBatchTypeVal1.setPrevGovernment(_returnBatchTypeVal1PrevGovernment);
            bg.government.iisda.ras.BatchRelationshipType _returnBatchTypeVal1StewardWithMoneyBatch = new bg.government.iisda.ras.BatchRelationshipType();
            bg.government.iisda.ras.BatchIdentificationInfoType _returnBatchTypeVal1StewardWithMoneyBatchRelatedBatch = new bg.government.iisda.ras.BatchIdentificationInfoType();
            _returnBatchTypeVal1StewardWithMoneyBatchRelatedBatch.setBatchID(-3814965994799292095l);
            bg.government.iisda.ras.BatchTypeEnum _returnBatchTypeVal1StewardWithMoneyBatchRelatedBatchType = bg.government.iisda.ras.BatchTypeEnum.ADVISORY_BOARD;
            _returnBatchTypeVal1StewardWithMoneyBatchRelatedBatch.setType(_returnBatchTypeVal1StewardWithMoneyBatchRelatedBatchType);
            _returnBatchTypeVal1StewardWithMoneyBatchRelatedBatch.setIdentificationNumber("IdentificationNumber-1754400977");
            _returnBatchTypeVal1StewardWithMoneyBatchRelatedBatch.setName("Name1821301123");
            bg.government.iisda.ras.AdmStructureKindsEnum _returnBatchTypeVal1StewardWithMoneyBatchRelatedBatchAdmStructureKind = bg.government.iisda.ras.AdmStructureKindsEnum.SPECIALIZED_LOCAL_ADMINISTRATION;
            _returnBatchTypeVal1StewardWithMoneyBatchRelatedBatch.setAdmStructureKind(_returnBatchTypeVal1StewardWithMoneyBatchRelatedBatchAdmStructureKind);
            _returnBatchTypeVal1StewardWithMoneyBatchRelatedBatch.setUIC("UIC-1396051913");
            bg.government.iisda.ras.BatchStatusEnum _returnBatchTypeVal1StewardWithMoneyBatchRelatedBatchStatus = bg.government.iisda.ras.BatchStatusEnum.CLOSED;
            _returnBatchTypeVal1StewardWithMoneyBatchRelatedBatch.setStatus(_returnBatchTypeVal1StewardWithMoneyBatchRelatedBatchStatus);
            _returnBatchTypeVal1StewardWithMoneyBatch.setRelatedBatch(_returnBatchTypeVal1StewardWithMoneyBatchRelatedBatch);
            _returnBatchTypeVal1StewardWithMoneyBatch.setBatchRelationshipID(8161725350652337035l);
            _returnBatchTypeVal1StewardWithMoneyBatch.setVersionID(-1220221046835245543l);
            _returnBatchTypeVal1.setStewardWithMoneyBatch(_returnBatchTypeVal1StewardWithMoneyBatch);
            java.util.List<bg.government.iisda.ras.BatchRelationshipType> _returnBatchTypeVal1StandaloneStructsToBatch = new java.util.ArrayList<bg.government.iisda.ras.BatchRelationshipType>();
            _returnBatchTypeVal1.getStandaloneStructsToBatch().addAll(_returnBatchTypeVal1StandaloneStructsToBatch);
            java.util.List<bg.government.iisda.ras.BatchRelationshipType> _returnBatchTypeVal1AdvBoardsToComOrAdmStruct = new java.util.ArrayList<bg.government.iisda.ras.BatchRelationshipType>();
            _returnBatchTypeVal1.getAdvBoardsToComOrAdmStruct().addAll(_returnBatchTypeVal1AdvBoardsToComOrAdmStruct);
            java.util.List<bg.government.iisda.ras.TownHallType> _returnBatchTypeVal1TownHalls = new java.util.ArrayList<bg.government.iisda.ras.TownHallType>();
            _returnBatchTypeVal1.getTownHalls().addAll(_returnBatchTypeVal1TownHalls);
            java.util.List<bg.government.iisda.ras.DeputyMayorType> _returnBatchTypeVal1DeputyMayors = new java.util.ArrayList<bg.government.iisda.ras.DeputyMayorType>();
            _returnBatchTypeVal1.getDeputyMayors().addAll(_returnBatchTypeVal1DeputyMayors);
            java.util.List<bg.government.iisda.ras.common.BatchIAAPositionType> _returnBatchTypeVal1BatchIAAPosition = new java.util.ArrayList<bg.government.iisda.ras.common.BatchIAAPositionType>();
            _returnBatchTypeVal1.getBatchIAAPosition().addAll(_returnBatchTypeVal1BatchIAAPosition);
            java.util.List<bg.government.iisda.ras.common.BatchIAAPersonType> _returnBatchTypeVal1BatchIAAPerson = new java.util.ArrayList<bg.government.iisda.ras.common.BatchIAAPersonType>();
            _returnBatchTypeVal1.getBatchIAAPerson().addAll(_returnBatchTypeVal1BatchIAAPerson);
            bg.government.iisda.ras.common.StaffNumbersType _returnBatchTypeVal1StaffNumbers = new bg.government.iisda.ras.common.StaffNumbersType();
            _returnBatchTypeVal1StaffNumbers.setStaffNumbersID(5107616042361950379l);
            _returnBatchTypeVal1StaffNumbers.setVersionID(4898311475425054438l);
            _returnBatchTypeVal1StaffNumbers.setTotalStaffNumbers(Double.valueOf(0.397255371045915));
            _returnBatchTypeVal1StaffNumbers.setExpertsNumbers(Double.valueOf(0.8332447399979539));
            _returnBatchTypeVal1StaffNumbers.setAdvisorsNumbers(Double.valueOf(0.023818340604646826));
            _returnBatchTypeVal1StaffNumbers.setCivilServantNumbers(Double.valueOf(0.23352997752242532));
            _returnBatchTypeVal1StaffNumbers.setEmploymentNumbers(Double.valueOf(0.7131072108262908));
            _returnBatchTypeVal1StaffNumbers.setBodiesDeputiesNumbers(Double.valueOf(0.05493669774925469));
            _returnBatchTypeVal1.setStaffNumbers(_returnBatchTypeVal1StaffNumbers);
            bg.government.iisda.ras.common.VacantPositionsNumbersType _returnBatchTypeVal1VacantPositionsNumbers = new bg.government.iisda.ras.common.VacantPositionsNumbersType();
            _returnBatchTypeVal1VacantPositionsNumbers.setVacantPositionsNumbersID(8414219872783837641l);
            _returnBatchTypeVal1VacantPositionsNumbers.setVersionID(-1542290444807984094l);
            _returnBatchTypeVal1VacantPositionsNumbers.setTotalVacantPositions(Double.valueOf(0.2612903672728));
            _returnBatchTypeVal1VacantPositionsNumbers.setCsVacantPosition(Double.valueOf(0.9210520649909412));
            _returnBatchTypeVal1VacantPositionsNumbers.setEmpltVacantPositions(Double.valueOf(0.36415721886689345));
            _returnBatchTypeVal1.setVacantPositionsNumbers(_returnBatchTypeVal1VacantPositionsNumbers);
            _returnBatchTypeVal1.setBatchID(2027800174514707663l);
            _returnBatchTypeVal1.setVersionID(-3112435256287490770l);
            bg.government.iisda.ras.BatchTypeEnum _returnBatchTypeVal1Type = bg.government.iisda.ras.BatchTypeEnum.ADVISORY_BOARD;
            _returnBatchTypeVal1.setType(_returnBatchTypeVal1Type);
            _returnBatchTypeVal1.setIdentificationNumber("IdentificationNumber772921267");
            _returnBatchTypeVal1.setName("Name-1161213437");
            bg.government.iisda.ras.BatchStatusEnum _returnBatchTypeVal1Status = bg.government.iisda.ras.BatchStatusEnum.CLOSED;
            _returnBatchTypeVal1.setStatus(_returnBatchTypeVal1Status);
            _returnBatchTypeVal1.setBudgetOfficerLevel(Byte.valueOf((byte)123));
            bg.government.iisda.ras.AdmStructureKindsEnum _returnBatchTypeVal1AdmStructureKind = bg.government.iisda.ras.AdmStructureKindsEnum.COUNCIL_OF_MINISTERS_ADMINISTRATION;
            _returnBatchTypeVal1.setAdmStructureKind(_returnBatchTypeVal1AdmStructureKind);
            _returnBatchType.add(_returnBatchTypeVal1);
            _return.getBatchType().addAll(_returnBatchType);
            return _return;
        } catch (java.lang.Exception ex) {
            ex.printStackTrace();
            throw new RuntimeException(ex);
        }
    }

    /* (non-Javadoc)
     * @see bg.government.iisda.ras.integrationservices.IBatchInfoService#searchBatchVersions(java.lang.String batchIdentificationNumber, javax.xml.datatype.XMLGregorianCalendar fromDate, javax.xml.datatype.XMLGregorianCalendar toDate)*
     */
    public bg.government.iisda.ras.integrationservices.ArrayOfVersionBatchInfoType searchBatchVersions(java.lang.String batchIdentificationNumber, javax.xml.datatype.XMLGregorianCalendar fromDate, javax.xml.datatype.XMLGregorianCalendar toDate) {
        LOG.info("Executing operation searchBatchVersions");
        System.out.println(batchIdentificationNumber);
        System.out.println(fromDate);
        System.out.println(toDate);
        try {
            bg.government.iisda.ras.integrationservices.ArrayOfVersionBatchInfoType _return = new bg.government.iisda.ras.integrationservices.ArrayOfVersionBatchInfoType();
            java.util.List<bg.government.iisda.ras.VersionBatchInfoType> _returnVersionBatchInfoType = new java.util.ArrayList<bg.government.iisda.ras.VersionBatchInfoType>();
            bg.government.iisda.ras.VersionBatchInfoType _returnVersionBatchInfoTypeVal1 = new bg.government.iisda.ras.VersionBatchInfoType();
            _returnVersionBatchInfoTypeVal1.setVersionID(Long.valueOf(9168053200057195693l));
            _returnVersionBatchInfoTypeVal1.setActivationDate(javax.xml.datatype.DatatypeFactory.newInstance().newXMLGregorianCalendar("2020-03-22T14:14:59.218+02:00"));
            _returnVersionBatchInfoTypeVal1.setReason("Reason1808937799");
            _returnVersionBatchInfoTypeVal1.setValidFrom(javax.xml.datatype.DatatypeFactory.newInstance().newXMLGregorianCalendar("2020-03-22T14:14:59.218+02:00"));
            java.util.List<bg.government.iisda.ras.BatchIdentificationInfoType> _returnVersionBatchInfoTypeVal1ChangedBatch = new java.util.ArrayList<bg.government.iisda.ras.BatchIdentificationInfoType>();
            _returnVersionBatchInfoTypeVal1.getChangedBatch().addAll(_returnVersionBatchInfoTypeVal1ChangedBatch);
            _returnVersionBatchInfoType.add(_returnVersionBatchInfoTypeVal1);
            _return.getVersionBatchInfoType().addAll(_returnVersionBatchInfoType);
            return _return;
        } catch (java.lang.Exception ex) {
            ex.printStackTrace();
            throw new RuntimeException(ex);
        }
    }

    /* (non-Javadoc)
     * @see bg.government.iisda.ras.integrationservices.IBatchInfoService#getTerritorialAdmStructure(java.lang.String uic)*
     */
    public bg.government.iisda.ras.TerritorialAdmStructure getTerritorialAdmStructure(java.lang.String uic) {
        LOG.info("Executing operation getTerritorialAdmStructure");
        System.out.println(uic);
        try {
            bg.government.iisda.ras.TerritorialAdmStructure _return = new bg.government.iisda.ras.TerritorialAdmStructure();
            _return.setIdentificationNumber("IdentificationNumber1479384318");
            _return.setName("Name649519311");
            _return.setFullName("FullName-448008197");
            _return.setUIC("UIC-1609948877");
            bg.government.iisda.ras.AdmStructureKindsEnum _returnAdmStructureKind = bg.government.iisda.ras.AdmStructureKindsEnum.COUNCIL;
            _return.setAdmStructureKind(_returnAdmStructureKind);
            return _return;
        } catch (java.lang.Exception ex) {
            ex.printStackTrace();
            throw new RuntimeException(ex);
        }
    }

    /* (non-Javadoc)
     * @see bg.government.iisda.ras.integrationservices.IBatchInfoService#searchBatchesIdentificationInfo(java.lang.String batchIdentificationNumber, java.lang.String batchUIC, bg.government.iisda.ras.AdmStructureKindsEnum admStructureKind, bg.government.iisda.ras.BatchTypeEnum batchType, bg.government.iisda.ras.BatchStatusEnum status, javax.xml.datatype.XMLGregorianCalendar dateAt, java.lang.Long versionIDAt)*
     */
    public bg.government.iisda.ras.integrationservices.ArrayOfBatchIdentificationInfoType searchBatchesIdentificationInfo(java.lang.String batchIdentificationNumber, java.lang.String batchUIC, bg.government.iisda.ras.AdmStructureKindsEnum admStructureKind, bg.government.iisda.ras.BatchTypeEnum batchType, bg.government.iisda.ras.BatchStatusEnum status, javax.xml.datatype.XMLGregorianCalendar dateAt, java.lang.Long versionIDAt) {
        LOG.info("Executing operation searchBatchesIdentificationInfo");
        System.out.println(batchIdentificationNumber);
        System.out.println(batchUIC);
        System.out.println(admStructureKind);
        System.out.println(batchType);
        System.out.println(status);
        System.out.println(dateAt);
        System.out.println(versionIDAt);
        try {
            bg.government.iisda.ras.integrationservices.ArrayOfBatchIdentificationInfoType _return = new bg.government.iisda.ras.integrationservices.ArrayOfBatchIdentificationInfoType();
            java.util.List<bg.government.iisda.ras.BatchIdentificationInfoType> _returnBatchIdentificationInfoType = new java.util.ArrayList<bg.government.iisda.ras.BatchIdentificationInfoType>();
            bg.government.iisda.ras.BatchIdentificationInfoType _returnBatchIdentificationInfoTypeVal1 = new bg.government.iisda.ras.BatchIdentificationInfoType();
            _returnBatchIdentificationInfoTypeVal1.setBatchID(8379504190649617423l);
            bg.government.iisda.ras.BatchTypeEnum _returnBatchIdentificationInfoTypeVal1Type = bg.government.iisda.ras.BatchTypeEnum.COM;
            _returnBatchIdentificationInfoTypeVal1.setType(_returnBatchIdentificationInfoTypeVal1Type);
            _returnBatchIdentificationInfoTypeVal1.setIdentificationNumber("IdentificationNumber-1025690098");
            _returnBatchIdentificationInfoTypeVal1.setName("Name-1133246309");
            bg.government.iisda.ras.AdmStructureKindsEnum _returnBatchIdentificationInfoTypeVal1AdmStructureKind = bg.government.iisda.ras.AdmStructureKindsEnum.SPECIALIZED_LOCAL_ADMINISTRATION;
            _returnBatchIdentificationInfoTypeVal1.setAdmStructureKind(_returnBatchIdentificationInfoTypeVal1AdmStructureKind);
            _returnBatchIdentificationInfoTypeVal1.setUIC("UIC-966731060");
            bg.government.iisda.ras.BatchStatusEnum _returnBatchIdentificationInfoTypeVal1Status = bg.government.iisda.ras.BatchStatusEnum.CLOSED;
            _returnBatchIdentificationInfoTypeVal1.setStatus(_returnBatchIdentificationInfoTypeVal1Status);
            _returnBatchIdentificationInfoType.add(_returnBatchIdentificationInfoTypeVal1);
            _return.getBatchIdentificationInfoType().addAll(_returnBatchIdentificationInfoType);
            return _return;
        } catch (java.lang.Exception ex) {
            ex.printStackTrace();
            throw new RuntimeException(ex);
        }
    }

}
