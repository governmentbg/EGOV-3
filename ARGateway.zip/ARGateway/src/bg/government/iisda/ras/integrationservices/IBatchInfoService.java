package bg.government.iisda.ras.integrationservices;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.ws.Action;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

@WebService(targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices", name = "IBatchInfoService")
@XmlSeeAlso({bg.government.iisda.ras.common.ObjectFactory.class, ObjectFactory.class, bg.government.iisda.ras.versioning.ObjectFactory.class, bg.government.iisda.ras.ObjectFactory.class})
public interface IBatchInfoService {

    @WebMethod(operationName = "GetBatchDetailedInfo", action = "http://iisda.government.bg/RAS/IntegrationServices/IBatchInfoService/GetBatchDetailedInfo")
    @Action(input = "http://iisda.government.bg/RAS/IntegrationServices/IBatchInfoService/GetBatchDetailedInfo", output = "http://iisda.government.bg/RAS/IntegrationServices/IBatchInfoService/GetBatchDetailedInfoResponse")
    @RequestWrapper(localName = "GetBatchDetailedInfo", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices", className = "bg.government.iisda.ras.integrationservices.GetBatchDetailedInfo")
    @ResponseWrapper(localName = "GetBatchDetailedInfoResponse", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices", className = "bg.government.iisda.ras.integrationservices.GetBatchDetailedInfoResponse")
    @WebResult(name = "GetBatchDetailedInfoResult", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices")
    public bg.government.iisda.ras.integrationservices.ArrayOfBatchType getBatchDetailedInfo(

        @WebParam(name = "batchIdentificationNumber", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices")
        bg.government.iisda.ras.integrationservices.ArrayOfString batchIdentificationNumber,
        @WebParam(name = "dateAt", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices")
        javax.xml.datatype.XMLGregorianCalendar dateAt,
        @WebParam(name = "versionIDAt", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices")
        java.lang.Long versionIDAt
    );

    @WebMethod(operationName = "SearchBatchVersions", action = "http://iisda.government.bg/RAS/IntegrationServices/IBatchInfoService/SearchBatchVersions")
    @Action(input = "http://iisda.government.bg/RAS/IntegrationServices/IBatchInfoService/SearchBatchVersions", output = "http://iisda.government.bg/RAS/IntegrationServices/IBatchInfoService/SearchBatchVersionsResponse")
    @RequestWrapper(localName = "SearchBatchVersions", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices", className = "bg.government.iisda.ras.integrationservices.SearchBatchVersions")
    @ResponseWrapper(localName = "SearchBatchVersionsResponse", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices", className = "bg.government.iisda.ras.integrationservices.SearchBatchVersionsResponse")
    @WebResult(name = "SearchBatchVersionsResult", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices")
    public bg.government.iisda.ras.integrationservices.ArrayOfVersionBatchInfoType searchBatchVersions(

        @WebParam(name = "batchIdentificationNumber", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices")
        java.lang.String batchIdentificationNumber,
        @WebParam(name = "fromDate", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices")
        javax.xml.datatype.XMLGregorianCalendar fromDate,
        @WebParam(name = "toDate", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices")
        javax.xml.datatype.XMLGregorianCalendar toDate
    );

    @WebMethod(operationName = "GetTerritorialAdmStructure", action = "http://iisda.government.bg/RAS/IntegrationServices/IBatchInfoService/GetTerritorialAdmStructure")
    @Action(input = "http://iisda.government.bg/RAS/IntegrationServices/IBatchInfoService/GetTerritorialAdmStructure", output = "http://iisda.government.bg/RAS/IntegrationServices/IBatchInfoService/GetTerritorialAdmStructureResponse")
    @RequestWrapper(localName = "GetTerritorialAdmStructure", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices", className = "bg.government.iisda.ras.integrationservices.GetTerritorialAdmStructure")
    @ResponseWrapper(localName = "GetTerritorialAdmStructureResponse", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices", className = "bg.government.iisda.ras.integrationservices.GetTerritorialAdmStructureResponse")
    @WebResult(name = "GetTerritorialAdmStructureResult", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices")
    public bg.government.iisda.ras.TerritorialAdmStructure getTerritorialAdmStructure(

        @WebParam(name = "uic", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices")
        java.lang.String uic
    );

    @WebMethod(operationName = "SearchBatchesIdentificationInfo", action = "http://iisda.government.bg/RAS/IntegrationServices/IBatchInfoService/SearchBatchesIdentificationInfo")
    @Action(input = "http://iisda.government.bg/RAS/IntegrationServices/IBatchInfoService/SearchBatchesIdentificationInfo", output = "http://iisda.government.bg/RAS/IntegrationServices/IBatchInfoService/SearchBatchesIdentificationInfoResponse")
    @RequestWrapper(localName = "SearchBatchesIdentificationInfo", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices", className = "bg.government.iisda.ras.integrationservices.SearchBatchesIdentificationInfo")
    @ResponseWrapper(localName = "SearchBatchesIdentificationInfoResponse", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices", className = "bg.government.iisda.ras.integrationservices.SearchBatchesIdentificationInfoResponse")
    @WebResult(name = "SearchBatchesIdentificationInfoResult", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices")
    public bg.government.iisda.ras.integrationservices.ArrayOfBatchIdentificationInfoType searchBatchesIdentificationInfo(

        @WebParam(name = "batchIdentificationNumber", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices")
        java.lang.String batchIdentificationNumber,
        @WebParam(name = "batchUIC", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices")
        java.lang.String batchUIC,
        @WebParam(name = "admStructureKind", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices")
        bg.government.iisda.ras.AdmStructureKindsEnum admStructureKind,
        @WebParam(name = "batchType", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices")
        bg.government.iisda.ras.BatchTypeEnum batchType,
        @WebParam(name = "status", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices")
        bg.government.iisda.ras.BatchStatusEnum status,
        @WebParam(name = "dateAt", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices")
        javax.xml.datatype.XMLGregorianCalendar dateAt,
        @WebParam(name = "versionIDAt", targetNamespace = "http://iisda.government.bg/RAS/IntegrationServices")
        java.lang.Long versionIDAt
    );
}
