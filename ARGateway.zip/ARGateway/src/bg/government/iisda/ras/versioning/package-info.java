@javax.xml.bind.annotation.XmlSchema(namespace = "http://iisda.government.bg/RAS/Versioning")
package bg.government.iisda.ras.versioning;
