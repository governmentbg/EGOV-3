
package bg.government.iisda.ras.common;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the bg.government.iisda.ras.common package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: bg.government.iisda.ras.common
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link StaffNumbersType }
     * 
     */
    public StaffNumbersType createStaffNumbersType() {
        return new StaffNumbersType();
    }

    /**
     * Create an instance of {@link VacantPositionsNumbersType }
     * 
     */
    public VacantPositionsNumbersType createVacantPositionsNumbersType() {
        return new VacantPositionsNumbersType();
    }

    /**
     * Create an instance of {@link PowerCompetenceFunctionType }
     * 
     */
    public PowerCompetenceFunctionType createPowerCompetenceFunctionType() {
        return new PowerCompetenceFunctionType();
    }

    /**
     * Create an instance of {@link ActDataType }
     * 
     */
    public ActDataType createActDataType() {
        return new ActDataType();
    }

    /**
     * Create an instance of {@link ActBaseType }
     * 
     */
    public ActBaseType createActBaseType() {
        return new ActBaseType();
    }

    /**
     * Create an instance of {@link StateGazetteNumberType }
     * 
     */
    public StateGazetteNumberType createStateGazetteNumberType() {
        return new StateGazetteNumberType();
    }

    /**
     * Create an instance of {@link ActChangeType }
     * 
     */
    public ActChangeType createActChangeType() {
        return new ActChangeType();
    }

    /**
     * Create an instance of {@link ActType }
     * 
     */
    public ActType createActType() {
        return new ActType();
    }

    /**
     * Create an instance of {@link PersonDataType }
     * 
     */
    public PersonDataType createPersonDataType() {
        return new PersonDataType();
    }

    /**
     * Create an instance of {@link CorrespondenceDataType }
     * 
     */
    public CorrespondenceDataType createCorrespondenceDataType() {
        return new CorrespondenceDataType();
    }

    /**
     * Create an instance of {@link CorrespondenceDataPhoneType }
     * 
     */
    public CorrespondenceDataPhoneType createCorrespondenceDataPhoneType() {
        return new CorrespondenceDataPhoneType();
    }

    /**
     * Create an instance of {@link AddressType }
     * 
     */
    public AddressType createAddressType() {
        return new AddressType();
    }

    /**
     * Create an instance of {@link EkatteAddressType }
     * 
     */
    public EkatteAddressType createEkatteAddressType() {
        return new EkatteAddressType();
    }

    /**
     * Create an instance of {@link WorkingTimeType }
     * 
     */
    public WorkingTimeType createWorkingTimeType() {
        return new WorkingTimeType();
    }

    /**
     * Create an instance of {@link PolicyAreaType }
     * 
     */
    public PolicyAreaType createPolicyAreaType() {
        return new PolicyAreaType();
    }

    /**
     * Create an instance of {@link BatchIAAPositionType }
     * 
     */
    public BatchIAAPositionType createBatchIAAPositionType() {
        return new BatchIAAPositionType();
    }

    /**
     * Create an instance of {@link BatchIAAPersonType }
     * 
     */
    public BatchIAAPersonType createBatchIAAPersonType() {
        return new BatchIAAPersonType();
    }

}
