@javax.xml.bind.annotation.XmlSchema(namespace = "http://iisda.government.bg/AdmServices/Common", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package bg.government.iisda.admservices.common;
