
package bg.government.iisda.admservices;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlMixed;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AdmServiceInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AdmServiceInfoType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PaymentInfo" type="{http://iisda.government.bg/AdmServices/}PaymentInfoType" minOccurs="0"/&gt;
 *         &lt;element name="GrantTerm" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OperationTerm" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="AppealGovBodyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ControlGovBodyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ProvisionGovBodyName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="OrderAndAppealTerms" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;any/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="Limitations" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;any/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *         &lt;element name="ServiceApplicationMethods" type="{http://iisda.government.bg/AdmServices/}ArrayOfServiceApplicationMethodsEnum" minOccurs="0"/&gt;
 *         &lt;element name="ServicingUnitContactData" type="{http://iisda.government.bg/AdmServices/}UnitContactType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Stages" type="{http://iisda.government.bg/AdmServices/}ArrayOfAdmServiceStageType" minOccurs="0"/&gt;
 *         &lt;element name="RegulatoryRegimeDocuments" type="{http://iisda.government.bg/AdmServices/}ArrayOfAdmServiceInfoDocumentType" minOccurs="0"/&gt;
 *         &lt;element name="ModelDocuments" type="{http://iisda.government.bg/AdmServices/}ArrayOfAdmServiceInfoDocumentType" minOccurs="0"/&gt;
 *         &lt;element name="IaaPositions" type="{http://iisda.government.bg/AdmServices/}ArrayOfBatchIAAPositionType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="ServiceID" use="required" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="BatchUIC" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="BatchName" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="ServiceNumber" use="required" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="Name" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="ServiceProvisionLevel" type="{http://iisda.government.bg/AdmServices/}ServiceProvisionLevelsEnum" /&gt;
 *       &lt;attribute name="ProvisionEAddress" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="SuggestionsEAddress" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="HasCivilPurpose" use="required" type="{http://www.w3.org/2001/XMLSchema}boolean" /&gt;
 *       &lt;attribute name="HasBusinessPurpose" use="required" type="{http://www.w3.org/2001/XMLSchema}boolean" /&gt;
 *       &lt;attribute name="PublicBatchPreviewUrl" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="RefNumber" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="PublicAdmServiceInfoPreviewUrl" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="PublicRegisterName" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="PublicRegisterWebAddress" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AdmServiceInfoType", propOrder = {
    "paymentInfo",
    "grantTerm",
    "operationTerm",
    "appealGovBodyName",
    "controlGovBodyName",
    "provisionGovBodyName",
    "orderAndAppealTerms",
    "limitations",
    "serviceApplicationMethods",
    "servicingUnitContactData",
    "stages",
    "regulatoryRegimeDocuments",
    "modelDocuments",
    "iaaPositions"
})
public class AdmServiceInfoType {

    @XmlElement(name = "PaymentInfo")
    protected PaymentInfoType paymentInfo;
    @XmlElement(name = "GrantTerm")
    protected String grantTerm;
    @XmlElement(name = "OperationTerm")
    protected String operationTerm;
    @XmlElement(name = "AppealGovBodyName")
    protected String appealGovBodyName;
    @XmlElement(name = "ControlGovBodyName")
    protected String controlGovBodyName;
    @XmlElement(name = "ProvisionGovBodyName")
    protected String provisionGovBodyName;
    @XmlElement(name = "OrderAndAppealTerms")
    protected AdmServiceInfoType.OrderAndAppealTerms orderAndAppealTerms;
    @XmlElement(name = "Limitations")
    protected AdmServiceInfoType.Limitations limitations;
    @XmlElement(name = "ServiceApplicationMethods")
    protected ArrayOfServiceApplicationMethodsEnum serviceApplicationMethods;
    @XmlElement(name = "ServicingUnitContactData")
    protected List<UnitContactType> servicingUnitContactData;
    @XmlElement(name = "Stages")
    protected ArrayOfAdmServiceStageType stages;
    @XmlElement(name = "RegulatoryRegimeDocuments")
    protected ArrayOfAdmServiceInfoDocumentType regulatoryRegimeDocuments;
    @XmlElement(name = "ModelDocuments")
    protected ArrayOfAdmServiceInfoDocumentType modelDocuments;
    @XmlElement(name = "IaaPositions")
    protected ArrayOfBatchIAAPositionType iaaPositions;
    @XmlAttribute(name = "ServiceID", required = true)
    protected long serviceID;
    @XmlAttribute(name = "BatchUIC")
    protected String batchUIC;
    @XmlAttribute(name = "BatchName")
    protected String batchName;
    @XmlAttribute(name = "ServiceNumber", required = true)
    protected long serviceNumber;
    @XmlAttribute(name = "Name")
    protected String name;
    @XmlAttribute(name = "ServiceProvisionLevel")
    protected ServiceProvisionLevelsEnum serviceProvisionLevel;
    @XmlAttribute(name = "ProvisionEAddress")
    protected String provisionEAddress;
    @XmlAttribute(name = "SuggestionsEAddress")
    protected String suggestionsEAddress;
    @XmlAttribute(name = "HasCivilPurpose", required = true)
    protected boolean hasCivilPurpose;
    @XmlAttribute(name = "HasBusinessPurpose", required = true)
    protected boolean hasBusinessPurpose;
    @XmlAttribute(name = "PublicBatchPreviewUrl")
    protected String publicBatchPreviewUrl;
    @XmlAttribute(name = "RefNumber")
    protected String refNumber;
    @XmlAttribute(name = "PublicAdmServiceInfoPreviewUrl")
    protected String publicAdmServiceInfoPreviewUrl;
    @XmlAttribute(name = "PublicRegisterName")
    protected String publicRegisterName;
    @XmlAttribute(name = "PublicRegisterWebAddress")
    protected String publicRegisterWebAddress;

    /**
     * Gets the value of the paymentInfo property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentInfoType }
     *     
     */
    public PaymentInfoType getPaymentInfo() {
        return paymentInfo;
    }

    /**
     * Sets the value of the paymentInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentInfoType }
     *     
     */
    public void setPaymentInfo(PaymentInfoType value) {
        this.paymentInfo = value;
    }

    /**
     * Gets the value of the grantTerm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGrantTerm() {
        return grantTerm;
    }

    /**
     * Sets the value of the grantTerm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGrantTerm(String value) {
        this.grantTerm = value;
    }

    /**
     * Gets the value of the operationTerm property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOperationTerm() {
        return operationTerm;
    }

    /**
     * Sets the value of the operationTerm property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOperationTerm(String value) {
        this.operationTerm = value;
    }

    /**
     * Gets the value of the appealGovBodyName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAppealGovBodyName() {
        return appealGovBodyName;
    }

    /**
     * Sets the value of the appealGovBodyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAppealGovBodyName(String value) {
        this.appealGovBodyName = value;
    }

    /**
     * Gets the value of the controlGovBodyName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getControlGovBodyName() {
        return controlGovBodyName;
    }

    /**
     * Sets the value of the controlGovBodyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setControlGovBodyName(String value) {
        this.controlGovBodyName = value;
    }

    /**
     * Gets the value of the provisionGovBodyName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProvisionGovBodyName() {
        return provisionGovBodyName;
    }

    /**
     * Sets the value of the provisionGovBodyName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProvisionGovBodyName(String value) {
        this.provisionGovBodyName = value;
    }

    /**
     * Gets the value of the orderAndAppealTerms property.
     * 
     * @return
     *     possible object is
     *     {@link AdmServiceInfoType.OrderAndAppealTerms }
     *     
     */
    public AdmServiceInfoType.OrderAndAppealTerms getOrderAndAppealTerms() {
        return orderAndAppealTerms;
    }

    /**
     * Sets the value of the orderAndAppealTerms property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdmServiceInfoType.OrderAndAppealTerms }
     *     
     */
    public void setOrderAndAppealTerms(AdmServiceInfoType.OrderAndAppealTerms value) {
        this.orderAndAppealTerms = value;
    }

    /**
     * Gets the value of the limitations property.
     * 
     * @return
     *     possible object is
     *     {@link AdmServiceInfoType.Limitations }
     *     
     */
    public AdmServiceInfoType.Limitations getLimitations() {
        return limitations;
    }

    /**
     * Sets the value of the limitations property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdmServiceInfoType.Limitations }
     *     
     */
    public void setLimitations(AdmServiceInfoType.Limitations value) {
        this.limitations = value;
    }

    /**
     * Gets the value of the serviceApplicationMethods property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfServiceApplicationMethodsEnum }
     *     
     */
    public ArrayOfServiceApplicationMethodsEnum getServiceApplicationMethods() {
        return serviceApplicationMethods;
    }

    /**
     * Sets the value of the serviceApplicationMethods property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfServiceApplicationMethodsEnum }
     *     
     */
    public void setServiceApplicationMethods(ArrayOfServiceApplicationMethodsEnum value) {
        this.serviceApplicationMethods = value;
    }

    /**
     * Gets the value of the servicingUnitContactData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the servicingUnitContactData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getServicingUnitContactData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link UnitContactType }
     * 
     * 
     */
    public List<UnitContactType> getServicingUnitContactData() {
        if (servicingUnitContactData == null) {
            servicingUnitContactData = new ArrayList<UnitContactType>();
        }
        return this.servicingUnitContactData;
    }

    /**
     * Gets the value of the stages property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfAdmServiceStageType }
     *     
     */
    public ArrayOfAdmServiceStageType getStages() {
        return stages;
    }

    /**
     * Sets the value of the stages property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfAdmServiceStageType }
     *     
     */
    public void setStages(ArrayOfAdmServiceStageType value) {
        this.stages = value;
    }

    /**
     * Gets the value of the regulatoryRegimeDocuments property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfAdmServiceInfoDocumentType }
     *     
     */
    public ArrayOfAdmServiceInfoDocumentType getRegulatoryRegimeDocuments() {
        return regulatoryRegimeDocuments;
    }

    /**
     * Sets the value of the regulatoryRegimeDocuments property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfAdmServiceInfoDocumentType }
     *     
     */
    public void setRegulatoryRegimeDocuments(ArrayOfAdmServiceInfoDocumentType value) {
        this.regulatoryRegimeDocuments = value;
    }

    /**
     * Gets the value of the modelDocuments property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfAdmServiceInfoDocumentType }
     *     
     */
    public ArrayOfAdmServiceInfoDocumentType getModelDocuments() {
        return modelDocuments;
    }

    /**
     * Sets the value of the modelDocuments property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfAdmServiceInfoDocumentType }
     *     
     */
    public void setModelDocuments(ArrayOfAdmServiceInfoDocumentType value) {
        this.modelDocuments = value;
    }

    /**
     * Gets the value of the iaaPositions property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfBatchIAAPositionType }
     *     
     */
    public ArrayOfBatchIAAPositionType getIaaPositions() {
        return iaaPositions;
    }

    /**
     * Sets the value of the iaaPositions property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfBatchIAAPositionType }
     *     
     */
    public void setIaaPositions(ArrayOfBatchIAAPositionType value) {
        this.iaaPositions = value;
    }

    /**
     * Gets the value of the serviceID property.
     * 
     */
    public long getServiceID() {
        return serviceID;
    }

    /**
     * Sets the value of the serviceID property.
     * 
     */
    public void setServiceID(long value) {
        this.serviceID = value;
    }

    /**
     * Gets the value of the batchUIC property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBatchUIC() {
        return batchUIC;
    }

    /**
     * Sets the value of the batchUIC property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBatchUIC(String value) {
        this.batchUIC = value;
    }

    /**
     * Gets the value of the batchName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBatchName() {
        return batchName;
    }

    /**
     * Sets the value of the batchName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBatchName(String value) {
        this.batchName = value;
    }

    /**
     * Gets the value of the serviceNumber property.
     * 
     */
    public long getServiceNumber() {
        return serviceNumber;
    }

    /**
     * Sets the value of the serviceNumber property.
     * 
     */
    public void setServiceNumber(long value) {
        this.serviceNumber = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the serviceProvisionLevel property.
     * 
     * @return
     *     possible object is
     *     {@link ServiceProvisionLevelsEnum }
     *     
     */
    public ServiceProvisionLevelsEnum getServiceProvisionLevel() {
        return serviceProvisionLevel;
    }

    /**
     * Sets the value of the serviceProvisionLevel property.
     * 
     * @param value
     *     allowed object is
     *     {@link ServiceProvisionLevelsEnum }
     *     
     */
    public void setServiceProvisionLevel(ServiceProvisionLevelsEnum value) {
        this.serviceProvisionLevel = value;
    }

    /**
     * Gets the value of the provisionEAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProvisionEAddress() {
        return provisionEAddress;
    }

    /**
     * Sets the value of the provisionEAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProvisionEAddress(String value) {
        this.provisionEAddress = value;
    }

    /**
     * Gets the value of the suggestionsEAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSuggestionsEAddress() {
        return suggestionsEAddress;
    }

    /**
     * Sets the value of the suggestionsEAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSuggestionsEAddress(String value) {
        this.suggestionsEAddress = value;
    }

    /**
     * Gets the value of the hasCivilPurpose property.
     * 
     */
    public boolean isHasCivilPurpose() {
        return hasCivilPurpose;
    }

    /**
     * Sets the value of the hasCivilPurpose property.
     * 
     */
    public void setHasCivilPurpose(boolean value) {
        this.hasCivilPurpose = value;
    }

    /**
     * Gets the value of the hasBusinessPurpose property.
     * 
     */
    public boolean isHasBusinessPurpose() {
        return hasBusinessPurpose;
    }

    /**
     * Sets the value of the hasBusinessPurpose property.
     * 
     */
    public void setHasBusinessPurpose(boolean value) {
        this.hasBusinessPurpose = value;
    }

    /**
     * Gets the value of the publicBatchPreviewUrl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPublicBatchPreviewUrl() {
        return publicBatchPreviewUrl;
    }

    /**
     * Sets the value of the publicBatchPreviewUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPublicBatchPreviewUrl(String value) {
        this.publicBatchPreviewUrl = value;
    }

    /**
     * Gets the value of the refNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefNumber() {
        return refNumber;
    }

    /**
     * Sets the value of the refNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefNumber(String value) {
        this.refNumber = value;
    }

    /**
     * Gets the value of the publicAdmServiceInfoPreviewUrl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPublicAdmServiceInfoPreviewUrl() {
        return publicAdmServiceInfoPreviewUrl;
    }

    /**
     * Sets the value of the publicAdmServiceInfoPreviewUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPublicAdmServiceInfoPreviewUrl(String value) {
        this.publicAdmServiceInfoPreviewUrl = value;
    }

    /**
     * Gets the value of the publicRegisterName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPublicRegisterName() {
        return publicRegisterName;
    }

    /**
     * Sets the value of the publicRegisterName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPublicRegisterName(String value) {
        this.publicRegisterName = value;
    }

    /**
     * Gets the value of the publicRegisterWebAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPublicRegisterWebAddress() {
        return publicRegisterWebAddress;
    }

    /**
     * Sets the value of the publicRegisterWebAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPublicRegisterWebAddress(String value) {
        this.publicRegisterWebAddress = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;any/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "content"
    })
    public static class Limitations {

        @XmlMixed
        @XmlAnyElement(lax = true)
        protected List<Object> content;

        /**
         * Gets the value of the content property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the content property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getContent().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Object }
         * {@link String }
         * 
         * 
         */
        public List<Object> getContent() {
            if (content == null) {
                content = new ArrayList<Object>();
            }
            return this.content;
        }

    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;any/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "content"
    })
    public static class OrderAndAppealTerms {

        @XmlMixed
        @XmlAnyElement(lax = true)
        protected List<Object> content;

        /**
         * Gets the value of the content property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the content property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getContent().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Object }
         * {@link String }
         * 
         * 
         */
        public List<Object> getContent() {
            if (content == null) {
                content = new ArrayList<Object>();
            }
            return this.content;
        }

    }

}
