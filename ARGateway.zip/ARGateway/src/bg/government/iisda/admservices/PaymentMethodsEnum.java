
package bg.government.iisda.admservices;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PaymentMethodsEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="PaymentMethodsEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="DeskCash"/&gt;
 *     &lt;enumeration value="DeskCart"/&gt;
 *     &lt;enumeration value="Bank"/&gt;
 *     &lt;enumeration value="Electronic"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "PaymentMethodsEnum")
@XmlEnum
public enum PaymentMethodsEnum {

    @XmlEnumValue("DeskCash")
    DESK_CASH("DeskCash"),
    @XmlEnumValue("DeskCart")
    DESK_CART("DeskCart"),
    @XmlEnumValue("Bank")
    BANK("Bank"),
    @XmlEnumValue("Electronic")
    ELECTRONIC("Electronic");
    private final String value;

    PaymentMethodsEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static PaymentMethodsEnum fromValue(String v) {
        for (PaymentMethodsEnum c: PaymentMethodsEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
