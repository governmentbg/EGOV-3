
package bg.government.iisda.admservices;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAnyElement;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlMixed;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for PaymentInfoType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="PaymentInfoType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="PaymentMethods" type="{http://iisda.government.bg/AdmServices/}PaymentMethodsEnum" maxOccurs="unbounded" minOccurs="0"/&gt;
 *         &lt;element name="Explanations" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;any/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="PaymentKind" use="required" type="{http://iisda.government.bg/AdmServices/}PaymentKindsEnum" /&gt;
 *       &lt;attribute name="PaymentGenerationKind" use="required" type="{http://iisda.government.bg/AdmServices/}PaymentGenerationKindsEnum" /&gt;
 *       &lt;attribute name="NormalCost" type="{http://www.w3.org/2001/XMLSchema}decimal" /&gt;
 *       &lt;attribute name="FastCost" type="{http://www.w3.org/2001/XMLSchema}decimal" /&gt;
 *       &lt;attribute name="ExpressCost" type="{http://www.w3.org/2001/XMLSchema}decimal" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "PaymentInfoType", propOrder = {
    "paymentMethods",
    "explanations"
})
public class PaymentInfoType {

    @XmlElement(name = "PaymentMethods")
    @XmlSchemaType(name = "string")
    protected List<PaymentMethodsEnum> paymentMethods;
    @XmlElement(name = "Explanations")
    protected PaymentInfoType.Explanations explanations;
    @XmlAttribute(name = "PaymentKind", required = true)
    protected PaymentKindsEnum paymentKind;
    @XmlAttribute(name = "PaymentGenerationKind", required = true)
    protected PaymentGenerationKindsEnum paymentGenerationKind;
    @XmlAttribute(name = "NormalCost")
    protected BigDecimal normalCost;
    @XmlAttribute(name = "FastCost")
    protected BigDecimal fastCost;
    @XmlAttribute(name = "ExpressCost")
    protected BigDecimal expressCost;

    /**
     * Gets the value of the paymentMethods property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the paymentMethods property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPaymentMethods().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link PaymentMethodsEnum }
     * 
     * 
     */
    public List<PaymentMethodsEnum> getPaymentMethods() {
        if (paymentMethods == null) {
            paymentMethods = new ArrayList<PaymentMethodsEnum>();
        }
        return this.paymentMethods;
    }

    /**
     * Gets the value of the explanations property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentInfoType.Explanations }
     *     
     */
    public PaymentInfoType.Explanations getExplanations() {
        return explanations;
    }

    /**
     * Sets the value of the explanations property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentInfoType.Explanations }
     *     
     */
    public void setExplanations(PaymentInfoType.Explanations value) {
        this.explanations = value;
    }

    /**
     * Gets the value of the paymentKind property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentKindsEnum }
     *     
     */
    public PaymentKindsEnum getPaymentKind() {
        return paymentKind;
    }

    /**
     * Sets the value of the paymentKind property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentKindsEnum }
     *     
     */
    public void setPaymentKind(PaymentKindsEnum value) {
        this.paymentKind = value;
    }

    /**
     * Gets the value of the paymentGenerationKind property.
     * 
     * @return
     *     possible object is
     *     {@link PaymentGenerationKindsEnum }
     *     
     */
    public PaymentGenerationKindsEnum getPaymentGenerationKind() {
        return paymentGenerationKind;
    }

    /**
     * Sets the value of the paymentGenerationKind property.
     * 
     * @param value
     *     allowed object is
     *     {@link PaymentGenerationKindsEnum }
     *     
     */
    public void setPaymentGenerationKind(PaymentGenerationKindsEnum value) {
        this.paymentGenerationKind = value;
    }

    /**
     * Gets the value of the normalCost property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getNormalCost() {
        return normalCost;
    }

    /**
     * Sets the value of the normalCost property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setNormalCost(BigDecimal value) {
        this.normalCost = value;
    }

    /**
     * Gets the value of the fastCost property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFastCost() {
        return fastCost;
    }

    /**
     * Sets the value of the fastCost property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFastCost(BigDecimal value) {
        this.fastCost = value;
    }

    /**
     * Gets the value of the expressCost property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getExpressCost() {
        return expressCost;
    }

    /**
     * Sets the value of the expressCost property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setExpressCost(BigDecimal value) {
        this.expressCost = value;
    }


    /**
     * <p>Java class for anonymous complex type.
     * 
     * <p>The following schema fragment specifies the expected content contained within this class.
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;any/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "content"
    })
    public static class Explanations {

        @XmlMixed
        @XmlAnyElement(lax = true)
        protected List<Object> content;

        /**
         * Gets the value of the content property.
         * 
         * <p>
         * This accessor method returns a reference to the live list,
         * not a snapshot. Therefore any modification you make to the
         * returned list will be present inside the JAXB object.
         * This is why there is not a <CODE>set</CODE> method for the content property.
         * 
         * <p>
         * For example, to add a new item, do as follows:
         * <pre>
         *    getContent().add(newItem);
         * </pre>
         * 
         * 
         * <p>
         * Objects of the following type(s) are allowed in the list
         * {@link Object }
         * {@link String }
         * 
         * 
         */
        public List<Object> getContent() {
            if (content == null) {
                content = new ArrayList<Object>();
            }
            return this.content;
        }

    }

}
