
package bg.government.iisda.admservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AdmServiceBatchDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AdmServiceBatchDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="AdmServiceData" type="{http://iisda.government.bg/AdmServices/}AdmServiceDataType" minOccurs="0"/&gt;
 *         &lt;element name="AdmServiceBatchInfo" type="{http://iisda.government.bg/AdmServices/}AdmServiceInfoType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AdmServiceBatchDataType", propOrder = {
    "admServiceData",
    "admServiceBatchInfo"
})
public class AdmServiceBatchDataType {

    @XmlElement(name = "AdmServiceData")
    protected AdmServiceDataType admServiceData;
    @XmlElement(name = "AdmServiceBatchInfo")
    protected AdmServiceInfoType admServiceBatchInfo;

    /**
     * Gets the value of the admServiceData property.
     * 
     * @return
     *     possible object is
     *     {@link AdmServiceDataType }
     *     
     */
    public AdmServiceDataType getAdmServiceData() {
        return admServiceData;
    }

    /**
     * Sets the value of the admServiceData property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdmServiceDataType }
     *     
     */
    public void setAdmServiceData(AdmServiceDataType value) {
        this.admServiceData = value;
    }

    /**
     * Gets the value of the admServiceBatchInfo property.
     * 
     * @return
     *     possible object is
     *     {@link AdmServiceInfoType }
     *     
     */
    public AdmServiceInfoType getAdmServiceBatchInfo() {
        return admServiceBatchInfo;
    }

    /**
     * Sets the value of the admServiceBatchInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdmServiceInfoType }
     *     
     */
    public void setAdmServiceBatchInfo(AdmServiceInfoType value) {
        this.admServiceBatchInfo = value;
    }

}
