
package bg.government.iisda.admservices;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for RegulatoryActLegalBasisType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="RegulatoryActLegalBasisType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="StructuredData" type="{http://iisda.government.bg/AdmServices/}RegulatoryActStructuredDataType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="RegulatoryActName" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RegulatoryActLegalBasisType", propOrder = {
    "structuredData"
})
public class RegulatoryActLegalBasisType {

    @XmlElement(name = "StructuredData")
    protected List<RegulatoryActStructuredDataType> structuredData;
    @XmlAttribute(name = "RegulatoryActName")
    protected String regulatoryActName;

    /**
     * Gets the value of the structuredData property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the structuredData property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getStructuredData().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RegulatoryActStructuredDataType }
     * 
     * 
     */
    public List<RegulatoryActStructuredDataType> getStructuredData() {
        if (structuredData == null) {
            structuredData = new ArrayList<RegulatoryActStructuredDataType>();
        }
        return this.structuredData;
    }

    /**
     * Gets the value of the regulatoryActName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegulatoryActName() {
        return regulatoryActName;
    }

    /**
     * Sets the value of the regulatoryActName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegulatoryActName(String value) {
        this.regulatoryActName = value;
    }

}
