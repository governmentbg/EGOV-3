@javax.xml.bind.annotation.XmlSchema(namespace = "http://iisda.government.bg/AdmServices/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package bg.government.iisda.admservices;
