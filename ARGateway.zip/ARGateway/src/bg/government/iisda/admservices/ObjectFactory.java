
package bg.government.iisda.admservices;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the bg.government.iisda.admservices package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: bg.government.iisda.admservices
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link AdmServiceStageType }
     * 
     */
    public AdmServiceStageType createAdmServiceStageType() {
        return new AdmServiceStageType();
    }

    /**
     * Create an instance of {@link PaymentInfoType }
     * 
     */
    public PaymentInfoType createPaymentInfoType() {
        return new PaymentInfoType();
    }

    /**
     * Create an instance of {@link AdmServiceInfoType }
     * 
     */
    public AdmServiceInfoType createAdmServiceInfoType() {
        return new AdmServiceInfoType();
    }

    /**
     * Create an instance of {@link AdmServiceBatchesType }
     * 
     */
    public AdmServiceBatchesType createAdmServiceBatchesType() {
        return new AdmServiceBatchesType();
    }

    /**
     * Create an instance of {@link AdmServiceBatchDataType }
     * 
     */
    public AdmServiceBatchDataType createAdmServiceBatchDataType() {
        return new AdmServiceBatchDataType();
    }

    /**
     * Create an instance of {@link AdmServiceDataType }
     * 
     */
    public AdmServiceDataType createAdmServiceDataType() {
        return new AdmServiceDataType();
    }

    /**
     * Create an instance of {@link RegulatoryActLegalBasisType }
     * 
     */
    public RegulatoryActLegalBasisType createRegulatoryActLegalBasisType() {
        return new RegulatoryActLegalBasisType();
    }

    /**
     * Create an instance of {@link RegulatoryActStructuredDataType }
     * 
     */
    public RegulatoryActStructuredDataType createRegulatoryActStructuredDataType() {
        return new RegulatoryActStructuredDataType();
    }

    /**
     * Create an instance of {@link ArrayOfServiceApplicationMethodsEnum }
     * 
     */
    public ArrayOfServiceApplicationMethodsEnum createArrayOfServiceApplicationMethodsEnum() {
        return new ArrayOfServiceApplicationMethodsEnum();
    }

    /**
     * Create an instance of {@link UnitContactType }
     * 
     */
    public UnitContactType createUnitContactType() {
        return new UnitContactType();
    }

    /**
     * Create an instance of {@link ArrayOfAdmServiceStageType }
     * 
     */
    public ArrayOfAdmServiceStageType createArrayOfAdmServiceStageType() {
        return new ArrayOfAdmServiceStageType();
    }

    /**
     * Create an instance of {@link AdmServiceInfoDocumentType }
     * 
     */
    public AdmServiceInfoDocumentType createAdmServiceInfoDocumentType() {
        return new AdmServiceInfoDocumentType();
    }

    /**
     * Create an instance of {@link ArrayOfAdmServiceInfoDocumentType }
     * 
     */
    public ArrayOfAdmServiceInfoDocumentType createArrayOfAdmServiceInfoDocumentType() {
        return new ArrayOfAdmServiceInfoDocumentType();
    }

    /**
     * Create an instance of {@link ArrayOfBatchIAAPositionType }
     * 
     */
    public ArrayOfBatchIAAPositionType createArrayOfBatchIAAPositionType() {
        return new ArrayOfBatchIAAPositionType();
    }

    /**
     * Create an instance of {@link BatchIAAPositionType }
     * 
     */
    public BatchIAAPositionType createBatchIAAPositionType() {
        return new BatchIAAPositionType();
    }

    /**
     * Create an instance of {@link AdmServiceMainDataType }
     * 
     */
    public AdmServiceMainDataType createAdmServiceMainDataType() {
        return new AdmServiceMainDataType();
    }

    /**
     * Create an instance of {@link AdmServiceStageType.Description }
     * 
     */
    public AdmServiceStageType.Description createAdmServiceStageTypeDescription() {
        return new AdmServiceStageType.Description();
    }

    /**
     * Create an instance of {@link PaymentInfoType.Explanations }
     * 
     */
    public PaymentInfoType.Explanations createPaymentInfoTypeExplanations() {
        return new PaymentInfoType.Explanations();
    }

    /**
     * Create an instance of {@link AdmServiceInfoType.OrderAndAppealTerms }
     * 
     */
    public AdmServiceInfoType.OrderAndAppealTerms createAdmServiceInfoTypeOrderAndAppealTerms() {
        return new AdmServiceInfoType.OrderAndAppealTerms();
    }

    /**
     * Create an instance of {@link AdmServiceInfoType.Limitations }
     * 
     */
    public AdmServiceInfoType.Limitations createAdmServiceInfoTypeLimitations() {
        return new AdmServiceInfoType.Limitations();
    }

}
