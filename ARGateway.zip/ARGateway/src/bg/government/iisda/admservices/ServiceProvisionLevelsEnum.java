
package bg.government.iisda.admservices;

import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlEnumValue;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ServiceProvisionLevelsEnum.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="ServiceProvisionLevelsEnum"&gt;
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string"&gt;
 *     &lt;enumeration value="SiteInfoOnly"/&gt;
 *     &lt;enumeration value="SiteInfoAndDocModel"/&gt;
 *     &lt;enumeration value="ApplicationEnabled"/&gt;
 *     &lt;enumeration value="RequestAndPayService"/&gt;
 *   &lt;/restriction&gt;
 * &lt;/simpleType&gt;
 * </pre>
 * 
 */
@XmlType(name = "ServiceProvisionLevelsEnum")
@XmlEnum
public enum ServiceProvisionLevelsEnum {

    @XmlEnumValue("SiteInfoOnly")
    SITE_INFO_ONLY("SiteInfoOnly"),
    @XmlEnumValue("SiteInfoAndDocModel")
    SITE_INFO_AND_DOC_MODEL("SiteInfoAndDocModel"),
    @XmlEnumValue("ApplicationEnabled")
    APPLICATION_ENABLED("ApplicationEnabled"),
    @XmlEnumValue("RequestAndPayService")
    REQUEST_AND_PAY_SERVICE("RequestAndPayService");
    private final String value;

    ServiceProvisionLevelsEnum(String v) {
        value = v;
    }

    public String value() {
        return value;
    }

    public static ServiceProvisionLevelsEnum fromValue(String v) {
        for (ServiceProvisionLevelsEnum c: ServiceProvisionLevelsEnum.values()) {
            if (c.value.equals(v)) {
                return c;
            }
        }
        throw new IllegalArgumentException(v);
    }

}
