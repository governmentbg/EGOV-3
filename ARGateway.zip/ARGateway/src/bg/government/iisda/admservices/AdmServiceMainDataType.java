
package bg.government.iisda.admservices;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AdmServiceMainDataType complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AdmServiceMainDataType"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="LegalBasis" type="{http://iisda.government.bg/AdmServices/}RegulatoryActLegalBasisType" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="ServiceNumber" use="required" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="SectionName" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="BatchID" type="{http://www.w3.org/2001/XMLSchema}long" /&gt;
 *       &lt;attribute name="Name" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="Description" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="IsFromEU" use="required" type="{http://www.w3.org/2001/XMLSchema}boolean" /&gt;
 *       &lt;attribute name="IsInternalAdminService" use="required" type="{http://www.w3.org/2001/XMLSchema}boolean" /&gt;
 *       &lt;attribute name="IsRegime" use="required" type="{http://www.w3.org/2001/XMLSchema}boolean" /&gt;
 *       &lt;attribute name="RegimeName" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="BusinessActivityName" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AdmServiceMainDataType", propOrder = {
    "legalBasis"
})
public class AdmServiceMainDataType {

    @XmlElement(name = "LegalBasis")
    protected List<RegulatoryActLegalBasisType> legalBasis;
    @XmlAttribute(name = "ServiceNumber", required = true)
    protected long serviceNumber;
    @XmlAttribute(name = "SectionName")
    protected String sectionName;
    @XmlAttribute(name = "BatchID")
    protected Long batchID;
    @XmlAttribute(name = "Name")
    protected String name;
    @XmlAttribute(name = "Description")
    protected String description;
    @XmlAttribute(name = "IsFromEU", required = true)
    protected boolean isFromEU;
    @XmlAttribute(name = "IsInternalAdminService", required = true)
    protected boolean isInternalAdminService;
    @XmlAttribute(name = "IsRegime", required = true)
    protected boolean isRegime;
    @XmlAttribute(name = "RegimeName")
    protected String regimeName;
    @XmlAttribute(name = "BusinessActivityName")
    protected String businessActivityName;

    /**
     * Gets the value of the legalBasis property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the legalBasis property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getLegalBasis().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link RegulatoryActLegalBasisType }
     * 
     * 
     */
    public List<RegulatoryActLegalBasisType> getLegalBasis() {
        if (legalBasis == null) {
            legalBasis = new ArrayList<RegulatoryActLegalBasisType>();
        }
        return this.legalBasis;
    }

    /**
     * Gets the value of the serviceNumber property.
     * 
     */
    public long getServiceNumber() {
        return serviceNumber;
    }

    /**
     * Sets the value of the serviceNumber property.
     * 
     */
    public void setServiceNumber(long value) {
        this.serviceNumber = value;
    }

    /**
     * Gets the value of the sectionName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSectionName() {
        return sectionName;
    }

    /**
     * Sets the value of the sectionName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSectionName(String value) {
        this.sectionName = value;
    }

    /**
     * Gets the value of the batchID property.
     * 
     * @return
     *     possible object is
     *     {@link Long }
     *     
     */
    public Long getBatchID() {
        return batchID;
    }

    /**
     * Sets the value of the batchID property.
     * 
     * @param value
     *     allowed object is
     *     {@link Long }
     *     
     */
    public void setBatchID(Long value) {
        this.batchID = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the isFromEU property.
     * 
     */
    public boolean isIsFromEU() {
        return isFromEU;
    }

    /**
     * Sets the value of the isFromEU property.
     * 
     */
    public void setIsFromEU(boolean value) {
        this.isFromEU = value;
    }

    /**
     * Gets the value of the isInternalAdminService property.
     * 
     */
    public boolean isIsInternalAdminService() {
        return isInternalAdminService;
    }

    /**
     * Sets the value of the isInternalAdminService property.
     * 
     */
    public void setIsInternalAdminService(boolean value) {
        this.isInternalAdminService = value;
    }

    /**
     * Gets the value of the isRegime property.
     * 
     */
    public boolean isIsRegime() {
        return isRegime;
    }

    /**
     * Sets the value of the isRegime property.
     * 
     */
    public void setIsRegime(boolean value) {
        this.isRegime = value;
    }

    /**
     * Gets the value of the regimeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRegimeName() {
        return regimeName;
    }

    /**
     * Sets the value of the regimeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRegimeName(String value) {
        this.regimeName = value;
    }

    /**
     * Gets the value of the businessActivityName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBusinessActivityName() {
        return businessActivityName;
    }

    /**
     * Sets the value of the businessActivityName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBusinessActivityName(String value) {
        this.businessActivityName = value;
    }

}
