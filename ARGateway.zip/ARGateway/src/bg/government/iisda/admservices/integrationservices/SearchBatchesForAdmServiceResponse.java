
package bg.government.iisda.admservices.integrationservices;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import bg.government.iisda.admservices.AdmServiceBatchesType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="SearchBatchesForAdmServiceResult" type="{http://iisda.government.bg/AdmServices/}AdmServiceBatchesType" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "searchBatchesForAdmServiceResult"
})
@XmlRootElement(name = "SearchBatchesForAdmServiceResponse")
public class SearchBatchesForAdmServiceResponse {

    @XmlElement(name = "SearchBatchesForAdmServiceResult")
    protected AdmServiceBatchesType searchBatchesForAdmServiceResult;

    /**
     * Gets the value of the searchBatchesForAdmServiceResult property.
     * 
     * @return
     *     possible object is
     *     {@link AdmServiceBatchesType }
     *     
     */
    public AdmServiceBatchesType getSearchBatchesForAdmServiceResult() {
        return searchBatchesForAdmServiceResult;
    }

    /**
     * Sets the value of the searchBatchesForAdmServiceResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link AdmServiceBatchesType }
     *     
     */
    public void setSearchBatchesForAdmServiceResult(AdmServiceBatchesType value) {
        this.searchBatchesForAdmServiceResult = value;
    }

}
