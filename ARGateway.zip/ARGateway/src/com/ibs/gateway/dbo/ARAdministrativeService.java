package com.ibs.gateway.dbo;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Hashtable;

import com.ibm.workplace.wcm.api.Content;
import com.ibs.gateway.ARConstants;
import com.ibs.gateway.db.DBTransaction;
import com.ibs.gateway.db.FinderException;
import com.ibs.gateway.db.PersistentObject;
import com.ibs.gateway.db.QueryComposer;
import com.ibs.gateway.db.QuerySet;
import com.ibs.gateway.utils.ARUtils;

public class ARAdministrativeService extends PersistentObject {

	private static String CLASS_NAME = ARAdministrativeService.class.getName();
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "ARADMINISTRATIVESERVICE";
        sequenceName = "SEQ_ARADMINISTRATIVESERVICEID";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "ARADMINISTRATIVESERVICEID");
        columnMap.put("serviceNumber", "SERVICENUMBER");
        columnMap.put("name", "NAME");
        columnMap.put("description", "DESCRIPTION");
        columnMap.put("sectionName", "SECTIONNAME");
        columnMap.put("supplierBatchId", "SUPPLIERBATCHID");        
        columnMap.put("supplierName", "SUPPLIERNAME");
        columnMap.put("lastUpdateDate", "LASTUPDATEDATE");
        columnMap.put("state", "STATE");       
        columnMap.put("synchronized", "SYNCHRONIZED");
        columnMap.put("blocked", "BLOCKED");
        columnMap.put("hash", "HASH");
        columnMap.put("contentUUID", "CONTENTUUID");
        columnMap.put("userDN", "USERDN");
        columnMap.put("creationDate", "CREATIONDATE");
        columnMap.put("synchronizedDate", "SYNCHRONIZEDDATE");
        columnMap.put("operationTime", "OPERATIONTIME");
        columnMap.put("changeRegisterDate", "CHANGEREGISTERDATE");
        querySet = QueryComposer.composeAll(table, sequenceName, columnMap);
    }
	
    public ARAdministrativeService() {
        super(querySet);
    }
    
    private BigDecimal serviceNumber;
    private String name = null;
    private String description = null;
    private String sectionName = null;
    private BigDecimal supplierBatchId;    
    private String supplierName = null;
	// This time is taken from AR service, (TBD).
	private String lastUpdateDate;
	private String state = null;
	private String synched = null;
	private String blocked = null;
	private String hash = null;
	private String contentUUID = null;
	private String userDN;	
	private String creationDate = null;
	private String synchronizedDate = null;
	private String operationTime = null;
	private String changeRegisterDate = null;
	// Only for business purpose.
	private Content content = null;
		
	public BigDecimal getServiceNumber() {
		return serviceNumber;
	}
	
	public void setServiceNumber(BigDecimal serviceNumber) {
		this.serviceNumber = serviceNumber;
	}
	
	public void setServiceNumber(String serviceNumber) {
		this.serviceNumber = new BigDecimal(serviceNumber);
	}	
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSectionName() {
		return sectionName;
	}
	
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}
	
	public BigDecimal getSupplierBatchId() {
		return supplierBatchId;
	}

	public void setSupplierBatchId(BigDecimal supplierBatchId) {
		this.supplierBatchId = supplierBatchId;
	}
	
	public void setSupplierBatchId(String supplierBatchId) {
		this.supplierBatchId = (supplierBatchId != null) ? new BigDecimal(supplierBatchId) : null;
	}	

	public String getSupplierName() {
		return supplierName;
	}
	
	public void setSupplierName(String supplierName) {
		this.supplierName = supplierName;
	}

	public Timestamp getLastUpdateDate() {
		return (lastUpdateDate != null) ? new Timestamp(Long.parseLong(lastUpdateDate)) : null;
	}
	
	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = (lastUpdateDate != null) ? String.valueOf(ARUtils.date_TimestampToTimeMillis(lastUpdateDate)) : null;
	}	
	
	public String getState() {
		return state;
	}
	
	public void setState(String state) {
		this.state = state;
	}
	
	public String getSynchronized() {
		return synched;
	}

	public void setSynchronized(String synched) {
		this.synched = synched;
	}

	public String getBlocked() {
		return blocked;
	}

	public void setBlocked(String blocked) {
		this.blocked = blocked;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public String getContentUUID() {
		return contentUUID;
	}

	public void setContentUUID(String contentUUID) {
		this.contentUUID = contentUUID;
	}

	public String getUserDN() {
		return userDN;
	}
	
	public void setUserDN(String userDN) {
		this.userDN = userDN;
	}
	
	public Timestamp getCreationDate() {
		return (creationDate != null) ? new Timestamp(Long.parseLong(creationDate)) : null;
	}
	
	public void setCreationDate(String creationDate) {
		this.creationDate = (creationDate != null) ? String.valueOf(ARUtils.date_TimestampToTimeMillis(creationDate)) : null;
	}	
	
	public Timestamp getSynchronizedDate() {
		return (synchronizedDate != null) ? new Timestamp(Long.parseLong(synchronizedDate)) : null;
	}
	
	public void setSynchronizedDate(String synchronizedDate) {
		this.synchronizedDate = (synchronizedDate != null) ? String.valueOf(ARUtils.date_TimestampToTimeMillis(synchronizedDate)) : null;
	}	
	
	public Timestamp getOperationTime() {
		return (operationTime != null) ? new Timestamp(Long.parseLong(operationTime)) : null;
	}
	
	public void setOperationTime(String operationTime) {
		this.operationTime = (operationTime != null) ? String.valueOf(ARUtils.date_TimestampToTimeMillis(operationTime)) : null;
	}	
	
	public Timestamp getChangeRegisterDate() {
		return (changeRegisterDate != null) ? new Timestamp(Long.parseLong(changeRegisterDate)) : null;
	}

	public void setChangeRegisterDate(String changeRegisterDate) {
		this.changeRegisterDate = (changeRegisterDate != null) ? String.valueOf(ARUtils.date_TimestampToTimeMillis(changeRegisterDate)) : null;
	}

	public Content getContent() {
		return content;
	}

	public void setContent(Content content) {
		this.content = content;
	}

	public static ARAdministrativeService findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (ARAdministrativeService) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}
	
	public static ARAdministrativeService findByServiceNumber(final String serviceNumber, final DBTransaction transaction) throws FinderException, Exception {
		return (ARAdministrativeService) findSingle(columnMap.get("serviceNumber") + "='" + serviceNumber + "'", CLASS_NAME, transaction);
	}
	
	public static ARAdministrativeService findByBatchId(final String batchId, final DBTransaction transaction) throws FinderException, Exception {
		return (ARAdministrativeService) findSingle(columnMap.get("batchId") + "='" + batchId + "'", CLASS_NAME, transaction);
	}
	
	public static ARAdministrativeService findByUIC(final String uic, final DBTransaction transaction) throws FinderException, Exception {
		return (ARAdministrativeService) findSingle(columnMap.get("uic") + "='" + uic + "'", CLASS_NAME, transaction);
	}

	public static ARAdministrativeService findByContentUUID(final String uuid, final DBTransaction transaction) throws FinderException, Exception {
        return (ARAdministrativeService) findSingle(columnMap.get("contentUUID") + "='" + uuid + "'", CLASS_NAME, transaction);
    }
	

	public static ARAdministrativeService[] findAllForUpdate(final String serviceNumber, final String name, final String sectionName, final String supplierBatchId, final String state, final Integer start, final Integer length, final Integer orderColumn, final String order, final DBTransaction transaction) throws FinderException, Exception {
		String query = columnMap.get("blocked") + " IS NULL";
		if (serviceNumber != null) {
			query += " AND " + columnMap.get("serviceNumber") + "=" + serviceNumber;
		}
		if (name != null) {
			query += " AND UPPER(" + columnMap.get("name") + ") LIKE '%" + name.toUpperCase() + "%'";
		}
		if (sectionName != null) {
			query += " AND UPPER(" + columnMap.get("sectionName") + ") = '" + sectionName.toUpperCase() + "'";
		}
		if (supplierBatchId != null) {
			query += " AND " + columnMap.get("supplierBatchId") + "=" + supplierBatchId;
		}
		if (state != null) {
			query += " AND " + columnMap.get("state") + "='" + state + "'";
		} else {
			// Exclude results with state 'Processed'.
			query += " AND " + columnMap.get("state") + " NOT IN ('" + ARConstants.ADMINISTRATIVE_SERVICE_STATE_PROCESSED + "')";
		}
		
		query += " ORDER BY ";

		if (orderColumn == null) {
			query += columnMap.get("name");
		} else {
			if (orderColumn == ARConstants.COLUMN_ID) {
				query += columnMap.get("serviceNumber");
			} else if (orderColumn == ARConstants.COLUMN_SERVICES_FOR_UPDATE_NAME) {
				query += columnMap.get("name");
			} else if (orderColumn == ARConstants.COLUMN_SERVICES_FOR_UPDATE_SECTION_NAME) {
				query += columnMap.get("sectionName");
			} else if (orderColumn == ARConstants.COLUMN_SERVICES_FOR_UPDATE_SUPPLIER_BATCH_ID) {
				query += columnMap.get("supplierBatchId");
			} else if (orderColumn == ARConstants.COLUMN_SERVICES_FOR_UPDATE_SUPPLIER_NAME) {
				query += columnMap.get("supplierName");
			} else if (orderColumn == ARConstants.COLUMN_SERVICES_FOR_UPDATE_STATE) {
				query += columnMap.get("state");
			} else if (orderColumn == ARConstants.COLUMN_SERVICES_FOR_UPDATE_DATE) {
				query += columnMap.get("synchronizedDate");
			} else {
				query += columnMap.get("name");			
			}
		}
		query += " " + (order != null && ARConstants.ORDER_DESC.equalsIgnoreCase(order) ? order.toUpperCase() : ARConstants.ORDER_ASC);
		
		// NOT SUPPORTED BY DB2, so we are doing workaround.
		//query += " LIMIT " + start + ", " + length;			
		if (start != null && length != null) {
			query += " FETCH FIRST " + (start + length) + " ROWS ONLY";
		}
		
		return findAllAdministrativeServices(query, transaction);
	}
	
	public static ARAdministrativeService[] findAllByFitler(final String serviceNumber, final String name, final String sectionName, final String supplierBatchId, final String state, final String synched, final Integer start, final Integer length, final Integer orderColumn, final String order, final DBTransaction transaction) throws FinderException, Exception {
		String query = "1=1";
		if (serviceNumber != null) {
			query += " AND " + columnMap.get("serviceNumber") + "=" + serviceNumber;
		}
		if (name != null) {
			query += " AND UPPER(" + columnMap.get("name") + ") LIKE '%" + name.toUpperCase() + "%'";
		}
		if (sectionName != null) {
			query += " AND UPPER(" + columnMap.get("sectionName") + ") = '" + sectionName.toUpperCase() + "'";
		}
		if (supplierBatchId != null) {
			query += " AND " + columnMap.get("supplierBatchId") + "=" + supplierBatchId;
		}
		if (state != null) {
			query += " AND " + columnMap.get("state") + "='" + state + "'";
		} else {
			query += " AND " + columnMap.get("state") + " IS NOT NULL";
		}
		if (synched != null) {
			if (ARConstants.ADMINISTRATIVE_SERVICE_SYNCHRONIZED.equals(synched)) {
				query += " AND " + columnMap.get("synchronized") + "='" + ARConstants.ADMINISTRATIVE_SERVICE_SYNCHRONIZED + "'";
			} else {
				query += " AND " + columnMap.get("synchronized") + "<>'" + ARConstants.ADMINISTRATIVE_SERVICE_SYNCHRONIZED + "'";
			}
		}
		
		query += " ORDER BY ";

		if (orderColumn == null) {
			query += columnMap.get("name");
		} else {
			if (orderColumn == ARConstants.COLUMN_ID) {
				query += columnMap.get("serviceNumber");
			} else if (orderColumn == ARConstants.COLUMN_SERVICES_ALL_NAME) {
				query += columnMap.get("name");
			} else if (orderColumn == ARConstants.COLUMN_SERVICES_ALL_SECTION_NAME) {
				query += columnMap.get("sectionName");
			} else if (orderColumn == ARConstants.COLUMN_SERVICES_ALL_SUPPLIER_BATCH_ID) {
				query += columnMap.get("supplierBatchId");
			} else if (orderColumn == ARConstants.COLUMN_SERVICES_ALL_SUPPLIER_NAME) {
				query += columnMap.get("supplierName");
			} else if (orderColumn == ARConstants.COLUMN_SERVICES_ALL_STATE) {
				query += columnMap.get("state");
			} else if (orderColumn == ARConstants.COLUMN_SERVICES_ALL_SYNCHRONIZED) {
				query += columnMap.get("synchronized");
			} else if (orderColumn == ARConstants.COLUMN_SERVICES_ALL_BLOCKED) {
				query += columnMap.get("blocked");
			} else if (orderColumn == ARConstants.COLUMN_SERVICES_ALL_DATE) {
				query += columnMap.get("synchronizedDate");
			} else {
				query += columnMap.get("name");			
			}
		}
		query += " " + (order != null && ARConstants.ORDER_DESC.equalsIgnoreCase(order) ? order.toUpperCase() : ARConstants.ORDER_ASC);
		
		// NOT SUPPORTED BY DB2, so we are doing workaround.
		//query += " LIMIT " + start + ", " + length;			
		if (start != null && length != null) {
			query += " FETCH FIRST " + (start + length) + " ROWS ONLY";
		}
		
		return findAllAdministrativeServices(query, transaction);
	}
	
	public static ARAdministrativeService[] findAllBlocked(final String serviceNumber, final String name, final String supplierBatchId, final Integer start, final Integer length, final Integer orderColumn, final String order, final DBTransaction transaction) throws FinderException, Exception {
		String query = columnMap.get("blocked") + "='" + ARConstants.ADMINISTRATIVE_SERVICE_BLOCKED + "'";
		if (serviceNumber != null) {
			query += " AND " + columnMap.get("serviceNumber") + "=" + serviceNumber;
		}
		if (name != null) {
			query += " AND UPPER(" + columnMap.get("name") + ") LIKE '%" + name.toUpperCase() + "%'";
		}
		if (supplierBatchId != null) {
			query += " AND " + columnMap.get("supplierBatchId") + "=" + supplierBatchId;
		}
		
		query += " ORDER BY ";

		if (orderColumn == null) {
			query += columnMap.get("name");
		} else {
			if (orderColumn == ARConstants.COLUMN_ID) {
				query += columnMap.get("serviceNumber");
			} else if (orderColumn == ARConstants.COLUMN_SERVICES_BLOCKED_NAME) {
				query += columnMap.get("name");
			} else if (orderColumn == ARConstants.COLUMN_SERVICES_BLOCKED_SECTION_NAME) {
				query += columnMap.get("sectionName");
			} else if (orderColumn == ARConstants.COLUMN_SERVICES_BLOCKED_SUPPLIER_BATCH_ID) {
				query += columnMap.get("supplierBatchId");
			} else if (orderColumn == ARConstants.COLUMN_SERVICES_BLOCKED_SUPPLIER_NAME) {
				query += columnMap.get("supplierName");
			} else if (orderColumn == ARConstants.COLUMN_SERVICES_BLOCKED_DATE) {
				query += columnMap.get("synchronizedDate");
			} else {
				query += columnMap.get("name");			
			}
		}
		query += " " + (order != null && ARConstants.ORDER_DESC.equalsIgnoreCase(order) ? order.toUpperCase() : ARConstants.ORDER_ASC);
		
		// NOT SUPPORTED BY DB2, so we are doing workaround.
		//query += " LIMIT " + start + ", " + length;			
		if (start != null && length != null) {
			query += " FETCH FIRST " + (start + length) + " ROWS ONLY";
		}
		
		return findAllAdministrativeServices(query, transaction);
	}
	
	public static ARAdministrativeService[] findAllBySectionName(final String sectionName, final DBTransaction transaction) throws FinderException, Exception {
		return findAllAdministrativeServices(columnMap.get("sectionName") + "='" + sectionName + "' ORDER BY " + columnMap.get("name") + " ASC", transaction);
	}
	
	public static ARAdministrativeService[] findAllByUserDN(final String userDN, final DBTransaction transaction) throws FinderException, Exception {
		return findAllAdministrativeServices(columnMap.get("userDN") + "='" + userDN + "' ORDER BY " + columnMap.get("name") + " ASC", transaction);
	}
	
	public static ARAdministrativeService[] findAllNotBlocked(final DBTransaction transaction) throws FinderException, Exception {
		return findAllAdministrativeServices(columnMap.get("blocked") + "<>'" + ARConstants.ADMINISTRATIVE_SERVICE_BLOCKED + "' ORDER BY " + columnMap.get("name") + " ASC", transaction);
	}
	
	public static ARAdministrativeService[] findAllSynchronized(final DBTransaction transaction) throws FinderException, Exception {
		return findAllAdministrativeServices(columnMap.get("synchronized") + "='" + ARConstants.ADMINISTRATIVE_SERVICE_SYNCHRONIZED + "' ORDER BY " + columnMap.get("name") + " ASC", transaction);
	}
	
	public static ARAdministrativeService[] findAllNotSynchronized(final DBTransaction transaction) throws FinderException, Exception {
        return findAllAdministrativeServices(columnMap.get("synchronized") + "<>'" + ARConstants.ADMINISTRATIVE_SERVICE_SYNCHRONIZED + "' ORDER BY " + columnMap.get("name") + " ASC", transaction);
    }
	
	public static ARAdministrativeService[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllAdministrativeServices("1=1", transaction);
	}

	public static ARAdministrativeService[] findAllAdministrativeServices(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final ARAdministrativeService[] administrativeServices = new ARAdministrativeService[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				administrativeServices[i] = (ARAdministrativeService) tmp[i];
			}
			return administrativeServices;
		} 
		return null;
	}
	
}
