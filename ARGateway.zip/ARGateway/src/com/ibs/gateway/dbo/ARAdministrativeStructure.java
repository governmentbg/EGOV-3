package com.ibs.gateway.dbo;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Hashtable;

import com.ibm.workplace.wcm.api.Content;
import com.ibs.gateway.ARConstants;
import com.ibs.gateway.db.DBTransaction;
import com.ibs.gateway.db.FinderException;
import com.ibs.gateway.db.PersistentObject;
import com.ibs.gateway.db.QueryComposer;
import com.ibs.gateway.db.QuerySet;
import com.ibs.gateway.utils.ARUtils;

public class ARAdministrativeStructure extends PersistentObject {

	private static String CLASS_NAME = ARAdministrativeStructure.class.getName();
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "ARADMINISTRATIVESTRUCTURE";
        sequenceName = "SEQ_ARADMINISTRATIVESTRUCTUREID";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "ARADMINISTRATIVESTRUCTUREID");
        columnMap.put("batchId", "BATCHID");
        columnMap.put("type", "TYPE");
        columnMap.put("identificationNumber", "IDENTIFICATIONNUMBER");
        columnMap.put("name", "NAME");        
        columnMap.put("admStructureKind", "ADMSTRUCTUREKIND");
        columnMap.put("uic", "UIC");
        columnMap.put("status", "STATUS");       
        columnMap.put("lastUpdateDate", "LASTUPDATEDATE");
        columnMap.put("state", "STATE");       
        columnMap.put("synchronized", "SYNCHRONIZED");
        columnMap.put("blocked", "BLOCKED");
        columnMap.put("hash", "HASH");
        columnMap.put("contentUUID", "CONTENTUUID");
        columnMap.put("userDN", "USERDN");
        columnMap.put("creationDate", "CREATIONDATE");
        columnMap.put("synchronizedDate", "SYNCHRONIZEDDATE");
        columnMap.put("operationTime", "OPERATIONTIME");
        columnMap.put("changeRegisterDate", "CHANGEREGISTERDATE");
        querySet = QueryComposer.composeAll(table, sequenceName, columnMap);
    }
	
    public ARAdministrativeStructure() {
        super(querySet);
    }
    
    private BigDecimal batchId;
    private String type = null;
	private String identificationNumber = null;
	private String name = null;
	private String admStructureKind = null;
	private String uic = null;	
	private String status;
	// This time is taken from AR service, (TBD).
	private String lastUpdateDate;
	private String state = null;
	private String synched = null;
	private String blocked = null;
	private String hash = null;
	private String contentUUID = null;
	private String userDN;	
	private String creationDate = null;
	private String synchronizedDate = null;
	private String operationTime = null;
	private String changeRegisterDate = null;
	// Only for business purpose.
	private Content content = null;
		
	public BigDecimal getBatchId() {
		return batchId;
	}

	public void setBatchId(BigDecimal batchId) {
		this.batchId = batchId;
	}
	
	public void setBatchId(String batchId) {
		this.batchId = new BigDecimal(batchId);
	}	

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getIdentificationNumber() {
		return identificationNumber;
	}

	public void setIdentificationNumber(String identificationNumber) {
		this.identificationNumber = identificationNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAdmStructureKind() {
		return admStructureKind;
	}

	public void setAdmStructureKind(String admStructureKind) {
		this.admStructureKind = admStructureKind;
	}

	public String getUic() {
		return uic;
	}

	public void setUic(String uic) {
		this.uic = uic;
	}

	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	public Timestamp getLastUpdateDate() {
		return (lastUpdateDate != null) ? new Timestamp(Long.parseLong(lastUpdateDate)) : null;
	}
	
	public void setLastUpdateDate(String lastUpdateDate) {
		this.lastUpdateDate = (lastUpdateDate != null) ? String.valueOf(ARUtils.date_TimestampToTimeMillis(lastUpdateDate)) : null;
	}	
	
	public String getState() {
		return state;
	}
	
	public void setState(String state) {
		this.state = state;
	}
	
	public String getSynchronized() {
		return synched;
	}

	public void setSynchronized(String synched) {
		this.synched = synched;
	}

	public String getBlocked() {
		return blocked;
	}

	public void setBlocked(String blocked) {
		this.blocked = blocked;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public String getContentUUID() {
		return contentUUID;
	}

	public void setContentUUID(String contentUUID) {
		this.contentUUID = contentUUID;
	}

	public String getUserDN() {
		return userDN;
	}
	
	public void setUserDN(String userDN) {
		this.userDN = userDN;
	}
	
	public Timestamp getCreationDate() {
		return (creationDate != null) ? new Timestamp(Long.parseLong(creationDate)) : null;
	}
	
	public void setCreationDate(String creationDate) {
		this.creationDate = (creationDate != null) ? String.valueOf(ARUtils.date_TimestampToTimeMillis(creationDate)) : null;
	}	
	
	public Timestamp getSynchronizedDate() {
		return (synchronizedDate != null) ? new Timestamp(Long.parseLong(synchronizedDate)) : null;
	}
	
	public void setSynchronizedDate(String synchronizedDate) {
		this.synchronizedDate = (synchronizedDate != null) ? String.valueOf(ARUtils.date_TimestampToTimeMillis(synchronizedDate)) : null;
	}	
	
	public Timestamp getOperationTime() {
		return (operationTime != null) ? new Timestamp(Long.parseLong(operationTime)) : null;
	}
	
	public void setOperationTime(String operationTime) {
		this.operationTime = (operationTime != null) ? String.valueOf(ARUtils.date_TimestampToTimeMillis(operationTime)) : null;
	}	
	
	public Timestamp getChangeRegisterDate() {
		return (changeRegisterDate != null) ? new Timestamp(Long.parseLong(changeRegisterDate)) : null;
	}

	public void setChangeRegisterDate(String changeRegisterDate) {
		this.changeRegisterDate = (changeRegisterDate != null) ? String.valueOf(ARUtils.date_TimestampToTimeMillis(changeRegisterDate)) : null;
	}

	public Content getContent() {
		return content;
	}

	public void setContent(Content content) {
		this.content = content;
	}

	public static ARAdministrativeStructure findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (ARAdministrativeStructure) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}
	
	public static ARAdministrativeStructure findByBatchId(final String batchId, final DBTransaction transaction) throws FinderException, Exception {
		return (ARAdministrativeStructure) findSingle(columnMap.get("batchId") + "=" + batchId, CLASS_NAME, transaction);
	}
	
	public static ARAdministrativeStructure[] findAllByBatchIds(final String batchIds, final DBTransaction transaction) throws FinderException, Exception {
		return findAllAdministrativeStructures(columnMap.get("batchId") + " IN (" + batchIds + ")", transaction);
	}
	
	public static ARAdministrativeStructure findByUIC(final String uic, final DBTransaction transaction) throws FinderException, Exception {
		return (ARAdministrativeStructure) findSingle(columnMap.get("uic") + "='" + uic + "'", CLASS_NAME, transaction);
	}

	public static ARAdministrativeStructure findByContentUUID(final String uuid, final DBTransaction transaction) throws FinderException, Exception {
        return (ARAdministrativeStructure) findSingle(columnMap.get("contentUUID") + "='" + uuid + "'", CLASS_NAME, transaction);
    }
	

	public static ARAdministrativeStructure[] findAllForUpdate(final String batchId, final String name, final String status, final String state, final Integer start, final Integer length, final Integer orderColumn, final String order, final DBTransaction transaction) throws FinderException, Exception {
		String query = columnMap.get("blocked") + " IS NULL";
		if (batchId != null) {
			query += " AND " + columnMap.get("batchId") + "='" + batchId + "'";
		}
		if (name != null) {
			query += " AND UPPER(" + columnMap.get("name") + ") LIKE '%" + name.toUpperCase() + "%'";
		}
		if (status != null) {
			query += " AND " + columnMap.get("status") + "='" + status + "'";
		}
		if (state != null) {
			query += " AND " + columnMap.get("state") + "='" + state + "'";
		} else {
			// Exclude results with state 'Processed'.
			query += " AND " + columnMap.get("state") + " NOT IN ('" + ARConstants.ADMINISTRATIVE_STRUCTURE_STATE_PROCESSED + "')";
		}
		query += " ORDER BY ";
		
		if (orderColumn == null) {
			query += columnMap.get("name");
		} else {
			if (orderColumn == ARConstants.COLUMN_ID) {
				query += columnMap.get("batchId");
			} else if (orderColumn == ARConstants.COLUMN_FOR_UPDATE_NAME) {
				query += columnMap.get("name");
			} else if (orderColumn == ARConstants.COLUMN_FOR_UPDATE_STATUS) {
				query += columnMap.get("status");;
			} else if (orderColumn == ARConstants.COLUMN_FOR_UPDATE_STATE) {
				query += columnMap.get("state");
			} else if (orderColumn == ARConstants.COLUMN_FOR_UPDATE_DATE) {
				query += columnMap.get("synchronizedDate");
			} else {
				query += columnMap.get("name");
			}
		}
		query += " " + (order != null && ARConstants.ORDER_DESC.equalsIgnoreCase(order) ? order.toUpperCase() : ARConstants.ORDER_ASC);
		
		// NOT SUPPORTED BY DB2, so we are doing workaround.
		//query += " LIMIT " + start + ", " + length;	
		if (start != null && length != null) {
			query += " FETCH FIRST " + (start + length) + " ROWS ONLY";
		}
		
		return findAllAdministrativeStructures(query, transaction);
	}
	
	public static ARAdministrativeStructure[] findAllByFilter(final String batchId, final String name, final String status, final String state, final String synched, final Integer start, final Integer length, final Integer orderColumn, final String order, final DBTransaction transaction) throws FinderException, Exception {
		String query = "1=1";
		if (batchId != null) {
			query += " AND " + columnMap.get("batchId") + "='" + batchId + "'";
		}
		if (name != null) {
			query += " AND UPPER(" + columnMap.get("name") + ") LIKE '%" + name.toUpperCase() + "%'";
		}
		if (status != null) {
			query += " AND " + columnMap.get("status") + "='" + status + "'";
		}
		if (state != null) {
			query += " AND " + columnMap.get("state") + "='" + state + "'";
		} else {
			query += " AND " + columnMap.get("state") + " IS NOT NULL";
		}
		if (synched != null) {
			if (ARConstants.ADMINISTRATIVE_STRUCTURE_SYNCHRONIZED.equals(synched)) {
				query += " AND " + columnMap.get("synchronized") + "='" + ARConstants.ADMINISTRATIVE_STRUCTURE_SYNCHRONIZED + "'";
			} else {
				query += " AND " + columnMap.get("synchronized") + "<>'" + ARConstants.ADMINISTRATIVE_STRUCTURE_SYNCHRONIZED + "'";
			}
		}
		query += " ORDER BY ";

		if (orderColumn == null) {
			query += columnMap.get("name");
		} else {
			if (orderColumn == ARConstants.COLUMN_ID) {
				query += columnMap.get("batchId");
			} else if (orderColumn == ARConstants.COLUMN_ALL_NAME) {
				query += columnMap.get("name");
			} else if (orderColumn == ARConstants.COLUMN_ALL_UIC) {
				query += columnMap.get("uic");;
			} else if (orderColumn == ARConstants.COLUMN_ALL_STATUS) {
				query += columnMap.get("status");;
			} else if (orderColumn == ARConstants.COLUMN_ALL_STATE) {
				query += columnMap.get("state");
			} else if (orderColumn == ARConstants.COLUMN_ALL_SYNCHRONIZED) {
				query += columnMap.get("synchronized");
			} else if (orderColumn == ARConstants.COLUMN_ALL_BLOCKED) {
				query += columnMap.get("blocked");
			} else if (orderColumn == ARConstants.COLUMN_FOR_UPDATE_DATE) {
				query += columnMap.get("synchronizedDate");
			} else {
				query += columnMap.get("name");			
			}
		}
		query += " " + (order != null && ARConstants.ORDER_DESC.equalsIgnoreCase(order) ? order.toUpperCase() : ARConstants.ORDER_ASC);
		
		// NOT SUPPORTED BY DB2, so we are doing workaround.
		//query += " LIMIT " + start + ", " + length;			
		if (start != null && length != null) {
			query += " FETCH FIRST " + (start + length) + " ROWS ONLY";
		}
		
		return findAllAdministrativeStructures(query, transaction);
	}
	
	public static ARAdministrativeStructure[] findAllBlocked(final String batchId, final String name, final String status, final Integer start, final Integer length, final Integer orderColumn, final String order, final DBTransaction transaction) throws FinderException, Exception {
		String query = columnMap.get("blocked") + "='" + ARConstants.ADMINISTRATIVE_STRUCTURE_BLOCKED + "'";
		if (batchId != null) {
			query += " AND " + columnMap.get("batchId") + "='" + batchId + "'";
		}
		if (name != null) {
			query += " AND UPPER(" + columnMap.get("name") + ") LIKE '%" + name.toUpperCase() + "%'";
		}
		if (status != null) {
			query += " AND " + columnMap.get("status") + "='" + status + "'";
		}
		query += " ORDER BY ";
		if (orderColumn == null) {
			query += columnMap.get("name");
		} else {
			if (orderColumn == ARConstants.COLUMN_ID) {
				query += columnMap.get("batchId");
			} else if (orderColumn == ARConstants.COLUMN_BLOCKED_NAME) {
				query += columnMap.get("name");
			} else if (orderColumn == ARConstants.COLUMN_BLOCKED_STATUS) {
				query += columnMap.get("status");;
			} else if (orderColumn == ARConstants.COLUMN_BLOCKED_DATE) {
				query += columnMap.get("synchronizedDate");
			} else {
				query += columnMap.get("name");
			}
		}
		query += " " + (order != null && ARConstants.ORDER_DESC.equalsIgnoreCase(order) ? order.toUpperCase() : ARConstants.ORDER_ASC);
		
		// NOT SUPPORTED BY DB2, so we are doing workaround.
		//query += " LIMIT " + start + ", " + length;		
		if (start != null && length != null) {
			query += " FETCH FIRST " + (start + length) + " ROWS ONLY";
		}
		
		return findAllAdministrativeStructures(query, transaction);
	}
	
	public static ARAdministrativeStructure[] findAllByType(final String type, final DBTransaction transaction) throws FinderException, Exception {
		return findAllAdministrativeStructures(columnMap.get("type") + "='" + type + "' ORDER BY " + columnMap.get("name") + " ASC", transaction);
	}
	
	public static ARAdministrativeStructure[] findAllByStatus(final String status, final DBTransaction transaction) throws FinderException, Exception {
		return findAllAdministrativeStructures(columnMap.get("status") + "='" + status + "' ORDER BY " + columnMap.get("name") + " ASC", transaction);
	}
	
	public static ARAdministrativeStructure[] findAllByAdmStructureKind(final String admStructureKind, final DBTransaction transaction) throws FinderException, Exception {
		return findAllAdministrativeStructures(columnMap.get("admStructureKind") + "='" + admStructureKind + "' ORDER BY " + columnMap.get("name") + " ASC", transaction);
	}
	
	public static ARAdministrativeStructure[] findAllByUserDN(final String userDN, final DBTransaction transaction) throws FinderException, Exception {
		return findAllAdministrativeStructures(columnMap.get("userDN") + "='" + userDN + "' ORDER BY " + columnMap.get("name") + " ASC", transaction);
	}
	
	public static ARAdministrativeStructure[] findAllNotBlocked(final DBTransaction transaction) throws FinderException, Exception {
		return findAllAdministrativeStructures(columnMap.get("blocked") + "<>'" + ARConstants.ADMINISTRATIVE_STRUCTURE_BLOCKED + "' ORDER BY " + columnMap.get("name") + " ASC", transaction);
	}
	
	public static ARAdministrativeStructure[] findAllSynchronized(final DBTransaction transaction) throws FinderException, Exception {
		return findAllAdministrativeStructures(columnMap.get("synchronized") + "='" + ARConstants.ADMINISTRATIVE_STRUCTURE_SYNCHRONIZED + "' ORDER BY " + columnMap.get("name") + " ASC", transaction);
	}
	
	public static ARAdministrativeStructure[] findAllNotSynchronized(final DBTransaction transaction) throws FinderException, Exception {
        return findAllAdministrativeStructures(columnMap.get("synchronized") + "<>'" + ARConstants.ADMINISTRATIVE_STRUCTURE_SYNCHRONIZED + "' ORDER BY " + columnMap.get("name") + " ASC", transaction);
    }
	
	public static ARAdministrativeStructure[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllAdministrativeStructures("1=1", transaction);
	}

	public static ARAdministrativeStructure[] findAllAdministrativeStructures(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final ARAdministrativeStructure[] administrativeStructures = new ARAdministrativeStructure[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				administrativeStructures[i] = (ARAdministrativeStructure) tmp[i];
			}
			return administrativeStructures;
		} 
		return null;
	}
	
}
