package com.ibs.gateway;

import java.util.HashMap;

import com.ibs.gateway.bean.Container;
import com.ibs.gateway.bean.Message;

public class ARGatewayPortletSessionBean {
	
	private String currentPage = ARGatewayPortlet.ADMINISTRATIVE_STRUCTURES_PAGE;
	HashMap<String, Container> container = null;
	HashMap<String, String> tabPerPage = null;
	Message message = null;
	java.util.Map<String, String[]> parameterMap = null;

	public String getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}

	public HashMap<String, Container> getContainer() {
		return container != null ? container : new HashMap<String, Container>();
	}

	public void setContainer(HashMap<String, Container> container) {
		this.container = container;
	}

	public HashMap<String, String> getTabPerPage() {
		return tabPerPage != null ? tabPerPage : new HashMap<String, String>();
	}

	public void setTabPerPage(HashMap<String, String> tabPerPage) {
		this.tabPerPage = tabPerPage;
	}

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}

	public java.util.Map<String, String[]> getParameterMap() {
		return parameterMap;
	}

	public void setParameterMap(java.util.Map<String, String[]> parameterMap) {
		this.parameterMap = parameterMap;
	}
	
}
