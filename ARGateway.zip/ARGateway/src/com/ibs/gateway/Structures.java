package com.ibs.gateway;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import com.ibs.gateway.dbo.ARAdministrativeStructure;
import com.ibs.gateway.management.ARStructureManagement;

@WebServlet("/structures")
public class Structures extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
       
    public Structures() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("application/json; charset=UTF-8");
		String tab = request.getParameter("tab");
		JSONObject json = new JSONObject();
		if (ARConstants.TAB_STRUCTURES_FOR_UPDATE.equalsIgnoreCase(tab)) {
			ARStructureManagement management = new ARStructureManagement();
			ARAdministrativeStructure[] structures = management.loadAdministrativeStructuresForUpdate(null, null, null, null);
			if (structures != null && structures.length > 0) {
				JSONArray ja = new JSONArray(); 
				JSONArray tmpJA = null; 
				for (int i = 0; i < structures.length; i++) {
					tmpJA = new JSONArray();
					tmpJA.put(structures[i].getBatchId().toString());
					tmpJA.put(structures[i].getName());
					tmpJA.put(structures[i].getStatus());
					tmpJA.put(structures[i].getState());
					tmpJA.put((structures[i].getLastUpdateDate() != null) ? structures[i].getLastUpdateDate() : "");
					tmpJA.put(structures[i].getId());
					ja.put(tmpJA);					
				}				
				json.put("data", ja);
			}
		} else if (ARConstants.TAB_STRUCTURES_ALL.equalsIgnoreCase(tab)) {
			ARStructureManagement management = new ARStructureManagement();
			ARAdministrativeStructure[] structures = management.loadAllAdministrativeStructures(null, null, null, null, null);
			if (structures != null && structures.length > 0) {
				JSONArray ja = new JSONArray(); 
				JSONArray tmpJA = null; 
				for (int i = 0; i < structures.length; i++) {
					tmpJA = new JSONArray();
					tmpJA.put(structures[i].getBatchId().toString());
					tmpJA.put(structures[i].getName());
					tmpJA.put(structures[i].getUic());
					tmpJA.put(structures[i].getStatus());
					tmpJA.put(structures[i].getState());
					tmpJA.put(structures[i].getSynchronized());
					tmpJA.put(structures[i].getBlocked());
					tmpJA.put((structures[i].getLastUpdateDate() != null) ? structures[i].getLastUpdateDate() : "");
					tmpJA.put(structures[i].getId());
					ja.put(tmpJA);					
				}				
				json.put("data", ja);
			}
		} else if (ARConstants.TAB_STRUCTURES_BLOCKED.equalsIgnoreCase(tab)) {
			ARStructureManagement management = new ARStructureManagement();
			ARAdministrativeStructure[] structures = management.loadAllBlockedAdministrativeStructures(null, null, null);
			if (structures != null && structures.length > 0) {
				JSONArray ja = new JSONArray(); 
				JSONArray tmpJA = null; 
				for (int i = 0; i < structures.length; i++) {
					tmpJA = new JSONArray();
					tmpJA.put(structures[i].getBatchId().toString());
					tmpJA.put(structures[i].getName());
					tmpJA.put(structures[i].getStatus());
					tmpJA.put((structures[i].getLastUpdateDate() != null) ? structures[i].getLastUpdateDate() : "");
					tmpJA.put(structures[i].getId());
					ja.put(tmpJA);					
				}				
				json.put("data", ja);
			}
		}
		String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
		response.getWriter().print(jsonPrettyPrintString);
		response.getWriter().flush();
		response.getWriter().close();		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
