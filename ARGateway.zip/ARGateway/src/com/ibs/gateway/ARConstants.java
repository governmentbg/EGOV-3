package com.ibs.gateway;

import javax.xml.namespace.QName;

public class ARConstants {
	// DB name for Oracle database.
	public static String _DB_ORACLE = "***";
	// DB name for IBM DB2 database.
	public static String _DB_DB2 = "***";
	// DB name for PostgreSQL database.
	public static String _DB_POSTGRESQL = "***";
	// Global administrator user name.
	public static String ADMIN_USER_NAME = "***";
	// Managers user name
	public static String[] MANAGERS_USER_NAME = {"*"};	
	
	// Configuration files.	
	public static String STRUCTURES_CONFIG_FILE_NAME = "structures.conf";
	public static String SERVICES_CONFIG_FILE_NAME = "services.conf";
	public static String THREAD_EXECUTION_TIME_PARAMETER = "thread_execution_time";

	// BatchInfoService WSDL URL.
	public static final String BATCH_INFO_SERVICE_URL = "https://iisda.government.bg/Services/RAS/RAS.Integration.Host/BatchInfoService.svc?wsdl";	
	public static final String BATCH_INFO_SERVICE_URL_HTTP_ONLY = "http://iisda.government.bg/Services/RAS/RAS.Integration.Host/BatchInfoService.svc?wsdl";
	// QName for BatchInfoService.
	public static final QName BATCH_INFO_SERVICE_QNAME = new QName("http://tempuri.org/", "BatchInfoService");
	// QName for WSHttpBinding_IBatchInfoService.
	public final static QName WS_HTTP_BINDING_I_BATCH_INFO_SERVICE_QNAME = new QName("http://tempuri.org/", "WSHttpBinding_IBatchInfoService");
	// "BatchInfoService WSDL file name.
	public static final String BATCH_INFO_SERVICE_WSDL_FILE_NAME = "BatchInfoService.wsdl";
	// AdmServicesService WSDL URL.
	// old, not supported anymore.
	public static final String ADM_SERVICES_SERVICE_URL = "https://iisda.government.bg/Services/AdmServices/AdministrativeServices.IntegrationServices/AdmServicesService/AdmServicesService.svc?wsdl";
	public static final String ADM_SERVICES_SERVICE_URL_HTTP_ONLY = "http://iisda.government.bg/Services/AdmServices/AdministrativeServices.IntegrationServices/AdmServicesService/AdmServicesService.svc?singleWsdl";
	// QName for AdmServicesService.
	public final static QName BASIC_HTTP_BINDING_I_ADM_SERVICES_SERVICE = new QName("http://tempuri.org/", "BasicHttpBinding_IAdmServicesService");
    public final static QName BASIC_HTTPS_BINDING_I_ADM_SERVICES_SERVICE = new QName("http://tempuri.org/", "BasicHttpsBinding_IAdmServicesService");    
    // QName for AdmServicesService.
    // old, not supported anymore.	
	public static final QName ADM_SERVICES_SERVICE_Q_NAME = new QName("http://tempuri.org/", "AdmServicesService");
	// "AdmServicesService WSDL file name.
	public static final String ADM_SERVICES_SERVICE_WSDL_FILE_NAME = "AdmServicesService.wsdl";
	// For new administrative structures.
	public static final String ADMINISTRATIVE_STRUCTURE_STATE_IS_NEW = "1";
	// For existing, but changes found on the source (AR).
	public static final String ADMINISTRATIVE_STRUCTURE_STATE_IS_UPDATE = "2";
	// For existing, but status was changed from ACTIVE -> INACTIVE, or the opposite.
	public static final String ADMINISTRATIVE_STRUCTURE_STATE_STATUS_CHANGED = "3";
	// For existing, no information found on the source anymore (maybe deleted on AR?).
	public static final String ADMINISTRATIVE_STRUCTURE_STATE_NOT_FOUND = "4";
	// After importing the AR to WCM we set the status to 'Processed'.
	public static final String ADMINISTRATIVE_STRUCTURE_STATE_PROCESSED = "9";
	// For new administrative services.
	public static final String ADMINISTRATIVE_SERVICE_STATE_IS_NEW = "1";
	// For existing, but changes found on the source (AR).
	public static final String ADMINISTRATIVE_SERVICE_STATE_IS_UPDATE = "2";
	// For existing, no information found on the source anymore (maybe deleted on AR?).
	public static final String ADMINISTRATIVE_SERVICE_STATE_NOT_FOUND = "4";
	// After importing the AR to WCM we set the status to 'Processed'.
	public static final String ADMINISTRATIVE_SERVICE_STATE_PROCESSED = "9";

	// Distinguished name for operation(s) executed internally.
	public static final String SYSTEM_USER_DN = "*";
	
	// Code for Bulgarian language.
	public static final String LANGUAGE_BG = "bg";
	// Code for English language.
	public static final String LANGUAGE_EN = "en";
	// Value for "Administrative Structures" mode of the portlet.
	public static final String MODE_ADMINISTRATIVE_STRUCTURES = "1";
	// Value for "Administrative Services" mode of the portlet.
	public static final String MODE_ADMINISTRATIVE_SERVICES = "2";
	// Default value for "results per page" in list view.
	public static final int RESULTS_PER_PAGE = 10;
	
	// Product name, printed in the server logs.
	public static String _PRODUCT_NAME = "ARGateway";
	// Product version, printed in the server logs.
	public static String _PRODUCT_VERSION = "1.0";
	public static String _OFFICIALMAILSENDER = null;
	
	// Value in the DB for blocked administrative structure(s).
	public static final String ADMINISTRATIVE_STRUCTURE_BLOCKED = "1";
	// Value in the DB for synchronized administrative structure(s).
	public static final String ADMINISTRATIVE_STRUCTURE_SYNCHRONIZED = "1";	
	// Value in the DB for blocked administrative service(s).
	public static final String ADMINISTRATIVE_SERVICE_BLOCKED = "1";
	// Value in the DB for synchronized administrative service(s).
	public static final String ADMINISTRATIVE_SERVICE_SYNCHRONIZED = "1";	
	
	// Constant for message type for "information".
	public static final String MESSAGE_TYPE_INFORMATION = "I";
	// Constant for message type for "warning".
	public static final String MESSAGE_TYPE_WARNING = "W";
	// Constant for message type for "error".
	public static final String MESSAGE_TYPE_ERROR = "E";
	
	// Time in hours at which the thread will load the data from the "Administrative Register" service. 
	public static final int AR_STRUCTURES_LOADER_PROCESS_TIME = 3; // (24 Hours time format) 
	// Time in hours at which the thread will load the data from the "Administrative Register" service. 
	public static final int AR_SERVICES_LOADER_PROCESS_TIME = 4; // (24 Hours time format) 
	// Theme "IBM".
	public static final String THEME_NAME_IBM = "ibm";
	// Theme "VP".
	public static final String THEME_NAME_VP = "vp";
	// Structures tabs.
	public static final String TAB_STRUCTURES_FOR_UPDATE = "0";
	public static final String TAB_STRUCTURES_ALL = "1";
	public static final String TAB_STRUCTURES_BLOCKED = "2";
	
	// Columns.
	public static final int COLUMN_ID = 0;
	
	public static final int COLUMN_FOR_UPDATE_NAME = 1;
	public static final int COLUMN_FOR_UPDATE_STATUS = 2;
	public static final int COLUMN_FOR_UPDATE_STATE = 3;
	public static final int COLUMN_FOR_UPDATE_DATE = 4;
	
	public static final int COLUMN_ALL_NAME = 1;
	public static final int COLUMN_ALL_UIC = 2;
	public static final int COLUMN_ALL_STATUS = 3;
	public static final int COLUMN_ALL_STATE = 4;
	public static final int COLUMN_ALL_SYNCHRONIZED = 5;
	public static final int COLUMN_ALL_BLOCKED = 6;
	public static final int COLUMN_ALL_DATE = 7;
	
	public static final int COLUMN_BLOCKED_NAME = 1;
	public static final int COLUMN_BLOCKED_STATUS = 2;
	public static final int COLUMN_BLOCKED_DATE = 3;
	
	public static final int COLUMN_SERVICES_FOR_UPDATE_NAME = 1;
	public static final int COLUMN_SERVICES_FOR_UPDATE_SECTION_NAME = 2;
	public static final int COLUMN_SERVICES_FOR_UPDATE_SUPPLIER_BATCH_ID = 3;
	public static final int COLUMN_SERVICES_FOR_UPDATE_SUPPLIER_NAME = 4;
	public static final int COLUMN_SERVICES_FOR_UPDATE_STATE = 5;
	public static final int COLUMN_SERVICES_FOR_UPDATE_DATE = 6;
	
	public static final int COLUMN_SERVICES_ALL_NAME = 1;
	public static final int COLUMN_SERVICES_ALL_SECTION_NAME = 2;
	public static final int COLUMN_SERVICES_ALL_SUPPLIER_BATCH_ID = 3;
	public static final int COLUMN_SERVICES_ALL_SUPPLIER_NAME = 4;
	public static final int COLUMN_SERVICES_ALL_STATE = 5;
	public static final int COLUMN_SERVICES_ALL_SYNCHRONIZED = 6;
	public static final int COLUMN_SERVICES_ALL_BLOCKED = 7;
	public static final int COLUMN_SERVICES_ALL_DATE = 8;
	
	public static final int COLUMN_SERVICES_BLOCKED_NAME = 1;
	public static final int COLUMN_SERVICES_BLOCKED_SECTION_NAME = 2;
	public static final int COLUMN_SERVICES_BLOCKED_SUPPLIER_BATCH_ID = 3;
	public static final int COLUMN_SERVICES_BLOCKED_SUPPLIER_NAME = 4;
	public static final int COLUMN_SERVICES_BLOCKED_DATE = 5;
	
	// Order
	public static final String ORDER_ASC = "asc";
	public static final String ORDER_DESC = "desc";
	
	// Constant used as a trigger for printing debug messages to the server logs.
	public static final boolean ISDEBUG = false;

}
