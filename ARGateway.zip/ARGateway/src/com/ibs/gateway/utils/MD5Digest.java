package com.ibs.gateway.utils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MD5Digest {
    private MessageDigest md5;
    private StringBuffer digestBuffer;

    public MD5Digest() throws NoSuchAlgorithmException {
        md5 = MessageDigest.getInstance("MD5");
        digestBuffer = new StringBuffer();
    }


    public String md5crypt(String password) {
        int index;
        byte[] digest;
        if (password == null) {
            return null;
        }
        digestBuffer.setLength(0);
        digest = md5.digest(password.getBytes());

        for (index = 0; index < digest.length; ++index) {
            digestBuffer.append(Integer.toHexString(digest[index] & 0xff));
        }

        return digestBuffer.toString();
    } // md5crypt


    public static final void main(String[] args) {
        MD5Digest md5;
        int argc;

        if (args.length < 1) {
            System.err.println("Usage: MD5Digest [password] ...");
            return;
        }

        try {
            md5 = new MD5Digest();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return;
        }

        for (argc = 0; argc < args.length; ++argc) {
            Logger.log(Logger.DEBUG_LEVEL, md5.md5crypt(args[argc]));
        }

    } // main
} // class MD5Digest