package com.ibs.gateway.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.StringTokenizer;

import javax.portlet.PortletPreferences;
import javax.portlet.RenderRequest;

import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.AuthoringTemplate;
import com.ibm.workplace.wcm.api.Category;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.ContentComponent;
import com.ibm.workplace.wcm.api.Document;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentTypes;
import com.ibm.workplace.wcm.api.LinkComponent;
import com.ibm.workplace.wcm.api.OptionSelectionComponent;
import com.ibm.workplace.wcm.api.RichTextComponent;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.SiteArea;
import com.ibm.workplace.wcm.api.Taxonomy;
import com.ibm.workplace.wcm.api.TextComponent;
import com.ibm.workplace.wcm.api.Workspace;
import com.ibs.gateway.ARConstants;
import com.ibs.gateway.ARGatewayPortlet;
import com.ibs.gateway.dbo.ARAdministrativeStructure;

import bg.government.iisda.admservices.AdmServiceInfoDocumentType;
import bg.government.iisda.admservices.AdmServiceInfoType;
import bg.government.iisda.admservices.AdmServiceStageType;
import bg.government.iisda.admservices.ArrayOfServiceApplicationMethodsEnum;
import bg.government.iisda.admservices.PaymentInfoType;
import bg.government.iisda.admservices.PaymentMethodsEnum;
import bg.government.iisda.admservices.RegulatoryActLegalBasisType;
import bg.government.iisda.admservices.RegulatoryActStructuredDataType;
import bg.government.iisda.admservices.ServiceApplicationMethodsEnum;
import bg.government.iisda.admservices.UnitContactType;
import bg.government.iisda.admservices.common.CorrespondenceDataPhoneType;
import bg.government.iisda.ras.common.ActBaseType;
import bg.government.iisda.ras.common.ActChangeType;
import bg.government.iisda.ras.common.ActType;
import bg.government.iisda.ras.common.CorrespondenceDataType;
import bg.government.iisda.ras.common.WorkingTimeType;
import bg.government.iisda.ras.common.WorkingTimeTypeEnum;

public class ARUtils {

	private static SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH);
	private static SimpleDateFormat dateTimeFormat_yyyy_MM_dd = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);

	public static void loadPreferences(RenderRequest request) {
		PortletPreferences portletPreferences = request.getPreferences();
		if (portletPreferences != null) {
			String resultsPerPage = portletPreferences.getValue(ARGatewayPortlet.PORTLET_PREFERENCE_STRUCTURES_RESULTS_PER_PAGE, ARConstants.RESULTS_PER_PAGE + "");
			if (resultsPerPage != null && resultsPerPage.trim().length() > 0) {
				try {
					ARGatewayPortlet.structuresResultsPerPage = Integer.parseInt(resultsPerPage);
				} catch (NumberFormatException e) {
				}
			}	
			resultsPerPage = portletPreferences.getValue(ARGatewayPortlet.PORTLET_PREFERENCE_SERVICES_RESULTS_PER_PAGE, ARConstants.RESULTS_PER_PAGE + "");
			if (resultsPerPage != null && resultsPerPage.trim().length() > 0) {
				try {
					ARGatewayPortlet.servicesResultsPerPage = Integer.parseInt(resultsPerPage);
				} catch (NumberFormatException e) {
				}
			}	
			ARGatewayPortlet.mode = portletPreferences.getValue(ARGatewayPortlet.PORTLET_PREFERENCE_MODE, ARConstants.MODE_ADMINISTRATIVE_STRUCTURES);
			ARGatewayPortlet.mailSmtpHost = portletPreferences.getValue(ARGatewayPortlet.PORTLET_PREFERENCE_MAIL_SMTP_HOST, "mail");
			ARGatewayPortlet.fromAddress = portletPreferences.getValue(ARGatewayPortlet.PORTLET_PREFERENCE_FROM_ADDRESS, "");
			ARGatewayPortlet.language = portletPreferences.getValue(ARGatewayPortlet.PORTLET_PREFERENCE_LANGUAGE, ARConstants.LANGUAGE_BG);			
			ARGatewayPortlet.theme = portletPreferences.getValue(ARGatewayPortlet.PORTLET_PREFERENCE_THEME, ARConstants.THEME_NAME_VP);
			ARGatewayPortlet.autoPublish = "1".equals(portletPreferences.getValue(ARGatewayPortlet.PORTLET_PREFERENCE_AUTO_PUBLISH, "0")); 
			ARGatewayPortlet.portletWidth = portletPreferences.getValue(ARGatewayPortlet.PORTLET_PREFERENCE_PORTLET_WIDTH, null);
			if (ARConstants.MODE_ADMINISTRATIVE_STRUCTURES.equalsIgnoreCase(ARGatewayPortlet.mode)) {
				try {
					ARGatewayPortlet.structuresThreadExecutionTime = Integer.parseInt(portletPreferences.getValue(ARGatewayPortlet.PORTLET_PREFERENCE_THREAD_EXECUTION_TIME, ARConstants.AR_STRUCTURES_LOADER_PROCESS_TIME + ""));	
				} catch (Exception e) {
					e.printStackTrace();
				}				
			} else if (ARConstants.MODE_ADMINISTRATIVE_SERVICES.equalsIgnoreCase(ARGatewayPortlet.mode)) {
				try {
					ARGatewayPortlet.servicesThreadExecutionTime = Integer.parseInt(portletPreferences.getValue(ARGatewayPortlet.PORTLET_PREFERENCE_THREAD_EXECUTION_TIME, ARConstants.AR_SERVICES_LOADER_PROCESS_TIME + ""));	
				} catch (Exception e) {
					e.printStackTrace();
				}				
				
			}
			ARGatewayPortlet.debug = "1".equals(portletPreferences.getValue(ARGatewayPortlet.PORTLET_PREFERENCE_DEBUG, "0"));	
			
			return;
		}
		ARGatewayPortlet.preferencesLoaded = false;
	}
	
	public static boolean isAdmCentral(ARAdministrativeStructure administrativeStructure) {
		if (administrativeStructure == null) return false;
		return (bg.government.iisda.ras.AdmStructureKindsEnum.COUNCIL_OF_MINISTERS_ADMINISTRATION.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind())
				|| bg.government.iisda.ras.AdmStructureKindsEnum.MINISTRY.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind())
				|| bg.government.iisda.ras.AdmStructureKindsEnum.STATE_AGENCY.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind())
				|| bg.government.iisda.ras.AdmStructureKindsEnum.STATE_COMMISION_ADMINISTRION.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind())
				|| bg.government.iisda.ras.AdmStructureKindsEnum.EXECUTIVE_AGENCY.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind())
				|| bg.government.iisda.ras.AdmStructureKindsEnum.EXECUTIVE_POWER_ADMINISTRATIVE_STRUCTURE.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind())
				|| bg.government.iisda.ras.AdmStructureKindsEnum.ACT_60_ADIMINISTRATIVE_STRUCTURE.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind()));
	}
	
	public static boolean isAdmRegional(ARAdministrativeStructure administrativeStructure) {
		if (administrativeStructure == null) return false;
		return bg.government.iisda.ras.AdmStructureKindsEnum.REGIONAL_ADMINISRATION.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind());
	}
	
	public static boolean isAdmMunicipal(ARAdministrativeStructure administrativeStructure) {
		if (administrativeStructure == null) return false;
		return bg.government.iisda.ras.AdmStructureKindsEnum.MUNICIPAL_ADMINISTRATION.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind());
	}
	
	public static boolean isAdmAreaMunicipal(ARAdministrativeStructure administrativeStructure) {
		if (administrativeStructure == null) return false;
		return bg.government.iisda.ras.AdmStructureKindsEnum.AREA_MUNICIPAL_ADMINISTRATION.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind());
	}
	
	public static boolean isAdmSpecializedTerritorial(ARAdministrativeStructure administrativeStructure) {
		if (administrativeStructure == null) return false;
		return bg.government.iisda.ras.AdmStructureKindsEnum.SPECIALIZED_LOCAL_ADMINISTRATION.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind());
	}
	
	// This is a logical grouping.
	public static boolean isAdmTerritorial(ARAdministrativeStructure administrativeStructure) {
		if (administrativeStructure == null) return false;
		return isAdmRegional(administrativeStructure) || 
			   isAdmMunicipal(administrativeStructure) || 
			   isAdmAreaMunicipal(administrativeStructure) ||
			   isAdmSpecializedTerritorial(administrativeStructure);
	}
	
	public static AuthoringTemplate getATByAdmStructureKind(ARAdministrativeStructure administrativeStructure) {
		if (isAdmCentral(administrativeStructure)) {
			return EgovWCMCache.getATServiceProviderCentralAdministration();
		} else if (isAdmTerritorial(administrativeStructure)) {
			return EgovWCMCache.getATServiceProviderTerritorialAdministration();
		}
		return null;
		
	}

	public static String buildWCMSiteAreaNameFromAdministrativeStructure(ARAdministrativeStructure administrativeStructure) {
		if (bg.government.iisda.ras.AdmStructureKindsEnum.COUNCIL_OF_MINISTERS_ADMINISTRATION.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind())) {
			return EgovWCMCache.SP_SITE_AREA_COUNCIL_OF_MINISTERS_ADMINISTRATION_NAME;
		}
		if (bg.government.iisda.ras.AdmStructureKindsEnum.MINISTRY.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind())) {
			return EgovWCMCache.SP_SITE_AREA_MINISTRY_NAME;			
		}
		if (bg.government.iisda.ras.AdmStructureKindsEnum.STATE_AGENCY.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind())) {
			return EgovWCMCache.SP_SITE_AREA_STATE_AGENCY_NAME;			
		}
		if (bg.government.iisda.ras.AdmStructureKindsEnum.STATE_COMMISION_ADMINISTRION.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind())) {
			return EgovWCMCache.SP_SITE_AREA_STATE_COMMISION_ADMINISTRION_NAME;			
		}
		if (bg.government.iisda.ras.AdmStructureKindsEnum.EXECUTIVE_AGENCY.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind())) {
			return EgovWCMCache.SP_SITE_AREA_EXECUTIVE_AGENCY_NAME;			
		}
		if (bg.government.iisda.ras.AdmStructureKindsEnum.EXECUTIVE_POWER_ADMINISTRATIVE_STRUCTURE.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind())) {
			if (administrativeStructure.getName().toLowerCase().contains("агенция")) {
				return EgovWCMCache.SP_SITE_AREA_EXECUTIVE_POWER_ADMINISTRATIVE_STRUCTURE_AGENCY_NAME;
			} else if (administrativeStructure.getName().toLowerCase().contains("комисия")) {
				return EgovWCMCache.SP_SITE_AREA_EXECUTIVE_POWER_ADMINISTRATIVE_STRUCTURE_COMMISION_NAME;
			}
			return EgovWCMCache.SP_SITE_AREA_EXECUTIVE_POWER_ADMINISTRATIVE_STRUCTURE_OTHER_NAME;
		}
		if (bg.government.iisda.ras.AdmStructureKindsEnum.ACT_60_ADIMINISTRATIVE_STRUCTURE.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind())) {
			return EgovWCMCache.SP_SITE_AREA_ACT_60_ADIMINISTRATIVE_STRUCTURE_NAME;
		}
		if (bg.government.iisda.ras.AdmStructureKindsEnum.REGIONAL_ADMINISRATION.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind())) {
			return EgovWCMCache.SP_SITE_AREA_REGIONAL_ADMINISRATION_NAME;			
		}
		if (bg.government.iisda.ras.AdmStructureKindsEnum.MUNICIPAL_ADMINISTRATION.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind())) {
			return EgovWCMCache.SP_SITE_AREA_MUNICIPAL_ADMINISTRATION_NAME;			
		}
		if (bg.government.iisda.ras.AdmStructureKindsEnum.AREA_MUNICIPAL_ADMINISTRATION.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind())) {
			return EgovWCMCache.SP_SITE_AREA_AREA_MUNICIPAL_ADMINISTRATION_NAME;			
		}
		if (bg.government.iisda.ras.AdmStructureKindsEnum.SPECIALIZED_LOCAL_ADMINISTRATION.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind())) {
			// We return the parent. The child is loaded later.
			return EgovWCMCache.SP_SITE_AREA_SPECIALIZED_TERRITORIAL_ADMINISTRATION_NAME;
		}
		return null;
	}
	
	@SuppressWarnings({ "rawtypes"})
	public static DocumentId getWCMAdmStructureKindCategoryFromAdministrativeStructure(ARAdministrativeStructure administrativeStructure) {
		Taxonomy taxonomy = EgovWCMCache.getTaxonomyAdmStructureKindsEnum();
		if (taxonomy != null) {
			DocumentIdIterator dIt = taxonomy.getChildren();
			if (dIt != null) {
				DocumentId dId = null;
				while (dIt.hasNext()) { 
					dId = dIt.next();
					if (dId.getName().equalsIgnoreCase(administrativeStructure.getAdmStructureKind())) {
						return dId;
					}
				}
			}
		}
		return null;
	}
	
	@SuppressWarnings({ "rawtypes"})
	public static DocumentId getWCMDistrictEkatteCategory(String districtEkatteCode) {
		if (districtEkatteCode == null) return null;
		Taxonomy taxonomy = EgovWCMCache.getTaxonomyDistrictsEkatte();
		if (taxonomy != null) {
			DocumentIdIterator dIt = taxonomy.getChildren();
			if (dIt != null) {
				DocumentId dId = null;
				while (dIt.hasNext()) { 
					dId = dIt.next();
					if (dId.getName().equalsIgnoreCase(districtEkatteCode)) {
						return dId;
					}
				}
			}
		}
		return null;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked"})
	public static DocumentId getWCMMunicipalityEkatteCategory(String municipalityEkatteCode) {
		if (municipalityEkatteCode == null) return null;
		Taxonomy taxonomy = EgovWCMCache.getTaxonomyDistrictsEkatte();
		if (taxonomy != null) {
			DocumentIdIterator dIt = taxonomy.getChildren();
			if (dIt != null) {
				DocumentId dId = null;
				String districtEkatteCode = municipalityEkatteCode.substring(0, 3);
				Category category = null;
				while (dIt.hasNext()) { 
					dId = dIt.next();
					if (dId.getName().equalsIgnoreCase(districtEkatteCode)) {
						try {
							category = (Category)EgovWCMCache.getWorkspace().getById(dId);
							if (category != null) {
								DocumentIdIterator docIt = category.getChildren();
								if (docIt != null) {
									dId = null;
									while (docIt.hasNext()) { 
										dId = docIt.next();
										if (dId.getName().equalsIgnoreCase(municipalityEkatteCode)) {
											return dId;
										}
									}
								}
							}						
						} catch (Exception e) {
							e.printStackTrace();
						}
						return null;
					}					
				}
			}
		}
		return null;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked"})
	public static DocumentId getWCMMainCategoryFromAdministrativeStructureAndSiteAreaName(ARAdministrativeStructure administrativeStructure, String siteAreaName) {
		Taxonomy taxonomy = EgovWCMCache.getTaxonomyServiceProviders();
		if (taxonomy != null) {
			DocumentIdIterator dIt = taxonomy.getChildren();
			if (dIt != null) {
				DocumentId dId = null;
				// Here we cover the following administrations:
				// Specialized Territorial
				if (bg.government.iisda.ras.AdmStructureKindsEnum.SPECIALIZED_LOCAL_ADMINISTRATION.value().equalsIgnoreCase(administrativeStructure.getAdmStructureKind())) {
					// We need to go down one level more.
					String parentSiteAreaName = EgovWCMCache.SP_SITE_AREA_SPECIALIZED_TERRITORIAL_ADMINISTRATION_NAME;
					while (dIt.hasNext()) { 
						dId = dIt.next();
						if (dId.getName().equalsIgnoreCase(parentSiteAreaName)) {
							try {
								Category parentCategory = (Category) EgovWCMCache.getWorkspace().getById(dId);
								if (parentCategory != null) {
									DocumentIdIterator parentdIt = parentCategory.getChildren();
									if (parentdIt != null) {
										DocumentId docId = null;
										while (parentdIt.hasNext()) { 
											docId = parentdIt.next();
											if (docId.getName().equalsIgnoreCase(siteAreaName)) {
												return docId;
											}
										}
									}
								}
							} catch (Exception e) {
								e.printStackTrace();
							}
							break;
						}
					}
				} else {
					// Here we cover the following administrations:
					// Central
					// Regional
					// Municipal
					// AreaMunicipal 
					while (dIt.hasNext()) { 
						dId = dIt.next();
						if (dId.getName().equalsIgnoreCase(siteAreaName)) {
							return dId;
						}
					}
				}
			}
		}
		return null;
	}
	
	public static String getAdmCustomName (String admStructureName) {
		if (admStructureName == null) return null;
		int pos = admStructureName.indexOf(" - ");
		if (pos != -1) {
			return admStructureName.substring(pos + 3).trim();
		}
		// Fallback to admStructureName.
		return admStructureName.trim();
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked"})
	public static ArrayList getAdmSpecializedLocalCustomData(ARAdministrativeStructure administrativeStructure) {
		SiteArea specializedSiteArea = EgovWCMCache.getSiteAreaAdmTerritorialKindSpecializedTerritorial();
		DocumentIdIterator iterator = specializedSiteArea.getDirectChildren(Workspace.WORKFLOWSTATUS_PUBLISHED);
		if (iterator.hasNext()) {						
			DocumentId tmpDocId = null;
			Content content = null;
			String asName = administrativeStructure.getName().toLowerCase();
			String genericName = null;
			String customName = null;			
			Category extendGenericName = null;
			if (asName.contains("Басейнова дирекция".toLowerCase())) {
				genericName = EgovWCMCache.SP_SITE_AREA_STA_BASEYNOVA_DIREKTSIA_NAME;
				customName = administrativeStructure.getName();
				extendGenericName = EgovWCMCache.getCategoryCommonNo();
			} else if (asName.contains("Горска семеконтролна станция".toLowerCase())) {
				genericName = EgovWCMCache.SP_SITE_AREA_STA_GORSKA_SEMEKONTROLNA_STANTSIA_NAME;
				customName = administrativeStructure.getName();
				extendGenericName = EgovWCMCache.getCategoryCommonNo();
			} else if (asName.contains("Дирекция \"Национален парк".toLowerCase())) {
				genericName = EgovWCMCache.SP_SITE_AREA_STA_DIREKTSIA_NATSIONALEN_PARK_NAME;
				customName = administrativeStructure.getName();
				extendGenericName = EgovWCMCache.getCategoryCommonNo();
			} else if (asName.contains("Дирекция природен парк".toLowerCase())) {
				genericName = EgovWCMCache.SP_SITE_AREA_STA_DIREKTSIA_PRIRODEN_PARK_NAME;
				customName = administrativeStructure.getName();
				extendGenericName = EgovWCMCache.getCategoryCommonNo();
			} else if (asName.contains("Лесозащитна станция".toLowerCase())) {
				genericName = EgovWCMCache.SP_SITE_AREA_STA_LESOZASHTITNA_STANTSIA_NAME;
				customName = getAdmCustomName(administrativeStructure.getName());
				extendGenericName = EgovWCMCache.getCategoryCommonYes();
			} else if (asName.contains("Областна дирекция \"Земеделие\"".toLowerCase())) {
				genericName = EgovWCMCache.SP_SITE_AREA_STA_OBLASTNA_DIREKTSIA_ZEMEDELIE_NAME;
				customName = getAdmCustomName(administrativeStructure.getName());
				extendGenericName = EgovWCMCache.getCategoryCommonYes();
			} else if (asName.contains("Регионална дирекция по горите".toLowerCase())) {
				genericName = EgovWCMCache.SP_SITE_AREA_STA_REGIONALNA_DIREKTSIA_PO_GORITE_NAME;
				customName = getAdmCustomName(administrativeStructure.getName());
				extendGenericName = EgovWCMCache.getCategoryCommonYes();
			} else if (asName.contains("Регионална здравна инспекция".toLowerCase()) || asName.equalsIgnoreCase("Столична регионална здравна инспекция")) {
				genericName = EgovWCMCache.SP_SITE_AREA_STA_REGIONALNA_ZDRAVNA_INSPEKTSIA_NAME;
				if (asName.equalsIgnoreCase("Столична регионална здравна инспекция")) {
					customName = administrativeStructure.getName();
					extendGenericName = EgovWCMCache.getCategoryCommonNo();
				} else {
					customName = getAdmCustomName(administrativeStructure.getName());
					extendGenericName = EgovWCMCache.getCategoryCommonYes();
				}
			} else if (asName.contains("Регионална инспекция по околна среда и водите".toLowerCase())) {
				genericName = EgovWCMCache.SP_SITE_AREA_STA_REGIONALNA_INSPEKTSIA_PO_OKOLNA_SREDA_I_VODITE_NAME;
				customName = getAdmCustomName(administrativeStructure.getName());
				extendGenericName = EgovWCMCache.getCategoryCommonYes();
			} else if (asName.contains("Регионално управление на образованието ".toLowerCase())) {
				genericName = EgovWCMCache.SP_SITE_AREA_STA_REGIONALNO_UPRAVLENIE_NA_OBRAZOVANIETO_NAME;
				customName = getAdmCustomName(administrativeStructure.getName());
				extendGenericName = EgovWCMCache.getCategoryCommonYes();
			} else if (asName.contains("Териториално статистическо бюро".toLowerCase())) {
				genericName = EgovWCMCache.SP_SITE_AREA_STA_TERITORIALNO_STATISTICHESKO_BYURO_NAME;
				customName = getAdmCustomName(administrativeStructure.getName());
				extendGenericName = EgovWCMCache.getCategoryCommonYes();
			}
			if (genericName != null) {
				while (iterator.hasNext()) {
					tmpDocId = iterator.next();
					// Find the site area first.
					if (tmpDocId.getType().isOfType(DocumentTypes.SiteArea) && tmpDocId.getName().equalsIgnoreCase(genericName)) {
						try {
							SiteArea specializedSiteAreaChild = (SiteArea)EgovWCMCache.getWorkspace().getById(tmpDocId);
							if (specializedSiteAreaChild != null) {
								DocumentIdIterator docIt = specializedSiteAreaChild.getDirectChildren(Workspace.WORKFLOWSTATUS_PUBLISHED);
								if (docIt != null && docIt.hasNext()) {	
									while (docIt.hasNext()) {
										tmpDocId = docIt.next();
										if (tmpDocId.getType().isOfType(DocumentTypes.Content) && tmpDocId.getName().equalsIgnoreCase(genericName)) {
											content = (Content)EgovWCMCache.getWorkspace().getById(tmpDocId);
											if (content.isPublished()) {
												ArrayList arrList = new ArrayList();
												arrList.add(content);
												arrList.add(customName);
												arrList.add(extendGenericName);
												arrList.add(genericName);
												return arrList;	
											} else {
												Logger.log(Logger.ERROR_LEVEL, "ARUtils -> getAdmSpecializedLocalAdmTerritorialKindContent() | Content is NOT Published : " + content.getId().getId());
											}
										}
									}
								}
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
						return null;
					}
				}
				return null;
			}
		}
		return null;
	}
	
	public static String getAdmSpecializedLocalTitle(Content content, String administrativeStructureName, String customName) {
		if (
			"Baseynova direktsia".equalsIgnoreCase(content.getName()) ||
			"Gorska semekontrolna stantsia".equalsIgnoreCase(content.getName()) ||
			"Direktsia Natsionalen park".equalsIgnoreCase(content.getName()) ||
			"Direktsia priroden park".equalsIgnoreCase(content.getName()) ||
			"Столична регионална здравна инспекция".equalsIgnoreCase(administrativeStructureName)) {
			return administrativeStructureName;
		} 
		return content.getTitle() + " - " + customName;		
	}
	
	public static String formatCorrespondanceDataForRichText (CorrespondenceDataType correspondanceData) {
		String html = "";
//		SKIP FOR NOW.
//		if (correspondanceData.getWebSiteUrl() != null && correspondanceData.getWebSiteUrl().trim().length() > 0) {
//			String http = (correspondanceData.getWebSiteUrl().indexOf("http://") == -1 && correspondanceData.getWebSiteUrl().indexOf("https://") == -1) ? "http://" : "";
//			html += "<p>";
//			html += "Уеб сайт: <a href=\"" + http + correspondanceData.getWebSiteUrl() + "\" target=\"_blank\">" + correspondanceData.getWebSiteUrl() + "</a>";
//			html += "</p>";
//		}
		if (correspondanceData.getEmail() != null && correspondanceData.getEmail().trim().length() > 0) {
			html += "<p>";
			html += "Е-mail: <a href=\"mailto:" + correspondanceData.getEmail() + "\">" + correspondanceData.getEmail() + "</a>";
			html += "</p>";
		}		
		if (correspondanceData.getInterSettlementCallingCode() != null && correspondanceData.getInterSettlementCallingCode().trim().length() > 0) {
			html += "<p>";
			html += "Kод за междуселищно избиране: (" + correspondanceData.getInterSettlementCallingCode() + ")";
			html += "</p>";
		}
		if (correspondanceData.getPhone() != null && correspondanceData.getPhone().size() > 0) {
			html += "<p>";
			html += "Телефони: ";
			
			for (int i = 0; i < correspondanceData.getPhone().size(); i++) {				
				if (correspondanceData.getPhone().get(i).getPhoneNumber() != null && correspondanceData.getPhone().get(i).getPhoneNumber().trim().length() > 0) {
					if (i > 0) {
						html += ", ";
					}
					if (correspondanceData.getPhone().get(i).isIncludesSettlementCallCode()
						&& correspondanceData.getInterSettlementCallingCode() != null && correspondanceData.getInterSettlementCallingCode().trim().length() > 0) {
						html += "(" + correspondanceData.getInterSettlementCallingCode() + ") " + correspondanceData.getPhone().get(i).getPhoneNumber().trim();
					} else {
						html += correspondanceData.getPhone().get(i).getPhoneNumber().trim();
					}
				}										
			}
			html += "</p>";
		}
		if (correspondanceData.getFaxNumber() != null && correspondanceData.getFaxNumber().trim().length() > 0) {
			html += "<p>";
			html += "Факс: ";
			if (correspondanceData.isFaxIncludesSettlementCallCode() 
				&& correspondanceData.getInterSettlementCallingCode() != null && correspondanceData.getInterSettlementCallingCode().trim().length() > 0) {				
				html += "(" + correspondanceData.getInterSettlementCallingCode() + ") " + correspondanceData.getFaxNumber();
			} else {
				html += correspondanceData.getFaxNumber();
			}
			html += "</p>";
		}
		return html;
	}
	
	public static String formatWorkingTimeDataForRichText (WorkingTimeType workingTime) {
		String html = "";
		if (workingTime != null) {
			if (WorkingTimeTypeEnum.FLEXIBLE.value().equals(workingTime.getType().value())) {
				html += "<p>Гъвкаво работно време</p>";
			} else {
				html += "<p>Стандартно работно време</p>";
			}
			boolean hasStartTime = false;
			boolean hasEndTime = false;
			if (workingTime.getStartTime() != null && workingTime.getStartTime().trim().length() > 0) {
				html += "<p>";
				html += "От: " + (workingTime.getStartTime().trim().length() > 5 ? workingTime.getStartTime().substring(0, 5) : workingTime.getStartTime()) + " ч.";
				hasStartTime = true;
			}
			if (workingTime.getEndTime() != null && workingTime.getEndTime().trim().length() > 0) {
				if (!hasStartTime) {
					html += "<p>";
				}
				html += (hasStartTime ? " - " : "") + "До: " + (workingTime.getEndTime().trim().length() > 5 ? workingTime.getEndTime().substring(0, 5) : workingTime.getEndTime()) + " ч.";
				html += "</p>";
				hasEndTime = true;
			}
			if (hasStartTime && !hasEndTime) {
				html += "</p>";
			}
			if (workingTime.getDuration() != null) {
				html += "<p>";
				html += "Продължителност: ";
				html += (workingTime.getDuration().getHours() < 10) ? "0" + workingTime.getDuration().getHours() : workingTime.getDuration().getHours();
				html += ":";
				html += (workingTime.getDuration().getMinutes() < 10) ? "0" + workingTime.getDuration().getMinutes() : workingTime.getDuration().getMinutes();
				html += " ч.";
				html += "</p>";
			}
			if (workingTime.getDescription() != null) {
				html += "<p>";
				html += workingTime.getDescription();
				html += "</p>";
			}
		}
		return html;
	}
	
	public static String formatProcedureRulesDataForRichText (List<ActType> actTypes) {
		String html = "";
		ActBaseType act = null;
		ActChangeType actChangeType = null;
		for (int i = 0; i < actTypes.size(); i++) {
			if (i > 0) {
				html += "<br/>";
			}
			act = actTypes.get(i);
			if (act != null) {
				html += "<p>";
				html += act.getName();
				html += "<br/>";				
				//act.getGroupActName();
				//act.isIsPublishedSG();
				if (act.getStateGazetteNumber() != null) {
					html += "Обн. ДВ бр. " + act.getStateGazetteNumber().getNumber();
					html += " от " + act.getStateGazetteNumber().getYear() + " г. ";
				}										
				if (act.getActChange() != null && act.getActChange().size() > 0) {
					for (int j = 0; j < act.getActChange().size(); j++) {
						actChangeType = act.getActChange().get(j);
						if (actChangeType != null) {
							html += ", изм. ДВ бр. " + actChangeType.getStateGazetteNumber().getNumber();
							html += " от " + actChangeType.getStateGazetteNumber().getYear() + " г. ";
						}
					}
				}
				html += "</p>";
			}     
		}
		return html;
	}

	public static String formatRegulatoryActsDataForRichText (List<RegulatoryActLegalBasisType> regulatoryActs) {
		String html = "";
		if (regulatoryActs != null && regulatoryActs.size() > 0) {
			RegulatoryActLegalBasisType basisType = null;
    		RegulatoryActStructuredDataType dataType = null;
    		String line = "";
    		String data = "";
    		for (int i = 0; i < regulatoryActs.size(); i++) {
    			html += "<p>";
    			line = "";
    			basisType = regulatoryActs.get(i);
    			if (basisType.getStructuredData() != null && basisType.getStructuredData().size() > 0) {
    				for (int j = 0; j < basisType.getStructuredData().size(); j++) {
    					data = "";    					
    					dataType = basisType.getStructuredData().get(j);
    					if (dataType.getArticle() != null) {    						
    						data += "чл. " + dataType.getArticle(); 
    					}
    					if (dataType.getParagraph() != null) {
    						if (data.length() > 0) {
    							data += ", ";
    						}
    						data += "п. " + dataType.getParagraph(); 
    					}
    					if (dataType.getSubParagraph() != null) {
    						if (data.length() > 0) {
    							data += ", ";
    						}
    						data += "ал. " + dataType.getSubParagraph(); 
    					}
    					if (dataType.getLetter() != null) {
    						if (data.length() > 0) {
    							data += ", ";
    						}
    						data += "б. " + dataType.getLetter(); 
    					}
    					if (dataType.getPoint() != null) {
    						if (data.length() > 0) {
    							data += ", ";
    						}
    						data += "т. " + dataType.getPoint(); 
    					}
    					if (dataType.getText() != null) {
    						if (data.length() > 0) {
    							data += ", ";
    						}
    						data += dataType.getText(); 
    					}
    					line += ((j > 0) ? "; " : "") + data;
    				}
    			}
    			html += basisType.getRegulatoryActName() + (line.length() > 0 ? " - " + line : "");
    			html += "</p>";
			}
		}
		return html;
	}
	
	public static String formatmModelDocumentsDataForRichText (List<AdmServiceInfoDocumentType> documents) {
		String html = "";
		AdmServiceInfoDocumentType tmpAdmInfoDocumentType = null;
		for (int i = 0; i < documents.size(); i++) {
			tmpAdmInfoDocumentType = documents.get(i);
			if (tmpAdmInfoDocumentType != null) {
				html += "<p>";
				html += "<a href=\"" + tmpAdmInfoDocumentType.getDocumentDownloadUrl() +  "\" title=\"" + tmpAdmInfoDocumentType.getName().replaceAll("\"", "&quot;") + "\" target=\"_blank\">" + tmpAdmInfoDocumentType.getName() + "</a>";		
				html += "</p>";
			}
		}
		return html; 
	}
	
	public static String formatStagesDataForRichText (List<AdmServiceStageType> stages) {
		String html = "";
		AdmServiceStageType tmpAdmServiceStageType = null;
		AdmServiceInfoDocumentType tmpAdmServiceInfoDocumentType = null;
		for (int i = 0; i < stages.size(); i++) {
			tmpAdmServiceStageType = stages.get(i);
			if (tmpAdmServiceStageType != null) {
				if (i > 0) {
					html += "<p>&nbsp;</p>";
				}
				html += "<p>" + tmpAdmServiceStageType.getName() + "</p>";				
				if (tmpAdmServiceStageType.getDescription() != null && tmpAdmServiceStageType.getDescription().getContent() != null) {    
					for (int j = 0; j < tmpAdmServiceStageType.getDescription().getContent().size(); j++) {
						html += "<p>" + tmpAdmServiceStageType.getDescription().getContent().get(j) + "</p>"; 
					}
				}
				if (tmpAdmServiceStageType.getDocument() != null && tmpAdmServiceStageType.getDocument().size() > 0) {
					for (int j = 0; j < tmpAdmServiceStageType.getDocument().size(); j++) {
						tmpAdmServiceInfoDocumentType = tmpAdmServiceStageType.getDocument().get(j);
						if (tmpAdmServiceInfoDocumentType != null) {
							html += "<p>";
							html += "<a href=\"" + tmpAdmServiceInfoDocumentType.getDocumentDownloadUrl() +  "\" title=\"" + tmpAdmServiceInfoDocumentType.getName().replaceAll("\"", "&quot;") + "\" target=\"_blank\">" + tmpAdmServiceInfoDocumentType.getName() + "</a>";		
							html += "<p>";
						}
					}
				}
			}
		}
		return html; 
	}
	
	public static String formatPaymentInfoDataForRichText (PaymentInfoType paymentInfo) {
		String html = "";
		if (paymentInfo.getPaymentKind() == null) return html;
		if (EgovWCMCache.AR_SERVICE_PAYMENT_KIND_FREE.equalsIgnoreCase(paymentInfo.getPaymentKind().value())) {
			return "<p>Не се заплаща за услугата</p>";
		} else {
			int countPrices = 0; 
			if (paymentInfo.getNormalCost() != null) {
				countPrices++;
			}
			if (paymentInfo.getExpressCost() != null) {
				countPrices++;
			}
			if (paymentInfo.getFastCost() != null) {
				countPrices++;
			}
			html += "<p>";
			if (countPrices > 1 ) {
				html += "<strong>";
			}
			html += "За услугата се заплаща";
			if (EgovWCMCache.AR_SERVICE_PAYMENT_GENERATION_KIND_FIXED.equalsIgnoreCase(paymentInfo.getPaymentGenerationKind().value())) {
				html += " " + "фиксирана";				
			}
			if (EgovWCMCache.AR_SERVICE_PAYMENT_KIND_CHARGE.equalsIgnoreCase(paymentInfo.getPaymentKind().value())) {
				html += " " + "такса";
				if (countPrices == 1) {
					html += " " + "на стойност";
				} else { // In case we have more than 1 prices, we need to show them in a list.
					html += " в зависимост от вида:";
				}
			} else if (EgovWCMCache.AR_SERVICE_PAYMENT_KIND_PRICE.equalsIgnoreCase(paymentInfo.getPaymentKind().value())) {
				html += " " + "цена";
			}
			if (countPrices == 1) {
				if (paymentInfo.getNormalCost() != null) {
					html += " " + paymentInfo.getNormalCost().toString();
				} else if (paymentInfo.getExpressCost() != null) {
					html += " " + paymentInfo.getExpressCost().toString();
				} else if (paymentInfo.getFastCost() != null) {
					html += " " + paymentInfo.getFastCost().toString();
				}
				html += " " + "лв.";			
			} 
			if (countPrices > 1 ) {
				html += "</strong>";
			}
			html += "</p>";	
			if (countPrices > 1 ) {
				html += "<div class=\"adm-supply-unit-data-service-multiple-prices\">";
				if (paymentInfo.getNormalCost() != null) {
					html += "<p>За обикновена услуга " + paymentInfo.getNormalCost().toString() +  " лв.</p>";
				}
				if (paymentInfo.getExpressCost() != null) {
					html += "<p>За експресна услуга " + paymentInfo.getExpressCost().toString() +  " лв.</p>";
				}
				if (paymentInfo.getFastCost() != null) {
					html += "<p>За бърза услуга " + paymentInfo.getFastCost().toString() +  " лв.</p>";
				}
				html += "</div>";
			}
		} 
		if (paymentInfo.getExplanations() != null && paymentInfo.getExplanations().getContent() != null && paymentInfo.getExplanations().getContent().size() > 0) {
			html += "<p>";
			for (int i = 0; i < paymentInfo.getExplanations().getContent().size(); i++) {
				html += paymentInfo.getExplanations().getContent().get(i).toString();
			}
			html += "</p>";
		}
		return html; 
	}

	public static String formatAdministrativeSupplyUnitsDataForRichText (List<UnitContactType> servicingUnitContactData, ResourceBundle bundle) {
		String html = "";
		UnitContactType unitContactType = null;
		CorrespondenceDataPhoneType phoneType = null;
		// In AR they are rendered backwards, that's why we iterate by DESC order.
		for (int i = servicingUnitContactData.size() - 1; i >= 0; i--) {
			unitContactType = servicingUnitContactData.get(i);
			if (unitContactType != null) {
				if (i < servicingUnitContactData.size() - 1) {
					html += "<p>&nbsp;</p>";
				}
				html += "<div class=\"adm-supply-unit-data\">";
				html += "<div class=\"adm-supply-unit-data-name\">" + unitContactType.getName() + "</div>";
				html += "<div class=\"adm-supply-unit-data-content\">";
				// address.
				if (unitContactType.getAddress() != null) {
					html += "<div class=\"adm-supply-unit-data-row\">";
					html += "<span class=\"adm-supply-unit-data-row-label\" data-name=\"address\">" + bundle.getString("ar.adm.supply.unit.address") + ":</span> ";
					String address = "";
					if (unitContactType.getAddress().getEkatteAddress() != null) {
						if (unitContactType.getAddress().getEkatteAddress().getDistrictName() != null) {
							address += "обл. " + unitContactType.getAddress().getEkatteAddress().getDistrictName();
						}
						if (unitContactType.getAddress().getEkatteAddress().getMunicipalityName() != null) {
							if (address.length() > 0) {
								address += ", ";
							}
							address += "общ. " + unitContactType.getAddress().getEkatteAddress().getMunicipalityName();
						}
						if (unitContactType.getAddress().getEkatteAddress().getSettlementName() != null) {
							if (address.length() > 0) {
								address += ", ";
							}
							address += "гр. " + unitContactType.getAddress().getEkatteAddress().getSettlementName();
						}
						if (unitContactType.getAddress().getEkatteAddress().getAreaName() != null) {
							if (address.length() > 0) {
								address += ", ";
							}
							address += "р-н " + unitContactType.getAddress().getEkatteAddress().getAreaName();
						}
					}
					if (unitContactType.getAddress().getAddressText() != null) {
						if (address.length() > 0) {
							address += ", ";
						}
						address += unitContactType.getAddress().getAddressText();
					}
					if (unitContactType.getAddress().getPostCode() != null) {
						if (address.length() > 0) {
							address += ", ";
						}
						address += "п.к. " + unitContactType.getAddress().getPostCode();
					}
					html += address;
					html += "</div>";
				}
				
				if (unitContactType.getCorrespondenceData() != null) {
					// interSettlementCallingCode.
					if (unitContactType.getCorrespondenceData().getInterSettlementCallingCode() != null) {
						html += "<div class=\"adm-supply-unit-data-row\"><span class=\"adm-supply-unit-data-row-label\" data-name=\"interSettlementCallingCode\">" + bundle.getString("ar.adm.supply.unit.inter.settlement.calling.code") + ":</span> " + unitContactType.getCorrespondenceData().getInterSettlementCallingCode() + "</div>";
					}
					// phone(s).
					if (unitContactType.getCorrespondenceData().getPhone() != null && unitContactType.getCorrespondenceData().getPhone().size() > 0) {
						html += "<div class=\"adm-supply-unit-data-row\">";
						html += "<span class=\"adm-supply-unit-data-row-label\" data-name=\"phone\">" + bundle.getString("ar.adm.supply.unit.phone") + ":</span> ";
						for (int j = 0; j < unitContactType.getCorrespondenceData().getPhone().size(); j++) {
							phoneType = unitContactType.getCorrespondenceData().getPhone().get(j);
							if (phoneType != null) {
								if (j > 0) {
									html += ", ";
								}
								html += ((phoneType.isIncludesSettlementCallCode() && unitContactType.getCorrespondenceData().getInterSettlementCallingCode() != null) ? "(" + unitContactType.getCorrespondenceData().getInterSettlementCallingCode() + ")" : "") +  phoneType.getPhoneNumber();								
							}            									
						}
						html += "</div>";
					}
					// fax.
					if (unitContactType.getCorrespondenceData().getFaxNumber() != null) {
						html += "<div class=\"adm-supply-unit-data-row\"><span class=\"adm-supply-unit-data-row-label\" data-name=\"faxNumber\">" + bundle.getString("ar.adm.supply.unit.fax") + ":</span> " + ((phoneType != null && phoneType.isIncludesSettlementCallCode() && unitContactType.getCorrespondenceData().getInterSettlementCallingCode() != null) ? "(" + unitContactType.getCorrespondenceData().getInterSettlementCallingCode() + ")" : "") + unitContactType.getCorrespondenceData().getFaxNumber() + "</div>";
					}
					// email.
					if (unitContactType.getCorrespondenceData().getEmail() != null) {
						html += "<div class=\"adm-supply-unit-data-row\"><span class=\"adm-supply-unit-data-row-label\" data-name=\"email\">" + bundle.getString("ar.adm.supply.unit.email") + ":</span> " + unitContactType.getCorrespondenceData().getEmail() + "</div>";
					}
					// web site.
					if (unitContactType.getCorrespondenceData().getWebSiteUrl() != null) {
						String webSiteUrl = unitContactType.getCorrespondenceData().getWebSiteUrl();
						if (!(webSiteUrl.startsWith("http://") || webSiteUrl.startsWith("https://"))) {
							webSiteUrl = "http://" + webSiteUrl;
						}
						html += "<div class=\"adm-supply-unit-data-row\"><a href=\"" + webSiteUrl + "\" target=\"_blank\" data-name=\"webSiteUrl\">" + unitContactType.getCorrespondenceData().getWebSiteUrl() + "</a>";
					}
				}
				// working time.
				String workingTime = unitContactType.getWorkTime();
				if (workingTime != null) {
					// AR dummy fix.
					if (workingTime.indexOf("Гъвкаво,") != -1) {
						workingTime = workingTime.replaceFirst("Гъвкаво,", "Гъвкаво работно време,");
					} else if (workingTime.indexOf("Стандартно,") != -1) {
						workingTime = workingTime.replaceFirst("Стандартно,", "Стандартно работно време,");
					}
					workingTime = unitContactType.getWorkTime().replaceFirst("Гъвкаво,", "Гъвкаво работно време,");
					html += "<div class=\"adm-supply-unit-data-row\"><span class=\"adm-supply-unit-data-row-label\" data-name=\"workingTime\">" + bundle.getString("ar.adm.supply.unit.working.time") + ":</span> " + workingTime + "</div>";
				}
				
				// description.
				html += "</div>";
				// unit-data.
				html += "</div>";
			}
		}
		return html; 
	}

	public static String buildUrlArOrganigram (String admStructureKind, String batchId) {
		if (bg.government.iisda.ras.AdmStructureKindsEnum.COUNCIL_OF_MINISTERS_ADMINISTRATION.value().equalsIgnoreCase(admStructureKind)) {
			return EgovWCMCache.ADM_URL_ORGANIGRAM_PREFIX + EgovWCMCache.AR_URL_ORGANIGRAM_COUNCIL_OF_MINISTERS_ADMINISTRATION;
		} else if (bg.government.iisda.ras.AdmStructureKindsEnum.MINISTRY.value().equalsIgnoreCase(admStructureKind)) {
			return EgovWCMCache.ADM_URL_ORGANIGRAM_PREFIX + EgovWCMCache.AR_URL_ORGANIGRAM_MINISTRY + batchId;
		} else if (bg.government.iisda.ras.AdmStructureKindsEnum.STATE_AGENCY.value().equalsIgnoreCase(admStructureKind)) {
			return EgovWCMCache.ADM_URL_ORGANIGRAM_PREFIX + EgovWCMCache.AR_URL_ORGANIGRAM_STATE_AGENCY + batchId;
		} else if (bg.government.iisda.ras.AdmStructureKindsEnum.STATE_COMMISION_ADMINISTRION.value().equalsIgnoreCase(admStructureKind)) {
			return EgovWCMCache.ADM_URL_ORGANIGRAM_PREFIX + EgovWCMCache.AR_URL_ORGANIGRAM_STATE_COMMISION_ADMINISTRATION + batchId;
		} else if (bg.government.iisda.ras.AdmStructureKindsEnum.EXECUTIVE_AGENCY.value().equalsIgnoreCase(admStructureKind)) {
			return EgovWCMCache.ADM_URL_ORGANIGRAM_PREFIX + EgovWCMCache.AR_URL_ORGANIGRAM_EXECUTIVE_AGENCY + batchId;
		} else if (bg.government.iisda.ras.AdmStructureKindsEnum.EXECUTIVE_POWER_ADMINISTRATIVE_STRUCTURE.value().equalsIgnoreCase(admStructureKind)) {
			return EgovWCMCache.ADM_URL_ORGANIGRAM_PREFIX + EgovWCMCache.AR_URL_ORGANIGRAM_EXECUTIVE_POWER_ADMINISTRATIVE_STRUCTURE + batchId;
		} else if (bg.government.iisda.ras.AdmStructureKindsEnum.ACT_60_ADIMINISTRATIVE_STRUCTURE.value().equalsIgnoreCase(admStructureKind)) {
			return EgovWCMCache.ADM_URL_ORGANIGRAM_PREFIX + EgovWCMCache.AR_URL_ORGANIGRAM_ACT60_ADMINISTRATIVE_STRUCTURE + batchId;
		} else if (bg.government.iisda.ras.AdmStructureKindsEnum.REGIONAL_ADMINISRATION.value().equalsIgnoreCase(admStructureKind)) {
			return EgovWCMCache.ADM_URL_ORGANIGRAM_PREFIX + EgovWCMCache.AR_URL_ORGANIGRAM_REGIONAL_ADMINISTRATION + batchId;
		} else if (bg.government.iisda.ras.AdmStructureKindsEnum.MUNICIPAL_ADMINISTRATION.value().equalsIgnoreCase(admStructureKind)) {
			return EgovWCMCache.ADM_URL_ORGANIGRAM_PREFIX + EgovWCMCache.AR_URL_ORGANIGRAM_MUNICIPAL_ADMINISTRATION + batchId;
		} else if (bg.government.iisda.ras.AdmStructureKindsEnum.AREA_MUNICIPAL_ADMINISTRATION.value().equalsIgnoreCase(admStructureKind)) {
			return EgovWCMCache.ADM_URL_ORGANIGRAM_PREFIX + EgovWCMCache.AR_URL_ORGANIGRAM_AREA_MUNICIPAL_ADMINISTRATION + batchId;
		} else if (bg.government.iisda.ras.AdmStructureKindsEnum.SPECIALIZED_LOCAL_ADMINISTRATION.value().equalsIgnoreCase(admStructureKind)) {
			return EgovWCMCache.ADM_URL_ORGANIGRAM_PREFIX + EgovWCMCache.AR_URL_ORGANIGRAM_SPECIALIZED_LOCAL_ADMINISTRATION + batchId;
		}  
		return "";
	}
	
	@SuppressWarnings({ "rawtypes"})
	public static DocumentId getWCMAdmSectionNameCategoryBySectionName(String sectionName, ResourceBundle bundle) throws Exception {
		if (sectionName == null) return null;
		Taxonomy taxonomy = EgovWCMCache.getTaxonomyAdmSectionName();
		if (taxonomy == null) {
			throw new Exception(bundle.getString("wcm.cache.object.is.missing") + " [taxonomyAdmSectionName]!");
		}
		String categoryName = null;
		if (EgovWCMCache.AR_SERVICE_SECTION_NAME_CENTRAL_ADMINISTRATIONS.equalsIgnoreCase(sectionName)) {
			categoryName = EgovWCMCache.CATEGORY_ADM_SECTION_NAME_CENTRAL_ADMINISTRATIONS_NAME;
		} else if (EgovWCMCache.AR_SERVICE_SECTION_NAME_REGIONAL_ADMINISTRATIONS.equalsIgnoreCase(sectionName)) {
			categoryName = EgovWCMCache.CATEGORY_ADM_SECTION_NAME_REGIONAL_ADMINISTRATIONS_NAME;
		} else if (EgovWCMCache.AR_SERVICE_SECTION_NAME_MUNICIPAL_ADMINISTRATIONS.equalsIgnoreCase(sectionName)) {
			categoryName = EgovWCMCache.CATEGORY_ADM_SECTION_NAME_MUNICIPALITY_ADMINISTRATIONS_NAME;
		} else if (EgovWCMCache.AR_SERVICE_SECTION_NAME_SPECIALIZED_TERRITORIAL_ADMINISTRATIONS.equalsIgnoreCase(sectionName)) {
			categoryName = EgovWCMCache.CATEGORY_ADM_SECTION_NAME_SPECIALIZED_TERRITORIAL_ADMINISTRATIONS_NAME;
		} else if (EgovWCMCache.AR_SERVICE_SECTION_NAME_ALL_ADMINISTRATIONS.equalsIgnoreCase(sectionName)) {
			categoryName = EgovWCMCache.CATEGORY_ADM_SECTION_NAME_ALL_ADMINISTRATIONS_NAME;
		}
		
		if (categoryName == null) {
			throw new Exception(bundle.getString("wcm.cache.object.is.missing") + " [sectionName mapping not found for -> " + sectionName + "]!");
		}
				
		DocumentIdIterator dIt = taxonomy.getChildren();
		if (dIt != null) {
			DocumentId dId = null;
			while (dIt.hasNext()) { 
				dId = dIt.next();
				if (categoryName.equalsIgnoreCase(dId.getName())) {
					return dId;
				}
			}
		}
		
		throw new Exception(bundle.getString("wcm.cache.object.is.missing") + " [sectionName mapping not found for any category of taxonomy \"taxonomyAdmSectionName\"]!");
	}
	
	@SuppressWarnings({ "rawtypes"})
	public static DocumentId[] getWCMServiceApplicationMethodCategoriesFromAdmServiceInfoType(AdmServiceInfoType admServiceInfoType, ResourceBundle bundle) throws Exception {
		if (admServiceInfoType == null) return null;
		Taxonomy taxonomy = EgovWCMCache.getTaxonomyServiceApplicationMethods();
		if (taxonomy == null) {
			throw new Exception(bundle.getString("wcm.cache.object.is.missing") + " [taxonomyServiceApplicationMethodsEnum]!");
		}
		ArrayOfServiceApplicationMethodsEnum serviceApplicationMethodsArr = admServiceInfoType.getServiceApplicationMethods();
		if (serviceApplicationMethodsArr == null || serviceApplicationMethodsArr.getMethod() == null || serviceApplicationMethodsArr.getMethod().size() == 0) {
			throw new Exception(bundle.getString("ar.service.application.methods.are.empty"));
		}
		
		ArrayList<DocumentId> serviceApplicationMethodsCategories = new ArrayList<DocumentId>();
		HashMap<String, DocumentId> taxonomyServiceApplicationMethodByName = new HashMap<String, DocumentId>(); 
				
		DocumentIdIterator dIt = taxonomy.getChildren();
		if (dIt != null) {
			DocumentId dId = null;
			while (dIt.hasNext()) { 
				dId = dIt.next();
				taxonomyServiceApplicationMethodByName.put(dId.getName(), dId);
			}
		}
		
		Iterator<ServiceApplicationMethodsEnum> iterator = serviceApplicationMethodsArr.getMethod().iterator();
		DocumentId tmpDocId = null;
		String serviceApplicationMethod = null;
		while (iterator.hasNext()) {
			serviceApplicationMethod = iterator.next().value();
			tmpDocId = taxonomyServiceApplicationMethodByName.get(serviceApplicationMethod);
			if (tmpDocId == null) {
				throw new Exception(bundle.getString("wcm.missing.category.for.service.application.method" + " [" + serviceApplicationMethod + "]!"));
			}			
			serviceApplicationMethodsCategories.add(tmpDocId);		
		}		
		return (DocumentId[])serviceApplicationMethodsCategories.toArray(new DocumentId[serviceApplicationMethodsCategories.size()]);
	}

	@SuppressWarnings({ "rawtypes"})
	public static DocumentId[] getWCMPaymentMethodsCategoriesFromAdmServiceInfoType(AdmServiceInfoType admServiceInfoType) throws Exception {
		if (admServiceInfoType == null) return null;
		Taxonomy taxonomy = EgovWCMCache.getTaxonomyPaymentMethods();
		if (taxonomy == null) {
			throw new Exception("Неинициализиран кеш обект" + " [taxonomyPaymentMethods]!");
		}
		
		ArrayList<DocumentId> paymentMethodsCategories = new ArrayList<DocumentId>();
		HashMap<String, DocumentId> taxonomyPaymentMethodByName = new HashMap<String, DocumentId>(); 
				
		DocumentIdIterator dIt = taxonomy.getChildren();
		if (dIt != null) {
			DocumentId dId = null;
			while (dIt.hasNext()) { 
				dId = dIt.next();
				taxonomyPaymentMethodByName.put(dId.getName(), dId);
			}
		}
		
		Iterator<PaymentMethodsEnum> iterator = admServiceInfoType.getPaymentInfo().getPaymentMethods().iterator();
		DocumentId tmpDocId = null;
		String paymentMethod = null;
		while (iterator.hasNext()) {
			paymentMethod = iterator.next().value();
			tmpDocId = taxonomyPaymentMethodByName.get(paymentMethod);
			if (tmpDocId == null) {
				throw new Exception("Липсва категория за \"начини на плащане\"" + " [" + paymentMethod + "]!");
			}			
			paymentMethodsCategories.add(tmpDocId);		
		}		
		return (DocumentId[])paymentMethodsCategories.toArray(new DocumentId[paymentMethodsCategories.size()]);
	}
	
	
	public static boolean hasComponent(Content content, String elementName) {
		for (int i = 0; i < content.getComponentNames().length; i++) {
			if (content.getComponentNames()[i].equals(elementName))
				return true;
		}
		return false;
	}
	
	public static void clearOptionSelectionField(Content content, String componentName) throws Exception {
		if (hasComponent(content, componentName)) {
			OptionSelectionComponent component = (OptionSelectionComponent) content.getComponent(componentName);
			component.setCategorySelections(new DocumentId[0]);
			content.setComponent(componentName, component);
		}
	}
	
	@SuppressWarnings({ "rawtypes"})
	public static void populateOptionSelectionField(Content content, String componentName, DocumentId value) throws Exception {
		if (hasComponent(content, componentName)) {
			OptionSelectionComponent component = (OptionSelectionComponent) content.getComponent(componentName);
			component.setCategorySelections(new DocumentId[] {value});
			content.setComponent(componentName, component);
		}
	}
	
	@SuppressWarnings({ "rawtypes"})
	public static void populateOptionSelectionField(Content content, String componentName, DocumentId[] values) throws Exception {
		if (hasComponent(content, componentName)) {
			OptionSelectionComponent component = (OptionSelectionComponent) content.getComponent(componentName);
			component.setCategorySelections(values);
			content.setComponent(componentName, component);
		}
	}
	
	public static void populateLinkField(Content content, String componentName, String value) throws Exception {
		if (hasComponent(content, componentName)) {
			LinkComponent component = (LinkComponent) content.getComponent(componentName);
			component.setExternalReference(value);
			content.setComponent(componentName, component);
		}
	}
	
	public static void populateTextField(Content content, String componentName, String value) throws Exception {
		if (value == null) {
			value = "";
		}
		if (hasComponent(content, componentName)) {		
			ContentComponent contentComponent = content.getComponent(componentName);			
			if (contentComponent instanceof ShortTextComponent) {
				ShortTextComponent component = (ShortTextComponent)contentComponent; 
				component.setText(value);
				content.setComponent(componentName, component);
			} else if (contentComponent instanceof TextComponent) {
				TextComponent component = (TextComponent)contentComponent; 
				component.setText(value);
				content.setComponent(componentName, component);
			} else if (contentComponent instanceof RichTextComponent) {
				RichTextComponent component = (RichTextComponent)contentComponent; 
				component.setRichText(value);
				content.setComponent(componentName, component);
			}
		}
	}
	
	public static String getTextField(Content content, String componentName) throws Exception {
		if (hasComponent(content, componentName)) {		
			ContentComponent contentComponent = content.getComponent(componentName);			
			if (contentComponent instanceof ShortTextComponent) {
				ShortTextComponent component = (ShortTextComponent)contentComponent; 
				return component.getText();
			} else if (contentComponent instanceof TextComponent) {
				TextComponent component = (TextComponent)contentComponent; 
				return component.getText();
			} else if (contentComponent instanceof RichTextComponent) {
				RichTextComponent component = (RichTextComponent)contentComponent; 
				return component.getRichText();
			}
		}
		return null;
	}
	
	public static String getLinkField(Content content, String componentName) throws Exception {
		if (hasComponent(content, componentName)) {
			LinkComponent component = (LinkComponent) content.getComponent(componentName);
			return component.getURL();			
		}
		return "";
	}
	
	@SuppressWarnings({ "rawtypes"})
	public static DocumentId[] getOptionSelectionCategoriesField(Content content, String componentName) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "ARUtils -> getOptionSelectionCategoriesField(content," + componentName + ") start...");
		if (hasComponent(content, componentName)) {
			Logger.log(Logger.DEBUG_LEVEL, "ARUtils -> getOptionSelectionCategoriesField: component found!");
			OptionSelectionComponent component = (OptionSelectionComponent) content.getComponent(componentName);
			if (component.getCategorySelections() != null && component.getCategorySelections().length > 0) {
				Logger.log(Logger.DEBUG_LEVEL, "ARUtils -> getOptionSelectionCategoriesField: categories founded=" + component.getCategorySelections().length);
			} else {
				Logger.log(Logger.DEBUG_LEVEL, "ARUtils -> getOptionSelectionCategoriesField: NO categories founded!");
			}
			return component.getCategorySelections();						
		}
		return null;
	}

	
	public static synchronized void save(Workspace workspace, Document doc) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "ARUtils -> save(workspace," + doc.getName() + " " + doc.getTitle() + ") start...");
		String[] save = workspace.save(doc);
		String errors = "";
		for (String string : save) {
			Logger.log(Logger.ERROR_LEVEL, "WCM error after saving: " + string);
			if (errors.length() > 0) {
				errors += "; ";
			}
			errors += string;
		}
		if (errors.length() > 0) {
			throw new Exception(errors);
		}
		Logger.log(Logger.DEBUG_LEVEL, "ARUtils -> save(workspace," + doc.getName() + " " + doc.getTitle() + ") ...end");
	}
	
	public static String prepareApplicationForm(String link) {
		if (link != null && link.trim().length() > 0) {
			return "<a href=\"" + link + "\">Изтегли заявление</a>";
		}
		return link;
	}	
	
	// This method stops at parent of type "Site" (in our case is 'egov').
	@SuppressWarnings("unchecked")
	public static synchronized ArrayList<Document> getPath(DocumentId<Document> parentDocId, String top, String skip) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "ARUtils -> getPath(" + parentDocId.getName() + ") start...");
		ArrayList<Document> pathArr = new ArrayList<>(); 
		Document doc = null;	
		while (parentDocId != null) {
			Logger.log(Logger.DEBUG_LEVEL, "ARUtils -> parentDocId = " + parentDocId.getName());
			doc = (Document)EgovWCMCache.getWorkspace().getById(parentDocId, true);
			if (doc == null || !doc.getId().isOfType(DocumentTypes.SiteArea) || (top != null && doc.getName().equalsIgnoreCase(top))) break;
			// is "skip" parameter is passed, we skip this site area.
			if (skip == null || (skip != null && !doc.getName().equalsIgnoreCase(skip))) {
				pathArr.add(doc);					
			}
			parentDocId = ((SiteArea)doc).getParentId();					
		}
		Logger.log(Logger.DEBUG_LEVEL, "ARUtils -> getPath(" + parentDocId.getName() + ") end! [" + (pathArr.size()) + "]");
		return pathArr;
	}
	
	public static String getNewCategoryIdByOldCategoryIdMapping(String categoryId) {
		if ("6a43ac89-5411-4443-b62c-e83d0064048d".equalsIgnoreCase(categoryId)) {
			return "34408248-cbf0-4d5b-8b58-6089d22c0101";
		} else if ("6d7ce51a-456d-442c-88c2-9b127e7f97ca".equalsIgnoreCase(categoryId)) {
			return "a6a00431-3929-4678-b53a-52b3c2e8384e";
		} else if ("dbc315fd-1848-4b4a-9b05-50f4da477e4c".equalsIgnoreCase(categoryId)) {
			return "f4ed7de2-9102-4519-b392-31b12b3978ab";
		} else if ("f8b98d64-e7b6-4117-b3fc-0064f3f99b69".equalsIgnoreCase(categoryId)) {
			return "5eba0f4c-1d25-4ae5-8e6f-d92a725afcec";
		} else if ("52df13fb-e30a-425f-adf7-5efaaf13d94b".equalsIgnoreCase(categoryId)) {
			return "5421bd63-0ac3-49b1-9a2e-00624079bdec";
		} else if ("be7cd91b-3d64-4f55-b649-43c6fe2660f0".equalsIgnoreCase(categoryId)) {
			return "7a2ccceb-9db0-475b-87ef-d1298c47ccb0";
		} else if ("e157ffcc-8378-4059-9474-7a77e1fa4c93".equalsIgnoreCase(categoryId)) {
			return "be47aa85-6cee-409a-807e-1d645bf5cc83";
		} else if ("9673b384-d070-459d-a40b-f9ee37740549".equalsIgnoreCase(categoryId)) {
			return "ea53356d-84b7-412d-83cd-e13698912bdd";
		} else if ("01d935a1-70f8-46bd-b267-f8f25a5c3086".equalsIgnoreCase(categoryId)) {
			return "b7cda030-0fde-4b2f-8d9c-101c02e0a3bf";
		} else if ("31143f75-2f6e-4ef0-8c0b-b6205fe56d85".equalsIgnoreCase(categoryId)) {
			return "db5014e4-3b8d-4dd7-a9f9-8b386ec9e5a8";
		} else if ("10c9e05b-a50e-4642-8a3b-b6e556abd075".equalsIgnoreCase(categoryId)) {
			return "00083a46-85a5-46e9-8e53-c2e5f0c864ab";
		} else if ("902eecbd-0535-49a8-9e18-6a8309a6e248".equalsIgnoreCase(categoryId)) {
			return "703bfb79-b10b-41db-a3ae-73075ee48948";
		} else if ("4a75c799-cff4-4a0a-98b8-3bf95f16bff5".equalsIgnoreCase(categoryId)) {
			return "0e81e0d1-98a6-420b-84a4-f4dea6b87387";
			//citizen rights.
		} else if ("c6778349-156f-4391-9552-fb0468cee268".equalsIgnoreCase(categoryId)) {
			return "8c1b2b60-c15f-4fe5-9c1b-d2ab62f14955";
		} else if ("cfe3b767-f9ca-473e-b555-886ad39615e9".equalsIgnoreCase(categoryId)) {
			return "6143856f-e911-4365-a04c-3355a5696196";
		} else if ("8eca4d21-358f-422f-b6a8-6a9c99914098".equalsIgnoreCase(categoryId)) {
			return "2f5177dd-e9c0-4ab4-bb68-ab76db160dcd";
		} else if ("b39b939e-be91-4541-a4b2-0c1317af9069".equalsIgnoreCase(categoryId)) {
			return "144061f3-f840-49e8-9e12-010be7372591";
		} else if ("b0fdc2d0-a245-4d78-a989-aeba6e6a22f7".equalsIgnoreCase(categoryId)) {
			return "dac6cc67-c559-4de9-83cb-38fe15ae9064";
		} else if ("2ae4919a-3196-4b81-bba8-937d0719d3fe".equalsIgnoreCase(categoryId)) {
			return "6632b511-df83-4b28-a165-33a1588bdfdb";
			// citizen condition.
		} else if ("686fe77f-84dd-4751-bd0d-ff20efca98ab".equalsIgnoreCase(categoryId)) {
			return "1e90639b-3767-4bb8-b8a1-bab66ce9ee7f";
		} else if ("5bf156e1-5e4c-4d97-9746-c2b1297cb322".equalsIgnoreCase(categoryId)) {
			return "ebf554d7-eb8c-4931-83a3-e8b53dab60c1";
		} else if ("0efec56e-a7af-4f27-be03-7a2402f2f006".equalsIgnoreCase(categoryId)) {
			return "cbd192e0-7697-4dbf-9bd2-2a0ca6fc1d39";
		} else if ("fbb5059d-aa63-4e8c-a9be-a0a0d3eb7a88".equalsIgnoreCase(categoryId)) {
			return "be09fe08-2a66-4727-98a8-8d97438a0462";
		} else if ("e2a23337-6e33-4ade-aaa5-4a7eda92555a".equalsIgnoreCase(categoryId)) {
			return "6ae7dbc7-b867-45da-b063-c02218fc7f78";
		} else if ("f49da16c-1d4b-4fd8-9353-74ba51d2f7fc".equalsIgnoreCase(categoryId)) {
			return "6d8ef037-ae25-441a-9f01-d5978ceba005";
		} else if ("06f20889-f312-4dbc-8218-d9284513faaf".equalsIgnoreCase(categoryId)) {
			return "e4fca24f-9697-4877-a179-54db94753437";
			// taxes.
		} else if ("635bf540-c634-413e-8c31-faecaab83eed".equalsIgnoreCase(categoryId)) {
			return "b996d84f-8630-43a7-9c51-e93c03363f71";
		} else if ("c339e427-aca7-4aae-bf6f-62dc70da7d58".equalsIgnoreCase(categoryId)) {
			return "d76bd943-fe1c-4754-9c9d-0e51aa90f181";
		} else if ("709728f7-c4dd-476f-82e3-3e8e6827ff70".equalsIgnoreCase(categoryId)) {
			return "74402b45-4de1-4732-9eaa-91dfb5948703";
		} else if ("0b6ab274-5bb4-456b-9025-0411253456db".equalsIgnoreCase(categoryId)) {
			return "367109bf-3655-4694-932c-a966871a0ba9";
			// ecology.
		} else if ("06b0bae9-e1cc-4176-93dc-ef5dec06a454".equalsIgnoreCase(categoryId)) {
			return "269e09d1-5e60-400d-b874-42625d1519be";
		} else if ("96da2a31-42c5-4b16-b90d-239baaf80e91".equalsIgnoreCase(categoryId)) {
			return "d5462cbf-fb05-4c69-9dc9-8f4f41e4d2ac";
		} else if ("ce65c153-da19-4276-9cbb-ada884ce039c".equalsIgnoreCase(categoryId)) {
			return "efe4a6c2-0d9d-49d4-94bc-fc562e35b95d";
		} else if ("58be3a49-ce49-437a-899a-eb90b8f10d7c".equalsIgnoreCase(categoryId)) {
			return "80c04146-6fad-483a-9182-d2215e19c198";
		} else if ("30f17b3b-900e-4bce-96e6-ab9ef7a5548f".equalsIgnoreCase(categoryId)) {
			return "b5701f32-86c6-4d6d-ae20-33b66b44b6e8";
		} else if ("f5801cb8-96b1-4899-aa08-e42c2b1f93c9".equalsIgnoreCase(categoryId)) {
			return "73be9788-e262-486d-8681-eb3eb297509f";
			// health insurance.
		} else if ("5ddc9b60-ce5e-4c40-b5ee-e690580445ef".equalsIgnoreCase(categoryId)) {
			return "fd5c8847-c90a-4e55-9f46-d6f721349beb";
		} else if ("ab153c20-5ab4-4142-b6d1-fec7c6ca58c3".equalsIgnoreCase(categoryId)) {
			return "cfaf0078-26d2-4301-a614-5d15d982963b";
			// real estates.
		} else if ("cdf4f1ec-1428-40f1-8545-84e6a8397d81".equalsIgnoreCase(categoryId)) {
			return "b22002fd-70ee-4955-ae2e-9ab57ce88979";
		} else if ("d033dae0-f5a3-4052-b7ed-e0adf7037a76".equalsIgnoreCase(categoryId)) {
			return "b786f1ee-583b-4ff2-a1e8-2b5352fc82b7";
		} else if ("da8f5e49-5a6d-4ecb-9d0c-8843210cb36d".equalsIgnoreCase(categoryId)) {
			return "cba53fee-f949-4475-8012-ba647c9089f0";
		} else if ("32aaedc6-a734-45b7-a057-829592d12c1f".equalsIgnoreCase(categoryId)) {
			return "5d00f95b-ccff-4028-8bef-1a16fb9bbe7d";
		} else if ("e6a7ba4e-1ad6-4633-ae47-834c7205001a".equalsIgnoreCase(categoryId)) {
			return "a8d5cfce-e8a9-4e08-a002-13d583bb7c2d";
		} else if ("f3189d84-da61-4a43-a805-f8808aee6e87".equalsIgnoreCase(categoryId)) {
			return "28a17f93-1c43-4815-bc14-cfdd9111f6e1";
		} else if ("f252ea4d-e769-409e-b59c-3e0791b2682d".equalsIgnoreCase(categoryId)) {
			return "2fd54f60-e41a-45a6-ba5b-671393cea34b";
		} else if ("bc3fee29-c6d9-4a0e-925d-2581f43b0886".equalsIgnoreCase(categoryId)) {
			return "5ed3e301-47d6-4387-a65b-b7be9d581748";
			// education.
		} else if ("9eb0b232-8e88-4da6-be7b-701bb9d4fafd".equalsIgnoreCase(categoryId)) {
			return "90e7be7a-ab54-4d11-8790-e3c1bd74f1b4";
		} else if ("6772455b-0a44-4024-a2ff-baac3b276713".equalsIgnoreCase(categoryId)) {
			return "f8430d84-aa24-4528-be98-3220635ae366";
		} else if ("2f303b1a-e943-469d-86ab-d1d2e4ccac79".equalsIgnoreCase(categoryId)) {
			return "0c9bf14f-04b5-4fc0-917c-2dd434c6c9ac";
		} else if ("4d2ddd91-e72c-4641-8485-54066c1ae196".equalsIgnoreCase(categoryId)) {
			return "7a69c200-ba26-43e4-aeea-23f59c0f6dbb";
		} else if ("3ade36e2-17f3-4f45-a27b-3e3a4d9735ca".equalsIgnoreCase(categoryId)) {
			return "c8a686ec-22fc-439b-8107-e966410a2741";
			// work and social activities.
		} else if ("51dcff1b-a513-4ab8-90ab-c6f461157155".equalsIgnoreCase(categoryId)) {
			return "6d7af6da-3bd1-4517-957f-756d17c7c0a6";
		} else if ("28a80310-78e3-4f90-ac1b-ea68bbac3566".equalsIgnoreCase(categoryId)) {
			return "75b68d36-3ec1-4250-999d-5ba244364dea";
		} else if ("6bac5bcc-ca83-476d-b46c-973f9de6d46a".equalsIgnoreCase(categoryId)) {
			return "e18a279e-7341-40c3-8e6d-ca60c3b34cf4";
		} else if ("16807fef-ce49-44b3-9894-6194d3e2d98e".equalsIgnoreCase(categoryId)) {
			return "dd7a9c5b-a9f2-41b7-b278-d59e7b78b2b8";
		} else if ("5de59e01-22d7-457f-a169-688b3bde4398".equalsIgnoreCase(categoryId)) {
			return "e6152035-015c-443e-8059-87552971cf0c";
		} else if ("1b9672c7-0eaf-449b-8027-ad23e70f47fb".equalsIgnoreCase(categoryId)) {
			return "a52ac03f-19fa-411b-9e36-5fe996444a2d";
			// agriculture and woods
		} else if ("8dd31aa8-2a95-48d9-ab47-bb889bd7d5e0".equalsIgnoreCase(categoryId)) {
			return "69847e82-4683-4d00-8f56-0fe254788039";
		} else if ("43d17d32-8df0-4d58-83e3-6d360d11ebe3".equalsIgnoreCase(categoryId)) {
			return "8eca300b-8bab-4886-89c0-b8f8ec6e6162";
		} else if ("6d568b8c-1cd8-4c5e-961a-d92dd1407d76".equalsIgnoreCase(categoryId)) {
			return "e54fc81c-a166-4e9f-8d9d-2529eabcef0a";
		} else if ("fe246e6c-05b7-4da9-b878-c855280171c5".equalsIgnoreCase(categoryId)) {
			return "b2ea7927-b897-4444-9a34-e5266787d631";
		} else if ("05c3d6f1-e760-4c1a-8746-f266a64ac61b".equalsIgnoreCase(categoryId)) {
			return "18c08977-9e3c-426f-8cdd-13c0ecd00b10";
		} else if ("9977dfc7-0706-40d8-af95-b8bcc9b7465e".equalsIgnoreCase(categoryId)) {
			return "f8d49adf-791b-4df5-b1fd-e289a5c8a984";
		} else if ("75a756e3-0487-4173-a9fc-f71e6c586c34".equalsIgnoreCase(categoryId)) {
			return "53ff2883-e3ed-4b78-b4e9-3691cfa24442";
		} else if ("7dc484ea-978b-4da6-82a2-8b472bc2c70e".equalsIgnoreCase(categoryId)) {
			return "2e8865bd-3029-4e6d-8dd0-28546b048fcf";
		} else if ("a8643a1d-2a5c-456f-8f57-96c27d6968b7".equalsIgnoreCase(categoryId)) {
			return "3810764e-9410-46a4-a30b-83bf926a2f01";
			// transport.
		} else if ("13ffbf16-a1f4-4547-99c6-73c8d83d21dc".equalsIgnoreCase(categoryId)) {
			return "cc34c2ac-e0a7-462d-8cc8-a7d4babf65c4";
		} else if ("17c86567-056c-426b-ab08-a00983911053".equalsIgnoreCase(categoryId)) {
			return "0f3bc5f6-6cc2-43f1-aa39-fcb6ccf2c6a0";
		} else if ("94d52a29-9ff1-4e8f-9249-b909fed13407".equalsIgnoreCase(categoryId)) {
			return "c7643672-eeff-4554-80b2-f3d934fbf456";
		} else if ("dbcd355a-04cd-47f1-9fc7-8c7b8a1406df".equalsIgnoreCase(categoryId)) {
			return "4c062266-eb66-46e3-9559-8017db93544c";
		} else if ("074c6ea4-8dc3-4e1f-b708-267db1e811c8".equalsIgnoreCase(categoryId)) {
			return "ce88be42-6343-4b21-bf94-42d4038be3c3";
			// cadaster.
		} else if ("3ff57a1d-8ba4-4e15-afb9-373724b7e4c5".equalsIgnoreCase(categoryId)) {
			return "7bd8cda8-2cb0-4538-be7f-6e4bc79964c8";
		} else if ("8444104d-4054-43f0-b0d9-6abcf1300335".equalsIgnoreCase(categoryId)) {
			return "93182576-7a37-4ef2-9377-9b50625e1a1f";
		} else if ("3dba9c19-362d-4c4b-b3a6-bd58dd6039fd".equalsIgnoreCase(categoryId)) {
			return "2baf509b-aab5-4f07-908b-41aebb283fdf";
		} else if ("135ea7d8-0895-4cb2-a42d-819bc797bc36".equalsIgnoreCase(categoryId)) {
			return "86c35d2a-5b20-415e-b5b8-c4659c206fdc";
		} else if ("42955c67-49d2-42c7-bfc0-d3ab3a674c68".equalsIgnoreCase(categoryId)) {
			return "31f58805-7247-4d86-9dd1-0d7707629fe6";
		} else if ("972635bb-4717-4402-b87e-b6ed38192a52".equalsIgnoreCase(categoryId)) {
			return "145b1f12-757e-4509-b735-e6aac7c0a977";
		} else if ("71126825-cd5a-4eda-ac13-ffe0b3ff8c67".equalsIgnoreCase(categoryId)) {
			return "3e50b2be-7ce8-4784-ba17-4007f6c08b2f";
		} else if ("35dc52e0-a5fa-4bdd-b6c9-de65325be680".equalsIgnoreCase(categoryId)) {
			return "d514feaa-c026-4c98-b764-0a49fe51b3e8";
		}
		return null;
	}
	
	public static String clearRichTextFormatting(String html) {
		if (html == null) return html;
		html = html.replace("font-size:9.0pt;", "");
		html = html.replace("font-size: 11px;", "");
		html = html.replace("font-size: 12px;", "");
		html = html.replace("font-size: 13px;", "");
		html = html.replace("font-size: 14px;", "");
		html = html.replace("font-size: 15px;", "");
		html = html.replace("font-size: 16px;", "");
		html = html.replace("font-size: 17px;", "");
		html = html.replace("font-size: 18px;", "");
		html = html.replace("font-weight: 300;", "");
		html = html.replace("font-weight: 400;", "");
		html = html.replace("font-weight: 500;", "");
		html = html.replace("font-weight: 600;", "");
		html = html.replace("font-weight: 700;", "");
		html = html.replace("font-weight: 800;", "");
		html = html.replace("font-family: &amp;quot;Roboto&amp;quot;,sans-serif;", "");
		html = html.replace("font-family:&quot;Arial&quot;,sans-serif;", "");
		html = html.replace("font-family: Arial,Verdana,sans-serif;", "");
		html = html.replace("font-family: Roboto,sans-serif;", "");
		return html;
	}
	
	public static long date_TimestampToTimeMillis(final String s) {
		if (s != null) {
			try {
				return dateTimeFormat.parse(s).getTime();
			} catch (final Exception e) {
			}
		}
		return 0;
	}

	public static String timeMillisToTimestamp(final String millis) {
		try {
			final long l = Long.parseLong(millis);
			return dateTimeFormat.format(new Date(l));
		} catch (final Exception e) {
			System.out.println("Utils : timeMillisToTimestamp : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static String timeMillisToTimestamp(final long millis) {
		try {

			return dateTimeFormat.format(new Date(millis));
		} catch (final Exception e) {
			System.out.println("Utils : timeMillisToTimestamp : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static String timeMillisToYYYY_MM_DD_HH_MM_SS(final String timeMillis) {
		try {
			final Date date = new Date(Long.parseLong(timeMillis));
			return dateTimeFormat.format(date);
		} catch (Exception e) {
			System.out.println("Utils : timeMillisToYYYY_MM_DD_HH_MM_SS : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static String timeMillisToYYYY_MM_DD_HH_MM_SS(final long timeMillis) {
		try {
			final Date date = new Date(timeMillis);
			return dateTimeFormat.format(date);
		} catch (Exception e) {
			System.out.println("Utils : timeMillisToYYYY_MM_DD_HH_MM_SS : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static String timeMillisToYYYY_MM_DD(final String timeMillis) {
		try {
			final Date date = new Date(Long.parseLong(timeMillis));
			return dateTimeFormat_yyyy_MM_dd.format(date);
		} catch (Exception e) {
			System.out.println("Utils : timeMillisToYYYY_MM_DD : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static String timeMillisToYYYY_MM_DD(final long timeMillis) {
		try {
			final Date date = new Date(timeMillis);
			return dateTimeFormat_yyyy_MM_dd.format(date);
		} catch (Exception e) {
			System.out.println("Utils : timeMillisToYYYY_MM_DD : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static synchronized long date_yyyy_MM_dd_ToTimeMillis(String date, boolean beginDay) {
		try {
			StringTokenizer st = new StringTokenizer(date, "-");
			if (st.countTokens() != 3)
				return 0;
			int year = Integer.parseInt(st.nextToken());
			int month = Integer.parseInt(st.nextToken());
			int day = Integer.parseInt(st.nextToken());
			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.DAY_OF_MONTH, day);
			cal.set(Calendar.MONTH, month - 1);
			cal.set(Calendar.YEAR, year);

			if (beginDay) {
				cal.set(Calendar.HOUR_OF_DAY, 0);
				cal.set(Calendar.MINUTE, 0);
				cal.set(Calendar.SECOND, 0);
				cal.set(Calendar.MILLISECOND, 0);
			} else {
				cal.set(Calendar.HOUR_OF_DAY, 23);
				cal.set(Calendar.MINUTE, 59);
				cal.set(Calendar.SECOND, 59);
				cal.set(Calendar.MILLISECOND, 999);
			}
			return cal.getTime().getTime();
		} catch (NumberFormatException e) {
			e.printStackTrace();
			System.out.println("Utils : date_yyyy_MM_dd_ToTimeMillis : " + e.getMessage());
		}
		return 0;
	}
	
	public static String getCurrentDate(String format) {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern(format != null ? format : "dd.MM.yyyy");
		LocalDate localDate = LocalDate.now();
		return dtf.format(localDate); //16.11.2016
	}
	
	public static int getCurrentHour() {
		return LocalDateTime.now().getHour();	
	}

	public static int getCurrentPageNumber(int total, int currentPage, int resultsPerPage) {
		if (total > 0 && resultsPerPage > 0) {
			int totalPages = getTotalPages(total, resultsPerPage);
			if (totalPages < currentPage) {
				currentPage = totalPages;
			}
			return currentPage;
		}
		return 1;
	}
	
	public static String getConfigValueFromFile(String filePath, String configParamName) {
		Scanner scanner = null;
		try {
			scanner = new Scanner(new File(filePath));
			if (scanner.hasNext()) {
				String line = null;
				String[] paramValues = null;
				while(scanner.hasNext()) {
					line = scanner.nextLine();
					if (line != null && line.trim().length() > 0) {
						if (line.indexOf(configParamName) != -1) {
							paramValues = line.split("=");
							if (paramValues != null && paramValues.length == 2) {								
								return paramValues[1].trim();
							}
						}
					}					
				}				
			}			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				if (scanner != null) {
					scanner.close();
				}
			} catch (Exception e) {}
		}		
		return null;
	}
	
	public static String setValueToConfigFile(String filePath, String configParamName, String value) {
		Scanner scanner = null;
		boolean found = false;
		StringBuffer inputBuffer = null;
		try {
			scanner = new Scanner(new File(filePath));
			if (scanner.hasNext()) {
				String line = null;
				inputBuffer = new StringBuffer();
				while(scanner.hasNext()) {
					line = scanner.nextLine();
					if (line != null && line.trim().length() > 0) {
						if (line.indexOf(configParamName) != -1) {
							line = configParamName + "=" + value;	
							found = true;
						}
						inputBuffer.append(line);
			            inputBuffer.append('\n');
					}					
				}
				if (!found) {
					inputBuffer.append(configParamName + "=" + value);
		            inputBuffer.append('\n');					
				}
			}			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				if (scanner != null) {
					scanner.close();
				}
			} catch (Exception e) {}
	    }		
		if (inputBuffer != null) {
			FileOutputStream fileOut = null;
			// write the new string with the replaced line OVER the same file
	        try {
				fileOut = new FileOutputStream(filePath);
				fileOut.write(inputBuffer.toString().getBytes());
				fileOut.close();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (fileOut != null) {
						fileOut.close();
					}
				} catch (Exception e) {}
		    }
		}
		return null;
	}
	
	public static void main(String[] args) {
		System.out.println(getCurrentHour());
	}

	public static int getTotalPages(int total, int resultsPerPage) {
		if (total > 0 && resultsPerPage > 0) {
			try {
				return (int) Math.ceil((double) total / (double) resultsPerPage);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return 1;
	}
	
	public static String escapeStringForDB(String text) {
		String tmp = text.replaceAll("\\\\", "\\\\\\\\\\\\\\\\");
		return tmp.replaceAll("'", "\\\\'");
	}
}
