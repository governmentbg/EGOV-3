package com.ibs.gateway.utils;

import com.ibs.gateway.ARConstants;
import com.ibs.gateway.ARGatewayPortlet;
import com.ibs.gateway.db.Base;

public class Logger extends Base {

    public final static int ERROR_LEVEL = 0;
    public final static int WARNING_LEVEL = 1;
    public final static int DEBUG_LEVEL = 2;

    public synchronized static void log(String logMessage) {
        System.err.println(logMessage);
    }

    public synchronized static void log(int logLevel, String logMessage) {
        String message = ARConstants._PRODUCT_NAME + " " + ARConstants._PRODUCT_VERSION + " | ";

        if ((logLevel <= _LOGLEVEL || (ARGatewayPortlet.debug && logLevel == DEBUG_LEVEL)) && _LOGON) {
        	message += logMessage;
            System.err.println(message);
        }
    }
}
