package com.ibs.gateway;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.ibs.gateway.db.DBPool;
import com.ibs.gateway.db.DBResources;
import com.ibs.gateway.utils.Logger;

@WebListener
public class InitializeListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        ServletContext servletContext = sce.getServletContext();
        String realPath = servletContext.getRealPath("/");

        System.out.println(ARConstants._PRODUCT_NAME + " " + ARConstants._PRODUCT_VERSION + " | APPLICATION IS UP!");
        if (DBResources.init(realPath)) {
        	ARStructuresLoader.init(realPath);
        	ARServicesLoader.init(realPath);
        	ARCronJobsLoader.init(realPath);
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        Logger.log(Logger.DEBUG_LEVEL, "STOPPING ALL THREADS");        
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        ARCronJobsLoader.shutdown();                      
        try {
        	Thread.sleep(1000);
        } catch (Exception e) {
        	e.printStackTrace();
        }
        ARStructuresLoader.shutdown();                      
        try {
        	Thread.sleep(1000);
        } catch (Exception e) {
        	e.printStackTrace();
        }
        ARServicesLoader.shutdown();                      
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Logger.log(Logger.DEBUG_LEVEL, "SHUT DOWN DATASOURCE...");
        DBPool.shutdownDataSource();
        Logger.log(Logger.DEBUG_LEVEL, "STOP FINISHED");
    }

}