package com.ibs.gateway;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.xml.ws.Service;

import com.ibs.gateway.db.Base;
import com.ibs.gateway.dbo.ARAdministrativeService;
import com.ibs.gateway.management.ARServiceManagement;
import com.ibs.gateway.utils.ARUtils;
import com.ibs.gateway.utils.Logger;
import com.ibs.gateway.utils.MD5Digest;

import bg.government.iisda.admservices.AdmServiceBatchDataType;
import bg.government.iisda.admservices.AdmServiceBatchesType;
import bg.government.iisda.admservices.AdmServiceInfoDocumentType;
import bg.government.iisda.admservices.AdmServiceInfoType;
import bg.government.iisda.admservices.AdmServiceMainDataType;
import bg.government.iisda.admservices.AdmServiceStageType;
import bg.government.iisda.admservices.ArrayOfServiceApplicationMethodsEnum;
import bg.government.iisda.admservices.PaymentMethodsEnum;
import bg.government.iisda.admservices.RegulatoryActLegalBasisType;
import bg.government.iisda.admservices.RegulatoryActStructuredDataType;
import bg.government.iisda.admservices.ServiceApplicationMethodsEnum;
import bg.government.iisda.admservices.UnitContactType;
import bg.government.iisda.admservices.common.CorrespondenceDataPhoneType;
import bg.government.iisda.admservices.integrationservices.ArrayOfAdmServiceBatchDataType;
import bg.government.iisda.admservices.integrationservices.ArrayOfAdmServiceMainDataType;
import bg.government.iisda.admservices.integrationservices.IAdmServicesService;

public class ARServicesLoader {

	private static int sleepTime = 1 * 60 * 60 * 1000; // 1 hour
//	private static int sleepTime = 5 * 1000; // 5 seconds.
	private static boolean enableARServicesLoaderThread = false;
	private static boolean startARServicesLoaderThread = true;
	public static boolean isRunning = false;
	public static boolean initialized = false;
	private static ARServicesLoaderThread arServicesLoaderThread = null;
	private static IAdmServicesService port = null;
	private static String lastProcessedDate = null;	
	private static final String ADM_SERVICES_ADDRESS = "https://iisda.government.bg/Services/AdmServices/AdministrativeServices.IntegrationServices/AdmServicesService/AdmServicesService.svc?wsdl=wsdl0";

	public ARServicesLoader() {
	}

	public static synchronized int load(String currentUserDN) {
		Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() -> START!");
		
		if (ARServicesLoader.isRunning) {
			Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() -> isRunning = TRUE, exiting...-1");
			return -1;
		}
		
		Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() -> set isRunning to TRUE!");
		ARServicesLoader.isRunning = true;
		lastProcessedDate = ARUtils.getCurrentDate(null);
		if (currentUserDN == null || currentUserDN.trim().length() == 0) {
			currentUserDN = ARConstants.SYSTEM_USER_DN;
		}
						
		ARServiceManagement management = new ARServiceManagement();
		Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: loadAllAdministrativeServices started...");
		// Load all administrative services from our custom DB.
		ARAdministrativeService[] administrativeServices = management.loadAllAdministrativeServices(null, null, null, null, null, null);
		Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: loadAllAdministrativeServices finished!");
		// Put loaded administrative services by serviceNumber in the HashMap. 
		Map<String, ARAdministrativeService> admServicesHm = new HashMap<String, ARAdministrativeService>();
		// Store array of loaded serviceNumbers.
		List<String> loadedServiceNumbers = new ArrayList<String>();
		if (administrativeServices != null && administrativeServices.length > 0) {
			Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() -> administrativeServices.length=" + administrativeServices.length);
			for (int i = 0; i < administrativeServices.length; i++) {
				admServicesHm.put(administrativeServices[i].getServiceNumber().toString(), administrativeServices[i]);
				loadedServiceNumbers.add(administrativeServices[i].getServiceNumber().toString());
			}
		} else {
			Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() -> administrativeServices.length=0");
		}
		
		ArrayOfAdmServiceMainDataType result = null;
		
		try {
			// Call service to load ALL main data services.
			Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() -> Before call searchAdmServiceMainData -> " + ARUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(System.currentTimeMillis()));
			result = port.searchAdmServiceMainData(null, null);
			Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() -> After call searchAdmServiceMainData -> " + ARUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(System.currentTimeMillis()));
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "--- ARServicesLoader: load() -> port.searchAdmServiceMainData: " + e.getMessage());
			System.out.println(e.getMessage());
			e.printStackTrace();
			ARServicesLoader.isRunning = false;
			Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() -> set isRunning to FALSE, exiting...-2!");
			return -2;
		}

		// Calculated hash from all used fields.
		String hash = null;
		// State with change, if any.
		String state = null;
		// AdmServiceMainDataType.
		AdmServiceMainDataType admServiceMainDataType = null;
		// AdmServiceBatchDataType
		AdmServiceBatchDataType admServiceBatchDataType = null;
		// admService.
		ARAdministrativeService admService = null;
		// Put loaded admServiceBatchDataType info by serviceNumber in the HashMap, 		
		Map<String, AdmServiceBatchDataType> admServiceBatchDataTypeHm = new HashMap<String, AdmServiceBatchDataType>();
		int arNew = 0;
		int arUpdated = 0;
		int arStatusChanged = 0;
		int arNotFound = 0;
		
		if (result != null && result.getAdmServiceMainDataType() != null && result.getAdmServiceMainDataType().size() > 0) {
			Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() -> port.searchAdmServiceMainData: TOTAL -> " + result.getAdmServiceMainDataType().size());					
			
			// We need this call, until AR service add support to pass "lastUpdatedTime" field, 
			// to be used as compare flag for Services in AR.
			Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() -> Before call loadAdmServiceBatchDataType -> " + ARUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(System.currentTimeMillis()));
			// This function returns ArrayList with two values: 0 -> Map admServiceBatchDataTypeHm, 1 -> ArraList with invalid batchIdentNumbers.
			try {
				admServiceBatchDataTypeHm = loadAdmServiceBatchDataType(result.getAdmServiceMainDataType());
			} catch (Exception e) {
				e.printStackTrace();
				return -2;
			}
			
			int j = 0;
			for (int i = 0; i < result.getAdmServiceMainDataType().size(); i++) {
				admServiceMainDataType = result.getAdmServiceMainDataType().get(i);
				//if (2865 != admServiceMainDataType.getServiceNumber()) continue;
				//Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() -> 2865!!!");
//				printAdmServiceMainDataType(admServiceMainDataType, 0);
				state = null;	
				admServiceBatchDataType = admServiceBatchDataTypeHm.get(admServiceMainDataType.getServiceNumber() + "");
				if (admServiceBatchDataType == null) {
					Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() -> Service [" + admServiceMainDataType.getServiceNumber() + "] has no admServiceBatchDataType, we will use mainData only!");
				}
				hash = calculateHash(admServiceMainDataType, admServiceBatchDataType);
				admService = admServicesHm.get(admServiceMainDataType.getServiceNumber() + "");
				if (admService == null) {
					// No records found in our DB for current Administrative Service, so set the state to 'NEW'. 
					state = ARConstants.ADMINISTRATIVE_SERVICE_STATE_IS_NEW;						
				} else if (admService != null) {						 
					// If Administrative Service is not marked as "BLOCKED" from DAEU Administrator 
					// & hash change was found, 
					// we update the hash and set the state to 'UPDATE'.
					
					// When AR service add support for lastUpdateTime, we will use it instead of the "hash" we build now.
					if (!ARConstants.ADMINISTRATIVE_SERVICE_BLOCKED.equals(admService.getBlocked()) 
							&& !hash.equals(admService.getHash())) {
						state = ARConstants.ADMINISTRATIVE_SERVICE_STATE_IS_UPDATE;							
					} else if (ARConstants.ADMINISTRATIVE_SERVICE_STATE_IS_UPDATE.equalsIgnoreCase(admService.getState())
							&& hash.equals(admService.getHash())) {
						Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() [hash match 100%] -> current state is \"UPDATE\", new state will be \"PROCESSED\"");
						// Hash match, but state is update -> reset state to PROCESSED.
						management.updateAdministrativeServiceState(admService, ARConstants.ADMINISTRATIVE_SERVICE_STATE_PROCESSED, hash, currentUserDN);
					}
					// This one was processed, so remove it.
					loadedServiceNumbers.remove(admService.getServiceNumber().toString());
				}	
				Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() -> state = " + state);
				if (state != null) {
					if (ARConstants.ADMINISTRATIVE_SERVICE_STATE_IS_NEW.equals(state)) {	
						Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() -> adding: " + (admServiceMainDataType.getBatchID() != null ? admServiceMainDataType.getBatchID() : "NO_BATCH_ID") + " [" + admServiceMainDataType.getServiceNumber() + "]");
						management.createAdministrativeService(admServiceMainDataType, admServiceBatchDataType, state, hash, currentUserDN);
						arNew++;
					} else {
						// If we found a hash update to service that is not already sync, we just update the hash and keep the state the same.
						if (!hash.equals(admService.getHash()) && !ARConstants.ADMINISTRATIVE_SERVICE_SYNCHRONIZED.equals(admService.getSynchronized())) {
							state = ARConstants.ADMINISTRATIVE_SERVICE_STATE_IS_NEW;
						}
						Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() -> updating: " + (admServiceMainDataType.getBatchID() != null ? admServiceMainDataType.getBatchID() : "NO_BATCH_ID") + " [" + admServiceMainDataType.getServiceNumber() + "]");
						// If hash difference is found - update all the data for the admService.
						if (!hash.equals(admService.getHash())) {
							management.updateAdministrativeService(admService, admServiceMainDataType, admServiceBatchDataType, state, hash, currentUserDN);
						} // If state change is found - update only the state.
						else {
							management.updateAdministrativeServiceState(admService, state, hash, currentUserDN);
						}
						arUpdated++;
					}
				}
				j++;				
			}
			Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() -> TOTAL=" + j);
		}
		
		// We have abandoned records in our DB.
		if (loadedServiceNumbers != null && loadedServiceNumbers.size() > 0) {
			Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() -> Abandoned records in our custom DB, check if they are marked as blocked:" + loadedServiceNumbers.size());
			// Store array of filtered loaded batchIds.
			List<String> filteredLoadedServiceNumbers = new ArrayList<String>();
			// Remove all 'BLOCKED' records, as we do not need to process them.
			for (int i = 0; i < loadedServiceNumbers.size(); i++) {
				admService = admServicesHm.get(loadedServiceNumbers.get(i));
				if (admService != null && !ARConstants.ADMINISTRATIVE_SERVICE_BLOCKED.equals(admService.getBlocked())) {
					filteredLoadedServiceNumbers.add(loadedServiceNumbers.get(i));
				}
			}
			loadedServiceNumbers = filteredLoadedServiceNumbers;
		}
						
		// We have not 'BLOCKED' abandoned records in our DB.
		if (loadedServiceNumbers != null && loadedServiceNumbers.size() > 0) {		
			Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() -> We have not 'BLOCKED' abandoned records in our DB:" + loadedServiceNumbers.size());
			// Call service to load all 'Closed' administrative structures.
			
			// We still have abandoned records in our DB.
			if (loadedServiceNumbers != null && loadedServiceNumbers.size() > 0) {
				for (int i = 0; i < loadedServiceNumbers.size(); i++) {
					admService = admServicesHm.get(loadedServiceNumbers.get(i));
					if (admService != null) {
						Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() -> STATE changed to 'Not Found':" + admService.getServiceNumber());
						// We set the state to 'NOT FOUND'.
						management.updateAdministrativeServiceState(admService, ARConstants.ADMINISTRATIVE_SERVICE_STATE_NOT_FOUND, admService.getHash(), currentUserDN);
						arNotFound++;
					}
				}
			}
		}		
		
		// Clear temporary data.
		loadedServiceNumbers.clear();
		admServicesHm.clear();
		admServiceBatchDataTypeHm.clear();
		administrativeServices = null;
		result = null;
		Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: ---- Summary ------");
		Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: NEW          : " + arNew);
		Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: UPDATED      : " + arUpdated);
		Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: STATUS CHANGE: " + arStatusChanged);
		Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: NOT FOUND     : " + arNotFound);
		Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: ---- // Summary ------");
		Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() -> END!");
		
		ARServicesLoader.isRunning = false;
		Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: load() -> set isRunning to FALSE, exiting...0!");
		return 0;
	}
	

	// This function call service "searchAdmServices".
	private static Map<String, AdmServiceBatchDataType> loadAdmServiceBatchDataType(List<AdmServiceMainDataType> admServiceMainDataTypeList) throws Exception {
		// The HashMap we are going to return.
		Map<String, AdmServiceBatchDataType> admServiceBatchDataTypeHm = null;
		// Array list with all the batch Ids that we will pass to the service to get admServiceBatchDataType.
		ArrayList<String> batchIds = new ArrayList<String>();		
		// Temporary variable.
		AdmServiceMainDataType tmpAdmServiceMainDataType = null;
		// Temporary variable.
		AdmServiceBatchDataType tmpAdmServiceBatchDataType = null;
		// Temporary variable.
		String batchIdentNumber = null;
		if (admServiceMainDataTypeList != null && admServiceMainDataTypeList.size() > 0) {
			admServiceBatchDataTypeHm = new HashMap<String, AdmServiceBatchDataType>();
			for (int i = 0; i < admServiceMainDataTypeList.size(); i++) {
				tmpAdmServiceMainDataType = admServiceMainDataTypeList.get(i);
				if (tmpAdmServiceMainDataType.getBatchID() != null) {
					if (!batchIds.contains(tmpAdmServiceMainDataType.getBatchID().toString())) {
						batchIds.add(tmpAdmServiceMainDataType.getBatchID().toString());
					}
				} 
			}
			Logger.log(Logger.DEBUG_LEVEL,"--- ARServicesLoader: loadAdmServiceBatchDataType() -> Total BatchIds: " + batchIds.size());
			// Let's call the service, passing the batchIdentNumber to get "more" data for services. 
			// (the call will return >= 1 results as we are getting all services per given batchIdentNumber.
			ArrayOfAdmServiceBatchDataType result = null;
			for (int i = 0; i < batchIds.size(); i++) {
				batchIdentNumber = batchIds.get(i);
				result = null;
				try {
					// Some services does not have a "valid" batchIdentNumber, as they have only "mainData" info, so we skip the exception.
					result = port.searchAdmServices(batchIdentNumber, null, null, null);
				} catch (Exception e) {
					Logger.log(Logger.ERROR_LEVEL, "--- ARServicesLoader: loadAdmServiceBatchDataType() -> searchAdmServices for batchIdentNumber = " + batchIdentNumber + " [" + e.getMessage() + ", SKIPPING...]");
					if (e.getMessage().indexOf("Cannot convert object of type") != -1) {
						throw new Exception(e.getMessage());
					}										
				}
				
				if (result != null && result.getAdmServiceBatchDataType() != null && result.getAdmServiceBatchDataType().size() > 0) {
					Logger.log(Logger.DEBUG_LEVEL,"--- ARServicesLoader: loadAdmServiceBatchDataType() -> Total results per batchId[" + batchIdentNumber + "]: " + result.getAdmServiceBatchDataType().size());
	            	for (int j = 0; j < result.getAdmServiceBatchDataType().size(); j++) {
	            		tmpAdmServiceBatchDataType = result.getAdmServiceBatchDataType().get(j);
	            		if (tmpAdmServiceBatchDataType != null && tmpAdmServiceBatchDataType.getAdmServiceData() != null) {
	            			admServiceBatchDataTypeHm.put(tmpAdmServiceBatchDataType.getAdmServiceData().getServiceNumber() + "", tmpAdmServiceBatchDataType);
	            		}
	            	}
				}
			}
			
		}
		return admServiceBatchDataTypeHm;
	}

	// This function call service "searchAdmServiceMainData".
	public static ArrayOfAdmServiceMainDataType loadAdmServiceMainData(long serviceNumber) {
		Logger.log(Logger.DEBUG_LEVEL,"ARServicesLoader -> loadAdmServiceMainData(" + serviceNumber + ")");
		return port.searchAdmServiceMainData(serviceNumber, null);
	}
	
	// This function call service "searchAdmServices".
	public static ArrayOfAdmServiceBatchDataType loadAdmServiceBatchDataType(String bacthIdentNumber, long serviceNumber) {
		Logger.log(Logger.DEBUG_LEVEL,"ARServicesLoader -> loadAdmServiceBatchDataType(" + bacthIdentNumber + "," + serviceNumber + ")");
		return port.searchAdmServices(bacthIdentNumber, null, null, serviceNumber);
	}
	
	// This function call service "searchBatchesForAdmService".
	public static AdmServiceBatchesType loadAdmServiceBatches(long serviceNumber) {
		Logger.log(Logger.DEBUG_LEVEL,"ARServicesLoader -> searchBatchesForAdmService(" + serviceNumber + ")");
		return port.searchBatchesForAdmService(serviceNumber);
	}

	
	/*
	 *  This function aggregates all used data to build hash string and encrypt it in MD5 algorithm.
	 */
	private static String calculateHash(AdmServiceMainDataType admServiceMainDataType, AdmServiceBatchDataType admiServiceBatchDataType) {
		if (admServiceMainDataType != null) {
			MD5Digest md5;
			try {
				md5 = new MD5Digest();
				// Use data from batchIdentificationInfoType.
				String hash = admServiceMainDataType.getServiceNumber() + "";
				hash += admServiceMainDataType.getName();
				hash += admServiceMainDataType.getDescription();
				hash += admServiceMainDataType.getSectionName();
				hash += admServiceMainDataType.getBatchID();
				hash += admServiceMainDataType.isIsFromEU();
				hash += admServiceMainDataType.isIsInternalAdminService();
				hash += admServiceMainDataType.isIsRegime();
				if (admServiceMainDataType.getLegalBasis() != null && admServiceMainDataType.getLegalBasis().size() > 0) {
					RegulatoryActLegalBasisType basisType = null;
					RegulatoryActStructuredDataType dataType = null;
					for (int i = 0; i < admServiceMainDataType.getLegalBasis().size(); i++) {
            			basisType = admServiceMainDataType.getLegalBasis().get(i);
            			hash += basisType.getRegulatoryActName();
            			if (basisType.getStructuredData() != null && basisType.getStructuredData().size() > 0) {
            				for (int j = 0; j < basisType.getStructuredData().size(); j++) {
            					dataType = basisType.getStructuredData().get(j);
            					hash += dataType.getArticle() != null ? dataType.getArticle() : "";
            					hash += dataType.getLetter() != null ? dataType.getLetter() : "";
            					hash += dataType.getParagraph() != null ? dataType.getParagraph() : "";
            					hash += dataType.getSubParagraph() != null ? dataType.getSubParagraph() : "";
            					hash += dataType.getPoint() != null ? dataType.getPoint() : "";
            					hash += dataType.getText() != null ? dataType.getText() : "";
            				}
            			}
					}
					
				}
				// There are almost 200 services that does not have batchID and they don't have AdmServiceBatchDataType.
				if (admiServiceBatchDataType != null && admiServiceBatchDataType.getAdmServiceBatchInfo() != null) {	
					//Here we cover Central Administrations and Specialized Territorial Administrations.
					AdmServiceInfoType tmpAdmInfoType = admiServiceBatchDataType.getAdmServiceBatchInfo();				
					hash += tmpAdmInfoType.getBatchName();
					hash += tmpAdmInfoType.getServiceID() + "";
					// Service description.
					if (tmpAdmInfoType.getStages() != null && tmpAdmInfoType.getStages().getStage() != null && tmpAdmInfoType.getStages().getStage().size() > 0) {
						AdmServiceStageType tmpAdmServiceStageType = null;
						AdmServiceInfoDocumentType tmpAdmServiceInfoDocumentType = null;
						for (int i = 0; i < tmpAdmInfoType.getStages().getStage().size(); i++) {
							tmpAdmServiceStageType = tmpAdmInfoType.getStages().getStage().get(i);
							if (tmpAdmServiceStageType != null) {
								if (tmpAdmServiceStageType.getDescription() != null && tmpAdmServiceStageType.getDescription().getContent() != null) {    
									for (int j = 0; j < tmpAdmServiceStageType.getDescription().getContent().size(); j++) {
										hash += tmpAdmServiceStageType.getDescription().getContent().get(j); 
									}
								}
								if (tmpAdmServiceStageType.getDocument() != null && tmpAdmServiceStageType.getDocument().size() > 0) {
									for (int j = 0; j < tmpAdmServiceStageType.getDocument().size(); j++) {
										tmpAdmServiceInfoDocumentType = tmpAdmServiceStageType.getDocument().get(j);
										if (tmpAdmServiceInfoDocumentType != null) {
											hash += tmpAdmServiceInfoDocumentType.getDocumentDownloadUrl();
											hash += tmpAdmServiceInfoDocumentType.getName();
										}
									}
								}
							}
						}
					}
					// possibleWaysToApply.
					ArrayOfServiceApplicationMethodsEnum serviceApplicationMethodsArr = tmpAdmInfoType.getServiceApplicationMethods();
					if (serviceApplicationMethodsArr != null && serviceApplicationMethodsArr.getMethod() != null && serviceApplicationMethodsArr.getMethod().size() > 0) {
						Iterator<ServiceApplicationMethodsEnum> iterator = serviceApplicationMethodsArr.getMethod().iterator();
						while (iterator.hasNext()) {
							hash += iterator.next().value();
						}		
					}
					// applicationForm.
					if (tmpAdmInfoType.getModelDocuments() != null && tmpAdmInfoType.getModelDocuments().getDocument() != null && tmpAdmInfoType.getModelDocuments().getDocument().size() > 0) {
						AdmServiceInfoDocumentType tmpAdmInfoDocumentType = null;
						for (int i = 0; i < tmpAdmInfoType.getModelDocuments().getDocument().size(); i++) {
							tmpAdmInfoDocumentType = tmpAdmInfoType.getModelDocuments().getDocument().get(i);
							if (tmpAdmInfoDocumentType != null) {
								hash += tmpAdmInfoDocumentType.getDocumentDownloadUrl();
								hash += tmpAdmInfoDocumentType.getName();
							}
						}
					}
					// terms.
					if (tmpAdmInfoType.getGrantTerm() != null) {
						hash += tmpAdmInfoType.getGrantTerm();
					}
					// administrationAuthority.
					if (tmpAdmInfoType.getProvisionGovBodyName() != null) {
						hash += tmpAdmInfoType.getProvisionGovBodyName();
					}
					// provisionEAddress.
					if (tmpAdmInfoType.getProvisionEAddress() != null) {
						hash += tmpAdmInfoType.getProvisionEAddress();
					}
					// paymentInfo.
					if (tmpAdmInfoType.getPaymentInfo() != null) {
						if (tmpAdmInfoType.getPaymentInfo().getPaymentKind() != null) {
							hash += tmpAdmInfoType.getPaymentInfo().getPaymentKind().value();
							hash += tmpAdmInfoType.getPaymentInfo().getPaymentGenerationKind().value();
							hash += tmpAdmInfoType.getPaymentInfo().getNormalCost() != null ? tmpAdmInfoType.getPaymentInfo().getNormalCost() : "N";
							hash += tmpAdmInfoType.getPaymentInfo().getExpressCost() != null ? tmpAdmInfoType.getPaymentInfo().getExpressCost() : "E";
							hash += tmpAdmInfoType.getPaymentInfo().getFastCost() != null ? tmpAdmInfoType.getPaymentInfo().getFastCost() : "N";
							if (tmpAdmInfoType.getPaymentInfo().getExplanations() != null && tmpAdmInfoType.getPaymentInfo().getExplanations().getContent() != null && tmpAdmInfoType.getPaymentInfo().getExplanations().getContent().size() > 0) {
								for (int i = 0; i < tmpAdmInfoType.getPaymentInfo().getExplanations().getContent().size(); i++) {
									hash += tmpAdmInfoType.getPaymentInfo().getExplanations().getContent().get(i).toString();
								}
							}
						}
					}
					// paymentMethods.
					if (tmpAdmInfoType.getPaymentInfo() != null && tmpAdmInfoType.getPaymentInfo().getPaymentMethods() != null &&  tmpAdmInfoType.getPaymentInfo().getPaymentMethods().size() > 0) {
						Iterator<PaymentMethodsEnum> iterator = tmpAdmInfoType.getPaymentInfo().getPaymentMethods().iterator();
						while (iterator.hasNext()) {
							hash += iterator.next().value();
						}	
					}
					// administrativeSupplyUnits.
					if (tmpAdmInfoType.getServicingUnitContactData() != null && tmpAdmInfoType.getServicingUnitContactData().size() > 0) {
						UnitContactType unitContactType = null;
						CorrespondenceDataPhoneType phoneType = null;
						// In AR they are rendered backwards, that's why we iterate by DESC order.
						for (int i = tmpAdmInfoType.getServicingUnitContactData().size() - 1; i >= 0; i--) {
							unitContactType = tmpAdmInfoType.getServicingUnitContactData().get(i);
							if (unitContactType != null) {
								hash += unitContactType.getName();
								if (unitContactType.getAddress() != null) {
									if (unitContactType.getAddress().getEkatteAddress() != null) {
										hash += unitContactType.getAddress().getEkatteAddress().getDistrictName() != null ? unitContactType.getAddress().getEkatteAddress().getDistrictName() : "";
										hash += unitContactType.getAddress().getEkatteAddress().getMunicipalityName() != null ? unitContactType.getAddress().getEkatteAddress().getMunicipalityName() : "";
										hash += unitContactType.getAddress().getEkatteAddress().getSettlementName() != null ? unitContactType.getAddress().getEkatteAddress().getSettlementName() : "";
										hash += unitContactType.getAddress().getEkatteAddress().getAreaName() != null ? unitContactType.getAddress().getEkatteAddress().getAreaName() : "";
										hash += unitContactType.getAddress().getAddressText() != null ? unitContactType.getAddress().getAddressText() : "";
										hash += unitContactType.getAddress().getPostCode() != null ? unitContactType.getAddress().getPostCode() : "";
									}
									if (unitContactType.getCorrespondenceData() != null) {
										hash += unitContactType.getCorrespondenceData().getInterSettlementCallingCode() != null ? unitContactType.getCorrespondenceData().getInterSettlementCallingCode() : "";
										if (unitContactType.getCorrespondenceData().getPhone() != null && unitContactType.getCorrespondenceData().getPhone().size() > 0) {
											for (int j = 0; j < unitContactType.getCorrespondenceData().getPhone().size(); j++) {
												phoneType = unitContactType.getCorrespondenceData().getPhone().get(j);
												if (phoneType != null) {
													hash += phoneType.isIncludesSettlementCallCode();
													hash += phoneType.getPhoneNumber();								
												}            									
											}
										}
										// fax.
										if (unitContactType.getCorrespondenceData().getFaxNumber() != null) {
											hash += unitContactType.getCorrespondenceData().getFaxNumber();
										}
										// email.
										if (unitContactType.getCorrespondenceData().getEmail() != null) {
											hash += unitContactType.getCorrespondenceData().getEmail();
										}
										// web site.
										if (unitContactType.getCorrespondenceData().getWebSiteUrl() != null) {
											hash += unitContactType.getCorrespondenceData().getWebSiteUrl();
										}
										// working time.
										hash += unitContactType.getWorkTime();
									}
								}
							}
						}
					}
					
				}
				Logger.log(Logger.DEBUG_LEVEL,"ARServicesLoader -> calculateHash: hash>" + hash+"<");
				Logger.log(Logger.DEBUG_LEVEL,"ARServicesLoader -> calculateHash: md5hash>" + md5.md5crypt(hash) + "<");
				return md5.md5crypt(hash);
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			} 
		}
		return "";
	}
	
	public static void printAdmServiceMainDataType(AdmServiceMainDataType admServiceMainDataType, int depth) {
		if (admServiceMainDataType != null) {
			System.out.println("------------[ " + admServiceMainDataType.getName() + " ] -------");
			System.out.println("ServiceNumber=" + admServiceMainDataType.getServiceNumber());
			System.out.println("Name=" + admServiceMainDataType.getName());
			System.out.println("Description=" + admServiceMainDataType.getDescription());
			System.out.println("SectionName=" + admServiceMainDataType.getSectionName());
			System.out.println("BatchID=" + admServiceMainDataType.getBatchID());
			System.out.println("-------------------------------------------------");
		}
	}
	
	
	public static class ARServicesLoaderThread extends Thread {

		public void run() {
			Logger.log(Logger.DEBUG_LEVEL, "------ ARServicesLoaderThread start");
			if (!ARServicesLoader.initialized) {
				Logger.log(Logger.ERROR_LEVEL, "Service is not initialized... Thread will NOT RUN!");
				return;
			}
			int hour = ARConstants.AR_SERVICES_LOADER_PROCESS_TIME;
			String loadedHour = null;
			while (ARServicesLoader.startARServicesLoaderThread) {				
				if (ARServicesLoader.enableARServicesLoaderThread) {					
					// Load time from file.
					loadedHour = ARUtils.getConfigValueFromFile(Base.CONFIG_FILE_LOCATION + ARConstants.SERVICES_CONFIG_FILE_NAME, ARConstants.THREAD_EXECUTION_TIME_PARAMETER);
					if (loadedHour != null) {
						try {
							hour = Integer.parseInt(loadedHour.trim());
						} catch (Exception e) {e.printStackTrace();}
					}			
					Logger.log(Logger.DEBUG_LEVEL, "------ ARServicesLoaderThread threadExecutionTime is " + hour + "h");
					// This constant is loaded from file.
					if (hour == ARUtils.getCurrentHour() 
							&& (ARServicesLoader.lastProcessedDate == null || !ARUtils.getCurrentDate(null).equals(ARServicesLoader.lastProcessedDate))) {
						try {
							ARServicesLoader.load(ARConstants.SYSTEM_USER_DN);
						} catch (Exception e) {
							e.printStackTrace();
							ARServicesLoader.isRunning = false;
						}
					}
				}
				try {
					Logger.log(Logger.DEBUG_LEVEL, "------ ARServicesLoaderThread will sleep for another: " + (ARServicesLoader.sleepTime / 1000 < 60 ? (ARServicesLoader.sleepTime / 1000) + " seconds." : (ARServicesLoader.sleepTime / 60000) + " minutes."));
					ARServicesLoader.isRunning = false;
					sleep(ARServicesLoader.sleepTime);
				} catch (InterruptedException e) {
				}
			}
			ARServicesLoader.isRunning = false;
			Logger.log(Logger.DEBUG_LEVEL, "------ ARServicesLoaderThread stop");
		}
	}

	private static void initializeService(String realPath) {
		Logger.log(Logger.ERROR_LEVEL, "ARServicesLoader -> initializeService() started...");
		String wsdlPath = realPath + File.separator + "WEB-INF" + File.separator + "wsdl" + File.separator + ARConstants.ADM_SERVICES_SERVICE_WSDL_FILE_NAME;
		URL url = null;
        try {        	        	
        	// Refer to local WSDL file, with change from wsdl:definition xmlns:wsp="http://schemas.xmlsoap.org/ws/2004/09/policy"
        	// to xmlns:wsp="http://www.w3.org/ns/ws-policy"
        	url = new URL("file:" + wsdlPath);
        	// WAS 8.5 complains for wsdl:definition xmlns:wsp="http://schemas.xmlsoap.org/ws/2004/09/policy",        	
        	// that's why we cannot refer to WSDL from URL, but local file instead.
        	//url = new URL (ARConstants.BATCH_INFO_SERVICE_URL);
        } catch (MalformedURLException e) {
        	Logger.log(Logger.ERROR_LEVEL, "Can not initialize the default wsdl from address:" + wsdlPath);
        }
        boolean successConnection = false;
        try {
			successConnection = testConnection();
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "ARServicesLoader -> initializeService() [ERROR]: " + e.getMessage());
		}
        if (successConnection) {
	        try {
	        	Service service = Service.create(url, ARConstants.ADM_SERVICES_SERVICE_Q_NAME);        	
	        	IAdmServicesService iAdmServicesService = service.getPort(
	        			ARConstants.BASIC_HTTPS_BINDING_I_ADM_SERVICES_SERVICE,  
	        			IAdmServicesService.class, 
	        			new javax.xml.ws.soap.AddressingFeature());
	        	if (iAdmServicesService != null) {        		
	        		port = iAdmServicesService;
	        		initialized = true;
	        		Logger.log(Logger.ERROR_LEVEL, "ARServicesLoader -> initializeService() [OK]");
	        	} else {
	        		Logger.log(Logger.ERROR_LEVEL, "ARServicesLoader -> initializeService() [ERROR]");
	        	}
			} catch (Exception e) {
				Logger.log(Logger.ERROR_LEVEL, "ARServicesLoader -> initializeService(" + realPath + ") error:" + e.getMessage());
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
        }
        
        Logger.log(Logger.ERROR_LEVEL, "ARServicesLoader -> initializeService() finished...");
        
//    	These lines below DO NOT WORK ON WAS 8.5, so comment it and used the ones above.
//		URL wsdlURL = BatchInfoService.WSDL_LOCATION;
//		BatchInfoService ss = new BatchInfoService(wsdlURL, ARConstants.BATCH_INFO_SERVICE_QNAME);
//		ARServicesLoader.port = ss.getWSHttpBindingIBatchInfoService();
	}

	public static synchronized void init(String realPath) {
		enableARServicesLoaderThread = true;
		initializeService(realPath);
		lastProcessedDate = null;
		arServicesLoaderThread = new ARServicesLoaderThread();
		arServicesLoaderThread.start();
	}

	public static void shutdown() {
		enableARServicesLoaderThread = false;
		startARServicesLoaderThread = false;
		arServicesLoaderThread.interrupt();
		while (isRunning) {
			Logger.log(Logger.DEBUG_LEVEL, "--- Waiting ARServicesLoaderThread for stop signal...");
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			}
		}
		Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoaderThread HAS BEEN KILLED SUCCESSFULLY!");
	}
	
	private static boolean testConnection() throws NoSuchAlgorithmException, KeyManagementException {
		// Create a trust manager that does not validate certificate chains
        TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                return null;
            }
            public void checkClientTrusted(X509Certificate[] certs, String authType) {
            }
            public void checkServerTrusted(X509Certificate[] certs, String authType) {
            }
        }
        };

        // Install the all-trusting trust manager
        SSLContext sc = SSLContext.getInstance("SSL");
        sc.init(null, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

        // Create all-trusting host name verifier
        HostnameVerifier allHostsValid = new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        };

        // Install the all-trusting host verifier
        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
        return testAdmWSDLConnection();
	}
	
	private static boolean testAdmWSDLConnection() throws RuntimeException {
		 boolean success = false;
        StringBuilder strBuf = new StringBuilder();

        HttpsURLConnection conn = null;
        BufferedReader reader = null;
        try {
        	Logger.log(Logger.ERROR_LEVEL, "--- ARServicesLoader: check connection to : " + ADM_SERVICES_ADDRESS);
            URL url = new URL(ADM_SERVICES_ADDRESS);
            conn = (HttpsURLConnection) url.openConnection();
            conn.setRequestMethod("GET");	            
            conn.setRequestProperty("Accept", "*/*");
            conn.setDoOutput(true);
            conn.setConnectTimeout(7000);
            conn.setReadTimeout(7000);

            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode());
            }

            reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
            String output = null;
            while ((output = reader.readLine()) != null) {
                strBuf.append(output);
            }
            success = true;
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
        return success;
    }
	
	public static void main(String[] args) {
		URL url = null;
        try {        	        	
        	url = new URL (ARConstants.ADM_SERVICES_SERVICE_URL);
        } catch (MalformedURLException e) {
        	Logger.log(Logger.ERROR_LEVEL, "Can not initialize the default wsdl from address:" + ARConstants.ADM_SERVICES_SERVICE_URL);
        }
        Service service = Service.create(url, ARConstants.ADM_SERVICES_SERVICE_Q_NAME);
        IAdmServicesService iAdmServicesService = service.getPort(
    			ARConstants.BASIC_HTTPS_BINDING_I_ADM_SERVICES_SERVICE,  
    			IAdmServicesService.class, 
    			new javax.xml.ws.soap.AddressingFeature());
    	if (iAdmServicesService != null) {
    		ARServicesLoader.port = iAdmServicesService;
    	}
    	Base._LOGLEVEL = 2;
    	Base._LOGON = true;
		//load(ARConstants.SYSTEM_USER_DN);
    	try {
			// Call service to load ALL main data services.
			Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: main() -> Before call searchAdmServiceMainData -> " + ARUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(System.currentTimeMillis()));
			ArrayOfAdmServiceMainDataType admServiceMainDataTypeArr = port.searchAdmServiceMainData(1141l, null);
			if (admServiceMainDataTypeArr != null) {
				System.out.println("has data");
				if (admServiceMainDataTypeArr == null || admServiceMainDataTypeArr.getAdmServiceMainDataType() == null || admServiceMainDataTypeArr.getAdmServiceMainDataType().size() == 0) {
					throw new Exception("Неуспешно зареждане на \"Основни данни\" от Административния регистър!");
				}
				AdmServiceMainDataType admServiceMainDataType = admServiceMainDataTypeArr.getAdmServiceMainDataType().get(0);
			}
			Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: main() -> After call searchAdmServiceMainData -> " + ARUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(System.currentTimeMillis()));
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "--- ARServicesLoader: main() -> port.searchAdmServiceMainData: " + e.getMessage());
			System.out.println(e.getMessage());
			e.printStackTrace();
			Logger.log(Logger.DEBUG_LEVEL, "--- ARServicesLoader: main() -> set isRunning to FALSE, exiting...-2!");
		}
	}

}
