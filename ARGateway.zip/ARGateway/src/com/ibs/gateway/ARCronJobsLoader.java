package com.ibs.gateway;

import com.ibs.gateway.management.ARServiceManagement;
import com.ibs.gateway.utils.ARUtils;
import com.ibs.gateway.utils.Logger;

public class ARCronJobsLoader {

	private static int sleepTime = 1 * 60 * 60 * 1000; // 1 hour
//	private static int sleepTime = 5 * 1000; // 5 seconds
	private static int hourToRun = 20;
	private static boolean enableARCronJobsLoaderThread = false;
	private static boolean startARCronJobsLoaderThread = true;
	public static boolean isRunning = false;
	public static boolean initialized = false;
	public static boolean cronJobOtherDataRequested = false;
	
	private static ARCronJobsLoaderThread arCronJobsLoaderThread = null;

	public ARCronJobsLoader() {
	}
	
	public static class ARCronJobsLoaderThread extends Thread {

		public void run() {
			Logger.log(Logger.DEBUG_LEVEL, "------ ARCronJobsLoaderThread start");
			while (ARCronJobsLoader.startARCronJobsLoaderThread) {				
				if (ARCronJobsLoader.enableARCronJobsLoaderThread) {
					if (ARCronJobsLoader.cronJobOtherDataRequested) {
						Logger.log(Logger.DEBUG_LEVEL, "------ ARCronJobsLoaderThread threadExecutionTime is " + hourToRun + "h");
						if (hourToRun == ARUtils.getCurrentHour()) {
							try {
								ARServiceManagement management = new ARServiceManagement();
								management.downloadOtherDataTaxesFromARToAllUnifiedServiceInWCM(ARConstants.SYSTEM_USER_DN);
								ARCronJobsLoader.cronJobOtherDataRequested = false;
							} catch (Exception e) {
								e.printStackTrace();
								ARCronJobsLoader.isRunning = false;
								ARCronJobsLoader.cronJobOtherDataRequested = false;
							}
						}
					} else {
						ARCronJobsLoader.isRunning = false;
					}
				}
				try {
					Logger.log(Logger.DEBUG_LEVEL, "------ ARCronJobsLoaderThread will sleep for another: " + (ARCronJobsLoader.sleepTime / 1000 < 60 ? (ARCronJobsLoader.sleepTime / 1000) + " seconds." : (ARCronJobsLoader.sleepTime / 60000) + " minutes."));
					ARCronJobsLoader.isRunning = false;
					sleep(ARCronJobsLoader.sleepTime);
				} catch (InterruptedException e) {
				}
			}
			ARCronJobsLoader.isRunning = false;
			Logger.log(Logger.DEBUG_LEVEL, "------ ARCronJobsLoaderThread stop");
		}
	}


	public static synchronized void init(String realPath) {
		enableARCronJobsLoaderThread = true;
		arCronJobsLoaderThread = new ARCronJobsLoaderThread();
		arCronJobsLoaderThread.start();
	}

	public static void shutdown() {
		enableARCronJobsLoaderThread = false;
		startARCronJobsLoaderThread = false;
		arCronJobsLoaderThread.interrupt();
		while (isRunning) {
			Logger.log(Logger.DEBUG_LEVEL, "------ Waiting ARCronJobsLoaderThread for stop signal...");
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			}
		}
		Logger.log(Logger.DEBUG_LEVEL, "------ ARCronJobsLoaderThread HAS BEEN KILLED SUCCESSFULLY!");
	}
	

}
