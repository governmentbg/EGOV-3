package com.ibs.gateway;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.ws.Service;

import com.ibs.gateway.db.Base;
import com.ibs.gateway.dbo.ARAdministrativeStructure;
import com.ibs.gateway.management.ARStructureManagement;
import com.ibs.gateway.utils.ARUtils;
import com.ibs.gateway.utils.Logger;
import com.ibs.gateway.utils.MD5Digest;

import bg.government.iisda.ras.BatchIdentificationInfoType;
import bg.government.iisda.ras.common.ActBaseType;
import bg.government.iisda.ras.common.ActChangeType;
import bg.government.iisda.ras.integrationservices.ArrayOfBatchIdentificationInfoType;
import bg.government.iisda.ras.integrationservices.IBatchInfoService;

public class ARStructuresLoader {

	private static int sleepTime = 1 * 60 * 60 * 1000; // 1 hour
//	private static int sleepTime = 5 * 1000; // 5 seconds.
	private static boolean enableARStructuresLoaderThread = false;
	private static boolean startARStructuresLoaderThread = true;
	public static boolean isRunning = false;
	public static boolean initialized = false;
	private static ARStructuresLoaderThread arStructuresLoaderThread = null;
	private static IBatchInfoService port = null;
	private static String lastProcessedDate = null;	

	public ARStructuresLoader() {
	}

	public static synchronized int load(String currentUserDN) {
		Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: load() -> START!");
		
		if (isRunning) {
			Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: load() -> isRunning = TRUE, exiting...-1");
			return -1;
		}
		
		Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: load() -> set isRunning to TRUE!");
		isRunning = true;
		lastProcessedDate = ARUtils.getCurrentDate(null);
		if (currentUserDN == null || currentUserDN.trim().length() == 0) {
			currentUserDN = ARConstants.SYSTEM_USER_DN;
		}
						
		ARStructureManagement management = new ARStructureManagement();
		// Load all administrative structures (ACTIVE & INACTIVE) from our custom DB.
		ARAdministrativeStructure[] administrativeStructures = management.loadAllAdministrativeStructures(null, null, null, null, null);
		// Put loaded administrative structures by batchID in the HashMap.
		Map<String, ARAdministrativeStructure> admStructuresHm = new HashMap<String, ARAdministrativeStructure>();
		// Store array of loaded batchIds.
		List<String> loadedBatchIds = new ArrayList<String>();
		if (administrativeStructures != null && administrativeStructures.length > 0) {
			Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: load() -> administrativeStructures.length=" + administrativeStructures.length);
			for (int i = 0; i < administrativeStructures.length; i++) {
				admStructuresHm.put(administrativeStructures[i].getBatchId().toString(), administrativeStructures[i]);
				loadedBatchIds.add(administrativeStructures[i].getBatchId().toString());
			}
		} else {
			Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: load() -> administrativeStructures.length=0");
		}
		
		ArrayOfBatchIdentificationInfoType result = null;
		
		try {
			// Call service to load all 'Active' administrative structures.
			result = port.searchBatchesIdentificationInfo(null, null, null, null, bg.government.iisda.ras.BatchStatusEnum.ACTIVE, null, null);
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "------ ARStructuresLoader: load() -> port.searchBatchesIdentificationInfo: " + e.getMessage());
			System.out.println(e.getMessage());
			e.printStackTrace();
			isRunning = false;
			Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: load() -> set isRunning to FALSE, exiting...-2!");
			return -2;
		}
		

		// Administrative structure type.
		String type = null;
		// Administrative structure kind.
		String admStructureKind = null;
		// Calculated hash from all used fields.
		String hash = null;
		// State with change, if any.
		String state = null;
		// batchIdentificationInfoType.
		BatchIdentificationInfoType batchIdentificationInfoType = null;
		// admStructure.
		ARAdministrativeStructure admStructure = null;
		// Put loaded batchDetails info by BatchID in the HashMap, 		
		Map<String, bg.government.iisda.ras.BatchType> batchDetailsHm = new HashMap<String, bg.government.iisda.ras.BatchType>();
		int arNew = 0;
		int arUpdated = 0;
		int arStatusChanged = 0;
		int arNotFound = 0;
		
		if (result != null && result.getBatchIdentificationInfoType() != null && result.getBatchIdentificationInfoType().size() > 0) {
			Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: load() -> port.searchBatchesIdentificationInfo: TOTAL -> " + result.getBatchIdentificationInfoType().size());
			// We need this call, until AR service add support to pass "lastUpdatedTime" field, 
			// to be used as compare flag for data in AR.
			Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: load() -> Before call loadBatchDetails -> " + ARUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(System.currentTimeMillis()));
			batchDetailsHm = loadAllBatchDetails(result.getBatchIdentificationInfoType());
			Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: load() -> After call loadBatchDetails -> " + ARUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(System.currentTimeMillis()));
			int j = 0;
			for (int i = 0; i < result.getBatchIdentificationInfoType().size(); i++) {
				batchIdentificationInfoType = result.getBatchIdentificationInfoType().get(i);
				type = batchIdentificationInfoType.getType().value();
				admStructureKind = batchIdentificationInfoType.getAdmStructureKind().value();
				
				// We support types in ["AdmStructure", "COM"] 
				// and AdmStructureKind NOT in ["Council", "StatePublicConsultativeCommission"]
				if (isSupportedStructure(type, admStructureKind)) {
//					printBatchIndentificationInfoType(batchIdentificationInfoType, 0);
					state = null;										
					hash = calculateHash(batchIdentificationInfoType, batchDetailsHm.get(batchIdentificationInfoType.getBatchID() + ""));
					admStructure = admStructuresHm.get(batchIdentificationInfoType.getBatchID() + "");
					if (admStructure == null) {
						// No records found in our DB for current Administrative Structure, so set the state to 'NEW'. 
						state = ARConstants.ADMINISTRATIVE_STRUCTURE_STATE_IS_NEW;						
					} else if (admStructure != null) {						 
						// If Administrative Structure is not marked as "BLOCKED" from DAEU Administrator 
						// & hash change was found, 
						// we update the hash and set the state to 'UPDATE'.
						
						// When AR service add support for lastUpdateTime, we will use it instead of the "hash" we build now.
						if (!ARConstants.ADMINISTRATIVE_STRUCTURE_BLOCKED.equals(admStructure.getBlocked()) 
								&& !hash.equals(admStructure.getHash())) {
							state = ARConstants.ADMINISTRATIVE_STRUCTURE_STATE_IS_UPDATE;							
						} 
						// This one was processed, so remove it.
						loadedBatchIds.remove(admStructure.getBatchId().toString());
					}
					if (state != null) {
						if (ARConstants.ADMINISTRATIVE_STRUCTURE_STATE_IS_NEW.equals(state)) {	
							Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: load() -> ADMINISTRATIVE_STRUCTURE_STATE_IS_NEW:" + batchIdentificationInfoType.getBatchID());
							management.createAdministrativeStructure(batchIdentificationInfoType, state, hash, currentUserDN);
							arNew++;
						} else {
							// If we found a hash update to structure that is not already sync, we just update the hash and keep the state the same.
							if (!hash.equals(admStructure.getHash()) && !ARConstants.ADMINISTRATIVE_STRUCTURE_SYNCHRONIZED.equals(admStructure.getSynchronized())) {
								state = ARConstants.ADMINISTRATIVE_STRUCTURE_STATE_IS_NEW;
							}
							Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: load() -> ADMINISTRATIVE_STRUCTURE_STATE_IS_UPDATE:" + batchIdentificationInfoType.getBatchID());
							// If hash difference is found - update all the data for the admStructure.
							if (!hash.equals(admStructure.getHash())) {
								management.updateAdministrativeStructure(admStructure, batchIdentificationInfoType, state, hash, currentUserDN);
							} // If state change is found - update only the state.
							else {
								management.updateAdministrativeStructureState(admStructure, state, hash, currentUserDN);
							}
							arUpdated++;
						}
					}
					j++;
				}
			}
			Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: load() -> TOTAL=" + j);
			Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: load() -> TOTAL=" + result.getBatchIdentificationInfoType().size());
		}
		
		// We have abandoned records in our DB.
		if (loadedBatchIds != null && loadedBatchIds.size() > 0) {
			Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: load() -> Abandoned records in our custom DB, check if they are marked as blocked:" + loadedBatchIds.size());
			// Store array of filtered loaded batchIds.
			List<String> filteredLoadedBatchIds = new ArrayList<String>();
			// Remove all 'BLOCKED' records, as we do not need to process them.
			for (int i = 0; i < loadedBatchIds.size(); i++) {
				admStructure = admStructuresHm.get(loadedBatchIds.get(i));
				if (admStructure != null && !ARConstants.ADMINISTRATIVE_STRUCTURE_BLOCKED.equals(admStructure.getBlocked())) {
					filteredLoadedBatchIds.add(loadedBatchIds.get(i));
				}
			}
			loadedBatchIds = filteredLoadedBatchIds;
		}
						
		// We have not 'BLOCKED' abandoned records in our DB.
		if (loadedBatchIds != null && loadedBatchIds.size() > 0) {		
			Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: load() -> We have not 'BLOCKED' abandoned records in our DB:" + loadedBatchIds.size());
			// Call service to load all 'Closed' administrative structures.
			result = port.searchBatchesIdentificationInfo(null, null, null, null,
					bg.government.iisda.ras.BatchStatusEnum.CLOSED, null, null);
			if (result != null && result.getBatchIdentificationInfoType() != null && result.getBatchIdentificationInfoType().size() > 0) {
				for (int i = 0; i < result.getBatchIdentificationInfoType().size(); i++) {
					batchIdentificationInfoType = result.getBatchIdentificationInfoType().get(i);
					type = batchIdentificationInfoType.getType().value();
					admStructureKind = batchIdentificationInfoType.getAdmStructureKind().value();
					if (isSupportedStructure(type, admStructureKind)) {
						admStructure = admStructuresHm.get(batchIdentificationInfoType.getBatchID() + "");
						if (admStructure != null) {
							// Process ONLY if the state is not already set to 'STATUS_CHANGED'. 
							if (!ARConstants.ADMINISTRATIVE_STRUCTURE_STATE_STATUS_CHANGED.equalsIgnoreCase(admStructure.getState())) {
								Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: load() -> STATE changed from 'Active' to 'Closed':" + batchIdentificationInfoType.getBatchID());
								// We found our 'Active' AS to be changed to 'Closed', so set the state to 'STATUS CHANGED'.
								management.updateAdministrativeStructureState(admStructure, ARConstants.ADMINISTRATIVE_STRUCTURE_STATE_STATUS_CHANGED, admStructure.getHash(), currentUserDN);
								arStatusChanged++;
							}
							// This one was processed, so remove it.
							loadedBatchIds.remove(admStructure.getBatchId().toString());
						}
					}
				}
			}
			// We still have abandoned records in our DB.
			if (loadedBatchIds != null && loadedBatchIds.size() > 0) {
				for (int i = 0; i < loadedBatchIds.size(); i++) {
					admStructure = admStructuresHm.get(loadedBatchIds.get(i));
					if (admStructure != null) {
						Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: load() -> STATE changed to 'Not Found':" + admStructure.getBatchId());
						// We set the state to 'NOT FOUND'.
						management.updateAdministrativeStructureState(admStructure, ARConstants.ADMINISTRATIVE_STRUCTURE_STATE_NOT_FOUND, admStructure.getHash(), currentUserDN);
						arNotFound++;
					}
				}
			}
		}		
		
		// Clear temporary data.
		loadedBatchIds.clear();
		admStructuresHm.clear();
		batchDetailsHm.clear();
		administrativeStructures = null;
		result = null;
		Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: ------- Summary ------");
		Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: NEW          : " + arNew);
		Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: UPDATED      : " + arUpdated);
		Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: STATUS CHANGE: " + arStatusChanged);
		Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: NOT FOUND     : " + arNotFound);
		Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: ------- // Summary ------");
		Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: load() -> END!");
		
		ARStructuresLoader.isRunning = false;
		Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoader: load() -> set isRunning to FALSE, exiting...0!");
		return 0;
	}
	

	// This function call service "getBatchDetailedInfo".
	private static Map<String, bg.government.iisda.ras.BatchType> loadAllBatchDetails(List<BatchIdentificationInfoType> batchIdentificationInfoTypeList) {
		// batchIdentificationInfoType.
		BatchIdentificationInfoType batchIdentificationInfoType = null;
		// Administrative structure type.
		String type = null;
		// Administrative structure kind.
		String admStructureKind = null;
		// Service object container with all batchIdentificationNumbers that we need to get for service call.
		bg.government.iisda.ras.integrationservices.ArrayOfString batchIdentificationNumberArr = new bg.government.iisda.ras.integrationservices.ArrayOfString();
		// List with all batchIdentificationNumbers that we need pass to batchIdentificationNumberArr.
		List<String> batchIdentificationNumberList = new ArrayList<String>();
		
		for (int i = 0; i < batchIdentificationInfoTypeList.size(); i++) {
			batchIdentificationInfoType = batchIdentificationInfoTypeList.get(i);
			type = batchIdentificationInfoType.getType().value();
			admStructureKind = batchIdentificationInfoType.getAdmStructureKind().value();						
			if (isSupportedStructure(type, admStructureKind)) {
				batchIdentificationNumberList.add(batchIdentificationInfoType.getIdentificationNumber());
			}
		}
		
		Logger.log(Logger.DEBUG_LEVEL,"Total Numbers:" + batchIdentificationNumberList.size());
		
		// Populate service object container with batchIdentificationNumberList.
		batchIdentificationNumberArr.getString().addAll(batchIdentificationNumberList);

		// Put loaded batchTypes by BatchID in the HashMap.	
		Map<String, bg.government.iisda.ras.BatchType> batchDetailsHm = new HashMap<String, bg.government.iisda.ras.BatchType>();
		
		// Call service passing array of batch identification numbers.
		bg.government.iisda.ras.integrationservices.ArrayOfBatchType batchTypes = port.getBatchDetailedInfo(batchIdentificationNumberArr, null, null);
		if (batchTypes != null && batchTypes.getBatchType() != null && batchTypes.getBatchType().size() > 0) {
			for (int i = 0; i < batchTypes.getBatchType().size(); i++) {
				batchDetailsHm.put(batchTypes.getBatchType().get(i).getBatchID() + "", batchTypes.getBatchType().get(i));
			}
		}
		
		return batchDetailsHm;
	}

	// This function call service "getBatchDetailedInfo".
	public static bg.government.iisda.ras.BatchType loadBatchDetails(String batchIdentificationNumber) {
		Logger.log(Logger.DEBUG_LEVEL,"ARStructuresLoader -> loadBatchDetails(" + batchIdentificationNumber + ")");
		
		// Service object container with the batchIdentificationNumber that we need to get for service call.
		bg.government.iisda.ras.integrationservices.ArrayOfString batchIdentificationNumberArr = new bg.government.iisda.ras.integrationservices.ArrayOfString();
		// List with all batchIdentificationNumbers that we need pass to batchIdentificationNumberArr.
		List<String> batchIdentificationNumberString = new ArrayList<String>();
		batchIdentificationNumberString.add(batchIdentificationNumber);
		
		// Populate service object container with batchIdentificationNumberList.
		batchIdentificationNumberArr.getString().addAll(batchIdentificationNumberString);

		// Call service passing array of batch identification numbers.
		bg.government.iisda.ras.integrationservices.ArrayOfBatchType batchTypes = port.getBatchDetailedInfo(batchIdentificationNumberArr, null, null);
		if (batchTypes != null && batchTypes.getBatchType() != null && batchTypes.getBatchType().size() > 0) {
			return batchTypes.getBatchType().get(0);
		}
		
		return null;
	}

	
	/*
	 *  We support Types ["AdmStructure", "COM"], and AdmStructureKind Not in ["Council", "StatePublicConsultativeCommission"]
	 */
	private static boolean isSupportedStructure(String type, String admStructureKind) {
		return ((bg.government.iisda.ras.BatchTypeEnum.ADM_STRUCTURE.value().equalsIgnoreCase(type) ||
				bg.government.iisda.ras.BatchTypeEnum.COM.value().equalsIgnoreCase(type)) &&
				(!(admStructureKind.equalsIgnoreCase(bg.government.iisda.ras.AdmStructureKindsEnum.COUNCIL.value()) ||
						admStructureKind.equalsIgnoreCase(bg.government.iisda.ras.AdmStructureKindsEnum.STATE_PUBLIC_CONSULTATIVE_COMMISSION.value()))));
	}

	/*
	 *  This function aggregates all used data to build hash string and encrypt it in MD5 algorithm.
	 */
	private static String calculateHash(BatchIdentificationInfoType batchIdentificationInfoType, bg.government.iisda.ras.BatchType batchType) {
		if (batchIdentificationInfoType != null) {
			MD5Digest md5;
			try {
				md5 = new MD5Digest();
				// Use data from batchIdentificationInfoType.
				String hash = batchIdentificationInfoType.getBatchID() + "";
				hash += batchIdentificationInfoType.getType().value();
				hash += batchIdentificationInfoType.getIdentificationNumber();
				hash += batchIdentificationInfoType.getName();
				hash += batchIdentificationInfoType.getAdmStructureKind().value();
				hash += (batchIdentificationInfoType.getUIC() != null && batchIdentificationInfoType.getUIC().trim().length() > 0) ? batchIdentificationInfoType.getUIC() : "-"; 
				hash += batchIdentificationInfoType.getStatus();
				// Append data from batchType.
				if (batchType != null) {
					if (batchType.getAdministration() != null) { 
						if (batchType.getAdministration().getAddress() != null) {
							// Add EKATTE number.
							hash += ARServiceHelper.getEkatteNumberFromEkatteAddressType(batchType.getAdministration().getAddress().getEkatteAddress());
							// Add address text.
							hash += (batchType.getAdministration().getAddress().getAddressText() != null && batchType.getAdministration().getAddress().getAddressText().trim().length() > 0) ? batchType.getAdministration().getAddress().getAddressText() : "-";
							// Add post code.							
							hash += (batchType.getAdministration().getAddress().getPostCode() != null && batchType.getAdministration().getAddress().getPostCode().trim().length() > 0) ? batchType.getAdministration().getAddress().getPostCode() : "-";
							
							// Add CorrespondanceDataType.
							if (batchType.getAdministration().getCorrespondenceData() != null) {
								// Add web site URL.
								hash += (batchType.getAdministration().getCorrespondenceData().getWebSiteUrl() != null && batchType.getAdministration().getCorrespondenceData().getWebSiteUrl().trim().length() > 0) ? batchType.getAdministration().getCorrespondenceData().getWebSiteUrl() : "-";
								// Add phones.
								if (batchType.getAdministration().getCorrespondenceData().getPhone() != null && batchType.getAdministration().getCorrespondenceData().getPhone().size() > 0) {
									for (int i = 0; i < batchType.getAdministration().getCorrespondenceData().getPhone().size(); i++) {
										if (batchType.getAdministration().getCorrespondenceData().getPhone().get(i).getPhoneNumber() != null
											&& batchType.getAdministration().getCorrespondenceData().getPhone().get(i).getPhoneNumber().trim().length() > 0) {
											hash += batchType.getAdministration().getCorrespondenceData().getPhone().get(i).getPhoneNumber().trim();
											hash += batchType.getAdministration().getCorrespondenceData().getPhone().get(i).isIncludesSettlementCallCode();
										}										
									}
								}
								// Add InterSettlementCallingCode.
								hash += batchType.getAdministration().getCorrespondenceData().getInterSettlementCallingCode();
								// Add FAX number.
								hash += batchType.getAdministration().getCorrespondenceData().getFaxNumber();
								// Add Email.
								hash += batchType.getAdministration().getCorrespondenceData().getEmail();
							}
							// Add working time.
							if (batchType.getAdministration().getWorkingTime() != null) {
								// Add type.
								hash += batchType.getAdministration().getWorkingTime().getType().value();
								// Add description.
								hash += batchType.getAdministration().getWorkingTime().getDescription();
								// Add start time.
								hash += batchType.getAdministration().getWorkingTime().getStartTime();
								// Add end time.
								hash += batchType.getAdministration().getWorkingTime().getEndTime();
								// Add duration.
								hash += batchType.getAdministration().getWorkingTime().getDuration();
							}
							// Add procedure rules.
							if (batchType.getAct() != null && batchType.getAct().size() > 0) {
								ActBaseType act = null;
								ActChangeType actChangeType = null;
								for (int i = 0; i < batchType.getAct().size(); i++) {
									act = batchType.getAct().get(i);
									if (act != null) {
										hash += act.getName();
										hash += act.getGroupActName();
										hash += act.isIsPublishedSG();
										if (act.getStateGazetteNumber() != null) {
											hash += act.getStateGazetteNumber().getNumber();
											hash += act.getStateGazetteNumber().getYear();
										}										
										if (act.getActChange() != null && act.getActChange().size() > 0) {
											for (int j = 0; j < act.getActChange().size(); j++) {
												actChangeType = act.getActChange().get(j);
												if (actChangeType != null) {
													hash += actChangeType.getStateGazetteNumber().getNumber();
													hash += actChangeType.getStateGazetteNumber().getYear();
												}
											}
										}
									}     
								}
							}
						}
    				}
				}				
				return md5.md5crypt(hash);
			} catch (NoSuchAlgorithmException e) {
				e.printStackTrace();
			} 
		}
		return "";
	}
	
	public static void printBatchIndentificationInfoType(BatchIdentificationInfoType batchIdentificationInfoType, int depth) {
		if (batchIdentificationInfoType != null) {
			System.out.println("------------[ " + batchIdentificationInfoType.getName() + " ] -------");
			System.out.println("BatchID=" + batchIdentificationInfoType.getBatchID());
			System.out.println("Type=" + batchIdentificationInfoType.getType().value());
			System.out.println("IdentificationNumber=" + batchIdentificationInfoType.getIdentificationNumber());
			System.out.println("Name=" + batchIdentificationInfoType.getName());
			System.out.println("AdmStructureKind=" + batchIdentificationInfoType.getAdmStructureKind().value());
			System.out.println("UIC=" + batchIdentificationInfoType.getUIC());
			System.out.println("Status=" + batchIdentificationInfoType.getStatus());
			System.out.println("-------------------------------------------------");
		}
	}
	
	
	
	public static class ARStructuresLoaderThread extends Thread {

		public void run() {
			Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoaderThread start");
			if (!ARStructuresLoader.initialized) {
				Logger.log(Logger.ERROR_LEVEL, "Service is not initialized... Thread will NOT RUN!");
				return;
			}			
			int hour = ARConstants.AR_STRUCTURES_LOADER_PROCESS_TIME;
			String loadedHour = null;
			while (ARStructuresLoader.startARStructuresLoaderThread) {				
				if (ARStructuresLoader.enableARStructuresLoaderThread) {
					// Load time from file.
					loadedHour = ARUtils.getConfigValueFromFile(Base.CONFIG_FILE_LOCATION + ARConstants.STRUCTURES_CONFIG_FILE_NAME, ARConstants.THREAD_EXECUTION_TIME_PARAMETER);
					if (loadedHour != null) {
						try {
							hour = Integer.parseInt(loadedHour.trim());
						} catch (Exception e) {e.printStackTrace();}
					}			
					Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoaderThread threadExecutionTime is " + hour + "h");
					// This constant is loaded from file.
					if (hour == ARUtils.getCurrentHour() 
							&& (ARStructuresLoader.lastProcessedDate == null || !ARUtils.getCurrentDate(null).equals(ARStructuresLoader.lastProcessedDate))) {
						try {
							ARStructuresLoader.load(ARConstants.SYSTEM_USER_DN);
						} catch (Exception e) {
							e.printStackTrace();
							ARStructuresLoader.isRunning = false;
						}
					}
				}
				try {
					Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoaderThread will sleep for another: " + (ARStructuresLoader.sleepTime / 1000 < 60 ? (ARStructuresLoader.sleepTime / 1000) + " seconds." : (ARStructuresLoader.sleepTime / 60000) + " minutes."));
					ARStructuresLoader.isRunning = false;
					sleep(ARStructuresLoader.sleepTime);
				} catch (InterruptedException e) {
				}
			}
			ARStructuresLoader.isRunning = false;
			Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoaderThread stop");
		}
	}

	private static void initializeService(String realPath) {
		Logger.log(Logger.ERROR_LEVEL, "ARStructuresLoader -> initializeService() started...");
		String wsdlPath = realPath + File.separator + "WEB-INF" + File.separator + "wsdl" + File.separator + ARConstants.BATCH_INFO_SERVICE_WSDL_FILE_NAME;
		URL url = null;
        try {        	        	
        	// Refer to local WSDL file, with change from wsdl:definition xmlns:wsp="http://schemas.xmlsoap.org/ws/2004/09/policy"
        	// to xmlns:wsp="http://www.w3.org/ns/ws-policy"
        	url = new URL("file:" + wsdlPath);
        	// WAS 8.5 complains for wsdl:definition xmlns:wsp="http://schemas.xmlsoap.org/ws/2004/09/policy",        	
        	// that's why we cannot refer to WSDL from URL, but local file instead.
        	//url = new URL (ARConstants.BATCH_INFO_SERVICE_URL);
        } catch (MalformedURLException e) {
        	Logger.log(Logger.ERROR_LEVEL, "Can not initialize the default wsdl from address:" + wsdlPath);
        }
        try {
        	Service service = Service.create(url, ARConstants.BATCH_INFO_SERVICE_QNAME);
        	IBatchInfoService iBatchInfoService = service.getPort(
        			ARConstants.WS_HTTP_BINDING_I_BATCH_INFO_SERVICE_QNAME,  
        			IBatchInfoService.class, 
        			new javax.xml.ws.soap.AddressingFeature());
        	if (iBatchInfoService != null) {
        		port = iBatchInfoService;
        		initialized = true;
        		Logger.log(Logger.ERROR_LEVEL, "ARStructuresLoader -> initializeService() [OK]");
        	} else {
        		Logger.log(Logger.ERROR_LEVEL, "ARStructuresLoader -> initializeService() [ERROR]");
        	}
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "ARStructuresLoader -> initializeService(" + realPath + ") error:" + e.getMessage());
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
        
        Logger.log(Logger.ERROR_LEVEL, "ARStructuresLoader -> initializeService() finished...");
        
//    	These lines below DO NOT WORK ON WAS 8.5, so comment it and used the ones above.
//		URL wsdlURL = BatchInfoService.WSDL_LOCATION;
//		BatchInfoService ss = new BatchInfoService(wsdlURL, ARConstants.BATCH_INFO_SERVICE_QNAME);
//		ARStructuresLoader.port = ss.getWSHttpBindingIBatchInfoService();
	}

	public static synchronized void init(String realPath) {
		enableARStructuresLoaderThread = true;
		initializeService(realPath);
		lastProcessedDate = null;
		arStructuresLoaderThread = new ARStructuresLoaderThread();
		arStructuresLoaderThread.start();
	}

	public static void shutdown() {
		enableARStructuresLoaderThread = false;
		startARStructuresLoaderThread = false;
		arStructuresLoaderThread.interrupt();
		while (isRunning) {
			Logger.log(Logger.DEBUG_LEVEL, "------ Waiting ARStructuresLoaderThread for stop signal...");
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			}
		}
		Logger.log(Logger.DEBUG_LEVEL, "------ ARStructuresLoaderThread HAS BEEN KILLED SUCCESSFULLY!");
	}
	
	public static void main(String[] args) {
		String current = "";
		try {
			current = new java.io.File( "." ).getCanonicalPath();
			System.out.println("Current dir:"+current);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		URL url = null;
        try {        	        	
        	url = new URL (ARConstants.BATCH_INFO_SERVICE_URL);
        } catch (MalformedURLException e) {
        	Logger.log(Logger.ERROR_LEVEL, "Can not initialize the default wsdl from address:" + ARConstants.BATCH_INFO_SERVICE_URL);
        }
        Service service = Service.create(url, ARConstants.BATCH_INFO_SERVICE_QNAME);
    	IBatchInfoService iBatchInfoService = service.getPort(
    			ARConstants.WS_HTTP_BINDING_I_BATCH_INFO_SERVICE_QNAME,  
    			IBatchInfoService.class, 
    			new javax.xml.ws.soap.AddressingFeature());
    	if (iBatchInfoService != null) {
    		ARStructuresLoader.port = iBatchInfoService;
    	}
    	Base._LOGLEVEL = 2;
    	Base._LOGON = true;
		load(ARConstants.SYSTEM_USER_DN);
	}

}
