
package com.ibs.gateway;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.namespace.QName;

import org.tempuri.BatchInfoService;

import bg.government.iisda.ras.BatchIdentificationInfoType;
import bg.government.iisda.ras.BatchRelationshipType;
import bg.government.iisda.ras.BatchType;
import bg.government.iisda.ras.DeputyMayorType;
import bg.government.iisda.ras.DmPositionPersonDataType;
import bg.government.iisda.ras.GBPositionBatchType;
import bg.government.iisda.ras.GBPositionPersonDataType;
import bg.government.iisda.ras.GoverningBodyPositionType;
import bg.government.iisda.ras.GoverningBodyType;
import bg.government.iisda.ras.GovernmentType;
import bg.government.iisda.ras.PolOfficePostnPersonType;
import bg.government.iisda.ras.PoliticalOfficePositionType;
import bg.government.iisda.ras.PoliticalOfficeType;
import bg.government.iisda.ras.PositionType;
import bg.government.iisda.ras.ThPositionPersonDataType;
import bg.government.iisda.ras.TownHallType;
import bg.government.iisda.ras.UnitPositionCommonDataType;
import bg.government.iisda.ras.UpFunctionCategoryType;
import bg.government.iisda.ras.UpPositionPersonType;
import bg.government.iisda.ras.common.ActBaseType;
import bg.government.iisda.ras.common.ActChangeType;
import bg.government.iisda.ras.common.AddressType;
import bg.government.iisda.ras.common.BatchIAAPersonType;
import bg.government.iisda.ras.common.BatchIAAPositionType;
import bg.government.iisda.ras.common.CorrespondenceDataPhoneType;
import bg.government.iisda.ras.common.CorrespondenceDataType;
import bg.government.iisda.ras.common.EkatteAddressType;
import bg.government.iisda.ras.common.PersonDataType;
import bg.government.iisda.ras.common.PolicyAreaType;
import bg.government.iisda.ras.common.PowerCompetenceFunctionType;
import bg.government.iisda.ras.common.StaffNumbersType;
import bg.government.iisda.ras.common.VacantPositionsNumbersType;
import bg.government.iisda.ras.common.WorkingTimeType;
import bg.government.iisda.ras.integrationservices.IBatchInfoService;

public final class ARServiceHelper {

	public static String getEkatteNumberFromEkatteAddressType(EkatteAddressType address) {
		if (address != null) {
			if (address.getAreaEkatteCode() != null && address.getAreaEkatteCode().trim().length() > 0) {
				return address.getAreaEkatteCode().trim();
			}
			if (address.getSettlementEkatteCode() != null && address.getSettlementEkatteCode().trim().length() > 0) {
				return address.getSettlementEkatteCode().trim();
			}
			if (address.getMunicipalityEkatteCode() != null && address.getMunicipalityEkatteCode().trim().length() > 0) {
				return address.getMunicipalityEkatteCode().trim();
			}
			if (address.getDistrictEkatteCode() != null && address.getDistrictEkatteCode().trim().length() > 0) {
				return address.getDistrictEkatteCode().trim();
			}			
		}
		return null;
	}
	
	public static String getDistrictEkatteCodeFromEkatteAddressType(EkatteAddressType address) {
		if (address != null) {			
			if (address.getDistrictEkatteCode() != null && address.getDistrictEkatteCode().trim().length() > 0) {
				return address.getDistrictEkatteCode().trim();
			}			
		}
		return null;
	}
	
	public static String getMunicipalityEkatteCodeFromEkatteAddressType(EkatteAddressType address) {
		if (address != null) {			
			if (address.getMunicipalityEkatteCode() != null && address.getMunicipalityEkatteCode().trim().length() > 0) {
				return address.getMunicipalityEkatteCode().trim();
			}			
		}
		return null;
	}
	
	public static String getSettlementEkatteCodeFromEkatteAddressType(EkatteAddressType address) {
		if (address != null) {			
			if (address.getSettlementEkatteCode() != null && address.getSettlementEkatteCode().trim().length() > 0) {
				return address.getSettlementEkatteCode().trim();
			}			
		}
		return null;
	}

	public static void main(String args[]) throws java.lang.Exception {
		URL wsdlURL = BatchInfoService.WSDL_LOCATION;
		if (args.length > 0 && args[0] != null && !"".equals(args[0])) {
			File wsdlFile = new File(args[0]);
			try {
				if (wsdlFile.exists()) {
					wsdlURL = wsdlFile.toURI().toURL();
				} else {
					wsdlURL = new URL(args[0]);
				}
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
		}
		QName SERVICE_NAME = new QName("http://tempuri.org/", "BatchInfoService");
		BatchInfoService ss = new BatchInfoService(wsdlURL, SERVICE_NAME);
		IBatchInfoService port = ss.getWSHttpBindingIBatchInfoService();
//        String batchIdentificationNumber = "627597";
		String batchIdentificationNumber = "119";

		{

			{
//        System.out.println("Invoking searchBatchVersions...");
				java.lang.String _searchBatchVersions_batchIdentificationNumber = batchIdentificationNumber;
				javax.xml.datatype.XMLGregorianCalendar _searchBatchVersions_fromDate = javax.xml.datatype.DatatypeFactory
						.newInstance().newXMLGregorianCalendar("2020-03-22T14:14:59.200+02:00");
				javax.xml.datatype.XMLGregorianCalendar _searchBatchVersions_toDate = javax.xml.datatype.DatatypeFactory
						.newInstance().newXMLGregorianCalendar("2020-03-22T14:14:59.201+02:00");
//        bg.government.iisda.ras.integrationservices.ArrayOfVersionBatchInfoType _searchBatchVersions__return = port.searchBatchVersions(_searchBatchVersions_batchIdentificationNumber, _searchBatchVersions_fromDate, _searchBatchVersions_toDate);
//        bg.government.iisda.ras.integrationservices.ArrayOfVersionBatchInfoType _searchBatchVersions__return = port.searchBatchVersions(_searchBatchVersions_batchIdentificationNumber, null, null);
//        System.out.println("searchBatchVersions.result=" + _searchBatchVersions__return);

			}
			{
//        System.out.println("Invoking getTerritorialAdmStructure...");
				java.lang.String _getTerritorialAdmStructure_uic = "627597";
//        bg.government.iisda.ras.TerritorialAdmStructure _getTerritorialAdmStructure__return = port.getTerritorialAdmStructure(_getTerritorialAdmStructure_uic);
//        System.out.println("getTerritorialAdmStructure.result=" + _getTerritorialAdmStructure__return);

			}
			{
				System.out.println("Invoking searchBatchesIdentificationInfo...");
				java.lang.String _searchBatchesIdentificationInfo_batchIdentificationNumber = batchIdentificationNumber;
				java.lang.String _searchBatchesIdentificationInfo_batchUIC = "627597";
				bg.government.iisda.ras.AdmStructureKindsEnum _searchBatchesIdentificationInfo_admStructureKind = bg.government.iisda.ras.AdmStructureKindsEnum.MUNICIPAL_ADMINISTRATION;
				bg.government.iisda.ras.BatchTypeEnum _searchBatchesIdentificationInfo_batchType = bg.government.iisda.ras.BatchTypeEnum.ADM_STRUCTURE;
				bg.government.iisda.ras.BatchStatusEnum _searchBatchesIdentificationInfo_status = bg.government.iisda.ras.BatchStatusEnum.ACTIVE;
				javax.xml.datatype.XMLGregorianCalendar _searchBatchesIdentificationInfo_dateAt = javax.xml.datatype.DatatypeFactory
						.newInstance().newXMLGregorianCalendar("2020-03-22T14:14:59.202+02:00");
				java.lang.Long _searchBatchesIdentificationInfo_versionIDAt = Long.valueOf(8897335641936189682l);
				// bg.government.iisda.ras.integrationservices.ArrayOfBatchIdentificationInfoType
				// _searchBatchesIdentificationInfo__return =
				// port.searchBatchesIdentificationInfo(_searchBatchesIdentificationInfo_batchIdentificationNumber,
				// _searchBatchesIdentificationInfo_batchUIC,
				// _searchBatchesIdentificationInfo_admStructureKind,
				// _searchBatchesIdentificationInfo_batchType,
				// _searchBatchesIdentificationInfo_status,
				// _searchBatchesIdentificationInfo_dateAt,
				// _searchBatchesIdentificationInfo_versionIDAt);
				bg.government.iisda.ras.integrationservices.ArrayOfBatchIdentificationInfoType result = port
						.searchBatchesIdentificationInfo(null, null, _searchBatchesIdentificationInfo_admStructureKind,
								_searchBatchesIdentificationInfo_batchType, _searchBatchesIdentificationInfo_status,
								null, null);
				System.out.println("searchBatchesIdentificationInfo.result=" + result);
				if (result != null && result.getBatchIdentificationInfoType() != null
						&& result.getBatchIdentificationInfoType().size() > 0) {
					BatchIdentificationInfoType biiType = null;
					BatchType batchType = null;
					int depth = 0;
					System.out.println("TOTAL: = " + result.getBatchIdentificationInfoType().size());
					System.out.println("");
					System.out.println("");
					log("------------------[ Извикване на searchBatchesIdentificationInfo... ] ---------- ", depth);
					log("------------------[ параметри:  admStructureKind = 'MunicipalAdministration'] ---------- ",
							depth);
					log("------------------[ параметри:  status			  = 'Active'] ---------- ", depth);
					log("------------------[ параметри:  batchType		  = 'AdmStructure'] ---------- ", depth);
					System.out.println("");
					System.out.println("");
					for (int i = 0; i < result.getBatchIdentificationInfoType().size(); i++) {
						printBatchIndentificationInfoType(result.getBatchIdentificationInfoType().get(i), depth);
					}
					log("-----------------------------------", depth);
					log("------------[ TOTAL: " + result.getBatchIdentificationInfoType().size() + " ] -------", depth);
					log("-----------------------------------", depth);
					log("", depth);
					log("", depth);
					log("------------------[ Извикване на getBatchDetailedInfo... ] ---------- ", depth);
					log("------------------[ параметри:  batchIdentificationNumber = '510'] ---------- ", depth);
					bg.government.iisda.ras.integrationservices.ArrayOfString _getBatchDetailedInfo_batchIdentificationNumber = new bg.government.iisda.ras.integrationservices.ArrayOfString();
					java.util.List<java.lang.String> _getBatchDetailedInfo_batchIdentificationNumberString = new java.util.ArrayList<java.lang.String>();
					java.lang.String _getBatchDetailedInfo_batchIdentificationNumberStringVal1 = "510";
					_getBatchDetailedInfo_batchIdentificationNumberString
							.add(_getBatchDetailedInfo_batchIdentificationNumberStringVal1);
					_getBatchDetailedInfo_batchIdentificationNumber.getString()
							.addAll(_getBatchDetailedInfo_batchIdentificationNumberString);
					// javax.xml.datatype.XMLGregorianCalendar _getBatchDetailedInfo_dateAt =
					// javax.xml.datatype.DatatypeFactory.newInstance().newXMLGregorianCalendar("2020-03-22T14:14:59.197+02:00");
					// java.lang.Long _getBatchDetailedInfo_versionIDAt =
					// Long.valueOf(-6621378964977549697l);
					// bg.government.iisda.ras.integrationservices.ArrayOfBatchType
					// _getBatchDetailedInfo__return =
					// port.getBatchDetailedInfo(_getBatchDetailedInfo_batchIdentificationNumber,
					// _getBatchDetailedInfo_dateAt, _getBatchDetailedInfo_versionIDAt);
					bg.government.iisda.ras.integrationservices.ArrayOfBatchType batchDetails = port
							.getBatchDetailedInfo(_getBatchDetailedInfo_batchIdentificationNumber, null, null);
					// System.out.println("getBatchDetailedInfo.result=" + (batchDetails != null &&
					// batchDetails.getBatchType() != null && batchDetails.getBatchType().size() > 0
					// ? batchDetails.getBatchType().size() : "0"));
					log("", 0);
					if (batchDetails != null && batchDetails.getBatchType() != null
							&& batchDetails.getBatchType().size() > 0) {
						depth++;
						for (int i = 0; i < batchDetails.getBatchType().size(); i++) {
							batchType = batchDetails.getBatchType().get(i);
							if (batchType != null) {
								log("---------------[ Данни за администрация. ]-----------------", 0);
								log("", 0);
								if (batchType.getAdministration() != null) {
									if (batchType.getAdministration().getUnitPositionsSubjectOfHeadOfAdm() != null
											&& batchType.getAdministration().getUnitPositionsSubjectOfHeadOfAdm()
													.size() > 0) {
										log("", depth);
										log("---------------[ UnitPositionsSubjectOfHeadOfAdm ]-----------------",
												depth);
										printUnitPositionCommonDataType(
												batchType.getAdministration().getUnitPositionsSubjectOfHeadOfAdm(),
												depth + 1);
										log("---------------[ // UnitPositionsSubjectOfHeadOfAdm: " + batchType
												.getAdministration().getUnitPositionsSubjectOfHeadOfAdm().size()
												+ "]-----------------", depth);
										log("", depth);
									}
									if (batchType.getAdministration().getUnitPositionsInAdm() != null
											&& batchType.getAdministration().getUnitPositionsInAdm().size() > 0) {
										log("", depth);
										log("---------------[ UnitPositionsInAdm ]-----------------", depth);
										printUnitPositionCommonDataType(
												batchType.getAdministration().getUnitPositionsInAdm(), depth + 1);
										log("---------------[ // UnitPositionsInAdm "
												+ batchType.getAdministration().getUnitPositionsInAdm().size()
												+ "]-----------------", depth);
										log("", depth);
									}
									if (batchType.getAdministration().getCorrespondenceData() != null) {
										log("", depth);
										log("---------------[ CorrespondenceData ]-----------------", depth);
										printCorrespondenceDataType(
												batchType.getAdministration().getCorrespondenceData(), depth + 1);
										log("---------------[ // CorrespondenceData ]-----------------", depth);
										log("", depth);
									}
									if (batchType.getAdministration().getAddress() != null) {
										log("", depth);
										log("---------------[ Address ]-----------------", depth);
										printAddress(batchType.getAdministration().getAddress(), depth + 1);
										log("---------------[ // Address ]-----------------", depth);
										log("", depth);
									}
									if (batchType.getAdministration().getWorkingTime() != null) {
										log("", depth);
										log("---------------[ WorkingTime ]-----------------", depth);
										printWorkTimeType(batchType.getAdministration().getWorkingTime(), depth + 1);
										log("---------------[ // WorkingTime ]-----------------", depth);
										log("", depth);
									}
									if (batchType.getAdministration().getAdmTerritorialRange() != null
											&& batchType.getAdministration().getAdmTerritorialRange().size() > 0) {
										log("", depth);
										log("---------------[ AdmTerritorialRange ]-----------------", depth);
										for (int j = 0; j < batchType.getAdministration().getAdmTerritorialRange()
												.size(); j++) {
											printEkatteAddressType(
													batchType.getAdministration().getAdmTerritorialRange().get(j),
													depth + 1);
										}
										log("---------------[ // AdmTerritorialRange ]-----------------", depth);
										log("", depth);
									}
									if (batchType.getAdministration().getSecretaryPosition() != null) {
										log("", depth);
										log("---------------[ SecretaryPosition ]-----------------", depth);
										printPositionType(batchType.getAdministration().getSecretaryPosition(),
												depth + 1);
										log("---------------[ // SecretaryPosition ]-----------------", depth);
										log("", depth);
									}
									log("----------------", depth);
									log("SecretaryAbsenceReason = "
											+ batchType.getAdministration().getSecretaryAbsenceReason(), depth);
									log("BatchID = " + batchType.getAdministration().getBatchID(), depth);
									log("VersionID = " + batchType.getAdministration().getVersionID(), depth);
									log("UIC = " + batchType.getAdministration().getUIC(), depth);
									log("HeadPositionID = " + batchType.getAdministration().getHeadPositionID(), depth);
								}
								log("", 0);
								log("---------------[ // Данни за администрация. ]-----------------", 0);
								log("", 0);
								log("", 0);
								log("---------------[ Данни за актове. ]-----------------", 0);
								if (batchType.getAct() != null && batchType.getAct().size() > 0) {
									log("", 0);
									for (int j = 0; j < batchType.getAct().size(); j++) {
										printAct(batchType.getAct().get(j), depth);
									}
									log("", 0);
								}
								log("---------------[ // Данни за актове. ]-----------------", 0);
								log("", 0);
								log("", 0);
								log("---------------[ Данни за области на политика. ]-----------------", 0);
								if (batchType.getPolicyArea() != null && batchType.getPolicyArea().size() > 0) {
									log("", 0);
									for (int j = 0; j < batchType.getPolicyArea().size(); j++) {
										printPolicyAreaType(batchType.getPolicyArea().get(j), depth);
									}
									log("", 0);
								}
								log("---------------[ // Данни за области на политика. ]-----------------", 0);
								log("", 0);
								log("", 0);
								log("---------------[ Данни за ръководен орган. ]-----------------", 0);
								if (batchType.getGoverningBody() != null && batchType.getGoverningBody().size() > 0) {
									log("", 0);
									for (int j = 0; j < batchType.getGoverningBody().size(); j++) {
										printGoverningBodyType(batchType.getGoverningBody().get(j), depth);
									}
									log("", 0);
								}
								log("---------------[ // Данни за ръководен орган. ]-----------------", 0);
								log("", 0);
								log("", 0);
								log("---------------[ Данни за правителство за партидата на МС. ]-----------------", 0);
								if (batchType.getGovernment() != null) {
									log("", 0);
									printGovernmentType(batchType.getGovernment(), depth);
									log("", 0);
								}
								log("---------------[ // Данни за правителство за партидата на МС. ]-----------------",
										0);
								log("", 0);
								log("", 0);
								log("---------------[ Данни за предходно правителство за партидата на МС. ]-----------------",
										0);
								if (batchType.getPrevGovernment() != null) {
									log("", 0);
									printGovernmentType(batchType.getPrevGovernment(), depth);
									log("", 0);
								}
								log("---------------[ // Данни за предходно правителство за партидата на МС. ]-----------------",
										0);
								log("", 0);
								log("", 0);
								log("---------------[ Данни за разпоредител с бюджет. ]-----------------", 0);
								if (batchType.getStewardWithMoneyBatch() != null) {
									log("", 0);
									printBatchRelationshipType(batchType.getStewardWithMoneyBatch(), depth);
									log("", 0);
								}
								log("---------------[ // Данни за разпоредител с бюджет. ]-----------------", 0);
								log("", 0);
								log("", 0);
								log("---------------[ Самостоятелна структура към партида. ]-----------------", 0);
								if (batchType.getStandaloneStructsToBatch() != null
										&& batchType.getStandaloneStructsToBatch().size() > 0) {
									log("", 0);
									for (int j = 0; j < batchType.getStandaloneStructsToBatch().size(); j++) {
										printBatchRelationshipType(batchType.getStandaloneStructsToBatch().get(j),
												depth);
									}
									log("", 0);
								}
								log("---------------[ // Самостоятелна структура към партида. ]-----------------", 0);
								log("", 0);
								log("", 0);
								log("---------------[ Консултативен орган към партида на МС или Административна структура. ]-----------------",
										0);
								if (batchType.getAdvBoardsToComOrAdmStruct() != null
										&& batchType.getAdvBoardsToComOrAdmStruct().size() > 0) {
									log("", 0);
									for (int j = 0; j < batchType.getAdvBoardsToComOrAdmStruct().size(); j++) {
										printBatchRelationshipType(batchType.getAdvBoardsToComOrAdmStruct().get(j),
												depth);
									}
									log("", 0);
								}
								log("---------------[ // Консултативен орган към партида на МС или Административна структура. ]-----------------",
										0);
								log("", 0);
								log("", 0);
								log("---------------[ Кметства към общинска администрация. ]-----------------", 0);
								if (batchType.getTownHalls() != null && batchType.getTownHalls().size() > 0) {
									log("", 0);
									for (int j = 0; j < batchType.getTownHalls().size(); j++) {
										printTownHallType(batchType.getTownHalls().get(j), depth);
									}
									log("", 0);
								}
								log("---------------[ // Кметства към общинска администрация. ]-----------------", 0);
								log("", 0);
								log("", 0);
								log("---------------[ Кметски наместници към общинска администрация. ]-----------------",
										0);
								if (batchType.getDeputyMayors() != null && batchType.getDeputyMayors().size() > 0) {
									log("", 0);
									for (int j = 0; j < batchType.getDeputyMayors().size(); j++) {
										printDeputyMayors(batchType.getDeputyMayors().get(j), depth);
									}
									log("", 0);
								}
								log("---------------[ // Кметски наместници към общинска администрация. ]-----------------",
										0);
								log("", 0);
								log("", 0);
								log("---------------[ Длъжности към лица издаващи ИАА ]-----------------", 0);
								if (batchType.getBatchIAAPosition() != null
										&& batchType.getBatchIAAPosition().size() > 0) {
									log("", 0);
									for (int j = 0; j < batchType.getBatchIAAPosition().size(); j++) {
										printBatchIAAPositionType(batchType.getBatchIAAPosition().get(j), depth);
									}
									log("", 0);
								}
								log("---------------[ // Длъжности към лица издаващи ИАА ]-----------------", 0);
								log("", 0);
								log("", 0);
								log("---------------[ Лица издаващи ИАА ]-----------------", 0);
								if (batchType.getBatchIAAPerson() != null && batchType.getBatchIAAPerson().size() > 0) {
									log("", 0);
									for (int j = 0; j < batchType.getBatchIAAPerson().size(); j++) {
										printBatchIAAPerson(batchType.getBatchIAAPerson().get(j), depth);
									}
									log("", 0);
								}
								log("---------------[ // Лица издаващи ИАА ]-----------------", 0);

								log("", 0);
								log("", 0);
								log("---------------[ Данни за обща численост на партида. ]-----------------", 0);
								if (batchType.getStaffNumbers() != null) {
									log("", 0);
									printStaffNumbers(batchType.getStaffNumbers(), depth);
									log("", 0);
								}
								log("---------------[ // Данни за обща численост на партида. ]-----------------", 0);
								log("", 0);
								log("", 0);
								log("---------------[ Данни за брой незаети места на партида. ]-----------------", 0);
								if (batchType.getVacantPositionsNumbers() != null) {
									log("", 0);
									printVacantPositionsNumbers(batchType.getVacantPositionsNumbers(), depth);
									log("", 0);
								}
								log("---------------[ // Данни за брой незаети места на партида. ]-----------------",
										0);
								log("", 0);
								log("", 0);
								log("---------------[ Атрибути ]-----------------", 0);
								log("BatchID = " + batchType.getBatchID(), 0);
								log("VersionID = " + batchType.getVersionID(), 0);
								log("Type = " + batchType.getType().value(), 0);
								log("IdentificationNumber = " + batchType.getIdentificationNumber(), 0);
								log("Name = " + batchType.getName(), 0);
								log("BudgetOfficerLevel = " + (batchType.getBudgetOfficerLevel() != null
										? batchType.getBudgetOfficerLevel().toString()
										: ""), 0);
								log("AdmStructureKind = " + (batchType.getAdmStructureKind() != null
										? batchType.getAdmStructureKind().value()
										: ""), 0);
								log("---------------[ // Атрибути ]-----------------", 0);
							}
						}

					}

				}
			}
		}
		System.exit(0);
	}

	private static void printBatchIndentificationInfoType(BatchIdentificationInfoType batchIdentificationInfoType,
			int depth) {
		if (batchIdentificationInfoType != null) {
			log("------------[ " + batchIdentificationInfoType.getName() + " ] -------", depth);
			log("BatchID=" + batchIdentificationInfoType.getBatchID(), depth);
			log("Type=" + batchIdentificationInfoType.getType().value(), depth);
			log("IdentificationNumber=" + batchIdentificationInfoType.getIdentificationNumber(), depth);
			log("Name=" + batchIdentificationInfoType.getName(), depth);
			log("AdmStructureKind=" + batchIdentificationInfoType.getAdmStructureKind().value(), depth);
			log("UIC=" + batchIdentificationInfoType.getUIC(), depth);
			log("Status=" + batchIdentificationInfoType.getStatus(), depth);
			log("-------------------------------------------------", depth);
		}
	}

	private static void printUnitPositionCommonDataType(List<UnitPositionCommonDataType> unitPositionCommonDataTypes,
			int depth) {
		UnitPositionCommonDataType unitPositionCommonDataType = null;
		UpFunctionCategoryType upFunctionCategoryType = null;
		for (int j = 0; j < unitPositionCommonDataTypes.size(); j++) {
			unitPositionCommonDataType = unitPositionCommonDataTypes.get(j);
			if (unitPositionCommonDataType != null) {
				printStaffNumbers(unitPositionCommonDataType.getStaffNumbers(), depth);
				printVacantPositionsNumbers(unitPositionCommonDataType.getVacantPositionsNumbers(), depth);
				if (unitPositionCommonDataType.getFunction() != null
						&& unitPositionCommonDataType.getFunction().size() > 0) {
					for (int k = 0; k < unitPositionCommonDataType.getFunction().size(); k++) {
						// [ FUNCTION ]
						printPowerCompetenceFunctionType(unitPositionCommonDataType.getFunction().get(k), depth);
					}
				}
				if (unitPositionCommonDataType.getChildPositionsAndUnit() != null
						&& unitPositionCommonDataType.getChildPositionsAndUnit().size() > 0) {
					log("ChildPositionsAndUnit => [recursion -> we skip it] size: "
							+ unitPositionCommonDataType.getChildPositionsAndUnit().size(), depth);
					for (int k = 0; k < unitPositionCommonDataType.getChildPositionsAndUnit().size(); k++) {
//						TODO					
//						unitPositionCommonDataTypeChild = unitPositionCommonDataType.getChildPositionsAndUnit().get(k);

					}
				}
				if (unitPositionCommonDataType.getUpFunctionCategory() != null
						&& unitPositionCommonDataType.getUpFunctionCategory().size() > 0) {
					for (int k = 0; k < unitPositionCommonDataType.getUpFunctionCategory().size(); k++) {
						log("---------------[ UpFunctionCategory ]-----------------", depth);
						upFunctionCategoryType = unitPositionCommonDataType.getUpFunctionCategory().get(k);
						if (upFunctionCategoryType != null) {
							log("UpFunctionCategoryID = " + upFunctionCategoryType.getUpFunctionCategoryID(),
									depth + 1);
							log("VersionID = " + upFunctionCategoryType.getVersionID(), depth + 1);
							if (upFunctionCategoryType.getFunctionCategory() != null) {
								log("FunctionCategory = " + upFunctionCategoryType.getFunctionCategory().value(),
										depth + 1);
							}
						}
						log("---------------[ // UpFunctionCategory ]-----------------", depth);

					}
				}
				log("UnitPosID = " + unitPositionCommonDataType.getUnitPosID(), depth);
				log("VersionID = " + unitPositionCommonDataType.getVersionID(), depth);
				log("Name = " + unitPositionCommonDataType.getName(), depth);
				if (unitPositionCommonDataType.getKind() != null) {
					log("Kind = " + unitPositionCommonDataType.getKind().value(), depth);
				}
				log("ParentID = " + unitPositionCommonDataType.getParentID(), depth);
				if (unitPositionCommonDataType.getAdministrationType() != null) {
					log("AdministrationType = " + unitPositionCommonDataType.getAdministrationType().value(), depth);
				}
				log("Rank = " + unitPositionCommonDataType.getRank(), depth);
				log("CreationDate = " + unitPositionCommonDataType.getCreationDate(), depth);
				log("ClosingDate = " + unitPositionCommonDataType.getClosingDate(), depth);
				log("ProvideAccessForPeopleWithDisabilities = "
						+ unitPositionCommonDataType.isProvideAccessForPeopleWithDisabilities(), depth);
				if (unitPositionCommonDataType.getStatus() != null) {
					log("Status = " + unitPositionCommonDataType.getStatus().value(), depth);
				}
			}
		}
	}

	private static void printCorrespondenceDataType(CorrespondenceDataType correspondenceDataType, int depth) {
		CorrespondenceDataPhoneType correspondenceDataPhoneType = null;
		if (correspondenceDataType.getPhone() != null && correspondenceDataType.getPhone().size() > 0) {
			log("Phone------------------", depth);
			for (int j = 0; j < correspondenceDataType.getPhone().size(); j++) {
				correspondenceDataPhoneType = correspondenceDataType.getPhone().get(j);
				log("CorrespDataPhoneID = " + correspondenceDataPhoneType.getCorrespDataPhoneID(), depth + 1);
				log("VersionID = " + correspondenceDataPhoneType.getVersionID(), depth + 1);
				log("PhoneNumber = " + correspondenceDataPhoneType.getPhoneNumber(), depth + 1);
				log("IncludesSettlementCallCode = " + correspondenceDataPhoneType.isIncludesSettlementCallCode(),
						depth + 1);
			}
			log("    -------------------------", depth);
		}
		log("CorrespDataID = " + correspondenceDataType.getCorrespDataID(), depth);
		log("VersionID = " + correspondenceDataType.getVersionID(), depth);
		log("InterSettlementCallingCode = " + correspondenceDataType.getInterSettlementCallingCode(), depth);
		log("FaxNumber = " + correspondenceDataType.getFaxNumber(), depth);
		log("Email = " + correspondenceDataType.getEmail(), depth);
		log("WebSiteUrl = " + correspondenceDataType.getWebSiteUrl(), depth);
	}

	private static void printAddress(AddressType address, int depth) {
		if (address != null) {
			printEkatteAddressType(address.getEkatteAddress(), depth);
			log("AddressID = " + address.getAddressID(), depth);
			log("VersionID = " + address.getVersionID(), depth);
			log("PostCode = " + address.getPostCode(), depth);
			log("AddressText = " + address.getAddressText(), depth);
		}
	}

	private static void printWorkTimeType(WorkingTimeType workingTime, int depth) {
		if (workingTime != null) {
			log("WorkingTimeID = " + workingTime.getWorkingTimeID(), depth);
			log("VersionID = " + workingTime.getVersionID(), depth);
			if (workingTime.getType() != null) {
				log("Type = " + workingTime.getType().value(), depth);
			}
			log("Description = " + workingTime.getDescription(), depth);
			log("StartTime = " + workingTime.getStartTime(), depth);
			log("EndTime = " + workingTime.getEndTime(), depth);
			log("Duration = " + workingTime.getDuration(), depth);
		}
	}

	private static void printEkatteAddressType(EkatteAddressType address, int depth) {
		if (address != null) {
			log("EkatteAddress--------", depth);
			log("DistrictEkatteCode = " + address.getDistrictEkatteCode(), depth + 1);
			log("DistrictName = " + address.getDistrictName(), depth + 1);
			log("MunicipalityEkatteCode = " + address.getMunicipalityEkatteCode(), depth + 1);
			log("MunicipalityName = " + address.getMunicipalityName(), depth + 1);
			log("SettlementEkatteCode = " + address.getSettlementEkatteCode(), depth + 1);
			log("SettlementName = " + address.getSettlementName(), depth + 1);
			log("AreaEkatteCode = " + address.getAreaEkatteCode(), depth + 1);
			log("AreaName = " + address.getAreaName(), depth + 1);
			log("    --------------------------", depth);
		}
	}

	private static void printPositionType(PositionType positionType, int depth) {
		if (positionType != null) {
			List<UnitPositionCommonDataType> tmpUPCT = new ArrayList<UnitPositionCommonDataType>();
			tmpUPCT.add(positionType);
			printUnitPositionCommonDataType(tmpUPCT, depth);
			log("PositionPersonData---------------", depth);
			printPositionPersonData(positionType.getPositionPersonData(), depth);
			log("PrevPositionPersonData---------------", depth);
			printPositionPersonData(positionType.getPrevPositionPersonData(), depth);
			log("DoesHeadExecutePosition = " + positionType.isDoesHeadExecutePosition(), depth);
		}
	}

	private static void printPositionPersonData(UpPositionPersonType upPositionPersonType, int depth) {
		if (upPositionPersonType != null) {
			if (upPositionPersonType.getPersonData() != null) {
				log("PersonData ---------------", depth);
				printPersonData(upPositionPersonType.getPersonData(), depth + 1);
				log("----------------------------------------------", depth + 1);
			}
			log("UpPstnPersonID = " + upPositionPersonType.getUpPstnPersonID(), depth);
			log("VersionID = " + upPositionPersonType.getVersionID(), depth);
			log("TakeOfficeDate = " + upPositionPersonType.getTakeOfficeDate(), depth);
			log("LeaveOfficeDate = " + upPositionPersonType.getLeaveOfficeDate(), depth);
		}
	}

	private static void printPersonData(PersonDataType personData, int depth) {
		log("PersonDataID = " + personData.getPersonDataID(), depth);
		log("VersionID = " + personData.getVersionID(), depth);
		log("FirstName = " + personData.getFirstName(), depth);
		log("SecondName = " + personData.getSecondName(), depth);
		log("ThirdName = " + personData.getThirdName(), depth);
		log("Email = " + personData.getEmail(), depth);
	}

	private static void printAct(ActBaseType act, int depth) {
		if (act != null) {
			ActChangeType actChangeType = null;
			if (act != null) {
				log("Name = " + act.getName(), depth);
				log("GroupActName = " + act.getGroupActName(), depth);
				log("IsPublishedSG = " + act.isIsPublishedSG(), depth);
				if (act.getStateGazetteNumber() != null) {
					log("StateGazetteNumber: number = " + act.getStateGazetteNumber().getNumber(), depth);
					log("StateGazetteNumber: year = " + act.getStateGazetteNumber().getYear(), depth);
				}
				if (act.getActChange() != null && act.getActChange().size() > 0) {
					for (int z = 0; z < act.getActChange().size(); z++) {
						actChangeType = act.getActChange().get(z);
						if (actChangeType != null) {
							log("actChangeType = " + actChangeType.getDateChanged(), depth);
						}
					}
				}
			}
		}
	}

	private static void printPolicyAreaType(PolicyAreaType policyAreaType, int depth) {
		if (policyAreaType != null) {
			log("PolicyAreaID = " + policyAreaType.getPolicyAreaID(), depth);
			log("VersionID = " + policyAreaType.getVersionID(), depth);
			log("Name = " + policyAreaType.getName(), depth);
		}
	}

	private static void printGoverningBodyType(GoverningBodyType governingBodyType, int depth) {
		if (governingBodyType != null) {
			if (governingBodyType.getHeadPosition() != null) {
				log("---- [ HeadPosition ] -------------", depth);
				printGoverningBodyPositionType(governingBodyType.getHeadPosition(), depth);
				log("---- [ // HeadPosition ] -------------", depth);
			}
			if (governingBodyType.getDeputyPosition() != null && governingBodyType.getDeputyPosition().size() > 0) {
				log("---- [ DeputyPositions ] -------------", depth);
				for (int i = 0; i < governingBodyType.getDeputyPosition().size(); i++) {
					log("---- [ DeputyPosition ] -------------", depth + 1);
					printGoverningBodyPositionType(governingBodyType.getDeputyPosition().get(i), depth + 2);
					log("---- [ // DeputyPosition ] -------------", depth + 1);
				}
				log("----------------------------------------------", depth + 1);
				log("---- [ // DeputyPositions: " + governingBodyType.getDeputyPosition().size() + "]---------------",
						depth);
			}
			if (governingBodyType.getMemberPosition() != null && governingBodyType.getMemberPosition().size() > 0) {
				log("---- [ MemberPositions ] -------------", depth);
				for (int i = 0; i < governingBodyType.getMemberPosition().size(); i++) {
					log("---- [ MemberPosition ] -------------", depth + 1);
					printGoverningBodyPositionType(governingBodyType.getMemberPosition().get(i), depth + 2);
					log("---- [ // MemberPosition ] -------------", depth + 1);
				}
				log("----------------------------------------------", depth + 1);
				log("---- [ // MemberPositions: " + governingBodyType.getMemberPosition().size() + "]---------------",
						depth);
			}
			if (governingBodyType.getMinisterWithoutPortfolioPosition() != null
					&& governingBodyType.getMinisterWithoutPortfolioPosition().size() > 0) {
				log("---- [ MinisterWithoutPortfolioPositions ] -------------", depth);
				for (int i = 0; i < governingBodyType.getMinisterWithoutPortfolioPosition().size(); i++) {
					log("---- [ MinisterWithoutPortfolioPosition ] -------------", depth + 1);
					printGoverningBodyPositionType(governingBodyType.getMinisterWithoutPortfolioPosition().get(i),
							depth + 2);
					log("---- [ // MinisterWithoutPortfolioPosition ] -------------", depth + 1);
				}
				log("----------------------------------------------", depth + 1);
				log("---- [ // MinisterWithoutPortfolioPositions: "
						+ governingBodyType.getMinisterWithoutPortfolioPosition().size() + "]---------------", depth);
			}
			if (governingBodyType.getCompetence() != null && governingBodyType.getCompetence().size() > 0) {
				log("---- [ Competence ] -------------", depth);
				for (int i = 0; i < governingBodyType.getCompetence().size(); i++) {
					printPowerCompetenceFunctionType(governingBodyType.getCompetence().get(i), depth + 1);
				}
				log("---- [ // Competence ] -------------", depth);
			}

			if (governingBodyType.getPower() != null && governingBodyType.getPower().size() > 0) {
				log("---- [ Power ] -------------", depth);
				for (int i = 0; i < governingBodyType.getPower().size(); i++) {
					printPowerCompetenceFunctionType(governingBodyType.getPower().get(i), depth + 1);
				}
				log("---- [ // Power ] -------------", depth);
			}

			log("GoverningBodyID = " + governingBodyType.getGoverningBodyID(), depth);
			log("VersionID = " + governingBodyType.getVersionID(), depth);
			log("IsExecutiveBody = " + governingBodyType.isIsExecutiveBody(), depth);
			log("Name = " + governingBodyType.getName(), depth);
			log("Type = " + governingBodyType.getType().value(), depth);
		}
	}

	private static void printGBPositionPersonDataType(GBPositionPersonDataType positionPersonData, int depth) {
		if (positionPersonData != null) {
			log("PersonData ---------------", depth);
			printPersonData(positionPersonData.getPersonData(), depth + 1);
			log("----------------------------------------------", depth + 1);
			log("GBPositionPersonID = " + positionPersonData.getGBPositionPersonID(), depth);
			log("VersionID = " + positionPersonData.getVersionID(), depth);
			log("TakeOfficeDate = " + positionPersonData.getTakeOfficeDate(), depth);
			log("LeaveOfficeDate = " + positionPersonData.getLeaveOfficeDate(), depth);
		}
	}

	private static void printGBPositionBatchType(GBPositionBatchType positionBatchType, int depth) {
		if (positionBatchType != null) {
			printAct(positionBatchType.getAct(), depth);
			log("---------------[ Batch ]-----------------", depth);
			printBatchIndentificationInfoType(positionBatchType.getBatch(), depth + 1);
			log("---------------[ // Batch ]-----------------", depth);
			log("Batch (will not go deeper) -> " + positionBatchType.getBatch(), depth);
			log("PersonData ---------------", depth);
			log("GbPositionBatchID = " + positionBatchType.getGbPositionBatchID(), depth);
			log("VersionID = " + positionBatchType.getVersionID(), depth);
			log("Rank = " + positionBatchType.getRank(), depth);
		}
	}

	private static void printPowerCompetenceFunctionType(PowerCompetenceFunctionType powerCompetenceFunctionType,
			int depth) {
		log("---------------[ Function ]-----------------", depth);
		if (powerCompetenceFunctionType != null) {
			if (powerCompetenceFunctionType.getAct() != null) {
				log("---------------[ Act ]-----------------", depth);
				log("ActID = " + powerCompetenceFunctionType.getAct().getActID(), depth);
				printAct(powerCompetenceFunctionType.getAct().getAct(), depth);
			}
			log("PowerComptFuncID = " + powerCompetenceFunctionType.getPowerComptFuncID(), depth);
			log("VersionID = " + powerCompetenceFunctionType.getVersionID(), depth);
			log("Name = " + powerCompetenceFunctionType.getName(), depth);
			log("Rank = " + powerCompetenceFunctionType.getRank(), depth);
		}
		log("---------------[ // Function ]-----------------", depth);
	}

	private static void printPoliticalOfficeType(PoliticalOfficeType politicalOfficeType, int depth) {
		if (politicalOfficeType != null) {
			printStaffNumbers(politicalOfficeType.getStaffNumber(), depth);
			printVacantPositionsNumbers(politicalOfficeType.getVacantPositionsNumbers(), depth);
			if (politicalOfficeType.getFunction() != null && politicalOfficeType.getFunction().size() > 0) {
				for (int i = 0; i < politicalOfficeType.getFunction().size(); i++) {
					printPowerCompetenceFunctionType(politicalOfficeType.getFunction().get(i), depth);
				}
			}
			if (politicalOfficeType.getPosition() != null && politicalOfficeType.getPosition().size() > 0) {
				for (int i = 0; i < politicalOfficeType.getPosition().size(); i++) {
					printPoliticalOfficePositionType(politicalOfficeType.getPosition().get(i), depth);
				}
			}
			log("PoliticalOfficeID = " + politicalOfficeType.getPoliticalOfficeID(), depth);
			log("VersionID = " + politicalOfficeType.getVersionID(), depth);
		}
	}

	private static void printStaffNumbers(StaffNumbersType staffNumbers, int depth) {
		if (staffNumbers != null) {
			log("---------------[ StaffNumbers ]-----------------", depth);
			log("StaffNumbersID = " + staffNumbers.getStaffNumbersID(), depth);
			log("VersionID = " + staffNumbers.getVersionID(), depth);
			log("TotalStaffNumbers = " + staffNumbers.getTotalStaffNumbers(), depth);
			log("ExpertsNumbers = " + staffNumbers.getExpertsNumbers(), depth);
			log("AdvisorsNumbers = " + staffNumbers.getAdvisorsNumbers(), depth);
			log("CivilServantNumbers = " + staffNumbers.getCivilServantNumbers(), depth);
			log("EmploymentNumbers = " + staffNumbers.getEmploymentNumbers(), depth);
			log("BodiesDeputiesNumbers = " + staffNumbers.getBodiesDeputiesNumbers(), depth);
			log("---------------[ // StaffNumbers ]-----------------", depth);
		}
	}

	private static void printVacantPositionsNumbers(VacantPositionsNumbersType vacantPositionsNumbers, int depth) {
		if (vacantPositionsNumbers != null) {
			log("---------------[ VacantPositionsNumbers ]-----------------", depth);
			log("VacantPositionsNumbersID = " + vacantPositionsNumbers.getVacantPositionsNumbersID(), depth);
			log("VersionID = " + vacantPositionsNumbers.getVersionID(), depth);
			log("TotalVacantPositions = " + vacantPositionsNumbers.getTotalVacantPositions(), depth);
			log("CsVacantPosition = " + vacantPositionsNumbers.getCsVacantPosition(), depth);
			log("EmpltVacantPositions = " + vacantPositionsNumbers.getEmpltVacantPositions(), depth);
			log("---------------[ // VacantPositionsNumbers ]-----------------", depth);
		}
	}

	private static void printPoliticalOfficePositionType(PoliticalOfficePositionType politicalOfficePosition,
			int depth) {
		if (politicalOfficePosition != null) {
			log("---------------[ PositionPersonData ]-----------------", depth + 1);
			printPositionPersonData(politicalOfficePosition.getPositionPersonData(), depth + 1);
			log("---------------[ // PositionPersonData ]-----------------", depth + 1);
			log("---------------[ PrevPositionPersonData ]-----------------", depth + 1);
			printPositionPersonData(politicalOfficePosition.getPrevPositionPersonData(), depth + 1);
			log("---------------[ // PrevPositionPersonData ]-----------------", depth + 1);
			log("---------------[ Position ]-----------------", depth);
			if (politicalOfficePosition.getFunction() != null && politicalOfficePosition.getFunction().size() > 0) {
				for (int i = 0; i < politicalOfficePosition.getFunction().size(); i++) {
					printPowerCompetenceFunctionType(politicalOfficePosition.getFunction().get(i), depth + 1);
				}
			}
			log("PolOfficePostnID = " + politicalOfficePosition.getPolOfficePostnID(), depth);
			log("VersionID = " + politicalOfficePosition.getVersionID(), depth);
			log("Name = " + politicalOfficePosition.getName(), depth);
			log("IsPositionEmpty = " + politicalOfficePosition.isIsPositionEmpty(), depth);
			log("Rank = " + politicalOfficePosition.getRank(), depth);
			log("---------------[ // Position ]-----------------", depth);
		}
	}

	private static void printPositionPersonData(PolOfficePostnPersonType polOfficePostnPerson, int depth) {
		if (polOfficePostnPerson != null) {
			printPersonData(polOfficePostnPerson.getPersonData(), depth);
			log("PositionID = " + polOfficePostnPerson.getPositionID(), depth);
			log("PolOfficePostnPersonID = " + polOfficePostnPerson.getPolOfficePostnPersonID(), depth);
			log("VersionID = " + polOfficePostnPerson.getVersionID(), depth);
			log("TakeOfficeDate = " + polOfficePostnPerson.getTakeOfficeDate(), depth);
			log("LeaveOfficeDate = " + polOfficePostnPerson.getLeaveOfficeDate(), depth);
		}
	}

	private static void printGoverningBodyPositionType(GoverningBodyPositionType governingBodyPosition, int depth) {
		log("---- [ PositionPersonData ] -------------", depth + 1);
		printGBPositionPersonDataType(governingBodyPosition.getPositionPersonData(), depth + 2);
		log("---- [ // PositionPersonData ] -------------", depth + 1);
		log("---- [ PrevPositionPersonData ] -------------", depth + 1);
		printGBPositionPersonDataType(governingBodyPosition.getPrevPositionPersonData(), depth + 2);
		log("---- [ // PrevPositionPersonData ] -------------", depth + 1);
		if (governingBodyPosition.getPositionBatch() != null && governingBodyPosition.getPositionBatch().size() > 0) {
			log("---- [ PositionBatch ] -------------", depth + 1);
			for (int i = 0; i < governingBodyPosition.getPositionBatch().size(); i++) {
				printGBPositionBatchType(governingBodyPosition.getPositionBatch().get(i), depth + 2);
			}
			log("---- [ // PositionBatch: " + governingBodyPosition.getPositionBatch().size() + " ] -------------",
					depth + 1);
		}
		if (governingBodyPosition.getPower() != null && governingBodyPosition.getPower().size() > 0) {
			log("---- [ Power ] -------------", depth + 1);
			for (int i = 0; i < governingBodyPosition.getPower().size(); i++) {
				printPowerCompetenceFunctionType(governingBodyPosition.getPower().get(i), depth + 2);
			}
			log("---- [ // Power: " + governingBodyPosition.getPower().size() + " ] -------------", depth + 1);
		}
		if (governingBodyPosition.getPoliticalOffice() != null) {
			log("---- [ PoliticalOffice ] -------------", depth + 1);
			printPoliticalOfficeType(governingBodyPosition.getPoliticalOffice(), depth + 2);
			log("---- [ // PoliticalOffice ] -------------", depth + 1);
		}
		log("PositionID = " + governingBodyPosition.getPositionID(), depth);
		log("VersionID = " + governingBodyPosition.getVersionID(), depth);
		log("Name = " + governingBodyPosition.getName(), depth);
		log("FieldsOfActivityName = " + governingBodyPosition.getFieldsOfActivityName(), depth);
		log("IsHeadOfAdministration = " + governingBodyPosition.isIsHeadOfAdministration(), depth);
	}

	private static void printGovernmentType(GovernmentType government, int depth) {
		if (government != null) {
			log("GovernmentID = " + government.getGovernmentID(), depth);
			log("VersionID = " + government.getVersionID(), depth);
			log("Type = " + government.getType().value(), depth);
			log("CeasePowersDate = " + government.getCeasePowersDate(), depth);
			log("FromDate = " + government.getFromDate(), depth);
			log("ToDate = " + government.getToDate(), depth);
		}

	}

	private static void printBatchRelationshipType(BatchRelationshipType batchRelationship, int depth) {
		if (batchRelationship != null) {
			log("---- [ RelatedBatch ] -------------", depth);
			printBatchIndentificationInfoType(batchRelationship.getRelatedBatch(), depth + 1);
			log("---- [ // RelatedBatch ] -------------", depth);
			log("BatchRelationshipID = " + batchRelationship.getBatchRelationshipID(), depth);
			log("VersionID = " + batchRelationship.getVersionID(), depth);
		}
	}

	private static void printTownHallType(TownHallType townHall, int depth) {
		if (townHall != null) {
			log("---- [ CorrespondenceData ] -------------", depth);
			printCorrespondenceDataType(townHall.getCorrespondenceData(), depth + 1);
			log("---- [ // CorrespondenceData ] -------------", depth);
			log("---- [ Address ] -------------", depth);
			printAddress(townHall.getAddress(), depth + 1);
			log("---- [ // Address ] -------------", depth);
			log("---- [ WorkingTime ] -------------", depth);
			printWorkTimeType(townHall.getWorkingTime(), depth + 1);
			log("---- [ // WorkingTime ] -------------", depth);
			log("---- [ TerritorialRange ] -------------", depth);
			if (townHall.getTerritorialRange() != null && townHall.getTerritorialRange().size() > 0) {
				for (int i = 0; i < townHall.getTerritorialRange().size(); i++) {
					printEkatteAddressType(townHall.getTerritorialRange().get(i), depth + 1);
				}
			}
			log("---- [ // TerritorialRange ] -------------", depth);
			log("---- [ ThMayorPowers ] -------------", depth);
			if (townHall.getThMayorPowers() != null && townHall.getThMayorPowers().size() > 0) {
				for (int i = 0; i < townHall.getThMayorPowers().size(); i++) {
					printPowerCompetenceFunctionType(townHall.getThMayorPowers().get(i), depth + 1);
				}
			}
			log("---- [ // ThMayorPowers ] -------------", depth);
			log("---- [ ThPositionPersonData ] -------------", depth);
			if (townHall.getThPositionPersonData() != null) {
				printThPositionPersonDataType(townHall.getThPositionPersonData(), depth + 1);
			}
			log("---- [ // ThPositionPersonData ] -------------", depth);
			log("---- [ PrevThPositionPersonData ] -------------", depth);
			if (townHall.getPrevThPositionPersonData() != null) {
				printThPositionPersonDataType(townHall.getPrevThPositionPersonData(), depth + 1);
			}
			log("---- [ // PrevThPositionPersonData ] -------------", depth);
			log("---- [ StaffNumbers ] -------------", depth);
			printStaffNumbers(townHall.getStaffNumbers(), depth);
			log("---- [ // StaffNumbers ] -------------", depth);

			log("---- [ VacantPositionsNumbers ] -------------", depth);
			printVacantPositionsNumbers(townHall.getVacantPositionsNumbers(), depth);
			log("---- [ // VacantPositionsNumbers ] -------------", depth);

			log("TownHallID = " + townHall.getTownHallID(), depth);
			log("VersionID = " + townHall.getVersionID(), depth);
			log("ThName = " + townHall.getThName(), depth);
			log("ThEkatteCode = " + townHall.getThEkatteCode(), depth);
		}
	}

	private static void printDeputyMayors(DeputyMayorType deputyMayor, int depth) {
		if (deputyMayor != null) {
			log("---- [ CorrespondenceData ] -------------", depth);
			printCorrespondenceDataType(deputyMayor.getCorrespondenceData(), depth + 1);
			log("---- [ // CorrespondenceData ] -------------", depth);
			log("---- [ TerritorialRange ] -------------", depth);
			if (deputyMayor.getTerritorialRange() != null && deputyMayor.getTerritorialRange().size() > 0) {
				for (int i = 0; i < deputyMayor.getTerritorialRange().size(); i++) {
					printEkatteAddressType(deputyMayor.getTerritorialRange().get(i), depth + 1);
				}
			}
			log("---- [ // TerritorialRange ] -------------", depth);
			log("---- [ DmPower ] -------------", depth);
			if (deputyMayor.getDmPower() != null && deputyMayor.getDmPower().size() > 0) {
				for (int i = 0; i < deputyMayor.getDmPower().size(); i++) {
					printPowerCompetenceFunctionType(deputyMayor.getDmPower().get(i), depth + 1);
				}
			}
			log("---- [ // DmPower ] -------------", depth);
			log("---- [ DmPositionPersonData ] -------------", depth);
			if (deputyMayor.getDmPositionPersonData() != null) {
				printDmPositionPersonDataType(deputyMayor.getDmPositionPersonData(), depth + 1);
			}
			log("---- [ // DmPositionPersonData ] -------------", depth);
			log("---- [ PrevDmPositionPersonData ] -------------", depth);
			if (deputyMayor.getPrevDmPositionPersonData() != null) {
				printDmPositionPersonDataType(deputyMayor.getPrevDmPositionPersonData(), depth + 1);
			}
			log("---- [ // PrevDmPositionPersonData ] -------------", depth);
			log("---- [ Location ] -------------", depth);
			if (deputyMayor.getLocation() != null) {
				printEkatteAddressType(deputyMayor.getLocation(), depth + 1);
			}
			log("---- [ // Location ] -------------", depth);
			log("DeputyMayorID = " + deputyMayor.getDeputyMayorID(), depth);
			log("VersionID = " + deputyMayor.getVersionID(), depth);
		}
	}

	private static void printThPositionPersonDataType(ThPositionPersonDataType positionPersonData, int depth) {
		if (positionPersonData != null) {
			log("PersonData ---------------", depth);
			printPersonData(positionPersonData.getPersonData(), depth + 1);
			log("----------------------------------------------", depth + 1);
			log("ThPositionPersonID = " + positionPersonData.getThPositionPersonID(), depth);
			log("VersionID = " + positionPersonData.getVersionID(), depth);
			log("TakeOfficeDate = " + positionPersonData.getTakeOfficeDate(), depth);
			log("LeaveOfficeDate = " + positionPersonData.getLeaveOfficeDate(), depth);
		}
	}

	private static void printDmPositionPersonDataType(DmPositionPersonDataType positionPersonData, int depth) {
		if (positionPersonData != null) {
			log("PersonData ---------------", depth);
			printPersonData(positionPersonData.getPersonData(), depth + 1);
			log("----------------------------------------------", depth + 1);
			log("DmPositionPersonID = " + positionPersonData.getDmPositionPersonID(), depth);
			log("VersionID = " + positionPersonData.getVersionID(), depth);
			log("TakeOfficeDate = " + positionPersonData.getTakeOfficeDate(), depth);
			log("LeaveOfficeDate = " + positionPersonData.getLeaveOfficeDate(), depth);
		}
	}

	private static void printBatchIAAPositionType(BatchIAAPositionType iaaPosition, int depth) {
		if (iaaPosition != null) {
			log("---- [ Power ] -------------", depth);
			if (iaaPosition.getPower() != null && iaaPosition.getPower().size() > 0) {
				for (int i = 0; i < iaaPosition.getPower().size(); i++) {
					printPowerCompetenceFunctionType(iaaPosition.getPower().get(i), depth + 1);
				}
			}
			log("---- [ // Power ] -------------", depth);
			log("---- [ Acts ] -------------", depth);
			if (iaaPosition.getAct() != null && iaaPosition.getAct().size() > 0) {
				for (int i = 0; i < iaaPosition.getAct().size(); i++) {
					log("---------------[ Act ]-----------------", depth + 1);
					log("ActID = " + iaaPosition.getAct().get(i).getActID(), depth + 1);
					printAct(iaaPosition.getAct().get(i).getAct(), depth + 1);
					log("---------------[ Act ]-----------------", depth + 1);
				}
			}
			log("---- [ // Acts ] -------------", depth);
			log("BatchIAAPositionID = " + iaaPosition.getBatchIAAPositionID(), depth);
			log("VersionID = " + iaaPosition.getVersionID(), depth);
			log("PositionName = " + iaaPosition.getPositionName(), depth);
		}
	}

	private static void printBatchIAAPerson(BatchIAAPersonType iaaPerson, int depth) {
		if (iaaPerson != null) {
			log("---- [ PersonData ] -------------", depth);
			if (iaaPerson.getPersonData() != null) {
				printPersonData(iaaPerson.getPersonData(), depth + 1);
			}
			log("---- [ // PersonData ] -------------", depth);
			log("---- [ // Acts ] -------------", depth);
			log("BatchIAAPersonID = " + iaaPerson.getBatchIAAPersonID(), depth);
			log("VersionID = " + iaaPerson.getVersionID(), depth);
			log("BatchIAAPositionID = " + iaaPerson.getBatchIAAPositionID(), depth);
			log("TakeOfficeDate = " + iaaPerson.getTakeOfficeDate(), depth);
			log("LeaveOfficeDate = " + iaaPerson.getLeaveOfficeDate(), depth);
		}
	}

	private static void log(String text, int depth) {
		String offset = "";
		for (int i = 0; i < depth; i++) {
			offset += "    ";
		}
		System.out.println(offset + text);
	}
}
