package com.ibs.gateway.bean;

import com.ibs.gateway.ARConstants;
import com.ibs.gateway.ARGatewayPortlet;

public class Container {
	
	String currentTab = ARGatewayPortlet.TAB_FOR_UPDATE;
	String filterNumber = null;
	String filterName = null;
	String filterSectionName = null;
	String filterStatus = null;
	String filterSupplierBatchId = null;
	String filterState= null;
	String filterUIC = null;
	String filterSynchronized = null;
	private boolean filterInitialised;
	private int resultsPerPage = 0;
	private int start = 0;
	private int orderColumn = ARConstants.COLUMN_ID;
	private String order = ARConstants.ORDER_DESC;	
	
	public String getCurrentTab() {
		return currentTab;
	}

	public void setCurrentTab(String currentTab) {
		this.currentTab = currentTab;
	}

	public String getFilterNumber() {
		return filterNumber;
	}
	public void setFilterNumber(String filterNumber) {
		this.filterNumber = filterNumber;
	}
	public String getFilterName() {
		return filterName;
	}
	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}
	public String getFilterSectionName() {
		return filterSectionName;
	}
	public void setFilterSectionName(String filterSectionName) {
		this.filterSectionName = filterSectionName;
	}
	public String getFilterStatus() {
		return filterStatus;
	}
	public void setFilterStatus(String filterStatus) {
		this.filterStatus = filterStatus;
	}
	public String getFilterSupplierBatchId() {
		return filterSupplierBatchId;
	}
	public void setFilterSupplierBatchId(String filterSupplierBatchId) {
		this.filterSupplierBatchId = filterSupplierBatchId;
	}
	public String getFilterState() {
		return filterState;
	}
	public void setFilterState(String filterState) {
		this.filterState = filterState;
	}
	public String getFilterUIC() {
		return filterUIC;
	}
	public void setFilterUIC(String filterUIC) {
		this.filterUIC = filterUIC;
	}
	public String getFilterSynchronized() {
		return filterSynchronized;
	}
	public void setFilterSynchronized(String filterSynchronized) {
		this.filterSynchronized = filterSynchronized;
	}

	public boolean isFilterInitialised() {
		return filterInitialised;
	}

	public void setFilterInitialised(boolean filterInitialised) {
		this.filterInitialised = filterInitialised;
	}

	public int getResultsPerPage() {
		return resultsPerPage;
	}

	public void setResultsPerPage(int resultsPerPage) {
		this.resultsPerPage = resultsPerPage;
	}

	public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getOrderColumn() {
		return orderColumn;
	}

	public void setOrderColumn(int orderColumn) {
		this.orderColumn = orderColumn;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}
	
}

