package com.ibs.gateway.management;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;

import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.AuthoringTemplate;
import com.ibm.workplace.wcm.api.ChildPosition;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.Document;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentIterator;
import com.ibm.workplace.wcm.api.DocumentLibrary;
import com.ibm.workplace.wcm.api.DocumentTypes;
import com.ibm.workplace.wcm.api.Reference;
import com.ibm.workplace.wcm.api.SiteArea;
import com.ibm.workplace.wcm.api.Workspace;
import com.ibm.workplace.wcm.api.exceptions.QueryServiceException;
import com.ibm.workplace.wcm.api.query.Query;
import com.ibm.workplace.wcm.api.query.ResultIterator;
import com.ibm.workplace.wcm.api.query.Selectors;
import com.ibm.workplace.wcm.api.query.WorkflowSelectors;
import com.ibs.gateway.ARConstants;
import com.ibs.gateway.ARGatewayPortlet;
import com.ibs.gateway.ARServicesLoader;
import com.ibs.gateway.db.FinderException;
import com.ibs.gateway.dbo.ARAdministrativeService;
import com.ibs.gateway.dbo.ARAdministrativeStructure;
import com.ibs.gateway.utils.ARUtils;
import com.ibs.gateway.utils.Logger;

import bg.government.iisda.admservices.AdmServiceBatchesType;
import bg.government.iisda.admservices.AdmServiceInfoType;
import bg.government.iisda.admservices.AdmServiceMainDataType;
import bg.government.iisda.admservices.integrationservices.ArrayOfAdmServiceBatchDataType;
import bg.government.iisda.admservices.integrationservices.ArrayOfAdmServiceMainDataType;

public class ARServiceToWCMManagement {
	
	public ARAdministrativeStructure checkSupplierIsAddedToWCM(String supplierBatchId, ResourceBundle bundle) throws Exception {
		if (supplierBatchId == null) {
			throw new Exception(bundle.getString("administrative.service.supplier.batch.id.is.empty"));
		}
		ARAdministrativeStructure administrativeStructure = null;
		try {
			administrativeStructure = ARAdministrativeStructure.findByBatchId(supplierBatchId.toString(), null);
		} catch (FinderException e) {
			throw new Exception(bundle.getString("administrative.structure.was.not.found") + " [" + supplierBatchId.toString() + "]");
		}			
		
		if (administrativeStructure == null) {
			throw new Exception(bundle.getString("administrative.structure.was.not.found") + " [" + supplierBatchId.toString() + "]");
		}
		
		if (!ARConstants.ADMINISTRATIVE_STRUCTURE_SYNCHRONIZED.equals(administrativeStructure.getSynchronized()) 
				|| administrativeStructure.getContentUUID() == null || administrativeStructure.getContentUUID().trim().length() == 0) {
			throw new Exception(bundle.getString("administrative.structure.should.be.synchronized") + " [" + supplierBatchId.toString() + "]");
		}
		// check content exists.
		Content content = null;
		try {
			content = (Content)EgovWCMCache.getWorkspace().getById(EgovWCMCache.getWorkspace().createDocumentId(administrativeStructure.getContentUUID()), true);			
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "ARServiceToWCMManagement : checkSupplierIsAddedToWCM() : " + e.getMessage());
		}
		if (content == null) {
			throw new Exception(bundle.getString("wcm.supplier.content.not.found") + " Content UUID [" + administrativeStructure.getContentUUID() + "]!");
		}
		administrativeStructure.setContent(content);
		return administrativeStructure;
	}
	
	@SuppressWarnings("unchecked")
	public ARAdministrativeStructure[] checkSuppliersAreAddedToWCM(ARAdministrativeService administrativeService, ARAdministrativeStructure[] administrativeStructures) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> checkSuppliersAreAddedToWCM() start... [" + administrativeStructures.length + "]");
		ARAdministrativeStructure administrativeStructure = null;
		HashMap<String, Content> contentsHm = new HashMap<String, Content>();
		//DocumentId<Document>[] contentIds = new DocumentId[administrativeStructures.length];
		ArrayList<DocumentId<Document>> contentIds = new ArrayList<DocumentId<Document>>();
		boolean allAdministrations = EgovWCMCache.AR_SERVICE_SECTION_NAME_ALL_ADMINISTRATIONS.equalsIgnoreCase(administrativeService.getSectionName());
		for (int i = 0; i < administrativeStructures.length; i++) {
			administrativeStructure = administrativeStructures[i];
			if (!ARConstants.ADMINISTRATIVE_STRUCTURE_SYNCHRONIZED.equals(administrativeStructure.getSynchronized()) 
					|| administrativeStructure.getContentUUID() == null || administrativeStructure.getContentUUID().trim().length() == 0) {
				if (!allAdministrations) {
					throw new Exception("Моля синхронизирайте административната структура, която предоставя избраната от Вас услуга!" + " [" + administrativeStructure.getBatchId().toString() + "]");
				} else {
					// For ALL_ADMINISTRATIONS we are not so strict for the "ARAdministrativeStructure" existence in WCM.
					continue;
				}
			}
			contentIds.add(EgovWCMCache.getWorkspace().createDocumentId(administrativeStructure.getContentUUID()));
		}
		
		// Load all contents from WCM.
		Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> checkSuppliersAreAddedToWCM(): load contents from WCM.");
		DocumentIterator<Document> docIterator = EgovWCMCache.getWorkspace().getByIds(EgovWCMCache.getWorkspace().createDocumentIdIterator(contentIds.toArray(new DocumentId[contentIds.size()])), true);
		if (docIterator == null || !docIterator.hasNext()) {
			throw new Exception("Няма намерени съдържания за Административните структури!");
		}
		Content content = null;
		while (docIterator.hasNext()) {
			content = (Content)docIterator.next();
			contentsHm.put(content.getId().getId(), content);
		}
		for (int i = 0; i < administrativeStructures.length; i++) {
			if (allAdministrations && (administrativeStructures[i].getContentUUID() == null || administrativeStructures[i].getContentUUID().trim().length() == 0)) {
				continue;
			}
			content = contentsHm.get(administrativeStructures[i].getContentUUID());
			if (content == null) {
				throw new Exception("Съдържание за Административната структура не е намерено в WCM!" + " Content UUID [" + administrativeStructure.getContentUUID() + "]!");
			}
			administrativeStructures[i].setContent(content);
		}
		Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> checkSuppliersAreAddedToWCM() end!");
		return administrativeStructures;
	}
	
	public String sendAdministrativeServiceToWCM(ARAdministrativeService administrativeService, ARAdministrativeStructure administrativeStructure, ResourceBundle bundle) throws Exception {	
		
		ArrayOfAdmServiceMainDataType admServiceMainDataTypeArr = ARServicesLoader.loadAdmServiceMainData(administrativeService.getServiceNumber().longValue());
		if (admServiceMainDataTypeArr == null || admServiceMainDataTypeArr.getAdmServiceMainDataType() == null || admServiceMainDataTypeArr.getAdmServiceMainDataType().size() == 0) {
			throw new Exception(bundle.getString("ar.service.main.data.type.not.loaded"));
		}
		AdmServiceMainDataType admServiceMainDataType = admServiceMainDataTypeArr.getAdmServiceMainDataType().get(0);
		
		// For Central Administrations.
		if (EgovWCMCache.AR_SERVICE_SECTION_NAME_CENTRAL_ADMINISTRATIONS.equalsIgnoreCase(administrativeService.getSectionName())) {
			// Load all batches for given Administrative service.
			AdmServiceBatchesType admServiceBatchType = ARServicesLoader.loadAdmServiceBatches(administrativeService.getServiceNumber().longValue());
			if (admServiceBatchType == null || admServiceBatchType.getBatchIdentNumber() == null || admServiceBatchType.getBatchIdentNumber().size() == 0) {
				throw new Exception(bundle.getString("ar.service.batches.not.loaded"));
			}
			// Load "Service Batch Data Type" for the given Administrative service.
			ArrayOfAdmServiceBatchDataType admServiceBatchDataType = ARServicesLoader.loadAdmServiceBatchDataType(admServiceBatchType.getBatchIdentNumber().get(0).replaceFirst("^0+(?!$)", ""), administrativeService.getServiceNumber().longValue());
			
			if (admServiceBatchDataType == null || admServiceBatchDataType.getAdmServiceBatchDataType() == null || admServiceBatchDataType.getAdmServiceBatchDataType().size() == 0) {			
				throw new Exception(bundle.getString("ar.service.batch.data.type.not.loaded"));
			}
			
			return createServiceByProviderInWCM(administrativeService, administrativeStructure, admServiceMainDataType, admServiceBatchDataType, bundle);
		}
		// For Specialized Territorial Administrations.
		if (EgovWCMCache.AR_SERVICE_SECTION_NAME_SPECIALIZED_TERRITORIAL_ADMINISTRATIONS.equalsIgnoreCase(administrativeService.getSectionName())) {
			// Load all batches for given Administrative service.
			AdmServiceBatchesType admServiceBatchType = ARServicesLoader.loadAdmServiceBatches(administrativeService.getServiceNumber().longValue());
			if (admServiceBatchType == null || admServiceBatchType.getBatchIdentNumber() == null || admServiceBatchType.getBatchIdentNumber().size() == 0) {
				throw new Exception(bundle.getString("ar.service.batches.not.loaded"));
			}
			String bacthIdentNumber = null;
			String contentUUID = null;
			ArrayOfAdmServiceBatchDataType admServiceBatchDataType = null;
			ARAdministrativeStructure[] administrativeStructures = new ARAdministrativeStructure[admServiceBatchType.getBatchIdentNumber().size()];
			for (int i = 0; i < admServiceBatchType.getBatchIdentNumber().size(); i++) {
    			bacthIdentNumber = admServiceBatchType.getBatchIdentNumber().get(i).replaceFirst("^0+(?!$)", "");
    			administrativeStructures[i] = checkSupplierIsAddedToWCM(bacthIdentNumber, bundle);
			}			
			for (int i = 0; i < administrativeStructures.length; i++) {
				// Load "Service Batch Data Type" for the given Administrative service.
				admServiceBatchDataType = ARServicesLoader.loadAdmServiceBatchDataType(administrativeStructures[i].getBatchId().toString(), administrativeService.getServiceNumber().longValue());
				
				if (admServiceBatchDataType == null || admServiceBatchDataType.getAdmServiceBatchDataType() == null || admServiceBatchDataType.getAdmServiceBatchDataType().size() == 0) {			
					throw new Exception(bundle.getString("ar.service.batch.data.type.not.loaded"));
				}
				
				contentUUID = createServiceByProviderInWCM(administrativeService, administrativeStructures[i], admServiceMainDataType, admServiceBatchDataType, bundle);
			}
			return contentUUID;
		}
		
		return null;		
	}
	
	@SuppressWarnings({ "rawtypes" })
	public String updateUnifiedServiceInWCM(ARAdministrativeService administrativeService, ARAdministrativeStructure administrativeStructure, String batchId, boolean updateOtherData, ResourceBundle bundle) throws Exception {	
		ArrayOfAdmServiceMainDataType admServiceMainDataTypeArr = ARServicesLoader.loadAdmServiceMainData(administrativeService.getServiceNumber().longValue());
		if (admServiceMainDataTypeArr == null || admServiceMainDataTypeArr.getAdmServiceMainDataType() == null || admServiceMainDataTypeArr.getAdmServiceMainDataType().size() == 0) {
			throw new Exception(bundle.getString("ar.service.main.data.type.not.loaded"));
		}
		AdmServiceMainDataType admServiceMainDataType = admServiceMainDataTypeArr.getAdmServiceMainDataType().get(0);
		
		ArrayOfAdmServiceBatchDataType admServiceBatchDataType = ARServicesLoader.loadAdmServiceBatchDataType(batchId, administrativeService.getServiceNumber().longValue());
		
		if (admServiceBatchDataType == null || admServiceBatchDataType.getAdmServiceBatchDataType() == null || admServiceBatchDataType.getAdmServiceBatchDataType().size() == 0) {			
			throw new Exception(bundle.getString("ar.service.batch.data.type.not.loaded"));
		}
		
		// Check we have valid data from the AR service.
		AdmServiceInfoType admServiceInfoType = null;
		if (admServiceBatchDataType.getAdmServiceBatchDataType().get(0) != null && admServiceBatchDataType.getAdmServiceBatchDataType().get(0).getAdmServiceBatchInfo() != null) {
			admServiceInfoType = admServiceBatchDataType.getAdmServiceBatchDataType().get(0).getAdmServiceBatchInfo();
		} else {
			throw new Exception(bundle.getString("ar.service.adm.service.batch.info.is.empty"));
		}
		// Load serviceApplicationMethod category by admServiceInfoType.
		DocumentId[] serviceApplicationMethodDocIds = ARUtils.getWCMServiceApplicationMethodCategoriesFromAdmServiceInfoType(admServiceInfoType, bundle);
		if (serviceApplicationMethodDocIds == null || serviceApplicationMethodDocIds.length == 0) {
			throw new Exception(bundle.getString("ar.service.application.methods.categories.are.empty"));		
		}
		
		Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> updateUnifiedServiceInWCM(): We are going to create NEW content.");
		// Load content object.
		Content content = EgovWCMCache.getWorkspace().getById(EgovWCMCache.getWorkspace().createDocumentId(administrativeService.getContentUUID()));
		content = getContent(content, null, null, true);
		// Populate common data.
		populateCommonData(content, administrativeService, administrativeStructure, admServiceMainDataType, bundle);
		// Populate Unified service data. (it is the same as "ServiceProvidedBySupplier" minus several fields,
		// which will be automatically skipped.
		populateServiceProvidedBySupplierData(content, admServiceInfoType, serviceApplicationMethodDocIds, false, bundle);
		// Save content to WCM.
		ARUtils.save(EgovWCMCache.getWorkspace(), content);
		
		// If "autoPublish" option is set in the portlet, move the content to next(publish) workflow stage.
		if (ARGatewayPortlet.autoPublish || updateOtherData) {
			//boolean runExitActions, boolean runEntryActions, java.lang.String comment
			if (content.isDraft() || content.isDraftOfPublishedDocument()) {
				content.approve(true, true, null);
			}
		}
		
		Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> updateUnifiedServiceInWCM() | content.getId().getId() = " + content.getId().getId());
		
		if (updateOtherData) {
			Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> updateUnifiedServiceInWCM() | updateOtherData = " + updateOtherData);
			administrativeService.setContent(content);
			administrativeService.setContentUUID(content.getId().getId());
			downloadOtherDataForAdministrativeServiceToWCM(administrativeService, false);
		}
		
		// Return the generated contentUUID.
		return content.getId().getId();
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String createUnifiedServiceInWCM(ARAdministrativeService administrativeService, ARAdministrativeStructure administrativeStructure, String batchId, boolean createOtherData, ResourceBundle bundle) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagement : createUnifiedServiceInWCM() started...");
		ArrayOfAdmServiceMainDataType admServiceMainDataTypeArr = ARServicesLoader.loadAdmServiceMainData(administrativeService.getServiceNumber().longValue());
		if (admServiceMainDataTypeArr == null || admServiceMainDataTypeArr.getAdmServiceMainDataType() == null || admServiceMainDataTypeArr.getAdmServiceMainDataType().size() == 0) {
			throw new Exception(bundle.getString("ar.service.main.data.type.not.loaded"));
		}
		AdmServiceMainDataType admServiceMainDataType = admServiceMainDataTypeArr.getAdmServiceMainDataType().get(0);
		
		ArrayOfAdmServiceBatchDataType admServiceBatchDataType = ARServicesLoader.loadAdmServiceBatchDataType(batchId, administrativeService.getServiceNumber().longValue());
		
		if (admServiceBatchDataType == null || admServiceBatchDataType.getAdmServiceBatchDataType() == null || admServiceBatchDataType.getAdmServiceBatchDataType().size() == 0) {			
			throw new Exception(bundle.getString("ar.service.batch.data.type.not.loaded"));
		}
		
		// Get target siteArea.
		DocumentId siteArea = null;
		String path = EgovWCMCache.SERVICE_PROVIDERS_SITE_AREA_PATH;
		if (EgovWCMCache.AR_SERVICE_SECTION_NAME_ALL_ADMINISTRATIONS.equalsIgnoreCase(administrativeService.getSectionName())) {
			path += "/" + EgovWCMCache.SP_SITE_AREA_ALL_ADMINISТRATIONS_NAME;
		} else if (EgovWCMCache.AR_SERVICE_SECTION_NAME_REGIONAL_ADMINISTRATIONS.equalsIgnoreCase(administrativeService.getSectionName())) {
			path += "/" + EgovWCMCache.SP_SITE_AREA_REGIONAL_ADMINISRATION_NAME;
		} else if (EgovWCMCache.AR_SERVICE_SECTION_NAME_MUNICIPAL_ADMINISTRATIONS.equalsIgnoreCase(administrativeService.getSectionName())) {
			path += "/" + EgovWCMCache.SP_SITE_AREA_MUNICIPAL_ADMINISTRATION_NAME;
		} else if (EgovWCMCache.AR_SERVICE_SECTION_NAME_SPECIALIZED_TERRITORIAL_ADMINISTRATIONS.equalsIgnoreCase(administrativeService.getSectionName())) {
			String specialzedTerritorialAdministrationPath = ""; 			
			// Load content by batchId.
			try {
				Query query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
				// filter by library.
				query.addSelector(Selectors.libraryEquals(EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)));
				query.addSelector(Selectors.nameEquals(batchId));
				// filter by territorial AT.
			 	query.addSelector(
						Selectors.authoringTemplateIn(
							new DocumentId[] {
								EgovWCMCache.getATServiceProviderTerritorialAdministration().getId()
							}
						)
				);
				// filter by published.
				query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
				query.returnIds();
				ResultIterator resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);			     
				if (resultIterator.hasNext()) {
					 Logger.log(Logger.ERROR_LEVEL, "ARServiceToWCMManagement :  -> specialized territorial administration founded [" + batchId + "]!");
					 while (resultIterator.hasNext()) {						 
				    	 Content specializedTerritorialAdministration = (Content)EgovWCMCache.getWorkspace().getById((DocumentId)resultIterator.next(), true);
				    	 if (specializedTerritorialAdministration != null) {				    		 
				    		 specialzedTerritorialAdministrationPath = "/" + EgovWCMCache.SP_SITE_AREA_SPECIALIZED_TERRITORIAL_ADMINISTRATION_NAME + "/" + specializedTerritorialAdministration.getParentId().getName();
				    	 }
					 }
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw new Exception("Възникна грешка при намиране на местоположението на доставчика. Моля свържете се със системния админстратор. [" + e.getMessage() + "]");				
			}
			if (specialzedTerritorialAdministrationPath.length() == 0) {
				throw new Exception("Възникна грешка при намиране на местоположението на доставчика. Моля свържете се със системния админстратор.");
			}
			Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> createUnifiedServiceInWCM(): specialzedTerritorialAdministrationPath = " + specialzedTerritorialAdministrationPath);
			path += specialzedTerritorialAdministrationPath;
		} else {
			throw new Exception(bundle.getString("not.supported.type.for.migration") + " - [" + administrativeService.getSectionName() + "]");
		}
		
		path += "/" + EgovWCMCache.SERVICES_SITE_AREA_NAME_UNIFIED_SERVICES;
				
		Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> createUnifiedServiceInWCM(): path=" + path);
		
		DocumentIdIterator iterator = EgovWCMCache.getWorkspace().findAllByPath(path, DocumentTypes.SiteArea, Workspace.WORKFLOWSTATUS_PUBLISHED, new DocumentLibrary[] { EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)});
		if (iterator.hasNext()) { // Site area found.									
			siteArea = iterator.next();
			Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> createUnifiedServiceInWCM(): SA founded!");
		}
		
		if (siteArea == null) {
			Logger.log(Logger.ERROR_LEVEL, "ARServiceToWCMManagemnt -> createUnifiedServiceInWCM(): SA not found [" + path + "]!");
			throw new Exception(bundle.getString("wcm.sa.not.found") + " SITEAREA [" + path + "]!");
		}
		Content content = null;
		// Check content exists.
		iterator = EgovWCMCache.getWorkspace().findAllByPath(path + "/" + administrativeService.getServiceNumber().toString(), DocumentTypes.Content, Workspace.WORKFLOWSTATUS_ALL, new DocumentLibrary[] { EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)});
		if (iterator.hasNext()) { // Content found.
			Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> createUnifiedServiceInWCM(): existing content found!");
			content = (Content)EgovWCMCache.getWorkspace().getById(iterator.next());
			//throw new Exception(bundle.getString("wcm.existing.content.found") + " CONTENT [" + path + "/" + administrativeService.getServiceNumber().toString() + "]!");
		}
		
		AuthoringTemplate authoringTemplate = EgovWCMCache.getATUnifiedService();
		if (authoringTemplate == null) {
			throw new Exception(bundle.getString("egov.wcm.cache.object.missing") + " АТ [" + EgovWCMCache.SERVICE_AUTHORING_TEMPLATE_UNIFIED_SERVICE + "]!");
		}
		
		// Check we have valid data from the AR service.
		AdmServiceInfoType admServiceInfoType = null;
		if (admServiceBatchDataType.getAdmServiceBatchDataType().get(0) != null && admServiceBatchDataType.getAdmServiceBatchDataType().get(0).getAdmServiceBatchInfo() != null) {
			admServiceInfoType = admServiceBatchDataType.getAdmServiceBatchDataType().get(0).getAdmServiceBatchInfo();
		} else {
			throw new Exception(bundle.getString("ar.service.adm.service.batch.info.is.empty"));
		}
		// Load serviceApplicationMethod category by admServiceInfoType.
		DocumentId[] serviceApplicationMethodDocIds = ARUtils.getWCMServiceApplicationMethodCategoriesFromAdmServiceInfoType(admServiceInfoType, bundle);
		if (serviceApplicationMethodDocIds == null || serviceApplicationMethodDocIds.length == 0) {
			throw new Exception(bundle.getString("ar.service.application.methods.categories.are.empty"));		
		}
				
		Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> createUnifiedServiceInWCM(): We are going to create NEW content.");
		if (content == null) {
			// Create content object.
			content = EgovWCMCache.getWorkspace().createContent(authoringTemplate.getId(), siteArea, null, ChildPosition.END);
		} else {
			content = getContent(content, authoringTemplate.getId(), siteArea, true);
		}
		// Populate common data.
		populateCommonData(content, administrativeService, administrativeStructure, admServiceMainDataType, bundle);
		// Populate Unified service data. (it is the same as "ServiceProvidedBySupplier" minus several fields,
		// which will be automatically skipped.
		populateServiceProvidedBySupplierData(content, admServiceInfoType, serviceApplicationMethodDocIds, false, bundle);
		// Save content to WCM.
		ARUtils.save(EgovWCMCache.getWorkspace(), content);
		
		// If "autoPublish" option is set in the portlet, move the content to next(publish) workflow stage.
		if (ARGatewayPortlet.autoPublish || createOtherData) {
			//boolean runExitActions, boolean runEntryActions, java.lang.String comment
			if (content.isDraft() || content.isDraftOfPublishedDocument()) {
				content.approve(true, true, null);
			}
		}
		
		Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> createUnifiedServiceInWCM() | content.getId().getId() = " + content.getId().getId());
		
		if (createOtherData) {
			Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> createUnifiedServiceInWCM() | createOtherData = " + createOtherData);
			administrativeService.setContent(content);
			administrativeService.setContentUUID(content.getId().getId());
			downloadOtherDataForAdministrativeServiceToWCM(administrativeService, false);
		}
		
		// Return the generated contentUUID.
		return content.getId().getId();
	}

	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String createServiceByProviderInWCM(ARAdministrativeService administrativeService, ARAdministrativeStructure administrativeStructure, AdmServiceMainDataType admServiceMainDataType, ArrayOfAdmServiceBatchDataType admServiceBatchDataType, ResourceBundle bundle) throws Exception {
		
		// Create content object.
		Content content = null;
		boolean edit = false;
		if (administrativeService.getContentUUID() != null && administrativeService.getContentUUID().trim().length() > 0) {
			try {
				content = (Content)EgovWCMCache.getWorkspace().getById(EgovWCMCache.getWorkspace().createDocumentId(administrativeService.getContentUUID()));
			} catch (Exception e) {
				Logger.log(Logger.ERROR_LEVEL, "ARServiceToWCMManagement : createServiceByProviderInWCM() : " + e.getMessage());
			}			
			if (content == null) {
				throw new Exception(bundle.getString("wcm.content.not.found") + " Content UUID [" + administrativeService.getContentUUID() + "]!");
			}
			if (EgovWCMCache.getWorkspace().isLocked(content.getId())) {
				throw new Exception(bundle.getString("wcm.content.locked") + " '" + content.getTitle()+ "'!");
			}
			edit = true;
		}
				
		AuthoringTemplate authoringTemplate = EgovWCMCache.getATServiceProvidedBySupplier();
		if (authoringTemplate == null) {
			throw new Exception(bundle.getString("egov.wcm.cache.object.missing") + " АТ [" + EgovWCMCache.SERVICE_AUTHORING_TEMPLATE_SERVICE_PROVIDED_BY_SUPPLIER + "]!");
		}
		String parentSiteAreaPath = EgovWCMCache.getWorkspace().getPathById(administrativeStructure.getContent().getParentId(), false, true);
		if (parentSiteAreaPath == null) {
			throw new Exception(bundle.getString("wcm.sa.not.found") + " SITEAREA ID [" + administrativeStructure.getContent().getParentId() + "]!");
		}
		if (parentSiteAreaPath.toLowerCase().startsWith(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME.toLowerCase())) {
			parentSiteAreaPath = parentSiteAreaPath.substring(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME.length());
		}
		
		Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> createServiceProviderInWCM() | parentSiteAreaPath = " + parentSiteAreaPath);
		
		String siteAreaName = EgovWCMCache.SERVICES_SITE_AREA_NAME_BY_SUPPLIER_PREFIX + administrativeStructure.getBatchId().toString();
					
		Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> createServiceProviderInWCM() | siteAreaName = " + siteAreaName);

		DocumentId siteArea = null;
		DocumentIdIterator iterator = EgovWCMCache.getWorkspace().findAllByPath(parentSiteAreaPath + "/" + siteAreaName, DocumentTypes.SiteArea, Workspace.WORKFLOWSTATUS_PUBLISHED, new DocumentLibrary[] { EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)});
		if (iterator.hasNext()) { // SiteArea was founded.									
			siteArea = iterator.next();
		}
		
		if (siteArea == null) {
			throw new Exception(bundle.getString("wcm.sa.not.found") + " SITEAREA [" + parentSiteAreaPath + "/" + siteAreaName + "]!");			
		}
		Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> createServiceProviderInWCM() | siteAreaPath = " + parentSiteAreaPath + "/" + siteAreaName);
		
		// Check we already has content, but not editing current so we fire exception.
		if (!edit) { 
			iterator = EgovWCMCache.getWorkspace().findAllByPath(parentSiteAreaPath + "/" + siteAreaName + "/" + administrativeService.getServiceNumber().toString(), DocumentTypes.Content, Workspace.WORKFLOWSTATUS_ALL, new DocumentLibrary[] { EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)});
			if (iterator.hasNext()) { // Existing content was founded, but is not attached to our DB, so fire exception.									
				throw new Exception(bundle.getString("wcm.existing.content.found") + " CONTENT [" + parentSiteAreaPath + "/" + siteAreaName + "/" + administrativeService.getServiceNumber().toString() + "]!");
			}
		}
		
		// Check we have valid data from the AR service.
		AdmServiceInfoType admServiceInfoType = null;
		if (admServiceBatchDataType.getAdmServiceBatchDataType().get(0) != null && admServiceBatchDataType.getAdmServiceBatchDataType().get(0).getAdmServiceBatchInfo() != null) {
			admServiceInfoType = admServiceBatchDataType.getAdmServiceBatchDataType().get(0).getAdmServiceBatchInfo();
		} else {
			throw new Exception(bundle.getString("ar.service.adm.service.batch.info.is.empty"));
		}
		// Load serviceApplicationMethod category by admServiceInfoType.
		DocumentId[] serviceApplicationMethodDocIds = ARUtils.getWCMServiceApplicationMethodCategoriesFromAdmServiceInfoType(admServiceInfoType, bundle);
		if (serviceApplicationMethodDocIds == null || serviceApplicationMethodDocIds.length == 0) {
			throw new Exception(bundle.getString("ar.service.application.methods.categories.are.empty"));		
		}
				
		// Load content.
		content = getContent(content, authoringTemplate.getId(), siteArea, edit);		
		// Populate common data.
		populateCommonData(content, administrativeService, administrativeStructure, admServiceMainDataType, bundle);
		// Populate ServiceProvidedBySupplier data.
		populateServiceProvidedBySupplierData(content, admServiceInfoType, serviceApplicationMethodDocIds, edit, bundle);
		// Save content to WCM.
		ARUtils.save(EgovWCMCache.getWorkspace(), content);
		
		// If "autoPublish" option is set in the portlet, move the content to next(publish) workflow stage.
		if (ARGatewayPortlet.autoPublish) {
			//boolean runExitActions, boolean runEntryActions, java.lang.String comment
			if (content.isDraft() || content.isDraftOfPublishedDocument()) {
				content.approve(true, true, null);
			}
		}
		
		Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> createServiceProviderInWCM() | content.getId().getId() = " + content.getId().getId());
		
		// Return the generated contentUUID.
		return content.getId().getId();
	}
	
	private void populateCommonData(Content content, ARAdministrativeService administrativeService, ARAdministrativeStructure administrativeStructure, AdmServiceMainDataType admServiceMainDataType, ResourceBundle bundle) throws Exception {
		// name.
		content.setName(administrativeService.getServiceNumber().toString());
		// title.
		String title = administrativeService.getName().trim();
		if (title.length() > 125) {
			title = title.substring(0, 122);
			int pos = title.lastIndexOf(" ");
			if (pos != -1) {
				title = title.substring(0, pos);
			}
			title += "...";
		}
		content.setTitle(title);
		if (content.getDescription() == null || content.getDescription().trim().length() == 0) {
			// description.		
			content.setDescription(bundle.getString("wcm.default.text.please.enter.short.description"));
		}
		// serviceNumber.
		ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_SERVICE_NUMBER_NAME, administrativeService.getServiceNumber().toString());		
		// serviceName.
		ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_SERVICE_NAME_NAME, administrativeService.getName());
		// isInternalAdminService.
		ARUtils.populateOptionSelectionField(content, EgovWCMCache.SERVICE_FIELD_IS_INTERNAL_ADMIN_SERVICE_NAME, (admServiceMainDataType.isIsInternalAdminService() ? EgovWCMCache.getCategoryCommonYes().getId() : EgovWCMCache.getCategoryCommonNo().getId()));
		// regulatoryAct.
		ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_REGULATORY_ACT_NAME, ARUtils.formatRegulatoryActsDataForRichText(admServiceMainDataType.getLegalBasis()));
		// serviceSupplier.
		ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_SERVICE_SUPPLIER_NAME, administrativeStructure.getContentUUID());
		// sectionNameAR. 
		ARUtils.populateOptionSelectionField(content, EgovWCMCache.SERVICE_FIELD_SECTION_NAME_AR_NAME, ARUtils.getWCMAdmSectionNameCategoryBySectionName(administrativeService.getSectionName(), bundle));
		// inputType.
		ARUtils.populateOptionSelectionField(content, EgovWCMCache.SERVICE_FIELD_INPUT_TYPE_NAME, EgovWCMCache.getCategoryInputTypeFromAR().getId());
		// status. -> Active
		ARUtils.populateOptionSelectionField(content, EgovWCMCache.SERVICE_FIELD_STATUS_NAME, EgovWCMCache.getCategoryServiceStatusActive().getId());
	}
	
	@SuppressWarnings({ "rawtypes"})
	private void populateServiceProvidedBySupplierData(Content content, AdmServiceInfoType admServiceInfoType, DocumentId[] serviceApplicationMethodDocIds, boolean edit, ResourceBundle bundle) throws Exception {
		// serviceDescription.
		if (!edit) {
			if (admServiceInfoType.getStages() != null && admServiceInfoType.getStages().getStage() != null && admServiceInfoType.getStages().getStage().size() > 0) {
				ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_SERVICE_DESCRIPTION_NAME, ARUtils.formatStagesDataForRichText(admServiceInfoType.getStages().getStage()));
			} 				
		}
		// possibleWaysToApply.
		ARUtils.populateOptionSelectionField(content, EgovWCMCache.SERVICE_FIELD_POSSIBLE_WAYS_TO_APPLY_NAME, serviceApplicationMethodDocIds);
		if (content.isNew()) {
			// applicationForm.
			if (admServiceInfoType.getModelDocuments() != null && admServiceInfoType.getModelDocuments().getDocument() != null && admServiceInfoType.getModelDocuments().getDocument().size() > 0) {
				ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_APPLICATION_FORM_NAME, ARUtils.formatmModelDocumentsDataForRichText(admServiceInfoType.getModelDocuments().getDocument()));
			} 
		}
		// terms.
		if (admServiceInfoType.getGrantTerm() != null) {
			ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_TERMS_NAME, admServiceInfoType.getGrantTerm());
		}
		// administrationAuthority.
		if (admServiceInfoType.getProvisionGovBodyName() != null) {
			ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_ADMINISTRATION_AUTHORITY_NAME, admServiceInfoType.getProvisionGovBodyName());
		}
		// provisionEAddress.
		if (admServiceInfoType.getProvisionEAddress() != null) {
			ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_PROVISION_E_ADDRESS_NAME, admServiceInfoType.getProvisionEAddress());
		}
		// paymentInfo.
		if (admServiceInfoType.getPaymentInfo() != null) {
			ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_PAYMENT_INFO_NAME, ARUtils.formatPaymentInfoDataForRichText(admServiceInfoType.getPaymentInfo()));
		}
		// paymentMethods.
		if (admServiceInfoType.getPaymentInfo() != null && admServiceInfoType.getPaymentInfo().getPaymentMethods() != null &&  admServiceInfoType.getPaymentInfo().getPaymentMethods().size() > 0) {
			ARUtils.populateOptionSelectionField(content, EgovWCMCache.SERVICE_FIELD_PAYMENT_METHODS_NAME, ARUtils.getWCMPaymentMethodsCategoriesFromAdmServiceInfoType(admServiceInfoType));
		} else if (edit) {
			ARUtils.clearOptionSelectionField(content, EgovWCMCache.SERVICE_FIELD_PAYMENT_METHODS_NAME);
		}
		// administrativeSupplyUnits.
		if (admServiceInfoType.getServicingUnitContactData() != null && admServiceInfoType.getServicingUnitContactData().size() > 0) {
			ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_ADMINISTRATIVE_SUPPLY_UNITS_NAME, ARUtils.formatAdministrativeSupplyUnitsDataForRichText(admServiceInfoType.getServicingUnitContactData(), bundle));
		}
	}
	
	@SuppressWarnings("unchecked")
	public String downloadOtherDataForAdministrativeServiceToWCM(ARAdministrativeService administrativeService, boolean onlyTermsAndPaymentInfo) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> downloadOtherDataForAdministrativeServiceToWCM(administrativeService, " + onlyTermsAndPaymentInfo + ") start...");
		// Load all batches for given Administrative service.
		AdmServiceBatchesType admServiceBatchType = ARServicesLoader.loadAdmServiceBatches(administrativeService.getServiceNumber().longValue());
		if (admServiceBatchType == null || admServiceBatchType.getBatchIdentNumber() == null || admServiceBatchType.getBatchIdentNumber().size() == 0) {
			throw new Exception("Възникна грешка при опит за извличането на данни от Административния регистър!");
			
		}
		ArrayList<Document> pathArr = null;
		String path = "";
		DocumentId<Document> siteAreaId = null;
		Content content = administrativeService.getContent();
		ArrayOfAdmServiceBatchDataType admServiceBatchDataType = null;
		ARAdministrativeStructure[] administrativeStructures = null;
		
		// Load all AdministrativeStructures that we have in our DB, by IdentificationNumber.
		String batchIdentNumbers = "";
		for (int i = 0; i < admServiceBatchType.getBatchIdentNumber().size(); i++) {
			if (batchIdentNumbers.trim().length() > 0) {
				batchIdentNumbers += ",";
			}
			//batchIdentNumbers += admServiceBatchType.getBatchIdentNumber().get(i).replaceFirst("^0+(?!$)", "");			
			batchIdentNumbers += "'" + admServiceBatchType.getBatchIdentNumber().get(i) + "'";			
		}	
		ARStructureManagement management = new ARStructureManagement();
		//administrativeStructures = management.loadAllAdministrativeStructuresByBatchIds(batchIdentNumbers);
		administrativeStructures = management.loadAllAdministrativeStructuresByIdentificationNumbers(batchIdentNumbers);
		if (administrativeStructures == null) {
			throw new Exception("Няма въведени Административни структури в системата по подадените номера!" + " batchIds [" + batchIdentNumbers.replaceAll("'","") + "]");
		}
		// Skip this check for services provided by ALL_ADMINISTRATIONS.
		if (!EgovWCMCache.AR_SERVICE_SECTION_NAME_ALL_ADMINISTRATIONS.equalsIgnoreCase(administrativeService.getSectionName())) {
			// If lengths do not match, fire exception.
			if (administrativeStructures.length != admServiceBatchType.getBatchIdentNumber().size()) {
				ArrayList<String> batchesInDBArr = new ArrayList<String>();
				String[] batchIdentNumbersArr = batchIdentNumbers.replaceAll("'","").split(",");
				for (int i = 0; i < administrativeStructures.length; i++) {
					batchesInDBArr.add(administrativeStructures[i].getBatchId().toString());
				}
				for (int i = 0; i < batchIdentNumbersArr.length; i++) {
					if (!batchesInDBArr.contains(batchIdentNumbersArr[i])) {
						throw new Exception("Липсва административна структура" + " batchId [" + batchIdentNumbersArr[i] + "]");
					}
				}
				throw new Exception("Липсва административна структура");
			}
		}
		
		// We check suppliers are added to WCM and populate Content object to the administrativeStructures array.
		administrativeStructures = checkSuppliersAreAddedToWCM(administrativeService, administrativeStructures);
		
		AuthoringTemplate authoringTemplate = EgovWCMCache.getATAdditionalDataOfServiceProvidedBySupplier();
		if (authoringTemplate == null) {
			throw new Exception("Липсва кеш обект" + " АТ [" + EgovWCMCache.SERVICE_AUTHORING_TEMPLATE_ADDITIONAL_DATA_OF_SERVICE_PROVIDED_BY_SUPPLIER + "]!");
		}		

		if (administrativeStructures.length > 0) {
			pathArr = ARUtils.getPath(content.getParentId(), null, null);
			if (pathArr == null || pathArr.size() < 2) {
				throw new Exception("Възникна грешка при извличането на пътя до унифицираната услуга!");
			}							
			for (int i = pathArr.size() - 1; i >= 0; i--) {
				path += "/" + pathArr.get(i).getName();
			}			
			path = "/egov" + path;
		}
		Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> downloadOtherDataForAdministrativeServiceToWCM() | PATH = " + path);
		boolean isNewSiteArea = true;
		// Check content exists.
		DocumentIdIterator<Document> iterator = EgovWCMCache.getWorkspace().findAllByPath(path + "/" + content.getName() + EgovWCMCache.SERVICES_SITE_AREA_NAME_UNIFIED_SERVICE_SUFFIX, DocumentTypes.SiteArea, Workspace.WORKFLOWSTATUS_PUBLISHED, new DocumentLibrary[] { EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)});
		if (iterator.hasNext()) { // Site area was founded.				
			siteAreaId = iterator.next();		
			isNewSiteArea = false;
			Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> downloadOtherDataForAdministrativeServiceToWCM() | siteArea found = " + siteAreaId.getName());
		}  else {			
			String title = content.getTitle();
			if (title.length() > (125 - EgovWCMCache.SERVICES_SITE_AREA_TITLE_UNIFIED_SERVICE_SUFFIX.length())) {
				title = title.substring(0, 125 - (EgovWCMCache.SERVICES_SITE_AREA_TITLE_UNIFIED_SERVICE_SUFFIX.length() + 3));
				int pos = title.lastIndexOf(" ");
				if (pos != -1) {
					title = title.substring(0, pos);
				}
				title += "...";
			}
			// We are going to create the siteArea.
			SiteArea newSiteArea = EgovWCMCache.getWorkspace().createSiteArea(content.getParentId(), content.getId(), ChildPosition.AFTER);
			newSiteArea.setName(content.getName() + EgovWCMCache.SERVICES_SITE_AREA_NAME_UNIFIED_SERVICE_SUFFIX);
			newSiteArea.setTitle(title + EgovWCMCache.SERVICES_SITE_AREA_TITLE_UNIFIED_SERVICE_SUFFIX);
			Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> downloadOtherDataForAdministrativeServiceToWCM() We are going to create NEW siteArea [" + content.getName() + EgovWCMCache.SERVICES_SITE_AREA_NAME_UNIFIED_SERVICE_SUFFIX + "]");
			// Save siteArea to WCM.
			ARUtils.save(EgovWCMCache.getWorkspace(), newSiteArea);		
			siteAreaId = newSiteArea.getId();
		}
		List<String> contentNames = new ArrayList<String>(); 
		String identificaitonNumber = null;
		for (int i = 0; i < administrativeStructures.length; i++) {
//			if (administrativeService.getServiceNumber().intValue() == 1997 && administrativeStructures[i].getBatchId().intValue() != 541) {
//				continue;
//			}
			identificaitonNumber = administrativeStructures[i].getIdentificationNumber().replaceFirst("^0+(?!$)", "");
			// Load "Service Batch Data Type" for the given Administrative service.
			admServiceBatchDataType = ARServicesLoader.loadAdmServiceBatchDataType(identificaitonNumber, administrativeService.getServiceNumber().longValue());
			
			if (admServiceBatchDataType == null || admServiceBatchDataType.getAdmServiceBatchDataType() == null || admServiceBatchDataType.getAdmServiceBatchDataType().size() == 0) {			
				throw new Exception("Възникна грешка при опит за извличането на данни от Административния регистър!");
			}	
			if (admServiceBatchDataType.getAdmServiceBatchDataType().get(0) == null || admServiceBatchDataType.getAdmServiceBatchDataType().get(0).getAdmServiceBatchInfo() == null) {
				// Empty AR data found - skip it.
				Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> downloadOtherDataForAdministrativeServiceToWCM() : Empty AR data found for identificationNumber=" + identificaitonNumber);
				continue;
			}			
			createOtherDataProvidedBySupplierInWCM(administrativeService, administrativeStructures[i], path, siteAreaId, authoringTemplate.getId(), admServiceBatchDataType, onlyTermsAndPaymentInfo);
			contentNames.add(administrativeStructures[i].getBatchId().toString());
		}
		
		Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> downloadOtherDataForAdministrativeServiceToWCM() | contentNames.size() = " + contentNames.size());
		
		// We need to check wether content was removed from AR, so we need to delete it too.
		if (!isNewSiteArea) {
			SiteArea sa = (SiteArea)EgovWCMCache.getWorkspace().getById(siteAreaId);
			if (sa != null) {
				iterator = sa.getDirectChildren(Workspace.WORKFLOWSTATUS_PUBLISHED);
				if (iterator != null) {
					DocumentId<Document> docId = null;
					while (iterator.hasNext()) {
						docId = iterator.next();
						if (docId.getType().isOfType(DocumentTypes.Content) 
								&& !contentNames.contains(docId.getName())) {
							try {
								Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> downloadOtherDataForAdministrativeServiceToWCM() | remove content = " + docId.getName());
//								// Delete content.
								if (EgovWCMCache.getWorkspace().isLocked(docId)) {
									EgovWCMCache.getWorkspace().unlock(docId);	
								}
								EgovWCMCache.getWorkspace().delete(docId);								
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					}
				}
			}			
		}
		contentNames.clear();
		contentNames = null;
		return administrativeService.getContentUUID();
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void createOtherDataProvidedBySupplierInWCM(ARAdministrativeService administrativeService, ARAdministrativeStructure administrativeStructure, String path, DocumentId siteArea, DocumentId authoringTemplate, ArrayOfAdmServiceBatchDataType admServiceBatchDataType, boolean onlyTermsAndPaymentInfo) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> createOtherDataProvidedBySupplierInWCM(administrativeService, administrativeStructure, " + path + ", siteArea, admServiceBatchDataType, " + onlyTermsAndPaymentInfo + ") start...");
		// Create content object.
		Content content = null;
		boolean edit = false;

		AdmServiceInfoType admServiceInfoType = admServiceBatchDataType.getAdmServiceBatchDataType().get(0).getAdmServiceBatchInfo();		
			
		// Check content exists.
		DocumentId contentId = null;
		DocumentIdIterator iterator = EgovWCMCache.getWorkspace().findAllByPath(path + "/" + siteArea.getName() + "/" + administrativeStructure.getBatchId().toString(), DocumentTypes.Content, Workspace.WORKFLOWSTATUS_PUBLISHED, new DocumentLibrary[] { EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)});
		if (iterator.hasNext()) { // Content was founded.				
			contentId = iterator.next();
			content = (Content)EgovWCMCache.getWorkspace().getById(contentId);
			if (content == null) {
				throw new Exception("Съдържанието не беше намерено!" + " Content UUID [" + contentId.getId() + "]!");
			}
			if (EgovWCMCache.getWorkspace().isLocked(content.getId())) {
				throw new Exception("Съдържанието е заключено!" + " '" + content.getTitle()+ "'!");
			}
			edit = true;
			Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> createOtherDataProvidedBySupplierInWCM() | content found = " + content.getTitle());
		} 
		
		boolean hasChange = true;
		if (edit && onlyTermsAndPaymentInfo) {
			hasChange = hasChangeOtherData(content, admServiceInfoType);
			if (!hasChange) {
				Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> createOtherDataProvidedBySupplierInWCM() | NO CHANGE [" + content.getName() + "][" + content.getTitle() + "]");
			}
		}
		
		if (hasChange) {
			if (edit) {
				Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> createOtherDataProvidedBySupplierInWCM() | CHANGE FOUND FOR -> [" + content.getName() + "][" + content.getTitle() + "]");
			} else {
				Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> createOtherDataProvidedBySupplierInWCM() | GOING TO CREATE NEW CONTENT");
			}
			// Load content.
			content = getContentOtherData(content, authoringTemplate, siteArea, edit);		
			// Populate data.
			populateOtherDataProvidedBySupplier(content, administrativeService, administrativeStructure, admServiceInfoType, edit, onlyTermsAndPaymentInfo);
			// Save content to WCM.
			ARUtils.save(EgovWCMCache.getWorkspace(), content);
			// We publish the content.
			if (content.isDraft() || content.isDraftOfPublishedDocument()) {
				content.approve(true, true, null);
			}
			
		}
		Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> createOtherDataProvidedBySupplierInWCM() | content.getId().getId() = " + content.getId().getId());
	}
	
	private void populateOtherDataProvidedBySupplier(Content content, ARAdministrativeService administrativeService, ARAdministrativeStructure administrativeStructure, AdmServiceInfoType admServiceInfoType, boolean edit, boolean onlyTermsAndPaymentInfo) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> populateOtherDataProvidedBySupplier() | batchId = " + administrativeStructure.getBatchId().toString());
		// If we are in update only terms and payment info mode.
		if (edit && onlyTermsAndPaymentInfo) {
			// terms.
			if (admServiceInfoType.getGrantTerm() != null) {
				//Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> [" + EgovWCMCache.SERVICE_FIELD_TERMS_NAME + "] = " + admServiceInfoType.getGrantTerm());
				ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_TERMS_NAME, admServiceInfoType.getGrantTerm());
			} else {
				ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_TERMS_NAME, "");
			}
			// paymentInfo.
			if (admServiceInfoType.getPaymentInfo() != null) {
				//Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> [" + EgovWCMCache.SERVICE_FIELD_PAYMENT_INFO_NAME + "] = " + ARUtils.formatPaymentInfoDataForRichText(admServiceInfoType.getPaymentInfo(), bundle));
				ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_PAYMENT_INFO_NAME, ARUtils.formatPaymentInfoDataForRichText(admServiceInfoType.getPaymentInfo()));
			} else {
				ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_TERMS_NAME, "");
			}
			// paymentMethods.
			if (admServiceInfoType.getPaymentInfo() != null && admServiceInfoType.getPaymentInfo().getPaymentMethods() != null &&  admServiceInfoType.getPaymentInfo().getPaymentMethods().size() > 0) {
				//Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> [" + EgovWCMCache.SERVICE_FIELD_PAYMENT_METHODS_NAME + "] = " + ARUtils.getWCMPaymentMethodsCategoriesFromAdmServiceInfoType(admServiceInfoType, bundle));
				ARUtils.populateOptionSelectionField(content, EgovWCMCache.SERVICE_FIELD_PAYMENT_METHODS_NAME, ARUtils.getWCMPaymentMethodsCategoriesFromAdmServiceInfoType(admServiceInfoType));
			} else {
				ARUtils.clearOptionSelectionField(content, EgovWCMCache.SERVICE_FIELD_PAYMENT_METHODS_NAME);
			}
			return;
		}
		
		// name.
		content.setName(administrativeStructure.getBatchId().toString());
		// title.
		String title = administrativeStructure.getName().trim();
		if (title.length() > 125) {
			title = title.substring(0, 122);
			int pos = title.lastIndexOf(" ");
			if (pos != -1) {
				title = title.substring(0, pos);
			}
			title += "...";
		}
		content.setTitle(title);
		//Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> name = " + administrativeStructure.getBatchId().toString());
		//Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> title = " + title);
		//Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> [" + EgovWCMCache.SERVICE_FIELD_SERVICE_SUPPLIER_NAME + "] = " + administrativeStructure.getContentUUID());
		// serviceSupplier.
		ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_SERVICE_SUPPLIER_NAME, administrativeStructure.getContentUUID());
		// provisionEAddress.
		if (admServiceInfoType.getProvisionEAddress() != null) {
			//Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> [" + EgovWCMCache.SERVICE_FIELD_PROVISION_E_ADDRESS_NAME + "] = " + admServiceInfoType.getProvisionEAddress());
			ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_PROVISION_E_ADDRESS_NAME, admServiceInfoType.getProvisionEAddress());
		}
		// terms.
		if (admServiceInfoType.getGrantTerm() != null) {
			//Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> [" + EgovWCMCache.SERVICE_FIELD_TERMS_NAME + "] = " + admServiceInfoType.getGrantTerm());
			ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_TERMS_NAME, admServiceInfoType.getGrantTerm());
		}
		// paymentInfo.
		if (admServiceInfoType.getPaymentInfo() != null) {
			//Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> [" + EgovWCMCache.SERVICE_FIELD_PAYMENT_INFO_NAME + "] = " + ARUtils.formatPaymentInfoDataForRichText(admServiceInfoType.getPaymentInfo(), bundle));
			ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_PAYMENT_INFO_NAME, ARUtils.formatPaymentInfoDataForRichText(admServiceInfoType.getPaymentInfo()));
		}
		// paymentMethods.
		if (admServiceInfoType.getPaymentInfo() != null && admServiceInfoType.getPaymentInfo().getPaymentMethods() != null &&  admServiceInfoType.getPaymentInfo().getPaymentMethods().size() > 0) {
			//Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> [" + EgovWCMCache.SERVICE_FIELD_PAYMENT_METHODS_NAME + "] = " + ARUtils.getWCMPaymentMethodsCategoriesFromAdmServiceInfoType(admServiceInfoType, bundle));
			ARUtils.populateOptionSelectionField(content, EgovWCMCache.SERVICE_FIELD_PAYMENT_METHODS_NAME, ARUtils.getWCMPaymentMethodsCategoriesFromAdmServiceInfoType(admServiceInfoType));
		} else if (edit) {
			ARUtils.clearOptionSelectionField(content, EgovWCMCache.SERVICE_FIELD_PAYMENT_METHODS_NAME);
		}
		// status. -> Active
		ARUtils.populateOptionSelectionField(content, EgovWCMCache.SERVICE_FIELD_STATUS_NAME, EgovWCMCache.getCategoryServiceStatusActive().getId());
	}

	@SuppressWarnings("rawtypes")
	private boolean hasChangeOtherData (Content content, AdmServiceInfoType admServiceInfoType) throws Exception {
		String terms = ARUtils.getTextField(content, EgovWCMCache.SERVICE_FIELD_TERMS_NAME);
		if ((terms == null && admServiceInfoType.getGrantTerm() != null) || (terms != null && !terms.equals(admServiceInfoType.getGrantTerm()))) {
			return true;
		}
		String paymentInfo = ARUtils.getTextField(content, EgovWCMCache.SERVICE_FIELD_PAYMENT_INFO_NAME);
		if ((paymentInfo == null && admServiceInfoType.getPaymentInfo() != null) || (paymentInfo != null && !paymentInfo.equals(ARUtils.formatPaymentInfoDataForRichText(admServiceInfoType.getPaymentInfo())))) {
			return true;
		}
		DocumentId[] categoriesIds = ARUtils.getOptionSelectionCategoriesField(content, EgovWCMCache.SERVICE_FIELD_PAYMENT_METHODS_NAME);
		if ((categoriesIds == null || categoriesIds.length == 0) && admServiceInfoType.getPaymentInfo() != null && admServiceInfoType.getPaymentInfo().getPaymentMethods() != null &&  admServiceInfoType.getPaymentInfo().getPaymentMethods().size() > 0) {
			return true;
		} else if ((categoriesIds != null && categoriesIds.length > 0) && (admServiceInfoType.getPaymentInfo() == null || admServiceInfoType.getPaymentInfo().getPaymentMethods() == null ||  admServiceInfoType.getPaymentInfo().getPaymentMethods().size() == 0)) {
			return true;
		} else {
			DocumentId[] newCategoriesIds = ARUtils.getWCMPaymentMethodsCategoriesFromAdmServiceInfoType(admServiceInfoType);
			if (categoriesIds != null && categoriesIds.length > 0) { 
				if (newCategoriesIds == null || newCategoriesIds.length == 0 || categoriesIds.length != newCategoriesIds.length) {				
					return true;
				} else {
					boolean founded = false;
					for (int i = 0; i < categoriesIds.length; i++) {
						founded = false;
						for (int j = 0; j < newCategoriesIds.length; j++) {
							if (categoriesIds[i].getId().equalsIgnoreCase(newCategoriesIds[j].getId())) {
								founded = true;
								break;
							}
						}
						if (!founded) {
							return true;
						}
					}
				}
			}
		}
		return false;
	}
	
	@SuppressWarnings({ "rawtypes"})
	private Content getContent(Content content, DocumentId authoringTemplate, DocumentId siteArea, boolean edit) throws Exception {
		if (!edit) {
			Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> getContent() We are going to create NEW content.");
			// Create content object.
			content = EgovWCMCache.getWorkspace().createContent(authoringTemplate, siteArea, null, ChildPosition.END);			
		} else {
			if (content.hasDraft()) {
				Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> getContent() Content has a draft so let's try to find it...");
				content = getDraftContent(content);
			} else if (content.isPublished()) {
				Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> getContent() Content is published, so we have to create draft document.");
				// Create draft content.
				content = (Content)content.createDraftDocument();
			}					
		}
		return content;
	}
	
	@SuppressWarnings({ "rawtypes"})
	private Content getContentOtherData(Content content, DocumentId authoringTemplate, DocumentId siteArea, boolean edit) throws Exception {
		if (!edit) {
			Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> getContent() We are going to create NEW content.");
			// Create content object.
			content = EgovWCMCache.getWorkspace().createContent(authoringTemplate, siteArea, null, ChildPosition.END);			
		} 
		return content;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Content getDraftContent(Content content) throws Exception {
		// Load the draft content.
		Reference[] references = EgovWCMCache.getWorkspace().getReferences(content.getId());
		if (references != null && references.length > 0) {
			Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> getDraftContent() Found " + references.length + " references.");
			DocumentId tmpDocId = null;
			Content tmpContent = null;
			for (int i = 0; i < references.length; i++) {
				tmpDocId = references[i].getRefererDocumentId();
				if (tmpDocId.getType().isOfType(DocumentTypes.Content) && tmpDocId.isDraft()) {
					tmpContent = (Content)EgovWCMCache.getWorkspace().getById(tmpDocId);
					// Check this content is our draft content.
					if (tmpContent.getParentId().getId().equalsIgnoreCase(content.getParentId().getId())) {																
						content = (Content)EgovWCMCache.getWorkspace().getById(tmpDocId);
						if (EgovWCMCache.getWorkspace().isLocked(content.getId())) {
							throw new Exception("Съдържанието е заключено!" + " '" + content.getTitle()+ "'!");
						}
						Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> getDraftContent() Draft content founded with UUID " + tmpDocId.getId() + ", breaking.");
						break;
					}
				}
			}
		}
		return content;
	}
	
	// This method is used for internal use ONLY!
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public int mergeOldWCMServiceWithNewOne(ARAdministrativeService administrativeService, String userDN, ResourceBundle bundle) throws Exception {	
		Logger.log(Logger.ERROR_LEVEL, "ARServiceToWCMManagement :  -> mergeOldWCMServiceWithNewOne started...");
		try {			
			// Search for content in WCM with title starts with the service number.
			Query query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
			// filter by library.
			query.addSelector(Selectors.libraryEquals(EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)));
			// filter by services (old) AT ONLY.
		 	query.addSelector(
					Selectors.authoringTemplateIn(
						new DocumentId[] {
							EgovWCMCache.getServiceAuthoringTemplate(),
							EgovWCMCache.getServiceStateAuthoringTemplate(),
							EgovWCMCache.getServiceMetaAuthoringTemplate()
						}
					)
			);
			// filter by published.
			query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
			// filter by title.
			query.addSelector(Selectors.titleLike("%" + administrativeService.getServiceNumber() + " %"));
			query.returnIds();
			try {
			     ResultIterator resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);			     
			     if (resultIterator.hasNext()) {
			    	 Logger.log(Logger.ERROR_LEVEL, "ARServiceToWCMManagement :  -> mergeOldWCMServiceWithNewOne founded [" + administrativeService.getServiceNumber() + "]!");
			    	 while (resultIterator.hasNext()) {
				    	 Logger.log(Logger.ERROR_LEVEL, "ARServiceToWCMManagement :  -> mergeOldWCMServiceWithNewOne founded, check for real title match!");
				    	 Content oldContent = (Content)EgovWCMCache.getWorkspace().getById((DocumentId)resultIterator.next(), true);
				    	 if (oldContent != null) {
				    		 if (!oldContent.getTitle().trim().startsWith(administrativeService.getServiceNumber() + " ")) {
				    			 Logger.log(Logger.ERROR_LEVEL, "ARServiceToWCMManagement :  -> mergeOldWCMServiceWithNewOne WRONG TITLE MATCH, continue...");
				    			 continue;
				    		 }
				    		Logger.log(Logger.ERROR_LEVEL, "ARServiceToWCMManagement :  -> mergeOldWCMServiceWithNewOne oldContent[" + oldContent.getTitle() + "]!");
				    		// Load new content, without parameter true, because we are going to modify it.
			    			Content newContent = null;
			    			try {
			    				newContent = (Content)EgovWCMCache.getWorkspace().getById(EgovWCMCache.getWorkspace().createDocumentId(administrativeService.getContentUUID()));
							} catch (Exception e) {
								Logger.log(Logger.ERROR_LEVEL, "ARServiceToWCMManagement : mergeOldWCMServiceWithNewOne() : " + e.getMessage());
							}			    			
			    			if (newContent == null) {
			    				throw new Exception(bundle.getString("wcm.service.content.not.found") + " Content UUID [" + administrativeService.getContentUUID() + "]!");
			    			}
			    			// prepare data for merging.
			    			String oid = ARUtils.getTextField(oldContent, "oid");			    			
			    			String prepareInAdvance = ARUtils.getTextField(oldContent, "prepareInAdvance");
			    			String result = ARUtils.getTextField(oldContent, "result");			    						    			
			    			String serviceDescription = ARUtils.getTextField(oldContent, "serviceDescription");
			    			String applicationForm = ARUtils.getLinkField(oldContent, "applicationForm");			    			
			    			String onlineApplicationDescription = ARUtils.getTextField(oldContent, "onlineApplicationDescription");
			    			String eauApplicationFormLink = ARUtils.getLinkField(oldContent, "eauApplicationFormLink");
			    			if (oid != null && oid.trim().length() > 0) {
			    				ARUtils.populateTextField(newContent, EgovWCMCache.SERVICE_FIELD_OID_NAME, oid);
			    			}
			    			if (prepareInAdvance != null && prepareInAdvance.trim().length() > 0) {
			    				ARUtils.populateTextField(newContent, EgovWCMCache.SERVICE_FIELD_PREPARE_IN_ADVANCE_NAME, ARUtils.clearRichTextFormatting(prepareInAdvance));
			    			}
			    			if (result != null && result.trim().length() > 0) {
			    				ARUtils.populateTextField(newContent, EgovWCMCache.SERVICE_FIELD_RESULT_NAME, ARUtils.clearRichTextFormatting(result));
			    			}
			    			if (serviceDescription != null && serviceDescription.trim().length() > 0) {
			    				ARUtils.populateTextField(newContent, EgovWCMCache.SERVICE_FIELD_SERVICE_DESCRIPTION_NAME, ARUtils.clearRichTextFormatting(serviceDescription));
			    			}
			    			if (applicationForm != null && applicationForm.trim().length() > 0) {
			    				ARUtils.populateTextField(newContent, EgovWCMCache.SERVICE_FIELD_APPLICATION_FORM_NAME, ARUtils.prepareApplicationForm(applicationForm));
			    			}
			    			if (onlineApplicationDescription != null && onlineApplicationDescription.trim().length() > 0) {
			    				ARUtils.populateTextField(newContent, EgovWCMCache.SERVICE_FIELD_ONLINE_APPLICATION_DESCRIPTION_NAME, ARUtils.clearRichTextFormatting(onlineApplicationDescription));
			    				// clear eauApplicationFormLink field data from AR.
			    				ARUtils.populateLinkField(newContent, EgovWCMCache.SERVICE_FIELD_EAU_APPLICATION_FORM_LINK_NAME, "");
			    			}
			    			if (eauApplicationFormLink != null && eauApplicationFormLink.trim().length() > 0) {
			    				// however if we have old data, we populate it.
			    				ARUtils.populateLinkField(newContent, EgovWCMCache.SERVICE_FIELD_EAU_APPLICATION_FORM_LINK_NAME, eauApplicationFormLink);
			    			}
			    			// Category mapping.
			    			DocumentId[] mainCategory = ARUtils.getOptionSelectionCategoriesField(oldContent, "taxonomy");
			    			DocumentId[] otherCategories = ARUtils.getOptionSelectionCategoriesField(oldContent, "taxonomyOther");
			    			ArrayList<DocumentId> foundedCategories = new ArrayList<DocumentId>();
			    			if (mainCategory != null && mainCategory.length > 0) {
			    				String mainCategoryId = ARUtils.getNewCategoryIdByOldCategoryIdMapping(mainCategory[0].getID());
			    				if (mainCategoryId != null) {
			    					foundedCategories.add(EgovWCMCache.getWorkspace().createDocumentId(mainCategoryId));
			    				}
			    			}
			    			if (otherCategories != null && otherCategories.length > 0) {
			    				String otherCategoryId = null;
			    				for (int i = 0; i < otherCategories.length; i++) {
			    					otherCategoryId = ARUtils.getNewCategoryIdByOldCategoryIdMapping(otherCategories[i].getID());
			    					if (otherCategoryId != null) {
			    						foundedCategories.add(EgovWCMCache.getWorkspace().createDocumentId(otherCategoryId));
			    					}
								}
			    			}
			    			if (foundedCategories != null && foundedCategories.size() > 0) {
			    				ARUtils.populateOptionSelectionField(newContent, EgovWCMCache.SERVICE_FIELD_CLASSIFICATION_NAME, (DocumentId[])foundedCategories.toArray(new DocumentId[foundedCategories.size()]));			    				
			    			}
			    			ARUtils.save(EgovWCMCache.getWorkspace(), newContent);			    			
				    	 }
				    	 return 1;
			    	 }
			     }
			} catch (QueryServiceException e) {
				Logger.log(Logger.ERROR_LEVEL, "ARServiceToWCMManagement :  -> mergeOldWCMServiceWithNewOne - error: " + e.getMessage());				 
			    e.printStackTrace();
			} 
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "ARServiceToWCMManagement :  -> mergeOldWCMServiceWithNewOne : " + e.getMessage());
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}	
		return 0;
	}
		

	// This method is used for internal use ONLY!
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public int mergeOldWCMServiceWithNewOneExtra(ARAdministrativeService administrativeService, String userDN, ResourceBundle bundle) throws Exception {	
		Logger.log(Logger.ERROR_LEVEL, "ARServiceToWCMManagement :  -> mergeOldWCMServiceWithNewOneExtra started...");
		try {			
			// Search for content in WCM with title starts with the service number.
			Query query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
			// filter by library.
			query.addSelector(Selectors.libraryEquals(EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)));
			// filter by services (old) AT ONLY.
			query.addSelector(
					Selectors.authoringTemplateIn(
							new DocumentId[] {
									EgovWCMCache.getServiceAuthoringTemplate(),
									EgovWCMCache.getServiceStateAuthoringTemplate(),
									EgovWCMCache.getServiceMetaAuthoringTemplate()
							}
							)
					);
			// filter by published.
			query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
			// filter by title.
			query.addSelector(Selectors.titleLike("%" + administrativeService.getServiceNumber() + " %"));
			query.returnIds();
			try {
				ResultIterator resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);			     
				if (resultIterator.hasNext()) {
					Logger.log(Logger.ERROR_LEVEL, "ARServiceToWCMManagement :  -> mergeOldWCMServiceWithNewOneExtra founded [" + administrativeService.getServiceNumber() + "]!");
					while (resultIterator.hasNext()) {
						Logger.log(Logger.ERROR_LEVEL, "ARServiceToWCMManagement :  -> mergeOldWCMServiceWithNewOneExtra founded, check for real title match!");
						Content oldContent = (Content)EgovWCMCache.getWorkspace().getById((DocumentId)resultIterator.next(), true);
						if (oldContent != null) {
							if (!oldContent.getTitle().trim().startsWith(administrativeService.getServiceNumber() + " ")) {
								Logger.log(Logger.ERROR_LEVEL, "ARServiceToWCMManagement :  -> mergeOldWCMServiceWithNewOneExtra WRONG TITLE MATCH, continue...");
								continue;
							}
							Logger.log(Logger.ERROR_LEVEL, "ARServiceToWCMManagement :  -> mergeOldWCMServiceWithNewOneExtra oldContent[" + oldContent.getTitle() + "]!");
							// Load new content, without parameter true, because we are going to modify it.
							Content newContent = null;
							try {
								newContent = (Content)EgovWCMCache.getWorkspace().getById(EgovWCMCache.getWorkspace().createDocumentId(administrativeService.getContentUUID()));								
							} catch (Exception e) {
								Logger.log(Logger.ERROR_LEVEL, "ARServiceToWCMManagement : mergeOldWCMServiceWithNewOneExtra() : " + e.getMessage());
							}
							if (newContent == null) {
								throw new Exception(bundle.getString("wcm.service.content.not.found") + " Content UUID [" + administrativeService.getContentUUID() + "]!");
							}
							// prepare data for merging.
							// load field data from old content.
							String administrationUnit = ARUtils.getTextField(oldContent, "administrationUnit");
							// load field data from new content.
							String administrativeInfoUnits = ARUtils.getTextField(newContent, EgovWCMCache.SERVICE_FIELD_ADMINISTRATIVE_INFO_UNITS_NAME);
							
							if (administrationUnit != null && administrationUnit.trim().length() > 0 
									&& (administrativeInfoUnits == null || administrativeInfoUnits.trim().length() == 0)) {
								ARUtils.populateTextField(newContent, EgovWCMCache.SERVICE_FIELD_ADMINISTRATIVE_INFO_UNITS_NAME, administrationUnit);							
								ARUtils.save(EgovWCMCache.getWorkspace(), newContent);
								return 1;
							}
						}						
					}
				}
			} catch (QueryServiceException e) {
				Logger.log(Logger.ERROR_LEVEL, "ARServiceToWCMManagement :  -> mergeOldWCMServiceWithNewOneExtra - error: " + e.getMessage());				 
				e.printStackTrace();
			} 
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "ARServiceToWCMManagement :  -> mergeOldWCMServiceWithNewOneExtra : " + e.getMessage());
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}	
		return 0;
	}

}
