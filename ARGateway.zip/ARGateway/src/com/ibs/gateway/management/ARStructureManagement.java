package com.ibs.gateway.management;

import java.sql.SQLException;
import java.util.ResourceBundle;

import com.ibs.gateway.ARConstants;
import com.ibs.gateway.db.DBTransaction;
import com.ibs.gateway.db.FinderException;
import com.ibs.gateway.db.QueryExecution;
import com.ibs.gateway.dbo.ARAdministrativeStructure;
import com.ibs.gateway.utils.ARUtils;

import bg.government.iisda.ras.BatchIdentificationInfoType;

public class ARStructureManagement {
	
	public int countStructures(String tab, String filterNumber, String filterName, String filterStatus, String filterState, String fitlerSynchronized) {
		try {
			QueryExecution qe = new QueryExecution();
			return qe.countStructures(tab, filterNumber, filterName, filterStatus, filterState, fitlerSynchronized, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	public ARAdministrativeStructure[] loadAllAdministrativeStructures(String filterNumber, String filterName, String filterStatus, String filterState, String fitlerSynchronized) {
		try {
			return ARAdministrativeStructure.findAllByFilter(filterNumber, filterName, filterStatus, filterState, fitlerSynchronized, null, null, null, null, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;	
	}
	
	public ARAdministrativeStructure[] loadAllAdministrativeStructures(String filterNumber, String filterName, String filterStatus, String filterState, String fitlerSynchronized, int start, int length, int orderColumn, String order) {
		try {
			return ARAdministrativeStructure.findAllByFilter(filterNumber, filterName, filterStatus, filterState, fitlerSynchronized, start, length, orderColumn, order, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public ARAdministrativeStructure[] loadAdministrativeStructuresForUpdate(String filterNumber, String filterName, String filterStatus, String filterState) {
		try {
			return ARAdministrativeStructure.findAllForUpdate(filterNumber, filterName, filterStatus, filterState, null, null, null, null, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	public ARAdministrativeStructure[] loadAdministrativeStructuresForUpdate(String filterNumber, String filterName, String filterStatus, String filterState, int start, int length, int orderColumn, String order) {
		try {
			return ARAdministrativeStructure.findAllForUpdate(filterNumber, filterName, filterStatus, filterState, start, length, orderColumn, order, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	public ARAdministrativeStructure[] loadAllBlockedAdministrativeStructures(String filterNumber, String filterName, String filterStatus, int start, int length, int orderColumn, String order) {
		try {
			return ARAdministrativeStructure.findAllBlocked(filterNumber, filterName, filterStatus, start, length, orderColumn, order, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public ARAdministrativeStructure[] loadAllBlockedAdministrativeStructures(String filterNumber, String filterName, String filterStatus) {
		try {
			return ARAdministrativeStructure.findAllBlocked(filterNumber, filterName, filterStatus, null, null, null, null, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public ARAdministrativeStructure[] loadAllAdministrativeStructuresByBatchIds(String batchIds) {
		try {
			return ARAdministrativeStructure.findAllByBatchIds(batchIds, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public ARAdministrativeStructure[] loadAllAdministrativeStructuresByIdentificationNumbers(String identificationNumbers) {
		try {
			return ARAdministrativeStructure.findAllByIdentificationNumbers(identificationNumbers, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}


	public int createAdministrativeStructure(BatchIdentificationInfoType batchIdentificationInfoType, String state, String hash, String userDN) {
		DBTransaction transaction = null;
		long currentTime = System.currentTimeMillis();
		try {
			transaction = new DBTransaction();
			ARAdministrativeStructure administrativeStructure = new ARAdministrativeStructure();
			administrativeStructure.setBatchId(batchIdentificationInfoType.getBatchID() + "");
			administrativeStructure.setType(batchIdentificationInfoType.getType().value());
			administrativeStructure.setIdentificationNumber(batchIdentificationInfoType.getIdentificationNumber());
			administrativeStructure.setName(batchIdentificationInfoType.getName());
			administrativeStructure.setAdmStructureKind(batchIdentificationInfoType.getAdmStructureKind().value());
			administrativeStructure.setUic(batchIdentificationInfoType.getUIC());
			administrativeStructure.setStatus(batchIdentificationInfoType.getStatus().value());
			// will be null for now, until AR update their service.
//			administrativeStructure.setLastUpdateDate(lastUpdateDate);
			administrativeStructure.setState(state); 
			administrativeStructure.setHash(hash); 
			administrativeStructure.setUserDN(userDN);
			administrativeStructure.setCreationDate(ARUtils.timeMillisToTimestamp(currentTime));			
			administrativeStructure.setOperationTime(ARUtils.timeMillisToTimestamp(currentTime));			
			administrativeStructure.create(transaction);
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println("ARAdministrativeStructureManagement : createAdministrativeStructure : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("ARAdministrativeStructureManagement : createAdministrativeStructure : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
		}
		return -1;
	}
	
	public int updateAdministrativeStructure(ARAdministrativeStructure administrativeStructure, BatchIdentificationInfoType batchIdentificationInfoType, String state, String hash, String userDN) {
		DBTransaction transaction = null;
		long currentTime = System.currentTimeMillis();
		try {
			transaction = new DBTransaction();
			if (administrativeStructure != null) {
				administrativeStructure.setBatchId(batchIdentificationInfoType.getBatchID() + "");
				administrativeStructure.setType(batchIdentificationInfoType.getType().value());
				administrativeStructure.setIdentificationNumber(batchIdentificationInfoType.getIdentificationNumber());
				administrativeStructure.setName(batchIdentificationInfoType.getName());
				administrativeStructure.setAdmStructureKind(batchIdentificationInfoType.getAdmStructureKind().value());
				administrativeStructure.setUic(batchIdentificationInfoType.getUIC());
				administrativeStructure.setStatus(batchIdentificationInfoType.getStatus().value());
				// will be null for now, until AR update their service.
//				administrativeStructure.setLastUpdateDate(lastUpdateDate);
				administrativeStructure.setState(state);
				administrativeStructure.setHash(hash);
				administrativeStructure.setUserDN(userDN);
				administrativeStructure.setOperationTime(ARUtils.timeMillisToTimestamp(currentTime));
				administrativeStructure.setChangeRegisterDate(ARUtils.timeMillisToTimestamp(currentTime));
				administrativeStructure.store(transaction); 
			}			
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println("ARAdministrativeStructureManagement : updateAdministrativeStructure : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("ARAdministrativeStructureManagement : updateAdministrativeStructure : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
		}
		return -1;
	}
	
	public int updateAdministrativeStructureState(ARAdministrativeStructure administrativeStructure, String state, String hash, String userDN) {
		DBTransaction transaction = null;
		long currentTime = System.currentTimeMillis();
		try {
			transaction = new DBTransaction();
			if (administrativeStructure != null) {
				administrativeStructure.setState(state);
				administrativeStructure.setHash(hash);
				administrativeStructure.setUserDN(userDN);
				administrativeStructure.setOperationTime(ARUtils.timeMillisToTimestamp(currentTime));
				administrativeStructure.setChangeRegisterDate(ARUtils.timeMillisToTimestamp(currentTime));
				administrativeStructure.store(transaction); 
			}			
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println("ARAdministrativeStructureManagement : updateAdministrativeStructureState : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("ARAdministrativeStructureManagement : updateAdministrativeStructureState : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
		}
		return -1;
	}
	
	public String sendAdministrativeStructureToWCM(String id, String userDN, ResourceBundle bundle) throws Exception {		
		try {
			ARAdministrativeStructure administrativeStructure = null;
			try {
				administrativeStructure = ARAdministrativeStructure.findById(id, null);
			} catch (FinderException e) {
				throw new Exception(bundle.getString("administrative.structure.was.not.found"));
			}			
			
			if (administrativeStructure == null) {
				throw new Exception(bundle.getString("administrative.structure.was.not.found"));
			}
			
			if (ARConstants.ADMINISTRATIVE_STRUCTURE_BLOCKED.equals(administrativeStructure.getBlocked())) {
				throw new Exception(bundle.getString("administrative.structure.should.be.unblocked.first"));
			}
			ARStructureToWCMManagement management = new ARStructureToWCMManagement();
			
			// Create content in WCM for the given AR.
			String contentUUID = management.sendAdministrativeStructureToWCM(administrativeStructure, bundle);
			
			if (contentUUID == null) {
				throw new Exception(bundle.getString("wcm.create.service.provider.error"));
			}
			// Update AR record accordingly.
			long currentTime = System.currentTimeMillis();		
			administrativeStructure.setUserDN(userDN);
			administrativeStructure.setOperationTime(ARUtils.timeMillisToTimestamp(currentTime));
			// We set contentUUID only if we create the content to WCM for the first time.
			if (administrativeStructure.getContentUUID() == null || administrativeStructure.getContentUUID().trim().length() == 0) {
				administrativeStructure.setContentUUID(contentUUID);
			}
			administrativeStructure.setSynchronized(ARConstants.ADMINISTRATIVE_STRUCTURE_SYNCHRONIZED);
			administrativeStructure.setState(ARConstants.ADMINISTRATIVE_STRUCTURE_STATE_PROCESSED);
			administrativeStructure.setSynchronizedDate(ARUtils.timeMillisToTimestamp(currentTime));
			administrativeStructure.store();
			return contentUUID;
		} catch (Exception e) {
			System.out.println("ARAdministrativeStructureManagement : sendAdministrativeStructureToWCM : " + e.getMessage());
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}		
	}
	
	public ARAdministrativeStructure blockAdministrativeStructure(String id, String userDN, ResourceBundle bundle) throws Exception {
		DBTransaction transaction = null;
		long currentTime = System.currentTimeMillis();
		try {
			transaction = new DBTransaction();
			ARAdministrativeStructure administrativeStructure = null;
			try {
				administrativeStructure = ARAdministrativeStructure.findById(id, transaction);
			} catch (FinderException e) {
				throw new Exception(bundle.getString("administrative.structure.was.not.found"));
			}			
			
			if (administrativeStructure != null) {
				administrativeStructure.setBlocked(ARConstants.ADMINISTRATIVE_STRUCTURE_BLOCKED);
				administrativeStructure.setUserDN(userDN);
				administrativeStructure.setOperationTime(ARUtils.timeMillisToTimestamp(currentTime));
				administrativeStructure.store(transaction);
			}			
			transaction.commit();	
			return administrativeStructure;
		} catch (Exception e) {
			System.out.println("ARAdministrativeStructureManagement : blockAdministrativeStructure : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("ARAdministrativeStructureManagement : blockAdministrativeStructure : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			throw new Exception(e.getMessage());
		}		
	}
	
	public ARAdministrativeStructure unblockAdministrativeStructure(String id, String userDN, ResourceBundle bundle) throws Exception {
		DBTransaction transaction = null;
		long currentTime = System.currentTimeMillis();
		try {
			transaction = new DBTransaction();
			ARAdministrativeStructure administrativeStructure = null;
			try {
				administrativeStructure = ARAdministrativeStructure.findById(id, transaction);
			} catch (FinderException e) {
				throw new Exception(bundle.getString("administrative.structure.was.not.found"));
			}			
			
			if (administrativeStructure != null) {
				administrativeStructure.setBlocked(null);
				administrativeStructure.setUserDN(userDN);
				administrativeStructure.setOperationTime(ARUtils.timeMillisToTimestamp(currentTime));
				administrativeStructure.store(transaction);
			}			
			transaction.commit();	
			return administrativeStructure;
		} catch (Exception e) {
			System.out.println("ARAdministrativeStructureManagement : unblockAdministrativeStructure : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("ARAdministrativeStructureManagement : unblockAdministrativeStructure : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			throw new Exception(e.getMessage());
		}		
	}

	public ARAdministrativeStructure deleteAdministrativeStructure(String id, ResourceBundle bundle) throws Exception {
		DBTransaction transaction = null;
		try {
			transaction = new DBTransaction();
			ARAdministrativeStructure administrativeStructure = null;
			try {
				administrativeStructure = ARAdministrativeStructure.findById(id, transaction);
			} catch (FinderException e) {
				throw new Exception(bundle.getString("administrative.structure.was.not.found"));
			}			
			administrativeStructure.remove(transaction);						
			transaction.commit();	
			return administrativeStructure;
		} catch (Exception e) {
			System.out.println("ARAdministrativeStructureManagement : deleteAdministrativeStructure : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("ARAdministrativeStructureManagement : deleteAdministrativeStructure : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			throw new Exception(e.getMessage());
		}		
	}

}
