package com.ibs.gateway.management;

import java.util.ArrayList;
import java.util.ResourceBundle;

import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.AuthoringTemplate;
import com.ibm.workplace.wcm.api.Category;
import com.ibm.workplace.wcm.api.ChildPosition;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentLibrary;
import com.ibm.workplace.wcm.api.DocumentTypes;
import com.ibm.workplace.wcm.api.Reference;
import com.ibm.workplace.wcm.api.SiteArea;
import com.ibm.workplace.wcm.api.Workspace;
import com.ibs.gateway.ARGatewayPortlet;
import com.ibs.gateway.ARServiceHelper;
import com.ibs.gateway.ARStructuresLoader;
import com.ibs.gateway.dbo.ARAdministrativeService;
import com.ibs.gateway.dbo.ARAdministrativeStructure;
import com.ibs.gateway.utils.ARUtils;
import com.ibs.gateway.utils.Logger;

public class ARStructureToWCMManagement {
	
	public String sendAdministrativeStructureToWCM(ARAdministrativeStructure administrativeStructure, ResourceBundle bundle) throws Exception {	
		
		// Load "Batch Details" for the given Administrative structure.
		bg.government.iisda.ras.BatchType batchType = ARStructuresLoader.loadBatchDetails(administrativeStructure.getIdentificationNumber());
		
		if (batchType == null || batchType.getAdministration() == null || batchType.getAdministration().getAddress() == null) {
			throw new Exception(bundle.getString("ar.batch.details.not.loaded"));
		}
		
		return createServiceProviderInWCM(administrativeStructure, batchType, bundle);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String createServiceProviderInWCM(ARAdministrativeStructure administrativeStructure, bg.government.iisda.ras.BatchType batchType, ResourceBundle bundle) throws Exception {
		
		// Create content object.
		Content content = null;
		boolean edit = false;
		boolean moveOperation = false;
		String contentParentSAName = null;
		if (administrativeStructure.getContentUUID() != null && administrativeStructure.getContentUUID().trim().length() > 0) {
			try {
				content = (Content)EgovWCMCache.getWorkspace().getById(EgovWCMCache.getWorkspace().createDocumentId(administrativeStructure.getContentUUID()));
			} catch (Exception e) {
				Logger.log(Logger.ERROR_LEVEL, "ARStructureToWCMManagemnt : createServiceProviderInWCM() : " + e.getMessage());
			}
			if (content == null) {
				throw new Exception(bundle.getString("wcm.content.not.found") + " Content UUID [" + administrativeStructure.getContentUUID() + "]!");
			}
			if (EgovWCMCache.getWorkspace().isLocked(content.getId())) {
				throw new Exception(bundle.getString("wcm.content.locked") + " '" + content.getTitle()+ "'!");
			}
			edit = true;
			contentParentSAName = content.getParentId().getName();
			Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> createServiceProviderInWCM() | contentParentSAName = " + contentParentSAName);
		}
				
		AuthoringTemplate at = ARUtils.getATByAdmStructureKind(administrativeStructure);
		if (at == null) {
			throw new Exception(bundle.getString("egov.wcm.cache.object.missing") + " АТ [" + administrativeStructure.getAdmStructureKind() + "]!");
		}
		String siteAreaName = ARUtils.buildWCMSiteAreaNameFromAdministrativeStructure(administrativeStructure);
		if (siteAreaName == null) {
			throw new Exception(bundle.getString("ar.mapping.error") + " SA [" + administrativeStructure.getAdmStructureKind() + "]!");
		}
		if (edit && contentParentSAName != null && !siteAreaName.equalsIgnoreCase(contentParentSAName)) {
			moveOperation = true;
			Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> createServiceProviderInWCM() | contentParentSAName != siteAreaName -> " + contentParentSAName + " != " + siteAreaName);			
		}
		String parentSiteAreaName = "";
		
		// We load customData object needed for Specialized Territorial Administration.
		ArrayList customData = null;		
		if (ARUtils.isAdmSpecializedTerritorial(administrativeStructure)) { 
			customData = ARUtils.getAdmSpecializedLocalCustomData(administrativeStructure); // returns ArrayList<Content,String,Category>
			if (customData == null || customData.size() != 4) {
				throw new Exception(bundle.getString("adm.specialized.local.custom.data.error"));
			}
			parentSiteAreaName = siteAreaName + "/";
			// We get the siteAreaName from the customData object.
			siteAreaName = (String)customData.get(3);
		}
		// admTerritorialKind.
					
		Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> createServiceProviderInWCM() | siteAreaName = " + parentSiteAreaName + siteAreaName);

		DocumentId siteArea = null;
		DocumentIdIterator iterator = EgovWCMCache.getWorkspace().findAllByPath(EgovWCMCache.SERVICE_PROVIDERS_SITE_AREA_PATH + "/" + parentSiteAreaName + siteAreaName, DocumentTypes.SiteArea, Workspace.WORKFLOWSTATUS_PUBLISHED, new DocumentLibrary[] { EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)});
		if (iterator.hasNext()) { // SITE AREA FOUNDED...									
			siteArea = iterator.next();
		}
		
		if (siteArea == null) {
			throw new Exception(bundle.getString("wcm.sa.not.found") + " SITEAREA [" + EgovWCMCache.SERVICE_PROVIDERS_SITE_AREA_PATH + "/" + parentSiteAreaName + siteAreaName + "]!");
		}
		Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> createServiceProviderInWCM() | siteAreaPath = " + EgovWCMCache.SERVICE_PROVIDERS_SITE_AREA_PATH + "/" + parentSiteAreaName + siteAreaName);
		
		// Load AdmStructureKindEnum category.
		DocumentId admStructureKindDocId = ARUtils.getWCMAdmStructureKindCategoryFromAdministrativeStructure(administrativeStructure);
		if (admStructureKindDocId == null) {
			throw new Exception(bundle.getString("wcm.adm.structure.kind.enum.category.not.found") + " CATEGORY [" + administrativeStructure.getAdmStructureKind() + "]!");		
		}
		
		// Load mainCategory.
		DocumentId mainCategoryDocId = ARUtils.getWCMMainCategoryFromAdministrativeStructureAndSiteAreaName(administrativeStructure, siteAreaName);
		if (mainCategoryDocId == null) {
			throw new Exception(bundle.getString("wcm.main.category.not.found") + " CATEGORY [" + administrativeStructure.getAdmStructureKind() + "] SiteArea [" + siteAreaName + "]!");		
		}
		if (moveOperation) {
			Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> createServiceProviderInWCM() | [ MOVE ] operation will be initiated...");
			if (content.hasDraft()) {
				throw new Exception("Доставчикът трябва да бъде преместен от '" + contentParentSAName + "' в '" + siteAreaName + "', но съществува чернова. Моля изтрийте черновата!");						
			}
			String currentContentSAPath = EgovWCMCache.getWorkspace().getPathById(content.getParentId(), false, true);
			currentContentSAPath = currentContentSAPath.substring(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME.length());
			Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> createServiceProviderInWCM() | currentContentSAPath = " + currentContentSAPath);
			DocumentIdIterator tmpIterator = EgovWCMCache.getWorkspace().findAllByPath(currentContentSAPath + "/" + EgovWCMCache.SERVICES_SITE_AREA_NAME_BY_SUPPLIER_PREFIX + content.getName(), DocumentTypes.SiteArea, Workspace.WORKFLOWSTATUS_PUBLISHED, new DocumentLibrary[] { EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)});
			Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> createServiceProviderInWCM() | search for currentContentServicesSAPath = " + currentContentSAPath + "/" + EgovWCMCache.SERVICES_SITE_AREA_NAME_BY_SUPPLIER_PREFIX + content.getName());
			DocumentId currentContentServicesSA = null;
			if (tmpIterator.hasNext()) { // SITE AREA FOUNDED...									
				currentContentServicesSA = tmpIterator.next();
				Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> createServiceProviderInWCM() | currentContentServicesSA => [FOUND]");
			} else {
				Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> createServiceProviderInWCM() | currentContentServicesSA => [NOT FOUND]");
			}			
			// Set to publish content the new "mainCategory".
			// We need that, otherwise it won't be listed in the new category.
			ARUtils.populateOptionSelectionField(content, EgovWCMCache.SP_FIELD_MAIN_CATEGORY, mainCategoryDocId);
			// Save content to WCM.
			ARUtils.save(EgovWCMCache.getWorkspace(), content);
			Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> createServiceProviderInWCM() | Moving content from " + currentContentSAPath + "/" + content.getName() + ", to " + EgovWCMCache.SERVICE_PROVIDERS_SITE_AREA_PATH + "/" + parentSiteAreaName + siteAreaName + "/" + content.getName());
			EgovWCMCache.getWorkspace().move(content.getId(), siteArea);			
			if (currentContentServicesSA != null) {
				Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> createServiceProviderInWCM() | Moving site area from " + currentContentSAPath + "/" + EgovWCMCache.SERVICES_SITE_AREA_NAME_BY_SUPPLIER_PREFIX + content.getName() + ", to " + EgovWCMCache.SERVICE_PROVIDERS_SITE_AREA_PATH + "/" + parentSiteAreaName + siteAreaName + "/" + EgovWCMCache.SERVICES_SITE_AREA_NAME_BY_SUPPLIER_PREFIX + content.getName());
				EgovWCMCache.getWorkspace().move(currentContentServicesSA, siteArea);
			}
		}
		DocumentId parentEkatteDocId = null;
		// Municipal Administration.
		if (ARUtils.isAdmMunicipal(administrativeStructure)) { 
			String districtEkatteCode = ARServiceHelper.getDistrictEkatteCodeFromEkatteAddressType(batchType.getAdministration().getAddress() != null ? batchType.getAdministration().getAddress().getEkatteAddress() : null);
			if (districtEkatteCode == null) {
				throw new Exception(bundle.getString("regional.ekatte.code.not.found") + " AdministrativeStructure [" + administrativeStructure.getBatchId().toString() + "]!");
			}
			parentEkatteDocId = ARUtils.getWCMDistrictEkatteCategory(districtEkatteCode);
			if (parentEkatteDocId == null) {
				throw new Exception(bundle.getString("regional.ekatte.code.not.found") + " districtEkatteCode [" + districtEkatteCode + "]!");
			}
		} // AreaMunicipal Administration.
		else if (ARUtils.isAdmAreaMunicipal(administrativeStructure)) { 
			String municipalityEkatteCode = ARServiceHelper.getMunicipalityEkatteCodeFromEkatteAddressType(batchType.getAdministration().getAddress() != null ? batchType.getAdministration().getAddress().getEkatteAddress() : null);
			if (municipalityEkatteCode == null) {
				throw new Exception(bundle.getString("municipality.ekatte.code.not.found") + " AdministrativeStructure [" + administrativeStructure.getBatchId().toString() + "]!");
			}
			parentEkatteDocId = ARUtils.getWCMMunicipalityEkatteCategory(municipalityEkatteCode);
			if (parentEkatteDocId == null) {
				throw new Exception(bundle.getString("municipality.ekatte.code.not.found") + " municipalityEkatteCode [" + municipalityEkatteCode + "]!");
			}
		}  
		// Load content.
		content = getContent(content, at, siteArea, edit, bundle);		
		// Populate common data.
		populateCommonData(content, admStructureKindDocId, mainCategoryDocId, administrativeStructure);
		// Populate Service Provider data.
		populateServiceProviderData(content, administrativeStructure, batchType, parentEkatteDocId, customData, bundle);
		// Save content to WCM.
		ARUtils.save(EgovWCMCache.getWorkspace(), content);
		
		// If "autoPublish" option is set in the portlet, move the content to next(publish) workflow stage.
		if (ARGatewayPortlet.autoPublish) {
			//boolean runExitActions, boolean runEntryActions, java.lang.String comment
			if (content.isDraft() || content.isDraftOfPublishedDocument()) {
				content.approve(true, true, null);
			}
		}
		
		Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> createServiceProviderInWCM() | content.getId().getId() = " + content.getId().getId());
		
		// We check for existence of site area for the services of the administrative structure;
		iterator = EgovWCMCache.getWorkspace().findAllByPath(EgovWCMCache.SERVICE_PROVIDERS_SITE_AREA_PATH + "/" + parentSiteAreaName + siteAreaName + "/" + EgovWCMCache.SERVICES_SITE_AREA_NAME_BY_SUPPLIER_PREFIX + content.getName(), DocumentTypes.SiteArea, Workspace.WORKFLOWSTATUS_PUBLISHED, new DocumentLibrary[] { EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)});
		// Site area for services not found, so we will create it.
		if (!iterator.hasNext()) { 		
			String title = content.getTitle();
			if (title.length() > 125) {
				title = title.substring(0, 116);
				int pos = title.lastIndexOf(" ");
				if (pos != -1) {
					title = title.substring(0, pos);
				}
				title += "...";
			}
			SiteArea newSiteArea = EgovWCMCache.getWorkspace().createSiteArea(siteArea, content.getId(), ChildPosition.AFTER);
			newSiteArea.setName(EgovWCMCache.SERVICES_SITE_AREA_NAME_BY_SUPPLIER_PREFIX + content.getName());
			newSiteArea.setTitle(title + EgovWCMCache.SERVICES_SITE_AREA_TITLE_BY_SUPPLIER_SUFFIX);
			Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> We are going to create NEW siteArea [" + EgovWCMCache.SERVICES_SITE_AREA_NAME_BY_SUPPLIER_PREFIX + content.getName() + "]");
			// Save siteArea to WCM.
			ARUtils.save(EgovWCMCache.getWorkspace(), newSiteArea);			
		}		
		
		// Return the generated contentUUID.
		return content.getId().getId();
	}
	
	@SuppressWarnings({ "rawtypes"})
	private void populateCommonData(Content content, DocumentId admStructureKindDocId, DocumentId mainCategoryDocId, ARAdministrativeStructure administrativeStructure) throws Exception {
		// batchId.
		ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_BATCHID_NAME, administrativeStructure.getBatchId().toString());
		// identificationNumber.
		ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_IDENTIFICATION_NUMBER_NAME, administrativeStructure.getIdentificationNumber());
		// providerNameAr.
		ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_PROVIDER_NAME_AR_NAME, administrativeStructure.getName());
		// eik.
		if (administrativeStructure.getUic() != null) {
			ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_EIK_NAME, administrativeStructure.getUic());
		}
		// inputType.
		ARUtils.populateOptionSelectionField(content, EgovWCMCache.SP_FIELD_INPUT_TYPE_NAME, EgovWCMCache.getCategoryInputTypeFromAR().getId());
		// admStructureKind.
		ARUtils.populateOptionSelectionField(content, EgovWCMCache.SP_FIELD_ADM_STRUCTURE_KIND_NAME, admStructureKindDocId);
		// serviceProviderType.
		if (ARUtils.isAdmCentral(administrativeStructure)) {
			ARUtils.populateOptionSelectionField(content, EgovWCMCache.SP_FIELD_SERVICE_PROVIDER_TYPE_NAME, EgovWCMCache.getCategoryProviderTypeCentral().getId());
		} else if (ARUtils.isAdmRegional(administrativeStructure)) {
			ARUtils.populateOptionSelectionField(content, EgovWCMCache.SP_FIELD_SERVICE_PROVIDER_TYPE_NAME, EgovWCMCache.getCategoryProviderTypeRegional().getId());
		} else if (ARUtils.isAdmMunicipal(administrativeStructure)) {
			ARUtils.populateOptionSelectionField(content, EgovWCMCache.SP_FIELD_SERVICE_PROVIDER_TYPE_NAME, EgovWCMCache.getCategoryProviderTypeMunicipal().getId());
		} else if (ARUtils.isAdmAreaMunicipal(administrativeStructure)) {
			ARUtils.populateOptionSelectionField(content, EgovWCMCache.SP_FIELD_SERVICE_PROVIDER_TYPE_NAME, EgovWCMCache.getCategoryProviderTypeAreaMunicipal().getId());
		} else if (ARUtils.isAdmSpecializedTerritorial(administrativeStructure)) {
			ARUtils.populateOptionSelectionField(content, EgovWCMCache.SP_FIELD_SERVICE_PROVIDER_TYPE_NAME, EgovWCMCache.getCategoryProviderTypeSpecializedTerritorial().getId());
		}
		// mainCategory.
		ARUtils.populateOptionSelectionField(content, EgovWCMCache.SP_FIELD_MAIN_CATEGORY, mainCategoryDocId);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void populateServiceProviderData(Content content, ARAdministrativeStructure administrativeStructure, bg.government.iisda.ras.BatchType batchType, DocumentId parentEkatteDocId, ArrayList customData, ResourceBundle bundle) throws Exception {
		// name.
		content.setName(administrativeStructure.getBatchId().toString());
		
		// Populate the following fields:
		// title 				- for all AS types
		// admTerritorialKind* 	- for AdmTerritorial types ONLY 
		// extendGenericName* 	- for AdmTerritorial types ONLY
		// customName* 			- for AdmTerritorial types ONLY
		// nameEkatte* 			- for AdmTerritorial types ONLY
		if (ARUtils.isAdmCentral(administrativeStructure)) {
			// title.
			String title = administrativeStructure.getName().trim();
			if (title.length() > 125) {
				// Populate providerFullName.
				Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> populateServiceProviderData: " + EgovWCMCache.SP_FIELD_PROVIDER_FULL_NAME_NAME + "=" + title);
				ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_PROVIDER_FULL_NAME_NAME, title);
				title = title.substring(0, 122);
				int pos = title.lastIndexOf(" ");
				if (pos != -1) {
					title = title.substring(0, pos);
				}
				title += "...";
			}
			// title.
			content.setTitle(title);
			Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> populateServiceProviderData: title=" + title);
			
		} else if (ARUtils.isAdmRegional(administrativeStructure)) { // Regional Administration.
			// admTerritorialKind.
			ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_ADM_TERRITORIAL_KIND, EgovWCMCache.getContentAdmTerritorialKindRegional().getId().getId());			
			// customName.
			String customName = ARUtils.getAdmCustomName(administrativeStructure.getName());
			ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_CUSTOM_NAME_NAME, customName);
			// extendGenericName - set to "Yes".
			ARUtils.populateOptionSelectionField(content, EgovWCMCache.SP_FIELD_EXTEND_GENERIC_NAME, EgovWCMCache.getCategoryCommonYes().getId());
			// title.
			content.setTitle(EgovWCMCache.getContentAdmTerritorialKindRegional().getTitle() + " - " + customName);			
			// nameEkatte.
			String nameEkatte = ARServiceHelper.getDistrictEkatteCodeFromEkatteAddressType(batchType.getAdministration().getAddress().getEkatteAddress());
			ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_NAME_EKATTE_NAME, nameEkatte);			
		} else if (ARUtils.isAdmMunicipal(administrativeStructure)) { // Municipal Administration.
			// admTerritorialKind.
			ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_ADM_TERRITORIAL_KIND, EgovWCMCache.getContentAdmTerritorialKindMunicipal().getId().getId());			
			// customName.
			String customName = ARUtils.getAdmCustomName(administrativeStructure.getName());
			ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_CUSTOM_NAME_NAME, customName);
			// extendGenericName - set to "Yes".
			ARUtils.populateOptionSelectionField(content, EgovWCMCache.SP_FIELD_EXTEND_GENERIC_NAME, EgovWCMCache.getCategoryCommonYes().getId());
			// title.
			content.setTitle(EgovWCMCache.getContentAdmTerritorialKindMunicipal().getTitle() + " - " + customName);
			// nameEkatte.
			String nameEkatte = ARServiceHelper.getMunicipalityEkatteCodeFromEkatteAddressType(batchType.getAdministration().getAddress().getEkatteAddress());
			ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_NAME_EKATTE_NAME, nameEkatte);	
			// Only for Municipality we set in the content categories the Regional Ekatte code.
			DocumentId[] docIds = new DocumentId[] {parentEkatteDocId};			
			content.addCategoryIds(docIds);
		} else if (ARUtils.isAdmAreaMunicipal(administrativeStructure)) { // AreaMunicipal Administration.
			// admTerritorialKind.
			ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_ADM_TERRITORIAL_KIND, EgovWCMCache.getContentAdmTerritorialKindAreaMunicipal().getId().getId());			
			// customName.
			String customName = ARUtils.getAdmCustomName(administrativeStructure.getName());
			ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_CUSTOM_NAME_NAME, customName);
			// extendGenericName - set to "Yes".
			ARUtils.populateOptionSelectionField(content, EgovWCMCache.SP_FIELD_EXTEND_GENERIC_NAME, EgovWCMCache.getCategoryCommonYes().getId());
			// title.
			content.setTitle(EgovWCMCache.getContentAdmTerritorialKindAreaMunicipal().getTitle() + " - " + customName);
			// nameEkatte.
			String nameEkatte = ARServiceHelper.getEkatteNumberFromEkatteAddressType(batchType.getAdministration().getAddress().getEkatteAddress());
			ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_NAME_EKATTE_NAME, nameEkatte);	
			// Only for Municipality we set in the content categories the Municipality Ekatte code.
			DocumentId[] docIds = new DocumentId[] {parentEkatteDocId};			
			content.addCategoryIds(docIds);
		} else if (ARUtils.isAdmSpecializedTerritorial(administrativeStructure)) { // SpecializedTerritorial Administration.
			// admTerritorialKind.			
			ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_ADM_TERRITORIAL_KIND, ((Content)customData.get(0)).getId().getId());			
			// customName - calculated in ARUtils.getAdmSpecializedLocalCustomData function.
			String customName = (String)customData.get(1); // customName at index 1
			ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_CUSTOM_NAME_NAME, customName);
			// extendGenericName - calculated in ARUtils.getAdmSpecializedLocalCustomData function.
			ARUtils.populateOptionSelectionField(content, EgovWCMCache.SP_FIELD_EXTEND_GENERIC_NAME, ((Category)customData.get(2)).getId());
			// title.
			content.setTitle(ARUtils.getAdmSpecializedLocalTitle((Content)customData.get(0), administrativeStructure.getName(), customName));			
		}
		
		String ekatteNumber = ARServiceHelper.getEkatteNumberFromEkatteAddressType(batchType.getAdministration().getAddress().getEkatteAddress());		
		// addressEkatte.
		ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_ADDRESS_EKATTE_NAME, ekatteNumber);
		Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> populateServiceProviderData: " + EgovWCMCache.SP_FIELD_ADDRESS_EKATTE_NAME + "=" + ekatteNumber);
		// address.
		if (batchType.getAdministration().getAddress().getAddressText() == null || batchType.getAdministration().getAddress().getAddressText().trim().length() == 0) {
			throw new Exception(bundle.getString("ar.address.text.empty"));
		}		 
		ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_ADDRESS_NAME, batchType.getAdministration().getAddress().getAddressText());
		Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> populateServiceProviderData: " + EgovWCMCache.SP_FIELD_ADDRESS_NAME + "=" + batchType.getAdministration().getAddress().getAddressText());
		// postCode.
//		if (batchType.getAdministration().getAddress().getPostCode() == null || batchType.getAdministration().getAddress().getPostCode().trim().length() == 0) {
//			throw new Exception(bundle.getString("ar.post.code.empty"));
//		}		 
		ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_POST_CODE_NAME, batchType.getAdministration().getAddress().getPostCode());
		// url.
//		if (batchType.getAdministration().getCorrespondenceData() == null 
//				|| batchType.getAdministration().getCorrespondenceData().getWebSiteUrl() == null || batchType.getAdministration().getCorrespondenceData().getWebSiteUrl().trim().length() == 0) {
//			throw new Exception(bundle.getString("ar.web.site.url.empty"));
//		}		 
		if (batchType.getAdministration().getCorrespondenceData() != null && batchType.getAdministration().getCorrespondenceData().getWebSiteUrl() != null) {
			ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_URL_NAME, batchType.getAdministration().getCorrespondenceData().getWebSiteUrl());
		}
		// contacts.
		if (batchType.getAdministration().getCorrespondenceData() == null) {
			throw new Exception(bundle.getString("ar.contacts.empty"));
		}		 
		ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_CONTACTS_NAME, ARUtils.formatCorrespondanceDataForRichText(batchType.getAdministration().getCorrespondenceData()));
		Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> populateServiceProviderData: " + EgovWCMCache.SP_FIELD_CONTACTS_NAME + "=" + ARUtils.formatCorrespondanceDataForRichText(batchType.getAdministration().getCorrespondenceData()));
		// workingTime.
		if (batchType.getAdministration().getWorkingTime() != null) {
			ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_WORKING_TIME_NAME, ARUtils.formatWorkingTimeDataForRichText(batchType.getAdministration().getWorkingTime()));
			Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> populateServiceProviderData: " + EgovWCMCache.SP_FIELD_WORKING_TIME_NAME + "=" + ARUtils.formatWorkingTimeDataForRichText(batchType.getAdministration().getWorkingTime()));
		}
		// procedureRules.
		if (batchType.getAct() != null && batchType.getAct().size() > 0) {
			ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_PROCEDURE_RULES_NAME, ARUtils.formatProcedureRulesDataForRichText(batchType.getAct()));
			Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> populateServiceProviderData: " + EgovWCMCache.SP_FIELD_PROCEDURE_RULES_NAME + "=" + ARUtils.formatProcedureRulesDataForRichText(batchType.getAct()));
		}
		// Populate urlArOrganigram.
		ARUtils.populateTextField(content, EgovWCMCache.SP_FIELD_URL_AR_ORGANIGRAM_NAME, ARUtils.buildUrlArOrganigram(administrativeStructure.getAdmStructureKind(), administrativeStructure.getBatchId().toString()));
		// status. -> Active
		ARUtils.populateOptionSelectionField(content, EgovWCMCache.SP_FIELD_STATUS_NAME, EgovWCMCache.getCategoryCommonActive().getId());
	}
	
	
	@SuppressWarnings({ "rawtypes"})
	private Content getContent(Content content, AuthoringTemplate at, DocumentId siteArea, boolean edit, ResourceBundle bundle) throws Exception {
		if (!edit) {
			Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> getContent() We going to create NEW content.");
			// Create content object.
			content = EgovWCMCache.getWorkspace().createContent(at.getId(), siteArea, null, ChildPosition.END);			
		} else {
			if (content.hasDraft()) {
				Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> getContent() Content has a draft so let's try to find it...");
				content = getDraftContent(content, bundle);
			} else if (content.isPublished()) {
				Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> getContent() Content is published, so we have to create draft document.");
				// Create draft content.
				content = (Content)content.createDraftDocument();
			}					
		}
		return content;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Content getDraftContent(Content content, ResourceBundle bundle) throws Exception {
		// Load the draft content.
		Reference[] references = EgovWCMCache.getWorkspace().getReferences(content.getId());
		if (references != null && references.length > 0) {
			Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> getDraftContent() Found " + references.length + " references.");
			DocumentId tmpDocId = null;
			Content tmpContent = null;
			for (int i = 0; i < references.length; i++) {
				tmpDocId = references[i].getRefererDocumentId();
				if (tmpDocId.getType().isOfType(DocumentTypes.Content) && tmpDocId.isDraft()) {
					tmpContent = (Content)EgovWCMCache.getWorkspace().getById(tmpDocId);
					// Check this content is our draft content.
					if (tmpContent.getParentId().getId().equalsIgnoreCase(content.getParentId().getId())) {																
						content = (Content)EgovWCMCache.getWorkspace().getById(tmpDocId);
						if (EgovWCMCache.getWorkspace().isLocked(content.getId())) {
							throw new Exception(bundle.getString("wcm.content.locked") + " '" + content.getTitle()+ "'!");
						}
						Logger.log(Logger.DEBUG_LEVEL, "ARStructureToWCMManagemnt -> getDraftContent() Draft content founded with UUID " + tmpDocId.getId() + ", breaking.");
						break;
					}
				}
			}
		}
		return content;
	}
	
	public String sendAdministrativeServiceToWCM(ARAdministrativeService administrativeService, ResourceBundle bundle) throws Exception {	
		
		// Load "Batch Details" for the given Administrative structure.
//		bg.government.iisda.ras.BatchType batchType = ARStructuresLoader.loadBatchDetails(administrativeStructure.getIdentificationNumber());
//		
//		if (batchType == null) {
//			throw new Exception(bundle.getString("ar.batch.details.not.loaded"));
//		}
//		
		return null;
//		return createServiceProviderInWCM(administrativeService, batchType, bundle);
	}


}
