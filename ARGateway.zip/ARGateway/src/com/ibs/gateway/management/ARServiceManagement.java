package com.ibs.gateway.management;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.AuthoringTemplate;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.Document;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentLibrary;
import com.ibm.workplace.wcm.api.DocumentTypes;
import com.ibm.workplace.wcm.api.Workspace;
import com.ibm.workplace.wcm.api.query.ProfileSelectors;
import com.ibm.workplace.wcm.api.query.Query;
import com.ibm.workplace.wcm.api.query.ResultIterator;
import com.ibm.workplace.wcm.api.query.Selectors;
import com.ibm.workplace.wcm.api.query.WorkflowSelectors;
import com.ibs.gateway.ARConstants;
import com.ibs.gateway.ARServicesLoader;
import com.ibs.gateway.db.DBTransaction;
import com.ibs.gateway.db.FinderException;
import com.ibs.gateway.db.QueryExecution;
import com.ibs.gateway.dbo.ARAdministrativeService;
import com.ibs.gateway.dbo.ARAdministrativeStructure;
import com.ibs.gateway.utils.ARUtils;
import com.ibs.gateway.utils.Logger;

import bg.government.iisda.admservices.AdmServiceBatchDataType;
import bg.government.iisda.admservices.AdmServiceBatchesType;
import bg.government.iisda.admservices.AdmServiceInfoType;
import bg.government.iisda.admservices.AdmServiceMainDataType;
import bg.government.iisda.admservices.integrationservices.ArrayOfAdmServiceBatchDataType;

public class ARServiceManagement {
	
	public int countServices(String tab, String filterNumber, String filterName, String filterSectionName, String filterSupplierBatchId, String filterState, String fitlerSynchronized) {
		try {
			QueryExecution qe = new QueryExecution();
			return qe.countServices(tab, filterNumber, filterName, filterSectionName, filterSupplierBatchId, filterState, fitlerSynchronized, null); 
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return 0;
	}

	
	public ARAdministrativeService[] loadAllAdministrativeServices(String filterNumber, String filterName, String filterSectionName, String filterSupplierBatchId, String filterState, String fitlerSynchronized) {
		try {
			return ARAdministrativeService.findAllByFitler(filterNumber, filterName, filterSectionName, filterSupplierBatchId, filterState, fitlerSynchronized, null, null, null, null, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public ARAdministrativeService[] loadAllAdministrativeServices(String filterNumber, String filterName, String filterSectionName, String filterSupplierBatchId, String filterState, String fitlerSynchronized, int start, int length, int orderColumn, String order) {
		try {
			return ARAdministrativeService.findAllByFitler(filterNumber, filterName, filterSectionName, filterSupplierBatchId, filterState, fitlerSynchronized, start, length, orderColumn, order, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public ARAdministrativeService[] loadAdministrativeServicesForUpdate(String filterNumber, String filterName, String filterSectionName, String filterSupplierBatchId, String filterState) {
		try {
			return ARAdministrativeService.findAllForUpdate(filterNumber, filterName, filterSectionName, filterSupplierBatchId, filterState, null, null, null, null, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public ARAdministrativeService[] loadAdministrativeServicesForUpdate(String filterNumber, String filterName, String filterSectionName, String filterSupplierBatchId, String filterState, int start, int length, int orderColumn, String order) {
		try {
			return ARAdministrativeService.findAllForUpdate(filterNumber, filterName, filterSectionName, filterSupplierBatchId, filterState, start, length, orderColumn, order, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	public ARAdministrativeService[] loadAllBlockedAdministrativeServices(String filterNumber, String filterName, String filterSupplierBatchId) {
		try {
			return ARAdministrativeService.findAllBlocked(filterNumber, filterName, filterSupplierBatchId, null, null, null, null, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public ARAdministrativeService[] loadAllBlockedAdministrativeServices(String filterNumber, String filterName, String filterSupplierBatchId, int start, int length, int orderColumn, String order) {
		try {
			return ARAdministrativeService.findAllBlocked(filterNumber, filterName, filterSupplierBatchId, start, length, orderColumn, order, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public ARAdministrativeService loadAdministrativeServiceByServiceNumber(String serviceNumber) {
		try {
			return ARAdministrativeService.findByServiceNumber(serviceNumber, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}


	public int createAdministrativeService(AdmServiceMainDataType admServiceMainDataType, AdmServiceBatchDataType admServiceBatchDataType, String state, String hash, String userDN) {
		DBTransaction transaction = null;
		long currentTime = System.currentTimeMillis();
		try {
			transaction = new DBTransaction();
			ARAdministrativeService administrativeService = new ARAdministrativeService();
			administrativeService.setServiceNumber(admServiceMainDataType.getServiceNumber() + "");
			administrativeService.setName(admServiceMainDataType.getName());
			// Our max size is 1024, so we trim to 1020.
			administrativeService.setDescription(admServiceMainDataType.getDescription() != null && admServiceMainDataType.getDescription().trim().length() > 1020 ? admServiceMainDataType.getDescription().substring(0, 1020) : admServiceMainDataType.getDescription());
			administrativeService.setSectionName(admServiceMainDataType.getSectionName());
			if (admServiceMainDataType.getBatchID() != null) {
				administrativeService.setSupplierBatchId(admServiceMainDataType.getBatchID() + "");
				if (admServiceBatchDataType != null && admServiceBatchDataType.getAdmServiceBatchInfo() != null) {
					administrativeService.setSupplierName(admServiceBatchDataType.getAdmServiceBatchInfo().getBatchName());
				}
			}
			
			// will be null for now, until AR update their service.
//			administrativeService.setLastUpdateDate(lastUpdateDate);
			administrativeService.setState(state); 
			administrativeService.setHash(hash); 
			administrativeService.setUserDN(userDN);
			administrativeService.setCreationDate(ARUtils.timeMillisToTimestamp(currentTime));			
			administrativeService.setOperationTime(ARUtils.timeMillisToTimestamp(currentTime));			
			administrativeService.create(transaction);
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println("ARAdministrativeServiceManagement : createAdministrativeService : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("ARAdministrativeServiceManagement : createAdministrativeService : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
		}
		return -1;
	}
	
	public int updateAdministrativeService(ARAdministrativeService administrativeService, AdmServiceMainDataType admServiceMainDataType, AdmServiceBatchDataType admServiceBatchDataType, String state, String hash, String userDN) {
		DBTransaction transaction = null;
		long currentTime = System.currentTimeMillis();
		try {
			transaction = new DBTransaction();
			if (administrativeService != null) {
				administrativeService.setName(admServiceMainDataType.getName());
				// Our max size is 1024, so we trim to 1020.
				administrativeService.setDescription(admServiceMainDataType.getDescription() != null && admServiceMainDataType.getDescription().trim().length() > 1020 ? admServiceMainDataType.getDescription().substring(0, 1020) : admServiceMainDataType.getDescription());
				administrativeService.setSectionName(admServiceMainDataType.getSectionName());
				if (admServiceMainDataType.getBatchID() != null) {
					administrativeService.setSupplierBatchId(admServiceMainDataType.getBatchID() + "");
					if (admServiceBatchDataType != null && admServiceBatchDataType.getAdmServiceBatchInfo() != null) {
						administrativeService.setSupplierName(admServiceBatchDataType.getAdmServiceBatchInfo().getBatchName());
					}
				}
				administrativeService.setState(state);
				// will be null for now, until AR update their service.
//				administrativeService.setLastUpdateDate(lastUpdateDate);
				administrativeService.setHash(hash);
				administrativeService.setUserDN(userDN);
				administrativeService.setOperationTime(ARUtils.timeMillisToTimestamp(currentTime));
				administrativeService.setChangeRegisterDate(ARUtils.timeMillisToTimestamp(currentTime));
				administrativeService.store(transaction); 
			}			
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println("ARAdministrativeServiceManagement : updateAdministrativeService : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("ARAdministrativeServiceManagement : updateAdministrativeService : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
		}
		return -1;
	}
	
	public int updateAdministrativeServiceState(ARAdministrativeService administrativeService, String state, String hash, String userDN) {
		DBTransaction transaction = null;
		long currentTime = System.currentTimeMillis();
		try {
			transaction = new DBTransaction();
			if (administrativeService != null) {
				administrativeService.setState(state);
				administrativeService.setHash(hash);
				administrativeService.setUserDN(userDN);
				administrativeService.setOperationTime(ARUtils.timeMillisToTimestamp(currentTime));
				administrativeService.setChangeRegisterDate(ARUtils.timeMillisToTimestamp(currentTime));
				administrativeService.store(transaction); 
			}			
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println("ARAdministrativeServiceManagement : updateAdministrativeServiceState : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("ARAdministrativeServiceManagement : updateAdministrativeServiceState : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
		}
		return -1;
	}
	
	public String sendAdministrativeServiceToWCM(String id, String userDN, ResourceBundle bundle) throws Exception {		
		try {
			ARAdministrativeService administrativeService = null;
			try {
				administrativeService = ARAdministrativeService.findById(id, null);
			} catch (FinderException e) {
				throw new Exception(bundle.getString("administrative.service.was.not.found"));
			}			
			
			if (administrativeService == null) {
				throw new Exception(bundle.getString("administrative.service.was.not.found"));
			}
			
			if (ARConstants.ADMINISTRATIVE_SERVICE_BLOCKED.equals(administrativeService.getBlocked())) {
				throw new Exception(bundle.getString("administrative.service.should.be.unblocked.first"));
			}
			ARServiceToWCMManagement management = new ARServiceToWCMManagement();
			ARAdministrativeStructure administrativeStructure = null;
			// For CentralAdministrations - check service supplier is added to the system and get administrativeStructure, else throw error.		
			if (EgovWCMCache.AR_SERVICE_SECTION_NAME_CENTRAL_ADMINISTRATIONS.equalsIgnoreCase(administrativeService.getSectionName())) {
				administrativeStructure = management.checkSupplierIsAddedToWCM(administrativeService.getSupplierBatchId().toString(), bundle);	
			}
			
			// Create content in WCM for the given AR.
			String contentUUID = management.sendAdministrativeServiceToWCM(administrativeService, administrativeStructure, bundle);
			
			if (contentUUID == null) {
				throw new Exception(bundle.getString("wcm.create.service.error"));
			}
			// Update AR record accordingly.
			long currentTime = System.currentTimeMillis();		
			administrativeService.setUserDN(userDN);
			administrativeService.setOperationTime(ARUtils.timeMillisToTimestamp(currentTime));
			// We set contentUUID only if we create the content to WCM for the first time.
			if (administrativeService.getContentUUID() == null || administrativeService.getContentUUID().trim().length() == 0) {
				administrativeService.setContentUUID(contentUUID);
			}
			administrativeService.setSynchronized(ARConstants.ADMINISTRATIVE_SERVICE_SYNCHRONIZED);
			administrativeService.setState(ARConstants.ADMINISTRATIVE_SERVICE_STATE_PROCESSED);
			administrativeService.setSynchronizedDate(ARUtils.timeMillisToTimestamp(currentTime));
			administrativeService.store();
			return contentUUID;
		} catch (Exception e) {
			System.out.println("ARAdministrativeServiceManagement : sendAdministrativeServiceToWCM : " + e.getMessage());
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}		
	}
	
	private String getUnifiedServiceContentPath(ARAdministrativeService administrativeService, ResourceBundle bundle) throws Exception {
		String path = EgovWCMCache.SERVICE_PROVIDERS_SITE_AREA_PATH;
		if (EgovWCMCache.AR_SERVICE_SECTION_NAME_ALL_ADMINISTRATIONS.equalsIgnoreCase(administrativeService.getSectionName())) {
			path += "/" + EgovWCMCache.SP_SITE_AREA_ALL_ADMINISТRATIONS_NAME;
		} else if (EgovWCMCache.AR_SERVICE_SECTION_NAME_REGIONAL_ADMINISTRATIONS.equalsIgnoreCase(administrativeService.getSectionName())) {
			path += "/" + EgovWCMCache.SP_SITE_AREA_REGIONAL_ADMINISRATION_NAME;
		} else if (EgovWCMCache.AR_SERVICE_SECTION_NAME_MUNICIPAL_ADMINISTRATIONS.equalsIgnoreCase(administrativeService.getSectionName())) {
			path += "/" + EgovWCMCache.SP_SITE_AREA_MUNICIPAL_ADMINISTRATION_NAME;
		} else if (EgovWCMCache.AR_SERVICE_SECTION_NAME_SPECIALIZED_TERRITORIAL_ADMINISTRATIONS.equalsIgnoreCase(administrativeService.getSectionName())) {
			// TODO implement when we have real case.
			throw new Exception(bundle.getString("not.supported.type.for.migration") + " - [" + administrativeService.getSectionName() + "]");
//			String specialzedTerritorialAdministrationPath = ""; 			
//			// Load content by batchId.
//			try {
//				Query query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
//				// filter by library.
//				query.addSelector(Selectors.libraryEquals(EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)));
//				query.addSelector(Selectors.nameEquals(batchId));
//				// filter by territorial AT.
//			 	query.addSelector(
//						Selectors.authoringTemplateIn(
//							new DocumentId[] {
//								EgovWCMCache.getATServiceProviderTerritorialAdministration().getId()
//							}
//						)
//				);
//				// filter by published.
//				query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
//				query.returnIds();
//				ResultIterator resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);			     
//				if (resultIterator.hasNext()) {
//					 Logger.log(Logger.ERROR_LEVEL, "ARServiceToWCMManagement :  -> specialized territorial administration founded [" + batchId + "]!");
//					 while (resultIterator.hasNext()) {						 
//				    	 Content specializedTerritorialAdministration = (Content)EgovWCMCache.getWorkspace().getById((DocumentId)resultIterator.next(), true);
//				    	 if (specializedTerritorialAdministration != null) {				    		 
//				    		 specialzedTerritorialAdministrationPath = "/" + EgovWCMCache.SP_SITE_AREA_SPECIALIZED_TERRITORIAL_ADMINISTRATION_NAME + "/" + specializedTerritorialAdministration.getParentId().getName();
//				    	 }
//					 }
//				}
//			} catch (Exception e) {
//				e.printStackTrace();
//				throw new Exception("Възникна грешка при намиране на местоположението на доставчика. Моля свържете се със системния админстратор. [" + e.getMessage() + "]");				
//			}
//			if (specialzedTerritorialAdministrationPath.length() == 0) {
//				throw new Exception("Възникна грешка при намиране на местоположението на доставчика. Моля свържете се със системния админстратор.");
//			}
//			Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> createUnifiedServiceInWCM(): specialzedTerritorialAdministrationPath = " + specialzedTerritorialAdministrationPath);
//			path += specialzedTerritorialAdministrationPath;			
		} else {
			throw new Exception(bundle.getString("not.supported.type.for.migration") + " - [" + administrativeService.getSectionName() + "]");
		}		
		path += "/" + EgovWCMCache.SERVICES_SITE_AREA_NAME_UNIFIED_SERVICES;				
		Logger.log(Logger.DEBUG_LEVEL, "ARAdministrativeServiceManagement -> getUnifiedServiceContentPath(): path=" + path);
		return path;
	}
	
	// This method is used for unified services ONLY!
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String downloadOtherDataFromARToUnifiedServiceInWCM(String id, String userDN, ResourceBundle bundle) throws Exception {		
		try {
			ARAdministrativeService administrativeService = null;
			try {
				administrativeService = ARAdministrativeService.findById(id, null);
			} catch (FinderException e) {
				throw new Exception(bundle.getString("administrative.service.was.not.found"));
			}			
			
			if (administrativeService == null) {
				throw new Exception(bundle.getString("administrative.service.was.not.found"));
			}
			
			if (ARConstants.ADMINISTRATIVE_SERVICE_BLOCKED.equals(administrativeService.getBlocked())) {
				throw new Exception(bundle.getString("administrative.service.should.be.unblocked.first"));
			}
			// We have a front-end check for this, but let's do it more safe by adding back-end check too.
			if (administrativeService.getContentUUID() == null || administrativeService.getContentUUID().trim().length() == 0) {
				throw new Exception(bundle.getString("administrative.service.no.wcm.content.reference.exists"));
			}
			// Load content from WCM.
			// check content exists.
			Content content = null;
			try {
				content = (Content)EgovWCMCache.getWorkspace().getById(EgovWCMCache.getWorkspace().createDocumentId(administrativeService.getContentUUID()), true);
			} catch (Exception e) {
				Logger.log(Logger.ERROR_LEVEL, "ARAdministrativeServiceManagement : downloadOtherDataFromARToUnifiedServiceInWCM() [content with UUID does not found in repository] : " + e.getMessage());
				// Check content exists.
				String path = getUnifiedServiceContentPath(administrativeService, bundle);
				if (path != null && path.trim().length() > 0) {
					DocumentIdIterator iterator = EgovWCMCache.getWorkspace().findAllByPath(path + "/" + administrativeService.getServiceNumber().toString(), DocumentTypes.Content, Workspace.WORKFLOWSTATUS_ALL, new DocumentLibrary[] { EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)});
					if (iterator.hasNext()) { // Content found.
						Logger.log(Logger.DEBUG_LEVEL, "ARServiceToWCMManagemnt -> createUnifiedServiceInWCM(): existing content found, overwrite contentUUID data.");
						content = (Content)EgovWCMCache.getWorkspace().getById(iterator.next());
						if (content != null) {
							administrativeService.setContentUUID(content.getId().getID());
							administrativeService.store();
						}
					}
				}
			}
			
			if (content == null) {
				throw new Exception(bundle.getString("wcm.service.content.not.found") + " Content UUID [" + administrativeService.getContentUUID() + "]!");
			}
			if (EgovWCMCache.getATUnifiedService() == null) {
				throw new Exception(bundle.getString("egov.wcm.cache.object.missing") + " АТ [" + EgovWCMCache.SERVICE_AUTHORING_TEMPLATE_UNIFIED_SERVICE + "]!");
			}
			if (!content.getAuthoringTemplateID().getId().equalsIgnoreCase(EgovWCMCache.getATUnifiedService().getId().getId())) {
				try {
					AuthoringTemplate at = (AuthoringTemplate)EgovWCMCache.getWorkspace().getById(content.getAuthoringTemplateID(), true);
					if (at != null) {
						throw new Exception(bundle.getString("administrative.service.type.is.not.supported.for.chosen.opearation") + " AT [" + at.getTitle() + "]!");
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				throw new Exception(bundle.getString("administrative.service.type.is.not.supported.for.chosen.opearation"));
			}
			
			administrativeService.setContent(content);
			
			ARServiceToWCMManagement management = new ARServiceToWCMManagement();
			
			// Download "Other data" from AR and store them in new site area with name "serviceName_drugi".
			return management.downloadOtherDataForAdministrativeServiceToWCM(administrativeService, false);
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "ARAdministrativeServiceManagement : downloadOtherDataFromARToUnifiedServiceInWCM() : " + e.getMessage());
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}		
	}
		
	@SuppressWarnings("unchecked")
	public String downloadOtherDataTaxesFromARToAllUnifiedServiceInWCM(String userDN) throws Exception {		
		try {
			// Load All Unified Services in WCM.
			Workspace workspace = EgovWCMCache.getWorkspace();
			Query query = workspace.getQueryService().createQuery(Content.class);				
			query.addSelector(Selectors.libraryEquals(workspace.getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)));			
			query.addSelector(Selectors.authoringTemplateEquals(EgovWCMCache.getATUnifiedService().getId()));			
			// filter by published.
			query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));			
			// generate result
			query.returnObjects();
			ResultIterator<Document> docIterator = workspace.getQueryService().execute(query);			
			if (docIterator != null && docIterator.hasNext()) {
				Content content = null;
				ArrayList<Content> unifiedServices = new ArrayList<Content>();				
				ARAdministrativeService administrativeService = null;
				ARServiceToWCMManagement management =  new ARServiceToWCMManagement();
				//DocumentId[] inputType = null;
				while (docIterator.hasNext()) {
					content = (Content) docIterator.next(); 
					if (content != null) {
						//if (!"2469".equalsIgnoreCase(content.getName())) continue;
						//inputType = ARUtils.getOptionSelectionCategoriesField(content, EgovWCMCache.SERVICE_FIELD_INPUT_TYPE_NAME);
						//if (inputType != null && inputType.length > 0) {
						//if (EgovWCMCache.getCategoryInputTypeFromAR().getId().getId().equalsIgnoreCase(inputType[0].getId())) {
						unifiedServices.add(content);
						//}
						//}						
					}
				}
				Logger.log(Logger.DEBUG_LEVEL, "ARAdministrativeServiceManagement -> unifiedServices.size() = " + unifiedServices.size());
				// Load Administrative service by founded content UUID.
				for (int i = 0; i < unifiedServices.size(); i++) {
					try {
						administrativeService = ARAdministrativeService.findByContentUUID(unifiedServices.get(i).getId().getId(), null);
						if (administrativeService != null) {	
							administrativeService.setContent(unifiedServices.get(i));
							// Download "Other data" from AR and store them in new site area with name "serviceName_drugi".
							management.downloadOtherDataForAdministrativeServiceToWCM(administrativeService, true);	
							Logger.log(Logger.DEBUG_LEVEL, "ARAdministrativeServiceManagement -> #####################################################################");							
							Logger.log(Logger.DEBUG_LEVEL, "ARAdministrativeServiceManagement -> proccessed [" + unifiedServices.get(i).getName() + "][" + (i+1) + "]");							
							Logger.log(Logger.DEBUG_LEVEL, "ARAdministrativeServiceManagement -> #####################################################################");							
						}
					} catch (Exception e) {
						if (e instanceof FinderException) {
							Logger.log(Logger.DEBUG_LEVEL, "ARAdministrativeServiceManagement -> skipped [" + unifiedServices.get(i).getName() + "][" + unifiedServices.get(i).getId().getId() + "]");
						} else {
							Logger.log(Logger.DEBUG_LEVEL, "ARAdministrativeServiceManagement -> error [" + unifiedServices.get(i).getName() + "][" + unifiedServices.get(i).getId().getId() + "]");
							e.printStackTrace();
						}
						
					}	
				}
				Logger.log(Logger.DEBUG_LEVEL, "ARAdministrativeServiceManagement -> downloadOtherDataTaxesFromARToAllUnifiedServiceInWCM => END!");
			}
			return null;
		} catch (Exception e) {
			System.out.println("ARAdministrativeServiceManagement : downloadOtherDataTaxesFromARToAllUnifiedServiceInWCM : " + e.getMessage());
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}		
	}
	
	@SuppressWarnings({ "unchecked", "deprecation" })
	public String downloadAdministrativeSupplyUnitsFromARToServicesProvidedBySupplierInWCM(String userDN, ResourceBundle bundle) throws Exception {		
		try {
			// Load All Unified Services in WCM.
			Workspace workspace = EgovWCMCache.getWorkspace();
			Query query = workspace.getQueryService().createQuery(Content.class);				
			query.addSelector(Selectors.libraryEquals(workspace.getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)));			
			query.addSelector(Selectors.authoringTemplateEquals(EgovWCMCache.getATServiceProvidedBySupplier().getId()));			
			// filter by published.
			query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));	
			// load only 'active' services.
			query.addSelector(ProfileSelectors.categoriesContains(EgovWCMCache.getCategoryInputTypeFromAR().getId()));
			// generate result
			query.returnObjects();
			ResultIterator<Document> docIterator = workspace.getQueryService().execute(query);			
			if (docIterator != null && docIterator.hasNext()) {
				Content content = null;
				AdmServiceBatchesType admServiceBatchType = null;
				ArrayOfAdmServiceBatchDataType admServiceBatchDataType = null;
				AdmServiceInfoType admServiceInfoType = null;
				long serviceNumber = 0;
				System.out.println("TOTAL=" + docIterator.getSize());
				int i = 0;
				while (docIterator.hasNext()) {
					content = (Content) docIterator.next(); 
					if (content != null) {
						i++;						
						try {
							System.out.println("downloadAdministrativeSupplyUnitsFromARToServicesProvidedBySupplierInWCM >> Processed [" + i + ", " + content.getName() + ", " + content.getId().getID() + "]");						
							serviceNumber = Long.parseLong(content.getName());
							//if (!"1168".equalsIgnoreCase(content.getName())) continue;
							// Load all batches for given Administrative service.
							admServiceBatchType = ARServicesLoader.loadAdmServiceBatches(serviceNumber);
							if (admServiceBatchType == null || admServiceBatchType.getBatchIdentNumber() == null || admServiceBatchType.getBatchIdentNumber().size() == 0) {
								throw new Exception("AR service batch not loaded! [" + serviceNumber + "]");
							}
							// Load "Service Batch Data Type" for the given Administrative service.
							admServiceBatchDataType = ARServicesLoader.loadAdmServiceBatchDataType(admServiceBatchType.getBatchIdentNumber().get(0).replaceFirst("^0+(?!$)", ""), serviceNumber);
							if (admServiceBatchDataType == null || admServiceBatchDataType.getAdmServiceBatchDataType() == null || admServiceBatchDataType.getAdmServiceBatchDataType().size() == 0) {			
								throw new Exception("AR service batch data type not loaded! [" + serviceNumber + "]");
							}
							// Check we have valid data from the AR service.
							if (admServiceBatchDataType.getAdmServiceBatchDataType().get(0) != null && admServiceBatchDataType.getAdmServiceBatchDataType().get(0).getAdmServiceBatchInfo() != null) {
								admServiceInfoType = admServiceBatchDataType.getAdmServiceBatchDataType().get(0).getAdmServiceBatchInfo();
							} else {
								throw new Exception("AR service ADM service batch is empty!");
							}
							// administrativeSupplyUnits.
							if (admServiceInfoType.getServicingUnitContactData() != null && admServiceInfoType.getServicingUnitContactData().size() > 0) {
								ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_ADMINISTRATIVE_SUPPLY_UNITS_NAME, ARUtils.formatAdministrativeSupplyUnitsDataForRichText(admServiceInfoType.getServicingUnitContactData(), bundle));
							}
							
							// Save content to WCM.
							ARUtils.save(EgovWCMCache.getWorkspace(), content);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
				Logger.log(Logger.DEBUG_LEVEL, "ARAdministrativeServiceManagement -> downloadAdministrativeSupplyUnitsFromARToServicesProvidedBySupplierInWCM => END!");
			}
			return null;
		} catch (Exception e) {
			System.out.println("ARAdministrativeServiceManagement : downloadAdministrativeSupplyUnitsFromARToServicesProvidedBySupplierInWCM : " + e.getMessage());
			e.printStackTrace();
			throw new Exception(e.getMessage());
		}		
	}
	
	public ARAdministrativeStructure[] getServiceSuppliers(String id, ResourceBundle bundle) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "ARAdministrativeServiceManagement -> getServiceSuppliers(" +id + ") start...");
		ARAdministrativeService administrativeService = null;
		try {
			administrativeService = ARAdministrativeService.findById(id, null);
		} catch (FinderException e) {
			throw new Exception(bundle.getString("administrative.service.was.not.found"));
		}			
		
		if (administrativeService == null) {
			throw new Exception(bundle.getString("administrative.service.was.not.found"));
		}
		
		if (ARConstants.ADMINISTRATIVE_SERVICE_BLOCKED.equals(administrativeService.getBlocked())) {
			throw new Exception(bundle.getString("administrative.service.should.be.unblocked.first"));
		}
		AdmServiceBatchesType admServiceBatchType = ARServicesLoader.loadAdmServiceBatches(administrativeService.getServiceNumber().longValue());
		if (admServiceBatchType == null || admServiceBatchType.getBatchIdentNumber() == null || admServiceBatchType.getBatchIdentNumber().size() == 0) {
			throw new Exception(bundle.getString("ar.service.batches.not.loaded"));
		}
		ARAdministrativeStructure[] administrativeStructures = null;		
		// Load all AdministrativeStructures that we have in our DB, by batchIdentNumber.
		String batchIdentNumbers = "";
		for (int i = 0; i < admServiceBatchType.getBatchIdentNumber().size(); i++) {
			if (batchIdentNumbers.trim().length() > 0) {
				batchIdentNumbers += ",";
			}
			batchIdentNumbers += admServiceBatchType.getBatchIdentNumber().get(i).replaceFirst("^0+(?!$)", "");			
		}	
		ARStructureManagement management = new ARStructureManagement();
		administrativeStructures = management.loadAllAdministrativeStructuresByBatchIds(batchIdentNumbers);
		if (administrativeStructures == null) {
			throw new Exception(bundle.getString("no.administrative.structures.founded.for.given.batch.id") + " batchIds [" + batchIdentNumbers + "]");
		}
		
		// We skip this check services provided by ALL_ADMINISTRATIONS.
		if (!EgovWCMCache.AR_SERVICE_SECTION_NAME_ALL_ADMINISTRATIONS.equalsIgnoreCase(administrativeService.getSectionName())) {
			// If lengths do not match, fire exception.
			if (administrativeStructures.length != admServiceBatchType.getBatchIdentNumber().size()) {
				ArrayList<String> batchesInDBArr = new ArrayList<String>();
				String[] batchIdentNumbersArr = batchIdentNumbers.split(",");
				for (int i = 0; i < administrativeStructures.length; i++) {
					batchesInDBArr.add(administrativeStructures[i].getBatchId().toString());
				}
				for (int i = 0; i < batchIdentNumbersArr.length; i++) {
					if (!batchesInDBArr.contains(batchIdentNumbersArr[i])) {
						throw new Exception(bundle.getString("administrative.structure.is.missing") + " batchId [" + batchIdentNumbersArr[i] + "]");
					}
				}
				throw new Exception(bundle.getString("administrative.structure.is.missing"));
			}
		} else {
			return administrativeStructures;
		}
		
		ARServiceToWCMManagement managementToWCM = new ARServiceToWCMManagement();		
		// We check suppliers are added to WCM, and populate Content object to the administrativeStructures array.
		return managementToWCM.checkSuppliersAreAddedToWCM(administrativeService, administrativeStructures);
		
	}
	
	public String createUnifiedService(String id, String batchId, boolean createOtherData, String userDN, ResourceBundle bundle) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "ARAdministrativeServiceManagement : createUnifiedService(" +id + "," + batchId + "," + createOtherData + "," + userDN + ") start...");		
		ARAdministrativeService administrativeService = null;
		try {
			administrativeService = ARAdministrativeService.findById(id, null);
		} catch (FinderException e) {
			throw new Exception(bundle.getString("administrative.service.was.not.found"));
		}			
		
		if (administrativeService == null) {
			throw new Exception(bundle.getString("administrative.service.was.not.found"));
		}
		
		if (ARConstants.ADMINISTRATIVE_SERVICE_BLOCKED.equals(administrativeService.getBlocked())) {
			throw new Exception(bundle.getString("administrative.service.should.be.unblocked.first"));
		}
		AdmServiceBatchesType admServiceBatchType = ARServicesLoader.loadAdmServiceBatches(administrativeService.getServiceNumber().longValue());
		if (admServiceBatchType == null || admServiceBatchType.getBatchIdentNumber() == null || admServiceBatchType.getBatchIdentNumber().size() == 0) {
			throw new Exception(bundle.getString("ar.service.batches.not.loaded"));
		}			
		ARAdministrativeStructure[] administrativeStructures = null;
		ARAdministrativeStructure administrativeStructure = null;
		// Load all AdministrativeStructures that we have in our DB, by batchIdentNumber.
		String batchIdentNumbers = "";
		for (int i = 0; i < admServiceBatchType.getBatchIdentNumber().size(); i++) {
			if (batchIdentNumbers.trim().length() > 0) {
				batchIdentNumbers += ",";
			}
			batchIdentNumbers += admServiceBatchType.getBatchIdentNumber().get(i).replaceFirst("^0+(?!$)", "");			
		}	
		ARStructureManagement management = new ARStructureManagement();
		administrativeStructures = management.loadAllAdministrativeStructuresByBatchIds(batchIdentNumbers);
		if (administrativeStructures == null) {
			throw new Exception(bundle.getString("no.administrative.structures.founded.for.given.batch.id") + " batchIds [" + batchIdentNumbers + "]");
		}
		// Skip length match for services provided by ALL_ADMINISTRATIONS.
		if (!EgovWCMCache.AR_SERVICE_SECTION_NAME_ALL_ADMINISTRATIONS.equalsIgnoreCase(administrativeService.getSectionName())) {
			// If lengths do not match, fire exception.
			if (administrativeStructures.length != admServiceBatchType.getBatchIdentNumber().size()) {
				ArrayList<String> batchesInDBArr = new ArrayList<String>();
				String[] batchIdentNumbersArr = batchIdentNumbers.split(",");
				
				for (int i = 0; i < administrativeStructures.length; i++) {
					batchesInDBArr.add(administrativeStructures[i].getBatchId().toString());
				}
				for (int i = 0; i < batchIdentNumbersArr.length; i++) {
					if (!batchesInDBArr.contains(batchIdentNumbersArr[i])) {
						throw new Exception(bundle.getString("administrative.structure.is.missing") + " batchId [" + batchIdentNumbersArr[i] + "]");
					}
				}
				throw new Exception(bundle.getString("administrative.structure.is.missing"));
			} 
		}
		
		ARServiceToWCMManagement managementToWCM = new ARServiceToWCMManagement();
		
		// Skip this check for services provided by ALL_ADMINISTRATIONS.
		if (!EgovWCMCache.AR_SERVICE_SECTION_NAME_ALL_ADMINISTRATIONS.equalsIgnoreCase(administrativeService.getSectionName())) {
			// We check suppliers are added to WCM, and populate Content object to the administrativeStructures array.
			administrativeStructures = managementToWCM.checkSuppliersAreAddedToWCM(administrativeService, administrativeStructures);
		}
		
		for (int i = 0; i < administrativeStructures.length; i++) {
			if (administrativeStructures[i].getBatchId().toString().equals(batchId)) {
				administrativeStructure = administrativeStructures[i];
				break;
			}
		}
		
		if (administrativeStructure == null) {
			throw new Exception(bundle.getString("given.batch.id.not.found") + " batchId [" + batchId + "]");
		}
		
		String contentUUID = null;
		if (administrativeService.getContentUUID() != null && administrativeService.getContentUUID().trim().length() > 0) {
			Logger.log(Logger.DEBUG_LEVEL, "ARAdministrativeServiceManagement : createUnifiedService() has contentUUID = " + administrativeService.getContentUUID());
			// Check content exists, it could be delete. If latter we need to remove the reference.
			Content content = null;
			try {
				content = (Content)EgovWCMCache.getWorkspace().getById(EgovWCMCache.getWorkspace().createDocumentId(administrativeService.getContentUUID()));				
			} catch (Exception e) {
				Logger.log(Logger.ERROR_LEVEL, "ARAdministrativeServiceManagement : createUnifiedService() -> error=" + e.getMessage());
			}
			
			if (content == null) {
				Logger.log(Logger.DEBUG_LEVEL, "ARAdministrativeServiceManagement : createUnifiedService() content not found, clear the reference to 'broken' contentUUID.");
				// Create content in WCM for the given AR.
				contentUUID = managementToWCM.createUnifiedServiceInWCM(administrativeService, administrativeStructure, batchId, createOtherData, bundle);
				administrativeService.setContentUUID(null);
			} else {
				// Update content in WCM for the given AR.
				contentUUID = managementToWCM.updateUnifiedServiceInWCM(administrativeService, administrativeStructure, batchId, createOtherData, bundle);
			}
		} else {
			// Create content in WCM for the given AR.
			contentUUID = managementToWCM.createUnifiedServiceInWCM(administrativeService, administrativeStructure, batchId, createOtherData, bundle);
		}
		
		if (contentUUID == null) {
			throw new Exception(bundle.getString("wcm.create.service.error"));
		}
		// Update AR record accordingly.
		long currentTime = System.currentTimeMillis();		
		administrativeService.setUserDN(userDN);
		administrativeService.setOperationTime(ARUtils.timeMillisToTimestamp(currentTime));
		// We set contentUUID only if we create the content to WCM for the first time.
		if (administrativeService.getContentUUID() == null || administrativeService.getContentUUID().trim().length() == 0) {
			administrativeService.setContentUUID(contentUUID);
		}
		administrativeService.setSynchronized(ARConstants.ADMINISTRATIVE_SERVICE_SYNCHRONIZED);
		administrativeService.setState(ARConstants.ADMINISTRATIVE_SERVICE_STATE_PROCESSED);
		administrativeService.setSynchronizedDate(ARUtils.timeMillisToTimestamp(currentTime));
		administrativeService.store();
		return contentUUID;
	}


	public ARAdministrativeService blockAdministrativeService(String id, String userDN, ResourceBundle bundle) throws Exception {
		DBTransaction transaction = null;
		long currentTime = System.currentTimeMillis();
		try {
			transaction = new DBTransaction();
			ARAdministrativeService administrativeService = null;
			try {
				administrativeService = ARAdministrativeService.findById(id, transaction);
			} catch (FinderException e) {
				throw new Exception(bundle.getString("administrative.service.was.not.found"));
			}			
			
			if (administrativeService != null) {
				administrativeService.setBlocked(ARConstants.ADMINISTRATIVE_SERVICE_BLOCKED);
				administrativeService.setUserDN(userDN);
				administrativeService.setOperationTime(ARUtils.timeMillisToTimestamp(currentTime));
				administrativeService.store(transaction);
			}			
			transaction.commit();	
			return administrativeService;
		} catch (Exception e) {
			System.out.println("ARAdministrativeServiceManagement : blockAdministrativeService : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("ARAdministrativeServiceManagement : blockAdministrativeService : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			throw new Exception(e.getMessage());
		}		
	}
	
	public ARAdministrativeService unblockAdministrativeService(String id, String userDN, ResourceBundle bundle) throws Exception {
		DBTransaction transaction = null;
		long currentTime = System.currentTimeMillis();
		try {
			transaction = new DBTransaction();
			ARAdministrativeService administrativeService = null;
			try {
				administrativeService = ARAdministrativeService.findById(id, transaction);
			} catch (FinderException e) {
				throw new Exception(bundle.getString("administrative.service.was.not.found"));
			}			
			
			if (administrativeService != null) {
				administrativeService.setBlocked(null);
				administrativeService.setUserDN(userDN);
				administrativeService.setOperationTime(ARUtils.timeMillisToTimestamp(currentTime));
				administrativeService.store(transaction);
			}			
			transaction.commit();	
			return administrativeService;
		} catch (Exception e) {
			System.out.println("ARAdministrativeServiceManagement : unblockAdministrativeService : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("ARAdministrativeServiceManagement : unblockAdministrativeService : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			throw new Exception(e.getMessage());
		}		
	}
	
	public ARAdministrativeService removeWCMReferenceFromAdministrativeService(String id, String userDN, ResourceBundle bundle) throws Exception {
		DBTransaction transaction = null;
		long currentTime = System.currentTimeMillis();
		try {
			transaction = new DBTransaction();
			ARAdministrativeService administrativeService = null;
			try {
				administrativeService = ARAdministrativeService.findById(id, transaction);
			} catch (FinderException e) {
				throw new Exception(bundle.getString("administrative.service.was.not.found"));
			}			
			
			if (administrativeService != null) {
				administrativeService.setState(ARConstants.ADMINISTRATIVE_SERVICE_STATE_IS_NEW);
				administrativeService.setContentUUID(null);
				administrativeService.setSynchronized(null);				
				administrativeService.setSynchronizedDate(null);
				administrativeService.setUserDN(userDN);
				administrativeService.setOperationTime(ARUtils.timeMillisToTimestamp(currentTime));
				administrativeService.store(transaction);
			}			
			transaction.commit();	
			return administrativeService;
		} catch (Exception e) {
			System.out.println("ARAdministrativeServiceManagement : removeWCMReferenceFromAdministrativeService : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("ARAdministrativeServiceManagement : removeWCMReferenceFromAdministrativeService : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			throw new Exception(e.getMessage());
		}		
	}

	public ARAdministrativeService deleteAdministrativeService(String id, ResourceBundle bundle) throws Exception {
		DBTransaction transaction = null;
		try {
			transaction = new DBTransaction();
			ARAdministrativeService administrativeService = null;
			try {
				administrativeService = ARAdministrativeService.findById(id, transaction);
			} catch (FinderException e) {
				throw new Exception(bundle.getString("administrative.service.was.not.found"));
			}			
			administrativeService.remove(transaction);						
			transaction.commit();	
			return administrativeService;
		} catch (Exception e) {
			System.out.println("ARAdministrativeServiceManagement : deleteAdministrativeService : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("ARAdministrativeServiceManagement : deleteAdministrativeService : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			throw new Exception(e.getMessage());
		}		
	}
	
	public void loadAllCentralAdminstrationSericesInWCM(String userDN, ResourceBundle bundle) throws Exception {
		System.out.println("loadAllCentralAdminstrationSericesInWCM started...");
		try {
			ARAdministrativeService[] administrativeServices = null;
			try {
				administrativeServices = ARAdministrativeService.findAllBySectionName(EgovWCMCache.AR_SERVICE_SECTION_NAME_CENTRAL_ADMINISTRATIONS, null);
			} catch (FinderException e) {
				throw new Exception(bundle.getString("administrative.services.was.not.found"));
			}			
			
			if (administrativeServices == null) {
				throw new Exception(bundle.getString("administrative.services.was.not.found"));
			}
			
			System.out.println("total=" + administrativeServices.length);
			ARAdministrativeService administrativeService = null;
			// process administrative services.
			for (int i = 0; i < administrativeServices.length; i++) {
				administrativeService = administrativeServices[i];
				if (ARConstants.ADMINISTRATIVE_SERVICE_BLOCKED.equals(administrativeService.getBlocked())) continue;
				// If content UUID is null, we need to create the content first.
				if (administrativeService.getContentUUID() == null || administrativeService.getContentUUID().trim().length() == 0) {
					System.out.println("processing[" + (i + 1) + "] -> " + administrativeService.getName());
					try {
						sendAdministrativeServiceToWCM(administrativeService.getId(), userDN, bundle);
					} catch (Exception e) {
						e.printStackTrace();
					}					
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void mergeOldServicesWithNewOnes(String sectionName, String userDN, ResourceBundle bundle) throws Exception {
		System.out.println("mergeOldWCMServiceWithNewOne started...");
		try {
			ARAdministrativeService[] administrativeServices = null;
			try {
				administrativeServices = ARAdministrativeService.findAllBySectionName(sectionName, null);
			} catch (FinderException e) {
				throw new Exception(bundle.getString("administrative.services.was.not.found"));
			}			
			
			if (administrativeServices == null) {
				throw new Exception(bundle.getString("administrative.services.was.not.found"));
			}
			
			System.out.println("total=" + administrativeServices.length);
			ARAdministrativeService administrativeService = null;
			ARServiceToWCMManagement managementToWCM = new ARServiceToWCMManagement();
			// process administrative services.
			int processed = 0;
			for (int i = 0; i < administrativeServices.length; i++) {
				administrativeService = administrativeServices[i];
				if (ARConstants.ADMINISTRATIVE_SERVICE_BLOCKED.equals(administrativeService.getBlocked())) continue;
				// Process services stored one by one. 
				if (administrativeService.getContentUUID() != null && administrativeService.getContentUUID().trim().length() > 0) {
					System.out.println("processing[" + (i + 1) + "] -> " + administrativeService.getServiceNumber());
					//if (2559 != administrativeService.getServiceNumber().intValue()) continue;
					//System.out.println("processing[" + (i + 1) + "] STARTED FOR " + administrativeService.getServiceNumber());
					try {			
						//if (managementToWCM.mergeOldWCMCAServiceWithNewOne(administrativeService, userDN, bundle) > 0) {
						//	break;
						//}
						processed += managementToWCM.mergeOldWCMServiceWithNewOne(administrativeService, userDN, bundle);
					} catch (Exception e) {
						e.printStackTrace();
					}					
				}
			}
			System.out.println("mergeOldWCMServiceWithNewOne FOUDED $$$$$$$$$$$ " + processed);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void mergeOldServicesWithNewOnesExtra(String sectionName, String userDN, ResourceBundle bundle) throws Exception {
		System.out.println("mergeOldServicesWithNewOnesExtra started...");
		try {
			ARAdministrativeService[] administrativeServices = null;
			try {
				administrativeServices = ARAdministrativeService.findAllBySectionName(sectionName, null);
			} catch (FinderException e) {
				throw new Exception(bundle.getString("administrative.services.was.not.found"));
			}			
			
			if (administrativeServices == null) {
				throw new Exception(bundle.getString("administrative.services.was.not.found"));
			}
			
			System.out.println("total=" + administrativeServices.length);
			ARAdministrativeService administrativeService = null;
			ARServiceToWCMManagement managementToWCM = new ARServiceToWCMManagement();
			// process administrative services.
			int processed = 0;
			for (int i = 0; i < administrativeServices.length; i++) {
				administrativeService = administrativeServices[i];
				if (ARConstants.ADMINISTRATIVE_SERVICE_BLOCKED.equals(administrativeService.getBlocked())) continue;
				// Process services stored one by one. 
				if (administrativeService.getContentUUID() != null && administrativeService.getContentUUID().trim().length() > 0) {
					System.out.println("processing[" + (i + 1) + "] -> " + administrativeService.getServiceNumber());
					//if (2559 != administrativeService.getServiceNumber().intValue()) continue;
					//System.out.println("processing[" + (i + 1) + "] STARTED FOR " + administrativeService.getServiceNumber());
					try {			
						//if (managementToWCM.mergeOldWCMCAServiceWithNewOne(administrativeService, userDN, bundle) > 0) {
						//	break;
						//}
						processed += managementToWCM.mergeOldWCMServiceWithNewOneExtra(administrativeService, userDN, bundle);
					} catch (Exception e) {
						e.printStackTrace();
					}					
				}
			}
			System.out.println("mergeOldWCMServiceWithNewOne FOUDED $$$$$$$$$$$ " + processed);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public DocumentId getServiceContentUUIDFromWCM(String id) {		
		try {
			ARAdministrativeService administrativeService = null;
			try {
				administrativeService = ARAdministrativeService.findById(id, null);
			} catch (FinderException e) {
				e.printStackTrace();
			}			
			
			if (administrativeService == null) {
				System.err.println("ARServiceManagement:getServiceContentUUIDFromWCM -> administrativeService=null");
				return null;
			}
			
			String path = EgovWCMCache.SERVICE_PROVIDERS_SITE_AREA_PATH;
			if (EgovWCMCache.AR_SERVICE_SECTION_NAME_CENTRAL_ADMINISTRATIONS.equalsIgnoreCase(administrativeService.getSectionName())) {
				// Load supplier by batchId.
				try {
					Query query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
					// filter by library.
					query.addSelector(Selectors.libraryEquals(EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)));
					query.addSelector(Selectors.nameEquals(String.valueOf(administrativeService.getSupplierBatchId())));
					// filter by territorial AT.
				 	query.addSelector(
							Selectors.authoringTemplateIn(
								new DocumentId[] {
									EgovWCMCache.getATServiceProviderCentralAdministration().getId()
								}
							)
					);
					// filter by published.
					query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
					query.returnIds();
					ResultIterator resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);			     
					if (resultIterator.hasNext()) {
						 Logger.log(Logger.ERROR_LEVEL, "ARServiceManagement:getServiceContentUUIDFromWCM  -> central administration founded [" + administrativeService.getSupplierBatchId() + "]!");
						 while (resultIterator.hasNext()) {						 
					    	 Content centralAdministration = (Content)EgovWCMCache.getWorkspace().getById((DocumentId)resultIterator.next(), true);
					    	 if (centralAdministration != null) {				    		 
					    		 path += "/" + centralAdministration.getParentId().getName() + "/uslugi-" + String.valueOf(administrativeService.getSupplierBatchId());
					    	 }
					    	 break;
						 }
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else if (EgovWCMCache.AR_SERVICE_SECTION_NAME_ALL_ADMINISTRATIONS.equalsIgnoreCase(administrativeService.getSectionName())) {
				path += "/" + EgovWCMCache.SP_SITE_AREA_ALL_ADMINISТRATIONS_NAME;
				path += "/" + EgovWCMCache.SERVICES_SITE_AREA_NAME_UNIFIED_SERVICES;
			} else if (EgovWCMCache.AR_SERVICE_SECTION_NAME_REGIONAL_ADMINISTRATIONS.equalsIgnoreCase(administrativeService.getSectionName())) {
				path += "/" + EgovWCMCache.SP_SITE_AREA_REGIONAL_ADMINISRATION_NAME;
				path += "/" + EgovWCMCache.SERVICES_SITE_AREA_NAME_UNIFIED_SERVICES;
			} else if (EgovWCMCache.AR_SERVICE_SECTION_NAME_MUNICIPAL_ADMINISTRATIONS.equalsIgnoreCase(administrativeService.getSectionName())) {
				path += "/" + EgovWCMCache.SP_SITE_AREA_MUNICIPAL_ADMINISTRATION_NAME;
				path += "/" + EgovWCMCache.SERVICES_SITE_AREA_NAME_UNIFIED_SERVICES;
			} else if (EgovWCMCache.AR_SERVICE_SECTION_NAME_SPECIALIZED_TERRITORIAL_ADMINISTRATIONS.equalsIgnoreCase(administrativeService.getSectionName())) {
				// Load supplier by batchId.
				try {
					Query query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
					// filter by library.
					query.addSelector(Selectors.libraryEquals(EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)));
					query.addSelector(Selectors.nameEquals(String.valueOf(administrativeService.getServiceNumber())));
					// filter by territorial AT.
				 	query.addSelector(
							Selectors.authoringTemplateIn(
								new DocumentId[] {
									EgovWCMCache.getATUnifiedService().getId()
								}
							)
					);
					// filter by published.
					query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
					query.returnIds();
					ResultIterator resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);			     
					if (resultIterator.hasNext()) {
						 Logger.log(Logger.ERROR_LEVEL, "ARServiceManagement:getServiceContentUUIDFromWCM  -> specialized central administration founded [" + administrativeService.getSupplierBatchId() + "]!");
						 while (resultIterator.hasNext()) {						 
					    	 return (DocumentId)resultIterator.next(); 
						 }
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {
				throw new Exception("not.supported.type.for.migration" + " - [" + administrativeService.getSectionName() + "]");
			}
			
			path += "/" + administrativeService.getServiceNumber();
					
			Logger.log(Logger.DEBUG_LEVEL, "ARServiceManagement:getServiceContentUUIDFromWCM -> path=" + path);
			
			DocumentIdIterator iterator = EgovWCMCache.getWorkspace().findAllByPath(path, DocumentTypes.SiteArea, Workspace.WORKFLOWSTATUS_PUBLISHED, new DocumentLibrary[] { EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)});
			if (iterator.hasNext()) { // Content found.	
				DocumentId docId = iterator.next();
				administrativeService.setContentUUID(docId.getID());
				administrativeService.store();
				return docId;
			}
		} catch (Exception e) {
			System.out.println("ARServiceManagement:getServiceContentUUIDFromWCM -> " + e.getMessage());
			e.printStackTrace();			
		}		
		return null;
	}

}
