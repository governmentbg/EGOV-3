package com.ibs.gateway.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBconnection {
	private static final String PASSWORD = "*";
	private static final String USERNAME = "*";
	private static final String URL = "*";

	//loading the driver just once
	static {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Error while loading the driver!!!");
			cnfe.printStackTrace();
		}
	}
	
	/*
	 * Method that creates the database connection to the oracle schema - polls
	 * 
	 * @return connection object
	 */
	public static Connection getConnection() {
		//constants
		try {
			Connection con = DriverManager.getConnection(URL, USERNAME, PASSWORD);
			con.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
			return con;
		} catch (SQLException sqle) {
			System.out.println("Error while connecting to the database!!!");
			sqle.printStackTrace();
			return null;
		}
	}
}
