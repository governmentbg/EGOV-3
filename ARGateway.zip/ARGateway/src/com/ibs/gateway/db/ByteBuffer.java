package com.ibs.gateway.db;

public class ByteBuffer {

	private int bufferCount = 0;
	private int bufferIncrease = 32;

	private byte[] buffer = null;

	public ByteBuffer() {
		buffer = new byte[16];
	}
	public ByteBuffer(int initial_size) {
		bufferCount = 0;
		buffer = (initial_size <= 0) ? (new byte[16]) : new byte[initial_size];
	}
	public ByteBuffer(int initial_size, int increase) {
		bufferCount = 0;
		bufferIncrease = increase;
		buffer = (initial_size <= 0) ? (new byte[16]) : new byte[initial_size];
	}

	public void clear() {
		bufferCount = 0;
	}

	public byte[] getBytes() {
		if (bufferCount <= 0)
			return null;
		byte[] bytearr = new byte[bufferCount];
		System.arraycopy(buffer, 0, bytearr, 0, bufferCount);
		return bytearr;
	}

	public void append(byte[] bytes) {
		if (bufferCount + bytes.length >= buffer.length) {
			byte[] bytearr =
				new byte[buffer.length + bytes.length + bufferIncrease];
			System.arraycopy(buffer, 0, bytearr, 0, bufferCount);
			System.arraycopy(bytes, 0, bytearr, bufferCount, bytes.length);
			buffer = bytearr;
		} else
			System.arraycopy(bytes, 0, buffer, bufferCount, bytes.length);
		bufferCount += bytes.length;
	}

	public void append(byte[] bytes, int size) {
		if (size > bytes.length)
			throw new IndexOutOfBoundsException();

		if (bufferCount + size >= buffer.length) {
			byte[] bytearr = new byte[buffer.length + size + bufferIncrease];
			System.arraycopy(buffer, 0, bytearr, 0, bufferCount);
			System.arraycopy(bytes, 0, bytearr, bufferCount, size);
			buffer = bytearr;
		} else
			System.arraycopy(bytes, 0, buffer, bufferCount, size);
		bufferCount += size;
	}
}
