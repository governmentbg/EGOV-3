package com.ibs.gateway.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import com.ibs.gateway.ARConstants;
import com.ibs.gateway.ARGatewayPortlet;
import com.ibs.gateway.dbo.ARAdministrativeService;
import com.ibs.gateway.utils.ARUtils;
import com.ibs.gateway.utils.Logger;

public class QueryExecution {

	private static Connection getConnection() throws SQLException {

		Connection con = DBPool.getConnection();
		if (con == null) {
			throw new SQLException("Connection is NULL");
		}
		return con;

	}

	public static void setSessionTimestampFormat(final DBTransaction transaction) throws FinderException, Exception {
		Connection connection = null;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				Statement statement = connection.createStatement();
				statement.executeUpdate("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH24:MI:SSXFF'");
				statement.close();
			} else {
				throw new Exception("Connection or query set is not initialized.");
			}
		} catch (final SQLException e) {
			throw new Exception(e.getMessage());
		} 
	}
	
	public int countServices(final String tab, final String filterNumber, final String filterName, final String filterSectionName, final String filterSupplierBatchId, final String filterState, final String filterSynchronized, final DBTransaction transaction) {
		Logger.log(Logger.DEBUG_LEVEL, "QE -> countServices() started...");
		Connection connection = null;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "SELECT COUNT (" + DBResources._SCHEMANAME + "ARADMINISTRATIVESERVICE.ARADMINISTRATIVESERVICEID" + ")";				
				query += " FROM " + DBResources._SCHEMANAME + "ARADMINISTRATIVESERVICE";
				query += " WHERE 1=1";
				int column = 1;
				HashMap<String, String> tmpHm = new HashMap<String, String>(); 
				
				if (ARGatewayPortlet.TAB_FOR_UPDATE.equalsIgnoreCase(tab)) {
					query += " AND " + DBResources._SCHEMANAME + "ARADMINISTRATIVESERVICE.BLOCKED IS NULL";					
				} else if (ARGatewayPortlet.TAB_BLOCKED.equalsIgnoreCase(tab)) {
					query += " AND ";
					query += DBResources._SCHEMANAME + "ARADMINISTRATIVESERVICE.BLOCKED=?";
					tmpHm.put(column + "", ARConstants.ADMINISTRATIVE_SERVICE_BLOCKED);
					column++;
				}
				
				if (filterNumber != null && filterNumber.trim().length() > 0) {
					query += " AND ";
					query += DBResources._SCHEMANAME + "ARADMINISTRATIVESERVICE.SERVICENUMBER=?";
					tmpHm.put(column + "", filterNumber);
					column++;
				}
				if (filterName != null && filterName.trim().length() > 0) {
					query += " AND ";
					query += " UPPER(" + DBResources._SCHEMANAME + "ARADMINISTRATIVESERVICE.NAME) LIKE ?";
					tmpHm.put(column + "", "%" + filterName.toUpperCase() + "%");
					column++;
				}
				if (filterSectionName != null && filterSectionName.trim().length() > 0) {
					query += " AND ";	
					query += DBResources._SCHEMANAME + "ARADMINISTRATIVESERVICE.SECTIONNAME=?";
					tmpHm.put(column + "", filterSectionName);
					column++;
				}
				if (filterSupplierBatchId != null && filterSupplierBatchId.trim().length() > 0) {
					query += " AND ";	
					query += DBResources._SCHEMANAME + "ARADMINISTRATIVESERVICE.SUPPLIERBATCHID=?";
					tmpHm.put(column + "", filterSupplierBatchId);
					column++;
				}
				if (filterState != null && filterState.trim().length() > 0) {
					query += " AND ";
					query += DBResources._SCHEMANAME + "ARADMINISTRATIVESERVICE.STATE=?";
					tmpHm.put(column + "", filterState);
					column++;
				} else if (ARGatewayPortlet.TAB_FOR_UPDATE.equalsIgnoreCase(tab)) {
					query += " AND ";
					query += DBResources._SCHEMANAME + "ARADMINISTRATIVESERVICE.STATE NOT IN (?)";
					tmpHm.put(column + "", ARConstants.ADMINISTRATIVE_SERVICE_STATE_PROCESSED);
					column++;
				}
				if (filterSynchronized != null && filterSynchronized.trim().length() > 0) {
					query += " AND ";
					if (ARConstants.ADMINISTRATIVE_SERVICE_SYNCHRONIZED.equals(filterSynchronized)) {
						query += DBResources._SCHEMANAME + "ARADMINISTRATIVESERVICE.SYNCHRONIZED=?";
					} else {
						query += DBResources._SCHEMANAME + "ARADMINISTRATIVESERVICE.SYNCHRONIZED<>?";
					}
					tmpHm.put(column + "", ARConstants.ADMINISTRATIVE_SERVICE_SYNCHRONIZED);
					column++;
				}
				
				Logger.log(Logger.DEBUG_LEVEL, "query=" + query);
				
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				Logger.log(Logger.DEBUG_LEVEL, "column=" + column);
				if (column > 1) {
					String param = null;
					for (int i = 1; i < column; i++) {
						param = tmpHm.get(i + "");
						Logger.log(Logger.DEBUG_LEVEL, "get(" + i + ")");
						if (param != null) {
							Logger.log(Logger.DEBUG_LEVEL, "setString(" + i + "," + param + ")");
							preparedStatement.setString(i, param);							
						} else {
							Logger.log(Logger.DEBUG_LEVEL, "param is NULL [" + i + "]");
						}
					}
				}				
				
				ResultSet rs = preparedStatement.executeQuery();
				if (rs.next()) { 
					int count = rs.getInt(1);
					rs.close();
					preparedStatement.close();
					return count;
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		}
		return 0;
	}
	
	
	public int countStructures(final String tab, final String filterNumber, final String filterName, final String filterStatus, final String filterState, final String filterSynchronized, final DBTransaction transaction) {
		Logger.log(Logger.DEBUG_LEVEL, "QE -> countStructures() started...");
		Connection connection = null;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "SELECT COUNT (" + DBResources._SCHEMANAME + "ARADMINISTRATIVESTRUCTURE.ARADMINISTRATIVESTRUCTUREID" + ")";				
				query += " FROM " + DBResources._SCHEMANAME + "ARADMINISTRATIVESTRUCTURE";
				query += " WHERE 1=1";
				int column = 1;
				HashMap<String, String> tmpHm = new HashMap<String, String>(); 
				
				if (ARGatewayPortlet.TAB_FOR_UPDATE.equalsIgnoreCase(tab)) {
					query += " AND " + DBResources._SCHEMANAME + "ARADMINISTRATIVESTRUCTURE.BLOCKED IS NULL";					
				} else if (ARGatewayPortlet.TAB_BLOCKED.equalsIgnoreCase(tab)) {
					query += " AND ";
					query += DBResources._SCHEMANAME + "ARADMINISTRATIVESTRUCTURE.BLOCKED=?";
					tmpHm.put(column + "", ARConstants.ADMINISTRATIVE_STRUCTURE_BLOCKED);
					column++;
				}
				
				if (filterNumber != null && filterNumber.trim().length() > 0) {
					query += " AND ";
					query += DBResources._SCHEMANAME + "ARADMINISTRATIVESTRUCTURE.BATCHID=?";
					tmpHm.put(column + "", filterNumber);
					column++;
				}
				if (filterName != null && filterName.trim().length() > 0) {
					query += " AND ";
					query += " UPPER(" + DBResources._SCHEMANAME + "ARADMINISTRATIVESTRUCTURE.NAME) LIKE ?";
					tmpHm.put(column + "", "%" + filterName.toUpperCase() + "%");
					column++;
				}
				if (filterStatus != null && filterStatus.trim().length() > 0) {
					query += " AND ";	
					query += DBResources._SCHEMANAME + "ARADMINISTRATIVESTRUCTURE.STATUS=?";
					tmpHm.put(column + "", filterStatus);
					column++;
				}
				if (filterState != null && filterState.trim().length() > 0) {
					query += " AND ";
					query += DBResources._SCHEMANAME + "ARADMINISTRATIVESTRUCTURE.STATE=?";
					tmpHm.put(column + "", filterState);
					column++;
				} else if (ARGatewayPortlet.TAB_FOR_UPDATE.equalsIgnoreCase(tab)) {
					query += " AND ";
					query += DBResources._SCHEMANAME + "ARADMINISTRATIVESTRUCTURE.STATE NOT IN (?)";
					tmpHm.put(column + "", ARConstants.ADMINISTRATIVE_STRUCTURE_STATE_PROCESSED);
					column++;
				}
				if (filterSynchronized != null && filterSynchronized.trim().length() > 0) {
					query += " AND ";
					if (ARConstants.ADMINISTRATIVE_STRUCTURE_SYNCHRONIZED.equals(filterSynchronized)) {
						query += DBResources._SCHEMANAME + "ARADMINISTRATIVESTRUCTURE.SYNCHRONIZED=?";
					} else {
						query += DBResources._SCHEMANAME + "ARADMINISTRATIVESTRUCTURE.SYNCHRONIZED<>?";
					}
					tmpHm.put(column + "", ARConstants.ADMINISTRATIVE_STRUCTURE_SYNCHRONIZED);
					column++;
				}
				
				Logger.log(Logger.DEBUG_LEVEL, "query=" + query);
				
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				Logger.log(Logger.DEBUG_LEVEL, "column=" + column);
				if (column > 1) {
					String param = null;
					for (int i = 1; i < column; i++) {
						param = tmpHm.get(i + "");
						Logger.log(Logger.DEBUG_LEVEL, "get(" + i + ")");
						if (param != null) {
							Logger.log(Logger.DEBUG_LEVEL, "setString(" + i + "," + param + ")");
							preparedStatement.setString(i, param);							
						} else {
							Logger.log(Logger.DEBUG_LEVEL, "param is NULL [" + i + "]");
						}
					}
				}				
				
				ResultSet rs = preparedStatement.executeQuery();
				if (rs.next()) { 
					int count = rs.getInt(1);
					rs.close();
					preparedStatement.close();
					return count;
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		}
		return 0;
	}
	
	
	public static ARAdministrativeService[] findAllByFilter(final String serviceNumber, final String name, final String supplierBatchId, final String state, final String synched, final String blocked, final DBTransaction transaction) throws FinderException, Exception {
		Connection con = null;
		try {
			if (transaction != null) {
				con = transaction.getConnection();
			} else {
				con = getConnection();
			}
			if (con != null) {
				Statement stmt = con.createStatement();
				
				String query = "SELECT ARADMINISTRATIVESERVICEID, SERVICENUMBER, NAME, DESCRIPTION, SECTIONNAME, SUPPLIERBATCHID, SUPPLIERNAME, LASTUPDATEDATE, STATE, SYNCHRONIZED, BLOCKED, HASH, CONTENTUUID, USERDN, CREATIONDATE, CHANGEREGISTERDATE, SYNCHRONIZEDDATE, OPERATIONTIME " + " FROM " + DBResources._SCHEMANAME + "ARADMINISTRATIVESERVICE";
				
				String where = " WHERE ";
				if (blocked != null) {
					where += " BLOCKED ='" + blocked + "'";
				} else {
					where += " BLOCKED IS NULL";
				}
				if (serviceNumber != null) {
					where += " AND SERVICENUMBER=" + serviceNumber;
				}
				if (name != null) {
					where += " AND UPPER(NAME) LIKE '%" + name.toUpperCase() + "%'";
				}
				if (supplierBatchId != null) {
					where += " AND SUPPLIERBATCHID=" + supplierBatchId;
				}
				if (state != null) {
					where += " AND STATE='" + state + "'";
				} else {
					// Exclude results with state 'Processed'.
					where += " AND STATE NOT IN ('" + ARConstants.ADMINISTRATIVE_SERVICE_STATE_PROCESSED + "')";
				}
				if (synched != null) {
					if (ARConstants.ADMINISTRATIVE_SERVICE_SYNCHRONIZED.equals(synched)) {
						where += " AND SYNCHRONIZED='" + ARConstants.ADMINISTRATIVE_SERVICE_SYNCHRONIZED + "'";
					} else {
						where += " AND SYNCHRONIZED<>'" + ARConstants.ADMINISTRATIVE_SERVICE_SYNCHRONIZED + "'";
					}
				}
				where += " ORDER BY NAME ASC";
				
				query += where;
				ResultSet rs = stmt.executeQuery(query);
				if (rs != null && rs.next()) {
					ArrayList<ARAdministrativeService> arr = new ArrayList<ARAdministrativeService>();
					ARAdministrativeService admService = null;
					while (rs.next()) {
						admService = new ARAdministrativeService();
						admService.setId(rs.getString(1));
						admService.setServiceNumber(rs.getString(2));
						admService.setName(rs.getString(3));
						admService.setDescription(rs.getString(4));
						admService.setSectionName(rs.getString(5));
						admService.setSupplierBatchId(rs.getString(6));
						admService.setSupplierName(rs.getString(7));
						admService.setLastUpdateDate(rs.getString(8));
						if (rs.getString(8) != null) {
							admService.setLastUpdateDate(String.valueOf(ARUtils.date_TimestampToTimeMillis(rs.getString(8))));
						}
						admService.setState(rs.getString(9));
						admService.setSynchronized(rs.getString(10));
						admService.setBlocked(rs.getString(11));
						admService.setHash(rs.getString(12));
						admService.setContentUUID(rs.getString(13));
						admService.setUserDN(rs.getString(14));
						admService.setCreationDate(rs.getString(15));
						if (rs.getString(15) != null) {
							admService.setCreationDate(String.valueOf(ARUtils.date_TimestampToTimeMillis(rs.getString(15))));
						}
						admService.setChangeRegisterDate(rs.getString(16));
						if (rs.getString(16) != null) {
							admService.setChangeRegisterDate(String.valueOf(ARUtils.date_TimestampToTimeMillis(rs.getString(16))));
						}
						admService.setSynchronizedDate(rs.getString(17));
						if (rs.getString(17) != null) {
							admService.setSynchronizedDate(String.valueOf(ARUtils.date_TimestampToTimeMillis(rs.getString(17))));
						}
						admService.setOperationTime(rs.getString(18));
						if (rs.getString(18) != null) {
							admService.setOperationTime(String.valueOf(ARUtils.date_TimestampToTimeMillis(rs.getString(18))));
						}
						arr.add(admService);
					}
					rs.close();
					stmt.close();						
					return (arr != null && arr.size() > 0) ? (ARAdministrativeService[])arr.toArray(new ARAdministrativeService[0]) : null;
				} else {
					throw new FinderException("Unable to find object.");
				}
			} else
				throw new Exception("Connection or query set is not initialized.");
		} catch (SQLException e) {
			throw new Exception(e.getMessage());
		} 
	}

}
