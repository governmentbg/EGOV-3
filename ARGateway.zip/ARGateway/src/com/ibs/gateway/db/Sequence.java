package com.ibs.gateway.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Sequence {

	public synchronized static String getNextVal(String sequenceName, Connection connection) throws SQLException {
		String sequenceValue;
		sequenceValue = "-1";
		Statement st = connection.createStatement();
		String query = "";
		if (DBResources._DB2) {
			query = "select next value for " + DBResources._SCHEMANAME + sequenceName + " from SYSIBM.SYSDUMMY1";			
		} else if (DBResources._POSTRGRE) {
        	query = "select nextval('" + DBResources._SCHEMANAME + sequenceName + "')";        
		} else {
			query = "select " + DBResources._SCHEMANAME + sequenceName + ".nextval from dual";
		}
		ResultSet rs = st.executeQuery(query);
		if (rs != null) {
			if (rs.next()) {
				sequenceValue = rs.getString(1);
			}
		} // rs
		rs.close();
		st.close();
		return sequenceValue;
	} // getNextVal
} 