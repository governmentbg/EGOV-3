package com.ibs.gateway;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.PortletMode;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequest;
import javax.portlet.PortletRequestDispatcher;
import javax.portlet.PortletSession;
import javax.portlet.ReadOnlyException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.portlet.ValidatorException;
import javax.portlet.WindowState;

import org.json.JSONArray;
import org.json.JSONObject;

import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.portal.um.PumaHome;
import com.ibm.portal.um.exceptions.PumaException;
import com.ibm.workplace.wcm.api.Document;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibs.gateway.bean.Container;
import com.ibs.gateway.bean.Message;
import com.ibs.gateway.db.Base;
import com.ibs.gateway.dbo.ARAdministrativeService;
import com.ibs.gateway.dbo.ARAdministrativeStructure;
import com.ibs.gateway.management.ARServiceManagement;
import com.ibs.gateway.management.ARStructureManagement;
import com.ibs.gateway.utils.ARUtils;
import com.ibs.gateway.utils.Logger;

public class ARGatewayPortlet extends javax.portlet.GenericPortlet {
	
	private static final String JSP_FOLDER = "/_ARGateway/jsp/"; // JSP folder name
	
	public static final String ADMINISTRATIVE_STRUCTURES_PAGE = "admStructures"; 
	public static final String ADMINISTRATIVE_SERVICES_PAGE = "admServices";	
	public static final String TAB_FOR_UPDATE = "forUpdate";
	public static final String TAB_ALL = "all";
	public static final String TAB_BLOCKED = "blocked";
	public static final String CONFIG_JSP = "config";	
	public static final String EDIT_DEFAULTS_JSP = "editDefaults";
	
	public static final String CONFIG_CANCEL = "ARGatewayControllerPortletConfigCancel";
	public static final String CONFIG_SUBMIT = "ARGatewayControllerPortletConfigSubmit";
	public static final String EDIT_DEFAULTS_CANCEL = "ARGatewayControllerPortletEditSettingsCancel";
	public static final String EDIT_DEFAULTS_SUBMIT = "ARGatewayControllerPortletEditSettingsSubmit";
	public static final String SEARCH_FILTER_SUBMIT = "ARGatewayControllerPortletSearchFilterSubmit";
	
	public static final String PARAMETER_ACTION = "action";
	public static final String PARAMETER_VALUE = "value";
	public static final String PARAMETER_UUID = "uuid";
	public static final String PARAMETER_BATCH_ID = "batchId";
	public static final String PARAMETER_CREATE_OTHER_DATA = "createOtherData";
	public static final String PARAMETER_CURRENT_PAGE = "cP";
	public static final String PARAMETER_CURRENT_TAB = "cT";
	public static final String PARAMETER_FILTER_NUMBER = "filterNumber";
	public static final String PARAMETER_FILTER_NAME = "filterName";
	public static final String PARAMETER_FILTER_SECTION_NAME = "filterSectionName";
	public static final String PARAMETER_FILTER_STATUS = "filterStatus";
	public static final String PARAMETER_FILTER_STATE = "filterState";
	public static final String PARAMETER_FILTER_SUPPLIER_BATCH_ID = "filterSupplierBatchId";
	public static final String PARAMETER_FILTER_SYNCHRONIZED = "filterSynchronized";
	
	public static final String ACTION_CHANGE_TAB = "changeTab";
	public static final String ACTION_CHANGE_PAGE = "changePage";
	public static final String ACTION_RELOAD_PAGE = "reloadPage";
	public static final String ACTION_LOAD_DATA_FROM_AR = "downloadDataFromAR";
	public static final String ACTION_LOAD_ALL_CA_SERVICES_IN_WCM = "loadAllCAServicesInWCM";
	public static final String ACTION_MERGE_OLD_CA_SERVICES_WITH_NEW_ONES = "mergeOldCAServicesWithNewOnes";
	public static final String ACTION_MERGE_OLD_MUNICIPALITY_SERVICES_WITH_NEW_ONES = "mergeOldMunicipalityServicesWithNewOnes";
	public static final String ACTION_MERGE_OLD_CA_SERVICES_WITH_NEW_ONES_EXTRA = "mergeOldCAServicesWithNewOnesExtra";
	public static final String ACTION_MERGE_OLD_MUNICIPALITY_SERVICES_WITH_NEW_ONES_EXTRA = "mergeOldMunicipalityServicesWithNewOnesExtra";
	public static final String ACTION_BLOCK = "block";
	public static final String ACTION_UNBLOCK = "unblock";
	public static final String ACTION_REMOVE_WCM_REFERENCE = "removeWCMReference";
	public static final String ACTION_GET_CONTENT_UUID = "getContentUUID";
	public static final String ACTION_ADD = "add";
	public static final String ACTION_UPDATE = "update";
	public static final String ACTION_DELETE = "delete";
	public static final String ACTION_PREVIEW = "preview";
	public static final String ACTION_DOWNLOAD_OTHER_DATA= "downloadOtherDataAR";
	public static final String ACTION_DOWNLOAD_OTHER_DATA_TAXES = "downloadOtherDataTaxesAR";
	public static final String ACTION_REQUEST_DOWNLOAD_OTHER_DATA_TAXES = "requestDownloadOtherDataTaxesAR";
	public static final String ACTION_DOWNLOAD_ADMINISTRATIVE_SUPPLY_UNITS = "downloadAdministrativeSupplyUnitsAR";
	public static final String ACTION_GET_SERVICE_PROVIDERS= "getServiceProvidersFromAR";
	public static final String ACTION_CREATE_UNIFIED_SERVICE= "createUnifiedServiceFromAR";
//	public static final String ACTION_CHANGE_SEARCH_CRITERIA = "searchCriteria";
	
	public static final String ERROR_MESSAGE = "ARGatewayControllerPortletErrorMessage"; // Parameter name for the validation error message
	public static final String ERROR_KEYS = "ARGatewayControllerPortletErrorKeys"; // Parameter name for the validation failed keys
	
	public static final String SESSION_BEAN = "ARGatewayControllerPortletSessionBean"; // Bean name for the portlet session
	public static final String MESSAGE = "ARGatewayControllerMessage";
	public static final String MESSAGE_TYPE = "ARGatewayControllerMessageType";
	
	public static final String PORTLET_PREFERENCE_MAIL_SMTP_HOST = "mail.smtp.host";
	public static final String PORTLET_PREFERENCE_FROM_ADDRESS = "from.address";	
	public static final String PORTLET_PREFERENCE_MODE = "mode";
	public static final String PORTLET_PREFERENCE_STRUCTURES_RESULTS_PER_PAGE = "structures.results.per.page";
	public static final String PORTLET_PREFERENCE_SERVICES_RESULTS_PER_PAGE = "services.results.per.page";
	public static final String PORTLET_PREFERENCE_PORTLET_WIDTH = "portlet.width";
	public static final String PORTLET_PREFERENCE_THEME = "theme";
	public static final String PORTLET_PREFERENCE_LANGUAGE = "language";
	public static final String PORTLET_PREFERENCE_AUTO_PUBLISH = "autoPublish";
	public static final String PORTLET_PREFERENCE_THREAD_EXECUTION_TIME = "threadExecutionTime";
	public static final String PORTLET_PREFERENCE_DEBUG = "debug";

	public static String mode = ARConstants.MODE_ADMINISTRATIVE_STRUCTURES;
	public static int structuresResultsPerPage = ARConstants.RESULTS_PER_PAGE;
	public static int servicesResultsPerPage = ARConstants.RESULTS_PER_PAGE;
	public static String mailSmtpHost = "mail";
	public static String fromAddress = "";	
	public static String language = ARConstants.LANGUAGE_BG;
	public static String theme = ARConstants.THEME_NAME_IBM;
	public static boolean autoPublish = false;
	public static String portletWidth = null;
	public static int structuresThreadExecutionTime = ARConstants.AR_STRUCTURES_LOADER_PROCESS_TIME;
	public static int servicesThreadExecutionTime = ARConstants.AR_SERVICES_LOADER_PROCESS_TIME;
	private static PumaHome pumaHome = null;
	public static boolean preferencesLoaded = false;
	public static boolean userLoggedIn = false;
	public static com.ibm.portal.um.User currentUser = null;
	public static String currentUserDN = null;
	public static boolean debug = false;

	private static final PortletMode CUSTOM_CONFIG_MODE = new PortletMode("config");
	private static final PortletMode CUSTOM_EDIT_DEFAULTS_MODE = new PortletMode("edit_defaults");
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	public static boolean portletInitialized = false;
	
	public void init() throws PortletException {
		super.init();
		InitialContext initialcontext;
		try {
			initialcontext = new InitialContext();
			pumaHome = (PumaHome) initialcontext.lookup("portal:service/usermanagement/Puma");
		} catch (NamingException namingexception) {
			namingexception.printStackTrace();
		}
		portletInitialized = true;
	}
	
	public void doView(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		Logger.log(Logger.DEBUG_LEVEL, "doView() -> started...");

		// Set the MIME type for the render response
		if (request.getResponseContentType().equalsIgnoreCase("text/html")) {
			response.setContentType("text/html");
		} else {
			Logger.log("A request was received for an unsupported content type: " + request.getResponseContentType());
			new PortletException("reqested content type " + request.getResponseContentType() + "  not supported");
		}
		
		// Check if portlet session exists
		ARGatewayPortletSessionBean sessionBean = getSessionBean(request);
		if (sessionBean == null) {
			response.getWriter().println("<b>NO PORTLET SESSION YET</b>");
			return;
		}
				
		// Setting correct current page, according the mode.
		if (ARConstants.MODE_ADMINISTRATIVE_STRUCTURES.equals(mode)) {
			sessionBean.setCurrentPage(ARGatewayPortlet.ADMINISTRATIVE_STRUCTURES_PAGE);
		} else {
			sessionBean.setCurrentPage(ARGatewayPortlet.ADMINISTRATIVE_SERVICES_PAGE);
		}
		Logger.log(Logger.DEBUG_LEVEL, "doView() -> currentPage = " + sessionBean.getCurrentPage());
		String currentTab = getCurrentTab(sessionBean);
		Logger.log(Logger.DEBUG_LEVEL, "doView() -> currentTab = " + currentTab);
		Container container = sessionBean.getContainer().get(sessionBean.getCurrentPage() + currentTab);
		if (container == null) {
			Logger.log(Logger.DEBUG_LEVEL, "doView() -> container is NULL ");			
			container = new Container();	
			container.setResultsPerPage(structuresResultsPerPage);
			container.setOrderColumn(ARConstants.COLUMN_FOR_UPDATE_NAME);
			container.setOrder(ARConstants.ORDER_ASC);
			HashMap<String, Container> containerHm = sessionBean.getContainer();
			containerHm.put(sessionBean.getCurrentPage() + TAB_FOR_UPDATE, container);
			HashMap<String, String> tabPerPage = sessionBean.getTabPerPage();
			tabPerPage.put(sessionBean.getCurrentPage(), TAB_FOR_UPDATE);
			sessionBean.setTabPerPage(tabPerPage);		
			sessionBean.setContainer(containerHm);
			Logger.log(Logger.DEBUG_LEVEL, "doView() -> container was initialized for with tab TAB_FOR_UPDATE");
		}
					
					
		PortletRequestDispatcher rd = null;
//		Locale locale = new Locale(language);
//		PollContainerManager.process(request, response, getPortletConfig().getResourceBundle(locale), sessionBean);
		populateRequest(request, sessionBean);
		rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, sessionBean.getCurrentPage()));
		rd.include(request, response);		
	}
	
	protected void doDispatch(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		if (!WindowState.MINIMIZED.equals(request.getWindowState())) {
			ARUtils.loadPreferences(request);
			userLoggedIn = false;
			if (getPumaHome() != null) {
				com.ibm.portal.um.PumaProfile pumaProfile = getPumaHome().getProfile();
				if (pumaProfile != null) {
					try {
						com.ibm.portal.um.User user = pumaProfile.getCurrentUser();
						if (user != null) {
							userLoggedIn = true;
							currentUser = user;
							currentUserDN = pumaProfile.getIdentifier(user);
							System.out.println("userDN = " + currentUserDN);
						}
					} catch (PumaException e) {
						System.out.println(e.getMessage());
						e.printStackTrace();
					}
				}
			}
			PortletMode mode = request.getPortletMode();
			Logger.log(Logger.DEBUG_LEVEL, "doDispatch() -> mode=" + mode);
			if (CUSTOM_CONFIG_MODE.equals(mode)) {
				doCustomConfigure(request, response);
				return;
			} else if (CUSTOM_EDIT_DEFAULTS_MODE.equals(mode)) {
				doCustomEditDefaults(request, response);
				return;
			}
		}
		super.doDispatch(request, response);
	}
	
	public void processAction(ActionRequest request, ActionResponse response) throws PortletException, java.io.IOException {
		Logger.log(Logger.DEBUG_LEVEL, "processAction() started...");
		String action = request.getParameter(PARAMETER_ACTION);
		String value = request.getParameter(PARAMETER_VALUE);
		Logger.log(Logger.DEBUG_LEVEL, "processAction() param:action=" + action);
		Logger.log(Logger.DEBUG_LEVEL, "processAction() param:value=" + value);
		Locale locale = new Locale(language);
		ARGatewayPortletSessionBean sessionBean = getSessionBean(request);		
		Logger.log(Logger.DEBUG_LEVEL, "processAction() -> mode=" + ARGatewayPortlet.mode);
		HashMap<String, Container> sessionContainer = sessionBean.getContainer();
		String currentTab = getCurrentTab(sessionBean);
		Logger.log(Logger.DEBUG_LEVEL, "processAction() -> currentTab=" + currentTab);
		Container container = sessionContainer.get(sessionBean.getCurrentPage() + currentTab);
		Logger.log(Logger.DEBUG_LEVEL, "processAction() -> currentPage=" + sessionBean.getCurrentPage());
		
		// Clear message.
		if (!ACTION_RELOAD_PAGE.equals(action)) {
			sessionBean.setMessage(null);
		}
		
		// If container is not initialized or current user is NULL, show message.
		if (container == null || ARGatewayPortlet.currentUserDN == null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> container is null!");
			sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("sesson.timeout.new.was.generated")));			
			return;
		}
		
		// SET PARAMETERS TO BE VISIBILE FOR doView()...
		response.setRenderParameters(request.getParameterMap());
		if (ACTION_CHANGE_PAGE.equals(action)) {
			// NOT USED FOR NOW!
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + ACTION_CHANGE_PAGE);
			sessionBean.setCurrentPage(value);
			currentTab = sessionBean.getTabPerPage().get(value);
			if (currentTab == null) {
				if (ADMINISTRATIVE_STRUCTURES_PAGE.equalsIgnoreCase(value)) {
					currentTab = TAB_FOR_UPDATE;
				}	
			}
			container = sessionContainer.get(value + currentTab);
			if (container == null) {
				container = new Container();
			}	
			sessionContainer.put(sessionBean.getCurrentPage() + currentTab, container);
		} else if (ACTION_CHANGE_TAB.equals(action)) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + ACTION_CHANGE_TAB);
			HashMap<String, String> tabPerPage = sessionBean.getTabPerPage();
			tabPerPage.put(sessionBean.getCurrentPage(), value);
			sessionBean.setTabPerPage(tabPerPage);			
			container = sessionContainer.get(sessionBean.getCurrentPage() + value);
			if (container == null) {
				container = new Container();
				if (ARGatewayPortlet.ADMINISTRATIVE_STRUCTURES_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
					container.setResultsPerPage(structuresResultsPerPage);
				} else {
					container.setResultsPerPage(servicesResultsPerPage);
				}
				container.setOrderColumn(ARConstants.COLUMN_FOR_UPDATE_NAME);
				container.setOrder(ARConstants.ORDER_ASC);
			}						
			sessionContainer.put(sessionBean.getCurrentPage() + value, container);	
		} else if (ACTION_RELOAD_PAGE.equals(action)) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + ACTION_RELOAD_PAGE);
			
		} else if (request.getParameter(SEARCH_FILTER_SUBMIT) != null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> request.getParameter(SEARCH_FILTER_SUBMIT)");
			container.setFilterNumber(request.getParameter(PARAMETER_FILTER_NUMBER) != null && request.getParameter(PARAMETER_FILTER_NUMBER).trim().length() > 0 ? request.getParameter(PARAMETER_FILTER_NUMBER) : null);
			container.setFilterName(request.getParameter(PARAMETER_FILTER_NAME) != null && request.getParameter(PARAMETER_FILTER_NAME).trim().length() > 0 ? request.getParameter(PARAMETER_FILTER_NAME) : null);
			container.setFilterSectionName(request.getParameter(PARAMETER_FILTER_SECTION_NAME) != null && request.getParameter(PARAMETER_FILTER_SECTION_NAME).trim().length() > 0 ? request.getParameter(PARAMETER_FILTER_SECTION_NAME) : null);
			container.setFilterStatus(request.getParameter(PARAMETER_FILTER_STATUS) != null && request.getParameter(PARAMETER_FILTER_STATUS).trim().length() > 0 ? request.getParameter(PARAMETER_FILTER_STATUS) : null);
			container.setFilterSupplierBatchId(request.getParameter(PARAMETER_FILTER_SUPPLIER_BATCH_ID) != null && request.getParameter(PARAMETER_FILTER_SUPPLIER_BATCH_ID).trim().length() > 0 ? request.getParameter(PARAMETER_FILTER_SUPPLIER_BATCH_ID) : null);
			container.setFilterState(request.getParameter(PARAMETER_FILTER_STATE) != null && request.getParameter(PARAMETER_FILTER_STATE).trim().length() > 0 ? request.getParameter(PARAMETER_FILTER_STATE) : null);
			container.setFilterSynchronized(request.getParameter(PARAMETER_FILTER_SYNCHRONIZED) != null && request.getParameter(PARAMETER_FILTER_SYNCHRONIZED).trim().length() > 0 ? request.getParameter(PARAMETER_FILTER_SYNCHRONIZED) : null);
			container.setStart(0);
			sessionContainer.put(sessionBean.getCurrentPage() + currentTab, container);
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> filterNumber=" + container.getFilterNumber());
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> filterName=" + container.getFilterName());
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> filterStatus=" + container.getFilterStatus());
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> filterSupplierBatchId=" + container.getFilterSupplierBatchId());
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> filterState=" + container.getFilterState());
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> filterSynchronized=" + container.getFilterSynchronized());
		} else if (request.getParameter(CONFIG_SUBMIT) != null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> request.getParameter(CONFIG_SUBMIT)");
			String mailSmtpHost = request.getParameter(PORTLET_PREFERENCE_MAIL_SMTP_HOST);
			String fromAddress = request.getParameter(PORTLET_PREFERENCE_FROM_ADDRESS);
			String structuresResultsPerPage = request.getParameter(PORTLET_PREFERENCE_STRUCTURES_RESULTS_PER_PAGE);
			String servicesResultsPerPage = request.getParameter(PORTLET_PREFERENCE_SERVICES_RESULTS_PER_PAGE);
			String theme = request.getParameter(PORTLET_PREFERENCE_THEME);
			String language = request.getParameter(PORTLET_PREFERENCE_LANGUAGE);
			String portletWidth = request.getParameter(PORTLET_PREFERENCE_PORTLET_WIDTH);
			String debug = request.getParameter(PORTLET_PREFERENCE_DEBUG);			
			PortletPreferences prefs = request.getPreferences();
			try {
				prefs.setValue(PORTLET_PREFERENCE_MAIL_SMTP_HOST, mailSmtpHost);
				prefs.setValue(PORTLET_PREFERENCE_FROM_ADDRESS, fromAddress);
				prefs.setValue(PORTLET_PREFERENCE_STRUCTURES_RESULTS_PER_PAGE, structuresResultsPerPage);
				prefs.setValue(PORTLET_PREFERENCE_SERVICES_RESULTS_PER_PAGE, servicesResultsPerPage);
				prefs.setValue(PORTLET_PREFERENCE_THEME, theme);
				prefs.setValue(PORTLET_PREFERENCE_LANGUAGE, language);
				prefs.setValue(PORTLET_PREFERENCE_PORTLET_WIDTH, portletWidth != null && portletWidth.trim().length() > 0 ? portletWidth : null);
				prefs.setValue(PORTLET_PREFERENCE_DEBUG, debug);				
				prefs.store();
				Logger.log(Logger.DEBUG_LEVEL, "processAction() -> request.getParameter(CONFIG_SUBMIT): prefs.store();");
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("settings.were.saved")));
				response.setPortletMode(PortletMode.VIEW);
				response.setWindowState(WindowState.NORMAL);
				Logger.log(Logger.DEBUG_LEVEL, "processAction() -> request.getParameter(CONFIG_SUBMIT): done.");
			} catch (ReadOnlyException roe) {
				roe.printStackTrace();
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, roe.getMessage()));
			} catch (ValidatorException ve) {
				ve.printStackTrace();
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, ve.getMessage()));
			} catch (Exception e) {
				e.printStackTrace();
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
			}
		} else if (request.getParameter(CONFIG_CANCEL) != null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> request.getParameter(CONFIG_CANCEL)");
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);
		} else if (request.getParameter(EDIT_DEFAULTS_SUBMIT) != null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> request.getParameter(EDIT_DEFAULTS_SUBMIT)");
			String mode = request.getParameter(PORTLET_PREFERENCE_MODE);
			String mailSmtpHost = request.getParameter(PORTLET_PREFERENCE_MAIL_SMTP_HOST);
			String fromAddress = request.getParameter(PORTLET_PREFERENCE_FROM_ADDRESS);
			String structuresResultsPerPage = request.getParameter(PORTLET_PREFERENCE_STRUCTURES_RESULTS_PER_PAGE);
			String servicesResultsPerPage = request.getParameter(PORTLET_PREFERENCE_SERVICES_RESULTS_PER_PAGE);
			String theme = request.getParameter(PORTLET_PREFERENCE_THEME);
			String language = request.getParameter(PORTLET_PREFERENCE_LANGUAGE);
			String autoPublish = request.getParameter(PORTLET_PREFERENCE_AUTO_PUBLISH);
			String portletWidth = request.getParameter(PORTLET_PREFERENCE_PORTLET_WIDTH);
			String threadExecutionTime = request.getParameter(PORTLET_PREFERENCE_THREAD_EXECUTION_TIME);
			String debug = request.getParameter(PORTLET_PREFERENCE_DEBUG);
			PortletPreferences prefs = request.getPreferences();
			try {
				prefs.setValue(PORTLET_PREFERENCE_MODE, mode);
				prefs.setValue(PORTLET_PREFERENCE_MAIL_SMTP_HOST, mailSmtpHost);
				prefs.setValue(PORTLET_PREFERENCE_FROM_ADDRESS, fromAddress);
				prefs.setValue(PORTLET_PREFERENCE_STRUCTURES_RESULTS_PER_PAGE, structuresResultsPerPage);
				prefs.setValue(PORTLET_PREFERENCE_SERVICES_RESULTS_PER_PAGE, servicesResultsPerPage);
				prefs.setValue(PORTLET_PREFERENCE_THEME, theme);
				prefs.setValue(PORTLET_PREFERENCE_LANGUAGE, language);
				prefs.setValue(PORTLET_PREFERENCE_AUTO_PUBLISH, autoPublish);
				prefs.setValue(PORTLET_PREFERENCE_PORTLET_WIDTH, portletWidth != null && portletWidth.trim().length() > 0 ? portletWidth : null);
				if (threadExecutionTime != null && threadExecutionTime.trim().length() > 0) {
					try {
						Integer.parseInt(threadExecutionTime);
						prefs.setValue(PORTLET_PREFERENCE_THREAD_EXECUTION_TIME, threadExecutionTime);
						if (ARConstants.MODE_ADMINISTRATIVE_STRUCTURES.equals(mode)) {
							ARUtils.setValueToConfigFile(Base.CONFIG_FILE_LOCATION + ARConstants.STRUCTURES_CONFIG_FILE_NAME, ARConstants.THREAD_EXECUTION_TIME_PARAMETER, threadExecutionTime.trim());
						} else { // SERVICES
							ARUtils.setValueToConfigFile(Base.CONFIG_FILE_LOCATION + ARConstants.SERVICES_CONFIG_FILE_NAME, ARConstants.THREAD_EXECUTION_TIME_PARAMETER, threadExecutionTime.trim());
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				prefs.setValue(PORTLET_PREFERENCE_DEBUG, debug);
				prefs.store();
				Logger.log(Logger.DEBUG_LEVEL, "processAction() -> request.getParameter(EDIT_DEFAULTS_SUBMIT): prefs.store();");
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("settings.were.saved")));
				// Mode is changed.
				if (!ARGatewayPortlet.mode.equals(mode)) {
					Logger.log(Logger.DEBUG_LEVEL, "processAction() -> request.getParameter(EDIT_DEFAULTS_SUBMIT): mode is changed.");
					if (ARConstants.MODE_ADMINISTRATIVE_STRUCTURES.equals(mode)) {
						sessionBean.setCurrentPage(ARGatewayPortlet.ADMINISTRATIVE_STRUCTURES_PAGE);
					} else {
						sessionBean.setCurrentPage(ARGatewayPortlet.ADMINISTRATIVE_SERVICES_PAGE);
					}
				}
				response.setPortletMode(PortletMode.VIEW);
				response.setWindowState(WindowState.NORMAL);						
				Logger.log(Logger.DEBUG_LEVEL, "processAction() -> request.getParameter(EDIT_DEFAULTS_SUBMIT): done.");
			} catch (ReadOnlyException roe) {
				roe.printStackTrace();
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, roe.getMessage()));
			} catch (ValidatorException ve) {
				ve.printStackTrace();
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, ve.getMessage()));
			} catch (Exception e) {
				e.printStackTrace();
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
			}
		} else if (request.getParameter(EDIT_DEFAULTS_CANCEL) != null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> request.getParameter(EDIT_DEFAULTS_CANCEL)");
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);
		}
		sessionBean.setContainer(sessionContainer);
	}
	
	public void serveResource(ResourceRequest request, ResourceResponse response) throws PortletException, IOException {
		
		Logger.log(Logger.DEBUG_LEVEL, "serveResource() started...");
		response.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		Locale locale = new Locale(language);
		
		ARGatewayPortletSessionBean sessionBean = getSessionBean(request);
		if (sessionBean != null) {
			
			// If portelt was redeployed or session was expired, we need to fire session timeout exception.
			if (ARGatewayPortlet.currentUserDN == null) {
				JSONObject ja = new JSONObject(); 		
				ja.put("result", "0");
				ja.put("message", getPortletConfig().getResourceBundle(locale).getString("sesson.timeout.new.was.generated"));
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("sesson.timeout.new.was.generated")));
				json.put("data", ja);
				String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
				response.getWriter().print(jsonPrettyPrintString);
				response.getWriter().flush();
				response.getWriter().close();	
				return;
			}
						
			String action = request.getParameter(PARAMETER_ACTION);
			String currentTab = getCurrentTab(sessionBean);
			
			Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> action: " + action);
			
			if (ARConstants.MODE_ADMINISTRATIVE_STRUCTURES.equals(ARGatewayPortlet.mode)) {
				json = serveResourceAdministrativeStructures(request, locale, sessionBean, json, action, currentTab);
			} else if (ARConstants.MODE_ADMINISTRATIVE_SERVICES.equals(ARGatewayPortlet.mode)) {
				json = serveResourceAdministrativeServices(request, locale, sessionBean, json, action, currentTab);
			}
						
		}
		String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
		response.getWriter().print(jsonPrettyPrintString);
		response.getWriter().flush();
		response.getWriter().close();	
		
	}
	
	private JSONObject serveResourceAdministrativeStructures(ResourceRequest request, Locale locale, ARGatewayPortletSessionBean sessionBean, JSONObject json, String action, String currentTab) throws PortletException, IOException {
		if (ACTION_LOAD_DATA_FROM_AR.equals(action)) {								
			JSONObject ja = new JSONObject(); 				
			if (ARStructuresLoader.initialized) {
				try {
					int load = ARStructuresLoader.load(ARGatewayPortlet.currentUserDN);
					if (load == 0) {
						ja.put("result", "1");
						ja.put("message", getPortletConfig().getResourceBundle(locale).getString("load.completed.successfully"));
						sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("load.completed.successfully")));						
					} else if (load == -1) {
						ja.put("result", "0");
						ja.put("message", getPortletConfig().getResourceBundle(locale).getString("loading.is.running"));
						sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("loading.is.running")));
					} else if (load == -2) {
						ja.put("result", "0");
						ja.put("message", getPortletConfig().getResourceBundle(locale).getString("call.ar.service.error"));
						sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("call.ar.service.error")));
					} else {
						ja.put("result", "0");
						ja.put("message", getPortletConfig().getResourceBundle(locale).getString("system.error"));
						sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("system.error")));
					}
				} catch (Exception e) {
					e.printStackTrace();
					ja.put("result", "0");
					ja.put("message", getPortletConfig().getResourceBundle(locale).getString("system.error"));
					sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("system.error")));
				}					
			} else {
				ja.put("result", "0");
				ja.put("message", getPortletConfig().getResourceBundle(locale).getString("service.not.initialized"));
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("service.not.initialized")));
			} 
			json.put("data", ja);		
		} else if (ACTION_ADD.equals(action) || ACTION_UPDATE.equals(action)) {
			String value = request.getParameter(PARAMETER_VALUE);
			Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> value: " + value);
			JSONObject ja = new JSONObject(); 
			if (value != null && value.trim().length() > 0) {
				ARStructureManagement management = new ARStructureManagement();
				try {
					String contentUUID = management.sendAdministrativeStructureToWCM(value.trim(), ARGatewayPortlet.currentUserDN, getPortletConfig().getResourceBundle(locale));
					ja.put("result", "1");
					ja.put("contentUUID", contentUUID);
					Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> contentUUID: " + contentUUID);
				} catch (Exception e) {
					ja.put("result", "0");
					ja.put("message", e.getMessage());
					sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
				}
			} else {
				ja.put("result", "0");
				ja.put("message", getPortletConfig().getResourceBundle(locale).getString("invalid.parameters"));
			}
			json.put("data", ja);
		} else if (ACTION_BLOCK.equals(action)) {
			String value = request.getParameter(PARAMETER_VALUE);
			JSONObject ja = new JSONObject(); 
			if (value != null && value.trim().length() > 0) {
				ARStructureManagement management = new ARStructureManagement();
				try {
					ARAdministrativeStructure administrativeStructure = management.blockAdministrativeStructure(value.trim(), ARGatewayPortlet.currentUserDN, getPortletConfig().getResourceBundle(locale));
					ja.put("result", "1");
					ja.put("message", getPortletConfig().getResourceBundle(locale).getString("administrative.structure") + " '" + administrativeStructure.getName() + "' " + getPortletConfig().getResourceBundle(locale).getString("was.blocked.successfully"));
					sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("administrative.structure") + " '" + administrativeStructure.getName() + "' " + getPortletConfig().getResourceBundle(locale).getString("was.blocked.successfully")));
				} catch (Exception e) {
					ja.put("result", "0");
					ja.put("message", e.getMessage());
					sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
				}
			}
			json.put("data", ja);
		} else if (ACTION_UNBLOCK.equals(action)) {
			String value = request.getParameter(PARAMETER_VALUE);
			JSONObject ja = new JSONObject(); 
			if (value != null && value.trim().length() > 0) {
				ARStructureManagement management = new ARStructureManagement();
				try {
					ARAdministrativeStructure administrativeStructure = management.unblockAdministrativeStructure(value.trim(), ARGatewayPortlet.currentUserDN, getPortletConfig().getResourceBundle(locale));
					ja.put("result", "1");
					ja.put("message", getPortletConfig().getResourceBundle(locale).getString("administrative.structure") + " '" + administrativeStructure.getName() + "' " + getPortletConfig().getResourceBundle(locale).getString("was.unblocked.successfully"));
					sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("administrative.structure") + " '" + administrativeStructure.getName() + "' " + getPortletConfig().getResourceBundle(locale).getString("was.unblocked.successfully")));
				} catch (Exception e) {
					ja.put("result", "0");
					ja.put("message", e.getMessage());
					sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
				}
			}
			json.put("data", ja);
		} else if (ACTION_DELETE.equals(action)) {
			String value = request.getParameter(PARAMETER_VALUE);
			JSONObject ja = new JSONObject(); 
			boolean canDelete = false;
			for (int i = 0; i < ARConstants.MANAGERS_USER_NAME.length; i++) {
				if (ARConstants.MANAGERS_USER_NAME[i].equalsIgnoreCase(ARGatewayPortlet.currentUserDN)) {
					canDelete = true;
					break;
				}
			}
			if (canDelete) {
				if (value != null && value.trim().length() > 0) {
					ARStructureManagement management = new ARStructureManagement();
					try {
						ARAdministrativeStructure administrativeStructure = management.deleteAdministrativeStructure(value.trim(), getPortletConfig().getResourceBundle(locale));
						ja.put("result", "1");
						ja.put("message", getPortletConfig().getResourceBundle(locale).getString("administrative.structure") + " '" + administrativeStructure.getName() + "' " + getPortletConfig().getResourceBundle(locale).getString("was.deleted.successfully"));
						sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("administrative.structure") + " '" + administrativeStructure.getName() + "' " + getPortletConfig().getResourceBundle(locale).getString("was.deleted.successfully")));
					} catch (Exception e) {
						ja.put("result", "0");
						ja.put("message", e.getMessage());
						sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
					}
				}
			} else {
				ja.put("result", "0");
				ja.put("message", getPortletConfig().getResourceBundle(locale).getString("access.denied"));
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("access.denied")));
			}
			json.put("data", ja);
		} else {
			Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> currentPage is " + sessionBean.getCurrentPage());
			Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> currentTabForPage is " + currentTab);
			Container container = sessionBean.getContainer().get(sessionBean.getCurrentPage() + currentTab);
			if (container == null) {
				Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> container is NULL.");
			} 
			String draw = request.getParameter("draw");	
			int totalResults = 0;
			JSONArray ja = new JSONArray(); 
			if (container != null) {
				String filterNumber = container.getFilterNumber();
				String filterName = container.getFilterName();
				String filterStatus = container.getFilterStatus();
				String filterState = container.getFilterState();
				String filterSynchronized = container.getFilterSynchronized();
				try {
					container.setResultsPerPage(Integer.parseInt(request.getParameter("length")));
					container.setStart(Integer.parseInt(request.getParameter("start")));
					container.setOrderColumn(Integer.parseInt(request.getParameter("order[0][column]")));	
				} catch (Exception e) {
					e.printStackTrace();
				}
				container.setOrder(request.getParameter("order[0][dir]")); 
				Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> currentTab=" + currentTab);
				if (ARGatewayPortlet.TAB_FOR_UPDATE.equalsIgnoreCase(currentTab)) {
					Logger.log(Logger.DEBUG_LEVEL, "serveResource -> TAB_FOR_UPDATE");					
					ARStructureManagement management = new ARStructureManagement();
					totalResults = management.countStructures(currentTab, filterNumber, filterName, filterStatus, filterState, null);
					if (totalResults > 0) {
						ARAdministrativeStructure[] structures = management.loadAdministrativeStructuresForUpdate(filterNumber, filterName, filterStatus, filterState, container.getStart(), container.getResultsPerPage(), container.getOrderColumn(), container.getOrder());
						if (structures != null && structures.length > 0) {
							Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> structures.length=" + structures.length);
							JSONArray tmpJA = null; 
							//for (int i = 0; i < structures.length; i++) {
							for (int i = container.getStart(); i < structures.length; i++) {
								tmpJA = new JSONArray();
								tmpJA.put(structures[i].getBatchId().toString());
								tmpJA.put(structures[i].getName());
								tmpJA.put(structures[i].getStatus());
								tmpJA.put(structures[i].getState());
								tmpJA.put((structures[i].getSynchronizedDate() != null) ? ARUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(structures[i].getSynchronizedDate().getTime()) : "");
								tmpJA.put((structures[i].getContentUUID() != null) ? structures[i].getContentUUID() : "");
								tmpJA.put(structures[i].getId());
								ja.put(tmpJA);					 
							}				
						} else {
							Logger.log(Logger.DEBUG_LEVEL, "serveResource -> structures.length=0");
						}
					}
				} else if (ARGatewayPortlet.TAB_ALL.equalsIgnoreCase(currentTab)) {
					Logger.log(Logger.DEBUG_LEVEL, "serveResource -> TAB_ALL");		
					ARStructureManagement management = new ARStructureManagement();
					totalResults = management.countStructures(currentTab, filterNumber, filterName, filterStatus, filterState, filterSynchronized);
					if (totalResults > 0) {
						ARAdministrativeStructure[] structures = management.loadAllAdministrativeStructures(filterNumber, filterName, filterStatus, filterState, filterSynchronized, container.getStart(), container.getResultsPerPage(), container.getOrderColumn(), container.getOrder());
						if (structures != null && structures.length > 0) {
							Logger.log(Logger.DEBUG_LEVEL, "serveResource -> structures.length=" + structures.length);
							JSONArray tmpJA = null; 							
							//for (int i = 0; i < structures.length; i++) {
							for (int i = container.getStart(); i < structures.length; i++) {
								tmpJA = new JSONArray();
								tmpJA.put(structures[i].getBatchId().toString());
								tmpJA.put(structures[i].getName());
								tmpJA.put(structures[i].getUic());
								tmpJA.put(structures[i].getStatus());
								tmpJA.put(structures[i].getState());
								tmpJA.put(structures[i].getSynchronized());
								tmpJA.put(structures[i].getBlocked());
								tmpJA.put((structures[i].getSynchronizedDate() != null) ? ARUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(structures[i].getSynchronizedDate().getTime()) : "");
								tmpJA.put((structures[i].getContentUUID() != null) ? structures[i].getContentUUID() : "");
								tmpJA.put(structures[i].getId());
								ja.put(tmpJA);					
							}				
						} else {
							Logger.log(Logger.DEBUG_LEVEL, "serveResource -> structures.length=0");
						}
					}
				} else if (ARGatewayPortlet.TAB_BLOCKED.equalsIgnoreCase(currentTab)) {
					Logger.log(Logger.DEBUG_LEVEL, "serveResource -> TAB_BLOCKED");
					ARStructureManagement management = new ARStructureManagement();
					totalResults = management.countStructures(currentTab, filterNumber, filterName, filterStatus, null, null);
					if (totalResults > 0) {
						ARAdministrativeStructure[] structures = management.loadAllBlockedAdministrativeStructures(filterNumber, filterName, filterStatus, container.getStart(), container.getResultsPerPage(), container.getOrderColumn(), container.getOrder());
						if (structures != null && structures.length > 0) {
							Logger.log(Logger.DEBUG_LEVEL, "serveResource -> structures.length=" + structures.length);
							JSONArray tmpJA = null; 
							//for (int i = 0; i < structures.length; i++) {
							for (int i = container.getStart(); i < structures.length; i++) {
								tmpJA = new JSONArray();
								tmpJA.put(structures[i].getBatchId().toString());
								tmpJA.put(structures[i].getName());
								tmpJA.put(structures[i].getStatus());
								tmpJA.put((structures[i].getSynchronizedDate() != null) ? ARUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(structures[i].getSynchronizedDate().getTime()) : "");
								tmpJA.put((structures[i].getContentUUID() != null) ? structures[i].getContentUUID() : "");								
								tmpJA.put(structures[i].getId());
								ja.put(tmpJA);					
							}				
						} else {
							Logger.log(Logger.DEBUG_LEVEL, "serveResource -> structures.length=0");
						}
					}
				}				
			}
			json.put("draw", draw);	
			json.put("recordsTotal", totalResults);	
			json.put("recordsFiltered", totalResults);	
			json.put("data", ja);
		}
		return json;
	}
	
	@SuppressWarnings("unchecked")
	private JSONObject serveResourceAdministrativeServices(ResourceRequest request, Locale locale, ARGatewayPortletSessionBean sessionBean, JSONObject json, String action, String currentTab) throws PortletException, IOException {
		if (ACTION_LOAD_DATA_FROM_AR.equals(action)) {								
			JSONObject ja = new JSONObject(); 				
			if (ARServicesLoader.initialized) {
				try {
					int load = ARServicesLoader.load(ARGatewayPortlet.currentUserDN);
					if (load == 0) {
						ja.put("result", "1");
						ja.put("message", getPortletConfig().getResourceBundle(locale).getString("load.completed.successfully"));
						sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("load.completed.successfully")));						
					} else if (load == -1) {
						ja.put("result", "0");
						ja.put("message", getPortletConfig().getResourceBundle(locale).getString("loading.is.running"));
						sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("loading.is.running")));
					} else if (load == -2) {
						ja.put("result", "0");
						ja.put("message", getPortletConfig().getResourceBundle(locale).getString("call.ar.service.error"));
						sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("call.ar.service.error")));
					} else {
						ja.put("result", "0");
						ja.put("message", getPortletConfig().getResourceBundle(locale).getString("system.error"));
						sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("system.error")));
					}
				} catch (Exception e) {
					e.printStackTrace();
					ja.put("result", "0");
					ja.put("message", getPortletConfig().getResourceBundle(locale).getString("system.error"));
					sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("system.error")));
				}					
			} else {
				ja.put("result", "0");
				ja.put("message", getPortletConfig().getResourceBundle(locale).getString("service.not.initialized"));
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("service.not.initialized")));
			} 
			json.put("data", ja);
		} else if (ACTION_LOAD_ALL_CA_SERVICES_IN_WCM.equals(action)) {								
			JSONObject ja = new JSONObject(); 				
			try {
				ARServiceManagement management = new ARServiceManagement();
				management.loadAllCentralAdminstrationSericesInWCM(ARGatewayPortlet.currentUserDN, getPortletConfig().getResourceBundle(locale));
				ja.put("result", "1");
				ja.put("message", getPortletConfig().getResourceBundle(locale).getString("load.all.ca.services.in.wcm.completed.successfully"));
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("load.all.ca.services.in.wcm.completed.successfully")));						
			} catch (Exception e) {
				e.printStackTrace();
				ja.put("result", "0");
				ja.put("message", getPortletConfig().getResourceBundle(locale).getString("system.error"));
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("system.error")));
			}					
			json.put("data", ja);	
		} else if (ACTION_MERGE_OLD_CA_SERVICES_WITH_NEW_ONES.equals(action)) {								
			JSONObject ja = new JSONObject(); 				
			try {
				ARServiceManagement management = new ARServiceManagement();
				management.mergeOldServicesWithNewOnes(EgovWCMCache.AR_SERVICE_SECTION_NAME_CENTRAL_ADMINISTRATIONS, ARGatewayPortlet.currentUserDN, getPortletConfig().getResourceBundle(locale));
				ja.put("result", "1");
				ja.put("message", getPortletConfig().getResourceBundle(locale).getString("load.all.ca.services.in.wcm.completed.successfully"));
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("merge.old.ca.services.with.new.ones.completed.successfully")));						
			} catch (Exception e) {
				e.printStackTrace();
				ja.put("result", "0");
				ja.put("message", getPortletConfig().getResourceBundle(locale).getString("system.error"));
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("system.error")));
			}					
			json.put("data", ja);	
		} else if (ACTION_MERGE_OLD_MUNICIPALITY_SERVICES_WITH_NEW_ONES.equals(action)) {								
			JSONObject ja = new JSONObject(); 				
			try {
				ARServiceManagement management = new ARServiceManagement();
				management.mergeOldServicesWithNewOnes(EgovWCMCache.AR_SERVICE_SECTION_NAME_MUNICIPAL_ADMINISTRATIONS, ARGatewayPortlet.currentUserDN, getPortletConfig().getResourceBundle(locale));
				ja.put("result", "1");
				ja.put("message", getPortletConfig().getResourceBundle(locale).getString("load.all.municipality.services.in.wcm.completed.successfully"));
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("merge.old.municipality.services.with.new.ones.completed.successfully")));						
			} catch (Exception e) {
				e.printStackTrace();
				ja.put("result", "0");
				ja.put("message", getPortletConfig().getResourceBundle(locale).getString("system.error"));
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("system.error")));
			}					
			json.put("data", ja);	
		} else if (ACTION_MERGE_OLD_CA_SERVICES_WITH_NEW_ONES_EXTRA.equals(action)) {								
			JSONObject ja = new JSONObject(); 				
			try {
				ARServiceManagement management = new ARServiceManagement();
				management.mergeOldServicesWithNewOnesExtra(EgovWCMCache.AR_SERVICE_SECTION_NAME_CENTRAL_ADMINISTRATIONS, ARGatewayPortlet.currentUserDN, getPortletConfig().getResourceBundle(locale));
				ja.put("result", "1");
				ja.put("message", getPortletConfig().getResourceBundle(locale).getString("load.all.ca.services.in.wcm.completed.successfully"));
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("merge.old.ca.services.with.new.ones.completed.successfully")));						
			} catch (Exception e) {
				e.printStackTrace();
				ja.put("result", "0");
				ja.put("message", getPortletConfig().getResourceBundle(locale).getString("system.error"));
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("system.error")));
			}					
			json.put("data", ja);	
		} else if (ACTION_MERGE_OLD_MUNICIPALITY_SERVICES_WITH_NEW_ONES_EXTRA.equals(action)) {								
			JSONObject ja = new JSONObject(); 				
			try {
				ARServiceManagement management = new ARServiceManagement();
				management.mergeOldServicesWithNewOnesExtra(EgovWCMCache.AR_SERVICE_SECTION_NAME_MUNICIPAL_ADMINISTRATIONS, ARGatewayPortlet.currentUserDN, getPortletConfig().getResourceBundle(locale));
				ja.put("result", "1");
				ja.put("message", getPortletConfig().getResourceBundle(locale).getString("load.all.municipality.services.in.wcm.completed.successfully"));
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("merge.old.municipality.services.with.new.ones.completed.successfully")));						
			} catch (Exception e) {
				e.printStackTrace();
				ja.put("result", "0");
				ja.put("message", getPortletConfig().getResourceBundle(locale).getString("system.error"));
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("system.error")));
			}					
			json.put("data", ja);	
		} else if (ACTION_GET_CONTENT_UUID.equals(action)) {
			String uuid = request.getParameter(PARAMETER_UUID);
			String value = request.getParameter(PARAMETER_VALUE);
			Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> value: " + value + ", uuid:" + uuid);
			JSONObject ja = new JSONObject(); 
			if (value != null && value.trim().length() > 0) {
				DocumentId<Document> docId = null;
				String contentUUID = uuid;
				try {
					try {
						docId = EgovWCMCache.getWorkspace().getById(EgovWCMCache.getWorkspace().createDocumentId(uuid));
					} catch (Exception e) {}
					if (docId == null) {
						ARServiceManagement management = new ARServiceManagement();
						docId = management.getServiceContentUUIDFromWCM(value.trim());
					}
					if (docId != null) {
						contentUUID = docId.getID();
						ja.put("result", "1");
						ja.put("contentUUID", contentUUID);						
					} else {
						ja.put("result", "0");
						ja.put("message", "Не е намерена услугата в WCM.");
					}
					Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> contentUUID: " + contentUUID);
				} catch (Exception e) {
					ja.put("result", "0");
					ja.put("message", e.getMessage());
					sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
				}
			} else {
				ja.put("result", "0");
				ja.put("message", getPortletConfig().getResourceBundle(locale).getString("invalid.parameters"));
			}
			json.put("data", ja);
		}
		// This will add/update content of type "serviceProvidedBySupplier".
		else if (ACTION_ADD.equals(action) || ACTION_UPDATE.equals(action)) {
			String value = request.getParameter(PARAMETER_VALUE);
			Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> value: " + value);
			JSONObject ja = new JSONObject(); 
			if (value != null && value.trim().length() > 0) {
				ARServiceManagement management = new ARServiceManagement();
				try {
					String contentUUID = management.sendAdministrativeServiceToWCM(value.trim(), ARGatewayPortlet.currentUserDN, getPortletConfig().getResourceBundle(locale));
					ja.put("result", "1");
					ja.put("contentUUID", contentUUID);
					Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> contentUUID: " + contentUUID);
				} catch (Exception e) {
					ja.put("result", "0");
					ja.put("message", e.getMessage());
					sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
				}
			} else {
				ja.put("result", "0");
				ja.put("message", getPortletConfig().getResourceBundle(locale).getString("invalid.parameters"));
			}
			json.put("data", ja);
		}
		else if (ACTION_DOWNLOAD_OTHER_DATA.equals(action)) {
			String value = request.getParameter(PARAMETER_VALUE);
			Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> value: " + value);
			JSONObject ja = new JSONObject(); 
			if (value != null && value.trim().length() > 0) {
				ARServiceManagement management = new ARServiceManagement();
				try {
					String contentUUID = management.downloadOtherDataFromARToUnifiedServiceInWCM(value.trim(), ARGatewayPortlet.currentUserDN, getPortletConfig().getResourceBundle(locale));
					ja.put("result", "1");
					ja.put("contentUUID", contentUUID);
					Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> contentUUID: " + contentUUID);
				} catch (Exception e) {
					ja.put("result", "0");
					ja.put("message", e.getMessage());
					sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
				}
			} else {
				ja.put("result", "0");
				ja.put("message", getPortletConfig().getResourceBundle(locale).getString("invalid.parameters"));
			}
			json.put("data", ja);
		}
		else if (ACTION_REQUEST_DOWNLOAD_OTHER_DATA_TAXES.equals(action)) {
			String value = request.getParameter(PARAMETER_VALUE);
			Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> action: " + ACTION_REQUEST_DOWNLOAD_OTHER_DATA_TAXES);
			Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> value: " + value);
			JSONObject ja = new JSONObject(); 
			try {
				ARCronJobsLoader.cronJobOtherDataRequested = true;
				ja.put("result", "1");					
				Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> result: 1 [OK]");
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_INFORMATION, "Вашата заявка за обновяване на Такси и срокове, беше успешно регистрирана в систената!"));
			} catch (Exception e) {
				ja.put("result", "0");
				ja.put("message", e.getMessage());
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
			}
			json.put("data", ja);
		}
		else if (ACTION_DOWNLOAD_OTHER_DATA_TAXES.equals(action)) {
			String value = request.getParameter(PARAMETER_VALUE);
			Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> action: " + ACTION_DOWNLOAD_OTHER_DATA_TAXES);
			Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> value: " + value);
			JSONObject ja = new JSONObject(); 
			ARServiceManagement management = new ARServiceManagement();
			try {
				String result = management.downloadOtherDataTaxesFromARToAllUnifiedServiceInWCM(ARGatewayPortlet.currentUserDN);
				ja.put("result", "1");					
				Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> result: " + result);
			} catch (Exception e) {
				ja.put("result", "0");
				ja.put("message", e.getMessage());
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
			}
			json.put("data", ja);
		}
		else if (ACTION_DOWNLOAD_ADMINISTRATIVE_SUPPLY_UNITS.equals(action)) {
			String value = request.getParameter(PARAMETER_VALUE);
			Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> action: " + ACTION_DOWNLOAD_ADMINISTRATIVE_SUPPLY_UNITS);
			Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> value: " + value);
			JSONObject ja = new JSONObject(); 
			ARServiceManagement management = new ARServiceManagement();
			try {
				String result = management.downloadAdministrativeSupplyUnitsFromARToServicesProvidedBySupplierInWCM(ARGatewayPortlet.currentUserDN, getPortletConfig().getResourceBundle(locale));
				ja.put("result", "1");					
				Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> result: " + result);
			} catch (Exception e) {
				ja.put("result", "0");
				ja.put("message", e.getMessage());
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
			}
			json.put("data", ja);
		}
		else if (ACTION_GET_SERVICE_PROVIDERS.equals(action)) {
			String value = request.getParameter(PARAMETER_VALUE);
			Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> value: " + value);
			JSONObject ja = new JSONObject(); 
			if (value != null && value.trim().length() > 0) { 
				ARServiceManagement management = new ARServiceManagement();
				try {
					ARAdministrativeStructure[] administrativeStructures = management.getServiceSuppliers(value.trim(), getPortletConfig().getResourceBundle(locale));					
					if (administrativeStructures != null && administrativeStructures.length > 0) {
						JSONArray jaContainer = new JSONArray();
						JSONArray tmpJA = null;
						for (int i = 0; i < administrativeStructures.length; i++) {
							tmpJA = new JSONArray();
							tmpJA.put(administrativeStructures[i].getBatchId().toString());
							tmpJA.put(administrativeStructures[i].getName());
							jaContainer.put(tmpJA);					
						}
						ja.put("result", "1");						
						ja.put("suppliers", jaContainer);
					} else {
						ja.put("result", "1");
						// Set empty results, usualy we should not get here!
						ja.put("suppliers", new JSONArray());						
					}					
					Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> administrativeStructures.length: " + (administrativeStructures != null ? administrativeStructures.length : 0));
				} catch (Exception e) {
					ja.put("result", "0");
					ja.put("message", e.getMessage());
					sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
				}
			} else {
				ja.put("result", "0");
				ja.put("message", getPortletConfig().getResourceBundle(locale).getString("invalid.parameters"));
			}
			json.put("data", ja);
		}
		else if (ACTION_CREATE_UNIFIED_SERVICE.equals(action)) {
			String value = request.getParameter(PARAMETER_VALUE);
			String batchId = request.getParameter(PARAMETER_BATCH_ID);
			boolean createOtherData = "1".equalsIgnoreCase(request.getParameter(PARAMETER_CREATE_OTHER_DATA));
			Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> value: " + value);
			JSONObject ja = new JSONObject(); 
			if (value != null && value.trim().length() > 0) { 
				ARServiceManagement management = new ARServiceManagement();
				try {
					String contentUUID = management.createUnifiedService(value.trim(), batchId, createOtherData, ARGatewayPortlet.currentUserDN, getPortletConfig().getResourceBundle(locale));
					ja.put("result", "1");
					ja.put("contentUUID", contentUUID);
					Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> contentUUID: " + contentUUID);
				} catch (Exception e) {
					ja.put("result", "0");
					ja.put("message", e.getMessage());
					sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
				}
			} else {
				ja.put("result", "0");
				ja.put("message", getPortletConfig().getResourceBundle(locale).getString("invalid.parameters"));
			}
			json.put("data", ja);
		} else if (ACTION_BLOCK.equals(action)) {
			String value = request.getParameter(PARAMETER_VALUE);
			JSONObject ja = new JSONObject(); 
			if (value != null && value.trim().length() > 0) {
				ARServiceManagement management = new ARServiceManagement();
				try {
					ARAdministrativeService administrativeService = management.blockAdministrativeService(value.trim(), ARGatewayPortlet.currentUserDN, getPortletConfig().getResourceBundle(locale));
					ja.put("result", "1");
					ja.put("message", getPortletConfig().getResourceBundle(locale).getString("administrative.service") + " '" + administrativeService.getName() + "' " + getPortletConfig().getResourceBundle(locale).getString("was.blocked.successfully"));
					sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("administrative.service") + " '" + administrativeService.getName() + "' " + getPortletConfig().getResourceBundle(locale).getString("was.blocked.successfully")));
				} catch (Exception e) {
					ja.put("result", "0");
					ja.put("message", e.getMessage());
					sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
				}
			}
			json.put("data", ja);
		} else if (ACTION_UNBLOCK.equals(action)) {
			String value = request.getParameter(PARAMETER_VALUE);
			JSONObject ja = new JSONObject(); 
			if (value != null && value.trim().length() > 0) {
				ARServiceManagement management = new ARServiceManagement();
				try {
					ARAdministrativeService administrativeService = management.unblockAdministrativeService(value.trim(), ARGatewayPortlet.currentUserDN, getPortletConfig().getResourceBundle(locale));
					ja.put("result", "1");
					ja.put("message", getPortletConfig().getResourceBundle(locale).getString("administrative.service") + " '" + administrativeService.getName() + "' " + getPortletConfig().getResourceBundle(locale).getString("was.unblocked.successfully"));
					sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("administrative.service") + " '" + administrativeService.getName() + "' " + getPortletConfig().getResourceBundle(locale).getString("was.unblocked.successfully")));
				} catch (Exception e) {
					ja.put("result", "0");
					ja.put("message", e.getMessage());
					sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
				}
			}
			json.put("data", ja);
		} else if (ACTION_REMOVE_WCM_REFERENCE.equals(action)) {
			String value = request.getParameter(PARAMETER_VALUE);
			JSONObject ja = new JSONObject(); 
			if (value != null && value.trim().length() > 0) {
				ARServiceManagement management = new ARServiceManagement();
				try {
					ARAdministrativeService administrativeService = management.removeWCMReferenceFromAdministrativeService(value.trim(), ARGatewayPortlet.currentUserDN, getPortletConfig().getResourceBundle(locale));
					ja.put("result", "1");
					ja.put("message", getPortletConfig().getResourceBundle(locale).getString("administrative.service") + " '" + administrativeService.getName() + "' " + getPortletConfig().getResourceBundle(locale).getString("was.removed.wcm.reference"));
					sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("administrative.service") + " '" + administrativeService.getName() + "' " + getPortletConfig().getResourceBundle(locale).getString("was.removed.wcm.reference")));
				} catch (Exception e) {
					ja.put("result", "0");
					ja.put("message", e.getMessage());
					sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
				}
			}
			json.put("data", ja);
		} else if (ACTION_DELETE.equals(action)) {
			String value = request.getParameter(PARAMETER_VALUE);
			JSONObject ja = new JSONObject(); 
			boolean canDelete = false;
			for (int i = 0; i < ARConstants.MANAGERS_USER_NAME.length; i++) {
				if (ARConstants.MANAGERS_USER_NAME[i].equalsIgnoreCase(ARGatewayPortlet.currentUserDN)) {
					canDelete = true;
					break;
				}
			}
			if (canDelete) {
				if (value != null && value.trim().length() > 0) {
					ARServiceManagement management = new ARServiceManagement();
					try {
						ARAdministrativeService administrativeService = management.deleteAdministrativeService(value.trim(), getPortletConfig().getResourceBundle(locale));
						ja.put("result", "1");
						ja.put("message", getPortletConfig().getResourceBundle(locale).getString("administrative.service") + " '" + administrativeService.getName() + "' " + getPortletConfig().getResourceBundle(locale).getString("was.deleted.successfully"));
						sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("administrative.service") + " '" + administrativeService.getName() + "' " + getPortletConfig().getResourceBundle(locale).getString("was.deleted.successfully")));
					} catch (Exception e) {
						ja.put("result", "0");
						ja.put("message", e.getMessage());
						sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
					}
				}
			} else {
				ja.put("result", "0");
				ja.put("message", getPortletConfig().getResourceBundle(locale).getString("access.denied"));
				sessionBean.setMessage(new Message(ARConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("access.denied")));
			}
			json.put("data", ja);
		} else {
			Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> mode = " + ARGatewayPortlet.mode);
			Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> currentPage is " + sessionBean.getCurrentPage());
			Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> currentTabForPage is " + currentTab);
			Container container = sessionBean.getContainer().get(sessionBean.getCurrentPage() + currentTab);
			if (container == null) {
				Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> container is NULL.");
			} 
			String draw = request.getParameter("draw");	
			int totalResults = 0;
			JSONArray ja = new JSONArray(); 
			if (container != null) {
				String filterNumber = container.getFilterNumber();
				String filterName = container.getFilterName();
				String filterSectionName = container.getFilterSectionName();
				String filterSupplierBatchId = container.getFilterSupplierBatchId();
				String filterState = container.getFilterState();
				String filterSynchronized = container.getFilterSynchronized();
				try {
					container.setResultsPerPage(Integer.parseInt(request.getParameter("length")));
					container.setStart(Integer.parseInt(request.getParameter("start")));
					container.setOrderColumn(Integer.parseInt(request.getParameter("order[0][column]")));	
				} catch (Exception e) {
					e.printStackTrace();
				}
				container.setOrder(request.getParameter("order[0][dir]")); 
				Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> currentTab=" + currentTab);
				if (ARGatewayPortlet.TAB_FOR_UPDATE.equalsIgnoreCase(currentTab)) {
					Logger.log(Logger.DEBUG_LEVEL, "serveResource -> TAB_FOR_UPDATE");					
					ARServiceManagement management = new ARServiceManagement(); 
					totalResults = management.countServices(currentTab, filterNumber, filterName, filterSectionName, filterSupplierBatchId, null, null);
					if (totalResults > 0) {
						ARAdministrativeService[] services = management.loadAdministrativeServicesForUpdate(filterNumber, filterName, filterSectionName, filterSupplierBatchId, filterState, container.getStart(), container.getResultsPerPage(), container.getOrderColumn(), container.getOrder());
						if (services != null && services.length > 0) {
							Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> services.length=" + services.length);
							JSONArray tmpJA = null; 
							//for (int i = 0; i < services.length; i++) {
							for (int i = container.getStart(); i < services.length; i++) {
								tmpJA = new JSONArray();
								tmpJA.put(services[i].getServiceNumber().toString());
								tmpJA.put(services[i].getName());
								tmpJA.put(services[i].getSectionName() != null ? services[i].getSectionName() : "");
								tmpJA.put(services[i].getSupplierBatchId() != null ? services[i].getSupplierBatchId().toString() : "");
								tmpJA.put(services[i].getSupplierName() != null ? services[i].getSupplierName() : "");
								tmpJA.put(services[i].getState());
								tmpJA.put((services[i].getSynchronizedDate() != null) ? ARUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(services[i].getSynchronizedDate().getTime()) : "");
								tmpJA.put((services[i].getContentUUID() != null) ? services[i].getContentUUID() : "");
								tmpJA.put(services[i].getId());
								ja.put(tmpJA);					
							}				
						} else {
							Logger.log(Logger.DEBUG_LEVEL, "serveResource -> services.length=0");
						}
					}
				} else if (ARGatewayPortlet.TAB_ALL.equalsIgnoreCase(currentTab)) {
					Logger.log(Logger.DEBUG_LEVEL, "serveResource -> TAB_ALL");		
					ARServiceManagement management = new ARServiceManagement();
					totalResults = management.countServices(currentTab, filterNumber, filterName, filterSectionName, filterSupplierBatchId, filterState, filterSynchronized);
					if (totalResults > 0) {
						ARAdministrativeService[] services = management.loadAllAdministrativeServices(filterNumber, filterName, filterSectionName, filterSupplierBatchId, filterState, filterSynchronized, container.getStart(), container.getResultsPerPage(), container.getOrderColumn(), container.getOrder());
						if (services != null && services.length > 0) {
							Logger.log(Logger.DEBUG_LEVEL, "serveResource -> services.length=" + services.length);
							JSONArray tmpJA = null; 
							//for (int i = 0; i < services.length; i++) {
							for (int i = container.getStart(); i < services.length; i++) {
								tmpJA = new JSONArray();
								tmpJA.put(services[i].getServiceNumber().toString());
								tmpJA.put(services[i].getName());
								tmpJA.put(services[i].getSectionName() != null ? services[i].getSectionName() : "");
								tmpJA.put(services[i].getSupplierBatchId() != null ? services[i].getSupplierBatchId().toString() : "");
								tmpJA.put(services[i].getSupplierName() != null ? services[i].getSupplierName() : "");
								tmpJA.put(services[i].getState());
								tmpJA.put(services[i].getSynchronized());
								tmpJA.put(services[i].getBlocked());
								tmpJA.put((services[i].getSynchronizedDate() != null) ? ARUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(services[i].getSynchronizedDate().getTime()) : "");
								tmpJA.put((services[i].getContentUUID() != null) ? services[i].getContentUUID() : "");
								tmpJA.put(services[i].getId());
								ja.put(tmpJA);					
							}				
						} else {
							Logger.log(Logger.DEBUG_LEVEL, "serveResource -> services.length=0");
						}
					}
				} else if (ARGatewayPortlet.TAB_BLOCKED.equalsIgnoreCase(currentTab)) {
					Logger.log(Logger.DEBUG_LEVEL, "serveResource -> TAB_BLOCKED");
					ARServiceManagement management = new ARServiceManagement();
					totalResults = management.countServices(currentTab, filterNumber, filterName, null, filterSupplierBatchId, null, null);
					if (totalResults > 0) {
					ARAdministrativeService[] services = management.loadAllBlockedAdministrativeServices(filterNumber, filterName, filterSupplierBatchId, container.getStart(), container.getResultsPerPage(), container.getOrderColumn(), container.getOrder());
						if (services != null && services.length > 0) {
							Logger.log(Logger.DEBUG_LEVEL, "serveResource -> services.length=" + services.length);
							JSONArray tmpJA = null; 
							//for (int i = 0; i < services.length; i++) {
							for (int i = container.getStart(); i < services.length; i++) {
								tmpJA = new JSONArray();
								tmpJA.put(services[i].getServiceNumber().toString());
								tmpJA.put(services[i].getName());
								tmpJA.put(services[i].getSectionName() != null ? services[i].getSectionName() : "");
								tmpJA.put(services[i].getSupplierBatchId() != null ? services[i].getSupplierBatchId().toString() : "");
								tmpJA.put(services[i].getSupplierName() != null ? services[i].getSupplierName() : "");
								tmpJA.put((services[i].getSynchronizedDate() != null) ? ARUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(services[i].getSynchronizedDate().getTime()) : "");
								tmpJA.put((services[i].getContentUUID() != null) ? services[i].getContentUUID() : "");								
								tmpJA.put(services[i].getId());
								ja.put(tmpJA);					
							}				
						} else {
							Logger.log(Logger.DEBUG_LEVEL, "serveResource -> services.length=0");
						}
					}
				}
			}
			json.put("draw", draw);	
			json.put("recordsTotal", totalResults);	
			json.put("recordsFiltered", totalResults);	
			json.put("data", ja);
		}
		return json;
	}
	
	protected void doCustomConfigure(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		response.setContentType(request.getResponseContentType());
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, CONFIG_JSP));
		rd.include(request, response);
	}

	protected void doCustomEditDefaults(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		response.setContentType(request.getResponseContentType());
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, EDIT_DEFAULTS_JSP));
		rd.include(request, response);
	}

	private static ARGatewayPortletSessionBean getSessionBean(PortletRequest request) {
		PortletSession session = request.getPortletSession();
		if (session == null) {
			return null;
		}
		ARGatewayPortletSessionBean sessionBean = (ARGatewayPortletSessionBean) session.getAttribute(SESSION_BEAN);
		if (sessionBean == null) {
			sessionBean = new ARGatewayPortletSessionBean();
			session.setAttribute(SESSION_BEAN, sessionBean);
		}
		return sessionBean;
	}

	private static void populateRequest(RenderRequest request, ARGatewayPortletSessionBean sessionBean) {
		if (sessionBean != null && sessionBean.getParameterMap() != null && sessionBean.getParameterMap().size() > 0) {
			java.util.Map<String, String[]> map = sessionBean.getParameterMap();
			Iterator<String> it = map.keySet().iterator();
			String paramName = null;
			String[] paramValues = null;
			while (it.hasNext()) {
				paramName = (String) it.next();
				paramValues = map.get(paramName);
				if (paramValues != null) {
					if (paramValues.length > 1) {
						request.setAttribute(paramName, paramValues);
					} else {
						request.setAttribute(paramName, paramValues[0]);
					}
				}
				// System.out.println(paramName + "=" + paramValues[0]);
			}
		}
	}
	
	private static String getCurrentTab(ARGatewayPortletSessionBean sessionBean) {
		String currentTab = sessionBean.getTabPerPage().get(sessionBean.getCurrentPage());
		if (currentTab == null) {
			if (ARConstants.MODE_ADMINISTRATIVE_STRUCTURES.equals(ARGatewayPortlet.mode)) {
				if (ARGatewayPortlet.ADMINISTRATIVE_STRUCTURES_PAGE.equals(sessionBean.getCurrentPage())) {
					return TAB_FOR_UPDATE;
				}
			} else {
				if (ARGatewayPortlet.ADMINISTRATIVE_SERVICES_PAGE.equals(sessionBean.getCurrentPage())) {
					return TAB_FOR_UPDATE;
				}
			}
		}
		return currentTab;
	}
	
	private static String getJspFilePath(RenderRequest request, String jspFile) {
		String markup = request.getProperty("wps.markup");
		if (markup == null)
			markup = getMarkup(request.getResponseContentType());
		return JSP_FOLDER + markup + "/" + jspFile + "." + getJspExtension(markup);
	}
	
	private static String getMarkup(String contentType) {
		if ("text/vnd.wap.wml".equals(contentType))
			return "wml";
		else
			return "html";
	}
	
	private static String getJspExtension(String markupName) {
		return "jsp";
	}


	public static PumaHome getPumaHome() {
		return pumaHome;
	}
	
}
