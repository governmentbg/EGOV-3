package com.ibs.gateway.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.Content;
import com.ibs.gateway.ARConstants;
import com.ibs.gateway.ARServicesLoader;
import com.ibs.gateway.dbo.ARAdministrativeService;
import com.ibs.gateway.management.ARServiceManagement;
import com.ibs.gateway.utils.ARUtils;
import com.ibs.gateway.utils.Logger;

import bg.government.iisda.admservices.AdmServiceMainDataType;
import bg.government.iisda.admservices.integrationservices.ArrayOfAdmServiceMainDataType;

@WebServlet("/ar-update-main-data")
public class ARUpdateMainData extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
       
    public ARUpdateMainData() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Logger.log(Logger.DEBUG_LEVEL, "ARUpdateMainData -> doGet()");
		
		request.setCharacterEncoding("utf8");	
		response.setHeader("Cache-Control", "no-cache");		
		response.setContentType("application/json; charset=UTF-8");
		
		Logger.log(Logger.DEBUG_LEVEL, "ARUpdateMainData -> doGet(): remoteAddr=" + request.getRemoteAddr());
		
		
		JSONObject json = new JSONObject();	
		JSONObject ja = new JSONObject(); 
		
		boolean userLoggedIn = request != null && request.getUserPrincipal() != null && request.getUserPrincipal().getName() != null && request.getUserPrincipal().getName().trim().length() > 0;
		
		try {
			if (!userLoggedIn) {
				throw new Exception("Неоторизиран достъп!");
			}
			
			String serviceNumberParam = request.getParameter("serviceNumber");
			String contentUUID = request.getParameter("contentUUID");
			if (serviceNumberParam == null || serviceNumberParam.trim().length() == 0 || contentUUID == null || contentUUID.trim().length() == 0) {
				throw new Exception("Некоректни параметри!");				
			}
			
			long serviceNumber = Long.parseLong(serviceNumberParam);
			// Load "Main Data" for given serviceNumber from AR.
			ArrayOfAdmServiceMainDataType admServiceMainDataTypeArr = ARServicesLoader.loadAdmServiceMainData(serviceNumber);
			if (admServiceMainDataTypeArr == null || admServiceMainDataTypeArr.getAdmServiceMainDataType() == null || admServiceMainDataTypeArr.getAdmServiceMainDataType().size() == 0) {
				throw new Exception("Неуспешно зареждане на \"Основни данни\" от Административния регистър!");
			}			
			ARServiceManagement management = new ARServiceManagement();
			// Load administrativeService from our DB.
			ARAdministrativeService administrativeService = management.loadAdministrativeServiceByServiceNumber(serviceNumberParam);
			if (administrativeService == null) {
				throw new Exception("Административна услуга с номер " + serviceNumberParam + " не е намерена в системния модул!");
			}
			// Load content by UUID from WCM.
			Content content = null;
			try {
				content = (Content)EgovWCMCache.getWorkspace().getById(EgovWCMCache.getWorkspace().createDocumentId(contentUUID));
			} catch (Exception e) {
				e.printStackTrace();
			}			
			if (content == null) {
				throw new Exception("Унифицирана услуга с номер " + contentUUID + " не е намерена!");
			}
			AdmServiceMainDataType admServiceMainDataType = admServiceMainDataTypeArr.getAdmServiceMainDataType().get(0);
			// name.
			content.setName(administrativeService.getServiceNumber().toString());
			// title.
			String title = administrativeService.getName().trim();
			if (title.length() > 125) {
				title = title.substring(0, 122);
				int pos = title.lastIndexOf(" ");
				if (pos != -1) {
					title = title.substring(0, pos);
				}
				title += "...";
			}
			content.setTitle(title);
			// serviceNumber.
			ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_SERVICE_NUMBER_NAME, administrativeService.getServiceNumber().toString());		
			// serviceName.
			ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_SERVICE_NAME_NAME, administrativeService.getName());
			// isInternalAdminService.
			ARUtils.populateOptionSelectionField(content, EgovWCMCache.SERVICE_FIELD_IS_INTERNAL_ADMIN_SERVICE_NAME, (admServiceMainDataType.isIsInternalAdminService() ? EgovWCMCache.getCategoryCommonYes().getId() : EgovWCMCache.getCategoryCommonNo().getId()));
			// regulatoryAct.
			ARUtils.populateTextField(content, EgovWCMCache.SERVICE_FIELD_REGULATORY_ACT_NAME, ARUtils.formatRegulatoryActsDataForRichText(admServiceMainDataType.getLegalBasis()));
			// Save content to WCM.
			ARUtils.save(EgovWCMCache.getWorkspace(), content);
			
			Logger.log(Logger.DEBUG_LEVEL, "ARUpdateMainData -> doGet() | content.getId().getId() = " + content.getId().getId());
			
			// Update Administrative Service record and mark it as sync.
			long currentTime = System.currentTimeMillis();					
			administrativeService.setOperationTime(ARUtils.timeMillisToTimestamp(currentTime));
			administrativeService.setContentUUID(contentUUID);
			administrativeService.setSynchronized(ARConstants.ADMINISTRATIVE_STRUCTURE_SYNCHRONIZED);
			administrativeService.setState(ARConstants.ADMINISTRATIVE_STRUCTURE_STATE_PROCESSED);
			administrativeService.setSynchronizedDate(ARUtils.timeMillisToTimestamp(currentTime));
			administrativeService.store();
			ja.put("result", "1");
			ja.put("contentUUID", contentUUID);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			ja.put("result", "0");
			ja.put("message", e.getMessage());
		}
		json.put("data", ja);
		String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
		response.getWriter().print(jsonPrettyPrintString);
		response.getWriter().flush();
		response.getWriter().close();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
