package com.ibs.gateway.servlet;

import java.io.IOException;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibs.gateway.ARConstants;
import com.ibs.gateway.utils.Logger;
import javax.xml.ws.Service;

import bg.government.iisda.ras.integrationservices.ArrayOfBatchIdentificationInfoType;
import bg.government.iisda.ras.integrationservices.IBatchInfoService;

@WebServlet("/ar-structure-test")
public class ARStructureTest extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ARStructureTest() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		boolean fromFile = request.getParameter("file") != null;
		URL url = null;
		if (fromFile) {
			String wsdlPath = request.getServletContext().getRealPath("/") + File.separator + "WEB-INF" + File.separator + "wsdl" + File.separator + ARConstants.BATCH_INFO_SERVICE_WSDL_FILE_NAME;
			System.out.println("wsdlPath=" + wsdlPath);
	        try {        	        	
	        	// Refer to local WSDL file, with change from wsdl:definition xmlns:wsp="http://schemas.xmlsoap.org/ws/2004/09/policy"
	        	// to xmlns:wsp="http://www.w3.org/ns/ws-policy"
	        	url = new URL("file:" + wsdlPath);
	        	// WAS 8.5 complains for wsdl:definition xmlns:wsp="http://schemas.xmlsoap.org/ws/2004/09/policy",        	
	        	// that's why we cannot refer to WSDL from URL, but local file instead.
	        	//url = new URL (ARConstants.BATCH_INFO_SERVICE_URL);
	        } catch (MalformedURLException e) {
	        	System.out.println(e.getMessage());
	        	Logger.log(Logger.ERROR_LEVEL, "Can not initialize the default wsdl from address:" + wsdlPath);
	        }
		} else {
			url = new URL (request.getParameter("http") != null ? ARConstants.BATCH_INFO_SERVICE_URL_HTTP_ONLY : ARConstants.BATCH_INFO_SERVICE_URL);
		}
		if (url != null) {
			Service service = Service.create(url, ARConstants.BATCH_INFO_SERVICE_QNAME);
	    	IBatchInfoService iBatchInfoService = service.getPort(
	    			ARConstants.WS_HTTP_BINDING_I_BATCH_INFO_SERVICE_QNAME,  
	    			IBatchInfoService.class, 
	    			new javax.xml.ws.soap.AddressingFeature());
	    	if (iBatchInfoService != null) {
	    		ArrayOfBatchIdentificationInfoType result = iBatchInfoService.searchBatchesIdentificationInfo(null, null, null, null, bg.government.iisda.ras.BatchStatusEnum.ACTIVE, null, null);
	    		if (result != null && result.getBatchIdentificationInfoType() != null && result.getBatchIdentificationInfoType().size() > 0) {
	    			response.getWriter().append("TOTAL=" + result.getBatchIdentificationInfoType().size());
	    		}
	    	}
		}
		// TODO Auto-generated method stub
		response.getWriter().append("<br/>Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
