package org.tempuri;

import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import javax.xml.ws.WebEndpoint;
//import javax.xml.ws.WebServiceClient;
import javax.xml.ws.WebServiceFeature;

import bg.government.iisda.ras.integrationservices.IBatchInfoService;

// Not Used.
//@WebServiceClient(name = "BatchInfoService",
//                  wsdlLocation = "https://iisda.government.bg/Services/RAS/RAS.Integration.Host/BatchInfoService.svc?wsdl",
//                  targetNamespace = "http://tempuri.org/")
public class BatchInfoService extends Service {

    public final static URL WSDL_LOCATION;

    public final static QName SERVICE = new QName("http://tempuri.org/", "BatchInfoService");
    public final static QName WSHttpBindingIBatchInfoService = new QName("http://tempuri.org/", "WSHttpBinding_IBatchInfoService");
    static {
        URL url = null;
        try {        	        	
        	url = new URL("http://iisda.government.bg/Services/RAS/RAS.Integration.Host/BatchInfoService.svc?wsdl");
        } catch (MalformedURLException e) {
            java.util.logging.Logger.getLogger(BatchInfoService.class.getName())
                .log(java.util.logging.Level.INFO,
                     "Can not initialize the default wsdl from {0}", "https://iisda.government.bg/Services/RAS/RAS.Integration.Host/BatchInfoService.svc?wsdl");
        }
        WSDL_LOCATION = url;
    }

    public BatchInfoService(URL wsdlLocation) {
        super(wsdlLocation, SERVICE);
    }

    public BatchInfoService(URL wsdlLocation, QName serviceName) {
        super(wsdlLocation, serviceName);
    }

    public BatchInfoService() {
        super(WSDL_LOCATION, SERVICE);
    }

    public BatchInfoService(WebServiceFeature ... features) {
        super(WSDL_LOCATION, SERVICE, features);
    }

    public BatchInfoService(URL wsdlLocation, WebServiceFeature ... features) {
        super(wsdlLocation, SERVICE, features);
    }

    public BatchInfoService(URL wsdlLocation, QName serviceName, WebServiceFeature ... features) {
        super(wsdlLocation, serviceName, features);
    }




    /**
     *
     * @return
     *     returns IBatchInfoService
     */
    @WebEndpoint(name = "WSHttpBinding_IBatchInfoService")
    public IBatchInfoService getWSHttpBindingIBatchInfoService() {
        return super.getPort(WSHttpBindingIBatchInfoService, IBatchInfoService.class);
    }

    /**
     *
     * @param features
     *     A list of {@link javax.xml.ws.WebServiceFeature} to configure on the proxy.  Supported features not in the <code>features</code> parameter will have their default values.
     * @return
     *     returns IBatchInfoService
     */
    @WebEndpoint(name = "WSHttpBinding_IBatchInfoService")
    public IBatchInfoService getWSHttpBindingIBatchInfoService(WebServiceFeature... features) {
        return super.getPort(WSHttpBindingIBatchInfoService, IBatchInfoService.class, features);
    }

}
