package bg.ibs.authorization.manager.portlet.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class UserProfileAndPersonalParametersMapper implements RowMapper<UserProfileAndPersonalParameters> {

	public UserProfileAndPersonalParameters mapRow(ResultSet resultSet, int i) throws SQLException {
        UserProfileAndPersonalParameters personalProfile = new UserProfileAndPersonalParameters();
        personalProfile.setUserProfileId(resultSet.getLong(1));
        personalProfile.setUserUID(resultSet.getString(2));
        personalProfile.setIdentifier(resultSet.getString(3));
        personalProfile.setNames(resultSet.getString(4));
        personalProfile.setStatus(resultSet.getInt(5));
        personalProfile.setDeactivationReason(resultSet.getString(6));
        personalProfile.setEik(resultSet.getString(7));
        personalProfile.setNameAndLegalForm(resultSet.getString(8));
        personalProfile.setQualityOfPhysicalPerson(resultSet.getString(9));
        personalProfile.setMethodOfRepresentation(resultSet.getString(10));
        personalProfile.setProfileType(resultSet.getInt(11));
        personalProfile.setProfileStructureType(resultSet.getString(12));
        personalProfile.setDateCreated(resultSet.getDate(13));
        personalProfile.setDateModified(resultSet.getDate(14));
        personalProfile.setGroupId(resultSet.getString(15));
        personalProfile.setSamlResponse(resultSet.getString(16));
        personalProfile.setCustomSideNav(resultSet.getString(17));
       
        personalProfile.setUserProfilePersonalParametersId(resultSet.getLong(18));
        personalProfile.setSecurityLevel(resultSet.getInt(19));
        personalProfile.setConsentToUseAddress(resultSet.getInt(20));
        personalProfile.setAddressDescription(resultSet.getString(21));
        personalProfile.setMailBox(resultSet.getString(22));
        personalProfile.setZipCode(resultSet.getString(23));
        personalProfile.setConsentToUsePhone(resultSet.getInt(24));
        personalProfile.setPhoneNumber(resultSet.getString(25));
        personalProfile.setConsentToUseEmail(resultSet.getInt(26));
        personalProfile.setEmail(resultSet.getString(27));
        personalProfile.setEkatte(resultSet.getString(28));
		return personalProfile;
	}
}
