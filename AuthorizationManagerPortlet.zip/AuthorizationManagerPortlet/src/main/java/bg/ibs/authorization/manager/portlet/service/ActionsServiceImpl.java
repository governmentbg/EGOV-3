package bg.ibs.authorization.manager.portlet.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import bg.ibs.authorization.manager.portlet.dao.ActionsDAO;
import bg.ibs.authorization.manager.portlet.model.Actions;

@Service("ActionsService")
public class ActionsServiceImpl implements ActionsService {

	@Autowired
	@Qualifier("ActionsDAO")
	private ActionsDAO actionsDAO; 
	
	public Actions getActionsById(Long id) {
		return actionsDAO.getActionsById(id);
	}
	
	public List<Actions> getAllActionsBySystemId(Long systemsId) {
		return actionsDAO.getAllActionsBySystemId(systemsId);
	}
	
	public Actions getActionsBySystemIdAndCode(Long systemsId, String code) {
		return actionsDAO.getActionsBySystemIdAndCode(systemsId, code);
	}
	
	public Actions getActionsBySystemIdAndCodeExcId(Long systemsId, String code, Long actionsId) {
		return actionsDAO.getActionsBySystemIdAndCodeExcId(systemsId, code, actionsId);
	}
	
	public List<Actions> getAllActions() {
		return actionsDAO.getAllActions();
	}
	
	public List<Actions> getAllActionsByIds(List<Long> actionsIds) {
		return actionsDAO.getAllActionsByIds(actionsIds);
	}
	
	public Integer countActionsByFilter(Long actionsId, String code, String description, Long systemsId) {
		return actionsDAO.countActionsByFilter(actionsId, code, description, systemsId);
	}
	
	public List<Actions> getAllActionsByFilter(Long actionsId, String code, String description, Long systemsId, Integer start, Integer length, Integer orderColumn, String order) {
		return actionsDAO.getAllActionsByFilter(actionsId, code, description, systemsId, start, length, orderColumn, order);
	}
	
	public Actions createActions(Actions action) {
		return actionsDAO.createActions(action);
	}
	
	public boolean updateActions(Actions action) {
		return actionsDAO.updateActions(action);
	}
	
	public boolean deleteActions(Actions action) {
		return actionsDAO.deleteActions(action);
	}

}
