package bg.ibs.authorization.manager.portlet.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import javax.annotation.Resource;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequest;
import javax.servlet.http.HttpServletRequest;

import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import bg.ibs.authorization.manager.portlet.AuthorizationManagerConstants;

@Component
public class AuthorizationManagerUtils {

	private static SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH);
	private static SimpleDateFormat dateTimeFormat_BG = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.ENGLISH);

	
	@Resource(name = "messageSource")
	private MessageSource messageSource;
	
	public String getRemoteIP(PortletRequest portletRequest) {
		String remoteIP = "localhost";	
		HttpServletRequest httpServletRequest = null;
		try {
			httpServletRequest = (HttpServletRequest) (com.ibm.ws.portletcontainer.portlet.PortletUtils.getHttpServletRequest(portletRequest));
			remoteIP = httpServletRequest.getHeader("X-FORWARDED-FOR");
			if (remoteIP == null) {
				remoteIP = httpServletRequest.getRemoteAddr();
			}				
		} catch (Exception e) {
			e.printStackTrace();
		}
		return remoteIP;
	}
	
	public String formatMultipleFieldsToOne(String str) {
		if (str == null || str.trim().length() == 0) {
			return null;
		}
		String[] profileTypes = str.split(",");
		String formatedProfileTypes = "";
		for (int i = 0; i < profileTypes.length; i++) {
			formatedProfileTypes += "^" + profileTypes[i] + "^";
		}
		return formatedProfileTypes;
	}
	
	public boolean hasMultipleValues(String profileType) {
		if (profileType != null) {
			return profileType.indexOf("^^") != -1;				
		}
		return false;
	}
	
	public String getValuesSplitedByCommaFromMultipleField(String value) {
		if (value != null) {
			if (value.indexOf("^^") != -1) {
				String[] values = value.split("\\^\\^");
				String valuesStr = "";
				for (int i = 0; i < values.length; i++) {
					if (i > 0) {
						valuesStr += ", ";
					}
					valuesStr += values[i].replaceAll("\\^", "");
				}
				return valuesStr;
			} else {
				return value.replaceAll("\\^", "");
			}
		}
		return "";
	}
	
//	public String getProfileTypeNames(String profileType) {
//		if (profileType != null) {
//			if (profileType.indexOf("^^") != -1) {
//				String[] profileTypeIds = profileType.split("\\^\\^");
//				String profileNames = "";
//				for (int i = 0; i < profileTypeIds.length; i++) {
//					if (i > 0) {
//						profileNames += ", ";
//					}
//					profileNames += wcmCommunicator.getProfileTypeName(profileTypeIds[i].replaceAll("\\^", ""));
//				}
//				return profileNames;
//			} else {
//				profileType = profileType.replaceAll("\\^", "");
//				return wcmCommunicator.getProfileTypeName(profileType);
//			}
//		}
//		return "";
//	}
	
	
	public Integer[] getIntegerArrayFromFormatedField(String str) {
		if (str != null && str.trim().length() > 0) {
			if (str.indexOf("^^") != -1) {
				String[] idsStr = str.split("\\^\\^");
				Integer[] ids = new Integer[idsStr.length];
				for (int i = 0; i < idsStr.length; i++) {
					ids[i] = Integer.parseInt(idsStr[i].replaceAll("\\^", ""));
				}
				return ids;
			} else {
				return new Integer[] {Integer.parseInt(str.replaceAll("\\^", ""))};
			}
		}
		return null;
	}
	
//	public com.egov.wcm.cache.model.EgovRegisterGroup populateCacheSystems(RegisterGroup registerGroup) {
//		com.egov.wcm.cache.model.EgovRegisterGroup group = new com.egov.wcm.cache.model.EgovRegisterGroup();
//		group.setRegisterGroupId(registerGroup.getRegisterGroupId());
//		group.setName(registerGroup.getName());
//		group.setLabel(registerGroup.getLabel());
//		group.setProfileType(registerGroup.getProfileType());
//		group.setProfileStructureType(registerGroup.getProfileStructureType());
//		group.setWeight(registerGroup.getWeight());
//		group.setStatus(registerGroup.getStatus());
//		group.setDateCreated(registerGroup.getDateCreated());
//		group.setDateModified(registerGroup.getDateModified());
//		group.setUserId(registerGroup.getUserId());
//		return group;
//	}
//	
//	public com.egov.wcm.cache.model.EgovRegisterGroupParameter populateCacheActions(RegisterGroupParameter registerParameter) {
//		com.egov.wcm.cache.model.EgovRegisterGroupParameter parameter = new com.egov.wcm.cache.model.EgovRegisterGroupParameter();
//		parameter.setRegisterGroupParameterId(registerParameter.getRegisterGroupParameterId());
//		parameter.setRegisterGroupId(registerParameter.getRegisterGroupId());
//		parameter.setName(registerParameter.getName());
//		parameter.setLabel(registerParameter.getLabel());
//		parameter.setParameterType(registerParameter.getParameterType());
//		parameter.setParameterValue(registerParameter.getParameterValue());
//		parameter.setDefaultValue(registerParameter.getDefaultValue());
//		parameter.setDescription(registerParameter.getDescription());
//		parameter.setHeader(registerParameter.getHeader());
//		parameter.setRequired(registerParameter.getRequired());
//		parameter.setConsent(registerParameter.getConsent());
//		parameter.setWeight(registerParameter.getWeight());
//		parameter.setStatus(registerParameter.getStatus());
//		parameter.setDateCreated(registerParameter.getDateCreated());
//		parameter.setDateModified(registerParameter.getDateModified());
//		parameter.setUserId(registerParameter.getUserId());
//		return parameter;
//	}
	
	public String[] getArrayFromFormatedField(String str) {
		if (str != null && str.trim().length() > 0) {
			if (str.indexOf("^^") != -1) {
				String[] systemsAndActionsStr = str.split("\\^\\^");
				String[] systemsAndActions = new String[systemsAndActionsStr.length];
				for (int i = 0; i < systemsAndActionsStr.length; i++) {
					systemsAndActions[i] = systemsAndActionsStr[i].replaceAll("\\^", "");
				}
				return systemsAndActions;
			} else {
				return new String[] {str.replaceAll("\\^", "")};
			}
		}
		return null;
	}
	
	public String dateToDD_MM_YYYY_HH_MM_SS(final Date date) {
		try {
			return dateTimeFormat_BG.format(date);
		} catch (Exception e) {
			System.out.println("Utils : dateToDD_MM_YYYY_HH_MM_SS : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public String timeMillisToTimestamp(final long millis) {
		try {

			return dateTimeFormat.format(new Date(millis));
		} catch (final Exception e) {
			System.out.println("Utils : timeMillisToTimestamp : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}
	
	public String formatFilterDateToMySQLDate(String ddMMYYYY) {
		if (ddMMYYYY == null || ddMMYYYY.trim().length() == 0) return ddMMYYYY;
		try {
			Date date = new SimpleDateFormat(AuthorizationManagerConstants.FILTER_DATE_FORMAT).parse(ddMMYYYY);
			DateFormat targetFormat = new SimpleDateFormat(AuthorizationManagerConstants.MY_SQL_DATE_FORMAT);
			return targetFormat.format(date);  
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public String getAuthorizedType(int type, PortletRequest portletRequest) {
		if (AuthorizationManagerConstants.AUTHORIZED_TYPE_PERSON == type) {
			return messageSource.getMessage("authorized.type.personal", null, getLocale(portletRequest));
		} else if (AuthorizationManagerConstants.AUTHORIZED_TYPE_LE == type) {
			return messageSource.getMessage("authorized.type.legal.entity", null, getLocale(portletRequest));
		}
		return "";
	}

	
	public String getAuthorizationStatusName(int status, Date validFrom, Date validTo, PortletRequest portletRequest) {
		if (AuthorizationManagerConstants.STATUS_ACTIVE == status) {
			Date today = new Date();
			if (today.compareTo(validFrom) < 0) { // not active yet.
				return messageSource.getMessage("status.inactive", null, getLocale(portletRequest)); 
            } else if (today.compareTo(validTo) > 0) { // expired.
            	return messageSource.getMessage("status.expired", null, getLocale(portletRequest));
            } 
			return messageSource.getMessage("status.active", null, getLocale(portletRequest));
		} else if (AuthorizationManagerConstants.STATUS_BLOCKED == status) {
			return messageSource.getMessage("status.blocked", null, getLocale(portletRequest));
		} else if (AuthorizationManagerConstants.STATUS_CANCELED == status) {
			return messageSource.getMessage("status.canceled", null, getLocale(portletRequest));
		}
		return "";
	}
	
	public Locale getLocale(PortletRequest request) {
		PortletPreferences prefs = request.getPreferences();
		return new Locale(prefs.getValue(AuthorizationManagerConstants.SETTING_PARAMETER_LANGUAGE, AuthorizationManagerConstants.LANGUAGE_BG));
	}
	
	public static void main(String[] args) {
//		Date today = new Date();
//		try {
//		Date validFrom = new SimpleDateFormat(AuthorizationManagerConstants.FILTER_DATE_FORMAT + " HH:mm:ss").parse("14.11.2021 11:23:30");
//		Date validTo = new SimpleDateFormat(AuthorizationManagerConstants.FILTER_DATE_FORMAT + " HH:mm:ss").parse("16.11.2021 11:20:40");
//		if (today.compareTo(validFrom) < 0) { // not active yet.
//			System.out.println("inactive");
//			return;
//        } else if (today.compareTo(validTo) > 0) { // expired.
//        	System.out.println("expired");
//        	return;
//        } 
//		System.out.println("active");
//		} catch (Exception e) {
//			e.printStackTrace();			
//		}
		String systemsStr = "^100:100^^100:101^^101:102^";
		AuthorizationManagerUtils utils = new AuthorizationManagerUtils();
		String[] data = utils.getArrayFromFormatedField(systemsStr);
		if (data != null) {
			String[] pair = null;
			for (int i = 0; i < data.length; i++) {
				System.out.println(data[i]);
				pair = data[i].split(":");
				System.out.println(pair[0] + "<>" + pair[1]);
			}			
		}
	}
}
