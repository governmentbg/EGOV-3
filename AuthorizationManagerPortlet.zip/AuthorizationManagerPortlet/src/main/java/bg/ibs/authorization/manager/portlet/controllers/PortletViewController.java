package bg.ibs.authorization.manager.portlet.controllers;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequest;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.portlet.ModelAndView;
import org.springframework.web.portlet.bind.annotation.ActionMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;
import org.springframework.web.portlet.bind.annotation.ResourceMapping;

import com.ibm.portal.um.PumaHome;
import com.ibm.portal.um.exceptions.PumaException;

import bg.ibs.authorization.manager.portlet.AuthorizationManagerConstants;
import bg.ibs.authorization.manager.portlet.AuthorizationNotificationsManager;
import bg.ibs.authorization.manager.portlet.beans.AuthorizationManagerSessionBean;
import bg.ibs.authorization.manager.portlet.beans.Container;
import bg.ibs.authorization.manager.portlet.beans.SelectedActionBean;
import bg.ibs.authorization.manager.portlet.beans.SelectedSystemBean;
import bg.ibs.authorization.manager.portlet.communicator.ESBCommunicator;
import bg.ibs.authorization.manager.portlet.communicator.PumaCommunicator;
import bg.ibs.authorization.manager.portlet.model.Actions;
import bg.ibs.authorization.manager.portlet.model.Authorizations;
import bg.ibs.authorization.manager.portlet.model.Systems;
import bg.ibs.authorization.manager.portlet.service.ActionsService;
import bg.ibs.authorization.manager.portlet.service.AuthorizationsService;
import bg.ibs.authorization.manager.portlet.service.SystemsService;
import bg.ibs.authorization.manager.portlet.utils.AuthorizationManagerLogger;
import bg.ibs.authorization.manager.portlet.utils.AuthorizationManagerUtils;
import bg.ibs.authorization.manager.portlet.utils.EncryptorAESGCM;

@Controller
@RequestMapping("view")
public class PortletViewController {
	
	@Resource(name = "sessionScopedBean")
	AuthorizationManagerSessionBean sessionBean;
	
	@Resource(name = "messageSource")
	private MessageSource messageSource;
	
	@Autowired
	AuthorizationManagerLogger logger;
	@Autowired
	PumaCommunicator pumaCommunicator;
	@Autowired
	ESBCommunicator esbCommunicator;
	@Autowired
	AuthorizationNotificationsManager notificationManager;	
	@Autowired
	AuthorizationManagerUtils utils;
	@Autowired
	EncryptorAESGCM aesCls;

	@Autowired
	AuthorizationsService authorizationsService;
	@Autowired
	SystemsService systemsService;
	@Autowired
	ActionsService actionsService;
	
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	
	private static PumaHome pumaHome = null;
	public static String language = AuthorizationManagerConstants.LANGUAGE_BG;
	public static String esbEventLogAddress = AuthorizationManagerConstants.ESB_LOGGING_URL;
	public static String mailSmtpHost = AuthorizationManagerConstants.MAIL_SMTP_HOST;
	public static String fromAddress = AuthorizationManagerConstants.MAIL_FROM_ADDRESS;
	public static boolean isDebug = false;		
	
	
	@PostConstruct
	public void init() {
		InitialContext initialcontext;
		try {
			initialcontext = new InitialContext();
			pumaHome = (PumaHome) initialcontext.lookup("portal:service/usermanagement/Puma");
		} catch (NamingException namingexception) {
			namingexception.printStackTrace();
		}
	}
	
	@RenderMapping
	public ModelAndView defaultView(RenderRequest renderRequest, RenderResponse renderResponse) {
		loadPreferences(renderRequest);

		if (!sessionBean.isInitialised()) {
			intializeBean();				
		}			
		String currentPage = sessionBean.getCurrentPage();
		ModelAndView mv = new ModelAndView(currentPage);
		mv.addObject("userUID", sessionBean.getUserUID());					
		mv.addObject("language", language);					
		// Populate "ModelAndView" accordingly.
		if (AuthorizationManagerConstants.INDEX_PAGE.equals(currentPage)) {
			Integer currentTab = sessionBean.getTabPerPage().get(currentPage);
			String uniquePath = "";
			uniquePath = currentPage + currentTab;
			Integer currentView = null;
			if (AuthorizationManagerConstants.TAB_SYSTEMS == currentTab) {
				currentView = sessionBean.getViewPerTab().get(currentPage + currentTab);
				uniquePath = currentPage + currentTab + currentView;
			}
			Container container = sessionBean.getContainer().get(uniquePath);			
			if (container == null) {
				container = new Container();
			}
			mv.addObject("currentTab", currentTab);
			
			if (AuthorizationManagerConstants.TAB_AUTHORIZATIONS == currentTab) {
				mv.addObject("filterId", container.getFilterId());			
				mv.addObject("filterOrn", container.getFilterOrn());			
				mv.addObject("filterUserNames", container.getFilterUserNames());			
				mv.addObject("filterAuthorizedType", container.getFilterAuthorizedType());			
				mv.addObject("filterAuthorizedNames", container.getFilterAuthorizedNames());			
				mv.addObject("filterValidFrom", container.getFilterValidFrom());			
				mv.addObject("filterValidTo", container.getFilterValidTo());			
				mv.addObject("filterStatus", container.getFilterStatus());							
			} else if (AuthorizationManagerConstants.TAB_SYSTEMS == currentTab) {
				mv.addObject("currentView", currentView);	
				mv.addObject("filterId", container.getFilterId());	
				if (AuthorizationManagerConstants.VIEW_SYSTEMS == currentView) {
					mv.addObject("filterTitle", container.getFilterTitle());
					mv.addObject("filterOid", container.getFilterOid());
				} else if (AuthorizationManagerConstants.VIEW_ACTIONS == currentView) {
					mv.addObject("currentSystem", container.getSystem());
					mv.addObject("filterCode", container.getFilterCode());
					mv.addObject("filterDescription", container.getFilterDescription());
					mv.addObject("filterSystem", container.getFilterSystem());					
					mv.addObject("allSystems", systemsService.getAllSystems());
				}
			} else if (AuthorizationManagerConstants.TAB_ACTIONS == currentTab) {
				mv.addObject("currentAction", new Actions());
				mv.addObject("filterId", container.getFilterId());
				mv.addObject("filterCode", container.getFilterCode());
				mv.addObject("filterDescription", container.getFilterDescription());
				mv.addObject("filterSystem", container.getFilterSystem());
				mv.addObject("allSystems", systemsService.getAllSystems());
			}
			
			mv.addObject("start", container.getStart());
			mv.addObject("resultsPerPage", container.getResultsPerPage());
			mv.addObject("orderColumn", container.getOrderColumn());
			mv.addObject("order", container.getOrder().toLowerCase());
			
			System.out.println("in defaultView() userUID=" + sessionBean.getUserUID());
			System.out.println("in defaultView() currentPage=" + currentPage);
			System.out.println("in defaultView() currentTab=" + currentTab);
			System.out.println("in defaultView() currentView=" + currentView);				
			System.out.println("defaultView() -> order=" + container.getOrder().toLowerCase());
			System.out.println("defaultView() -> orderColumn=" + container.getOrderColumn());
		} else if (AuthorizationManagerConstants.AUTHORIZATION_PAGE.equals(currentPage)) {	
			mv = processAuthorizationPage(renderRequest, renderResponse, mv);
		} else if (AuthorizationManagerConstants.SYSTEM_PAGE.equals(currentPage)) {	
			mv = processSystemPage(renderRequest, renderResponse, mv);
		} else if (AuthorizationManagerConstants.ACTION_PAGE.equals(currentPage)) {	
			mv = processActionPage(renderRequest, renderResponse, mv);
		}
		
		if (sessionBean.getError() != null) {
			mv.addObject("error", sessionBean.getError());
			sessionBean.setError(null);
		}
		if (sessionBean.getMessage() != null) {
			mv.addObject("message", sessionBean.getMessage());
			sessionBean.setMessage(null);
		}
		return mv;
	}
	
	/*
	 * This private method handles authorization page.	 
	 *
	 * @param renderRequest		render request.
	 * @param renderResponse	render response.
	 * @param mv		 		ModelAndView object.
	 * 
	 */
	private ModelAndView processAuthorizationPage(RenderRequest renderRequest, RenderResponse renderResponse, ModelAndView mv) {
		Authorizations authorization = new Authorizations();
		if (sessionBean.getAuthorizationsId() != null) {
			authorization = authorizationsService.getAuthorizationsById(sessionBean.getAuthorizationsId());	
			if (authorization == null || authorization.getAuthorizationsId() == null) {
				mv.addObject("error", "Овластяване с номер \"" + sessionBean.getAuthorizationsId() + "\" не е намеренo в системата.");
				return mv;
			}	
			String userIdentifier = authorization.getUserIdentifier();
			String authorizedIdentifier = authorization.getAuthorizedIdentifier();
			if (AuthorizationManagerConstants.USER_TYPE_PERSON == authorization.getUserType()) {
				userIdentifier = aesCls.decryptEgovIdentifier(userIdentifier);
				if (userIdentifier == null || userIdentifier.trim().length() == 0) {
					userIdentifier = authorization.getUserId();
				}
			}
			if (AuthorizationManagerConstants.AUTHORIZED_TYPE_PERSON == authorization.getAuthorizedType()) {
				authorizedIdentifier = aesCls.decryptEgovIdentifier(authorizedIdentifier);
			}
			mv.addObject("userIdentifier", userIdentifier);
			mv.addObject("authorizedIdentifier", authorizedIdentifier);
			mv.addObject("validFrom", utils.dateToDD_MM_YYYY_HH_MM_SS(authorization.getValidFrom()));
			mv.addObject("validTo", utils.dateToDD_MM_YYYY_HH_MM_SS(authorization.getValidTo()));
			mv.addObject("selectedSystems", parseSystemsToBean(authorization.getSystems()));
			mv.addObject("statusName",utils.getAuthorizationStatusName(authorization.getStatus(), authorization.getValidFrom(), authorization.getValidTo(), renderRequest));
			mv.addObject("creationTime", utils.dateToDD_MM_YYYY_HH_MM_SS(authorization.getCreationTime()));
			mv.addObject("operationTime", utils.dateToDD_MM_YYYY_HH_MM_SS(authorization.getOperationTime()));
			if (AuthorizationManagerConstants.STATUS_CANCELED == authorization.getStatus()
					|| AuthorizationManagerConstants.STATUS_BLOCKED == authorization.getStatus()) {
				mv.addObject("cancelTime", utils.dateToDD_MM_YYYY_HH_MM_SS(authorization.getCancelTime()));
			}
			if (sessionBean.getMode() != null) {
				if (AuthorizationManagerConstants.MODE_EDIT == sessionBean.getMode()) {
					mv.addObject("edit", true);
					mv.addObject("read", false);												
				} else {
					mv.addObject("read", true);
					mv.addObject("edit", false);
				}
			}
		} 		
		mv.addObject("authorization", authorization);
		return mv;
	}
	/*
	 * This private method handles system page.	 
	 *
	 * @param renderRequest		render request.
	 * @param renderResponse	render response.
	 * @param mv		 		ModelAndView object.
	 * 
	 */
	private ModelAndView processSystemPage(RenderRequest renderRequest, RenderResponse renderResponse, ModelAndView mv) {
		Systems system = new Systems();
		if (sessionBean.getSystemsId() != null) {
			system = systemsService.getSystemsById(sessionBean.getSystemsId());	
			if (system == null || system.getSystemsId() == null) {
				mv.addObject("error", "Система с номер \"" + sessionBean.getSystemsId() + "\" не е намерена в системата.");
				return mv;
			}	
			mv.addObject("operationTime", utils.dateToDD_MM_YYYY_HH_MM_SS(system.getOperationTime()));
			if (sessionBean.getMode() != null) {
				if (AuthorizationManagerConstants.MODE_EDIT == sessionBean.getMode()) {
					mv.addObject("edit", true);
					mv.addObject("read", false);												
				} else {
					mv.addObject("read", true);
					mv.addObject("edit", false);
				}
			}
		} 
		if (sessionBean.getError() != null) {
			system.setTitle(renderRequest.getParameter("title"));
			system.setOid(renderRequest.getParameter("oid"));
		}
		mv.addObject("system", system);
		return mv;
	}
	
	/*
	 * This private method handles action page.	 
	 *
	 * @param renderRequest		render request.
	 * @param renderResponse	render response.
	 * @param mv		 		ModelAndView object.
	 * 
	 */
	private ModelAndView processActionPage(RenderRequest renderRequest, RenderResponse renderResponse, ModelAndView mv) {
		Actions action = new Actions();
		List<Systems> allSystems = systemsService.getAllSystems();
		mv.addObject("allSystems", allSystems);
		if (sessionBean.getActionsId() != null) {
			action = actionsService.getActionsById(sessionBean.getActionsId());	
			if (action == null || action.getActionsId() == null) {
				mv.addObject("error", "Действие с номер \"" + sessionBean.getActionsId() + "\" не е намерен в системата.");
				return mv;
			}	
			mv.addObject("operationTime", utils.dateToDD_MM_YYYY_HH_MM_SS(action.getOperationTime()));
			if (sessionBean.getMode() != null) {
				if (AuthorizationManagerConstants.MODE_EDIT == sessionBean.getMode()) {
					mv.addObject("edit", true);
					mv.addObject("read", false);												
				} else {
					mv.addObject("read", true);
					mv.addObject("edit", false);					
				}
			}
		} else if (sessionBean.getSystemsId() != null) {
			action.setSystemsId(new Long(sessionBean.getSystemsId()));
		}
		if (sessionBean.getError() != null) {
			action.setCode(renderRequest.getParameter("code"));
			action.setDescription(renderRequest.getParameter("description"));
			
			if (renderRequest.getParameter("systemsId") != null && renderRequest.getParameter("systemsId").trim().length() > 0) {
				try {
					action.setSystemsId(Long.parseLong(renderRequest.getParameter("systemsId")));
				} catch (NumberFormatException e) {logger.error(e.getMessage());}
			}
		}
		
		mv.addObject("action", action);
		return mv;
	}
	
	/*
	 * This action is called from buttons "Add/Edit Group"
	 * and "Add/Edit Parameter". 
	 *
	 * @param page			the page name to switch to.
	 * @param id		 	the id of the object we will work with (group/parameter).
	 * 
	 */
	@ActionMapping(value = "changePage")
	public void changePage(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "page") String page,			
			@RequestParam(value = "authorizationsId", required = false) Long authorizationsId,
			@RequestParam(value = "systemsId", required = false) Long systemsId,
			@RequestParam(value = "actionsId", required = false) Long actionsId,
			@RequestParam(value = "mode", required = false) Integer mode) {
		logger.message("changePage [" + page + "][" + authorizationsId + "][" + systemsId + "][" + actionsId + "][" + mode + "]");
		sessionBean.setCurrentPage(page);		
		sessionBean.setAuthorizationsId(authorizationsId);
		sessionBean.setSystemsId(systemsId); 
		sessionBean.setActionsId(actionsId);
		sessionBean.setMode(mode);
		// Returns control to default view.
	}
	
	/*
	 * This action is called from form "reloadPage"
	 *
	 */
	@ActionMapping(value = "reloadPage")
	public void reloadPage(
			ActionRequest actionRequest, ActionResponse actionResponse) {
		logger.message("reloadPage");		
		// Returns control to default view.
	}
	
	
	/*
	 * This action is called from main tabs.
	 *
	 * @param tab			the tab id to switch to.
	 * 
	 */
	@ActionMapping(value = "changeTab")
	public void changeTab(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "tab") Integer tab) {
		logger.message("changeTab [" + tab+ "]");
		String currentPage = sessionBean.getCurrentPage();
		sessionBean.getTabPerPage().put(currentPage, tab);
		
		String uniquePath = "";
		uniquePath = currentPage + tab;
		Integer currentView = null;
		if (AuthorizationManagerConstants.TAB_SYSTEMS == tab) {
			currentView = sessionBean.getViewPerTab().get(currentPage + tab);
			if (currentView == null) {
				currentView = AuthorizationManagerConstants.VIEW_SYSTEMS;
				HashMap<String, Integer> viewPerTab = sessionBean.getViewPerTab();
				viewPerTab.put(currentPage + tab, currentView);
				sessionBean.setViewPerTab(viewPerTab);
			}
			uniquePath = currentPage + tab + currentView;
		}
		Container container = sessionBean.getContainer().get(uniquePath);			
		if (container == null) {
			container = new Container();	
			if (AuthorizationManagerConstants.TAB_AUTHORIZATIONS == tab) {
				container.setOrderColumn(AuthorizationManagerConstants.COLUMN_AUTHORIZATION_OPERATION_TIME);
				container.setOrder(AuthorizationManagerConstants.ORDER_DESC);
			} else {
				if (AuthorizationManagerConstants.TAB_SYSTEMS == tab) {					
					container.setOrderColumn(AuthorizationManagerConstants.COLUMN_SYSTEMS_TITLE);
					if (currentView != null && AuthorizationManagerConstants.VIEW_ACTIONS == currentView) {
						container.setOrderColumn(AuthorizationManagerConstants.COLUMN_ACTIONS_DESCRIPTION);
					} 
				} else {
					container.setOrderColumn(AuthorizationManagerConstants.COLUMN_ACTIONS_DESCRIPTION);
				}								
				container.setOrder(AuthorizationManagerConstants.ORDER_ASC);
			}
			sessionBean.getContainer().put(uniquePath, container);
		}		
		// Returns control to default view.
	}
	
	
	/*
	 * This action is called from tab "Systems"
	 * and is responsible for toggle among different views. 
	 *
	 * @param view			the view id to switch to.
	 * 
	 */
	@ActionMapping(value = "changeView")
	public void changeView(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "view") Integer view,
			@RequestParam(value = "systemsId", required = false) Long systemsId) {
		logger.message("changeView [" + view + "]");
		String currentPage = sessionBean.getCurrentPage();
		Integer currentTab = sessionBean.getTabPerPage().get(currentPage);
		try {
			HashMap<String, Integer> viewPerTab = sessionBean.getViewPerTab();
			viewPerTab.put(currentPage + currentTab, view);
			sessionBean.setViewPerTab(viewPerTab);
			Container container = sessionBean.getContainer().get(currentPage + currentTab + view);
			if (container == null) {
				container = new Container();	
				if (AuthorizationManagerConstants.VIEW_SYSTEMS == view) {
					container.setOrderColumn(AuthorizationManagerConstants.COLUMN_SYSTEMS_TITLE);
				} else {
					container.setOrderColumn(AuthorizationManagerConstants.COLUMN_ACTIONS_DESCRIPTION);
				}
				container.setOrder(AuthorizationManagerConstants.ORDER_ASC);
			}
			if (AuthorizationManagerConstants.VIEW_ACTIONS == view) {
				container.setFilterSystem(systemsId);
			}
			if (systemsId != null) {
				// Load system.
				container.setSystem(systemsService.getSystemsById(systemsId));
			} else {
				container.setSystem(null);
			}
			sessionBean.getContainer().put(currentPage + currentTab + view, container);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		// Returns control to default view.
	}
	
	/*
	 * This action is called from tab "Authorizations".
	 *
	 * @param authorizationsId		the id of the authorization.
	 * @param userNames				user names of the authorization.
	 * @param authorizedType		authorized type.
	 * @param authorizedNames		authorized names.
	 * @param validFrom				valid from date.
	 * @param validTo				valid to date.
	 * @param status				status.
	 * 
	 */
	@ActionMapping(value = "searchFilterAuthorizations")
	public void searchFilterAuthorizations(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "authorizationsId", required = false) Long authorizationsId,
			@RequestParam(value = "orn", required = false) String orn,
			@RequestParam(value = "userNames", required = false) String userNames,
			@RequestParam(value = "authorizedType", required = false) Integer authorizedType,
			@RequestParam(value = "authorizedNames", required = false) String authorizedNames,
			@RequestParam(value = "validFrom", required = false) String validFrom,
			@RequestParam(value = "validTo", required = false) String validTo,
			@RequestParam(value = "status", required = false) Integer status) 
	{
		loadPreferences(actionRequest);		
		logger.message("searchFilterAuthorizations");
		logger.message("authorizationsId=" + (authorizationsId != null ? authorizationsId : ""));
		logger.message("orn=" + (orn != null ? orn : ""));
		logger.message("userNames=" + (userNames != null ? userNames : ""));
		logger.message("authorizedType" + (authorizedType != null ? authorizedType : ""));
		logger.message("authorizedNames" + (authorizedNames != null ? authorizedNames : ""));
		logger.message("validFrom" + (validFrom != null ? validFrom : ""));
		logger.message("validTo" + (validTo != null ? validTo : ""));
		logger.message("status" + (status != null ? status : ""));
		
		if (sessionBean != null) {
			String currentPage = sessionBean.getCurrentPage();  
			Integer currentTab = sessionBean.getTabPerPage().get(currentPage);
			String uniquePath = currentPage + currentTab;
			
			Container container = sessionBean.getContainer().get(uniquePath);
			if (container == null) {
				container = new Container();
			}
			
			container.setFilterId(authorizationsId); 
			container.setFilterOrn(orn != null && orn.trim().length() > 0 ? orn.trim() : null); 
			container.setFilterUserNames(userNames != null && userNames.trim().length() > 0 ? userNames.trim() : null); 
			container.setFilterAuthorizedType(authorizedType);
			container.setFilterAuthorizedNames(authorizedNames != null && authorizedNames.trim().length() > 0 ? authorizedNames.trim() : null);
			container.setFilterValidFrom(validFrom != null && validFrom.trim().length() > 0 ? validFrom.trim() : null);
			container.setFilterValidTo(validTo != null && validTo.trim().length() > 0 ? validTo.trim() : null);
			container.setFilterStatus(status); 
			container.setStart(0);
			sessionBean.getContainer().put(uniquePath, container);
		}
	}
	
	/*
	 * This resource mapping is called from tab "Systems".
	 *
	 * @param draw				UI parameter from Datatables.
	 * @param start 			page number (started from 0).
	 * @param length			results per page.
	 * @param order[0][column]	order column index.
	 * @param order[0][dir]		order column direction.
	 * 
	 */
	@ResourceMapping(value = "getAuthorizations")
	public void getAuthorizations(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("draw") Integer draw,
			@RequestParam("start") Integer start,
			@RequestParam("length") Integer length,
			@RequestParam("order[0][column]") Integer orderColumn,
			@RequestParam("order[0][dir]") String order)
	{
		loadPreferences(resourceRequest);		
		logger.message("getAuthorizations");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONArray ja = new JSONArray();
		int totalResults = 0;
		if (sessionBean != null) {
			String currentPage = sessionBean.getCurrentPage();  
			Integer currentTab = sessionBean.getTabPerPage().get(currentPage);
			String uniquePath = currentPage + currentTab;
			
			Container container = sessionBean.getContainer().get(uniquePath);
			if (container == null) {
				container = new Container();
			}
			
			container.setResultsPerPage(length);
			container.setStart(start);
			container.setOrderColumn(orderColumn);
			container.setOrder(order);
			sessionBean.getContainer().put(uniquePath, container);
			
			
			Long filterId = container.getFilterId();
			String filterOrn = container.getFilterOrn() != null && container.getFilterOrn().trim().length() > 0 ? container.getFilterOrn().trim() : null;			
			String filterUserNames = container.getFilterUserNames() != null && container.getFilterUserNames().trim().length() > 0 ? container.getFilterUserNames().trim() : null;			
			Integer filterAuthorizedType = container.getFilterAuthorizedType();
			String filterAuthorizedNames = container.getFilterAuthorizedNames() != null && container.getFilterAuthorizedNames().trim().length() > 0 ? container.getFilterAuthorizedNames().trim() : null;
			String filterValidFrom = container.getFilterValidFrom() != null && container.getFilterValidFrom().trim().length() > 0 ? container.getFilterValidFrom().trim() : null;
			String filterValidTo = container.getFilterValidTo() != null && container.getFilterValidTo().trim().length() > 0 ? container.getFilterValidTo().trim() : null;
			Integer filterStatus = container.getFilterStatus(); 
			logger.message("getAuthorizations() -> length=" + length);
			logger.message("getAuthorizations() -> start=" + start);
			logger.message("getAuthorizations() -> orderColumn=" + orderColumn);
			logger.message("getAuthorizations() -> order=" + order);
			logger.message("getAuthorizations() -> filterId=" + filterId);
			logger.message("getAuthorizations() -> filterOrn=" + filterOrn);
			logger.message("getAuthorizations() -> filterUserNames=" + filterUserNames);
			logger.message("getAuthorizations() -> filterAuthorizedType=" + filterAuthorizedType);
			logger.message("getAuthorizations() -> filterAuthorizedNames=" + filterAuthorizedNames);
			logger.message("getAuthorizations() -> filterValidFrom=" + filterValidFrom);
			logger.message("getAuthorizations() -> filterValidTo=" + filterValidTo);
			logger.message("getAuthorizations() -> status=" + filterStatus);
			String validFrom = filterValidFrom != null ? utils.formatFilterDateToMySQLDate(filterValidFrom) + " 00:00:00" : null;
			String validTo = filterValidTo != null ? utils.formatFilterDateToMySQLDate(filterValidTo) + " 23:59:59" : null;
			logger.message("getAuthorizations() -> validFrom=" + validFrom);
			logger.message("getAuthorizations() -> validTo=" + validTo);
			totalResults = authorizationsService.countAuthorizationsByFilter(filterId, filterOrn, filterUserNames, filterAuthorizedType, filterAuthorizedNames, validFrom, validTo, filterStatus);
			if (totalResults > 0) {
				List<Authorizations> results = authorizationsService.getAllAuthorizationsByFilter(filterId, filterOrn, filterUserNames, filterAuthorizedType, filterAuthorizedNames, validFrom, validTo, filterStatus, start, length , orderColumn, order);
				if (results != null && results.size() > 0) {
					logger.message("getAuthorizations() -> results.size()=" + results.size());	
					JSONArray tmpJA = null;
					for (int i = 0; i < results.size(); i++) {
						tmpJA = new JSONArray();
						tmpJA.put(results.get(i).getAuthorizationsId());
						tmpJA.put(results.get(i).getOrn());
						tmpJA.put(results.get(i).getUserNames());
						tmpJA.put(utils.getAuthorizedType(results.get(i).getAuthorizedType(), resourceRequest));
						tmpJA.put(results.get(i).getAuthorizedNames());
						tmpJA.put(utils.dateToDD_MM_YYYY_HH_MM_SS(results.get(i).getValidFrom()));
						tmpJA.put(utils.dateToDD_MM_YYYY_HH_MM_SS(results.get(i).getValidTo()));						
						tmpJA.put(utils.getAuthorizationStatusName(results.get(i).getStatus(), results.get(i).getValidFrom(), results.get(i).getValidTo(), resourceRequest));
						tmpJA.put(utils.dateToDD_MM_YYYY_HH_MM_SS(results.get(i).getOperationTime()));
						tmpJA.put(results.get(i).getAuthorizationsId());
						ja.put(tmpJA);						
					}				
				} else {
					logger.message("getAuthorizations() -> results.length=0");
				}
			}
		}
		json.put("draw", draw);	
		json.put("recordsTotal", totalResults);	
		json.put("recordsFiltered", totalResults);	
		json.put("data", ja);	
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	 
	}
	
	/*
	 * This resource mapping is called from page "authorization".
	 *
	 * @param authorizationsId		the id of the authorization.
	 * 
	 */
	@ResourceMapping(value = "getAuthorizationFile")
	public void getAuthorizationFile(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("authorizationsId") Long authorizationsId) {
		loadPreferences(resourceRequest);		
		logger.message("getAuthorizationFile");
		if (authorizationsId != null) {
			Authorizations authorization = authorizationsService.getAuthorizedFileByAuthorizationsId(authorizationsId);
			if (authorization != null) {										
				OutputStream out = null;
				try {
					resourceResponse.setContentType((authorization.getAuthorizedDocumentContentType() != null ? authorization.getAuthorizedDocumentContentType() : "text/plain") + "; charset=UTF-8");
					resourceResponse.setCharacterEncoding("UTF-8");
					resourceResponse.setProperty("Content-disposition","attachment; filename=" + URLEncoder.encode(authorization.getAuthorizedDocumentName(), "UTF-8").replaceAll("\\+", " "));
					logger.message("serveResource() -> contentType: " + authorization.getAuthorizedDocumentContentType() != null ? authorization.getAuthorizedDocumentContentType() : "text/plain");
					logger.message("serveResource() -> filename: " + authorization.getAuthorizedDocumentName());
					out = resourceResponse.getPortletOutputStream();
					if (authorization.getAuthorizedDocument() != null) {
						resourceResponse.setContentLength(authorization.getAuthorizedDocument().length);
						try {
							out.write(authorization.getAuthorizedDocument() , 0, authorization.getAuthorizedDocument().length);
						} catch (Exception e) {
						   e.printStackTrace();
						} 
					}
					out.flush();
					out.close();
				} catch (Exception e) {		
					if (out != null) {
						try {
							out.flush();
							out.close();
						} catch (Exception e2) {}
					}
					e.printStackTrace();
				}
			}
		} else {
			try {
				resourceResponse.setContentType("text/plain");
				resourceResponse.getWriter().flush();
				resourceResponse.getWriter().close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	/*
	 * This resource mapping is called from page "authorization".
	 *
	 * @param authorizationsId		the id of the authorization.
	 * 
	 */
	@ResourceMapping(value = "getCancelFile")
	public void getAuthorizationCancelFile(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("authorizationsId") Long authorizationsId) {
		loadPreferences(resourceRequest);		
		logger.message("getAuthorizationCancelFile");
		if (authorizationsId != null) {
			Authorizations authorization = authorizationsService.getCancelFileByAuthorizationsId(authorizationsId);
			if (authorization != null) {										
				OutputStream out = null;
				try {
					resourceResponse.setContentType((authorization.getCancelDocumentContentType() != null ? authorization.getCancelDocumentContentType() : "text/plain") + "; charset=UTF-8");
					resourceResponse.setCharacterEncoding("UTF-8");
					resourceResponse.setProperty("Content-disposition","attachment; filename=" + URLEncoder.encode(authorization.getCancelDocumentName(), "UTF-8").replaceAll("\\+", " "));
					logger.message("serveResource() -> contentType: " + authorization.getCancelDocumentContentType() != null ? authorization.getCancelDocumentContentType() : "text/plain");
					logger.message("serveResource() -> filename: " + authorization.getCancelDocumentName());
					out = resourceResponse.getPortletOutputStream();
					if (authorization.getCancelDocument() != null) {
						resourceResponse.setContentLength(authorization.getCancelDocument().length);
						try {
							out.write(authorization.getCancelDocument() , 0, authorization.getCancelDocument().length);
						} catch (Exception e) {
							e.printStackTrace();
						} 
					}
					out.flush();
					out.close();
				} catch (Exception e) {		
					if (out != null) {
						try {
							out.flush();
							out.close();
						} catch (Exception e2) {}
					}
					e.printStackTrace();
				}
			}
		} else {
			try {
				resourceResponse.setContentType("text/plain");
				resourceResponse.getWriter().flush();
				resourceResponse.getWriter().close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	/*
	 * This resource mapping is called from tab "Authorizations" and handles the block operation.
	 *
	 * @param authorizationsId				the id of the authorization.
	 * @param blockReason					the reason for the block.
	 * 
	 */	
	@ResourceMapping(value = "blockAuthorization")
	public void blockAuthorization(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam(value = "authorizationsId") Long authorizationsId,
			@RequestParam(value = "blockReason", required = false) String blockReason)
	{
		loadPreferences(resourceRequest);		
		logger.message("blockAuthorization [" + authorizationsId + "]");
		logger.message("blockReason=" + blockReason);
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONObject ja = new JSONObject();
		boolean success = false;
		if (sessionBean != null) {			
			Date currentDate = new Date();
			Authorizations authorization = null;
			if (authorizationsId != null) {
				try {
					authorization = authorizationsService.getAuthorizationsById(authorizationsId);
					if (authorization == null || authorization.getAuthorizationsId() == null) {
						sessionBean.setError("Овластяване с номер \"" + authorizationsId + "\" не е намерено.");
						return;
					}
					authorization.setCancelUserId(sessionBean.getUserUID());
					authorization.setCancelUserNames(sessionBean.getUserCN());
					authorization.setCancelTime(currentDate);
					authorization.setOperationTime(currentDate);
					authorization.setStatus(AuthorizationManagerConstants.STATUS_BLOCKED);
					authorization.setCancelReason(blockReason != null ? blockReason.trim() : null);
					if (authorizationsService.blockAuthorizations(authorization)) {
						success = true;						
						// Send notifications.						
						String notificationError = notificationManager.notifyUsersForAuthorizationCancel(authorization, parseSystemsToBean(authorization.getSystems()));
						sessionBean.setMessage("Овластяване с номер \"" + authorizationsId + "\" беше блокирано успешно." + (notificationError != null ? notificationError : ""));
						// Register log event.
						esbCommunicator.sendEvent(sessionBean.getUserUID(), AuthorizationManagerConstants.EVENT_LOG_PORTAL_MODERATOR_BLOCK_AUTHORIZATION, "Блокиране на овластяване с номер \"" + authorizationsId + "\" от " + authorization.getUserNames() + " за " + authorization.getAuthorizedNames(), null, utils.getRemoteIP(resourceRequest), false);
						ja.put("result", "1");
						ja.put("message", "Овластяване с номер \"" + authorizationsId + "\" беше блокирано успешно.");
					}					
				} catch (Exception e) {
					e.printStackTrace();
				}	
			}
		}
		if (!success) {
			sessionBean.setError("Неуспешно блокиране на овластяване с номер " + authorizationsId + ".");
			ja.put("result", "0");
			ja.put("message", "Неуспешно блокиране на овластяване с номер " + authorizationsId + ".");
		}
		json.put("data", ja);
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	
	}
	
	/*
	 * This action is called from tab "Systems".
	 *
	 * @param systemsId		the id of the system.
	 * @param title		 	the system title.
	 * @param oid			oid of the system.
	 * 
	 */
	@ActionMapping(value = "searchFilterSystems")
	public void searchFilterSystems(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "systemsId", required = false) Long systemsId,
			@RequestParam(value = "title", required = false) String title,
			@RequestParam(value = "oid", required = false) String oid) 
	{
		loadPreferences(actionRequest);		
		logger.message("searchFilterSystems");
		logger.message("systemsId=" + (systemsId != null ? systemsId : ""));
		logger.message("title=" + (title != null ? title : ""));
		logger.message("oid=" + (oid != null ? oid : ""));
		
		if (sessionBean != null) {
			String currentPage = sessionBean.getCurrentPage();  
			Integer currentTab = sessionBean.getTabPerPage().get(currentPage);
			String uniquePath = currentPage + currentTab;
			// We support views ONLY for tab "Systems".
			if (AuthorizationManagerConstants.TAB_SYSTEMS == currentTab) {
				Integer currentView = sessionBean.getViewPerTab().get(currentPage + currentTab);
				uniquePath += currentView.toString();
			} 
			Container container = sessionBean.getContainer().get(uniquePath);
			if (container == null) {
				container = new Container();
			}
			
			container.setFilterId(systemsId); 
			container.setFilterTitle(title != null && title.trim().length() > 0 ? title.trim() : null); 
			container.setFilterOid(oid != null && oid.trim().length() > 0 ? oid.trim() : null); 
			container.setStart(0);
			logger.message("uniquePath=" + uniquePath);
			sessionBean.getContainer().put(uniquePath, container);
		}
		// Pass parameters to default view.
		//actionResponse.setRenderParameters(actionRequest.getParameterMap());
		// Returns control to default view.
	}
	
	/*
	 * This action is called from page "system.jsp" to save system form.
	 *
	 * @param systemsId						the id of the system (if we are editing)
	 * @param title							the title of the system.
	 * @param oid							the oid of the system.
	 * 
	 */
	@ActionMapping(value = "saveSystem")
	public void saveSystem(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "systemsId", required = false) Long systemsId,
			@RequestParam(value = "title") String title,
			@RequestParam(value = "oid") String oid) 
	{
		loadPreferences(actionRequest);		
		logger.message("saveSystem [" + systemsId + "]");
		logger.message("title=" + title);
		logger.message("oid=" + oid);
		if (sessionBean != null) {
			Date currentDate = new Date();
			Systems system = null;
			if (systemsId != null) {
				system = systemsService.getSystemsById(systemsId);
				if (system == null || system.getSystemsId() == null) {
					sessionBean.setError("Система с номер \"" + systemsId + "\" не е намерена.");
					return;
				}
			}
			if (system == null) {
				system = new Systems();
			}
			system.setTitle(title.trim());
			system.setOid(oid.trim());
			system.setOperationTime(currentDate);
			system.setUserId(sessionBean.getUserUID());
			boolean result = false;
			// Edit system.
			if (systemsId != null) {
				Systems existingSystem = systemsService.getSystemsByOIDExcId(oid, systemsId);
				if (existingSystem != null) {
					sessionBean.setError("Система с OID \"" + oid  + "\" вече съществува [" + existingSystem.getTitle() + "].");
				} else {
					try {
						result = systemsService.updateSystems(system); 
					} catch (Exception e) {
						e.printStackTrace();
					}		
				}
				if (result) {
					sessionBean.setMessage("Системата \"" + title + "\" беше редактирана успешно.");
					esbCommunicator.sendEvent(sessionBean.getUserUID(), AuthorizationManagerConstants.EVENT_LOG_PORTAL_UPDATE_AUTHORIZATION_SYSTEM, "Редактиране на система - \"" + system.getTitle() + "\" (" + system.getSystemsId() + ")", null, utils.getRemoteIP(actionRequest), false);
				} else {
					sessionBean.setError("Възникна грешка при редактиране на система \"" + title  + "\".");
				}
			} else { // Create group.				
				try {
					Systems existingSystem = systemsService.getSystemsByOID(oid);
					if (existingSystem != null) {
						sessionBean.setError("Система с OID \"" + oid  + "\" вече съществува [" + existingSystem.getTitle() + "].");
					} else {
						system = systemsService.createSystems(system);
						if (system != null) {
							result = true;
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}					 
				if (result) {
					sessionBean.setMessage("Системата \"" + title + "\" беше добавена успешно.");
					esbCommunicator.sendEvent(sessionBean.getUserUID(), AuthorizationManagerConstants.EVENT_LOG_PORTAL_ADD_AUTHORIZATION_SYSTEM, "Добавяне на система - \"" + system.getTitle() + "\" (" + system.getSystemsId() + ")", null, utils.getRemoteIP(actionRequest), false);
				} else if (sessionBean.getError() == null){
					sessionBean.setError("Възникна грешка при добавяне на система \"" + title  + "\".");
				}
				
			}
			if (result) {
				sessionBean.setCurrentPage(AuthorizationManagerConstants.INDEX_PAGE);
			} else {
				// Pass parameters to default view and return control.
				actionResponse.setRenderParameters(actionRequest.getParameterMap());
			}
		}
	}
	
	/*
	 * This resource mapping is called from tab "Systems".
	 *
	 * @param draw				UI parameter from Datatables.
	 * @param start 			page number (started from 0).
	 * @param length			results per page.
	 * @param order[0][column]	order column index.
	 * @param order[0][dir]		order column direction.
	 * 
	 */
	@ResourceMapping(value = "getSystems")
	public void getSystems(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("draw") Integer draw,
			@RequestParam("start") Integer start,
			@RequestParam("length") Integer length,
			@RequestParam("order[0][column]") Integer orderColumn,
			@RequestParam("order[0][dir]") String order)
	{
		loadPreferences(resourceRequest);		
		logger.message("getSystems");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONArray ja = new JSONArray();
		
		int totalResults = 0;
		if (sessionBean != null) {
			String currentPage = sessionBean.getCurrentPage();  
			Integer currentTab = sessionBean.getTabPerPage().get(currentPage);
			String uniquePath = currentPage + currentTab;
			Integer currentView = null;
			// We support views ONLY for tab "Systems".
			if (AuthorizationManagerConstants.TAB_SYSTEMS == currentTab) {
				currentView = sessionBean.getViewPerTab().get(currentPage + currentTab);
				uniquePath += currentView.toString();				
			} 
			Container container = sessionBean.getContainer().get(uniquePath);
			if (container == null) {
				container = new Container();
			}
			
			container.setResultsPerPage(length);
			container.setStart(start);
			container.setOrderColumn(orderColumn);
			container.setOrder(order);
			sessionBean.getContainer().put(uniquePath, container);
			
			
			Long filterId = container.getFilterId();
			String filterTitle = container.getFilterTitle() != null && container.getFilterTitle().trim().length() > 0 ? container.getFilterTitle().trim() : null;
			String filterOid = container.getFilterOid();
			logger.message("getSystems() -> length=" + length);
			logger.message("getSystems() -> start=" + start);
			logger.message("getSystems() -> orderColumn=" + orderColumn);
			logger.message("getSystems() -> order=" + order);
			logger.message("getSystems() -> filterId=" + filterId);
			logger.message("getSystems() -> filterTitle=" + filterTitle);
			logger.message("getSystems() -> filterOid=" + filterOid);
 
			totalResults = systemsService.countSystemsByFilter(filterId, filterTitle, filterOid);
			if (totalResults > 0) {
				List<Systems> results = systemsService.getAllSystemsByFilter(filterId, filterTitle, filterOid, start, length , orderColumn, order);
				if (results != null && results.size() > 0) {
					logger.message("getSystems() -> results.size()=" + results.size());	
					JSONArray tmpJA = null;
					
					for (int i = 0; i < results.size(); i++) {
						tmpJA = new JSONArray();
						tmpJA.put(results.get(i).getSystemsId());
						tmpJA.put(results.get(i).getTitle());
						tmpJA.put(results.get(i).getOid());
						tmpJA.put(utils.dateToDD_MM_YYYY_HH_MM_SS(results.get(i).getOperationTime()));
						tmpJA.put(results.get(i).getSystemsId());
						ja.put(tmpJA);						
					}				
				} else {
					logger.message("getSystems() -> results.length=0");
				}
			}
		} 
		json.put("draw", draw);	
		json.put("recordsTotal", totalResults);	
		json.put("recordsFiltered", totalResults);	
		json.put("data", ja);	
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	 
		
	}
	
	
	/*
	 * This resource mapping is called from tab "Systems" and handle the delete operation.
	 *
	 * @param systemsId		the id of the system that will be deleted.
	 * 
	 */
	@ResourceMapping(value = "deleteSystem")
	public void deleteSystem(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("systemsId") Long systemsId)
	{
		loadPreferences(resourceRequest);		
		logger.message("deleteGroup");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONObject ja = new JSONObject();
		Systems system = null;
		boolean success = false;
		if ("wpadmin".equalsIgnoreCase(sessionBean.getUserUID())) {
			try {
				system = systemsService.getSystemsById(systemsId);
				if (system != null) {
					if (systemsService.deleteSystems(system)) {
						success = true;
						sessionBean.setMessage("Система \"" + system.getTitle() + "\" беше изтрита успешно.");
						ja.put("result", "1");
						ja.put("message", "Система \"" + system.getTitle() + "\" беше изтрита успешно.");
					}
				} 
			} catch (Exception e) {
				e.printStackTrace();
			}	
		}
		if (!success) {
			sessionBean.setError("Неуспешно изтриване на система с номер " + systemsId + ".");
			ja.put("result", "0");
			ja.put("message", "Неуспешно изтриване на система с номер " + systemsId + ".");
		}
		json.put("data", ja);
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	
	}
	
	/*
	 * This action is called from tab "Systems" -> view "Actions"
	 * and also called from tab "Actions" 
	 *
	 * @param actionsId		the id of the action.
	 * @param code			the code of the action.
	 * @param description	the description of the action.
	 * @param systemsId		the id of the system.
	 * 
	 */
	@ActionMapping(value = "searchFilterActions")
	public void searchFilterActions(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "actionsId", required = false) Long actionsId,
			@RequestParam(value = "code", required = false) String code,
			@RequestParam(value = "description", required = false) String description,
			@RequestParam(value = "systemsId", required = false) Long systemsId) 
	{
		loadPreferences(actionRequest);
		logger.message("searchFilterActions");
		logger.message("actionsId=" + (actionsId != null ? actionsId : ""));
		logger.message("code=" + (code != null ? code : ""));
		logger.message("description=" + (description != null ? description : ""));
		logger.message("systemsId=" + (systemsId != null ? systemsId : ""));
		if (sessionBean != null) {
			String currentPage = sessionBean.getCurrentPage();  
			Integer currentTab = sessionBean.getTabPerPage().get(currentPage);
			String uniquePath = currentPage + currentTab;
			// We support views ONLY for tab "Systems".
			if (AuthorizationManagerConstants.TAB_SYSTEMS == currentTab) {
				Integer currentView = sessionBean.getViewPerTab().get(currentPage + currentTab);
				uniquePath += currentView.toString();
			} 
			Container container = sessionBean.getContainer().get(uniquePath);
			if (container == null) {
				container = new Container();
			}
			
			container.setFilterId(actionsId);
			container.setFilterCode(code != null && code.trim().length() > 0 ? code.trim() : null);
			container.setFilterDescription(description != null && description.trim().length() > 0 ? description.trim() : null);
			container.setFilterSystem(systemsId);
			container.setStart(0);
			logger.message("uniquePath=" + uniquePath);
			sessionBean.getContainer().put(uniquePath, container);
		}
		// Pass parameters to default view.
		//actionResponse.setRenderParameters(actionRequest.getParameterMap());
		// Returns control to default view.
	}
	
	/*
	 * This action is called from page "action.jsp" to save action form.
	 *
	 * @param actionsId				the id of the action (if we are editing).
	 * @param title					the title of the action.
	 * @param name					the code of the action.
	 * @param systemsId				the id of the system this action belongs to.
	 * 
	 */
	@ActionMapping(value = "saveAction")
	public void saveAction(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "actionsId", required = false) Long actionsId,			
			@RequestParam(value = "code") String code,
			@RequestParam(value = "description") String description,
			@RequestParam(value = "systemsId") Long systemsId) 
	{
		loadPreferences(actionRequest);		
		logger.message("saveAction [" + actionsId + "]");
		logger.message("code=" + code);
		logger.message("description=" + description);
		logger.message("systemsId=" + systemsId);
		if (sessionBean != null) {
			Date currentDate = new Date();
			Actions action = null;
			if (actionsId != null) {
				action = actionsService.getActionsById(actionsId);
				if (action == null || action.getActionsId() == null) {
					sessionBean.setError("Действие с номер \"" + actionsId + "\" не е намерен в системата.");
					return;
				}
			}
			if (action == null) {
				action = new Actions();
			}			
			action.setCode(code != null ? code.trim() : null);
			action.setDescription(description != null ? description.trim() : null);
			action.setSystemsId(systemsId);
			action.setOperationTime(currentDate);
			action.setUserId(sessionBean.getUserUID());
			boolean result = false;
			// Edit action.
			if (actionsId != null) { 
				Actions existingAction = actionsService.getActionsBySystemIdAndCodeExcId(systemsId, code, actionsId);
				if (existingAction != null) {
					sessionBean.setError("Действие с код \"" + code  + "\" вече съществува за избраната система.");
				} else {
					try {
						result = actionsService.updateActions(action); 
					} catch (Exception e) {
						e.printStackTrace();
					}		
				}
				if (result) {
					sessionBean.setMessage("Действието \"" + description + "\" беше редактирано успешно.");
					esbCommunicator.sendEvent(sessionBean.getUserUID(), AuthorizationManagerConstants.EVENT_LOG_PORTAL_UPDATE_AUTHORIZATION_ACTION, "Редактиране на действие - \"" + action.getDescription() + "\" (" + action.getActionsId() + ")", null, utils.getRemoteIP(actionRequest), false);
				} else {
					sessionBean.setError("Възникна грешка при редактиране на действие \"" + description  + "\".");
				}
			} else { // Create action.
				try {
					Actions existingAction = actionsService.getActionsBySystemIdAndCode(systemsId, code);
					if (existingAction != null) {
						sessionBean.setError("Действие с код \"" + code  + "\" вече съществува в системата.");
					} else {
						action = actionsService.createActions(action);
						if (action != null) {
							result = true;
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}					 
				if (result) {
					sessionBean.setMessage("Действието \"" + description + "\" беше добавено успешно.");
					esbCommunicator.sendEvent(sessionBean.getUserUID(), AuthorizationManagerConstants.EVENT_LOG_PORTAL_ADD_AUTHORIZATION_ACTION, "Добавяне на действие - \"" + action.getDescription() + "\" (" + action.getActionsId() + ")", null, utils.getRemoteIP(actionRequest), false);
				} else if (sessionBean.getError() == null){
					sessionBean.setError("Възникна грешка при добавяне на действие \"" + description  + "\".");
				}
				
			}
			if (result) {
				sessionBean.setCurrentPage(AuthorizationManagerConstants.INDEX_PAGE);
			} else {
				// Pass parameters to default view and return control.
				actionResponse.setRenderParameters(actionRequest.getParameterMap());
			}
		}
	}

	
	/*
	 * This resource mapping is called from tab "Systems" -> view "Actions"
	 * and also called from tab "Actions" 
	 *
	 * @param draw				UI parameter from Datatables.
	 * @param start 			page number (started from 0).
	 * @param length			results per page.
	 * @param order[0][column]	order column index.
	 * @param order[0][dir]		order column direction.
	 * 
	 */
	@ResourceMapping(value = "getActions")
	public void getActions(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("draw") Integer draw,
			@RequestParam("start") Integer start,
			@RequestParam("length") Integer length,
			@RequestParam("order[0][column]") Integer orderColumn,
			@RequestParam("order[0][dir]") String order)
	{
		loadPreferences(resourceRequest);		
		logger.message("getActions");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONArray ja = new JSONArray();
		
		int totalResults = 0;
		if (sessionBean != null) {
			String currentPage = sessionBean.getCurrentPage();  
			Integer currentTab = sessionBean.getTabPerPage().get(currentPage);
			String uniquePath = currentPage + currentTab;
			Integer currentView = null;
			// We support views ONLY for tab "Systems".
			if (AuthorizationManagerConstants.TAB_SYSTEMS == currentTab) {
				currentView = sessionBean.getViewPerTab().get(currentPage + currentTab);
				uniquePath += currentView.toString();				
			} 
			Container container = sessionBean.getContainer().get(uniquePath);
			if (container == null) {
				container = new Container();
			}
			
			container.setResultsPerPage(length);
			container.setStart(start);
			container.setOrderColumn(orderColumn);
			container.setOrder(order);
			sessionBean.getContainer().put(uniquePath, container);
			
			Long filterId = container.getFilterId(); 
			String filterCode = container.getFilterCode() != null && container.getFilterCode().trim().length() > 0 ? container.getFilterCode().trim() : null;
			String filterDescription = container.getFilterDescription() != null && container.getFilterDescription().trim().length() > 0 ? container.getFilterDescription().trim() : null;
			Long filterSystem = container.getFilterSystem();
			logger.message("getActions() -> length=" + length);
			logger.message("getActions() -> start=" + start);
			logger.message("getActions() -> orderColumn=" + orderColumn);
			logger.message("getActions() -> order=" + order);
			logger.message("getActions() -> filterId=" + filterId);
			logger.message("getActions() -> filterCode=" + filterCode);
			logger.message("getActions() -> filterDescription=" + filterDescription);
			logger.message("getActions() -> filterSystem=" + filterSystem);
 
			totalResults = actionsService.countActionsByFilter(filterId, filterCode, filterDescription, filterSystem);
			if (totalResults > 0) {
				List<Actions> results = actionsService.getAllActionsByFilter(filterId, filterCode, filterDescription, filterSystem, start, length, orderColumn, order);
				if (results != null && results.size() > 0) {
					logger.message("getActions() -> results.size()=" + results.size());	
					JSONArray tmpJA = null; 
					boolean isActionsView = AuthorizationManagerConstants.TAB_SYSTEMS == currentTab && currentView != null && AuthorizationManagerConstants.VIEW_ACTIONS == currentView;
					HashMap<Long, String> systemsHm = null;
					// Load systems names.
					if (!isActionsView) {
						systemsHm = new HashMap<Long, String>();
						List<Long> systemsIds = new ArrayList<>(); 
						for (int i = 0; i < results.size(); i++) {
							systemsIds.add(results.get(i).getSystemsId());
						}
						List<Systems> systems = systemsService.getAllSystemsByIds(systemsIds);
						if (systems != null && systems.size() > 0) {
							for (int i = 0; i < systems.size(); i++) {
								systemsHm.put(systems.get(i).getSystemsId(), systems.get(i).getTitle());
							}
						}
					}
					for (int i = 0; i < results.size(); i++) {
						tmpJA = new JSONArray();
						tmpJA.put(results.get(i).getActionsId());
						tmpJA.put(results.get(i).getCode());
						tmpJA.put(results.get(i).getDescription());
						if (!isActionsView) {
							tmpJA.put(systemsHm.get(results.get(i).getSystemsId()));
						} else {
							tmpJA.put(container.getSystem().getTitle());
						}
						tmpJA.put(utils.dateToDD_MM_YYYY_HH_MM_SS(results.get(i).getOperationTime()));
						tmpJA.put(results.get(i).getActionsId());
						ja.put(tmpJA);						
					}				
				} else {
					logger.message("getActions() -> results.length=0");
				}
			}
		} 
		json.put("draw", draw);	
		json.put("recordsTotal", totalResults);	
		json.put("recordsFiltered", totalResults);	
		json.put("data", ja);	
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	 
		
	}
	
	/*
	 * This resource mapping is called from tab "Systems" -> view "Actions"
	 * and also called from tab "Actions" and handle the delete operation.
	 *
	 * @param actionsId		the id of the action that will be deleted.
	 * 
	 */
	@ResourceMapping(value = "deleteAction")
	public void deleteAction(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("actionsId") Long actionsId)
	{
		loadPreferences(resourceRequest);		
		logger.message("deleteAction");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONObject ja = new JSONObject();
		Actions action = null;
		boolean success = false;
		if ("wpadmin".equalsIgnoreCase(sessionBean.getUserUID())) {
			try {
				action = actionsService.getActionsById(actionsId);
				if (action != null) {
					if (actionsService.deleteActions(action)) {
						success = true;
						sessionBean.setMessage("Действието \"" + action.getDescription() + "\" беше изтрито успешно.");
						ja.put("result", "1");
						ja.put("message", "Действието \"" + action.getDescription() + "\" беше изтрито успешно.");
					}
				} 
			} catch (Exception e) {
				e.printStackTrace();
			}	
		}
		if (!success) {
			sessionBean.setError("Неуспешно изтриване на действие с номер " + actionsId + ".");
			ja.put("result", "0");
			ja.put("message", "Неуспешно изтриване на действие с номер " + actionsId + ".");
		}
		json.put("data", ja);
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	
	}
	
	/*
	 * This action mapping is called from button "Update cache".	 
	 * 
	 */
	@ActionMapping(value = "updateCache")
	public void updateCache(ActionRequest actionRequest, ActionResponse actionResponse)
	{			
		logger.message("updateCache");
		
//		List<com.egov.wcm.cache.model.EgovRegisterGroup> groupsArr = null;
//		HashMap<Integer, List<com.egov.wcm.cache.model.EgovRegisterGroup>> groupsHm = null;
//		List<com.egov.wcm.cache.model.EgovRegisterGroupParameter> parametersArr = null;
//		
//		List<RegisterGroup> registerGroupsArr = null;
//		HashMap<Integer, List<RegisterGroup>> registerGroupHm = null;
//		
//		List<RegisterGroup> groups = registerGroupService.getAllRegisterGroups();
//		if (groups != null && groups.size() > 0) {		
//			logger.message("updateCache -> groups.size() = " + groups.size());
//			Integer[] profileTypes = null;
//			registerGroupHm = new HashMap<Integer, List<RegisterGroup>>();
//			for (int i = 0; i < groups.size(); i++) {				
//				profileTypes = utils.getArrayFromFormatedField(groups.get(i).getProfileType());
//				if (profileTypes != null && profileTypes.length > 0) {
//					for (int j = 0; j < profileTypes.length; j++) {
//						registerGroupsArr = registerGroupHm.get(profileTypes[j]);
//						if (registerGroupsArr == null) {
//							registerGroupsArr = new ArrayList<RegisterGroup>();
//						}
//						registerGroupsArr.add(groups.get(i)); 
//						registerGroupHm.put(profileTypes[j], registerGroupsArr);
//					}
//				}
//			}
//			
//			if (registerGroupHm != null && registerGroupHm.size() > 0) {
//				// Order groups per profile type.
//				List<Integer> profileTypeIds = new ArrayList<>(registerGroupHm.keySet());
//				for (int i = 0; i < profileTypeIds.size(); i++) {
//					registerGroupsArr = registerGroupHm.get(profileTypeIds.get(i));
//					if (registerGroupsArr != null) {	 							
//						registerGroupHm.put(profileTypeIds.get(i), utils.orderGroupsByWeight(registerGroupsArr, profileTypeIds.get(i), AuthorizationManagerConstants.ORDER_ASC));
//					}	 										
//				}
//				
//				// Move groups to cache groups object.				
//				groupsHm = new HashMap<>();								
//				for (int i = 0; i < profileTypeIds.size(); i++) {
//					registerGroupsArr = registerGroupHm.get(profileTypeIds.get(i));
//					if (registerGroupsArr != null) {
//						groupsArr = new ArrayList<>();
//						for (int j = 0; j < registerGroupsArr.size(); j++) {
//							groupsArr.add(utils.populateCacheGroup(registerGroupsArr.get(j)));
//						}						
//						groupsHm.put(profileTypeIds.get(i), groupsArr);
//					}	 										
//				}
//				
//				// Load all parameters ordered by group id and weight.
//				List<RegisterGroupParameter> registerParameters = registerGroupParameterService.getAllRegisterGroupParametersOrderByGroupIdAndWeight();
//				if (registerParameters != null && registerParameters.size() > 0) {
//					logger.message("updateCache -> registerParameters.size() = " + registerParameters.size());
//					List<RegisterGroupParameter> registerParametersArr = new ArrayList<>();
//					HashMap<Long, List<RegisterGroupParameter>> parametersPerGroup = new HashMap<Long, List<RegisterGroupParameter>>();
//					for (int i = 0; i < registerParameters.size(); i++) {
//						registerParametersArr = parametersPerGroup.get(registerParameters.get(i).getRegisterGroupId());
//						if (registerParametersArr == null) {
//							registerParametersArr = new ArrayList<RegisterGroupParameter>();
//						}
//						registerParametersArr.add(registerParameters.get(i));
//						parametersPerGroup.put(registerParameters.get(i).getRegisterGroupId(), registerParametersArr);
//					}
//					// Populate loaded parameters in each group.
//					if (parametersPerGroup != null && parametersPerGroup.size() > 0) {	
//						for (int i = 0; i < profileTypeIds.size(); i++) {
//							groupsArr = groupsHm.get(profileTypeIds.get(i));
//							if (groupsArr != null) {
//								for (int j = 0; j < groupsArr.size(); j++) {
//									registerParametersArr = parametersPerGroup.get(groupsArr.get(j).getRegisterGroupId());
//									if (registerParametersArr != null) {
//										parametersArr = new ArrayList<com.egov.wcm.cache.model.EgovRegisterGroupParameter>();
//										for (int k = 0; k < registerParametersArr.size(); k++) {
//											parametersArr.add(utils.populateCacheParameter(registerParametersArr.get(k)));
//										}
//										groupsArr.get(j).setRegisterGroupParameters(parametersArr);
//									}
//								}
//								groupsHm.put(profileTypeIds.get(i), groupsArr);
//							}
//						}
//					}
//				}
//			}
//		}
//		
//		if (groupsHm == null) {
//			groupsHm = new HashMap<Integer, List<com.egov.wcm.cache.model.EgovRegisterGroup>>();
//		}
//		EgovWCMCache.cacheObject.put(EgovWCMCache.KEY_REGISTER_GROUPS_BY_PROFILE_TYPE_ID, groupsHm);
//		sessionBean.setMessage("Актуализацията на кеша приключи успешно.");
		// Returns control to default view.
	}
	
	/*
	 * This method loads systems and actions from "Systems" field of the authorization.	 
	 * 
	 */
	private List<SelectedSystemBean> parseSystemsToBean(final String systemsStr) {
		String[] actionsPerSystem = utils.getArrayFromFormatedField(systemsStr);
		if (actionsPerSystem != null && actionsPerSystem.length > 0) {
			List<Long> systems = new ArrayList<>();
			List<Long> actions = new ArrayList<>();
			Map<Long, List<SelectedActionBean>> systemsHm = new HashMap<>();
			String[] pair = null;
			Long systemsId = null;
			Long actionsId = null;
			List<SelectedActionBean> selectedActionsBean = null;
			SelectedActionBean actionBean = null;
			for (int i = 0; i < actionsPerSystem.length; i++) {
				pair = actionsPerSystem[i].split(":");
				systemsId = Long.parseLong(pair[0]);
				actionsId = Long.parseLong(pair[1]);
				if (!systems.contains(systemsId)) {
					systems.add(systemsId);
				}
				if (!actions.contains(actionsId)) {
					actions.add(actionsId);
				}
				selectedActionsBean = systemsHm.get(systemsId);
				if (selectedActionsBean == null) {
					selectedActionsBean = new ArrayList<SelectedActionBean>();
				}
				actionBean = new SelectedActionBean();
				actionBean.setActionsId(actionsId);
				selectedActionsBean.add(actionBean);
				systemsHm.put(systemsId, selectedActionsBean);
			}
			// Load all systems and actions by ids.
			List<Systems> selectedSystems = systemsService.getAllSystemsByIds(systems);
			List<Actions> selectedActions = actionsService.getAllActionsByIds(actions);
			if (selectedSystems == null || selectedActions == null) {
				logger.error("No systems or actions found for current authorization.");
				return null;
			}
			List<SelectedSystemBean> loadedSystemBeans = new ArrayList<>();
			SelectedSystemBean loadedSystemBean = null;
			SelectedActionBean loadedActionBean = null;
			List<SelectedActionBean> loadedActionsBean = null;
			for (int i = 0; i < selectedSystems.size(); i++) {
				systemsId = selectedSystems.get(i).getSystemsId();
				selectedActionsBean = systemsHm.get(systemsId);
				if (selectedActionsBean != null) {
					loadedSystemBean = new SelectedSystemBean();
					loadedSystemBean.setSystemsId(systemsId);
					loadedSystemBean.setTitle(selectedSystems.get(i).getTitle());
					loadedSystemBean.setOid(selectedSystems.get(i).getOid());
					loadedActionsBean = new ArrayList<SelectedActionBean>();
					for (int j = 0; j < selectedActionsBean.size(); j++) {
						loadedActionBean = selectedActionsBean.get(j);
						for (int k = 0; k < selectedActions.size(); k++) {
							if (selectedActions.get(k).getActionsId() == loadedActionBean.getActionsId()) {
								loadedActionBean.setDescription(selectedActions.get(k).getDescription());
								loadedActionBean.setCode(selectedActions.get(k).getCode());
								loadedActionsBean.add(loadedActionBean);
								break;
							}
						}						
					}
					loadedSystemBean.setActions(loadedActionsBean);
					loadedSystemBeans.add(loadedSystemBean);
				}
			}
			systemsHm.clear();
			selectedActionsBean.clear();
			return loadedSystemBeans; 
		}
		return null;
	}

	
	private void intializeBean() {
		System.out.println("in defaultView() !sessionBean.isInitialised()");
		try {
			String[] attributes = pumaCommunicator.getUserUIDAndCN(pumaHome.getProfile().getCurrentUser(), pumaHome);
			sessionBean.setUserUID(attributes[0]);
			sessionBean.setUserCN(attributes[1]);
		} catch (PumaException e) {
			e.printStackTrace();
		}			
		sessionBean.setCurrentPage(AuthorizationManagerConstants.INDEX_PAGE);
		HashMap<String, Integer> tabPerPage = sessionBean.getTabPerPage();
		tabPerPage.put(AuthorizationManagerConstants.INDEX_PAGE, AuthorizationManagerConstants.TAB_AUTHORIZATIONS);
		sessionBean.setTabPerPage(tabPerPage);
		sessionBean.setContainer(new HashMap<>());
		
		// Initialize tab "Authorizations".
		Container container = new Container();
		container.setOrderColumn(AuthorizationManagerConstants.COLUMN_AUTHORIZATION_OPERATION_TIME);
		container.setOrder(AuthorizationManagerConstants.ORDER_DESC);
		sessionBean.getContainer().put(sessionBean.getCurrentPage() + AuthorizationManagerConstants.TAB_AUTHORIZATIONS, container);
		sessionBean.setInitialised(true);			
	}
	
	private void loadPreferences(PortletRequest request) {
		PortletPreferences prefs = request.getPreferences();		
		PortletViewController.language = prefs.getValue(AuthorizationManagerConstants.SETTING_PARAMETER_LANGUAGE, AuthorizationManagerConstants.LANGUAGE_BG);
		PortletViewController.isDebug = "1".equalsIgnoreCase(prefs.getValue(AuthorizationManagerConstants.SETTING_PARAMETER_DEBUG, ""));
		boolean test = !"PROD".equalsIgnoreCase(System.getProperty("environment")) && "TEST".equalsIgnoreCase(System.getProperty("environmentType"));
		PortletViewController.esbEventLogAddress = prefs.getValue(AuthorizationManagerConstants.SETTING_PARAMETER_ESB_EVENT_LOGGER_ADDRESS, test ? AuthorizationManagerConstants.ESB_LOGGING_URL_TEST : AuthorizationManagerConstants.ESB_LOGGING_URL);
		PortletViewController.mailSmtpHost = prefs.getValue(AuthorizationManagerConstants.SETTING_PARAMETER_MAIL_SMTP_HOST, AuthorizationManagerConstants.MAIL_SMTP_HOST);		
		PortletViewController.fromAddress = prefs.getValue(AuthorizationManagerConstants.SETTING_PARAMETER_MAIL_FROM_ADDRESS, AuthorizationManagerConstants.MAIL_FROM_ADDRESS);		

	}
	
}
