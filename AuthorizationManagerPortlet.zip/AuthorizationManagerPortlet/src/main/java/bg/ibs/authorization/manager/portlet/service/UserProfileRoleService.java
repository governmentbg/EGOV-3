package bg.ibs.authorization.manager.portlet.service;

import java.util.List;

import bg.ibs.authorization.manager.portlet.model.UserProfileRole;

public interface UserProfileRoleService {
	List<UserProfileRole> getAllUserProfileRolesByUserProfileIdAndAdminRole(Long userProfileId);
}
