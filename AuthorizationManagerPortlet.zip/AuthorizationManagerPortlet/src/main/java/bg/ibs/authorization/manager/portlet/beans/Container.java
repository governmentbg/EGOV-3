package bg.ibs.authorization.manager.portlet.beans;

import bg.ibs.authorization.manager.portlet.AuthorizationManagerConstants;
import bg.ibs.authorization.manager.portlet.model.Systems;

public class Container {
	
	private int currentTab = AuthorizationManagerConstants.TAB_AUTHORIZATIONS;
	private Integer currentView = null;
	private Systems system = null;
	private Long filterId = null;
	private String filterRnu = null;	
	private String filterTitle = null;	
	private String filterOid = null;
	private String filterCode = null;
	private String filterDescription = null;
	private String filterUserNames = null;
	private Integer filterAuthorizedType = null;
	private String filterAuthorizedNames = null;
	private String filterValidFrom = null;
	private String filterValidTo = null;
	private Integer filterStatus = null;
	private Long filterSystem = null;	
	
	private boolean filterInitialised;
	private int resultsPerPage = 0;
	private int start = 0;
	private int orderColumn = AuthorizationManagerConstants.COLUMN_ID;
	private String order = AuthorizationManagerConstants.ORDER_ASC;	
	
	public int getCurrentTab() {
		return currentTab;
	}

	public void setCurrentTab(int currentTab) {
		this.currentTab = currentTab;
	}

	public int getCurrentView() {
		return currentView;
	}

	public void setCurrentView(Integer currentView) {
		this.currentView = currentView;
	}

	public Systems getSystem() {
		return system;
	}

	public void setSystem(Systems system) {
		this.system = system;
	}

	public Long getFilterId() {
		return filterId;
	}

	public void setFilterId(Long filterId) {
		this.filterId = filterId;
	}

	public String getFilterRnu() {
		return filterRnu;
	}

	public void setFilterRnu(String filterRnu) {
		this.filterRnu = filterRnu;
	}

	public String getFilterTitle() {
		return filterTitle;
	}

	public void setFilterTitle(String filterTitle) {
		this.filterTitle = filterTitle;
	}

	public String getFilterOid() {
		return filterOid;
	}

	public void setFilterOid(String filterOid) {
		this.filterOid = filterOid;
	}
	
	public String getFilterCode() {
		return filterCode;
	}

	public void setFilterCode(String filterCode) {
		this.filterCode = filterCode;
	}

	public String getFilterDescription() {
		return filterDescription;
	}

	public void setFilterDescription(String filterDescription) {
		this.filterDescription = filterDescription;
	}

	public String getFilterUserNames() {
		return filterUserNames;
	}

	public void setFilterUserNames(String filterUserNames) {
		this.filterUserNames = filterUserNames;
	}

	public Integer getFilterAuthorizedType() {
		return filterAuthorizedType;
	}

	public void setFilterAuthorizedType(Integer filterAuthorizedType) {
		this.filterAuthorizedType = filterAuthorizedType;
	}

	public String getFilterAuthorizedNames() {
		return filterAuthorizedNames;
	}

	public void setFilterAuthorizedNames(String filterAuthorizedNames) {
		this.filterAuthorizedNames = filterAuthorizedNames;
	}

	public String getFilterValidFrom() {
		return filterValidFrom;
	}

	public void setFilterValidFrom(String filterValidFrom) {
		this.filterValidFrom = filterValidFrom;
	}

	public String getFilterValidTo() {
		return filterValidTo;
	}

	public void setFilterValidTo(String filterValidTo) {
		this.filterValidTo = filterValidTo;
	}

	public Integer getFilterStatus() {
		return filterStatus;
	}

	public void setFilterStatus(Integer filterStatus) {
		this.filterStatus = filterStatus;
	}

	public Long getFilterSystem() {
		return filterSystem;
	}

	public void setFilterSystem(Long filterSystem) {
		this.filterSystem = filterSystem;
	}

	public boolean isFilterInitialised() {
		return filterInitialised;
	}

	public void setFilterInitialised(boolean filterInitialised) {
		this.filterInitialised = filterInitialised;
	}

	public int getResultsPerPage() {
		return resultsPerPage;
	}

	public void setResultsPerPage(int resultsPerPage) {
		this.resultsPerPage = resultsPerPage;
	}

	public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getOrderColumn() {
		return orderColumn;
	}

	public void setOrderColumn(int orderColumn) {
		this.orderColumn = orderColumn;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

}

