package bg.ibs.authorization.manager.portlet.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import bg.ibs.authorization.manager.portlet.AuthorizationManagerConstants;
import bg.ibs.authorization.manager.portlet.model.Actions;
import bg.ibs.authorization.manager.portlet.model.ActionsMapper;
import bg.ibs.authorization.manager.portlet.utils.AuthorizationManagerLogger;

@Repository("ActionsDAO")
@Transactional
public class ActionsDAOImpl implements ActionsDAO { 
	private static final String TABLE_NAME = "Actions";
	
	JdbcTemplate jdbcTemplate;
	SimpleJdbcInsert simpleJdbcInsert;
	
	@Autowired
	AuthorizationManagerLogger logger; 

	private final String SQL_FIND_ACTION = "select * from " + TABLE_NAME + " where actionsId = ?";
	private final String SQL_FIND_ACTION_BY_SYSTEM_ID = "select * from " + TABLE_NAME + " where systemsId = ? order by code " + AuthorizationManagerConstants.ORDER_ASC;
	private final String SQL_FIND_ACTION_BY_SYSTEM_ID_AND_CODE = "select * from " + TABLE_NAME + " where systemsId = ? AND code = ?";
	private final String SQL_FIND_ACTION_BY_SYSTEM_ID_AND_CODE_EXC_ID = "select * from " + TABLE_NAME + " where systemsId = ? AND code = ? AND actionsId <> ?";
	private final String SQL_COUNT = "select count(actionsId) from " + TABLE_NAME;
	private final String SQL_GET_ALL = "select * from " + TABLE_NAME;
	private final String SQL_GET_ALL_BY_IDS = "select * from " + TABLE_NAME + " where actionsId in (%s)";
	private final String SQL_UPDATE_ACTION = "update " + TABLE_NAME + " set code = ?, description = ?, operationTime = ? where actionsId = ?";
	private final String SQL_DELETE_ACTION = "delete from " + TABLE_NAME + " where actionsId = ?";

	@Autowired
	public ActionsDAOImpl(@Qualifier("dataSource") DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		simpleJdbcInsert = new SimpleJdbcInsert(dataSource).
				withTableName(TABLE_NAME).
				usingColumns(
						"systemsId", 
						"code", 
						"description", 
						"operationTime", 
						"userId").
				usingGeneratedKeyColumns("actionsId");
	}
	
	public Actions getActionsById(final Long actionId) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_ACTION, new Object[] { actionId }, new ActionsMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public List<Actions> getAllActionsBySystemId(final Long systemId) {
		return jdbcTemplate.query(SQL_FIND_ACTION_BY_SYSTEM_ID, new Object[] { systemId }, new ActionsMapper());
	}
	
	public Actions getActionsBySystemIdAndCode(final Long systemsId, final String code) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_ACTION_BY_SYSTEM_ID_AND_CODE, new Object[] { systemsId, code }, new ActionsMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public Actions getActionsBySystemIdAndCodeExcId(final Long systemsId, final String code, final Long actionsId) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_ACTION_BY_SYSTEM_ID_AND_CODE_EXC_ID, new Object[] { systemsId, code, actionsId }, new ActionsMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public List<Actions> getAllActions() {
		return jdbcTemplate.query(SQL_GET_ALL + " where 1=1 order by title " + AuthorizationManagerConstants.ORDER_ASC, new ActionsMapper());
	}

	public List<Actions> getAllActionsByIds(List<Long> ids) {
		String inSql = String.join(",", Collections.nCopies(ids.size(), "?"));
		return jdbcTemplate.query(String.format(SQL_GET_ALL_BY_IDS, inSql), ids.toArray() , new ActionsMapper());
	}
	
	public Integer countActionsByFilter(final Long id, final String code, final String description, final Long systemsId) {
		if (id == null && (code == null || code.trim().length() == 0) && (description == null || description.trim().length() == 0) && systemsId == null) {
			return jdbcTemplate.queryForObject(SQL_COUNT + " where 1=1", Integer.class);
		}
		// We have filter(s) selected, so apply them.
		String qWhere = "";
		List<Object> filters = new ArrayList<>();
		if (id != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "actionsId = ?";
			filters.add(id);
		}
		if (code != null && code.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += " LOWER(code) LIKE ?";
			filters.add("%" + code.toLowerCase() + "%");
		}
		if (description != null && description.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += " LOWER(description) LIKE ?";
			filters.add("%" + description.toLowerCase() + "%");
		}
		
		if (systemsId != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "systemsId = ?";
			filters.add(systemsId);
		}
		return jdbcTemplate.queryForObject(SQL_COUNT + qWhere, filters.toArray(new Object[filters.size()]), Integer.class);
	}
	
	public List<Actions> getAllActionsByFilter(final Long id, final String code, final String description, final Long systemsId, final Integer start, final Integer length, final Integer orderColumn, final String order) {
		String qOrder = "";
		if (orderColumn != null) {
			if (AuthorizationManagerConstants.COLUMN_ID == orderColumn) {
				qOrder = " order by actionsId";			
			} else if (AuthorizationManagerConstants.COLUMN_ACTIONS_CODE == orderColumn) {
				qOrder = " order by code";
			} else if (AuthorizationManagerConstants.COLUMN_ACTIONS_DESCRIPTION == orderColumn) {
				qOrder = " order by description";
			} else if (AuthorizationManagerConstants.COLUMN_ACTIONS_SYSTEM == orderColumn) {
				qOrder = " order by systemsId";
			} else if (AuthorizationManagerConstants.COLUMN_ACTIONS_OPERATION_TIME == orderColumn) {
				qOrder = " order by operationTime";
			} else {
				qOrder = " order by title";
			}
		} 
		if (qOrder.trim().length() == 0) {
			qOrder = " order by title";
		}
		qOrder += " " + (AuthorizationManagerConstants.ORDER_DESC.equalsIgnoreCase(order) ? AuthorizationManagerConstants.ORDER_DESC : AuthorizationManagerConstants.ORDER_ASC);
		
		qOrder += " limit " + start + ", " + length;				
		
		if (id == null && (code == null || code.trim().length() == 0) && (description == null || description.trim().length() == 0) && systemsId == null) {
			logger.message("getAllActionsByFilter SQL_GET_ALL");
			return jdbcTemplate.query(SQL_GET_ALL + " where 1=1" +  qOrder, new ActionsMapper());
		}
		// We have filter(s) selected, so apply them.
		String qWhere = "";
		List<Object> filters = new ArrayList<>();
		if (id != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "actionsId = ?";
			filters.add(id);
		}
		if (code != null && code.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += " LOWER(code) LIKE ?";
			filters.add("%" + code.toLowerCase() + "%");
		}
		if (description != null && description.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += " LOWER(description) LIKE ?";
			filters.add("%" + description.toLowerCase() + "%");
		}
		
		if (systemsId != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "systemsId = ?";
			filters.add(systemsId);
		}
		return jdbcTemplate.query(SQL_GET_ALL + qWhere + qOrder, filters.toArray(new Object[filters.size()]), new ActionsMapper());
	}

	public Actions createActions(Actions action) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("systemsId", action.getSystemsId());
	    parameters.put("code", action.getCode());
	    parameters.put("description", action.getDescription());	    
	    parameters.put("operationTime", action.getOperationTime());
	    parameters.put("userId", action.getUserId());
		Long id = simpleJdbcInsert.executeAndReturnKey(parameters).longValue();
		logger.message("Generated id - " + id);
		action.setActionsId(id);
		return action;
	}
	
	public boolean updateActions(Actions action) {
		return jdbcTemplate.update(SQL_UPDATE_ACTION, 
				action.getCode(), 
				action.getDescription(), 
				action.getOperationTime(),
				action.getActionsId()) > 0;
	}
	
	public boolean deleteActions(Actions action) {
		return jdbcTemplate.update(SQL_DELETE_ACTION, action.getActionsId()) > 0;
	}

}
