package bg.ibs.authorization.manager.portlet.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import bg.ibs.authorization.manager.portlet.dao.AuthorizationsDAO;
import bg.ibs.authorization.manager.portlet.model.Authorizations;

@Service("AuthorizationsService")
public class AuthorizationsServiceImpl implements AuthorizationsService {

	@Autowired
	@Qualifier("AuthorizationsDAO")
	private AuthorizationsDAO authorizationsDAO; 
	
	public Authorizations getAuthorizationsById(Long id) {
		return authorizationsDAO.getAuthorizationsById(id);
	}
	
	public List<Authorizations> getAllAuthorizations() {
		return authorizationsDAO.getAllAuthorizations();
	}
	
	public Authorizations getAuthorizedFileByAuthorizationsId(Long authorizationsId) {
		return authorizationsDAO.getAuthorizedFileByAuthorizationsId(authorizationsId);
	}
	
	public Authorizations getCancelFileByAuthorizationsId(Long authorizationsId) {
		return authorizationsDAO.getCancelFileByAuthorizationsId(authorizationsId);
	}
	
	public Integer countAuthorizationsByFilter(Long authorizationsId, String orn, String userNames, Integer authorizedType, String authorizedNames, String validFrom, String validTo, Integer status) {
		return authorizationsDAO.countAuthorizationsByFilter(authorizationsId, orn, userNames, authorizedType, authorizedNames, validFrom, validTo, status);
	}
	
	public List<Authorizations> getAllAuthorizationsByFilter(Long authorizationsId, String orn, String userNames, Integer authorizedType, String authorizedNames, String validFrom, String validTo, Integer status, Integer start, Integer length, Integer orderColumn, String order) {
		return authorizationsDAO.getAllAuthorizationsByFilter(authorizationsId, orn, userNames, authorizedType, authorizedNames, validFrom, validTo, status, start, length, orderColumn, order);
	}
	
	public boolean blockAuthorizations(Authorizations authorizations) {
		return authorizationsDAO.blockAuthorizations(authorizations);
	}

}
