package bg.ibs.authorization.manager.portlet.utils;

import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.stereotype.Component;

import bg.ibs.authorization.manager.portlet.AuthorizationManagerConstants;

 
/**
 * AES-GCM inputs - 12 bytes IV, need the same IV and secret keys for encryption and decryption.
 * <p>
 * The output consist of iv, encrypted content, and auth tag in the following format:
 * output = byte[] {i i i c c c c c c ...}
 * <p>
 * i = IV bytes
 * c = content bytes (encrypted content, auth tag)
 */
@Component
public class EncryptorAESGCM {

    private static final String ENCRYPT_ALGO = "AES/GCM/NoPadding";
    private static final int TAG_LENGTH_BIT = 128;
    private static final int IV_LENGTH_BYTE = 12;
    private static final int AES_KEY_BIT = 256;

    private static final Charset UTF_8 = StandardCharsets.UTF_8;

    // AES-GCM needs GCMParameterSpec
    public static byte[] encrypt(byte[] pText, SecretKey secret, byte[] iv) throws Exception {
        Cipher cipher = Cipher.getInstance(ENCRYPT_ALGO);
        cipher.init(Cipher.ENCRYPT_MODE, secret, new GCMParameterSpec(TAG_LENGTH_BIT, iv));
        return cipher.doFinal(pText);
    }

    // prefix IV length + IV bytes to cipher text
    public static byte[] encryptWithPrefixIV(byte[] pText, SecretKey secret, byte[] iv) throws Exception {
        byte[] cipherText = encrypt(pText, secret, iv);

        byte[] cipherTextWithIv = ByteBuffer.allocate(iv.length + cipherText.length)
                .put(iv)
                .put(cipherText)
                .array();
        return cipherTextWithIv;

    }

    public static String decrypt(byte[] cText, SecretKey secret, byte[] iv) throws Exception {
        Cipher cipher = Cipher.getInstance(ENCRYPT_ALGO);
        cipher.init(Cipher.DECRYPT_MODE, secret, new GCMParameterSpec(TAG_LENGTH_BIT, iv));
        byte[] plainText = cipher.doFinal(cText);
        return new String(plainText, UTF_8);
    }

    public static String decryptWithPrefixIV(byte[] cText, SecretKey secret) throws Exception {
        ByteBuffer bb = ByteBuffer.wrap(cText);

        byte[] iv = new byte[IV_LENGTH_BYTE];
        bb.get(iv);

        byte[] cipherText = new byte[bb.remaining()];
        bb.get(cipherText);
        
        return decrypt(cipherText, secret, iv);
    }
    
    
    @SuppressWarnings("unused")
	private static String generateRandomAESKeyBase64Encoded() throws Exception {
    	 SecretKey secretKey = CryptoUtils.getAESKey(AES_KEY_BIT);
    	 return Base64.getEncoder().encodeToString(secretKey.getEncoded());
    }
 
    /**
     * Encrypt the eGov identifier using AES 256 algorithm and formated in Base 64. 
     * 
     * @param identifier			the eGov identifier that will be encrypted and stored in DB & LDAP.
     * @param key					the secret key.
     * @return          			encrypted identifier string. 
     *
     */
    public String encryptEgovIdentifier(String identifier) {
    	// This is the encrypted personal identifier in base 64 format.
    	String encryptedTextBase64 = "";
    	
    	// This key should be given to horizontal system X.
    	String secretKeyBase64 = AuthorizationManagerConstants._EGOV_IDENTIFIER_KEY;
    	
    	// With predefined key.
    	SecretKeySpec secretKey = new SecretKeySpec(Base64.getDecoder().decode(secretKeyBase64), "AES");               
    	
    	// It is always the first 16 characters, so having it dynamically is required.
    	byte[] iv = Base64.getDecoder().decode(AuthorizationManagerConstants._EGOV_IDENTIFIER_IV_KEY);    

    	try {
    		byte[] encryptedText = encryptWithPrefixIV(identifier.getBytes(UTF_8), secretKey, iv);
    		// This is parameter "profileID".        
    		encryptedTextBase64 = Base64.getEncoder().encodeToString(encryptedText);
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    	return encryptedTextBase64;
    }
    
    /**
     * Decrypt the identifier given in Base 64 format. 
     * 
     * @param encryptedTextInBase64		the identifier in Base 64 format.
     * @param key						the secret key.
     * @return          				decrypted identifier string. 
     *
     */
    public String decryptEgovIdentifier(String encryptedTextInBase64) {
    	int IV_LENGTH_BYTE = 12;
    	int TAG_LENGTH_BIT = 128;
    	String ENCRYPT_ALGO = "AES/GCM/NoPadding";    	
    	Charset UTF_8 = StandardCharsets.UTF_8;
    	String decryptedText = "";
    	
    	try {
	    	// Преобразуваме кодирания текст от Base64 формат в масив от байтове. 
	    	byte[] encryptedText = Base64.getDecoder().decode(encryptedTextInBase64);  
	    	// Преобразуваме кодирания ключ от Base64 формат в масив от байтове.
	    	byte[] secretKey = Base64.getDecoder().decode(AuthorizationManagerConstants._EGOV_IDENTIFIER_KEY);
	    	
	    	SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey, "AES");   
	    	
	    	ByteBuffer bb = ByteBuffer.wrap(encryptedText);
	    	
	    	byte[] iv = new byte[IV_LENGTH_BYTE];
	    	bb.get(iv);
	    	
	    	byte[] cipherText = new byte[bb.remaining()];
	    	bb.get(cipherText);
    	
    		Cipher cipher = Cipher.getInstance(ENCRYPT_ALGO);
    		cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, new GCMParameterSpec(TAG_LENGTH_BIT, iv));
    		byte[] plainText = cipher.doFinal(cipherText);
    		decryptedText = new String(plainText, UTF_8);                
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    	return decryptedText;
    }
    

}