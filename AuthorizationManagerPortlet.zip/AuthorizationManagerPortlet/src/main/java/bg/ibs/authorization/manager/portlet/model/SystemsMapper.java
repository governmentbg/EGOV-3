package bg.ibs.authorization.manager.portlet.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class SystemsMapper implements RowMapper<Systems> {

	public Systems mapRow(ResultSet resultSet, int i) throws SQLException {
		
		Systems system = new Systems();
		system.setSystemsId(resultSet.getLong("systemsId"));
		system.setTitle(resultSet.getString("title"));
		system.setOid(resultSet.getString("oid"));
		system.setOperationTime(resultSet.getTimestamp("operationTime"));
		system.setUserId(resultSet.getString("userId"));
		return system;
	}
}
