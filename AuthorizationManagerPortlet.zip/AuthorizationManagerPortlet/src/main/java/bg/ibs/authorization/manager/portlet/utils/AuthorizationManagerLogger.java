package bg.ibs.authorization.manager.portlet.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import bg.ibs.authorization.manager.portlet.controllers.PortletViewController;

@Component
public class AuthorizationManagerLogger {
	
	private Logger logger = LoggerFactory.getLogger("AuthorizationsManagerPortlet");
		
	public void error(String message) {
		logger.error(message);
	}
	public void message(String message) {
//		logger.trace("A TRACE Message");
//      logger.debug("A DEBUG Message");
//      logger.info("An INFO Message");
//      logger.warn("A WARN Message");
//      logger.error("An ERROR Message");
		if (PortletViewController.isDebug) {
			logger.info(message);
		}
	}
	
	public Logger getLogger() {
		return logger;
	}	
	
	public static void main(String[] args) {
		AuthorizationManagerLogger authorizationManagerLogger = new AuthorizationManagerLogger();
		authorizationManagerLogger.error("test");
	}
}
