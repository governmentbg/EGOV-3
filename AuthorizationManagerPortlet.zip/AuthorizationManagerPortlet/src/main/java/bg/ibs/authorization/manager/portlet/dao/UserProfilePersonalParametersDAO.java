package bg.ibs.authorization.manager.portlet.dao;

import bg.ibs.authorization.manager.portlet.model.UserProfilePersonalParameters;

public interface UserProfilePersonalParametersDAO {	
	UserProfilePersonalParameters getUserProfilePersonalParametersByUserProfileId(Long userProfileId);	
}
