package bg.ibs.authorization.manager.portlet.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import bg.ibs.authorization.manager.portlet.dao.UserProfileDAO;
import bg.ibs.authorization.manager.portlet.model.UserProfile;
import bg.ibs.authorization.manager.portlet.model.UserProfileAndPersonalParameters;

@Service("UserProfileService")
public class UserProfileServiceImpl implements UserProfileService {

	@Autowired
	@Qualifier("UserProfileDAO")
	private UserProfileDAO userProfileDao; 
	
	public UserProfile getUserProfileById(Long id) {
		return userProfileDao.getUserProfileById(id);
	}
	
	public UserProfile getUserProfileByIdentifierAndProfileType(String identifier, Integer profileType) {
		return userProfileDao.getUserProfileByIdentifierAndProfileType(identifier, profileType);
	}
	
	public UserProfile getUserProfileByEik(String eik) {
		return userProfileDao.getUserProfileByEik(eik);
	}
	
	public List<UserProfileAndPersonalParameters> getAllUserProfileAndPersonalParametersByUserUIDsAndProfileType(String userUIDs, Integer profileType) {
		return userProfileDao.getAllUserProfileAndPersonalParametersByUserUIDsAndProfileType(userUIDs, profileType);
	}
	
	public UserProfileAndPersonalParameters getUserProfileAndPersonalParametersByIdentifierAndProfileType(String identifier, Integer profileType) {
		return userProfileDao.getUserProfileAndPersonalParametersByIdentifierAndProfileType(identifier, profileType);
	}
	
	public UserProfileAndPersonalParameters getUserProfileAndPersonalParametersByEik(String eik) {
		return userProfileDao.getUserProfileAndPersonalParametersByEik(eik);
	}

}
