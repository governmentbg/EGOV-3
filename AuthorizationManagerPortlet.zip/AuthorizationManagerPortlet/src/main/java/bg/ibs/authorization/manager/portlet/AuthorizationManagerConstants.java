package bg.ibs.authorization.manager.portlet;

public final class AuthorizationManagerConstants {
	
	// DB schema name.
	public static final String DB_SCHEMA_NAME = "egov";
	// JNDI name.
	public static final String JNDI = "jdbc/egovdbDS";
	
	// Portlet session bean name.
	public static final String SESSION_BEAN = "AuthorizationManagerSessionBean";
	
	// Portlet settings parameters.
	public static final String SETTING_PARAMETER_ESB_EVENT_LOGGER_ADDRESS = "esbEventLogAddress";
	public static final String SETTING_PARAMETER_MAIL_SMTP_HOST = "mailSmtpHost";
	public static final String SETTING_PARAMETER_MAIL_FROM_ADDRESS = "mailFromAddress";
	public static final String SETTING_PARAMETER_LANGUAGE = "language";
	public static final String SETTING_PARAMETER_DEBUG = "debug";	
	
	// Supported language codes.
	public static final String LANGUAGE_BG = "bg";
	public static final String LANGUAGE_EN = "en";

	// User types.
	public static final int USER_TYPE_PERSON = 1;
	public static final int USER_TYPE_LE = 2;	
	// Authorized types.
	public static final int AUTHORIZED_TYPE_PERSON = 1;
	public static final int AUTHORIZED_TYPE_LE = 2;
	// Authorized identifier types.
	public static final int AUTHORIZED_IDENTIFIER_TYPE_EGN = 1;
	public static final int AUTHORIZED_IDENTIFIER_TYPE_EIK = 3;
	
	// Status codes.
	public static final int STATUS_INACTIVE = 0; // virtual.
	public static final int STATUS_ACTIVE = 1;
	public static final int STATUS_CANCELED = 2;
	public static final int STATUS_BLOCKED = 3;
	public static final int STATUS_EXPIRED = 9; // virtual.
	
	// Modes.
	public static final int MODE_READ = 0;
	public static final int MODE_EDIT = 1;
	
	// Pages.
	public static final String INDEX_PAGE = "index";
	public static final String AUTHORIZATION_PAGE = "authorization";
	public static final String SYSTEM_PAGE = "system";
	public static final String ACTION_PAGE = "action";
	
	// Role.
	public static final int USER_PROFILE_ROLE_SELECTED = 1;
	
	// Tabs.
	public static final int TAB_AUTHORIZATIONS = 0;
	public static final int TAB_SYSTEMS = 1;
	public static final int TAB_ACTIONS = 2;
	
	public static final int VIEW_SYSTEMS = 1;
	public static final int VIEW_ACTIONS = 2;

	// Columns.
	public static final int COLUMN_ID = 0;	
			
	public static final int COLUMN_SYSTEMS_TITLE = 1;
	public static final int COLUMN_SYSTEMS_OID = 2;
	public static final int COLUMN_SYSTEMS_OPERATION_TIME = 3;
	
	public static final int COLUMN_ACTIONS_CODE = 1;
	public static final int COLUMN_ACTIONS_DESCRIPTION = 2;
	public static final int COLUMN_ACTIONS_SYSTEM = 3;
	public static final int COLUMN_ACTIONS_OPERATION_TIME = 4;
	
	public static final int COLUMN_AUTHORIZATION_RNU = 1;
	public static final int COLUMN_AUTHORIZATION_USER_NAMES = 2;
	public static final int COLUMN_AUTHORIZATION_AUTHORIZED_TYPE = 3;
	public static final int COLUMN_AUTHORIZATION_AUTHORIZED_NAMES = 4;
	public static final int COLUMN_AUTHORIZATION_VALID_FROM = 5;
	public static final int COLUMN_AUTHORIZATION_VALID_TO = 6;
	public static final int COLUMN_AUTHORIZATION_OPERATION_TIME = 8;
	
	public static final String FILTER_DATE_FORMAT = "dd.MM.yyyy";
	public static final String MY_SQL_DATE_FORMAT = "yyyy-MM-dd";
	public static final String MY_SQL_DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";

	// Order
	public static final String ORDER_ASC = "asc";
	public static final String ORDER_DESC = "desc";
	
	// LDAP.
	public static final String LDAP_ATTRIBUTE_UID = "uid";
	public static final String LDAP_ATTRIBUTE_COMMON_NAME = "cn";
	
	// Email.
	public static final String MAIL_SMTP_HOST = "mail";
	public static final String MAIL_FROM_ADDRESS = "feedback.egov@egov.bg";
	
	// ESB.
	public static final String ESB_LOGGING_URL_TEST = "_REPLACED_";
	public static final String ESB_LOGGING_URL = "_REPLACED_";
	
	public static final int USER_PROFILE_TYPE_PERSONAL = 1;
	public static final int USER_PROFILE_TYPE_LEGAL_ENTITY = 2;
	public static final int USER_PROFILE_TYPE_SERVICE_SUPPLIER = 3;
	public static final int USER_PROFILE_TYPE_LEGAL_ENTITY_AL2 = 4;
	
	// AuditLog.
	public static final String EVENT_LOG_PORTAL_ADD_AUTHORIZATION_SYSTEM = "PORTAL_ADD_AUTHORIZATION_SYSTEM";
	public static final String EVENT_LOG_PORTAL_UPDATE_AUTHORIZATION_SYSTEM = "PORTAL_UPDATE_AUTHORIZATION_SYSTEM";
	public static final String EVENT_LOG_PORTAL_ADD_AUTHORIZATION_ACTION = "PORTAL_ADD_AUTHORIZATION_ACTION";
	public static final String EVENT_LOG_PORTAL_UPDATE_AUTHORIZATION_ACTION = "PORTAL_UPDATE_AUTHORIZATION_ACTION";
	public static final String EVENT_LOG_PORTAL_MODERATOR_BLOCK_AUTHORIZATION = "PORTAL_MODERATOR_BLOCK_AUTHORIZATION";
	
	public static final String _EGOV_IDENTIFIER_KEY = "_REPLACED_";
	public static final String _EGOV_IDENTIFIER_IV_KEY = "_REPLACED_";

}
