package bg.ibs.authorization.manager.portlet.dao;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import bg.ibs.authorization.manager.portlet.AuthorizationManagerConstants;
import bg.ibs.authorization.manager.portlet.model.UserProfilePersonalParameters;
import bg.ibs.authorization.manager.portlet.model.UserProfilePersonalParametersMapper;
import bg.ibs.authorization.manager.portlet.utils.AuthorizationManagerLogger;

@Repository("UserProfilePersonalParametersDAO")
@Transactional
public class UserProfilePersonalParametersDAOImpl implements UserProfilePersonalParametersDAO { 
	private static final String TABLE_NAME = "UserProfilePersonalParameters";
	
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	AuthorizationManagerLogger logger; 

	private final String SQL_FIND_PERSONAL_PARAMETERS = "select * from " + AuthorizationManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userProfileId = ?";

	@Autowired
	public UserProfilePersonalParametersDAOImpl(@Qualifier("dataSourceDB2") DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public UserProfilePersonalParameters getUserProfilePersonalParametersByUserProfileId(final Long userProfileId) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_PERSONAL_PARAMETERS, new Object[] { userProfileId }, new UserProfilePersonalParametersMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
}
