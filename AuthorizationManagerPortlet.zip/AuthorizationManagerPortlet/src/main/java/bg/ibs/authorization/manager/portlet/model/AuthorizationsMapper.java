package bg.ibs.authorization.manager.portlet.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class AuthorizationsMapper implements RowMapper<Authorizations> {

	public Authorizations mapRow(ResultSet resultSet, int i) throws SQLException {

		Authorizations authorization = new Authorizations();
		authorization.setAuthorizationsId(resultSet.getLong("authorizationsId"));
		authorization.setRnu(resultSet.getString("rnu"));
		authorization.setRnuCancel(resultSet.getString("rnuCancel"));
		authorization.setUserId(resultSet.getString("userId"));
		authorization.setUserIdentifier(resultSet.getString("userIdentifier"));
		authorization.setUserType(resultSet.getInt("userType"));		
		authorization.setUserNames(resultSet.getString("userNames"));
		authorization.setAuthorizedType(resultSet.getInt("authorizedType"));
		authorization.setAuthorizedIdentifierType(resultSet.getInt("authorizedIdentifierType"));
		authorization.setAuthorizedIdentifier(resultSet.getString("authorizedIdentifier"));
		authorization.setAuthorizedNames(resultSet.getString("authorizedNames"));
		authorization.setValidFrom(resultSet.getTimestamp("validFrom"));
		authorization.setValidTo(resultSet.getTimestamp("validTo"));
		authorization.setSystems(resultSet.getString("systems"));
		authorization.setAuthorizedDocumentName(resultSet.getString("authorizedDocumentName"));		
		authorization.setCancelDocumentName(resultSet.getString("cancelDocumentName"));		
		authorization.setCancelUserId(resultSet.getString("cancelUserId"));		
		authorization.setCancelUserNames(resultSet.getString("cancelUserNames"));		
		authorization.setStatus(resultSet.getInt("status"));
		authorization.setCancelReason(resultSet.getString("cancelReason"));		
		authorization.setCreationTime(resultSet.getTimestamp("creationTime"));
		authorization.setCancelTime(resultSet.getTimestamp("cancelTime"));
		authorization.setOperationTime(resultSet.getTimestamp("operationTime"));		 
		return authorization;
	}
}
