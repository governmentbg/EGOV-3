package bg.ibs.authorization.manager.portlet.dao;

import java.util.List;

import bg.ibs.authorization.manager.portlet.model.UserProfile;
import bg.ibs.authorization.manager.portlet.model.UserProfileAndPersonalParameters;

public interface UserProfileDAO {	
	UserProfile getUserProfileById(Long id);	
	UserProfile getUserProfileByIdentifierAndProfileType(String identifier, Integer profileType);
	UserProfile getUserProfileByEik(String eik);
	List<UserProfileAndPersonalParameters> getAllUserProfileAndPersonalParametersByUserUIDsAndProfileType(String userUIDs, Integer profileType);
	UserProfileAndPersonalParameters getUserProfileAndPersonalParametersByIdentifierAndProfileType(String identifier, Integer profileType);
	UserProfileAndPersonalParameters getUserProfileAndPersonalParametersByEik(String eik);
}
