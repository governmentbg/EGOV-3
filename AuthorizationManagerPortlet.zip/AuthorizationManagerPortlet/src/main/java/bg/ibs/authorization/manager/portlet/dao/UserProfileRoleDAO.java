package bg.ibs.authorization.manager.portlet.dao;

import java.util.List;

import bg.ibs.authorization.manager.portlet.model.UserProfileRole;

public interface UserProfileRoleDAO {	
	List<UserProfileRole> getAllUserProfileRolesByUserProfileIdAndAdminRole(Long userProfileId);
}
