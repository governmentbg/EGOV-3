package bg.ibs.authorization.manager.portlet.model;

import java.util.Date;

public class UserProfileAndPersonalParameters {
	private Long userProfileId;
	private String userUID;
	private String identifier;
	private String names;
	private int status;
	private String deactivationReason;
	private String eik;
	private String nameAndLegalForm;
	private String qualityOfPhysicalPerson;
	private String methodOfRepresentation;
	private int profileType;	
	private String profileStructureType = null;
    private Date dateCreated;
    private Date dateModified;
	private String groupId;
	private String samlResponse;
	private String customSideNav;
	
	private Long userProfilePersonalParametersId;
	private Integer securityLevel;
	private Integer consentToUseAddress;
	private String addressDescription;
	private String mailBox;
	private String zipCode;
	private Integer consentToUsePhone;
	private String phoneNumber;
	private Integer consentToUseEmail;
	private String email;
	private String ekatte;
	
	public Long getUserProfileId() {
		return userProfileId;
	}
	public void setUserProfileId(Long userProfileId) {
		this.userProfileId = userProfileId;
	}
	public String getUserUID() {
		return userUID;
	}
	public void setUserUID(String userUID) {
		this.userUID = userUID;
	}
	public String getIdentifier() {
		return identifier;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public String getNames() {
		return names;
	}
	public void setNames(String names) {
		this.names = names;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getDeactivationReason() {
		return deactivationReason;
	}
	public void setDeactivationReason(String deactivationReason) {
		this.deactivationReason = deactivationReason;
	}
	public String getEik() {
		return eik;
	}
	public void setEik(String eik) {
		this.eik = eik;
	}
	public String getNameAndLegalForm() {
		return nameAndLegalForm;
	}
	public void setNameAndLegalForm(String nameAndLegalForm) {
		this.nameAndLegalForm = nameAndLegalForm;
	}
	public String getQualityOfPhysicalPerson() {
		return qualityOfPhysicalPerson;
	}
	public void setQualityOfPhysicalPerson(String qualityOfPhysicalPerson) {
		this.qualityOfPhysicalPerson = qualityOfPhysicalPerson;
	}
	public String getMethodOfRepresentation() {
		return methodOfRepresentation;
	}
	public void setMethodOfRepresentation(String methodOfRepresentation) {
		this.methodOfRepresentation = methodOfRepresentation;
	}
	public int getProfileType() {
		return profileType;
	}
	public void setProfileType(int profileType) {
		this.profileType = profileType;
	}
	public String getProfileStructureType() {
		return profileStructureType;
	}
	public void setProfileStructureType(String profileStructureType) {
		this.profileStructureType = profileStructureType;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	public Date getDateModified() {
		return dateModified;
	}
	public void setDateModified(Date dateModified) {
		this.dateModified = dateModified;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getSamlResponse() {
		return samlResponse;
	}
	public void setSamlResponse(String samlResponse) {
		this.samlResponse = samlResponse;
	}
	public String getCustomSideNav() {
		return customSideNav;
	}
	public void setCustomSideNav(String customSideNav) {
		this.customSideNav = customSideNav;
	}
	public Long getUserProfilePersonalParametersId() {
		return userProfilePersonalParametersId;
	}
	public void setUserProfilePersonalParametersId(Long userProfilePersonalParametersId) {
		this.userProfilePersonalParametersId = userProfilePersonalParametersId;
	}
	public Integer getSecurityLevel() {
		return securityLevel;
	}
	public void setSecurityLevel(Integer securityLevel) {
		this.securityLevel = securityLevel;
	}
	public Integer getConsentToUseAddress() {
		return consentToUseAddress;
	}
	public void setConsentToUseAddress(Integer consentToUseAddress) {
		this.consentToUseAddress = consentToUseAddress;
	}
	public String getAddressDescription() {
		return addressDescription;
	}
	public void setAddressDescription(String addressDescription) {
		this.addressDescription = addressDescription;
	}
	public String getMailBox() {
		return mailBox;
	}
	public void setMailBox(String mailBox) {
		this.mailBox = mailBox;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public Integer getConsentToUsePhone() {
		return consentToUsePhone;
	}
	public void setConsentToUsePhone(Integer consentToUsePhone) {
		this.consentToUsePhone = consentToUsePhone;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Integer getConsentToUseEmail() {
		return consentToUseEmail;
	}
	public void setConsentToUseEmail(Integer consentToUseEmail) {
		this.consentToUseEmail = consentToUseEmail;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getEkatte() {
		return ekatte;
	}
	public void setEkatte(String ekatte) {
		this.ekatte = ekatte;
	}
	
}
