package bg.ibs.authorization.manager.portlet.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import bg.ibs.authorization.manager.portlet.dao.UserProfilePersonalParametersDAO;
import bg.ibs.authorization.manager.portlet.model.UserProfilePersonalParameters;

@Service("UserProfilePersonalParametersService")
public class UserPorofilePersonalParametersServiceImpl implements UserProfilePersonalParametersService {

	@Autowired
	@Qualifier("UserProfilePersonalParametersDAO")
	private UserProfilePersonalParametersDAO userProfilePersonalParametersDAO;
	
	public UserProfilePersonalParameters getUserProfilePersonalParametersByUserProfileId(Long userProfileId) {
		return userProfilePersonalParametersDAO.getUserProfilePersonalParametersByUserProfileId(userProfileId);
	}

}
