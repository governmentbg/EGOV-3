package bg.ibs.authorization.manager.portlet;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.ibs.authorization.manager.portlet.beans.SelectedActionBean;
import bg.ibs.authorization.manager.portlet.beans.SelectedSystemBean;
import bg.ibs.authorization.manager.portlet.controllers.PortletViewController;
import bg.ibs.authorization.manager.portlet.model.Authorizations;
import bg.ibs.authorization.manager.portlet.model.UserProfileAndPersonalParameters;
import bg.ibs.authorization.manager.portlet.model.UserProfileRole;
import bg.ibs.authorization.manager.portlet.service.UserProfilePersonalParametersService;
import bg.ibs.authorization.manager.portlet.service.UserProfileRoleService;
import bg.ibs.authorization.manager.portlet.service.UserProfileService;
import bg.ibs.authorization.manager.portlet.utils.AuthorizationManagerLogger;
import bg.ibs.authorization.manager.portlet.utils.AuthorizationManagerUtils;
import bg.ibs.authorization.manager.portlet.utils.MailMessage;

@Component
public class AuthorizationNotificationsManager {
	
	@Autowired
	AuthorizationManagerUtils utils;
	@Autowired
	AuthorizationManagerLogger logger;
	
	@Autowired
	UserProfileService userProfileService;
	@Autowired
	UserProfilePersonalParametersService userProfilePersonalParametersService;
	@Autowired
	UserProfileRoleService userProfileRoleService;
	
	public String notifyUsersForAuthorizationCancel(Authorizations authorization, List<SelectedSystemBean> selectedSystems) throws Exception {
		logger.message("AuthorizationNotificationsManager : notifyUsersForAuthorizationCancel() -> start...");	
		String error = "";
		if (authorization != null) {
			String sourceIdentifier = authorization.getUserIdentifier();
			String targetIdentifier = authorization.getAuthorizedIdentifier();
			UserProfileAndPersonalParameters sourceProfile = null;
			UserProfileAndPersonalParameters targetProfile = null;
			if (AuthorizationManagerConstants.USER_PROFILE_TYPE_PERSONAL == authorization.getUserType()) {
				sourceProfile = userProfileService.getUserProfileAndPersonalParametersByIdentifierAndProfileType(sourceIdentifier, AuthorizationManagerConstants.USER_PROFILE_TYPE_PERSONAL);
			} else {
				sourceProfile = userProfileService.getUserProfileAndPersonalParametersByEik(sourceIdentifier);
			}
			if (sourceProfile != null) {
				if (AuthorizationManagerConstants.USER_TYPE_PERSON == authorization.getAuthorizedType()) {
					targetProfile = userProfileService.getUserProfileAndPersonalParametersByIdentifierAndProfileType(targetIdentifier, AuthorizationManagerConstants.USER_PROFILE_TYPE_PERSONAL);
				} else {
					targetProfile = userProfileService.getUserProfileAndPersonalParametersByEik(targetIdentifier);	
				}
				if (targetProfile != null) {
					String subject = "Овластяване от " + authorization.getUserNames() + " за " + authorization.getAuthorizedNames() +  " беше оттеглено.";
					String body = emailBodyAuthorizationCаncel(authorization, selectedSystems);
					// Source is personal.
					if (AuthorizationManagerConstants.USER_PROFILE_TYPE_PERSONAL == authorization.getUserType()) {
						error = notifyPerson(sourceProfile, subject, body);						
					} // Source is legal entity.
					else { 
						error = notifyLE(sourceProfile, subject, body);
					}
					
					// Target is personal.
					if (AuthorizationManagerConstants.AUTHORIZED_TYPE_PERSON == authorization.getAuthorizedType()) {
						error += notifyPerson(targetProfile, subject, body);							
					} // Target is legal entity.
					else { 
						error += notifyLE(targetProfile, subject, body);
					}					
				} else {
					logger.error("AuthorizationNotificationsManager : notifyUsersForAuthorizationCancel() -> targetProfile NULL (" + targetIdentifier + ")");
				}
			} else {
				logger.error("AuthorizationNotificationsManager : notifyUsersForAuthorizationCancel() -> sourceProfile NULL (" + sourceIdentifier + ")");
			}
		}		
		return error != null && error.trim().length() > 0 ? error : null; 
	}
	
	private String notifyPerson(UserProfileAndPersonalParameters profile, String subject, String body) {
		String email = profile.getEmail() != null && profile.getEmail().trim().length() > 0 ? profile.getEmail() : null;
		if (email != null) {															
			try {
				if (MailMessage.sendEmail(PortletViewController.fromAddress, email, null, subject, body, PortletViewController.isDebug)) {
					logger.message("Mail send successfully to " + email + "!");									
				}
			} catch (Exception e) {
				e.printStackTrace();
				return " Неуспешно изпращане на е-поща до " + email;					
			}
		}
		return "";
	}
	
	private String notifyLE(UserProfileAndPersonalParameters profile, String subject, String body) {
		List<UserProfileRole> roles = userProfileRoleService.getAllUserProfileRolesByUserProfileIdAndAdminRole(profile.getUserProfileId());
		String error = "";
		if (roles != null && roles.size() > 0) {
			logger.message("AuthorizationNotificationsManager : notifyLE() -> roles.size() = " + roles.size());
			String adminUserIds = "";
			for (int i = 0; i < roles.size(); i++) {
				if (adminUserIds.length() > 0) {
					adminUserIds += ",";
				}
				adminUserIds += roles.get(i).getUserUID();
			}
			logger.message("AuthorizationNotificationsManager : notifyLE() -> adminUserIds = " + adminUserIds);
			List<UserProfileAndPersonalParameters> adminProfiles = userProfileService.getAllUserProfileAndPersonalParametersByUserUIDsAndProfileType(adminUserIds, AuthorizationManagerConstants.USER_PROFILE_TYPE_PERSONAL);
			if (adminProfiles != null && adminProfiles.size() > 0) {
				logger.message("AuthorizationNotificationsManager : notifyLE() -> adminProfiles.size() = " + adminProfiles.size());
				String email = null;
				for (int i = 0; i < adminProfiles.size(); i++) {
					email = adminProfiles.get(i).getEmail() != null && adminProfiles.get(i).getEmail().trim().length() > 0 ? adminProfiles.get(i).getEmail() : null;
					if (email != null) {															
						try {
							// Send email to each administrator of the legal entity that was authorized.
							if (MailMessage.sendEmail(PortletViewController.fromAddress, email, null, subject, body, PortletViewController.isDebug)) {
								logger.message("Mail send successfully to " + email + "!");
							}
						} catch (Exception e) {
							e.printStackTrace();
							error += " Неуспешно изпращане на е-поща до " + email;
						}
					}
				}
			} else {
				logger.message("AuthorizationNotificationsManager : notifyLE() -> adminUsers=NULL");
			}
		}
		return error;
	}
	
	private String emailBodyAuthorizationCаncel(Authorizations authorization, List<SelectedSystemBean> selectedSystems) {
		String validFrom = utils.dateToDD_MM_YYYY_HH_MM_SS(authorization.getValidFrom());
		String validTo = utils.dateToDD_MM_YYYY_HH_MM_SS(authorization.getValidTo());
		String html = "";
		html += "<div>"
				+ "<div><p><strong>Оттеглено</strong> овластяване от <strong>" + authorization.getUserNames() + "</strong> до <strong>" + authorization.getAuthorizedNames() + "</strong>, за достъп до следните системи и действия:</p></div>"
				+ "<div>"
				+ "";
			if (selectedSystems != null && selectedSystems.size() > 0) {
				SelectedSystemBean system = null;
				SelectedActionBean action = null;
				List<SelectedActionBean> actions = null;
				for (int i = 0; i < selectedSystems.size(); i ++) {	
					system = selectedSystems.get(i);
					actions = system.getActions();
		html += "	<ul style=\"margin:0px;padding-left: 30px !important;\">"
				+ "		<li><p><strong>" + system.getTitle() + "</strong></p>"
				+ "			<ul>";
					if (actions != null && actions.size() > 0) {
						for (int j = 0; j < actions.size(); j ++) {
							action = actions.get(j);
				html += "			"
				+ "				<li><p><strong>" + action.getDescription() + "</strong></p></li>";
						}
					}
				html += "			"
				+ "			</ul>"
				+ "		</li>"
				+ "	</ul>";
				}
			}
			html += " "
				+ "</div>"
				+ "<div>"
				+ "		<p>За периода от <strong>" + validFrom + "</strong> до <strong>" + validTo + "</strong></p>"
				+ "</div>"
				+ "<div>"
				+ "		<p>Статус: <strong>Оттеглено</strong></p>	"
				+ "</div>";
			if (authorization.getCancelReason() != null && authorization.getCancelReason().trim().length() > 0) {
				html += "<div>"
				+ "		<p>Основание: <strong>" + authorization.getCancelReason() + "</strong></p>	"
				+ "</div>";
			}
			html += "<div>"
				+ "		<p>Дата на оттегляне: <strong>" + utils.dateToDD_MM_YYYY_HH_MM_SS(authorization.getCancelTime()) + "</strong></p>"
				+ "</div>"
				+ "</div>";
		return html;
	}
	
}
