package bg.ibs.authorization.manager.portlet.beans;

public class Message {
	String type = null;
	String message = null;
	
	public Message(String type, String message) {
		this.type = type;
		this.message = message;
	}
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}