package bg.ibs.authorization.manager.portlet.dao;

import java.util.List;

import bg.ibs.authorization.manager.portlet.model.Authorizations;

public interface AuthorizationsDAO {
	Authorizations getAuthorizationsById(Long id);
	List<Authorizations> getAllAuthorizations();
	Authorizations getAuthorizedFileByAuthorizationsId(Long authorizationsId);
	Authorizations getCancelFileByAuthorizationsId(Long authorizationsId);
	Integer countAuthorizationsByFilter(Long authorizationsId, String orn, String userNames, Integer authorizedType, String authorizedNames, String validFrom, String validTo, Integer status);
	List<Authorizations> getAllAuthorizationsByFilter(Long authorizationsId, String orn, String userNames, Integer authorizedType, String authorizedNames, String validFrom, String validTo, Integer status, Integer start, Integer length, Integer orderColumn, String order);		
	boolean blockAuthorizations(Authorizations authorizations);
}
