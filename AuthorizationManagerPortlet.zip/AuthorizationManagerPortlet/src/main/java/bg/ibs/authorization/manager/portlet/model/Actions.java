package bg.ibs.authorization.manager.portlet.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Actions {
	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long actionsId;
	@Column(nullable = false)
	private Long systemsId;
	@Column(nullable = false)
	private String code;
	@Column(nullable = false)
	private String description;
	@Column(nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date operationTime;
	private String userId;
	

	public Long getActionsId() {
		return actionsId;
	}
	public void setActionsId(Long actionsId) {
		this.actionsId = actionsId;
	}
	public Long getSystemsId() {
		return systemsId;
	}
	public void setSystemsId(Long systemsId) {
		this.systemsId = systemsId;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getOperationTime() {
		return operationTime;
	}
	public void setOperationTime(Date operationTime) {
		this.operationTime = operationTime;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
}
