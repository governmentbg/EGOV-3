package bg.ibs.authorization.manager.portlet.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import bg.ibs.authorization.manager.portlet.AuthorizationManagerConstants;
import bg.ibs.authorization.manager.portlet.model.UserProfileRole;
import bg.ibs.authorization.manager.portlet.model.UserProfileRoleMapper;
import bg.ibs.authorization.manager.portlet.utils.AuthorizationManagerLogger;

@Repository("UserProfileRoleDAO")
@Transactional
public class UserProfileRoleDAOImpl implements UserProfileRoleDAO { 
	private static final String TABLE_NAME = "UserProfileRole";
	
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	AuthorizationManagerLogger logger; 

	private final String SQL_GET_ALL_BY_USER_PROFILE_ID_AND_ADMIN_ROLE = "select * from " + AuthorizationManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userProfileId = ? and admin = ?";

	@Autowired
	public UserProfileRoleDAOImpl(@Qualifier("dataSourceDB2") DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public List<UserProfileRole> getAllUserProfileRolesByUserProfileIdAndAdminRole(final Long userProfileId) { 
		return jdbcTemplate.query(SQL_GET_ALL_BY_USER_PROFILE_ID_AND_ADMIN_ROLE, new Object[] { userProfileId, AuthorizationManagerConstants.USER_PROFILE_ROLE_SELECTED + "" }, new UserProfileRoleMapper());
	}

}
