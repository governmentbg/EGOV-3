package bg.ibs.authorization.manager.portlet.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class UserProfileRole {
	@Id	
	private Long userProfileRoleId;
	@Column(nullable = false)
	private Long userProfileId;
	@Column(nullable = false)
	private String userUID;	
	private int admin;
	private int editor;
	private int serviceManager;
	private int userRole;
	@Column(name = "dateCreated", nullable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
	
	public Long getUserProfileRoleId() {
		return userProfileRoleId;
	}
	public void setUserProfileRoleId(Long userProfileRoleId) {
		this.userProfileRoleId = userProfileRoleId;
	}
	public Long getUserProfileId() {
		return userProfileId;
	}
	public void setUserProfileId(Long userProfileId) {
		this.userProfileId = userProfileId;
	}
	public String getUserUID() {
		return userUID;
	}
	public void setUserUID(String userUID) {
		this.userUID = userUID;
	}
	public int getAdmin() {
		return admin;
	}
	public void setAdmin(int admin) {
		this.admin = admin;
	}
	public int getEditor() {
		return editor;
	}
	public void setEditor(int editor) {
		this.editor = editor;
	}
	public int getServiceManager() {
		return serviceManager;
	}
	public void setServiceManager(int serviceManager) {
		this.serviceManager = serviceManager;
	}
	public int getUserRole() {
		return userRole;
	}
	public void setUserRole(int userRole) {
		this.userRole = userRole;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	
}
