package bg.ibs.authorization.manager.portlet.dao;

import java.util.List;

import bg.ibs.authorization.manager.portlet.model.Actions;

public interface ActionsDAO {
	Actions getActionsById(Long id);
	List<Actions> getAllActionsBySystemId(Long systemsId);
	Actions getActionsBySystemIdAndCode(Long systemsId, String code);
	Actions getActionsBySystemIdAndCodeExcId(Long systemsId, String code, Long actionsId);
	List<Actions> getAllActions();
	List<Actions> getAllActionsByIds(List<Long> ids);
	Integer countActionsByFilter(Long actionsId, String code, String description, Long systemsId);
	List<Actions> getAllActionsByFilter(Long actionsId, String code, String description, Long systemsId, Integer start, Integer length, Integer orderColumn, String order);		
	Actions createActions(Actions action);
	boolean updateActions(Actions action);
	boolean deleteActions(Actions action);
}
