package bg.ibs.authorization.manager.portlet.service;

import bg.ibs.authorization.manager.portlet.model.UserProfilePersonalParameters;

public interface UserProfilePersonalParametersService {
	UserProfilePersonalParameters getUserProfilePersonalParametersByUserProfileId(Long userProfileId);
}
