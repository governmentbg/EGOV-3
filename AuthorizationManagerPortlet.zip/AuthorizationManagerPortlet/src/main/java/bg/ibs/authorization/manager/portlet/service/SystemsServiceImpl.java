package bg.ibs.authorization.manager.portlet.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import bg.ibs.authorization.manager.portlet.dao.SystemsDAO;
import bg.ibs.authorization.manager.portlet.model.Systems;

@Service("SystemsService")
public class SystemsServiceImpl implements SystemsService {

	@Autowired
	@Qualifier("SystemsDAO")
	private SystemsDAO systemsDao; 
		
	public Systems getSystemsById(Long id) {
		return systemsDao.getSystemsById(id);
	}
	
	public Systems getSystemsByOID(String oid) {
		return systemsDao.getSystemsByOID(oid); 
	}
	
	public Systems getSystemsByOIDExcId(String oid, Long id) {
		return systemsDao.getSystemsByOIDExcId(oid, id); 
	}
	
	public List<Systems> getAllSystems() {
		return systemsDao.getAllSystems();
	}
	
	public List<Systems> getAllSystemsByIds(List<Long> ids) {
		return systemsDao.getAllSystemsByIds(ids);
	}
	
	public Integer countSystemsByFilter(Long id, String title, String oid) {
		return systemsDao.countSystemsByFilter(id, title, oid);
	}
	
	public List<Systems> getAllSystemsByFilter(Long id, String title, String oid, Integer start, Integer length, Integer orderColumn, String order) {
		return systemsDao.getAllSystemsByFilter(id, title, oid, start, length, orderColumn, order);
	}
	
	public Systems createSystems(Systems system) {
		return systemsDao.createSystems(system);
	}
	
	public boolean updateSystems(Systems system) {
		return systemsDao.updateSystems(system);
	}
	
	public boolean deleteSystems(Systems system) {
		return systemsDao.deleteSystems(system);
	}

}
