package bg.ibs.authorization.manager.portlet.beans;

import java.util.HashMap;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import bg.ibs.authorization.manager.portlet.AuthorizationManagerConstants;

@SessionScope
@Component
public class AuthorizationManagerSessionBean {
	
	private String currentPage = AuthorizationManagerConstants.INDEX_PAGE;
	private HashMap<String, Container> container = null;
	private HashMap<String, Integer> tabPerPage = null;
	private HashMap<String, Integer> viewPerTab = null;
	private Long authorizationsId = null;	
	private Long systemsId = null;
	private Long actionsId = null;
	private Integer mode = null;
	private String userUID = null;
	private String userCN = null;
	private String error = null;
	private String message = null;
	private int view = AuthorizationManagerConstants.VIEW_SYSTEMS;
	private boolean initialised;
	
	public String getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}
	
	public HashMap<String, Container> getContainer() {
		return container != null ? container : new HashMap<String, Container>();
	}

	public void setContainer(HashMap<String, Container> container) {
		this.container = container;
	}

	public HashMap<String, Integer> getTabPerPage() {
		return tabPerPage != null ? tabPerPage : new HashMap<String, Integer>();
	}

	public void setTabPerPage(HashMap<String, Integer> tabPerPage) {
		this.tabPerPage = tabPerPage;
	}
	
	public HashMap<String, Integer> getViewPerTab() {
		return viewPerTab != null ? viewPerTab : new HashMap<String, Integer>();
	}

	public void setViewPerTab(HashMap<String, Integer> viewPerTab) {
		this.viewPerTab = viewPerTab;
	}

	public Long getAuthorizationsId() {
		return authorizationsId;
	}

	public void setAuthorizationsId(Long authorizationsId) {
		this.authorizationsId = authorizationsId;
	}

	public Long getSystemsId() {
		return systemsId;
	}

	public void setSystemsId(Long systemsId) {
		this.systemsId = systemsId;
	}

	public Long getActionsId() {
		return actionsId;
	}

	public void setActionsId(Long actionsId) {
		this.actionsId = actionsId;
	}

	public Integer getMode() {
		return mode;
	}

	public void setMode(Integer mode) {
		this.mode = mode;
	}

	public String getUserUID() {
		return userUID;
	}

	public void setUserUID(String userUID) {
		this.userUID = userUID;
	}

	public String getUserCN() {
		return userCN;
	}

	public void setUserCN(String userCN) {
		this.userCN = userCN;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getView() {
		return view;
	}

	public void setView(int view) {
		this.view = view;
	}

	public boolean isInitialised() {
		return initialised;
	}
	public void setInitialised(boolean initialised) {
		this.initialised = initialised;
	}
}
