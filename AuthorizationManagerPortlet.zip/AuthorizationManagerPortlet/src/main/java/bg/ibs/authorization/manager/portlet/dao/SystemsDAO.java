package bg.ibs.authorization.manager.portlet.dao;

import java.util.List;

import bg.ibs.authorization.manager.portlet.model.Systems;

public interface SystemsDAO {
	Systems getSystemsById(Long id);
	Systems getSystemsByOID(String oid);
	Systems getSystemsByOIDExcId(String oid, Long id);
	List<Systems> getAllSystems();  
	List<Systems> getAllSystemsByIds(List<Long> ids);  
	Integer countSystemsByFilter(Long id, String title, String oid);
	List<Systems> getAllSystemsByFilter(Long id, String title, String oid, Integer start, Integer length, Integer orderColumn, String order);   
	Systems createSystems(Systems system);
	boolean updateSystems(Systems system);
	boolean deleteSystems(Systems system);
	
}
