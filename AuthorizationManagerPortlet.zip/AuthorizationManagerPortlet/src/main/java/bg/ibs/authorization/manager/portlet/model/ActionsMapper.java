package bg.ibs.authorization.manager.portlet.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ActionsMapper implements RowMapper<Actions> {

	public Actions mapRow(ResultSet resultSet, int i) throws SQLException {

		Actions action = new Actions();
		action.setActionsId(resultSet.getLong("actionsId"));
		action.setSystemsId(resultSet.getLong("systemsId"));
		action.setCode(resultSet.getString("code"));
		action.setDescription(resultSet.getString("description"));
		action.setOperationTime(resultSet.getTimestamp("operationTime"));
		action.setUserId(resultSet.getString("userId"));
		return action;
	}
}
