package bg.ibs.authorization.manager.portlet.communicator;

import java.security.PrivilegedExceptionAction;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ibm.portal.um.PumaEnvironment;
import com.ibm.portal.um.PumaHome;
import com.ibm.portal.um.PumaProfile;
import com.ibm.portal.um.User;

import bg.ibs.authorization.manager.portlet.AuthorizationManagerConstants;
import bg.ibs.authorization.manager.portlet.utils.AuthorizationManagerLogger;

@Component
public class PumaCommunicator {
	@Autowired
	AuthorizationManagerLogger logger;
		
	@SuppressWarnings("rawtypes")
	public String[] getUserUIDAndCN(final User user, final PumaHome pumaHome) {
		java.util.Map<String, Object> userInfo = getUserAttributesInfo(user, pumaHome, pumaHome.getProfile());
		String[] attributes = new String[2];
		if (userInfo != null) {
			Object attribute = userInfo.get(AuthorizationManagerConstants.LDAP_ATTRIBUTE_UID);			
			if (attribute != null) {
				String currentUserUID = null;
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							currentUserUID += " ";
						}
						currentUserUID += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					currentUserUID = (String)attribute;
				}		
				attributes[0]=currentUserUID;
			}
			attribute = userInfo.get(AuthorizationManagerConstants.LDAP_ATTRIBUTE_COMMON_NAME);			
			if (attribute != null) {
				String currentUserCN = null;
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							currentUserCN += " ";
						}
						currentUserCN += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					currentUserCN = (String)attribute;
				}		
				attributes[1]=currentUserCN;
			}
			return attributes;
		}
		return null;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public java.util.Map<String, Object> getUserAttributesInfo(final User user, final PumaHome pumaHome, final PumaProfile pumaProfile) {
		logger.message("getUserAttributesInfo(com.ibm.portal.um.User)");
		final java.util.List<String> attributesNamesList;
		try {
			final PumaEnvironment env = pumaHome.getEnvironment();
			attributesNamesList = new ArrayList<>();
			attributesNamesList.add(AuthorizationManagerConstants.LDAP_ATTRIBUTE_UID);
			attributesNamesList.add(AuthorizationManagerConstants.LDAP_ATTRIBUTE_COMMON_NAME);
			java.util.Map<String, Object> userInfo = (java.util.Map<String, Object>) env.runUnrestricted(new PrivilegedExceptionAction() {
				public Object run() throws Exception {
					return pumaProfile.getAttributes((com.ibm.portal.um.Principal) user, attributesNamesList);
				}
			});
			return userInfo;
		} catch (Exception e) {
			logger.error("getUserAttributesInfo(user, pumaHome, pumaProfile) -> Exception: " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
}
