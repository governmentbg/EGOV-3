package bg.ibs.authorization.manager.portlet.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import bg.ibs.authorization.manager.portlet.AuthorizationManagerConstants;
import bg.ibs.authorization.manager.portlet.model.Authorizations;
import bg.ibs.authorization.manager.portlet.model.AuthorizationsCancelFileMapper;
import bg.ibs.authorization.manager.portlet.model.AuthorizationsFileMapper;
import bg.ibs.authorization.manager.portlet.model.AuthorizationsMapper;
import bg.ibs.authorization.manager.portlet.utils.AuthorizationManagerLogger;
import bg.ibs.authorization.manager.portlet.utils.AuthorizationManagerUtils;

@Repository("AuthorizationsDAO")
@Transactional
public class AuthorizationsDAOImpl implements AuthorizationsDAO { 
	private static final String TABLE_NAME = "Authorizations";
	
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	AuthorizationManagerLogger logger; 
	@Autowired
	AuthorizationManagerUtils utils;

	private final String SQL_FIND_AUTHORIZATION = "select * from " + TABLE_NAME + " where authorizationsId = ?";
	private final String SQL_FIND_AUTHORIZED_FILE = "select authorizedDocument,authorizedDocumentName,authorizedDocumentSize,authorizedDocumentContentType from " + TABLE_NAME + " where authorizationsId = ?";
	private final String SQL_FIND_CANCEL_FILE = "select cancelDocument,cancelDocumentName,cancelDocumentSize,cancelDocumentContentType from " + TABLE_NAME + " where authorizationsId = ?";
	private final String SQL_COUNT = "select count(authorizationsId) from " + TABLE_NAME;
	private final String SQL_GET_ALL = "select * from " + TABLE_NAME;
	private final String SQL_BLOCK_AUTHORIZATION = "update " + TABLE_NAME + " set status = ?, cancelUserId = ?, cancelUserNames = ?, cancelReason = ?, cancelTime = ?, operationTime = ? where authorizationsId = ?";

	@Autowired
	public AuthorizationsDAOImpl(@Qualifier("dataSource") DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public Authorizations getAuthorizationsById(final Long authorizationsId) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_AUTHORIZATION, new Object[] { authorizationsId }, new AuthorizationsMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public List<Authorizations> getAllAuthorizations() {
		return jdbcTemplate.query(SQL_GET_ALL + " where 1=1 order by operationTime " + AuthorizationManagerConstants.ORDER_DESC, new AuthorizationsMapper());
	}
	
	public Authorizations getAuthorizedFileByAuthorizationsId(final Long authorizationsId) {
		try {			
			return jdbcTemplate.queryForObject(SQL_FIND_AUTHORIZED_FILE, new Object[] { authorizationsId }, new AuthorizationsFileMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public Authorizations getCancelFileByAuthorizationsId(final Long authorizationsId) {
		try {			
			return jdbcTemplate.queryForObject(SQL_FIND_CANCEL_FILE, new Object[] { authorizationsId }, new AuthorizationsCancelFileMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	public Integer countAuthorizationsByFilter(final Long authorizationsId, final String rnu, final String userNames, final Integer authorizedType, final String authorizedNames, final String validFrom, final String validTo, final Integer status) {
		if (authorizationsId == null 
				&& (rnu == null || rnu.trim().length() == 0)
				&& (userNames == null || userNames.trim().length() == 0)
				&& authorizedType == null 
				&& (authorizedNames == null || authorizedNames.trim().length() == 0)
				&& (validFrom == null || validFrom.trim().length() == 0)
				&& (validTo == null || validTo.trim().length() == 0)
				&& status == null) {
			return jdbcTemplate.queryForObject(SQL_COUNT + " where 1=1", Integer.class);
		}
		// We have filter(s) selected, so apply them.
		String qWhere = "";
		List<Object> filters = new ArrayList<>();
		if (authorizationsId != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "authorizationsId = ?";
			filters.add(authorizationsId);
		}
		if (rnu != null && rnu.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "(";
			qWhere += "rnu = ?";
			filters.add(rnu);
			qWhere += " OR ";
			qWhere += "rnuCancel = ?";
			filters.add(rnu);
			qWhere += ")";
		}
		if (userNames != null && userNames.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += " LOWER(userNames) LIKE ?";
			filters.add("%" + userNames.toLowerCase() + "%");
		}
		if (authorizedType != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "authorizedType = ?";
			filters.add(authorizedType);
		}
		if (authorizedNames != null && authorizedNames.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += " LOWER(authorizedNames) LIKE ?";
			filters.add("%" + authorizedNames.toLowerCase() + "%");
		}
		if (validFrom != null && validTo != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}			
			qWhere += "(validFrom = ? AND validTo = ?)";				
			filters.add(validFrom);
			filters.add(validTo);
		} else {
			if (validFrom != null) {
				if (qWhere.length() == 0) {
					qWhere += " WHERE ";
				} else {
					qWhere += " AND ";
				}
				qWhere += "validFrom >= ?";
				filters.add(validFrom);
			} else if (validTo != null) {
				if (qWhere.length() == 0) {
					qWhere += " WHERE ";
				} else {
					qWhere += " AND ";
				}
				qWhere += "validTo <= ?";
				filters.add(validTo);
			}
		}
		if (status != null) {
			int finalStatus = status;
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "status = ?";
			// If virtual status found, set it to active.
			if (AuthorizationManagerConstants.STATUS_INACTIVE == status || AuthorizationManagerConstants.STATUS_EXPIRED == status) {
				finalStatus = AuthorizationManagerConstants.STATUS_ACTIVE;
			}
			filters.add(finalStatus);
			// If status is active, inactive or expired check for valid dates interval.
			if (status == AuthorizationManagerConstants.STATUS_ACTIVE) {
				Date currentDate = new Date();
				qWhere += " AND ";
				qWhere += "validFrom <= ?";
				filters.add(utils.timeMillisToTimestamp(currentDate.getTime()));
				qWhere += " AND ";
				qWhere += "validTo >= ?";
				filters.add(utils.timeMillisToTimestamp(currentDate.getTime()));
			} else if (status == AuthorizationManagerConstants.STATUS_INACTIVE) {
				Date currentDate = new Date();
				qWhere += " AND ";
				qWhere += "validFrom > ?";
				filters.add(utils.timeMillisToTimestamp(currentDate.getTime()));				
			} else if (status == AuthorizationManagerConstants.STATUS_EXPIRED) {
				Date currentDate = new Date();
				qWhere += " AND ";
				qWhere += "validTo < ?";
				filters.add(utils.timeMillisToTimestamp(currentDate.getTime()));				
			}
		}
		return jdbcTemplate.queryForObject(SQL_COUNT + qWhere, filters.toArray(new Object[filters.size()]), Integer.class);
	}
	
	public List<Authorizations> getAllAuthorizationsByFilter(final Long authorizationsId, final String rnu, final String userNames, final Integer authorizedType, final String authorizedNames, final String validFrom, final String validTo, final Integer status, final Integer start, final Integer length, final Integer orderColumn, final String order) {
		String qOrder = "";
		if (orderColumn != null) {
			if (AuthorizationManagerConstants.COLUMN_ID == orderColumn) {
				qOrder = " order by authorizationsId";			
			} else if (AuthorizationManagerConstants.COLUMN_AUTHORIZATION_USER_NAMES == orderColumn) {
				qOrder = " order by userNames";
			} else if (AuthorizationManagerConstants.COLUMN_AUTHORIZATION_AUTHORIZED_TYPE == orderColumn) {
				qOrder = " order by authorizedType";
			} else if (AuthorizationManagerConstants.COLUMN_AUTHORIZATION_AUTHORIZED_NAMES == orderColumn) {
				qOrder = " order by authorizedNames";
			} else if (AuthorizationManagerConstants.COLUMN_AUTHORIZATION_VALID_FROM == orderColumn) {
				qOrder = " order by validFrom";
			} else if (AuthorizationManagerConstants.COLUMN_AUTHORIZATION_VALID_TO == orderColumn) {
				qOrder = " order by validTo";
			} else if (AuthorizationManagerConstants.COLUMN_ACTIONS_OPERATION_TIME == orderColumn) {
				qOrder = " order by operationTime";
			} else {
				qOrder = " order by operationTime";
			}
		} 
		if (qOrder.trim().length() == 0) {
			qOrder = " order by operationTime";
		}
		qOrder += " " + (AuthorizationManagerConstants.ORDER_ASC.equalsIgnoreCase(order) ? AuthorizationManagerConstants.ORDER_ASC : AuthorizationManagerConstants.ORDER_DESC);
		
		qOrder += " limit " + start + ", " + length;				
		
		if (authorizationsId == null 
				&& (rnu == null || rnu.trim().length() == 0)
				&& (userNames == null || userNames.trim().length() == 0)
				&& authorizedType == null 
				&& (authorizedNames == null || authorizedNames.trim().length() == 0)
				&& (validFrom == null || validFrom.trim().length() == 0)
				&& (validTo == null || validTo.trim().length() == 0)
				&& status == null) {
			logger.message("getAllAuthorizationsByFilter SQL_GET_ALL");
			return jdbcTemplate.query(SQL_GET_ALL + " where 1=1" +  qOrder, new AuthorizationsMapper());
		}
		// We have filter(s) selected, so apply them.
		String qWhere = "";
		List<Object> filters = new ArrayList<>();
		if (authorizationsId != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "authorizationsId = ?";
			filters.add(authorizationsId);
		}
		if (rnu != null && rnu.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "(";
			qWhere += "rnu = ?";
			filters.add(rnu);
			qWhere += " OR ";
			qWhere += "rnuCancel = ?";
			filters.add(rnu);
			qWhere += ")";			
		}
		if (userNames != null && userNames.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += " LOWER(userNames) LIKE ?";
			filters.add("%" + userNames.toLowerCase() + "%");
		}
		if (authorizedType != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "authorizedType = ?";
			filters.add(authorizedType);
		}
		if (authorizedNames != null && authorizedNames.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += " LOWER(authorizedNames) LIKE ?";
			filters.add("%" + authorizedNames.toLowerCase() + "%");
		}
		if (validFrom != null && validTo != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "(validFrom = ? AND validTo = ?)";				
			filters.add(validFrom);
			filters.add(validTo);
		} else {
			if (validFrom != null) {
				if (qWhere.length() == 0) {
					qWhere += " WHERE ";
				} else {
					qWhere += " AND ";
				}
				qWhere += "validFrom >= ?";
				filters.add(validFrom);
			} else if (validTo != null) {
				if (qWhere.length() == 0) {
					qWhere += " WHERE ";
				} else {
					qWhere += " AND ";
				}
				qWhere += "validTo <= ?";
				filters.add(validTo);
			}
		}
		if (status != null) {
			int finalStatus = status;
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "status = ?";
			// If virtual status found, set it to active.
			if (AuthorizationManagerConstants.STATUS_INACTIVE == status || AuthorizationManagerConstants.STATUS_EXPIRED == status) {
				finalStatus = AuthorizationManagerConstants.STATUS_ACTIVE;
			}			
			filters.add(finalStatus);
			// If status is active, inactive or expired check for valid dates interval.
			if (status == AuthorizationManagerConstants.STATUS_ACTIVE) {
				Date currentDate = new Date();
				qWhere += " AND ";
				qWhere += "validFrom <= ?";
				filters.add(utils.timeMillisToTimestamp(currentDate.getTime()));
				qWhere += " AND ";
				qWhere += "validTo >= ?";
				filters.add(utils.timeMillisToTimestamp(currentDate.getTime()));
			} else if (status == AuthorizationManagerConstants.STATUS_INACTIVE) {
				Date currentDate = new Date();
				qWhere += " AND ";
				qWhere += "validFrom > ?";
				filters.add(utils.timeMillisToTimestamp(currentDate.getTime()));				
			} else if (status == AuthorizationManagerConstants.STATUS_EXPIRED) {
				Date currentDate = new Date();
				qWhere += " AND ";
				qWhere += "validTo < ?";
				filters.add(utils.timeMillisToTimestamp(currentDate.getTime()));				
			}
		}
		return jdbcTemplate.query(SQL_GET_ALL + qWhere + qOrder, filters.toArray(new Object[filters.size()]), new AuthorizationsMapper());
	}

	public boolean blockAuthorizations(Authorizations authorization) {
		return jdbcTemplate.update(SQL_BLOCK_AUTHORIZATION,
				authorization.getStatus(), 
				authorization.getCancelUserId(), 
				authorization.getCancelUserNames(), 
				authorization.getCancelReason(), 
				authorization.getCancelTime(), 
				authorization.getOperationTime(),
				authorization.getAuthorizationsId()) > 0;
	}
	
}
