package bg.ibs.authorization.manager.portlet.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import bg.ibs.authorization.manager.portlet.dao.UserProfileRoleDAO;
import bg.ibs.authorization.manager.portlet.model.UserProfileRole;

@Service("UserProfileRoleService")
public class UserProfileRoleServiceImpl implements UserProfileRoleService {

	@Autowired
	@Qualifier("UserProfileRoleDAO")
	private UserProfileRoleDAO userProfileRoleDao; 
	
	public List<UserProfileRole> getAllUserProfileRolesByUserProfileIdAndAdminRole(Long userProfileId) {
		return userProfileRoleDao.getAllUserProfileRolesByUserProfileIdAndAdminRole(userProfileId);
	} 

}
