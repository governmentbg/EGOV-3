package bg.ibs.authorization.manager.portlet.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import bg.ibs.authorization.manager.portlet.AuthorizationManagerConstants;
import bg.ibs.authorization.manager.portlet.model.UserProfile;
import bg.ibs.authorization.manager.portlet.model.UserProfileAndPersonalParameters;
import bg.ibs.authorization.manager.portlet.model.UserProfileAndPersonalParametersMapper;
import bg.ibs.authorization.manager.portlet.model.UserProfileMapper;
import bg.ibs.authorization.manager.portlet.utils.AuthorizationManagerLogger;

@Repository("UserProfileDAO")
@Transactional
public class UserProfileDAOImpl implements UserProfileDAO { 
	private static final String TABLE_NAME = "UserProfile";
	
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	AuthorizationManagerLogger logger;  

	private final String SQL_FIND_PROFILE = "select * from " + AuthorizationManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userProfileId = ?";
	private final String SQL_FIND_PROFILE_BY_IDENTIFIER_AND_TYPE = "select * from " + AuthorizationManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where identifier = ? and profileType = ?";
	private final String SQL_FIND_PROFILE_BY_EIK = "select * from " + AuthorizationManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where eik = ?";

	@Autowired
	public UserProfileDAOImpl(@Qualifier("dataSourceDB2") DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);		
	}

	public UserProfile getUserProfileById(final Long userProfileId) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_PROFILE, new Object[] { userProfileId }, new UserProfileMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public UserProfile getUserProfileByIdentifierAndProfileType(final String identifier, final Integer profileType) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_PROFILE_BY_IDENTIFIER_AND_TYPE, new Object[] { identifier, profileType }, new UserProfileMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public UserProfile getUserProfileByEik(final String eik) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_PROFILE_BY_EIK, new Object[] { eik }, new UserProfileMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	} 
	
	public List<UserProfileAndPersonalParameters> getAllUserProfileAndPersonalParametersByUserUIDsAndProfileType(final String userUIDs, final Integer profileType) {
		String query = getUserProfileAndPersonalParametersQuery();
		
		query += AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.userUID in (%s)";
		String[] userUids = userUIDs.split(",");
		String inSql = String.join(",", Collections.nCopies(userUids.length, "?"));
		query = String.format(query, inSql);			
		query += " and ";
		query += AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.profileType = ?";
		List<String> parameters = new ArrayList<String>();
		for (int i = 0; i < userUids.length; i++) {
			parameters.add(userUids[i]);
		}
		parameters.add(profileType + "");			
		return jdbcTemplate.query(query, parameters.toArray(), new UserProfileAndPersonalParametersMapper());
	}
	
	public UserProfileAndPersonalParameters getUserProfileAndPersonalParametersByIdentifierAndProfileType(final String identifier, final Integer profileType) {
		try {
			String query = getUserProfileAndPersonalParametersQuery();
			query += AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.identifier = ?";
			query += " and ";
			query += AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.profileType = ?";
			return jdbcTemplate.queryForObject(query, new Object[] {identifier, profileType}, new UserProfileAndPersonalParametersMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public UserProfileAndPersonalParameters getUserProfileAndPersonalParametersByEik(final String eik) {
		try {
			String query = getUserProfileAndPersonalParametersQuery();
			query += AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.eik = ?";
			return jdbcTemplate.queryForObject(query, new Object[] {eik}, new UserProfileAndPersonalParametersMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	private String getUserProfileAndPersonalParametersQuery() {
		String query = "select";
		query += " " + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.userProfileId";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.userUID";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.identifier";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.names";				
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.status";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.deactivationReason";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.eik";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.nameAndLegalForm";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.qualityOfPhysicalPerson";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.methodOfRepresentation";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.profileType";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.profileStructureType";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.dateCreated";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.dateModified";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.groupId";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.samlResponse";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.customSideNav";	
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfilePersonalParameters.userProfilePersonalParametersId";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfilePersonalParameters.securityLevel";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfilePersonalParameters.consentToUseAddress";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfilePersonalParameters.addressDescription";						
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfilePersonalParameters.mailBox";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfilePersonalParameters.zipCode";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfilePersonalParameters.consentToUsePhone";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfilePersonalParameters.phoneNumber";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfilePersonalParameters.consentToUseEmail";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfilePersonalParameters.email";
		query += "," + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfilePersonalParameters.ekatte";
		query += " from " + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile";			
		query += " left join " + AuthorizationManagerConstants.DB_SCHEMA_NAME  + ".userProfilePersonalParameters on " + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfile.userProfileId = " + AuthorizationManagerConstants.DB_SCHEMA_NAME + ".userProfilePersonalParameters.userProfileId";			
		query += " where ";
		return query;
	}
}
