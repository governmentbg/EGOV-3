package bg.ibs.authorization.manager.portlet.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class Authorizations {
	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long authorizationsId;
	@Column(nullable = false)
	private String rnu;	
	private String rnuCancel;
	@Column(nullable = false)
	private String userId; 
	@Column(nullable = false)
	private String userIdentifier; // encrypted (egovIdentifier) or EIK
	@Column(nullable = false)
	private int userType; // 1 person, 2 legal entity.
	@Column(nullable = false)
	private String userNames;
	@Column(nullable = false)
	private int authorizedType; // 1 person, 2 legal entity.
	@Column(nullable = false)
	private int authorizedIdentifierType; // 1 egn, 2 ln4, EIK.
	@Column(nullable = false)
	private String authorizedIdentifier;
	@Column(nullable = false)
	private String authorizedNames;
	@Column(nullable = false)
	@Temporal(TemporalType.TIMESTAMP)	
	private Date validFrom;
	@Column(nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
    private Date validTo;
	@Column(nullable = false)
	private String systems;
	private byte[] authorizedDocument;
	private String authorizedDocumentName;
	private Integer authorizedDocumentSize;
	private String authorizedDocumentContentType;
	private byte[] cancelDocument;
	private String cancelDocumentName;
	private Integer cancelDocumentSize;
	private String cancelDocumentContentType;
	private String cancelUserId; 
	private String cancelUserNames; 
	@Column(nullable = false)
	private int status;
	private String cancelReason;	
	@Column(nullable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date creationTime;
	@Temporal(TemporalType.TIMESTAMP)
    private Date cancelTime;	
	@Column(nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date operationTime;
	
	public Long getAuthorizationsId() {
		return authorizationsId;
	}
	public void setAuthorizationsId(Long authorizationsId) {
		this.authorizationsId = authorizationsId;
	}
	public String getRnu() {
		return rnu;
	}
	public void setRnu(String rnu) {
		this.rnu = rnu;
	}
	public String getRnuCancel() {
		return rnuCancel;
	}
	public void setRnuCancel(String rnuCancel) {
		this.rnuCancel = rnuCancel;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserIdentifier() {
		return userIdentifier;
	}
	public void setUserIdentifier(String userIdentifier) {
		this.userIdentifier = userIdentifier;
	}
	public int getUserType() {
		return userType;
	}
	public void setUserType(int userType) {
		this.userType = userType;
	}
	public String getUserNames() {
		return userNames;
	}
	public void setUserNames(String userNames) {
		this.userNames = userNames;
	}
	public int getAuthorizedType() {
		return authorizedType;
	}
	public void setAuthorizedType(int authorizedType) {
		this.authorizedType = authorizedType;
	}
	public int getAuthorizedIdentifierType() {
		return authorizedIdentifierType;
	}
	public void setAuthorizedIdentifierType(int authorizedIdentifierType) {
		this.authorizedIdentifierType = authorizedIdentifierType;
	}
	public String getAuthorizedIdentifier() {
		return authorizedIdentifier;
	}
	public void setAuthorizedIdentifier(String authorizedIdentifier) {
		this.authorizedIdentifier = authorizedIdentifier;
	}
	public String getAuthorizedNames() {
		return authorizedNames;
	}
	public void setAuthorizedNames(String authorizedNames) {
		this.authorizedNames = authorizedNames;
	}
	public Date getValidFrom() {
		return validFrom;
	}
	public void setValidFrom(Date validFrom) {
		this.validFrom = validFrom;
	}
	public Date getValidTo() {
		return validTo;
	}
	public void setValidTo(Date validTo) {
		this.validTo = validTo;
	}
	public String getSystems() {
		return systems;
	}
	public void setSystems(String systems) {
		this.systems = systems;
	}
	public byte[] getAuthorizedDocument() {
		return authorizedDocument;
	}
	public void setAuthorizedDocument(byte[] authorizedDocument) {
		this.authorizedDocument = authorizedDocument;
	}
	public String getAuthorizedDocumentName() {
		return authorizedDocumentName;
	}
	public void setAuthorizedDocumentName(String authorizedDocumentName) {
		this.authorizedDocumentName = authorizedDocumentName;
	}
	public Integer getAuthorizedDocumentSize() {
		return authorizedDocumentSize;
	}
	public void setAuthorizedDocumentSize(Integer authorizedDocumentSize) {
		this.authorizedDocumentSize = authorizedDocumentSize;
	}
	public String getAuthorizedDocumentContentType() {
		return authorizedDocumentContentType;
	}
	public void setAuthorizedDocumentContentType(String authorizedDocumentContentType) {
		this.authorizedDocumentContentType = authorizedDocumentContentType;
	}
	public byte[] getCancelDocument() {
		return cancelDocument;
	}
	public void setCancelDocument(byte[] cancelDocument) {
		this.cancelDocument = cancelDocument;
	}
	public String getCancelDocumentName() {
		return cancelDocumentName;
	}
	public void setCancelDocumentName(String cancelDocumentName) {
		this.cancelDocumentName = cancelDocumentName;
	}
	public Integer getCancelDocumentSize() {
		return cancelDocumentSize;
	}
	public void setCancelDocumentSize(Integer cancelDocumentSize) {
		this.cancelDocumentSize = cancelDocumentSize;
	}
	public String getCancelDocumentContentType() {
		return cancelDocumentContentType;
	}
	public void setCancelDocumentContentType(String cancelDocumentContentType) {
		this.cancelDocumentContentType = cancelDocumentContentType;
	}	
	public String getCancelUserId() {
		return cancelUserId;
	}
	public void setCancelUserId(String cancelUserId) {
		this.cancelUserId = cancelUserId;
	}
	public String getCancelUserNames() {
		return cancelUserNames;
	}
	public void setCancelUserNames(String cancelUserNames) {
		this.cancelUserNames = cancelUserNames;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getCancelReason() {
		return cancelReason;
	}
	public void setCancelReason(String cancelReason) {
		this.cancelReason = cancelReason;
	}
	public Date getCreationTime() {
		return creationTime;
	}
	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}
	public Date getCancelTime() {
		return cancelTime;
	}
	public void setCancelTime(Date cancelTime) {
		this.cancelTime = cancelTime;
	}
	public Date getOperationTime() {
		return operationTime;
	}
	public void setOperationTime(Date operationTime) {
		this.operationTime = operationTime;
	}
	
}
