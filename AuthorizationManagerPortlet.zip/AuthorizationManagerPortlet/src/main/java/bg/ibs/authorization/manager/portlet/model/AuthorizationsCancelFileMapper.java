package bg.ibs.authorization.manager.portlet.model;

import java.io.InputStream;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;
import bg.ibs.authorization.manager.portlet.utils.ByteBuffer;

import org.springframework.jdbc.core.RowMapper;

public class AuthorizationsCancelFileMapper implements RowMapper<Authorizations> {

	public Authorizations mapRow(ResultSet resultSet, int i) throws SQLException {

		Authorizations authorization = new Authorizations();
		Blob blob = resultSet.getBlob("cancelDocument");
		if (blob != null) {
			InputStream inputStream = null;
			try {
				inputStream = blob.getBinaryStream(); 
			    ByteBuffer bbuffer = new ByteBuffer();
				int bytesread = 0;
				byte[] tmparr = new byte[1024];
				while (-1 != (bytesread = inputStream.read(tmparr, 0, 1024))) {
					bbuffer.append(tmparr, bytesread);
				}
				authorization.setCancelDocument(bbuffer.getBytes());
				inputStream.close();
			} catch (Exception e) {
				try {
					if (inputStream != null) {
						inputStream.close();
					}
				} catch (Exception e2) {}
				e.printStackTrace();				
			}
			authorization.setCancelDocumentName(resultSet.getString("cancelDocumentName"));
			authorization.setCancelDocumentSize(resultSet.getInt("cancelDocumentSize"));
			authorization.setCancelDocumentContentType(resultSet.getString("cancelDocumentContentType"));
		}
		return authorization;
	}
}
