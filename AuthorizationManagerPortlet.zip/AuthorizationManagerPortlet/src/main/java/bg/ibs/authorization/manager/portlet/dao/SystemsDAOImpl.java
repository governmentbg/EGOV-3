package bg.ibs.authorization.manager.portlet.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import bg.ibs.authorization.manager.portlet.AuthorizationManagerConstants;
import bg.ibs.authorization.manager.portlet.model.Systems;
import bg.ibs.authorization.manager.portlet.model.SystemsMapper;
import bg.ibs.authorization.manager.portlet.utils.AuthorizationManagerLogger;

@Repository("SystemsDAO")
@Transactional
public class SystemsDAOImpl implements SystemsDAO { 
	private static final String TABLE_NAME = "Systems";
	private static final String TABLE_NAME_ACTIONS = "Actions";
	
	JdbcTemplate jdbcTemplate;
	SimpleJdbcInsert simpleJdbcInsert;
	
	@Autowired
	private PlatformTransactionManager transactionManager;
	
	@Autowired
	AuthorizationManagerLogger logger;	

	private final String SQL_FIND_SYSTEM = "select * from " + TABLE_NAME + " where systemsId = ?";
	private final String SQL_FIND_SYSTEM_BY_OID = "select * from " + TABLE_NAME + " where oid = ?";
	private final String SQL_FIND_SYSTEM_BY_OID_EXC_ID = "select * from " + TABLE_NAME + " where oid = ? AND systemsId <> ?";
	private final String SQL_COUNT = "select count(systemsId) from " + TABLE_NAME;
	private final String SQL_GET_ALL = "select * from " + TABLE_NAME;
	private final String SQL_GET_ALL_BY_IDS = "select * from " + TABLE_NAME + " where systemsId in (%s)";

	private final String SQL_UPDATE_SYSTEM = "update " + TABLE_NAME + " set title = ?, oid = ?, operationTime = ? where systemsId = ?";
	private final String SQL_DELETE_SYSTEM = "delete from " + TABLE_NAME + " where systemsId = ?";
	private final String SQL_DELETE_ACTIONS = "delete from " + TABLE_NAME_ACTIONS + " where systemsId = ?";	

	@Autowired
	public SystemsDAOImpl(@Qualifier("dataSource") DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		simpleJdbcInsert = new SimpleJdbcInsert(dataSource).
				withTableName(TABLE_NAME).
				usingColumns("title", "oid", "operationTime", "userId").
				usingGeneratedKeyColumns("systemsId");
	}

	public Systems getSystemsById(final Long systemsId) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_SYSTEM, new Object[] { systemsId }, new SystemsMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public Systems getSystemsByOID(final String oid) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_SYSTEM_BY_OID, new Object[] { oid }, new SystemsMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public Systems getSystemsByOIDExcId(final String oid, final Long systemsId) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_SYSTEM_BY_OID_EXC_ID, new Object[] { oid, systemsId }, new SystemsMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	public List<Systems> getAllSystems() {
		return jdbcTemplate.query(SQL_GET_ALL + " where 1=1 order by title " + AuthorizationManagerConstants.ORDER_ASC, new SystemsMapper());
	}
	
	public List<Systems> getAllSystemsByIds(List<Long> ids) {
		String inSql = String.join(",", Collections.nCopies(ids.size(), "?"));
		return jdbcTemplate.query(String.format(SQL_GET_ALL_BY_IDS, inSql), ids.toArray() , new SystemsMapper());
	}

	public Integer countSystemsByFilter(final Long id, final String title, final String oid) {
		if (id == null && (title == null || title.trim().length() == 0) && (oid == null || oid.trim().length() == 0)) {
			return jdbcTemplate.queryForObject(SQL_COUNT + " where 1=1", Integer.class);
		}
		// We have filter(s) selected, so apply them.
		String qWhere = "";
		List<Object> filters = new ArrayList<>();
		if (id != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "systemsId = ?";
			filters.add(id);
		}
		if (title != null && title.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += " LOWER(title) LIKE ?";
			filters.add("%" + title.toLowerCase() + "%");
		}
		if (oid != null && oid.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += " oid LIKE ?";
			filters.add("%" + oid + "%");
		}
		
		return jdbcTemplate.queryForObject(SQL_COUNT + qWhere, filters.toArray(new Object[filters.size()]), Integer.class);
	}
	
	public List<Systems> getAllSystemsByFilter(final Long id, final String title, final String oid, final Integer start, final Integer length, final Integer orderColumn, final String order) {
		String qOrder = "";
		if (orderColumn != null) {
			if (AuthorizationManagerConstants.COLUMN_ID == orderColumn) {
				qOrder = " order by systemsId";
			} else if (AuthorizationManagerConstants.COLUMN_SYSTEMS_TITLE == orderColumn) {
				qOrder = " order by title";
			} else if (AuthorizationManagerConstants.COLUMN_SYSTEMS_OID == orderColumn) {
				qOrder = " order by oid";
			} else if (AuthorizationManagerConstants.COLUMN_SYSTEMS_OPERATION_TIME == orderColumn) {
				qOrder = " order by operationTime";
			} else {
				qOrder = " order by title";
			}
		} 
		if (qOrder.trim().length() == 0) {
			qOrder = " order by title";
		}
		qOrder += " " + (AuthorizationManagerConstants.ORDER_DESC.equalsIgnoreCase(order) ? AuthorizationManagerConstants.ORDER_DESC : AuthorizationManagerConstants.ORDER_ASC);
		
		qOrder += " limit " + start + ", " + length;
		
		if (id == null && (title == null || title.trim().length() == 0) && (oid == null || oid.trim().length() == 0)) {
			return jdbcTemplate.query(SQL_GET_ALL + " where 1=1" +  qOrder, new SystemsMapper());
		}
		// We have filter(s) selected, so apply them.
		String qWhere = "";
		List<Object> filters = new ArrayList<>();
		if (id != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "systemsId = ?";
			filters.add(id);
		}
		if (title != null && title.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += " LOWER(title) LIKE ?";
			filters.add("%" + title.toLowerCase() + "%");
		}
		if (oid != null && oid.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += " oid LIKE ?";
			filters.add("%" + oid + "%");
		}
		return jdbcTemplate.query(SQL_GET_ALL + qWhere + qOrder, filters.toArray(new Object[filters.size()]), new SystemsMapper());
	}
	
	public Systems createSystems(Systems system) {
		Map<String, Object> parameters = new HashMap<String, Object>();
	    parameters.put("title", system.getTitle());
	    parameters.put("oid", system.getOid());	    
	    parameters.put("operationTime", system.getOperationTime());
	    parameters.put("userId", system.getUserId());
		Long id = simpleJdbcInsert.executeAndReturnKey(parameters).longValue();
		logger.message("Generated id - " + id);
		system.setSystemsId(id);
		return system;
	}
	
	public boolean updateSystems(Systems system) {
		return jdbcTemplate.update(SQL_UPDATE_SYSTEM, system.getTitle(), system.getOid(), system.getOperationTime(), system.getSystemsId()) > 0;
	}

	
	public boolean deleteSystems(Systems system) {
		TransactionDefinition def = new DefaultTransactionDefinition();
	    TransactionStatus status = transactionManager.getTransaction(def);
	    int update = -1;
	    try {
			// Delete all actions for this system.
			jdbcTemplate.update(SQL_DELETE_ACTIONS, system.getSystemsId());
			// Delete the system.
			update = jdbcTemplate.update(SQL_DELETE_SYSTEM, system.getSystemsId());
			transactionManager.commit(status);
			return update > 0;						
		} catch (Exception e) {
			e.printStackTrace();
			transactionManager.rollback(status);
		}
	    return false;
	}
	
}
