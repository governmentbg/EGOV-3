package com.ibm.navigation;

import java.io.IOException;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.GenericPortlet;
import javax.portlet.PortletException;
import javax.portlet.PortletMode;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequestDispatcher;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.WindowState;

public class NavigationPortlet extends GenericPortlet {

	private static final PortletMode CUSTOM_CONFIG_MODE = new PortletMode("config");
	private static final PortletMode CUSTOM_EDIT_DEFAULTS_MODE = new PortletMode("edit_defaults");
	public static final String CONFIG_SUBMIT = "ConfigSubmit"; // Action name for submit form
	public static final String CONFIG_CANCEL = "ConfigCancel"; // Action name for submit form
	public static final String EDIT_DEFAULTS_SUBMIT = "EditDefaultsSubmit"; // Action name for submit form
	public static final String EDIT_DEFAULTS_CANCEL = "EditDefaultsCancel"; // Action name for submit form
	public static final String SETTING_PARAMETER_LAYOUT = "wps.layout";
	public static final String SETTING_PARAMETER_MODE = "wps.mode";	
	public static final String PARAMETER_LAYOUT_LIST = "0";
	public static final String PARAMETER_LAYOUT_TABS = "1";
	public static final String PARAMETER_MODE_CHILDREN = "0";
	public static final String PARAMETER_MODE_SIBLINGS = "1";
	
	public void init() throws PortletException{
		super.init();
	}
	
	public void doView(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		response.setContentType(request.getResponseContentType());
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher("/index.jsp");
		rd.include(request,response);		
	}

	public void doEdit(RenderRequest request, RenderResponse response) throws PortletException, IOException {
	}

	protected void doHelp(RenderRequest request, RenderResponse response) throws PortletException, IOException {
	}

	public void processAction(ActionRequest request, ActionResponse response) throws PortletException, java.io.IOException {
		if (request.getParameter(CONFIG_SUBMIT) != null || request.getParameter(EDIT_DEFAULTS_SUBMIT) != null) {		
			String layout = request.getParameter(SETTING_PARAMETER_LAYOUT);
			String mode = request.getParameter(SETTING_PARAMETER_MODE);
			PortletPreferences prefs = request.getPreferences();			
			try {
				prefs.setValue(SETTING_PARAMETER_MODE, mode);
				prefs.setValue(SETTING_PARAMETER_LAYOUT, layout);
				prefs.store();
				response.setPortletMode(PortletMode.VIEW);
				response.setWindowState(WindowState.NORMAL);
			} catch( Exception e ) { 
				e.printStackTrace();
			}
		} else if (request.getParameter(CONFIG_CANCEL) != null || request.getParameter(EDIT_DEFAULTS_CANCEL) != null) {			
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);
		} 
	}

	protected void doCustomConfigure(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		response.setContentType(request.getResponseContentType());
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher("/config.jsp");
		rd.include(request,response);
	}

	protected void doCustomEditDefaults(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		response.setContentType(request.getResponseContentType());
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher("/editDefaults.jsp");
		rd.include(request,response);
	}
	
	protected void doDispatch(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		if (!WindowState.MINIMIZED.equals(request.getWindowState())) {
			PortletMode mode = request.getPortletMode();
			if (CUSTOM_CONFIG_MODE.equals(mode)) {
				doCustomConfigure(request, response);
				return;
			}
			if (CUSTOM_EDIT_DEFAULTS_MODE.equals(mode)) {
				doCustomEditDefaults(request, response);
				return;
			}
		}
		super.doDispatch(request, response);
	}
}
