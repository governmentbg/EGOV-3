package bg.ibs.user.profile.manager.portlet;

public final class UserProfileManagerConstants {
	
	// DB schema name.
	public static final String DB_SCHEMA_NAME = "EGOV";
	// JNDI name.
	public static final String JNDI = "jdbc/egovdbDS";
	// Global administrator user name.
	public static String ADMIN_USER_NAME = "_REPLACED_";
	// Distinguished name for operation(s) executed internally.
	public static final String SYSTEM_USER_DN = "-1";
	
	// Portlet session bean name.
	public static final String SESSION_BEAN = "UserProfileManagerSessionBean";
	
	// Portlet settings parameters.
	public static final String SETTING_PARAMETER_ESB_EVENT_LOGGER_ADDRESS = "esbEventLogAddress";
	public static final String SETTING_PARAMETER_MAIL_SMTP_HOST = "mailSmtpHost";
	public static final String SETTING_PARAMETER_MAIL_FROM_ADDRESS = "mailFromAddress";
	public static final String SETTING_PARAMETER_RESULTS_PER_PAGE = "resultsPerPage";
	public static final String SETTING_PARAMETER_LANGUAGE = "language";
	public static final String SETTING_PARAMETER_DEBUG = "debug";	

	// Supported language codes.
	public static final String LANGUAGE_BG = "bg";
	public static final String LANGUAGE_EN = "en";
	
	public static final int RESULTS_PER_PAGE = 10;
	
	// Profile types.
	public static final int USER_PROFILE_TYPE_PERSONAL = 1;
	public static final int USER_PROFILE_TYPE_LEGAL_ENTITY = 2;
	public static final int USER_PROFILE_TYPE_SERVICE_SUPPLIER = 3;
	public static final int USER_PROFILE_TYPE_LEGAL_ENTITY_AL2 = 4;
	
	// Status codes.
	public static final int USER_PROFILE_STATUS_INACTIVE = 0;
	public static final int USER_PROFILE_STATUS_ACTIVE = 1;	
	// This status is used for profiles created after invitation accepted for LE association.
	public static final int USER_PROFILE_STATUS_NOT_CONFIRMED = 2;		
	public static final int USER_PROFILE_STATUS_BLOCKED = 9;
	
	public static final int CONSENT_YES = 1;
	public static final int CONSENT_NO = 0;
	
	public static final int USER_PROFILE_ROLE_SELECTED = 1;
	public static final int USER_PROFILE_CHANGE_EMAIL_CONFIRMED = 1;
	
	// Profile method of representation.
	public static final int USER_PROFILE_METHOD_OF_REPRESENTATION_SEPARATELY = 1;
	public static final int USER_PROFILE_METHOD_OF_REPRESENTATION_TOGETHER = 2;
	public static final int USER_PROFILE_METHOD_OF_REPRESENTATION_OTHER_WAY = 3;
	
	// Profile request status.
	public static final int USER_PROFILE_REQUEST_STATUS_APPROVED = 1;
	public static final int USER_PROFILE_REQUEST_STATUS_NOT_APPROVED = 2;	
	public static final int USER_PROFILE_REQUEST_STATUS_CANCELED = 9;	

	// Modes.
	public static final int MODE_READ = 0;
	public static final int MODE_EDIT = 1;
	
	// Pages.
	public static final String INDEX_PAGE = "index";
	public static final String REQUEST_PAGE = "request";
	public static final String PROFILE_PAGE = "profile";
	public static final String PROFILE_ACCESS_PAGE = "profileAccess";
	public static final String ADD_PROFILE_REIK_PAGE = "addProfileREIK";
	
	// Tabs.
	public static final int TAB_REQUESTS = 0;
	public static final int TAB_PROFILES = 1;
	public static final int TAB_HS_ROLES = 2;
	// Views.
	public static final int VIEW_HORIZONTAL_SYSTEMS = 1;
	public static final int VIEW_HORIZONTAL_SYSTEM_ROLES = 2;
	

	// Columns.
	public static final int COLUMN_ID = 0;
	
	public static final int COLUMN_REQUEST_PROFILE_NUMBER = 1;
	public static final int COLUMN_REQUEST_PROFILE_TYPE = 3;
	public static final int COLUMN_REQUEST_EIK = 4;
	public static final int COLUMN_REQUEST_NAME_AND_LEGAL_FORM = 5;
	public static final int COLUMN_REQUEST_NAMES = 6;
	public static final int COLUMN_REQUEST_DATE_CREATED = 9;
	public static final int COLUMN_REQUEST_DATE_APPROVED = 10;
	public static final int COLUMN_REQUEST_STATUS = 11;

	public static final int COLUMN_PROFILES_UID = 1;
	public static final int COLUMN_PROFILES_NAMES = 2;
	public static final int COLUMN_PROFILES_NAME_AND_LEGAL_FORM = 3;
	public static final int COLUMN_PROFILES_EIK = 4;
	public static final int COLUMN_PROFILES_TYPE = 5;
	public static final int COLUMN_PROFILES_DATE_CREATED = 7;
	public static final int COLUMN_PROFILES_DATE_MODIFIED = 8;
	public static final int COLUMN_PROFILES_STATUS = 9;
	
	public static final int COLUMN_HS_ROLES_TITLE = 1;
	public static final int COLUMN_HS_ROLES_DATE_CREATED = 3;
	public static final int COLUMN_HS_ROLES_DATE_MODIFIED = 4;
	
	// Order
	public static final String ORDER_ASC = "asc";
	public static final String ORDER_DESC = "desc";
		

	public static final String _EGOV_IDENTIFIER_KEY = "_REPLACED_";
	public static final String _EGOV_IDENTIFIER_IV_KEY = "_REPLACED_";
	
	// LDAP.
	public static final String LDAP_ATTRIBUTE_UID = "_REPLACED_";
	
	// Email.
	public static final String MAIL_SMTP_HOST = "mail";
	public static final String MAIL_FROM_ADDRESS = "feedback.egov@egov.bg";
	
	// ESB.
	public static final String ESB_LOGGING_URL_TEST = "_REPLACED_";
	public static final String ESB_LOGGING_URL = "_REPLACED_";
	
	// AuditLog.
	public static final String EVENT_LOG_PORTAL_APPROVE_PROFILE_REQUEST = "PORTAL_APPROVE_PROFILE_REQUEST";
	public static final String EVENT_LOG_PORTAL_CANCEL_PROFILE_REQUEST = "PORTAL_CANCEL_PROFILE_REQUEST";
	public static final String EVENT_LOG_PORTAL_MODERATOR_EDIT_PROFILE = "PORTAL_MODERATOR_EDIT_PROFILE";
	public static final String EVENT_LOG_PORTAL_MODERATOR_CREATE_LE_PROFILE_REIK = "PORTAL_MODERATOR_CREATE_LE_PROFILE_REIK";
	public static final String EVENT_LOG_PORTAL_MODERATOR_EDIT_PROFILE_ACCESS = "PORTAL_MODERATOR_EDIT_PROFILE_ACCESS";
	
	public static final String PORTAL_OID = "_REPLACED_";
	
	// eJournal.
	public static final String E_JOURNAL_ADDRESS_PROD = "_REPLACED_";
	public static final String E_JOURNAL_ADDRESS_TEST = "_REPLACED_";
	
	public static final String E_JOURNAL_SYSTEM_OID_OWNER = "ЕПДЕАУ";
	public static final int E_JOURNAL_ID_SERVICE_PARAM = 999999;
	
	public static final int E_JOURNAL_STAGE_INITIALIZE = 1;
	public static final int E_JOURNAL_STAGE_PAYMENT = 2;
	public static final int E_JOURNAL_STAGE_DELIVERY = 3;
	public static final int E_JOURNAL_STAGE_PROVISION = 4;
	public static final int E_JOURNAL_STAGE_CANCEL = 5;
	
	public static final int E_JOURNAL_STATUS_LOGIN_OR_CREATE_PE_PROFILE = 1;
	public static final int E_JOURNAL_STATUS_CREATE_LE_PROFILE = 2;
	public static final int E_JOURNAL_STATUS_ASSIGN_PE_PROFILE_TO_LE_PROFILE = 3;
	public static final int E_JOURNAL_STATUS_REMOVE_PE_PROFILE_FROM_LE_PROFILE = 4;
	public static final int E_JOURNAL_STATUS_CREATE_AUTHORIZATION = 5;
	public static final int E_JOURNAL_STATUS_CANCEL_AUTHORIZATION = 6;
	public static final int E_JOURNAL_STATUS_ACCESS_REGIX = 7;
	public static final int E_JOURNAL_STATUS_REQUEST_SERVICE = 8;
	public static final int E_JOURNAL_STATUS_PAYMENT_OF_OBLIGATION = 9;
	public static final int E_JOURNAL_STATUS_SEND_MESSAGE = 10;
	
}
