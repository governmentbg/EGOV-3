package bg.ibs.user.profile.manager.portlet;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.ibs.user.profile.manager.portlet.controllers.PortletViewController;
import bg.ibs.user.profile.manager.portlet.model.UserProfile;
import bg.ibs.user.profile.manager.portlet.model.UserProfilePersonalParameters;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRequest;
import bg.ibs.user.profile.manager.portlet.utils.UserProfileManagerUtils;
import bg.ibs.user.profile.manager.portlet.utils.MailMessage;
import bg.ibs.user.profile.manager.portlet.utils.UserProfileManagerLogger;

@Component
public class UserProfileNotificationManager {
	
	@Autowired
	UserProfileManagerUtils utils;
	@Autowired
	UserProfileManagerLogger logger;
	
	public boolean notifyUserForRequestLEProfileApproval(UserProfileRequest userProfileRequest, UserProfile personalProfile, UserProfilePersonalParameters personalParameters, UserProfile newLEProfile) throws Exception {
		if (personalParameters != null) {
			// Notify by email.
			String email = personalParameters.getEmail();
			if (email != null && email.trim().length() > 0) {
				String subject = "Вашата заявка за добавяне на профил на '" + userProfileRequest.getNameAndLegalForm() + "' беше одобрена.";
				String body = emailBodyRequestLEProfileApproval(userProfileRequest, newLEProfile.getDateCreated());
				try {
					if (MailMessage.sendEmail(PortletViewController.fromAddress, email, null, subject, body, PortletViewController.isDebug)) {
						logger.message("Mail send successfully to " + email + "!");
						return true;
					}
				} catch (Exception e) {
					e.printStackTrace();
					throw new Exception("Неуспешно изпращане на е-поща до " + email);					
				}
			}
		}
		return false;
	}
	
	public boolean notifyUserForRequestLEProfileCancel(UserProfileRequest userProfileRequest, UserProfile personalProfile, UserProfilePersonalParameters personalParameters, Date dateCancel, String cancelReason) throws Exception {
		if (personalParameters != null) {
			// Notify by email.
			String email = personalParameters.getEmail();
			if (email != null && email.trim().length() > 0) {
				String subject = "Вашата заявка за добавяне на профил на '" + userProfileRequest.getNameAndLegalForm() + "' беше отказана.";
				String body = emailBodyRequestLEProfileCancel(userProfileRequest, dateCancel, cancelReason);
				try {
					if (MailMessage.sendEmail(PortletViewController.fromAddress, email, null, subject, body, PortletViewController.isDebug)) {
						logger.message("Mail send successfully to " + email + "!");
						return true;
					}
				} catch (Exception e) {
					e.printStackTrace();
					throw new Exception("Неуспешно изпращане на е-поща до " + email);					
				}
			}
		}
		return false;
	}
	
	public boolean notifyNewlyAdmininistratorUserForCreateLEProfileWithREIK(UserProfile newLEProfile, UserProfilePersonalParameters personalParameters) throws Exception {
		if (personalParameters != null) {
			// Notify by email.
			String email = personalParameters.getEmail();
			if (email != null && email.trim().length() > 0) {
				String subject = "Усшено сте асоцииран като администратор за профил на ЮЛ '" + newLEProfile.getNameAndLegalForm() + "' (" + newLEProfile.getEik() + ").";
				String body = emailBodyAddLEProfileWithREIK(newLEProfile);
				try {
					if (MailMessage.sendEmail(PortletViewController.fromAddress, email, null, subject, body, PortletViewController.isDebug)) {
						logger.message("Mail send successfully to " + email + "!");
						return true;
					}
				} catch (Exception e) {
					e.printStackTrace();
					throw new Exception("Неуспешно изпращане на е-поща до " + email);					
				}
			}
		}
		return false;
	}


	
	private String emailBodyRequestLEProfileApproval(UserProfileRequest userProfileRequest, Date dateCreated) {
		String html = "";
		html += "<div>"
				+ "<h1>EGOV.BG</h1>"
				+ "<div><p style=\"font-size:16px;\">" + "Вашата заявка за добавяне на профил на '" + userProfileRequest.getNameAndLegalForm() + "' беше <strong>одобрена</strong>." + "</p></div>"
				+ "<div><p style=\"font-size:16px;\">Моля, влезте в \"Моето пространство\" за да оперирате с новия профил.</p></div>"
				+ "<div>Дата на одобряване:</div><div><strong>" + utils.dateToDD_MM_YYYY_HH_MM_SS(dateCreated) + "</strong></div><br/>"
				+ "</div>"
				+ "<br/>"
				+ "<br/>"
				+ "<div style=\"font-style: italic;color:#888;\">Моля не отговаряйте, автоматично съобщение.</div>";
		return html;
	}
	
	private String emailBodyRequestLEProfileCancel(UserProfileRequest userProfileRequest, Date dateCancel, String cancelReason) {
		String html = "";
		html += "<div>"
				+ "<h1>EGOV.BG</h1>"
				+ "<div><p>" + "Вашата заявка за добавяне на профил на '" + userProfileRequest.getNameAndLegalForm() + "' беше <strong>отказана</strong>." + "</p></div>";
		if (cancelReason != null && cancelReason.trim().length() > 0) {
			html += "<div>Причина:</div><div><strong>" + cancelReason + "</strong></div><br/>";
		}
		  html += "<div>Дата на отказ:</div><div><strong>" + utils.dateToDD_MM_YYYY_HH_MM_SS(dateCancel) + "</strong></div><br/>"			
			+ "</div>"
			+ "<br/>"
			+ "<br/>"
			+ "<div style=\"font-style: italic;color:#888;\">Моля не отговаряйте, автоматично съобщение.</div>";
		return html;
	}
	
	private String emailBodyAddLEProfileWithREIK(UserProfile userProfile) {
		String html = "";
		html += "<div>"
				+ "<h1>EGOV.BG</h1>"
				+ "<div><p>" + "Успешно сте асоцииран като администратор на ЮЛ '" + userProfile.getNameAndLegalForm() + "'." + "</p></div>"
				+ "<div><p>Моля, влезте в \"Моето пространство\" за да оперирате с новия профил.</p></div>"
				+ "<div>Дата на одобряване:</div><div><strong>" + utils.dateToDD_MM_YYYY_HH_MM_SS(userProfile.getDateCreated()) + "</strong></div><br/>"
				+ "</div>"
				+ "<br/>"
				+ "<br/>"
				+ "<div style=\"font-style: italic;color:#888;\">Моля не отговаряйте, автоматично съобщение.</div>";
		return html;
	}

	
}
