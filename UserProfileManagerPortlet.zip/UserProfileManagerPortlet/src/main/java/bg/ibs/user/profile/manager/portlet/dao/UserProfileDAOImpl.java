package bg.ibs.user.profile.manager.portlet.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import bg.ibs.user.profile.manager.portlet.UserProfileManagerConstants;
import bg.ibs.user.profile.manager.portlet.model.UserProfile;
import bg.ibs.user.profile.manager.portlet.model.UserProfileAndRole;
import bg.ibs.user.profile.manager.portlet.model.UserProfileAndRoleMapper;
import bg.ibs.user.profile.manager.portlet.model.UserProfileMapper;
import bg.ibs.user.profile.manager.portlet.model.UserProfilePersonalParameters;
import bg.ibs.user.profile.manager.portlet.model.UserProfilePersonalParametersMapper;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRef;
import bg.ibs.user.profile.manager.portlet.utils.UserProfileManagerLogger;
import bg.ibs.user.profile.manager.portlet.utils.UserProfileManagerUtils;

@Repository("UserProfileDAO")
@Transactional
public class UserProfileDAOImpl implements UserProfileDAO { 
	private static final String TABLE_NAME = "UserProfile";	
	private static final String TABLE_USER_PROFILE_ROLE_NAME = "UserProfileRole";
	private static final String TABLE_USER_PROFILE_PERSONAL_PARAMETERS_NAME = "UserProfilePersonalParameters";
	private static final String TABLE_USER_PROFILE_REF_NAME = "UserProfileRef";
	private static final String USER_PROFILE_SEQUENCE_NAME = "SEQ_USERPROFILE";
	private static final String USER_PROFILE_ROLE_SEQUENCE_NAME = "SEQ_USERPROFILEROLE";
	private static final String USER_PROFILE_REF_SEQUENCE_NAME = "SEQ_USERPROFILEREF";
	
	JdbcTemplate jdbcTemplate;
	SimpleJdbcInsert simpleJdbcInsert;
	
	@Autowired
	private PlatformTransactionManager transactionManager;
	
	@Autowired
	UserProfileManagerUtils utils;
	@Autowired
	UserProfileManagerLogger logger; 

	private final String SQL_FIND_PROFILE = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userProfileId = ?";
	private final String SQL_FIND_PROFILE_BY_UID_AND_TYPE = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userUid = ? and profileType = ?";
	private final String SQL_FIND_PROFILE_BY_IDENTIFIER_AND_TYPE = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where identifier = ? and profileType = ?";
	private final String SQL_FIND_PROFILE_BY_EIK = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where eik = ?";
	private final String SQL_FIND_PROFILE_BY_UIDS_AND_TYPE = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userUid in (%s) and profileType = ?";
	private final String SQL_FIND_PERSONAL_PARAMETERS_BY_USER_PROFILEID = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_PERSONAL_PARAMETERS_NAME + " where userProfileId = ?";
	private final String SQL_COUNT = "select count(userProfileId) from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME;
	private final String SQL_GET_ALL = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME;
	private final String SQL_GET_ALL_BY_IDS = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userProfileId in (%s)";
	private final String SQL_SELECT_USER_PROFILE_SEQUENCE_NEXT_VAL = "select next value for " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + USER_PROFILE_SEQUENCE_NAME + " from SYSIBM.SYSDUMMY1";
	private final String SQL_SELECT_USER_PROFILE_ROLE_SEQUENCE_NEXT_VAL = "select next value for " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + USER_PROFILE_ROLE_SEQUENCE_NAME + " from SYSIBM.SYSDUMMY1";
	private final String SQL_SELECT_USER_PROFILE_REF_SEQUENCE_NEXT_VAL = "select next value for " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + USER_PROFILE_REF_SEQUENCE_NAME + " from SYSIBM.SYSDUMMY1";
	private final String SQL_SELECT_LEGAL_ENTITY_REIK_9_NEXT_VAL = "select count(*) from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where eik like ? and not length(eik)=13";
	private final String SQL_SELECT_LEGAL_ENTITY_REIK_13_NEXT_VAL = "select count(*) from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where eik like ?";
	private final String SQL_CREATE_USER_PROFILE = "insert into " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " (userProfileId, userUID, identifier, identifierPrefix, names, eik, nameAndLegalForm, profileType, profileStructureType, dateCreated, dateModified, groupId, status) values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
	private final String SQL_CREATE_USER_PROFILE_ROLE = "insert into " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_ROLE_NAME + " (userProfileRoleId, userProfileId, userUID, admin, editor, serviceManager, userRole, dateCreated, email, confirm) values (?,?,?,?,?,?,?,?,?,?)";
	private final String SQL_CREATE_USER_PROFILE_REF = "insert into " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_REF_NAME + " (userProfileRefId, userProfileId, reik, eik, parentUserProfileId, parentUserProfileIds) values (?,?,?,?,?,?)";
	private final String SQL_UPDATE_USER_PROFILE = "update " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " set profileType = ?, profileStructureType = ?, status = ?, dateModified = ? where userProfileId = ?";
	//private final String SQL_UPDATE_USER_PROFILE_EIK = "update " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " set eik = ? where userProfileId = ?";
	private final String SQL_DELETE_USER_PROFILE = "delete from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userProfileId = ?";

	@Autowired
	public UserProfileDAOImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		simpleJdbcInsert = new SimpleJdbcInsert(dataSource).
				withSchemaName(UserProfileManagerConstants.DB_SCHEMA_NAME).
				withTableName(TABLE_NAME).
				usingColumns(
						"userProfileId", 
						"userUID", 
						"identifier", 
						"names", 
						"status", 
						"deactivationReason", 
						"eik", 
						"nameAndLegalForm", 
						"qualityOfPhysicalPerson", 
						"methodOfRepresentation", 
						"profileType", 
						"profileStructureType", 
						"status", 
						"dateCreated", 
						"dateModified", 
						"groupId", 
						"samlResponse", 
						"customSideNav",
						"identifierPrefix");
	}

	public UserProfile getUserProfileById(final Long userProfileId) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_PROFILE, new Object[] { userProfileId }, new UserProfileMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public UserProfile getUserProfileByUserUidAndProfileType(final String userUid, final Integer profileType) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_PROFILE_BY_UID_AND_TYPE, new Object[] { userUid, profileType }, new UserProfileMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public UserProfile getUserProfileByIdentifierAndProfileType(final String identifier, final Integer profileType) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_PROFILE_BY_IDENTIFIER_AND_TYPE, new Object[] { identifier, profileType }, new UserProfileMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public UserProfile getUserProfileByEik(final String eik) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_PROFILE_BY_EIK, new Object[] { eik }, new UserProfileMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public List<UserProfile> getUserProfileByUserUidsAndProfileType(final List<String> userUids, final Integer profileType) {
		String inSql = String.join(",", Collections.nCopies(userUids.size(), "?"));
		Object[] objArr = new Object[userUids.size() + 1];		
		for (int i = 0; i < userUids.size(); i++) {
			objArr[i] = userUids.get(i);
		}
		objArr[userUids.size()] = profileType;
		return jdbcTemplate.query(String.format(SQL_FIND_PROFILE_BY_UIDS_AND_TYPE, inSql), objArr, new UserProfileMapper());
	}
	
	public List<UserProfile> getAllUserProfiles() {
		return jdbcTemplate.query(SQL_GET_ALL + " where 1=1 order by userProfileId " + UserProfileManagerConstants.ORDER_DESC, new UserProfileMapper());
	}
	
	public List<UserProfile> getAllUserProfilesByIds(List<Long> userProfileIds) {
		String inSql = String.join(",", Collections.nCopies(userProfileIds.size(), "?"));	
		return jdbcTemplate.query(String.format(SQL_GET_ALL_BY_IDS, inSql), userProfileIds.toArray(), new UserProfileMapper());
	}
	
	public Integer countUserProfilesByFilter(final Long id, final Integer profileType, final Integer profileStructureType, final String userUID, final String name, final String dateFrom, final String dateTo, final Integer status) {
		if (id == null 
				&& profileType == null 
				&& profileStructureType == null 
				&& (userUID == null || userUID.trim().length() == 0) 
				&& (name == null || name.trim().length() == 0) 
				&& (dateFrom == null || dateFrom.trim().length() == 0) 
				&& (dateTo == null || dateTo.trim().length() == 0) 
				&& status == null) {
			return jdbcTemplate.queryForObject(SQL_COUNT + " where 1=1", Integer.class);
		}
		// We have filter(s) selected, so apply them.
		String qWhere = "";
		List<Object> filters = new ArrayList<>();
		if (id != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "userProfileId = ?";
			filters.add(id);
		}
		if (profileType != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "profileType = ?";
			filters.add(profileType);
		}
		if (profileStructureType != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "profileStructureType LIKE ?";
			filters.add("%^" + profileStructureType + "^%");
		}
		if (userUID != null && userUID.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "userUID = ?";
			filters.add(userUID);
		}
		if (name != null && name.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "(LOWER(nameAndLegalForm) LIKE ?";
			filters.add("%" + name.toLowerCase() + "%");
			qWhere += " OR LOWER(names) LIKE ?)";
			filters.add("%" + name.toLowerCase() + "%");
		}		
		if (dateFrom != null) {
			
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "dateCreated >= ?";
			filters.add(dateFrom);
		}
		if (dateTo != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "dateCreated <= ?";
			filters.add(dateTo);
		}
		if (status != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "status = ?";
			filters.add(status);
		}
		return jdbcTemplate.queryForObject(SQL_COUNT + qWhere, filters.toArray(new Object[filters.size()]), Integer.class);
	}
	
	public List<UserProfile> getAllUserProfilesByFilter(final Long id, final Integer profileType, final Integer profileStructureType, final String userUID, final String name, final String dateFrom, final String dateTo, final Integer status, final Integer start, final Integer length, final Integer orderColumn, final String order) {
		String qOrder = "";
		if (orderColumn != null) {
			if (UserProfileManagerConstants.COLUMN_ID == orderColumn) {
				qOrder = " order by userProfileId";
			} else if (UserProfileManagerConstants.COLUMN_PROFILES_UID == orderColumn) {
				qOrder = " order by userUID";
			} else if (UserProfileManagerConstants.COLUMN_PROFILES_NAMES == orderColumn) {
				qOrder = " order by names";
			} else if (UserProfileManagerConstants.COLUMN_PROFILES_NAME_AND_LEGAL_FORM == orderColumn) {
				qOrder = " order by nameAndLegalForm";
			} else if (UserProfileManagerConstants.COLUMN_PROFILES_EIK == orderColumn) {
				qOrder = " order by eik";
			} else if (UserProfileManagerConstants.COLUMN_PROFILES_TYPE == orderColumn) {
				qOrder = " order by profileType";
			} else if (UserProfileManagerConstants.COLUMN_PROFILES_DATE_CREATED == orderColumn) {
				qOrder = " order by dateCreated";
			} else if (UserProfileManagerConstants.COLUMN_PROFILES_DATE_MODIFIED == orderColumn) {
				qOrder = " order by dateModified";
			} else if (UserProfileManagerConstants.COLUMN_PROFILES_STATUS == orderColumn) {
				qOrder = " order by status";
			} else {
				qOrder = " order by userProfileId";
			}
		} 
		if (qOrder.trim().length() == 0) {
			qOrder = " order by userProfileId";
		}
		qOrder += " " + (UserProfileManagerConstants.ORDER_ASC.equalsIgnoreCase(order) ? UserProfileManagerConstants.ORDER_ASC : UserProfileManagerConstants.ORDER_DESC);
		
		// NOT SUPPORTED BY DB2, so we are doing workaround.
		//qOrder += " LIMIT " + start + ", " + length;				
		qOrder += " FETCH FIRST " + (start + length) + " ROWS ONLY";
		
		if (id == null 
				&& profileType == null 
				&& profileStructureType == null 
				&& (userUID == null || userUID.trim().length() == 0) 
				&& (name == null || name.trim().length() == 0) 
				&& (dateFrom == null || dateFrom.trim().length() == 0) 
				&& (dateTo == null || dateTo.trim().length() == 0) 
				&& status == null) {
			logger.message("getAllUserProfilesByFilter SQL_GET_ALL");
			return jdbcTemplate.query(SQL_GET_ALL + " where 1=1" +  qOrder, new UserProfileMapper());
		}
		// We have filter(s) selected, so apply them.
		String qWhere = "";
		List<Object> filters = new ArrayList<>();
		if (id != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "userProfileId = ?";
			filters.add(id);
		}
		if (profileType != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "profileType = ?";
			filters.add(profileType);
		}
		if (profileStructureType != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "profileStructureType LIKE ?";
			filters.add("%^" + profileStructureType + "^%");
		}
		if (userUID != null && userUID.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "userUID = ?";
			filters.add(userUID);
		}
		if (name != null && name.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "(LOWER(nameAndLegalForm) LIKE ?";
			filters.add("%" + name.toLowerCase() + "%");
			qWhere += " OR LOWER(names) LIKE ?)";
			filters.add("%" + name.toLowerCase() + "%");
		}
		if (dateFrom != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "dateCreated >= ?";
			filters.add(dateFrom);
		}
		if (dateTo != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "dateCreated <= ?";
			filters.add(dateTo);
		}
		if (status != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "status = ?";
			filters.add(status);
		}
		return jdbcTemplate.query(SQL_GET_ALL + qWhere + qOrder, filters.toArray(new Object[filters.size()]), new UserProfileMapper());
	}

	public UserProfile createUserProfile(UserProfile userProfile) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("userProfileId", getNextVal());
		parameters.put("userUID", userProfile.getUserUID());
		parameters.put("identifier", userProfile.getIdentifier());
	    parameters.put("names", userProfile.getNames());
	    parameters.put("status", userProfile.getStatus());
	    parameters.put("deactivationReason", userProfile.getDeactivationReason());	    
	    parameters.put("eik", userProfile.getEik());
	    parameters.put("nameAndLegalForm", userProfile.getNameAndLegalForm());
	    parameters.put("qualityOfPhysicalPerson", userProfile.getQualityOfPhysicalPerson());
	    parameters.put("methodOfRepresentation", userProfile.getMethodOfRepresentation());
	    parameters.put("profileType", userProfile.getProfileType());
	    parameters.put("profileStructureType", userProfile.getProfileStructureType());
	    parameters.put("dateCreated", userProfile.getDateCreated());
	    parameters.put("dateModified", userProfile.getDateModified());
	    parameters.put("groupId", userProfile.getGroupId());
	    parameters.put("samlResponse", userProfile.getSamlResponse());
	    parameters.put("customSideNav", userProfile.getCustomSideNav());
	    parameters.put("identifierPrefix", userProfile.getIdentifierPrefix());
		Long id = simpleJdbcInsert.executeAndReturnKey(parameters).longValue();
		logger.message("Generated id - " + id);
		userProfile.setUserProfileId(id);
		return userProfile;
//		return jdbcTemplate.update(SQL_INSERT_GROUP, registerGroup.getName(), registerGroup.getLabel(), registerGroup.getProfileType(),
//				registerGroup.getWeight(), registerGroup.getStatus(), registerGroup.getDateCreated(), 
//				registerGroup.getDateModified(), registerGroup.getUserId()) > 0;
	}
	
	private synchronized Long getNextVal() {		
		return jdbcTemplate.queryForObject(SQL_SELECT_USER_PROFILE_SEQUENCE_NEXT_VAL + " where 1=1", Long.class);
	} // getNextVal
	
	public boolean updateUserProfile(UserProfile userProfile) {
		return jdbcTemplate.update(SQL_UPDATE_USER_PROFILE, 
				userProfile.getProfileType(), 
				userProfile.getProfileStructureType(), 
				userProfile.getStatus(), 
				userProfile.getDateModified(),
				userProfile.getUserProfileId()) > 0;
	}
	
	public boolean deleteUserProfile(UserProfile userProfile) {
		return jdbcTemplate.update(SQL_DELETE_USER_PROFILE, userProfile.getUserProfileId()) > 0;
	} 
	
	public List<UserProfileAndRole> getUserProfileAndRolesByProfileId(final Long userProfileId) {
		String query = getUserProfileAndRoleQuery();
		query += UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfile.userProfileId = ?";
		return jdbcTemplate.query(query, new Object[] {userProfileId}, new UserProfileAndRoleMapper());
	}

	private String getUserProfileAndRoleQuery() {
		String query = "select";
		query += " " + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfile.userProfileId";
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfile.identifier";
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfile.names";				
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfile.status";
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfile.deactivationReason";
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfile.eik";
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfile.nameAndLegalForm";
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfile.qualityOfPhysicalPerson";
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfile.methodOfRepresentation";
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfile.profileType";
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfile.profileStructureType";
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfile.dateCreated";
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfile.dateModified";
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfile.groupId";
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfile.samlResponse";
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfile.customSideNav";	
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfile.identifierPrefix";	
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfileRole.userProfileRoleId";
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfileRole.userUID";
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfileRole.admin";
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfileRole.editor";
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfileRole.serviceManager";						
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfileRole.userRole";
		query += "," + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfileRole.email";
		query += " from " + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfile";			
		query += " left join " + UserProfileManagerConstants.DB_SCHEMA_NAME  + ".userProfileRole on " + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfile.userProfileId = " + UserProfileManagerConstants.DB_SCHEMA_NAME + ".userProfileRole.userProfileId";			
		query += " where ";
		return query;
	}
	
	private synchronized Long getUserProfleRoleSequenceNextVal() {		
		return jdbcTemplate.queryForObject(SQL_SELECT_USER_PROFILE_ROLE_SEQUENCE_NEXT_VAL + " where 1=1", Long.class);
	} // getNextVal

	private synchronized Long getUserProfleRefSequenceNextVal() {		
		return jdbcTemplate.queryForObject(SQL_SELECT_USER_PROFILE_REF_SEQUENCE_NEXT_VAL + " where 1=1", Long.class);
	} // getNextVal

	private synchronized Long getLEREIKNextVal(String eik) {
		Object[] values = new Object[1];
		values[0] = eik + "%";		
		return jdbcTemplate.queryForObject(eik.length() == 13 ? SQL_SELECT_LEGAL_ENTITY_REIK_13_NEXT_VAL : SQL_SELECT_LEGAL_ENTITY_REIK_9_NEXT_VAL, values, Long.class);		
	} // getNextVal
	
	public UserProfilePersonalParameters getUserProfilePersonalParameters(final Long userProfileId) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_PERSONAL_PARAMETERS_BY_USER_PROFILEID, new Object[] { userProfileId }, new UserProfilePersonalParametersMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	public UserProfile createLEUserProfileWithREIK(UserProfile leUserProfile, UserProfile adminUserProfile, String title, String profileStructureType) {
		Date currentDate = new Date();
		TransactionDefinition def = new DefaultTransactionDefinition();
	    TransactionStatus status = transactionManager.getTransaction(def);
		
	    try {
	    	// We generate the REIK sequence, before the new profile was added to the DB!
	    	Long reikSeq = getLEREIKNextVal(leUserProfile.getEik());
	    	String reik = utils.generateREIK(leUserProfile.getEik(), String.valueOf(reikSeq));
			// Populate userProfile object to create the corresponding profile.			
			UserProfile userProfile = new UserProfile();				
			Long userProfileId = getNextVal();
			userProfile.setUserProfileId(userProfileId);	
			userProfile.setUserUID(adminUserProfile.getUserUID());
			userProfile.setIdentifier(adminUserProfile.getIdentifier());
			userProfile.setIdentifierPrefix(adminUserProfile.getIdentifierPrefix());
			userProfile.setNames(adminUserProfile.getNames());
			userProfile.setEik(reik);
			userProfile.setNameAndLegalForm(title);
			userProfile.setProfileType(leUserProfile.getProfileType());
			userProfile.setProfileStructureType(profileStructureType);					
			userProfile.setDateCreated(currentDate);
			userProfile.setDateModified(currentDate);
			userProfile.setStatus(UserProfileManagerConstants.USER_PROFILE_STATUS_ACTIVE);					
			jdbcTemplate.update(SQL_CREATE_USER_PROFILE, new Object[] { 
					userProfile.getUserProfileId(),
					userProfile.getUserUID(),
					userProfile.getIdentifier(),
					userProfile.getIdentifierPrefix(),
					userProfile.getNames(),
					userProfile.getEik(),
					userProfile.getNameAndLegalForm(),
					userProfile.getProfileType(),
					userProfile.getProfileStructureType(),
					userProfile.getDateCreated(),
					userProfile.getDateModified(),
					userProfile.getGroupId(),
					userProfile.getStatus() 					
			});				
			logger.message("Generated userProfileId - " + userProfileId);
			Long userProfileRefId = getUserProfleRefSequenceNextVal();
			
			UserProfileRef userProfileRef = new UserProfileRef();
			userProfileRef.setUserProfileRefId(userProfileRefId);
			userProfileRef.setUserProfileId(userProfileId); 
			userProfileRef.setReik(reik);
			userProfileRef.setEik(leUserProfile.getEik());
			userProfileRef.setParentUserProfileId(leUserProfile.getUserProfileId());
			// TODO load from userProfileRef table the record for the parent, to build the whole tree.
			userProfileRef.setParentUserProfileIds(String.valueOf(leUserProfile.getUserProfileId()));
			jdbcTemplate.update(SQL_CREATE_USER_PROFILE_REF, new Object[] { 
					userProfileRef.getUserProfileRefId(),
					userProfileRef.getUserProfileId(),
					userProfileRef.getReik(),
					userProfileRef.getEik(),
					userProfileRef.getParentUserProfileId(),
					userProfileRef.getParentUserProfileIds() 					
			});
			logger.message("Generated userProfileRefId - " + userProfileRefId);
			// Update user profile's EIK with the generated REIK.
//			userProfile.setEik(reik);
//			jdbcTemplate.update(
//					SQL_UPDATE_USER_PROFILE_EIK,
//					userProfile.getEik(),
//					userProfileId);						
				
			Long userProfileRoleId = getUserProfleRoleSequenceNextVal();
			Integer editor = null;
			Integer serviceManager = null;
			if (UserProfileManagerConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER == leUserProfile.getProfileType()) {
				editor = UserProfileManagerConstants.USER_PROFILE_ROLE_SELECTED;
				serviceManager = UserProfileManagerConstants.USER_PROFILE_ROLE_SELECTED;
			}
			UserProfilePersonalParameters personalParameters = getUserProfilePersonalParameters(adminUserProfile.getUserProfileId());
			String email = personalParameters != null ? personalParameters.getEmail() : null;
			jdbcTemplate.update(SQL_CREATE_USER_PROFILE_ROLE, new Object[] { 
					userProfileRoleId,
					userProfile.getUserProfileId(),
					adminUserProfile.getUserUID(),
					UserProfileManagerConstants.USER_PROFILE_ROLE_SELECTED,
					editor,
					serviceManager,
					UserProfileManagerConstants.USER_PROFILE_ROLE_SELECTED,
					currentDate,
					email,
					UserProfileManagerConstants.USER_PROFILE_CHANGE_EMAIL_CONFIRMED
			});	
			transactionManager.commit(status);
			return userProfile;
		} catch (Exception e) {
			e.printStackTrace();
			transactionManager.rollback(status);
		}
		return null;
	}
}
