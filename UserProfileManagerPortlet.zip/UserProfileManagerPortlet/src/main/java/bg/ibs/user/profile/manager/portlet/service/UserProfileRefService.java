package bg.ibs.user.profile.manager.portlet.service;

import java.util.List;

import bg.ibs.user.profile.manager.portlet.model.UserProfileRef;

public interface UserProfileRefService {
	UserProfileRef getById(Long id);
	UserProfileRef getByUserProfileId(Long userProfileId);
	List<UserProfileRef> getAllByParentUserProfileId(Long userProfileId);	
}
