package bg.ibs.user.profile.manager.portlet.dao;

import java.util.List;

import bg.ibs.user.profile.manager.portlet.model.UserProfile;
import bg.ibs.user.profile.manager.portlet.model.UserProfileAndRole;

public interface UserProfileDAO {	
	UserProfile getUserProfileById(Long id);	
	UserProfile getUserProfileByUserUidAndProfileType(String userUid, Integer profileType);
	UserProfile getUserProfileByIdentifierAndProfileType(String identifier, Integer profileType);
	UserProfile getUserProfileByEik(String eik);
	List<UserProfile> getUserProfileByUserUidsAndProfileType(List<String> userUids, Integer profileType);
	List<UserProfile> getAllUserProfiles();
	List<UserProfile> getAllUserProfilesByIds(List<Long> userProfileIds);
	Integer countUserProfilesByFilter(Long id, Integer profileType, Integer profileStructureType, String userUID, String name, String dateFrom, String dateTo, Integer status);
	List<UserProfile> getAllUserProfilesByFilter(Long id, Integer profileType, Integer profileStructureType, String userUID, String name, String dateFrom, String dateTo, Integer status, Integer start, Integer length, Integer orderColumn, String order);		
	UserProfile createUserProfile(UserProfile UserProfile);
	UserProfile createLEUserProfileWithREIK(UserProfile leUserProfile, UserProfile adminUserProfile, String title, String profileStructureType);
	boolean updateUserProfile(UserProfile UserProfile);
	boolean deleteUserProfile(UserProfile userProfile);
	List<UserProfileAndRole> getUserProfileAndRolesByProfileId(Long profileId);
}
