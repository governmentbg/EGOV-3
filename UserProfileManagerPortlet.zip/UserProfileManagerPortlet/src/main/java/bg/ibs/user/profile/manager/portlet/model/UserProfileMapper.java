package bg.ibs.user.profile.manager.portlet.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class UserProfileMapper implements RowMapper<UserProfile> {

	public UserProfile mapRow(ResultSet resultSet, int i) throws SQLException {

		UserProfile profile = new UserProfile();
		profile.setUserProfileId(resultSet.getLong("userProfileId"));
		profile.setUserUID(resultSet.getString("userUID"));
		profile.setIdentifier(resultSet.getString("identifier"));
		profile.setNames(resultSet.getString("names"));
		profile.setStatus(resultSet.getInt("status"));
		profile.setDeactivationReason(resultSet.getString("deactivationReason"));
		profile.setEik(resultSet.getString("eik"));
		profile.setNameAndLegalForm(resultSet.getString("nameAndLegalForm"));
		profile.setQualityOfPhysicalPerson(resultSet.getString("qualityOfPhysicalPerson"));
		profile.setMethodOfRepresentation(resultSet.getString("methodOfRepresentation"));
		profile.setProfileType(resultSet.getInt("profileType"));
		profile.setProfileStructureType(resultSet.getString("profileStructureType"));
		profile.setDateCreated(resultSet.getDate("dateCreated"));
		profile.setDateModified(resultSet.getDate("dateModified"));
		profile.setGroupId(resultSet.getString("groupId"));
		profile.setSamlResponse(resultSet.getString("samlResponse"));
		profile.setCustomSideNav(resultSet.getString("customSideNav"));
		profile.setIdentifierPrefix(resultSet.getString("identifierPrefix"));
		return profile;
	}
}
