package bg.ibs.user.profile.manager.portlet.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import bg.ibs.user.profile.manager.portlet.controllers.PortletViewController;

@Component
public class UserProfileManagerLogger {
	
	private Logger logger = LoggerFactory.getLogger("UserProfileManagerPortlet");
		
	public void error(String message) {
		logger.error(message);
	}
	public void message(String message) {
//		logger.trace("A TRACE Message");
//      logger.debug("A DEBUG Message");
//      logger.info("An INFO Message");
//      logger.warn("A WARN Message");
//      logger.error("An ERROR Message");
		if (PortletViewController.isDebug) {
			logger.info(message);
		}
	}
	
	public Logger getLogger() {
		return logger;
	}	
	
	public static void main(String[] args) {
		UserProfileManagerLogger UserProfileManagerLogger = new UserProfileManagerLogger();
		UserProfileManagerLogger.error("test");
	}
}
