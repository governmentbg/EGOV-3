package bg.ibs.user.profile.manager.portlet.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import bg.ibs.user.profile.manager.portlet.dao.UserProfileRefDAO;
import bg.ibs.user.profile.manager.portlet.dao.UserProfileRoleDAO;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRef;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRole;

@Service("UserProfileRefService")
public class UserProfileRefServiceImpl implements UserProfileRefService {

	@Autowired
	@Qualifier("UserProfileRefDAO")
	private UserProfileRefDAO userProfileRefDao; 
	
	public UserProfileRef getById(Long id) {
		return userProfileRefDao.getById(id);
	} 
	
	public UserProfileRef getByUserProfileId(Long userProfileId) {
		return userProfileRefDao.getByUserProfileId(userProfileId);
	} 
	
	public List<UserProfileRef> getAllByParentUserProfileId(Long userProfileId) {
		return userProfileRefDao.getAllByParentUserProfileId(userProfileId);
	} 

}
