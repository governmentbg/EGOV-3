package bg.ibs.user.profile.manager.portlet.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Description;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import bg.ibs.user.profile.manager.portlet.UserProfileManagerConstants;
import bg.ibs.user.profile.manager.portlet.model.UserProfile;
import bg.ibs.user.profile.manager.portlet.model.UserProfileMapper;
import bg.ibs.user.profile.manager.portlet.model.UserProfilePersonalParameters;
import bg.ibs.user.profile.manager.portlet.model.UserProfilePersonalParametersMapper;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRole;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRoleMapper;
import bg.ibs.user.profile.manager.portlet.utils.UserProfileManagerLogger;
import bg.ibs.user.profile.manager.portlet.utils.UserProfileManagerUtils;

@Description("This class uses transaction from this article: https://www.tutorialspoint.com/spring/programmatic_management.htm")
@Repository("UserProfileRoleDAO")
public class UserProfileRoleDAOImpl implements UserProfileRoleDAO { 
	private static final String TABLE_NAME = "UserProfileRole";
	private static final String TABLE_USER_PROFILE_NAME = "UserProfile";
	private static final String TABLE_USER_PROFILE_PERSONAL_PARAMETERS_NAME = "UserProfilePersonalParameters";
	private static final String USER_PROFILE_ROLE_SEQUENCE_NAME = "SEQ_USERPROFILEROLE";
	
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	private PlatformTransactionManager transactionManager;
	
	@Autowired
	UserProfileManagerUtils utils; 
	
	@Autowired
	UserProfileManagerLogger logger; 

	private final String SQL_GET_ALL_BY_USER_PROFILE_ID = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userProfileId = ?";
	private final String SQL_GET_ALL_BY_USER_PROFILE_ID_AND_ADMIN_ROLE = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userProfileId = ? and admin = ?";
	private final String SQL_SELECT_USER_PROFILE_ROLE_SEQUENCE_NEXT_VAL = "select next value for " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + USER_PROFILE_ROLE_SEQUENCE_NAME + " from SYSIBM.SYSDUMMY1";
	private final String SQL_UPDATE_USER_PROFILE_ROLE = "update " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " set admin = ?, editor = ?, serviceManager = ?, userRole = ? where userProfileRoleId = ?";
	private final String SQL_UPDATE_USER_PROFILE_DATE_MODIFIED = "update " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_NAME + " set dateModified = ? where userProfileId = ?";	
	private final String SQL_CREATE_USER_PROFILE_ROLE = "insert into " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " (userProfileRoleId, userProfileId, userUID, admin, editor, serviceManager, userRole, dateCreated, email, confirm, code) values (?,?,?,?,?,?,?,?,?,?,?)";
	private final String SQL_DELETE_USER_PROFILE_ROLE = "delete from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userProfileRoleId in (%s)";
	private final String SQL_FIND_PROFILE_BY_UIDS_AND_TYPE = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_NAME + " where userUid in (%s) and profileType = ?";
	private final String SQL_FIND_PERSONAL_PARAMETERS_BY_USER_PROFILEID = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_PERSONAL_PARAMETERS_NAME + " where userProfileId = ?";

	@Autowired
	public UserProfileRoleDAOImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public List<UserProfileRole> getAllUserProfileRolesByUserProfileId(final Long userProfileId) {
		return jdbcTemplate.query(SQL_GET_ALL_BY_USER_PROFILE_ID, new Object[] { userProfileId }, new UserProfileRoleMapper());
	}
	
	public List<UserProfileRole> getAllUserProfileRolesByUserProfileIdAndAdminRole(final Long userProfileId) {
		return jdbcTemplate.query(SQL_GET_ALL_BY_USER_PROFILE_ID_AND_ADMIN_ROLE, new Object[] { userProfileId, UserProfileManagerConstants.USER_PROFILE_ROLE_SELECTED }, new UserProfileRoleMapper());
	}
	
	private List<UserProfile> getUserProfileByUserUidsAndProfileType(final List<String> userUids, final Integer profileType) {
		String inSql = String.join(",", Collections.nCopies(userUids.size(), "?"));
		Object[] objArr = new Object[userUids.size() + 1];		
		for (int i = 0; i < userUids.size(); i++) {
			objArr[i] = userUids.get(i);
		}
		objArr[userUids.size()] = profileType;
		return jdbcTemplate.query(String.format(SQL_FIND_PROFILE_BY_UIDS_AND_TYPE, inSql), objArr, new UserProfileMapper());
	}
	
	private UserProfilePersonalParameters getUserProfilePersonalParameters(final Long userProfileId) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_PERSONAL_PARAMETERS_BY_USER_PROFILEID, new Object[] { userProfileId }, new UserProfilePersonalParametersMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
 	
	private synchronized Long getUserProfleRoleSequenceNextVal() {		
		return jdbcTemplate.queryForObject(SQL_SELECT_USER_PROFILE_ROLE_SEQUENCE_NEXT_VAL + " where 1=1", Long.class);
	} // getNextVal

	public int updateAllUserProfileRolesForUserProfile(List<UserProfileRole> currentUsers, List<UserProfileRole> selectedUsers, Long userProfileId) {
		logger.message("updateAllUserProfileRolesForUserProfile() started...[" + (currentUsers != null ? currentUsers.size() : 0) + "][" + (selectedUsers != null ? selectedUsers.size() : 0) + "]" + userProfileId);
		Date currentDate = new Date();
		TransactionDefinition def = new DefaultTransactionDefinition();
	    TransactionStatus status = transactionManager.getTransaction(def);
		
	    try {
			List<Long> deleteIds = new ArrayList<Long>();
			List<String> proccessed = new ArrayList<String>();
			boolean hasChange = false;
			boolean founded = false;
			int result = -1;
			UserProfileRole currentUser = null;
			UserProfileRole selectedUser = null;
			for (int i = 0; i < currentUsers.size(); i++) {
				currentUser = currentUsers.get(i);
				founded = false;
				for (int j = 0; j < selectedUsers.size(); j++) {
					selectedUser = selectedUsers.get(j); 					
					logger.message("updateAllUserProfileRolesForUserProfile() -> " + currentUser.getUserUID() + "<>" + selectedUser.getUserUID());
					if (currentUser.getUserUID().equalsIgnoreCase(selectedUser.getUserUID())) {
						founded = true;	
						proccessed.add(currentUser.getUserUID());
						if (utils.hasRoleChange(currentUser, selectedUser)) {
							logger.message("updateAllUserProfileRolesForUserProfile() -> hasRoleChange");							
							hasChange = true;							
							// Update role.
							result = jdbcTemplate.update(
									SQL_UPDATE_USER_PROFILE_ROLE, 
									selectedUser.getAdmin(),
									selectedUser.getEditor(),
									selectedUser.getServiceManager(),
									selectedUser.getUserRole(),
									currentUser.getUserProfileRoleId()); 
							if (result < 1) {
								throw new Exception("Update role[" + currentUser.getUserProfileRoleId() + "] fails with result = " + result);
							}
						}
						break;
					}
				}
				if (!founded) {
					deleteIds.add(currentUser.getUserProfileRoleId());
					logger.message("updateAllUserProfileRolesForUserProfile() -> add to delete " + currentUser.getUserProfileRoleId());
					proccessed.add(currentUser.getUserUID());
					hasChange = true;
				}
			}
			if (deleteIds != null && deleteIds.size() > 0) {
				logger.message("updateAllUserProfileRolesForUserProfile() -> deleteIds.size()=" + deleteIds.size());
				// Delete removed users.
				String inSql = String.join(",", Collections.nCopies(deleteIds.size(), "?"));
				result = jdbcTemplate.update(String.format(SQL_DELETE_USER_PROFILE_ROLE, inSql), deleteIds.toArray());
				if (result != deleteIds.size()) {
					throw new Exception("Delete roles total[" + deleteIds.size() + "] fails with deleted result = " + result);
				}				
			}
			List<String> selectedUserUIDs = new ArrayList<String>();
			for (int i = 0; i < selectedUsers.size(); i++) {
				if (!proccessed.contains(selectedUsers.get(i).getUserUID())) {
					selectedUserUIDs.add(selectedUsers.get(i).getUserUID());
				}
			}
			if (selectedUserUIDs.size() > 0) {
				// Load profiles.
				List<UserProfile> personalProfiles = this.getUserProfileByUserUidsAndProfileType(selectedUserUIDs, UserProfileManagerConstants.USER_PROFILE_TYPE_PERSONAL);
				if (personalProfiles != null && personalProfiles.size() > 0) {
					Map<String, Long> profileIdByUserUID = new HashMap<>();
					for (int i = 0; i < personalProfiles.size(); i++) {
						profileIdByUserUID.put(personalProfiles.get(i).getUserUID(), personalProfiles.get(i).getUserProfileId());						
					}					
					Long tmpProfileId = null;
					String email = null;
					Integer confirm = null;
					String code = null;
					UserProfilePersonalParameters pp = null;
					for (int i = 0; i < selectedUsers.size(); i++) {
						selectedUser = selectedUsers.get(i);
						if (!proccessed.contains(selectedUser.getUserUID())) {
							// Insert role.
							email = null;
							confirm = null;
							code = null;
							
							tmpProfileId = profileIdByUserUID.get(selectedUser.getUserUID());
							if (tmpProfileId != null) {
								try {
									pp = this.getUserProfilePersonalParameters(tmpProfileId);
									if (pp != null) {
										email = pp.getEmail();
										confirm = UserProfileManagerConstants.USER_PROFILE_CHANGE_EMAIL_CONFIRMED;
									}
								} catch (Exception e) {
									e.printStackTrace();
								}
							}
							Long userProfileRoleId = getUserProfleRoleSequenceNextVal();
							jdbcTemplate.update(SQL_CREATE_USER_PROFILE_ROLE, new Object[] { 
									userProfileRoleId,
									userProfileId,
									selectedUser.getUserUID(),
									selectedUser.getAdmin(),
									selectedUser.getEditor(),
									selectedUser.getServiceManager(),									
									selectedUser.getUserRole(),									
									currentDate,
									email,
									confirm,
									code
							});	
							hasChange = true;
						}										
					}
				}
			}
			
			if (hasChange) {
				// Update profile date modified.
				result = jdbcTemplate.update(SQL_UPDATE_USER_PROFILE_DATE_MODIFIED, currentDate, userProfileId);
				if (result < 1) {
					throw new Exception("Update user profile [" + userProfileId + "] fails with result = " + result);
				}
			}						
			transactionManager.commit(status);
			return hasChange ? 1 : 0;
		} catch (Exception e) {
			e.printStackTrace();
			transactionManager.rollback(status);
		}
		return -1;
	}
	
}
