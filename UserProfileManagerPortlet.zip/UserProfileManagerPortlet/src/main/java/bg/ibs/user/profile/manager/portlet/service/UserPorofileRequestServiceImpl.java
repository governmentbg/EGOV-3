package bg.ibs.user.profile.manager.portlet.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import bg.ibs.user.profile.manager.portlet.dao.UserProfileRequestDAO;
import bg.ibs.user.profile.manager.portlet.model.UserProfile;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRequest;

@Service("UserProfileRequestService")
public class UserPorofileRequestServiceImpl implements UserProfileRequestService {

	@Autowired
	@Qualifier("UserProfileRequestDAO")
	private UserProfileRequestDAO userProfileRequestDAO; 
	
	public UserProfileRequest getUserProfileRequestById(Long id) {
		return userProfileRequestDAO.getUserProfileRequestById(id);
	}
	
	public UserProfileRequest getLastUserProfileRequestByUserUIDAndEIK(String userUID, String eik, boolean isREIK) {
		return userProfileRequestDAO.getLastUserProfileRequestByUserUIDAndEIK(userUID, eik, isREIK);
	}
	
	public UserProfileRequest getUserProfileRequestFileById(Long id) {
		return userProfileRequestDAO.getUserProfileRequestFileById(id);
	}
	
	public List<UserProfileRequest> getAllUserProfileRequests() {
		return userProfileRequestDAO.getAllUserProfileRequests();
	}

	public List<UserProfileRequest> getAllUserProfileRequestsByUserProfileId(Long userProfileId) {
		return userProfileRequestDAO.getAllUserProfileRequestsByUserProfileId(userProfileId);
	}
	
	public Integer countUserProfileRequestsByFilter(Long id, Long userProfileId, String name, Integer status) {
		return userProfileRequestDAO.countUserProfileRequestsByFilter(id, userProfileId, name, status);
	}
	
	public List<UserProfileRequest> getAllUserProfileRequestsByFilter(Long id, Long userProfileId, String name, Integer status, Integer start, Integer length, Integer orderColumn, String order) {
		return userProfileRequestDAO.getAllUserProfileRequestsByFilter(id, userProfileId, name, status, start, length, orderColumn, order);
	}
	
	public UserProfile approveUserProfileRequest(UserProfileRequest userProfileRequest, String profileStructureType, Date currentDate) {
		return userProfileRequestDAO.approveUserProfileRequest(userProfileRequest, profileStructureType, currentDate);
	}
	 
	public boolean cancelUserProfileRequest(UserProfileRequest userProfileRequest) {
		return userProfileRequestDAO.cancelUserProfileRequest(userProfileRequest);
	}
	
	public boolean deleteUserProfileRequest(UserProfileRequest userProfileRequest) {
		return userProfileRequestDAO.deleteUserProfileRequest(userProfileRequest);
	}

}
