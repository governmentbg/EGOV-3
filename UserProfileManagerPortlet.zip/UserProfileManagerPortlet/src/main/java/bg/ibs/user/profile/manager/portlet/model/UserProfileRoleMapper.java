package bg.ibs.user.profile.manager.portlet.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class UserProfileRoleMapper implements RowMapper<UserProfileRole> {

	public UserProfileRole mapRow(ResultSet resultSet, int i) throws SQLException {

		UserProfileRole role = new UserProfileRole();
		role.setUserProfileRoleId(resultSet.getLong("userProfileRoleId"));
		role.setUserProfileId(resultSet.getLong("userProfileId"));
		role.setUserUID(resultSet.getString("userUID"));
		role.setAdmin(resultSet.getInt("admin"));
		role.setEditor(resultSet.getInt("editor"));
		role.setServiceManager(resultSet.getInt("serviceManager"));
		role.setUserRole(resultSet.getInt("userRole"));
		role.setDateCreated(resultSet.getDate("dateCreated"));
		role.setEmail(resultSet.getString("email"));
		role.setConfirm(resultSet.getInt("confirm"));
		role.setCode(resultSet.getString("code"));
		return role;
	}
}
