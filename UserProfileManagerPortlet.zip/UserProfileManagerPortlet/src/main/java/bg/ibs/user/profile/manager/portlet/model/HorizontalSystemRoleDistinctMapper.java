package bg.ibs.user.profile.manager.portlet.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class HorizontalSystemRoleDistinctMapper implements RowMapper<HorizontalSystemRole> {

	public HorizontalSystemRole mapRow(ResultSet resultSet, int i) throws SQLException {

		HorizontalSystemRole role = new HorizontalSystemRole();
		role.setSystemOID(resultSet.getString("systemOID"));
		return role;
	}
}
