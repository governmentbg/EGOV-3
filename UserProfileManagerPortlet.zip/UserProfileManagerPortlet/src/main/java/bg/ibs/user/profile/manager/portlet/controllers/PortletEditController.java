package bg.ibs.user.profile.manager.portlet.controllers;

import java.io.IOException;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.PortletMode;
import javax.portlet.PortletPreferences;
import javax.portlet.WindowState;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.portlet.bind.annotation.ActionMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;

import bg.ibs.user.profile.manager.portlet.UserProfileManagerConstants;
import bg.ibs.user.profile.manager.portlet.beans.UserProfileManagerSessionBean;

@Controller
@RequestMapping("edit_defaults")
public class PortletEditController {
	
	private static final Logger logger = LoggerFactory.getLogger(PortletEditController.class);
	
	@Resource(name = "sessionScopedBean")
	UserProfileManagerSessionBean sessionBean;
	
	@Resource(name = "messageSource")
	private MessageSource messageSource;
	
	@PostConstruct
	public void init() {
	}
	
	@RenderMapping
    public String render(Model model, PortletPreferences prefs){
		logMessage("render()", prefs);

        model.addAttribute("attribute", prefs.getValue("prefVal", "default"));

        return "editDefaults";
    }

    @ActionMapping(value = "editDefaults")
    public void action(
    	@RequestParam("esbEventLogAddress") String esbEventLogAddress,    	
    	@RequestParam("mailSmtpHost") String mailSmtpHost,    	
    	@RequestParam("mailFromAddress") String mailFromAddress,    	
    	@RequestParam("language") String language,    	
    	@RequestParam("debug") String debug,
    	PortletPreferences prefs,  
    	ActionResponse response) throws PortletException, IOException {
    	
    	logMessage("action()", prefs);
    	
    	try {
    		prefs.setValue(UserProfileManagerConstants.SETTING_PARAMETER_ESB_EVENT_LOGGER_ADDRESS, esbEventLogAddress);    		
    		prefs.setValue(UserProfileManagerConstants.SETTING_PARAMETER_MAIL_SMTP_HOST, mailSmtpHost);    		
    		prefs.setValue(UserProfileManagerConstants.SETTING_PARAMETER_MAIL_FROM_ADDRESS, mailFromAddress);    		
    		prefs.setValue(UserProfileManagerConstants.SETTING_PARAMETER_LANGUAGE, language);    		
	    	prefs.setValue(UserProfileManagerConstants.SETTING_PARAMETER_DEBUG, debug);
	    	prefs.store();
	    	response.setPortletMode(PortletMode.VIEW);
	    	response.setWindowState(WindowState.NORMAL);
		} catch( Exception e ) { 
			//sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
		}
    }
	
	private void logMessage(String message, PortletPreferences prefs) { 
		boolean isDebug = "1".equalsIgnoreCase(prefs.getValue(UserProfileManagerConstants.SETTING_PARAMETER_DEBUG, ""));
		if (isDebug) {
			logger.info(message);
		}
	}
}
