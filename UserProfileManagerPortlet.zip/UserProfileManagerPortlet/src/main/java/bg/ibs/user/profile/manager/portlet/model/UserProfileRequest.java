package bg.ibs.user.profile.manager.portlet.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class UserProfileRequest {
	@Id		
	private Long userProfileRequestId;
	@Column(nullable = false)
	private Long userProfileId;
	@Column(nullable = false)
	private int profileType;
	@Column(nullable = false)
	private String eik;
	@Column(nullable = false)
	private String nameAndLegalForm;
	private String orderNumber;
	private byte[] orderDocument;
	private String orderDocumentName;
	private Integer orderDocumentSize;
	private String orderDocumentContentType;
	private String accessKind;
	@Column(nullable = false)
	private int status;
	@Column(name = "dateCreated", nullable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
	@Column(name = "dateApproved")
	@Temporal(TemporalType.TIMESTAMP)
	private Date dateApproved;
	@Column(name = "dateCanceled")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCanceled;
	private String cancelReason;
	@Column(nullable = false)
	private String userUID;
	@Column(nullable = false)
	private String names;
	private String profileStructureType;
	private String profileStructureTypeOther;
	private Long leUserProfileId;
	private String reik;
	
	public Long getUserProfileRequestId() {
		return userProfileRequestId;
	}
	public void setUserProfileRequestId(Long userProfileRequestId) {
		this.userProfileRequestId = userProfileRequestId;
	}
	public Long getUserProfileId() {
		return userProfileId;
	}
	public void setUserProfileId(Long userProfileId) {
		this.userProfileId = userProfileId;
	}
	public int getProfileType() {
		return profileType;
	}
	public void setProfileType(int profileType) {
		this.profileType = profileType;
	}
	public String getEik() {
		return eik;
	}
	public void setEik(String eik) {
		this.eik = eik;
	}
	public String getNameAndLegalForm() {
		return nameAndLegalForm;
	}
	public void setNameAndLegalForm(String nameAndLegalForm) {
		this.nameAndLegalForm = nameAndLegalForm;
	}
	public String getOrderNumber() {
		return orderNumber;
	}
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}
	public byte[] getOrderDocument() {
		return orderDocument;
	}
	public void setOrderDocument(byte[] orderDocument) {
		this.orderDocument = orderDocument;
	}
	public String getOrderDocumentName() {
		return orderDocumentName;
	}
	public void setOrderDocumentName(String orderDocumentName) {
		this.orderDocumentName = orderDocumentName;
	}
	public int getOrderDocumentSize() {
		return orderDocumentSize;
	}
	public void setOrderDocumentSize(Integer orderDocumentSize) {
		this.orderDocumentSize = orderDocumentSize;
	}
	public String getOrderDocumentContentType() {
		return orderDocumentContentType;
	}
	public void setOrderDocumentContentType(String orderDocumentContentType) {
		this.orderDocumentContentType = orderDocumentContentType;
	}
	public String getAccessKind() {
		return accessKind;
	}
	public void setAccessKind(String accessKind) {
		this.accessKind = accessKind;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	public Date getDateApproved() {
		return dateApproved;
	}
	public void setDateApproved(Date dateApproved) {
		this.dateApproved = dateApproved;
	}
	public Date getDateCanceled() {
		return dateCanceled;
	}
	public void setDateCanceled(Date dateCanceled) {
		this.dateCanceled = dateCanceled;
	}
	public String getCancelReason() {
		return cancelReason;
	}
	public void setCancelReason(String cancelReason) {
		this.cancelReason = cancelReason;
	}
	public String getUserUID() {
		return userUID;
	}
	public void setUserUID(String userUID) {
		this.userUID = userUID;
	}
	public String getNames() {
		return names;
	}
	public void setNames(String names) {
		this.names = names;
	}
	public String getProfileStructureType() {
		return profileStructureType;
	}
	public void setProfileStructureType(String profileStructureType) {
		this.profileStructureType = profileStructureType;
	}
	public String getProfileStructureTypeOther() {
		return profileStructureTypeOther;
	}
	public void setProfileStructureTypeOther(String profileStructureTypeOther) {
		this.profileStructureTypeOther = profileStructureTypeOther;
	}
	public Long getLeUserProfileId() {
		return leUserProfileId;
	}
	public void setLeUserProfileId(Long leUserProfileId) {
		this.leUserProfileId = leUserProfileId;
	}
	public String getReik() {
		return reik;
	}
	public void setReik(String reik) {
		this.reik = reik;
	}
	
}
