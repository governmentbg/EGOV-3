package bg.ibs.user.profile.manager.portlet.beans;

import java.util.HashMap;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import bg.ibs.user.profile.manager.portlet.UserProfileManagerConstants;

@SessionScope
@Component
public class UserProfileManagerSessionBean {
	
	private String currentPage = UserProfileManagerConstants.INDEX_PAGE;
	private HashMap<String, Container> container = null;
	private HashMap<String, Integer> tabPerPage = null;
	private Long requestId = null;	
	private Long profileId = null;	
	private Integer mode = null;
	private Integer callerMode = null;
	private String userUID = null;
	private String error = null;
	private String message = null;
	private boolean initialised;
	
	public String getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}
	
	public HashMap<String, Container> getContainer() {
		return container != null ? container : new HashMap<String, Container>();
	}

	public void setContainer(HashMap<String, Container> container) {
		this.container = container;
	}

	public HashMap<String, Integer> getTabPerPage() {
		return tabPerPage != null ? tabPerPage : new HashMap<String, Integer>();
	}

	public void setTabPerPage(HashMap<String, Integer> tabPerPage) {
		this.tabPerPage = tabPerPage;
	}
	
	public Long getRequestId() {
		return requestId;
	}

	public void setRequestId(Long requestId) {
		this.requestId = requestId;
	}

	public Long getProfileId() {
		return profileId;
	}

	public void setProfileId(Long profileId) {
		this.profileId = profileId;
	}

	public Integer getMode() {
		return mode;
	}

	public void setMode(Integer mode) {
		this.mode = mode;
	}

	public Integer getCallerMode() {
		return callerMode;
	}

	public void setCallerMode(Integer callerMode) {
		this.callerMode = callerMode;
	}

	public String getUserUID() {
		return userUID;
	}

	public void setUserUID(String userUID) {
		this.userUID = userUID;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public boolean isInitialised() {
		return initialised;
	}
	public void setInitialised(boolean initialised) {
		this.initialised = initialised;
	}
}
