package bg.ibs.user.profile.manager.portlet.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class UserProfileRefMapper implements RowMapper<UserProfileRef> {

	public UserProfileRef mapRow(ResultSet resultSet, int i) throws SQLException {

		UserProfileRef ref = new UserProfileRef();
		ref.setUserProfileRefId(resultSet.getLong("userProfileRefId"));
		ref.setUserProfileId(resultSet.getLong("userProfileId"));
		ref.setReik(resultSet.getString("reik"));
		ref.setEik(resultSet.getString("eik"));
		ref.setParentUserProfileId(resultSet.getLong("parentUserProfileId"));
		ref.setParentUserProfileIds(resultSet.getString("parentUserProfileIds"));
		return ref;
	}
}
