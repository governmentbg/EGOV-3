package bg.ibs.user.profile.manager.portlet.beans;

public class HorizontalSystem {
	private String oid;
	private String name;
	
	public String getOid() {
		return oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
