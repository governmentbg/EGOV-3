package bg.ibs.user.profile.manager.portlet.beans;

public class ProfileStructureTypeBean {
	Integer name = null;
	String title = null;
	
	public Integer getName() {
		return name;
	}
	public void setName(Integer name) {
		this.name = name;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}

}
