package bg.ibs.user.profile.manager.portlet.utils;

import java.io.UnsupportedEncodingException;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;

import bg.ibs.user.profile.manager.portlet.controllers.PortletViewController;

public class MailMessage extends Thread {
	
	public synchronized static boolean sendEmail(String t_from, String t_to, String t_cc,String t_subject, String t_simpleMessage, boolean isDebug) throws MessagingException {
		System.err.println("in sendSingle");
		InternetAddress[] to = InternetAddress.parse(t_to);
		InternetAddress from = new InternetAddress(t_from);	
		Properties properties = new Properties();
		properties.setProperty("mail.smtp.host", PortletViewController.mailSmtpHost);
		Session session = Session.getDefaultInstance(properties);
		MimeMessage msg = new MimeMessage(session);			
		msg.setFrom(from);
		msg.setRecipients(Message.RecipientType.TO, to);
		if (t_cc != null && !t_cc.trim().equals("")) {
			InternetAddress[] to_cc = InternetAddress.parse(t_cc);
			msg.setRecipients(Message.RecipientType.CC, to_cc);
			if (isDebug) { System.err.println("cc: " + t_cc);}
		}
	
		try {
			t_subject = MimeUtility.encodeText(t_subject, "utf-8", null);
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}

		//System.err.println("in sendSingle2");
		msg.setSubject(t_subject);

		MimeMultipart msgMultiPart = new MimeMultipart();
		DataHandler dh1 = new DataHandler(t_simpleMessage, "text/html; charset=utf-8");
		MimeBodyPart bp1 = new MimeBodyPart();
		bp1.setDataHandler(dh1);
		bp1.setHeader("Content-Transfer-Encoding", "base64");
		bp1.setHeader("Content-Type", "text/html; charset=\"utf-8\"");
		msgMultiPart.addBodyPart(bp1);
		msg.setContent(msgMultiPart);
		msg.saveChanges();
		//System.err.println("in sendSingle3");
		UserProfileManagerLogger logger = new UserProfileManagerLogger();
		logger.message("MailMessage [sendSingle] -> Sending email to... " + t_to);
		//logger.log(Logger.DEBUG_LEVEL, "MailMessage [sendSingle] -> Sending email to... " + t_to);
		//System.err.println("MailMessage [sendSingle] -> Sending email to... " + t_to);		
		//System.err.println("MailMessage [sendSingle] -> Sending email to... " + t_to);
		//System.err.println("MailMessage [sendSingle] -> Sending email to... " + t_to);
		try{
			Transport.send(msg);
		} catch (Exception e) {
			System.err.println(e.getMessage());			
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public synchronized static boolean sendMultiple(String t_from, String t_to, String t_bcc, String t_subject, String t_simpleMessage) throws MessagingException {
		InternetAddress from = new InternetAddress(t_from);
        InternetAddress to = new InternetAddress(t_to);
		InternetAddress[] to_bcc = InternetAddress.parse(t_bcc);
		Properties properties = new Properties();
		properties.setProperty("mail.smtp.host", PortletViewController.mailSmtpHost);
		Session session = Session.getDefaultInstance(properties);
		MimeMessage msg = new MimeMessage(session);	
		msg.setFrom(from);
		msg.setRecipient(Message.RecipientType.TO, to);
		msg.setRecipients(Message.RecipientType.BCC, to_bcc);

		try {
			t_subject = MimeUtility.encodeText(t_subject, "utf-8", null);
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}

		msg.setSubject(t_subject);

		MimeMultipart msgMultiPart = new MimeMultipart();
		DataHandler dh1 = new DataHandler(t_simpleMessage, "text/html; charset=utf-8");
		MimeBodyPart bp1 = new MimeBodyPart();
		bp1.setDataHandler(dh1);
//		bp1.setHeader("Content-Transfer-Encoding", "base64");
		bp1.setHeader("Content-Transfer-Encoding", "quoted-printable");
		bp1.setHeader("Content-Type", "text/html; charset=\"utf-8\"");
		msgMultiPart.addBodyPart(bp1);

		msg.setContent(msgMultiPart);

		msg.saveChanges();
		
		new MailMessage(msg).start();
		// Transport.send(msg);
		return true;
	}

	private Message msg;

	public MailMessage(Message msg) {
		this.msg = msg;
	}

	public void run() {
		try {
			Transport.send(msg);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
