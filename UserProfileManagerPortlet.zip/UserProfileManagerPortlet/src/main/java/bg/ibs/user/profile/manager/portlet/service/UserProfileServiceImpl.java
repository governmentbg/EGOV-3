package bg.ibs.user.profile.manager.portlet.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import bg.ibs.user.profile.manager.portlet.dao.UserProfileDAO;
import bg.ibs.user.profile.manager.portlet.model.UserProfile;
import bg.ibs.user.profile.manager.portlet.model.UserProfileAndRole;

@Service("UserProfileService")
public class UserProfileServiceImpl implements UserProfileService {

	@Autowired
	@Qualifier("UserProfileDAO")
	private UserProfileDAO userProfileDao; 
	
	public UserProfile getUserProfileById(Long id) {
		return userProfileDao.getUserProfileById(id);
	}
	
	public UserProfile getUserProfileByUserUidAndProfileType(String userUid, Integer profileType) {
		return userProfileDao.getUserProfileByUserUidAndProfileType(userUid, profileType);
	}
	
	public List<UserProfile> getUserProfileByUserUidsAndProfileType(List<String> userUids, Integer profileType) {
		return userProfileDao.getUserProfileByUserUidsAndProfileType(userUids, profileType);
	}

	public List<UserProfile> getAllUserProfiles() {
		return userProfileDao.getAllUserProfiles();
	}
	
	public Integer countUserProfilesByFilter(Long id, Integer profileType, Integer profileStructureType, String userUID, String name, Integer status) {
		return userProfileDao.countUserProfilesByFilter(id, profileType, profileStructureType, userUID, name, status);
	}
	
	public List<UserProfile> getAllUserProfilesByFilter(Long id, Integer profileType, Integer profileStructureType, String userUID, String name, Integer status, Integer start, Integer length, Integer orderColumn, String order) {
		return userProfileDao.getAllUserProfilesByFilter(id, profileType, profileStructureType, userUID, name, status, start, length, orderColumn, order);
	}
	
	public UserProfile createUserProfile(UserProfile userProfile) {
		return userProfileDao.createUserProfile(userProfile);
	}
	
	public boolean updateUserProfile(UserProfile userProfile) {
		return userProfileDao.updateUserProfile(userProfile);
	}
	
	public boolean deleteUserProfile(UserProfile userProfile) {
		return userProfileDao.deleteUserProfile(userProfile);
	}

	public List<UserProfileAndRole> getUserProfileAndRolesByProfileId(Long profileId) {
		return userProfileDao.getUserProfileAndRolesByProfileId(profileId);
	}
}
