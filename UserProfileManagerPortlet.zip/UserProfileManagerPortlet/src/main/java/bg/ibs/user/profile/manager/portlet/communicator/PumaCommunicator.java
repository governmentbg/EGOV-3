package bg.ibs.user.profile.manager.portlet.communicator;

import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ibm.portal.um.Group;
import com.ibm.portal.um.PumaController;
import com.ibm.portal.um.PumaEnvironment;
import com.ibm.portal.um.PumaHome;
import com.ibm.portal.um.PumaLocator;
import com.ibm.portal.um.PumaProfile;
import com.ibm.portal.um.User;
import com.ibm.portal.um.exceptions.MemberAlreadyExistsException;
import com.ibm.portal.um.exceptions.PumaMissingAccessRightsException;
import com.ibm.portal.um.exceptions.PumaModelException;
import com.ibm.portal.um.exceptions.PumaSystemException;

import bg.ibs.user.profile.manager.portlet.UserProfileManagerConstants;
import bg.ibs.user.profile.manager.portlet.utils.UserProfileManagerLogger;

@Component
public class PumaCommunicator {
	@Autowired
	UserProfileManagerLogger logger;
		
	@SuppressWarnings("rawtypes")
	public String getUserUID(final User user, final PumaHome pumaHome) {
		java.util.Map<String, Object> userInfo = getUserAttributesInfo(user, pumaHome, pumaHome.getProfile());
		if (userInfo != null) {
			Object attribute = userInfo.get(UserProfileManagerConstants.LDAP_ATTRIBUTE_UID);
			if (attribute != null) {
				String currentUserUID = null;
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							currentUserUID += " ";
						}
						currentUserUID += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					currentUserUID = (String)attribute;
				}		
				return currentUserUID;
			}
		}
		return null;
	}
	
	public User getUserByUID(final String userAttribute, final PumaHome pumaHome) {
		logger.message("getUserByUID(" + userAttribute + ")");
		User user = null;
		List<User> users = getUsersByAttribute(userAttribute, UserProfileManagerConstants.LDAP_ATTRIBUTE_UID, pumaHome);
		if (users != null && users.size() > 0) {
			logger.message("getUserByUID(" + userAttribute + ") -> users.size() = " + users.size());
			if (users.size() > 1) {
				logger.message("getUserByUID() -> " + "Warning: Using non-unique attribute for User. Attribute Name=" + UserProfileManagerConstants.LDAP_ATTRIBUTE_UID + " Value =" + userAttribute);
			} else {
				user = (User) users.get(0);
			}
		} else {
			logger.message("getUserByUID(" + userAttribute + ") -> No User was found!");
		}

		return user;
	}
	
	@SuppressWarnings("rawtypes")
	public String addUserToGroupsIfNotAdded(User user, final String groupId, final PumaHome pumaHome) {
		if (user != null) {
			// Check user is already added to the group.
			ArrayList <String> attribNames = new ArrayList<>(1);
			boolean founded = false;
			attribNames.add("cn");
			List<Group> userGroups;
			try {
				userGroups = pumaHome.getLocator().findGroupsByPrincipal(user, true);
				if (userGroups != null && userGroups.size() > 0) { 
					Map attributeMap=null;
					String groupCN = null;
					for (Group group : userGroups) {						
						attributeMap = pumaHome.getProfile().getAttributes(group, attribNames);
						groupCN = (String) attributeMap.get("cn");					
						logger.message("approveProfileRequest() -> groupCN = " + groupCN);							
						if (groupCN.equals(groupId)) { 
							logger.message("approveProfileRequest() -> founded = " + founded);
							founded = true;							
							break;
						}						
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			if (!founded) {
				return addUserToGroups(user, new String[] {groupId}, pumaHome);
			}
		}
		return null;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private List<User> getUsersByAttribute(final String userAttributeValue, final String searchAttribute, final PumaHome pumaHome) {
		logger.message("getUsersByAttribute(" + userAttributeValue + "," + searchAttribute + ")");
		List<User> users = null;
		try {
			final PumaEnvironment env = pumaHome.getEnvironment();
			final PumaLocator locatorService = pumaHome.getLocator();
			users = (List<User>) env.runUnrestricted(new PrivilegedExceptionAction() {
				public Object run() throws Exception {
					return locatorService.findUsersByAttribute(searchAttribute, userAttributeValue);
				}
			});
		} catch (Exception e) {
			logger.error("getUsersByAttribute(" + userAttributeValue + "," + searchAttribute + ") -> Exception: " + e.getMessage());
			e.printStackTrace();
		}		
		return users;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public java.util.Map<String, Object> getUserAttributesInfo(final User user, final PumaHome pumaHome, final PumaProfile pumaProfile) {
		logger.message("getUserAttributesInfo(com.ibm.portal.um.User)");
		final java.util.List<String> attributesNamesList;
		try {
			final PumaEnvironment env = pumaHome.getEnvironment();
			attributesNamesList = new ArrayList<>();
			attributesNamesList.add(UserProfileManagerConstants.LDAP_ATTRIBUTE_UID);
			java.util.Map<String, Object> userInfo = (java.util.Map<String, Object>) env.runUnrestricted(new PrivilegedExceptionAction() {
				public Object run() throws Exception {
					return pumaProfile.getAttributes((com.ibm.portal.um.Principal) user, attributesNamesList);
				}
			});
			return userInfo;
		} catch (Exception e) {
			logger.error("getUserAttributesInfo(user, pumaHome, pumaProfile) -> Exception: " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String addUserToGroups(User user, String[] groupsArr, final PumaHome pumaHome) {	
		logger.message("addUserToGroups(user, groupsArr) entering...");
		if (user == null || groupsArr == null || groupsArr.length == 0) return null;
		String retVal = null;
		final ArrayList<Group> groups = new ArrayList<Group>();
		Group tmpGroup = null;
		for (int i = 0; i < groupsArr.length; i++) {
			tmpGroup = getGroup(groupsArr[i], pumaHome);
			if (tmpGroup != null) {
				groups.add(tmpGroup);
			}
		}	
		logger.message("addUserToGroups(user, groupsArr) founded groups = " + groups.size());
		try {
			final PumaEnvironment pumaEnvironment = pumaHome.getEnvironment();
			final PumaController controller = pumaHome.getController();
			

			retVal = (String) pumaEnvironment.runUnrestricted(new PrivilegedExceptionAction() {
				String retValL = null;

				public Object run() {
					List<User> users = new ArrayList<User>();
					users.add(user);
					try {
						for (int i = 0; i < groups.size(); i++) {
							controller.addToGroup(groups.get(i), users);
							logger.message("addUserToGroups(user, groupsArr) USER ADDED TO GROUP = " + groups.get(i));
						}						
					} catch (PumaSystemException e) {
						retValL = "System_Exception";
						logger.error("addUserToGroups() [ERROR] - retValL :" + retValL + "---" + e.getMessage());
					} catch (MemberAlreadyExistsException e) {
						retValL = "User_Already_Added";
						logger.error("addUserToGroups() [ERROR] - retValL :" + retValL + "---" + e.getMessage());
					} catch (PumaModelException e) {
						retValL = "Data_Model_Exception";
						logger.error("addUserToGroups() [ERROR] - retValL :" + retValL + "---" + e.getMessage());
					} catch (PumaMissingAccessRightsException e) {
						retValL = "Missing_Access_Rights";
						logger.error("addUserToGroups() [ERROR] - retValL :" + retValL + "---" + e.getMessage());
					}
					return retValL;
				}
			});

		} catch (Exception e) {
			retVal = "Cannot_Add_Member_To_Group";
			logger.error("addUserToGroup_new Exception " + retVal + " ---" + e.getMessage());
			e.printStackTrace();
		}
		logger.message("addUserToGroups(user, groupsArr) exiting, retVal: " + retVal);
		return retVal;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Group getGroup(final String groupId, final PumaHome pumaHome) {
		logger.message("getGroup(" + groupId + ") entering...");
		Group group = null;
		try {			
			final PumaEnvironment pumaEnvironment = pumaHome.getEnvironment(); 
			final PumaLocator locatorService = pumaHome.getLocator();
			List<Group> groups = (List<Group>) pumaEnvironment.runUnrestricted(new PrivilegedExceptionAction() {
				public Object run() throws Exception {
					return locatorService.findGroupsByDefaultAttribute(groupId);
				}
			});
			if (groups != null && groups.size() > 0) {
				group = (Group) groups.get(0);
				logger.message("getGroup(" + groupId + ") Successfully retrieved group - " + groupId + "!");
			}
		} catch (PrivilegedActionException e) {
			logger.error("getGroup(" + groupId + ") [ERROR] -> " + e.getMessage());
		}
		logger.message("getGroup(" + groupId + ") exiting...");
		return group;
	}
}
