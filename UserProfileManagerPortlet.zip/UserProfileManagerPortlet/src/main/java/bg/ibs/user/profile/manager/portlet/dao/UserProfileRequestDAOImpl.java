package bg.ibs.user.profile.manager.portlet.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Description;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.egov.wcm.cache.EgovWCMCache;

import bg.ibs.user.profile.manager.portlet.UserProfileManagerConstants;
import bg.ibs.user.profile.manager.portlet.model.UserProfile;
import bg.ibs.user.profile.manager.portlet.model.UserProfileMapper;
import bg.ibs.user.profile.manager.portlet.model.UserProfilePersonalParameters;
import bg.ibs.user.profile.manager.portlet.model.UserProfilePersonalParametersMapper;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRef;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRefMapper;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRequest;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRequestFileMapper;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRequestMapper;
import bg.ibs.user.profile.manager.portlet.utils.UserProfileManagerLogger;
import bg.ibs.user.profile.manager.portlet.utils.UserProfileManagerUtils;

@Description("This class uses transaction from this article: https://www.tutorialspoint.com/spring/programmatic_management.htm")
@Repository("UserProfileRequestDAO")
public class UserProfileRequestDAOImpl implements UserProfileRequestDAO { 
	private static final String TABLE_NAME = "UserProfileRequest";
	private static final String TABLE_USER_PROFILE_NAME = "UserProfile";
	private static final String TABLE_USER_PROFILE_ROLE_NAME = "UserProfileRole";
	private static final String TABLE_USER_PROFILE_PERSONAL_PARAMETERS_NAME = "UserProfilePersonalParameters";
	private static final String TABLE_USER_PROFILE_REF_NAME = "UserProfileRef";
	private static final String USER_PROFILE_SEQUENCE_NAME = "SEQ_USERPROFILE";
	private static final String USER_PROFILE_ROLE_SEQUENCE_NAME = "SEQ_USERPROFILEROLE";
	private static final String USER_PROFILE_REF_SEQUENCE_NAME = "SEQ_USERPROFILEREF";
	
	private final JdbcTemplate jdbcTemplate;
	
	@Autowired
	private PlatformTransactionManager transactionManager;
	
	@Autowired
	UserProfileManagerUtils utils;	
	@Autowired
	UserProfileManagerLogger logger;	

	private final String SQL_FIND_USER_PROFILE_REQUEST = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userProfileRequestId = ?";
	private final String SQL_FIND_USER_PROFILE_REQUEST_FOR_PROFILE_BY_EIK = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userUID = ? AND eik = ? AND reik IS NULL AND status = ? order by dateApproved desc";
	private final String SQL_FIND_USER_PROFILE_REQUEST_FOR_PROFILE_BY_REIK = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userUID = ? AND reik = ? AND status = ? order by dateApproved desc";
	private final String SQL_FIND_USER_PROFILE_REQUEST_FILE = "select orderDocument,orderDocumentName,orderDocumentSize,orderDocumentContentType from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userProfileRequestId = ?";
	private final String SQL_COUNT = "select count(userProfileRequestId) from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME;
	private final String SQL_GET_ALL = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME;
	private final String SQL_GET_ALL_USER_PROFILES_BY_IDS = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_NAME + " where userProfileId in (%s)";
	private final String SQL_FIND_PROFILE = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_NAME + " where userProfileId = ?";
	private final String SQL_FIND_PROFILE_BY_EIK = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_NAME + " where eik = ?";
	private final String SQL_FIND_PERSONAL_PARAMETERS_BY_USER_PROFILEID = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_PERSONAL_PARAMETERS_NAME + " where userProfileId = ?";
	private final String SQL_FIND_PROFILE_REFS_BY_PARENT_USER_PROFILEID = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_REF_NAME + " where parentUserProfileId = ?";
	private final String SQL_FIND_PROFILE_BY_PROFILE_IDS_AND_STATUS = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_NAME + " where userProfileId in (%s) and status = ?";
	private final String SQL_SELECT_USER_PROFILE_SEQUENCE_NEXT_VAL = "select next value for " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + USER_PROFILE_SEQUENCE_NAME + " from SYSIBM.SYSDUMMY1";	
	private final String SQL_SELECT_USER_PROFILE_ROLE_SEQUENCE_NEXT_VAL = "select next value for " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + USER_PROFILE_ROLE_SEQUENCE_NAME + " from SYSIBM.SYSDUMMY1";
	private final String SQL_SELECT_USER_PROFILE_REF_SEQUENCE_NEXT_VAL = "select next value for " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + USER_PROFILE_REF_SEQUENCE_NAME + " from SYSIBM.SYSDUMMY1";
	private final String SQL_SELECT_LEGAL_ENTITY_REIK_9_NEXT_VAL = "select count(*) from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_NAME + " where eik like ? and not length(eik)=13";
	private final String SQL_SELECT_LEGAL_ENTITY_REIK_13_NEXT_VAL = "select count(*) from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_NAME + " where eik like ?";
	private final String SQL_APPROVE_USER_PROFILE_REQUEST = "update " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " set status = ?, dateApproved = ? where userProfileRequestId = ?";
	private final String SQL_CREATE_USER_PROFILE = "insert into " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_NAME + " (userProfileId, userUID, identifier, identifierPrefix, names, eik, nameAndLegalForm, profileType, profileStructureType, dateCreated, dateModified, groupId, status) values (?,?,?,?,?,?,?,?,?,?,?,?,?)";
	private final String SQL_CREATE_USER_PROFILE_ROLE = "insert into " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_ROLE_NAME + " (userProfileRoleId, userProfileId, userUID, admin, editor, serviceManager, userRole, dateCreated, email, confirm) values (?,?,?,?,?,?,?,?,?,?)";
	private final String SQL_CREATE_USER_PROFILE_REF = "insert into " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_REF_NAME + " (userProfileRefId, userProfileId, reik, eik, parentUserProfileId, parentUserProfileIds) values (?,?,?,?,?,?)";
	private final String SQL_UPDATE_USER_PROFILE_STATUS = "update " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_NAME + " set userUID = ?, names = ?, identifier = ?, identifierPrefix = ?, status = ?, deactivationReason = ?, dateModified = ? where userProfileId = ?";
	private final String SQL_UPDATE_USER_PROFILE_EIK = "update " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_NAME + " set eik = ? where userProfileId = ?";
	private final String SQL_UPDATE_USER_PROFILE_REQUEST_REIK = "update " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " set reik = ? where userProfileRequestId = ?";
	private final String SQL_CANCEL_USER_PROFILE_REQUEST = "update " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " set status = ?, dateCanceled = ?, cancelReason = ? where userProfileRequestId = ?";
	private final String SQL_DELETE_USER_PROFILE_REQUEST = "delete from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userProfileRequestId = ?";

	@Autowired
	public UserProfileRequestDAOImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		//transactionTemplate = new TransactionTemplate();
	}

	public UserProfileRequest getUserProfileRequestById(final Long userProfileRequestId) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_USER_PROFILE_REQUEST, new Object[] { userProfileRequestId }, new UserProfileRequestMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public UserProfileRequest getLastUserProfileRequestByUserUIDAndEIK(final String userUID, final String eik, final boolean isREIK) {
		try {
			List<UserProfileRequest> requests = jdbcTemplate.query(isREIK ? SQL_FIND_USER_PROFILE_REQUEST_FOR_PROFILE_BY_REIK : SQL_FIND_USER_PROFILE_REQUEST_FOR_PROFILE_BY_EIK, new Object[] { userUID, eik, UserProfileManagerConstants.USER_PROFILE_REQUEST_STATUS_APPROVED }, new UserProfileRequestMapper());
			if (requests != null && requests.size() > 0) {
				return requests.get(0);
			}
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
		return null;
	}
	
	public UserProfileRequest getUserProfileRequestFileById(final Long userProfileRequestId) {
		try {			
			return jdbcTemplate.queryForObject(SQL_FIND_USER_PROFILE_REQUEST_FILE, new Object[] { userProfileRequestId }, new UserProfileRequestFileMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	public List<UserProfileRequest> getAllUserProfileRequests() {
		return jdbcTemplate.query(SQL_GET_ALL + " where 1=1", new UserProfileRequestMapper());
	}
	
	public List<UserProfileRequest> getAllUserProfileRequestsByUserProfileId(Long userProfileId) {
		return jdbcTemplate.query(SQL_GET_ALL + " where userProfileId = ? ", new Object[] {userProfileId} , new UserProfileRequestMapper());
	}
	
	public Integer countUserProfileRequestsByFilter(final Long id, final Long userProfileId, final String name, final Integer status) {
		if (id == null && userProfileId == null && (name == null || name.trim().length() == 0) && status == null) {
			return jdbcTemplate.queryForObject(SQL_COUNT + " where 1=1", Integer.class);
		}
		// We have filter(s) selected, so apply them.
		String qWhere = "";
		List<Object> filters = new ArrayList<>();
		if (id != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "userProfileRequestId = ?";
			filters.add(id);
		}
		if (userProfileId != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "userProfileId = ?";
			filters.add(userProfileId);
		}
		if (name != null && name.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "(LOWER(nameAndLegalForm) LIKE ?";
			filters.add("%" + name.toLowerCase() + "%");
			qWhere += " OR LOWER(names) LIKE ?)";
			filters.add("%" + name.toLowerCase() + "%");
		}
		if (status != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "status = ?";
			filters.add(status);
		}
		return jdbcTemplate.queryForObject(SQL_COUNT + qWhere, filters.toArray(new Object[filters.size()]), Integer.class);
	}
	
	public List<UserProfileRequest> getAllUserProfileRequestsByFilter(final Long id, final Long userProfileId, final String name, final Integer status, final Integer start, final Integer length, final Integer orderColumn, final String order) {
		String qOrder = "";
		if (orderColumn != null) {
			if (UserProfileManagerConstants.COLUMN_ID == orderColumn) {
				qOrder = " order by userProfileRequestId";
			} else if (UserProfileManagerConstants.COLUMN_REQUEST_PROFILE_NUMBER == orderColumn) {
				qOrder = " order by userProfileId";
			} else if (UserProfileManagerConstants.COLUMN_REQUEST_PROFILE_TYPE == orderColumn) {
				qOrder = " order by profileType";
			} else if (UserProfileManagerConstants.COLUMN_REQUEST_EIK == orderColumn) {
				qOrder = " order by eik";
			} else if (UserProfileManagerConstants.COLUMN_REQUEST_NAME_AND_LEGAL_FORM == orderColumn) {
				qOrder = " order by nameAndLegalForm";
			} else if (UserProfileManagerConstants.COLUMN_REQUEST_NAMES == orderColumn) {
				qOrder = " order by names";
			} else if (UserProfileManagerConstants.COLUMN_REQUEST_DATE_CREATED == orderColumn) {
				qOrder = " order by dateCreated";
			} else if (UserProfileManagerConstants.COLUMN_REQUEST_DATE_APPROVED == orderColumn) {
				if (status != null && UserProfileManagerConstants.USER_PROFILE_REQUEST_STATUS_CANCELED == status) {
					qOrder = " order by dateCanceled";
				} else {
					qOrder = " order by dateApproved";
				}	
			} else if (UserProfileManagerConstants.COLUMN_REQUEST_STATUS == orderColumn) {
				qOrder = " order by status";
			} else {
				qOrder = " order by userProfileRequestId";
			}
		} 
		if (qOrder.trim().length() == 0) {
			qOrder = " order by userProfileRequestId";
		}
		qOrder += " " + (UserProfileManagerConstants.ORDER_ASC.equalsIgnoreCase(order) ? UserProfileManagerConstants.ORDER_ASC : UserProfileManagerConstants.ORDER_DESC);
		
		logger.message("qOrder=" + qOrder);
		
		// NOT SUPPORTED BY DB2, so we are doing workaround.
		//qOrder += " LIMIT " + start + ", " + length;				
		qOrder += " FETCH FIRST " + (start + length) + " ROWS ONLY";
		
		if (id == null && userProfileId == null && (name == null || name.trim().length() == 0) && status == null) {
			return jdbcTemplate.query(SQL_GET_ALL + " where 1=1 " +  qOrder, new UserProfileRequestMapper());
		}
		// We have filter(s) selected, so apply them.
		String qWhere = "";
		List<Object> filters = new ArrayList<>();
		if (id != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "userProfileRequestId = ?";
			filters.add(id);
		}
		if (userProfileId != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "userProfileId = ?";
			filters.add(userProfileId);
		}
		if (name != null && name.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "(LOWER(nameAndLegalForm) LIKE ?";
			filters.add("%" + name.toLowerCase() + "%");
			qWhere += " OR LOWER(names) LIKE ?)";
			filters.add("%" + name.toLowerCase() + "%");
		}
		if (status != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "status = ?";
			filters.add(status);
		}
		return jdbcTemplate.query(SQL_GET_ALL + qWhere + qOrder, filters.toArray(new Object[filters.size()]), new UserProfileRequestMapper());
	}
	
	public UserProfile getUserProfileById(final Long userProfileId) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_PROFILE, new Object[] { userProfileId }, new UserProfileMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public UserProfile getUserProfileByEIK(final String eik) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_PROFILE_BY_EIK, new Object[] { eik }, new UserProfileMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public UserProfilePersonalParameters getUserProfilePersonalParameters(final Long userProfileId) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_PERSONAL_PARAMETERS_BY_USER_PROFILEID, new Object[] { userProfileId }, new UserProfilePersonalParametersMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public List<UserProfileRef> getAllUserProfileRefByParentUserProfileId(final Long userProfileId) {
		try {
			return jdbcTemplate.query(SQL_FIND_PROFILE_REFS_BY_PARENT_USER_PROFILEID, new Object[] { userProfileId }, new UserProfileRefMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public List<UserProfile> getAllUserProfilesByIds(List<Long> userProfileIds) {
		String inSql = String.join(",", Collections.nCopies(userProfileIds.size(), "?"));	
		return jdbcTemplate.query(String.format(SQL_GET_ALL_USER_PROFILES_BY_IDS, inSql), userProfileIds.toArray(), new UserProfileMapper());
	}
	
	public List<UserProfile> getAllUserProfilesByIdsAndStatus(final List<Long> userProfileIds, final Integer profileStatus) {
		String inSql = String.join(",", Collections.nCopies(userProfileIds.size(), "?"));	
		Object[] objArr = new Object[userProfileIds.size() + 1];		
		for (int i = 0; i < userProfileIds.size(); i++) {
			objArr[i] = userProfileIds.get(i);
		}
		objArr[userProfileIds.size()] = profileStatus;
		return jdbcTemplate.query(String.format(SQL_FIND_PROFILE_BY_PROFILE_IDS_AND_STATUS, inSql), objArr, new UserProfileMapper());
	}
	
	private synchronized Long getUserProfleSequenceNextVal() {		
		return jdbcTemplate.queryForObject(SQL_SELECT_USER_PROFILE_SEQUENCE_NEXT_VAL + " where 1=1", Long.class);
	} // getNextVal
	
	private synchronized Long getUserProfleRoleSequenceNextVal() {		
		return jdbcTemplate.queryForObject(SQL_SELECT_USER_PROFILE_ROLE_SEQUENCE_NEXT_VAL + " where 1=1", Long.class);
	} // getNextVal

	private synchronized Long getUserProfleRefSequenceNextVal() {		
		return jdbcTemplate.queryForObject(SQL_SELECT_USER_PROFILE_REF_SEQUENCE_NEXT_VAL + " where 1=1", Long.class);
	} // getNextVal

	private synchronized Long getLEREIKNextVal(String eik) {		
		Object[] values = new Object[1];
		values[0] = eik + "%";		
		return jdbcTemplate.queryForObject(eik.length() == 13 ? SQL_SELECT_LEGAL_ENTITY_REIK_13_NEXT_VAL : SQL_SELECT_LEGAL_ENTITY_REIK_9_NEXT_VAL, values, Long.class);
	} // getNextVal

	public UserProfile approveUserProfileRequest(UserProfileRequest userProfileRequest, String profileStructureType, Date currentDate) {
		userProfileRequest.setDateApproved(currentDate);
		TransactionDefinition def = new DefaultTransactionDefinition();
	    TransactionStatus status = transactionManager.getTransaction(def);
		
	    try {
			// Update request.
			if (jdbcTemplate.update(SQL_APPROVE_USER_PROFILE_REQUEST, UserProfileManagerConstants.USER_PROFILE_REQUEST_STATUS_APPROVED, userProfileRequest.getDateApproved(), userProfileRequest.getUserProfileRequestId()) > 0) {
				boolean isREIKRequest = userProfileRequest.getLeUserProfileId() != null && userProfileRequest.getLeUserProfileId() > 0;
				UserProfile personalProfile = getUserProfileById(userProfileRequest.getUserProfileId());
				String email = null;
				if (personalProfile != null) {
					UserProfilePersonalParameters personalParameters = getUserProfilePersonalParameters(personalProfile.getUserProfileId());
					email = personalParameters != null ? personalParameters.getEmail() : null;
				}
				// Search for profile ONLY for regular request, skip for REIK.
				UserProfile userProfile = !isREIKRequest ? getUserProfileByEIK(userProfileRequest.getEik()) : null;
				// Search for groupId ONLY for regular request, skip for REIK.
				String groupId = !isREIKRequest ? (EgovWCMCache.getServiceProviderByEIK().get(userProfileRequest.getEik()) != null ? EgovWCMCache.getServiceProviderByEIK().get(userProfileRequest.getEik()).getName() : null) : null;
				// Set roles.
				Integer editor = null;
				Integer serviceManager = null;
				if (UserProfileManagerConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER == userProfileRequest.getProfileType()) {
					editor = UserProfileManagerConstants.USER_PROFILE_ROLE_SELECTED;
					serviceManager = UserProfileManagerConstants.USER_PROFILE_ROLE_SELECTED;
				}
				Long userProfileRoleId = null;
				Long reikSeq = null;
				// Populate userProfile object to create the corresponding profile.
				if (userProfile == null) {
					// We generate the REIK sequence, before the new profile was added to the DB!
					if (userProfileRequest.getLeUserProfileId() != null && userProfileRequest.getLeUserProfileId() > 0) {						
						reikSeq = getLEREIKNextVal(userProfileRequest.getEik());
					}					
					
					userProfile = new UserProfile();				
					Long userProfileId = getUserProfleSequenceNextVal();
					userProfile.setUserProfileId(userProfileId);	
					userProfile.setUserUID(personalProfile.getUserUID());
					userProfile.setIdentifier(personalProfile.getIdentifier());
					userProfile.setIdentifierPrefix(personalProfile.getIdentifierPrefix());
					userProfile.setNames(personalProfile.getNames());
					userProfile.setEik(userProfileRequest.getEik());
					userProfile.setNameAndLegalForm(userProfileRequest.getNameAndLegalForm());
					userProfile.setProfileType(userProfileRequest.getProfileType());
					userProfile.setProfileStructureType(profileStructureType);					
					userProfile.setDateCreated(currentDate);
					userProfile.setDateModified(currentDate);
					userProfile.setGroupId(groupId);
					userProfile.setStatus(UserProfileManagerConstants.USER_PROFILE_STATUS_ACTIVE);					
					jdbcTemplate.update(SQL_CREATE_USER_PROFILE, new Object[] { 
							userProfile.getUserProfileId(),
							userProfile.getUserUID(),
							userProfile.getIdentifier(),
							userProfile.getIdentifierPrefix(),
							userProfile.getNames(),
							userProfile.getEik(),
							userProfile.getNameAndLegalForm(),
							userProfile.getProfileType(),
							userProfile.getProfileStructureType(),
							userProfile.getDateCreated(),
							userProfile.getDateModified(),
							userProfile.getGroupId(),
							userProfile.getStatus() 					
					});				
					logger.message("Generated userProfileId - " + userProfileId);
					if (userProfileRequest.getLeUserProfileId() != null && userProfileRequest.getLeUserProfileId() > 0) {
						Long userProfileRefId = getUserProfleRefSequenceNextVal();
						logger.message("Generated reikSeq - " + reikSeq);
						String reik = utils.generateREIK(userProfileRequest.getEik(), String.valueOf(reikSeq));
						UserProfileRef userProfileRef = new UserProfileRef();
						userProfileRef.setUserProfileRefId(userProfileRefId);
						userProfileRef.setUserProfileId(userProfileId); 
						userProfileRef.setReik(reik);
						userProfileRef.setEik(userProfileRequest.getEik());
						userProfileRef.setParentUserProfileId(userProfileRequest.getLeUserProfileId());
						// TODO load from userProfileRef table the record for the parent, to build the whole tree.
						userProfileRef.setParentUserProfileIds(String.valueOf(userProfileRequest.getLeUserProfileId()));
						jdbcTemplate.update(SQL_CREATE_USER_PROFILE_REF, new Object[] { 
								userProfileRef.getUserProfileRefId(),
								userProfileRef.getUserProfileId(),
								userProfileRef.getReik(),
								userProfileRef.getEik(),
								userProfileRef.getParentUserProfileId(),
								userProfileRef.getParentUserProfileIds() 					
						});
						logger.message("Generated userProfileRefId - " + userProfileRefId);
						userProfile.setEik(reik);
						// Update user profile's EIK with the generated REIK.
						jdbcTemplate.update(
								SQL_UPDATE_USER_PROFILE_EIK,
								userProfile.getEik(),
								userProfileId);
						// Populate the request with the generated REIK.
						jdbcTemplate.update(
								SQL_UPDATE_USER_PROFILE_REQUEST_REIK,
								reik,
								userProfileRequest.getUserProfileRequestId());
					}
				} else if (UserProfileManagerConstants.USER_PROFILE_STATUS_ACTIVE != userProfile.getStatus()) {
					// If LE was deactivated, make it active again.
					jdbcTemplate.update(
							SQL_UPDATE_USER_PROFILE_STATUS, 
							personalProfile.getUserUID(),
							personalProfile.getNames(),
							personalProfile.getIdentifier(),
							personalProfile.getIdentifierPrefix(),
							UserProfileManagerConstants.USER_PROFILE_STATUS_ACTIVE, 
							null, 
							currentDate, 				 
							userProfile.getUserProfileId());
					// Check we have sub-profiles.
					List<UserProfileRef> userProfileRefs = getAllUserProfileRefByParentUserProfileId(userProfileRequest.getUserProfileId());
					if (userProfileRefs != null && userProfileRefs.size() > 0) {
						List<Long> userProfileIds = new ArrayList<Long>();
						for (int i = 0; i < userProfileRefs.size(); i++) {
							userProfileIds.add(userProfileRefs.get(i).getUserProfileId());
						}
						List<UserProfile> subProfiles = getAllUserProfilesByIdsAndStatus(userProfileIds, UserProfileManagerConstants.USER_PROFILE_STATUS_INACTIVE);
						if (subProfiles != null && subProfiles.size() > 0) {
							for (int i = 0; i < subProfiles.size(); i++) {
								// Activate the sub-profile.
								jdbcTemplate.update(
										SQL_UPDATE_USER_PROFILE_STATUS, 
										personalProfile.getUserUID(),
										personalProfile.getNames(),
										personalProfile.getIdentifier(),
										personalProfile.getIdentifierPrefix(),
										UserProfileManagerConstants.USER_PROFILE_STATUS_ACTIVE, 
										null, 
										currentDate, 				 
										subProfiles.get(i).getUserProfileId());
								// Add current user access (sub-profiles have same profile type as the parent).
								userProfileRoleId = getUserProfleRoleSequenceNextVal();								
								jdbcTemplate.update(SQL_CREATE_USER_PROFILE_ROLE, new Object[] { 
										userProfileRoleId,
										subProfiles.get(i).getUserProfileId(),
										personalProfile.getUserUID(),
										UserProfileManagerConstants.USER_PROFILE_ROLE_SELECTED,
										editor,
										serviceManager,
										UserProfileManagerConstants.USER_PROFILE_ROLE_SELECTED,
										currentDate,
										email,
										UserProfileManagerConstants.USER_PROFILE_CHANGE_EMAIL_CONFIRMED
								});	
							}
						}
					}
				}
				// Add current user access.
				userProfileRoleId = getUserProfleRoleSequenceNextVal();								
				jdbcTemplate.update(SQL_CREATE_USER_PROFILE_ROLE, new Object[] { 
						userProfileRoleId,
						userProfile.getUserProfileId(),
						personalProfile.getUserUID(),
						UserProfileManagerConstants.USER_PROFILE_ROLE_SELECTED,
						editor,
						serviceManager,
						UserProfileManagerConstants.USER_PROFILE_ROLE_SELECTED,
						currentDate,
						email,
						UserProfileManagerConstants.USER_PROFILE_CHANGE_EMAIL_CONFIRMED
				});	
				transactionManager.commit(status);
				return userProfile;
			}
		} catch (Exception e) {
			e.printStackTrace();
			transactionManager.rollback(status);
		}
		return null;
	}
	
	public boolean cancelUserProfileRequest(UserProfileRequest userProfileRequest) {
		return jdbcTemplate.update(
				SQL_CANCEL_USER_PROFILE_REQUEST, 
				UserProfileManagerConstants.USER_PROFILE_REQUEST_STATUS_CANCELED, 
				userProfileRequest.getDateCanceled(), 
				userProfileRequest.getCancelReason(), 
				userProfileRequest.getUserProfileRequestId()) > 0;		
	}
	
	public boolean deleteUserProfileRequest(UserProfileRequest userProfileRequest) {		
		return jdbcTemplate.update(SQL_DELETE_USER_PROFILE_REQUEST, userProfileRequest.getUserProfileRequestId()) > 0;		
	}
	
}
