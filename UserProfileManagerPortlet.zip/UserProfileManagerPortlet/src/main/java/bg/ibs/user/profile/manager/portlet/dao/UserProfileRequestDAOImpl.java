package bg.ibs.user.profile.manager.portlet.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Description;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.egov.wcm.cache.EgovWCMCache;

import bg.ibs.user.profile.manager.portlet.UserProfileManagerConstants;
import bg.ibs.user.profile.manager.portlet.model.UserProfile;
import bg.ibs.user.profile.manager.portlet.model.UserProfileMapper;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRequest;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRequestFileMapper;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRequestMapper;
import bg.ibs.user.profile.manager.portlet.utils.UserProfileManagerLogger;

@Description("This class uses transaction from this article: https://www.tutorialspoint.com/spring/programmatic_management.htm")
@Repository("UserProfileRequestDAO")
public class UserProfileRequestDAOImpl implements UserProfileRequestDAO { 
	private static final String TABLE_NAME = "UserProfileRequest";
	private static final String TABLE_USER_PROFILE_NAME = "UserProfile";
	private static final String TABLE_USER_PROFILE_ROLE_NAME = "UserProfileRole";
	private static final String USER_PROFILE_SEQUENCE_NAME = "SEQ_USERPROFILE";
	private static final String USER_PROFILE_ROLE_SEQUENCE_NAME = "SEQ_USERPROFILEROLE";
	
	private final JdbcTemplate jdbcTemplate;
	
	@Autowired
	private PlatformTransactionManager transactionManager;
	
	@Autowired
	UserProfileManagerLogger logger;	

	private final String SQL_FIND_USER_PROFILE_REQUEST = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userProfileRequestId = ?";
	private final String SQL_FIND_USER_PROFILE_REQUEST_FOR_PROFILE = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userUID = ? AND eik = ? AND status = ? order by dateApproved desc";
	private final String SQL_FIND_USER_PROFILE_REQUEST_FILE = "select orderDocument,orderDocumentName,orderDocumentSize,orderDocumentContentType from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userProfileRequestId = ?";
	private final String SQL_COUNT = "select count(userProfileRequestId) from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME;
	private final String SQL_GET_ALL = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME;
	private final String SQL_FIND_PROFILE = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_NAME + " where userProfileId = ?";
	private final String SQL_FIND_PROFILE_BY_EIK = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_NAME + " where eik = ?";
	private final String SQL_SELECT_USER_PROFILE_SEQUENCE_NEXT_VAL = "select next value for " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + USER_PROFILE_SEQUENCE_NAME + " from SYSIBM.SYSDUMMY1";
	private final String SQL_SELECT_USER_PROFILE_ROLE_SEQUENCE_NEXT_VAL = "select next value for " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + USER_PROFILE_ROLE_SEQUENCE_NAME + " from SYSIBM.SYSDUMMY1";
	private final String SQL_APPROVE_USER_PROFILE_REQUEST = "update " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " set status = ?, dateApproved = ? where userProfileRequestId = ?";
	private final String SQL_CREATE_USER_PROFILE = "insert into " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_NAME + " (userProfileId, userUID, identifier, names, eik, nameAndLegalForm, profileType, profileStructureType, dateCreated, dateModified, groupId, status) values (?,?,?,?,?,?,?,?,?,?,?,?)";
	private final String SQL_CREATE_USER_PROFILE_ROLE = "insert into " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_ROLE_NAME + " (userProfileRoleId, userProfileId, userUID, admin, editor, serviceManager, dateCreated) values (?,?,?,?,?,?,?)";
	private final String SQL_CANCEL_USER_PROFILE_REQUEST = "update " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " set status = ?, dateCanceled = ?, cancelReason = ? where userProfileRequestId = ?";
	private final String SQL_DELETE_USER_PROFILE_REQUEST = "delete from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userProfileRequestId = ?";

	@Autowired
	public UserProfileRequestDAOImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		//transactionTemplate = new TransactionTemplate();
	}

	public UserProfileRequest getUserProfileRequestById(final Long userProfileRequestId) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_USER_PROFILE_REQUEST, new Object[] { userProfileRequestId }, new UserProfileRequestMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public UserProfileRequest getLastUserProfileRequestByUserUIDAndEIK(final String userUID, final String eik) {
		try {
			List<UserProfileRequest> requests = jdbcTemplate.query(SQL_FIND_USER_PROFILE_REQUEST_FOR_PROFILE, new Object[] { userUID, eik, UserProfileManagerConstants.USER_PROFILE_REQUEST_STATUS_APPROVED }, new UserProfileRequestMapper());
			if (requests != null && requests.size() > 0) {
				return requests.get(0);
			}
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
		return null;
	}
	
	public UserProfileRequest getUserProfileRequestFileById(final Long userProfileRequestId) {
		try {			
			return jdbcTemplate.queryForObject(SQL_FIND_USER_PROFILE_REQUEST_FILE, new Object[] { userProfileRequestId }, new UserProfileRequestFileMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	public List<UserProfileRequest> getAllUserProfileRequests() {
		return jdbcTemplate.query(SQL_GET_ALL + " where 1=1", new UserProfileRequestMapper());
	}
	
	public List<UserProfileRequest> getAllUserProfileRequestsByUserProfileId(Long userProfileId) {
		return jdbcTemplate.query(SQL_GET_ALL + " where userProfileId = ? ", new Object[] {userProfileId} , new UserProfileRequestMapper());
	}
	
	public Integer countUserProfileRequestsByFilter(final Long id, final Long userProfileId, final String name, final Integer status) {
		if (id == null && userProfileId == null && (name == null || name.trim().length() == 0) && status == null) {
			return jdbcTemplate.queryForObject(SQL_COUNT + " where 1=1", Integer.class);
		}
		// We have filter(s) selected, so apply them.
		String qWhere = "";
		List<Object> filters = new ArrayList<>();
		if (id != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "userProfileRequestId = ?";
			filters.add(id);
		}
		if (userProfileId != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "userProfileId = ?";
			filters.add(userProfileId);
		}
		if (name != null && name.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "(LOWER(nameAndLegalForm) LIKE ?";
			filters.add("%" + name.toLowerCase() + "%");
			qWhere += " OR LOWER(names) LIKE ?)";
			filters.add("%" + name.toLowerCase() + "%");
		}
		if (status != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "status = ?";
			filters.add(status);
		}
		return jdbcTemplate.queryForObject(SQL_COUNT + qWhere, filters.toArray(new Object[filters.size()]), Integer.class);
	}
	
	public List<UserProfileRequest> getAllUserProfileRequestsByFilter(final Long id, final Long userProfileId, final String name, final Integer status, final Integer start, final Integer length, final Integer orderColumn, final String order) {
		String qOrder = "";
		if (orderColumn != null) {
			if (UserProfileManagerConstants.COLUMN_ID == orderColumn) {
				qOrder = " order by userProfileRequestId";
			} else if (UserProfileManagerConstants.COLUMN_REQUEST_PROFILE_NUMBER == orderColumn) {
				qOrder = " order by userProfileId";
			} else if (UserProfileManagerConstants.COLUMN_REQUEST_PROFILE_TYPE == orderColumn) {
				qOrder = " order by profileType";
			} else if (UserProfileManagerConstants.COLUMN_REQUEST_EIK == orderColumn) {
				qOrder = " order by eik";
			} else if (UserProfileManagerConstants.COLUMN_REQUEST_NAME_AND_LEGAL_FORM == orderColumn) {
				qOrder = " order by nameAndLegalForm";
			} else if (UserProfileManagerConstants.COLUMN_REQUEST_NAMES == orderColumn) {
				qOrder = " order by names";
			} else if (UserProfileManagerConstants.COLUMN_REQUEST_DATE_CREATED == orderColumn) {
				qOrder = " order by dateCreated";
			} else if (UserProfileManagerConstants.COLUMN_REQUEST_DATE_APPROVED == orderColumn) {
				if (status != null && UserProfileManagerConstants.USER_PROFILE_REQUEST_STATUS_CANCELED == status) {
					qOrder = " order by dateCanceled";
				} else {
					qOrder = " order by dateApproved";
				}	
			} else if (UserProfileManagerConstants.COLUMN_REQUEST_STATUS == orderColumn) {
				qOrder = " order by status";
			} else {
				qOrder = " order by userProfileRequestId";
			}
		} 
		if (qOrder.trim().length() == 0) {
			qOrder = " order by userProfileRequestId";
		}
		qOrder += " " + (UserProfileManagerConstants.ORDER_ASC.equalsIgnoreCase(order) ? UserProfileManagerConstants.ORDER_ASC : UserProfileManagerConstants.ORDER_DESC);
		
		logger.message("qOrder=" + qOrder);
		
		// NOT SUPPORTED BY DB2, so we are doing workaround.
		//qOrder += " LIMIT " + start + ", " + length;				
		qOrder += " FETCH FIRST " + (start + length) + " ROWS ONLY";
		
		if (id == null && userProfileId == null && (name == null || name.trim().length() == 0) && status == null) {
			return jdbcTemplate.query(SQL_GET_ALL + " where 1=1 " +  qOrder, new UserProfileRequestMapper());
		}
		// We have filter(s) selected, so apply them.
		String qWhere = "";
		List<Object> filters = new ArrayList<>();
		if (id != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "userProfileRequestId = ?";
			filters.add(id);
		}
		if (userProfileId != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "userProfileId = ?";
			filters.add(userProfileId);
		}
		if (name != null && name.trim().length() > 0) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "(LOWER(nameAndLegalForm) LIKE ?";
			filters.add("%" + name.toLowerCase() + "%");
			qWhere += " OR LOWER(names) LIKE ?)";
			filters.add("%" + name.toLowerCase() + "%");
		}
		if (status != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "status = ?";
			filters.add(status);
		}
		return jdbcTemplate.query(SQL_GET_ALL + qWhere + qOrder, filters.toArray(new Object[filters.size()]), new UserProfileRequestMapper());
	}
	
	public UserProfile getUserProfileById(final Long userProfileId) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_PROFILE, new Object[] { userProfileId }, new UserProfileMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public UserProfile getUserProfileByEIK(final String eik) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_PROFILE_BY_EIK, new Object[] { eik }, new UserProfileMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	private synchronized Long getUserProfleSequenceNextVal() {		
		return jdbcTemplate.queryForObject(SQL_SELECT_USER_PROFILE_SEQUENCE_NEXT_VAL + " where 1=1", Long.class);
	} // getNextVal
	
	private synchronized Long getUserProfleRoleSequenceNextVal() {		
		return jdbcTemplate.queryForObject(SQL_SELECT_USER_PROFILE_ROLE_SEQUENCE_NEXT_VAL + " where 1=1", Long.class);
	} // getNextVal

	public UserProfile approveUserProfileRequest(UserProfileRequest userProfileRequest, String profileStructureType) {
		Date currentDate = new Date();
		userProfileRequest.setDateApproved(currentDate);
		TransactionDefinition def = new DefaultTransactionDefinition();
	    TransactionStatus status = transactionManager.getTransaction(def);
		
	    try {
			// Update request.
			if (jdbcTemplate.update(SQL_APPROVE_USER_PROFILE_REQUEST, UserProfileManagerConstants.USER_PROFILE_REQUEST_STATUS_APPROVED, userProfileRequest.getDateApproved(), userProfileRequest.getUserProfileRequestId()) > 0) {
				UserProfile originProfile = getUserProfileById(userProfileRequest.getUserProfileId());
				UserProfile userProfile = getUserProfileByEIK(userProfileRequest.getEik());
				String groupId = EgovWCMCache.getServiceProviderByEIK().get(userProfileRequest.getEik()) != null ? EgovWCMCache.getServiceProviderByEIK().get(userProfileRequest.getEik()).getName() : null;
				// Populate userProfile object to create the corresponding profile.
				if (userProfile == null) {
					userProfile = new UserProfile();				
					Long userProfileId = getUserProfleSequenceNextVal();
					userProfile.setUserProfileId(userProfileId);	
					userProfile.setUserUID(originProfile.getUserUID());
					userProfile.setIdentifier(originProfile.getIdentifier());
					userProfile.setNames(originProfile.getNames());
					userProfile.setEik(userProfileRequest.getEik());
					userProfile.setNameAndLegalForm(userProfileRequest.getNameAndLegalForm());
					userProfile.setProfileType(userProfileRequest.getProfileType());
					userProfile.setProfileStructureType(profileStructureType);					
					userProfile.setDateCreated(currentDate);
					userProfile.setDateModified(currentDate);
					userProfile.setGroupId(groupId);
					userProfile.setStatus(UserProfileManagerConstants.STATUS_ACTIVE);
					jdbcTemplate.update(SQL_CREATE_USER_PROFILE, new Object[] { 
							userProfile.getUserProfileId(),
							userProfile.getUserUID(),
							userProfile.getIdentifier(),
							userProfile.getNames(),
							userProfile.getEik(),
							userProfile.getNameAndLegalForm(),
							userProfile.getProfileType(),
							userProfile.getProfileStructureType(),
							userProfile.getDateCreated(),
							userProfile.getDateModified(),
							userProfile.getGroupId(),
							userProfile.getStatus() 					
					});				
					logger.message("Generated id - " + userProfileId);
									
				}
				Long userProfileRoleId = getUserProfleRoleSequenceNextVal();
				Integer editor = null;
				Integer serviceManager = null;
				if (UserProfileManagerConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER == userProfileRequest.getProfileType()) {
					editor = UserProfileManagerConstants.USER_PROFILE_ROLE_SELECTED;
					serviceManager = UserProfileManagerConstants.USER_PROFILE_ROLE_SELECTED;
				}
				jdbcTemplate.update(SQL_CREATE_USER_PROFILE_ROLE, new Object[] { 
						userProfileRoleId,
						userProfile.getUserProfileId(),
						originProfile.getUserUID(),
						UserProfileManagerConstants.USER_PROFILE_ROLE_SELECTED,
						editor,
						serviceManager,
						currentDate
				});	
				transactionManager.commit(status);
				return userProfile;
			}
		} catch (Exception e) {
			e.printStackTrace();
			transactionManager.rollback(status);
		}
		return null;
	}
	
	public boolean cancelUserProfileRequest(UserProfileRequest userProfileRequest) {
		return jdbcTemplate.update(
				SQL_CANCEL_USER_PROFILE_REQUEST, 
				UserProfileManagerConstants.USER_PROFILE_REQUEST_STATUS_CANCELED, 
				userProfileRequest.getDateCanceled(), 
				userProfileRequest.getCancelReason(), 
				userProfileRequest.getUserProfileRequestId()) > 0;		
	}
	
	public boolean deleteUserProfileRequest(UserProfileRequest userProfileRequest) {		
		return jdbcTemplate.update(SQL_DELETE_USER_PROFILE_REQUEST, userProfileRequest.getUserProfileRequestId()) > 0;		
	}
	
}
