package bg.ibs.user.profile.manager.portlet.beans;

public class HorizontalSystemRoleESB {
	private String systemOID;
	private String uid;
	private String title;
	
	public String getSystemOID() {
		return systemOID;
	}
	public void setSystemOID(String systemOID) {
		this.systemOID = systemOID;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
}
