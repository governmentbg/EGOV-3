package bg.ibs.user.profile.manager.portlet.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class HorizontalSystemRole {
	@Id	
	private Long horizontalSystemRoleId;
	@Column(nullable = false)
	private String systemOID;
	@Column(nullable = false)
	private String uid;	
	private String title;
	@Column(name = "dateCreated", nullable = false, updatable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date dateCreated;
	@Column(name = "dateModified", nullable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateModified;
	
	public Long getHorizontalSystemRoleId() {
		return horizontalSystemRoleId;
	}
	public void setHorizontalSystemRoleId(Long horizontalSystemRoleId) {
		this.horizontalSystemRoleId = horizontalSystemRoleId;
	}
	public String getSystemOID() {
		return systemOID;
	}
	public void setSystemOID(String systemOID) {
		this.systemOID = systemOID;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	public Date getDateModified() {
		return dateModified;
	}
	public void setDateModified(Date dateModified) {
		this.dateModified = dateModified;
	}
	
}
