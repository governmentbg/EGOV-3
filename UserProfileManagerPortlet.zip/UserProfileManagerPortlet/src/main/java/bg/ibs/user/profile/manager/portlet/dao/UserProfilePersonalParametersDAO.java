package bg.ibs.user.profile.manager.portlet.dao;

import bg.ibs.user.profile.manager.portlet.model.UserProfilePersonalParameters;

public interface UserProfilePersonalParametersDAO {	
	UserProfilePersonalParameters getUserProfilePersonalParametersByUserProfileId(Long userProfileId);	
}
