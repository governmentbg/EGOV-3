package bg.ibs.user.profile.manager.portlet.communicator;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.ibs.user.profile.manager.portlet.UserProfileManagerConstants;
import bg.ibs.user.profile.manager.portlet.controllers.PortletViewController;
import bg.ibs.user.profile.manager.portlet.utils.UserProfileManagerLogger;
import bg.ibs.user.profile.manager.portlet.utils.UserProfileManagerUtils;

@Component
public class EJournalCommunicator {
	
	
	@Autowired
	UserProfileManagerUtils utils;
	@Autowired
	UserProfileManagerLogger logger;
		
	public String sendRNU(String rnu, int stageId, int statusId, long operationTime) {	
		logger.message("EJournalCommunicator::sendRNU(" + rnu + "," + stageId + "," + statusId + "," + operationTime + ")");
		if (!"TEST".equalsIgnoreCase(System.getProperty("environmentType"))) {
			return "0";
		}
		String response = null;
		StringBuilder strBuf = new StringBuilder();	
		HttpURLConnection conn = null; 
		BufferedReader reader = null;
		boolean isProd = "PROD".equalsIgnoreCase(System.getProperty("environment"));
		String eJournalAddress = null;
		String jsonBody = ""					
				+ "{"
				+ "    \"serviceRefNumber\": \"" + rnu + "\","
				+ "    \"systemOID\": \"" + UserProfileManagerConstants.PORTAL_OID + "\","
				+ "    \"subjectId\": \"\","
				+ "    \"subjectIdType\": \"\","
				+ "    \"subjectIdName\": \"\","
				+ "    \"systemOIDowner\": \"" + UserProfileManagerConstants.E_JOURNAL_SYSTEM_OID_OWNER + "\","
				+ "    \"idStage\": \"" + stageId + "\",   "
				+ "    \"idService\": \"" + UserProfileManagerConstants.E_JOURNAL_ID_SERVICE_PARAM + "\",   "
				+ "    \"idStatus\": \"" + statusId + "\",   "
				+ "    \"infoRelatedService\": \"\",   "
				+ "    \"timeStatusChange\": \"" + utils.timeMillisToYYYY_MM_DD_HH_MM_SS(operationTime) +  "\""
				+ "}";
		try {
			eJournalAddress = isProd ? PortletViewController.eJournalAddressProd : PortletViewController.eJournalAddressTest; 
			URL url = new URL(eJournalAddress); 
			conn = (HttpURLConnection) url.openConnection();
			
			byte[] postData = jsonBody.getBytes(StandardCharsets.UTF_8);
			int postDataLength = postData.length;	
			
			conn.setFixedLengthStreamingMode(postDataLength);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("Accept", "application/json");
			conn.setRequestProperty("Content-Length", Integer.toString(postDataLength));
			conn.setConnectTimeout(2000); //set timeout to 2 seconds
			conn.setReadTimeout(2000); //set timeout to 2 seconds
			conn.setDoOutput(true);
			conn.setUseCaches( false );
			
			try(OutputStream os = conn.getOutputStream()) {
				os.write(postData);
			}
			
			if (conn.getResponseCode() != 200) {
				System.err.println("ERROR calling -> [POST] eJournalAddress=" + eJournalAddress + " with jsonBody:" + jsonBody);
				throw new RuntimeException("HTTP POST Request Failed with Error code : " + conn.getResponseCode());
			}
			
			reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
			String output = null;
			while ((output = reader.readLine()) != null) {
				strBuf.append(output);
			}
			response = strBuf.toString();
			logger.message("EJournalCommunicator::sendRNU response:" + response);
            if (response != null && response.trim().length() > 0) {
            	 JSONObject jo = new JSONObject(response);            
                 if (jo != null && jo.has("id")) {
                	 return jo.get("id").toString();
                 }
            }
		} catch (SocketTimeoutException e) {
			System.err.println("ERROR calling -> [POST] eJournalAddress=" + eJournalAddress + " with jsonBody:" + jsonBody);
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				conn.disconnect();
			}
		}
		return null;
	}
}
