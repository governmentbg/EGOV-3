package bg.ibs.user.profile.manager.portlet.model;

import java.io.InputStream;
import java.sql.Blob;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import bg.ibs.user.profile.manager.portlet.utils.ByteBuffer;

public class UserProfileRequestFileMapper implements RowMapper<UserProfileRequest> {

	public UserProfileRequest mapRow(ResultSet resultSet, int i) throws SQLException {

		UserProfileRequest request = new UserProfileRequest();
		Blob blob = resultSet.getBlob("orderDocument");
		if (blob != null) {
			InputStream inputStream = null;
			try {
				inputStream = blob.getBinaryStream(); 
			    ByteBuffer bbuffer = new ByteBuffer();
				int bytesread = 0;
				byte[] tmparr = new byte[1024];
				while (-1 != (bytesread = inputStream.read(tmparr, 0, 1024))) {
					bbuffer.append(tmparr, bytesread);
				}
				request.setOrderDocument(bbuffer.getBytes());
				inputStream.close();
			} catch (Exception e) {
				try {
					if (inputStream != null) {
						inputStream.close();
					}
				} catch (Exception e2) {}
				e.printStackTrace();				
			}
			request.setOrderDocumentName(resultSet.getString("orderDocumentName"));
			request.setOrderDocumentSize(resultSet.getInt("orderDocumentSize"));
			request.setOrderDocumentContentType(resultSet.getString("orderDocumentContentType"));
		}
		return request;
	}
}
