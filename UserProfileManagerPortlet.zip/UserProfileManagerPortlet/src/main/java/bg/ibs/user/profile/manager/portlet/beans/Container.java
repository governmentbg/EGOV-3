package bg.ibs.user.profile.manager.portlet.beans;

import bg.ibs.user.profile.manager.portlet.UserProfileManagerConstants;

public class Container {
	
	private int currentTab = UserProfileManagerConstants.TAB_REQUESTS;
	private int currentView = UserProfileManagerConstants.VIEW_HORIZONTAL_SYSTEMS;
	private String systemOID = null;
	private Long filterId = null;
	private Long filterUserProfileId = null;
	private String filterUserUID = null;
	private String filterName = null;
	private Integer filterType = null;
	private Integer filterStructureType = null;
	private Integer filterStatus = null;
	private String filterDateFrom = null;
	private String filterDateTo = null;
	private boolean filterInitialised;
	private int resultsPerPage = 0;
	private int start = 0;
	private int orderColumn = UserProfileManagerConstants.COLUMN_ID;
	private String order = UserProfileManagerConstants.ORDER_DESC;	
	
	public int getCurrentTab() {
		return currentTab;
	}

	public void setCurrentTab(int currentTab) {
		this.currentTab = currentTab;
	}

	public int getCurrentView() {
		return currentView;
	}

	public void setCurrentView(int currentView) {
		this.currentView = currentView;
	}

	public String getSystemOID() {
		return systemOID;
	}

	public void setSystemOID(String systemOID) {
		this.systemOID = systemOID;
	}

	public Long getFilterId() {
		return filterId;
	}

	public void setFilterId(Long filterId) {
		this.filterId = filterId;
	}

	public Long getFilterUserProfileId() {
		return filterUserProfileId;
	}

	public void setFilterUserProfileId(Long filterUserProfileId) {
		this.filterUserProfileId = filterUserProfileId;
	}

	public String getFilterUserUID() {
		return filterUserUID;
	}

	public void setFilterUserUID(String filterUserUID) {
		this.filterUserUID = filterUserUID;
	}

	public String getFilterName() {
		return filterName;
	}

	public void setFilterName(String filterName) {
		this.filterName = filterName;
	}

	public Integer getFilterType() {
		return filterType;
	}

	public void setFilterType(Integer filterType) {
		this.filterType = filterType;
	}

	public Integer getFilterStructureType() {
		return filterStructureType;
	}

	public void setFilterStructureType(Integer filterStructureType) {
		this.filterStructureType = filterStructureType;
	}

	public Integer getFilterStatus() {
		return filterStatus;
	}

	public void setFilterStatus(Integer filterStatus) {
		this.filterStatus = filterStatus;
	}

	public String getFilterDateFrom() {
		return filterDateFrom;
	}

	public void setFilterDateFrom(String filterDateFrom) {
		this.filterDateFrom = filterDateFrom;
	}

	public String getFilterDateTo() {
		return filterDateTo;
	}

	public void setFilterDateTo(String filterDateTo) {
		this.filterDateTo = filterDateTo;
	}

	public boolean isFilterInitialised() {
		return filterInitialised;
	}

	public void setFilterInitialised(boolean filterInitialised) {
		this.filterInitialised = filterInitialised;
	}

	public int getResultsPerPage() {
		return resultsPerPage;
	}

	public void setResultsPerPage(int resultsPerPage) {
		this.resultsPerPage = resultsPerPage;
	}

	public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getOrderColumn() {
		return orderColumn;
	}

	public void setOrderColumn(int orderColumn) {
		this.orderColumn = orderColumn;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

}

