package bg.ibs.user.profile.manager.portlet.controllers;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequest;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.portlet.ModelAndView;
import org.springframework.web.portlet.bind.annotation.ActionMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;
import org.springframework.web.portlet.bind.annotation.ResourceMapping;

import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.portal.um.PumaHome;
import com.ibm.portal.um.User;
import com.ibm.portal.um.exceptions.PumaException;

import bg.ibs.user.profile.manager.portlet.UserProfileManagerConstants;
import bg.ibs.user.profile.manager.portlet.UserProfileNotificationManager;
import bg.ibs.user.profile.manager.portlet.beans.Container;
import bg.ibs.user.profile.manager.portlet.beans.HorizontalSystem;
import bg.ibs.user.profile.manager.portlet.beans.UserProfileManagerSessionBean;
import bg.ibs.user.profile.manager.portlet.communicator.EJournalCommunicator;
import bg.ibs.user.profile.manager.portlet.communicator.ESBCommunicator;
import bg.ibs.user.profile.manager.portlet.communicator.PumaCommunicator;
import bg.ibs.user.profile.manager.portlet.communicator.WCMCommunicator;
import bg.ibs.user.profile.manager.portlet.model.HorizontalSystemRole;
import bg.ibs.user.profile.manager.portlet.model.UserProfile;
import bg.ibs.user.profile.manager.portlet.model.UserProfileAndRole;
import bg.ibs.user.profile.manager.portlet.model.UserProfilePersonalParameters;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRef;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRequest;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRole;
import bg.ibs.user.profile.manager.portlet.service.HorizontalSystemRoleService;
import bg.ibs.user.profile.manager.portlet.service.UserProfilePersonalParametersService;
import bg.ibs.user.profile.manager.portlet.service.UserProfileRefService;
import bg.ibs.user.profile.manager.portlet.service.UserProfileRequestService;
import bg.ibs.user.profile.manager.portlet.service.UserProfileRoleService;
import bg.ibs.user.profile.manager.portlet.service.UserProfileService;
import bg.ibs.user.profile.manager.portlet.utils.EncryptorAESGCM;
import bg.ibs.user.profile.manager.portlet.utils.UserProfileManagerLogger;
import bg.ibs.user.profile.manager.portlet.utils.UserProfileManagerUtils;

@Controller
@RequestMapping("view")
public class PortletViewController {
	
	@Resource(name = "sessionScopedBean")
	UserProfileManagerSessionBean sessionBean;
	
	@Resource(name = "messageSource")
	private MessageSource messageSource;
	
	@Autowired
	UserProfileManagerLogger logger;
	@Autowired
	PumaCommunicator pumaCommunicator;
	@Autowired
	WCMCommunicator wcmCommunicator;
	@Autowired
	ESBCommunicator esbCommunicator;
	@Autowired
	EJournalCommunicator eJournalCommunicator;
	@Autowired
	UserProfileNotificationManager notificationManager;
	@Autowired
	UserProfileManagerUtils utils;

	@Autowired
	UserProfileRequestService userProfileRequestService;
	@Autowired
	UserProfilePersonalParametersService userProfilePersonalParametersService;
	@Autowired
	UserProfileRoleService userProfileRoleService;
	@Autowired
	HorizontalSystemRoleService hsRoleService;
	@Autowired
	UserProfileRefService userProfileRefService;
	@Autowired
	UserProfileService userProfileService;
	
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	
	private static PumaHome pumaHome = null;
	public static String eJournalAddressProd = UserProfileManagerConstants.E_JOURNAL_ADDRESS_PROD;
	public static String eJournalAddressTest = UserProfileManagerConstants.E_JOURNAL_ADDRESS_TEST;
	public static int resultsPerPage = UserProfileManagerConstants.RESULTS_PER_PAGE;
	public static String language = UserProfileManagerConstants.LANGUAGE_BG;
	public static String esbEventLogAddress = UserProfileManagerConstants.ESB_LOGGING_URL;
	public static String mailSmtpHost = UserProfileManagerConstants.MAIL_SMTP_HOST;
	public static String fromAddress = UserProfileManagerConstants.MAIL_FROM_ADDRESS;
	public static boolean isDebug = false;		
	
	
	@PostConstruct
	public void init() {
		InitialContext initialcontext;
		try {
			initialcontext = new InitialContext();
			pumaHome = (PumaHome) initialcontext.lookup("portal:service/usermanagement/Puma");
		} catch (NamingException namingexception) {
			namingexception.printStackTrace();
		}
	}
	
	@RenderMapping
	public ModelAndView defaultView(RenderRequest renderRequest, RenderResponse renderResponse) {
		loadPreferences(renderRequest);
		
		if (!sessionBean.isInitialised()) {
			intializeBean();
		}
		
		String currentPage = sessionBean.getCurrentPage();
		ModelAndView mv = new ModelAndView(currentPage);
		mv.addObject("userUID", sessionBean.getUserUID());					
		mv.addObject("language", language);					
		// Populate "ModelAndView" accordingly.
		if (UserProfileManagerConstants.INDEX_PAGE.equals(currentPage)) {
			Integer currentTab = sessionBean.getTabPerPage().get(currentPage);
			String uniquePath = "";
			uniquePath = currentPage + currentTab;
			Integer currentView = null;
			if (UserProfileManagerConstants.TAB_HS_ROLES == currentTab) {
				currentView = sessionBean.getViewPerTab().get(uniquePath);
				if (currentView == null) {
					// Initialize view.
					currentView = UserProfileManagerConstants.VIEW_HORIZONTAL_SYSTEMS;
					HashMap<String, Integer> viewPerTab = sessionBean.getViewPerTab();
					viewPerTab.put(uniquePath, currentView);
					sessionBean.setViewPerTab(viewPerTab);
				}
				uniquePath = currentPage + currentTab + currentView;
			}
			Container container = sessionBean.getContainer().get(uniquePath);			
			if (container == null) {
				container = new Container();
				container.setStart(0);
				container.setResultsPerPage(resultsPerPage);
				if (UserProfileManagerConstants.TAB_REQUESTS == currentTab) {					 
					container.setFilterStatus(UserProfileManagerConstants.USER_PROFILE_REQUEST_STATUS_NOT_APPROVED);
				}
				sessionBean.getContainer().put(uniquePath, container);
			}
			mv.addObject("currentTab", currentTab);
			
			if (UserProfileManagerConstants.TAB_REQUESTS == currentTab) {
				mv.addObject("filterId", container.getFilterId());
				mv.addObject("filterUserProfileId", container.getFilterUserProfileId());
				mv.addObject("filterName", container.getFilterName());
				mv.addObject("filterStatus", container.getFilterStatus());
			} else if (UserProfileManagerConstants.TAB_PROFILES == currentTab) {
				mv.addObject("filterId", container.getFilterId());
				mv.addObject("filterProfileType", container.getFilterType());
				mv.addObject("filterProfileStructureType", container.getFilterStructureType());
				mv.addObject("filterUserUID", container.getFilterUserUID());
				mv.addObject("filterName", container.getFilterName());
				mv.addObject("filterStatus", container.getFilterStatus());	
				mv.addObject("filterDateFrom", container.getFilterDateFrom());			
				mv.addObject("filterDateTo", container.getFilterDateTo());			
			} else if (UserProfileManagerConstants.TAB_HS_ROLES == currentTab) {
				mv.addObject("currentView", currentView);	
				if (UserProfileManagerConstants.VIEW_HORIZONTAL_SYSTEMS == currentView) {
					List<HorizontalSystemRole> horizontalSystemRoles = hsRoleService.getAllDistinctSystemOID();
					if (horizontalSystemRoles != null && horizontalSystemRoles.size() > 0) {
						List<HorizontalSystem> hsList = new ArrayList<>();
						HorizontalSystem hs = null;
						for (int i = 0; i < horizontalSystemRoles.size(); i++) {
							hs = new HorizontalSystem();
							hs.setOid(horizontalSystemRoles.get(i).getSystemOID());
							// Hardcoded for now.
							hs.setName(utils.getSystemNameByOID(hs.getOid()));
							hsList.add(hs);
						}
						mv.addObject("allSystems", hsList);
					} else {
						mv.addObject("allSystems", new ArrayList<>());
					}
				} else if (UserProfileManagerConstants.VIEW_HORIZONTAL_SYSTEM_ROLES == currentView) {
					String currentHorizontalSystemName = utils.getSystemNameByOID(container.getSystemOID());
					mv.addObject("currentHorizontalSystemName", currentHorizontalSystemName);
				}
			}

			mv.addObject("allProfileTypes", EgovWCMCache.getCategoriesProfileTypes());
			mv.addObject("allProfileStructureTypes", EgovWCMCache.getProfileStructureTypes());
			
			mv.addObject("start", container.getStart());
			mv.addObject("resultsPerPage", container.getResultsPerPage());
			mv.addObject("orderColumn", container.getOrderColumn());
			mv.addObject("order", container.getOrder().toLowerCase());
			
			System.out.println("in defaultView() userUID=" + sessionBean.getUserUID());
			System.out.println("in defaultView() currentPage=" + currentPage);
			System.out.println("in defaultView() currentTab=" + currentTab);
			System.out.println("defaultView() -> order=" + container.getOrder().toLowerCase());
			System.out.println("defaultView() -> orderColumn=" + container.getOrderColumn());
		} else if (UserProfileManagerConstants.REQUEST_PAGE.equals(currentPage)) {	
			mv = processUserProfileRequestPage(renderRequest, renderResponse, mv);
		} else if (UserProfileManagerConstants.PROFILE_PAGE.equals(currentPage)) {	
			mv = processUserProfilePage(renderRequest, renderResponse, mv);
		} else if (UserProfileManagerConstants.PROFILE_ACCESS_PAGE.equals(currentPage)) {	
			mv = processUserProfileAccessPage(renderRequest, renderResponse, mv);
		} else if (UserProfileManagerConstants.ADD_PROFILE_REIK_PAGE.equals(currentPage)) {	
			mv = processAddProfileREIKPage(renderRequest, renderResponse, mv);
		}
		
		if (sessionBean.getError() != null) {
			mv.addObject("error", sessionBean.getError());
			sessionBean.setError(null);
		}
		if (sessionBean.getMessage() != null) {
			mv.addObject("message", sessionBean.getMessage());
			sessionBean.setMessage(null);
		}
		return mv;
	}
	
	/*
	 * This private method handles user profile request page.	 
	 *
	 * @param renderRequest		render request.
	 * @param renderResponse	render response.
	 * @param mv		 		ModelAndView object.
	 * 
	 */
	private ModelAndView processUserProfileRequestPage(RenderRequest renderRequest, RenderResponse renderResponse, ModelAndView mv) {
		UserProfileRequest userProfileRequest = userProfileRequestService.getUserProfileRequestById(sessionBean.getRequestId());
		if (userProfileRequest == null) {
			mv.addObject("error", "Заявка с номер \"" + sessionBean.getRequestId() + "\" не е намерена в системата.");
			return mv;
		}
		if (sessionBean.getProfileId() != null) {
			mv.addObject("profileId", sessionBean.getProfileId());
			mv.addObject("callerMode", sessionBean.getCallerMode());
		}
		if (userProfileRequest.getLeUserProfileId() != null && userProfileRequest.getLeUserProfileId() > 0) {
			mv.addObject("leUserProfile", userProfileService.getUserProfileById(userProfileRequest.getLeUserProfileId()));
		}
		mv.addObject("userProfileRequest", userProfileRequest);
		mv.addObject("statusName", utils.getRequestStatusName(userProfileRequest.getStatus(), renderRequest));
		mv.addObject("profileTypeName", wcmCommunicator.getProfileTypeName(userProfileRequest.getProfileType() + ""));
		if (userProfileRequest.getProfileStructureType() != null && userProfileRequest.getProfileStructureType().trim().length() > 0) {
			mv.addObject("profileStructureType", wcmCommunicator.getProfileStructureTypeName(userProfileRequest.getProfileStructureType()));
		}
		mv.addObject("dateCreated", utils.timeMillisToDD_MM_YYYY_HH_MM_SS(userProfileRequest.getDateCreated().getTime()));
		if (UserProfileManagerConstants.USER_PROFILE_REQUEST_STATUS_APPROVED == userProfileRequest.getStatus()) {
			mv.addObject("dateApproved", utils.timeMillisToDD_MM_YYYY_HH_MM_SS(userProfileRequest.getDateApproved().getTime()));
		} else if (UserProfileManagerConstants.USER_PROFILE_REQUEST_STATUS_CANCELED == userProfileRequest.getStatus()) {
			mv.addObject("dateCanceled", utils.timeMillisToDD_MM_YYYY_HH_MM_SS(userProfileRequest.getDateCanceled().getTime()));
		}
		return mv;
	}
	
	/*
	 * This private method handles profile page.	 
	 *
	 * @param renderRequest		render request.
	 * @param renderResponse	render response.
	 * @param mv		 		ModelAndView object.
	 * 
	 */
	private ModelAndView processUserProfilePage(RenderRequest renderRequest, RenderResponse renderResponse, ModelAndView mv) {
		UserProfile userProfile = userProfileService.getUserProfileById(sessionBean.getProfileId());
		if (userProfile == null) {
			mv.addObject("error", "Профил с номер \"" + sessionBean.getProfileId() + "\" не е намерен в системата.");
			return mv;
		} 
		// Load profile request if type is not 'Personal'.
		if (UserProfileManagerConstants.USER_PROFILE_TYPE_PERSONAL != userProfile.getProfileType()) { 
			UserProfileRequest userProfileRequest = userProfileRequestService.getLastUserProfileRequestByUserUIDAndEIK(userProfile.getUserUID(), userProfile.getEik(), utils.isREIK(userProfile.getEik()));
			if (userProfileRequest != null) {
				mv.addObject("requestId", userProfileRequest.getUserProfileRequestId());
			}
		} else {
			// Load personal parameters.
			UserProfilePersonalParameters personalParameters = userProfilePersonalParametersService.getUserProfilePersonalParametersByUserProfileId(userProfile.getUserProfileId());
			if (personalParameters != null) {
				mv.addObject("personalParameters", personalParameters);
				if (personalParameters.getEkatte() != null && EgovWCMCache.getEkattesHm() != null) {
					mv.addObject("fullAddress", utils.getFullAddress(personalParameters));
				}
			}
		}
		
		mv.addObject("allProfileTypes", EgovWCMCache.getCategoriesProfileTypes());
		mv.addObject("allProfileStructureTypes", EgovWCMCache.getProfileStructureTypes());
		mv.addObject("selectedProfileStructureTypes", utils.getSelectedProfileStructureTypes(utils.getArrayFromFormatedField(userProfile.getProfileStructureType())));
		mv.addObject("profile", userProfile);
		mv.addObject("profileName", UserProfileManagerConstants.USER_PROFILE_TYPE_PERSONAL == userProfile.getProfileType() ? userProfile.getNames() : userProfile.getNameAndLegalForm());
		mv.addObject("statusName", utils.getProfileStatusName(userProfile.getStatus(), renderRequest));
		mv.addObject("profileTypeName", wcmCommunicator.getProfileTypeName(userProfile.getProfileType() + ""));
		mv.addObject("dateCreated", utils.timeMillisToDD_MM_YYYY_HH_MM_SS(userProfile.getDateCreated().getTime()));
		mv.addObject("dateModified", utils.timeMillisToDD_MM_YYYY_HH_MM_SS(userProfile.getDateModified().getTime()));
		mv.addObject("mode", sessionBean.getMode() != null ? sessionBean.getMode() : UserProfileManagerConstants.MODE_READ);
		if (utils.isREIK(userProfile.getEik())) {
			// Load UserProfileRef.
			UserProfileRef ref = userProfileRefService.getByUserProfileId(userProfile.getUserProfileId());
			if (ref != null) {	
				// If One-level.
				UserProfile parentProfile = userProfileService.getUserProfileById(ref.getParentUserProfileId());
				// If Multiple-level, skip for now.
				//<UserProfile> parentProfiles = userProfileService.getUserProfileByIds(ref.getParentUserProfileIds());
				if (parentProfile != null) {
					mv.addObject("parentProfile", parentProfile);
				}
			}			
		} else {
			// Search for child(ren) reference profile(s).
			List<UserProfileRef> refs = userProfileRefService.getAllByParentUserProfileId(userProfile.getUserProfileId());
			if (refs != null && refs.size() > 0) {
				List<Long> userProfileIds = new ArrayList<Long>();
				for (int i = 0; i < refs.size(); i++) {
					userProfileIds.add(refs.get(i).getUserProfileId());
				}
				List<UserProfile> childProfiles = userProfileService.getAllUserProfilesByIds(userProfileIds);
				if (childProfiles != null && childProfiles.size() > 0) {
					mv.addObject("childProfiles", childProfiles);
				}
			}
			
		}
		if (sessionBean.getMode() != null) {
			if (UserProfileManagerConstants.MODE_EDIT == sessionBean.getMode()) {
				mv.addObject("edit", true);
				mv.addObject("read", false);												
			} else {
				mv.addObject("read", true);
				mv.addObject("edit", false);
			}
		}
		return mv;
	}
	
	
	/*
	 * This private method handles profile page.	 
	 *
	 * @param renderRequest		render request.
	 * @param renderResponse	render response.
	 * @param mv		 		ModelAndView object.
	 * 
	 */
	private ModelAndView processUserProfileAccessPage(RenderRequest renderRequest, RenderResponse renderResponse, ModelAndView mv) {
		logger.message("processUserProfileAccessPage()");
		UserProfile userProfile = userProfileService.getUserProfileById(sessionBean.getProfileId());
		if (userProfile == null) {
			mv.addObject("error", "Профил с номер \"" + sessionBean.getProfileId() + "\" не е намерен в системата.");
			return mv;
		} 
		List<UserProfileAndRole> selectedUsers = userProfileService.getUserProfileAndRolesByProfileId(sessionBean.getProfileId());
		List<UserProfile> selectedUsersProfile = null;
		if (selectedUsers != null && selectedUsers.size() > 0) {
			List<String> userUIDs = new ArrayList<String>();
			for (int i = 0; i < selectedUsers.size(); i++) {
				userUIDs.add(selectedUsers.get(i).getUserUID());
			}
			selectedUsersProfile = userProfileService.getUserProfileByUserUidsAndProfileType(userUIDs, UserProfileManagerConstants.USER_PROFILE_TYPE_PERSONAL);
			if (selectedUsersProfile != null && selectedUsersProfile.size() > 0) {
				for (int i = 0; i < selectedUsers.size(); i++) {
					for (int j = 0; j < selectedUsersProfile.size(); j++) {
						if (selectedUsers.get(i).getUserUID().equalsIgnoreCase(selectedUsersProfile.get(j).getUserUID())) {
							selectedUsers.get(i).setNames(selectedUsersProfile.get(j).getNames());
							break;
						}
					}
				}
			}
		}
		logger.message("processUserProfileAccessPage() selectedUsers=" + (selectedUsers != null ? selectedUsers.size() : 0));
		
		mv.addObject("selectedUsers", selectedUsers);
		mv.addObject("profile", userProfile);
		mv.addObject("profileName", UserProfileManagerConstants.USER_PROFILE_TYPE_PERSONAL == userProfile.getProfileType() ? userProfile.getNames() : userProfile.getNameAndLegalForm());
		mv.addObject("statusName", utils.getProfileStatusName(userProfile.getStatus(), renderRequest));
		mv.addObject("profileTypeName", wcmCommunicator.getProfileTypeName(userProfile.getProfileType() + ""));
		mv.addObject("dateCreated", utils.timeMillisToDD_MM_YYYY_HH_MM_SS(userProfile.getDateCreated().getTime()));
		mv.addObject("dateModified", utils.timeMillisToDD_MM_YYYY_HH_MM_SS(userProfile.getDateModified().getTime()));
		mv.addObject("mode", sessionBean.getMode() != null ? sessionBean.getMode() : UserProfileManagerConstants.MODE_READ);
		if (sessionBean.getMode() != null) {
			if (UserProfileManagerConstants.MODE_EDIT == sessionBean.getMode()) {
				mv.addObject("edit", true);
				mv.addObject("read", false);												
			} else {
				mv.addObject("read", true);
				mv.addObject("edit", false);
			}
		}
		return mv;
	}
	
	/*
	 * This private method handles add profile REIK page.	 
	 *
	 * @param renderRequest		render request.
	 * @param renderResponse	render response.
	 * @param mv		 		ModelAndView object.
	 * 
	 */
	private ModelAndView processAddProfileREIKPage(RenderRequest renderRequest, RenderResponse renderResponse, ModelAndView mv) {		
		mv.addObject("allProfileStructureTypes", EgovWCMCache.getProfileStructureTypes());
		return mv;
	}
	
	/*
	 * This action is called from buttons "Add/Edit Group"
	 * and "Add/Edit Parameter". 
	 *
	 * @param page			the page name to switch to.
	 * @param id		 	the id of the object we will work with (group/parameter).
	 * 
	 */
	@ActionMapping(value = "changePage")
	public void changePage(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "page") String page,			
			@RequestParam(value = "requestId", required = false) Long requestId,
			@RequestParam(value = "profileId", required = false) Long profileId,
			@RequestParam(value = "mode", required = false) Integer mode,
			@RequestParam(value = "callerMode", required = false) Integer callerMode) {
		logger.message("changePage [" + page + "][" + requestId + "][" + profileId + "][" + mode + "][" + callerMode + "]");
		sessionBean.setCurrentPage(page);		
		sessionBean.setRequestId(requestId);
		sessionBean.setProfileId(profileId);
		sessionBean.setMode(mode);
		sessionBean.setCallerMode(callerMode);
		// Returns control to default view.
	}
	
	/*
	 * This action is called from form "reloadPage"
	 *
	 */
	@ActionMapping(value = "reloadPage")
	public void reloadPage(
			ActionRequest actionRequest, ActionResponse actionResponse) {
		logger.message("reloadPage");		
		// Returns control to default view.
	}
	
	
	/*
	 * This action is called from main tabs.
	 *
	 * @param tab			the tab id to switch to.
	 * 
	 */
	@ActionMapping(value = "changeTab")
	public void changeTab(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "tab") Integer tab) {
		logger.message("changeTab [" + tab+ "]");
		String currentPage = sessionBean.getCurrentPage();
		sessionBean.getTabPerPage().put(currentPage, tab);
		// Returns control to default view.
	}
	
	/*
	 * This action is called from tab "Roles (XC)"
	 * and is responsible for toggle among different views. 
	 *
	 * @param view			the view id to switch to.
	 * @param profileType 	the profile type to which the view will filter the results.
	 * 
	 */
	@ActionMapping(value = "changeView")
	public void changeView(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "view") Integer view,
			@RequestParam(value = "systemOID", required = false) String systemOID) {
		logger.message("changeView [" + view + "]");
		String currentPage = sessionBean.getCurrentPage();
		Integer currentTab = sessionBean.getTabPerPage().get(currentPage);
		try {
			HashMap<String, Integer> viewPerTab = sessionBean.getViewPerTab();
			viewPerTab.put(currentPage + currentTab, view);
			sessionBean.setViewPerTab(viewPerTab);
			Container container = sessionBean.getContainer().get(currentPage + currentTab + view);
			if (container == null) {
				container = new Container();	
				container.setOrderColumn(UserProfileManagerConstants.COLUMN_HS_ROLES_TITLE);
				container.setOrder(UserProfileManagerConstants.ORDER_ASC);
			}
			if (UserProfileManagerConstants.VIEW_HORIZONTAL_SYSTEM_ROLES == view) {
				container.setSystemOID(systemOID);
			} else {
				container.setSystemOID(null);
			}			
			sessionBean.getContainer().put(currentPage + currentTab + view, container);			
			container = sessionBean.getContainer().get(currentPage + currentTab + view);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		// Returns control to default view.
	}
	
	/*
	 * This resource mapping is called from "Requests" tab.
	 *
	 * @param requestId		the request id of the document to be download.
	 * 
	 */
	@ResourceMapping(value = "getOrderDocument")
	public void getOrderDocument(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("requestId") Long userProfileRequestId) {
		loadPreferences(resourceRequest);		
		logger.message("getOrderDocument");
		if (userProfileRequestId != null) {
			UserProfileRequest userProfileRequest = userProfileRequestService.getUserProfileRequestFileById(userProfileRequestId);
			if (userProfileRequest != null) {										
				OutputStream out = null;
				try {
					resourceResponse.setContentType((userProfileRequest.getOrderDocumentContentType() != null ? userProfileRequest.getOrderDocumentContentType() : "text/plain") + "; charset=UTF-8");
					resourceResponse.setCharacterEncoding("UTF-8");
					resourceResponse.setProperty("Content-disposition","attachment; filename=" + URLEncoder.encode(userProfileRequest.getOrderDocumentName(), "UTF-8").replaceAll("\\+", " "));
					logger.message("serveResource() -> contentType: " + userProfileRequest.getOrderDocumentContentType() != null ? userProfileRequest.getOrderDocumentContentType() : "text/plain");
					logger.message("serveResource() -> filename: " + userProfileRequest.getOrderDocumentName());
					out = resourceResponse.getPortletOutputStream();
					if (userProfileRequest.getOrderDocument() != null) {
						resourceResponse.setContentLength(userProfileRequest.getOrderDocument().length);
						try {
							out.write(userProfileRequest.getOrderDocument() , 0, userProfileRequest.getOrderDocument().length);
						} catch (Exception e) {
						   e.printStackTrace();
						} 
					}
					out.flush();
					out.close();
				} catch (Exception e) {		
					if (out != null) {
						try {
							out.flush();
							out.close();
						} catch (Exception e2) {}
					}
					e.printStackTrace();
				}
			}
		} else {
			try {
				resourceResponse.setContentType("text/plain");
				resourceResponse.getWriter().flush();
				resourceResponse.getWriter().close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	/*
	 * This action is called from tab "Requests".
	 *
	 * @param id				the id of the request.
	 * @param userProfileId 	the id of the profile.
	 * @param name			 	the names or nameAndLegalForm.
	 * @param status			boolean active/inactive.
	 * 
	 */
	@ActionMapping(value = "searchFilterRequests")
	public void searchFilterRequests(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "id", required = false) Long id,
			@RequestParam(value = "userProfileId", required = false) Long userProfileId,
			@RequestParam(value = "name", required = false) String name,
			@RequestParam(value = "status", required = false) Integer status) 
	{
		loadPreferences(actionRequest);
		logger.message("searchFilterRequests");
		logger.message("id=" + (id != null ? id : ""));
		logger.message("userProfileId=" + (userProfileId != null ? userProfileId : ""));
		logger.message("name=" + (name != null ? name : ""));
		logger.message("status=" + (status != null ? status : ""));
		if (sessionBean != null) {
			String currentPage = sessionBean.getCurrentPage();   
			Integer currentTab = sessionBean.getTabPerPage().get(currentPage);
			Container container = sessionBean.getContainer().get(currentPage + currentTab);
			if (container == null) {
				container = new Container();
			}
			
			container.setFilterId(id);
			container.setFilterUserProfileId(userProfileId);
			container.setFilterName(name != null && name.trim().length() > 0 ? name.trim() : null);
			container.setFilterStatus(status);
			container.setStart(0);
			sessionBean.getContainer().put(currentPage + currentTab, container);
		}
		// Pass parameters to default view.
		//actionResponse.setRenderParameters(actionRequest.getParameterMap());
		// Returns control to default view.
	}
	
	
	/*
	 * This resource mapping is called from tab "Requests". 
	 *
	 * @param draw				UI parameter from Datatables.
	 * @param start 			page number (started from 0).
	 * @param length			results per page.
	 * @param order[0][column]	order column index.
	 * @param order[0][dir]		order column direction.
	 * 
	 */
	@ResourceMapping(value = "getRequests")
	public void getRequests(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("draw") Integer draw,
			@RequestParam("start") Integer start,
			@RequestParam("length") Integer length,
			@RequestParam("order[0][column]") Integer orderColumn,
			@RequestParam("order[0][dir]") String order)
	{
		loadPreferences(resourceRequest);		
		logger.message("geRequests");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONArray ja = new JSONArray();
		
		int totalResults = 0;
		if (sessionBean != null) {
			String currentPage = sessionBean.getCurrentPage();  
			Integer currentTab = sessionBean.getTabPerPage().get(currentPage);
			Container container = sessionBean.getContainer().get(currentPage + currentTab);
			if (container == null) {
				container = new Container();
			}
			
			container.setResultsPerPage(length);
			container.setStart(start);
			container.setOrderColumn(orderColumn);
			container.setOrder(order);
			sessionBean.getContainer().put(currentPage + currentTab, container);
			
			
			Long filterId = container.getFilterId();
			Long filterUserProfileId = container.getFilterUserProfileId();
			String filterName = container.getFilterName() != null && container.getFilterName().trim().length() > 0 ? container.getFilterName().trim() : null;
			Integer filterStatus = container.getFilterStatus() != null ? container.getFilterStatus() : null;
			logger.message("geRequests() -> length=" + length);
			logger.message("geRequests() -> start=" + start);
			logger.message("geRequests() -> orderColumn=" + orderColumn);
			logger.message("geRequests() -> order=" + order);
			logger.message("geRequests() -> filterId=" + filterId);
			logger.message("geRequests() -> filterUserProfileId=" + filterUserProfileId);
			logger.message("geRequests() -> filterName=" + filterName);
			logger.message("geRequests() -> filterStatus=" + filterStatus);
 
			List<UserProfileRequest> results = userProfileRequestService.getAllUserProfileRequestsByFilter(filterId, filterUserProfileId, filterName, filterStatus, start, length, orderColumn, order);
			if (results != null && results.size() > 0) {
				logger.message("geRequests() -> results.size()=" + results.size());	
				JSONArray tmpJA = null;
				String profileStructureTypeName = null;
//				for (int i = 0; i < results.size(); i++) {
				// Check for request for LE with REIK.
				List<Long> leUserProfileId = new ArrayList<>();
				for (int i = container.getStart(); i < results.size(); i++) {
					if (results.get(i).getLeUserProfileId() != null && !leUserProfileId.contains(results.get(i).getLeUserProfileId())) {
						leUserProfileId.add(results.get(i).getLeUserProfileId());
					}
				}
				Map<Long, String> leByName = null;
				// REIK request(s) found.
				if (leUserProfileId != null && leUserProfileId.size() > 0) {
					List<UserProfile> profiles = userProfileService.getAllUserProfilesByIds(leUserProfileId);
					leByName = new HashMap<Long, String>();
					for (int i = 0; i < profiles.size(); i++) {
						leByName.put(profiles.get(i).getUserProfileId(), profiles.get(i).getNameAndLegalForm());
					}
				}
				String requestorName = null;
				for (int i = container.getStart(); i < results.size(); i++) {
					profileStructureTypeName = results.get(i).getProfileStructureTypeOther();					
					if (profileStructureTypeName == null || profileStructureTypeName.trim().length() == 0) {
						profileStructureTypeName = wcmCommunicator.getProfileStructureTypeName(results.get(i).getProfileStructureType());
					}
					requestorName = results.get(i).getNames();
					if (results.get(i).getLeUserProfileId() != null && results.get(i).getLeUserProfileId() > 0) {
						requestorName = leByName.get(results.get(i).getLeUserProfileId()) + " (" + results.get(i).getNames() + ")";
					}
					tmpJA = new JSONArray();
					tmpJA.put(results.get(i).getUserProfileRequestId());
					tmpJA.put(results.get(i).getUserProfileId());
					tmpJA.put(results.get(i).getProfileType());
					tmpJA.put(wcmCommunicator.getProfileTypeName(results.get(i).getProfileType() + ""));
					tmpJA.put(results.get(i).getProfileStructureType() != null ? results.get(i).getProfileStructureType() : "");					
					tmpJA.put(profileStructureTypeName);
					tmpJA.put(results.get(i).getEik());
					tmpJA.put(results.get(i).getNameAndLegalForm());
					tmpJA.put(requestorName);
					tmpJA.put(results.get(i).getOrderNumber() != null ? results.get(i).getOrderNumber().trim() : "");
					tmpJA.put(results.get(i).getOrderDocumentName() != null ? results.get(i).getOrderDocumentName().trim() : "");
					tmpJA.put(utils.timeMillisToDD_MM_YYYY_HH_MM_SS(results.get(i).getDateCreated().getTime()));
					if (UserProfileManagerConstants.USER_PROFILE_REQUEST_STATUS_CANCELED == results.get(i).getStatus()) {
						tmpJA.put((results.get(i).getDateCanceled() != null) ? utils.timeMillisToDD_MM_YYYY_HH_MM_SS(results.get(i).getDateCanceled().getTime()) : "");
					} else {
						tmpJA.put((results.get(i).getDateApproved() != null) ? utils.timeMillisToDD_MM_YYYY_HH_MM_SS(results.get(i).getDateApproved().getTime()) : "");
					}
					tmpJA.put(utils.getRequestStatusName(results.get(i).getStatus(), resourceRequest));
					tmpJA.put(results.get(i).getLeUserProfileId() != null && results.get(i).getLeUserProfileId() > 0 ? results.get(i).getLeUserProfileId() : "");
					tmpJA.put(results.get(i).getUserProfileRequestId());
					ja.put(tmpJA);						
				}				
			} else {
				logger.message("geRequests() -> requests.length=0");
			}
			totalResults = results != null ? results.size() : 0;
		} 
		json.put("draw", draw);	
		json.put("recordsTotal", totalResults);	
		json.put("recordsFiltered", totalResults);	
		json.put("data", ja);	
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	 
		
	}
	
	/*
	 * This resource mapping is called from tab "Requests" and handles the approve operation.
	 *
	 * @param requestId				the id of the request that will be approved.
	 * @param profileType			the profile type.
	 * @param profileStructureType	profile structure type(s).
	 * 
	 */
	@ResourceMapping(value = "approveRequest")
	public void approveRequest(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("requestId") Long userProfileRequestId,
			@RequestParam("profileType") Integer profileType,
			@RequestParam(value = "profileStructureType", required = false) String profileStructureType)
	{
		loadPreferences(resourceRequest);		
		logger.message("approveRequest");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONObject ja = new JSONObject();
		UserProfileRequest userProfileRequest = null;
		boolean success = false;
		String message = null;
		try {
			userProfileRequest = userProfileRequestService.getUserProfileRequestById(userProfileRequestId);
			if (userProfileRequest != null) {
				if (UserProfileManagerConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER == profileType 
						&& EgovWCMCache.getServiceProviderByEIK().get(userProfileRequest.getEik()) == null) {
					logger.message("approveRequest() -> load service provider name from cache = EMPTY!");
					message = "Не е намерен доставчик с ЕИК - " + userProfileRequest.getEik();
				} else {					
					userProfileRequest.setProfileType(profileType);
					userProfileRequest.setStatus(UserProfileManagerConstants.USER_PROFILE_REQUEST_STATUS_APPROVED);
					if (profileStructureType != null && profileStructureType.trim().length() > 0) {
						profileStructureType = utils.formatMultipleFieldsToOne(profileStructureType.trim());
					}
					Date currentDate = new Date();
					UserProfile newLEProfile = userProfileRequestService.approveUserProfileRequest(userProfileRequest, profileStructureType, currentDate);
					if (newLEProfile != null) {
						// Add user to group.
						if (newLEProfile.getGroupId() != null && newLEProfile.getGroupId().trim().length() > 0 && UserProfileManagerConstants.USER_PROFILE_TYPE_LEGAL_ENTITY != userProfileRequest.getProfileType()) {
							User user = pumaCommunicator.getUserByUID(userProfileRequest.getUserUID(), pumaHome);
							if (user != null) {
								String result = pumaCommunicator.addUserToGroupsIfNotAdded(user, newLEProfile.getGroupId(), pumaHome);
								logger.message("approveRequest() ->" + userProfileRequest.getUserUID() + "," + newLEProfile.getGroupId() + ") [ERROR] - result=" + result);
							}
						}	
						success = true;
						sessionBean.setMessage("Заявка с номер \"" + userProfileRequestId + "\" беше одобрена.");

						/*
						 *  Send email to the user, that created the request.
						 */
						// Load user personal profile.
						UserProfile userPersonalProfile = userProfileService.getUserProfileByUserUidAndProfileType(userProfileRequest.getUserUID(), UserProfileManagerConstants.USER_PROFILE_TYPE_PERSONAL);
						if (userPersonalProfile != null) {							
							// Load personal parameters.
							UserProfilePersonalParameters personalParameters = userProfilePersonalParametersService.getUserProfilePersonalParametersByUserProfileId(userPersonalProfile.getUserProfileId());
							try { 
								notificationManager.notifyUserForRequestLEProfileApproval(userProfileRequest, userPersonalProfile, personalParameters, newLEProfile);
							} catch (Exception e) {
								String msg = sessionBean.getMessage();
								msg += " " + e.getMessage();
								sessionBean.setMessage(msg);
								e.printStackTrace();
							}							
						}
						
						/*
						 *  Register log event.
						 */
						esbCommunicator.sendEvent(sessionBean.getUserUID(), UserProfileManagerConstants.EVENT_LOG_PORTAL_APPROVE_PROFILE_REQUEST, "Одобряване на заявка с номер \"" + userProfileRequestId + "\" за профил - \"" + userProfileRequest.getNameAndLegalForm() + "\" (" + userProfileRequest.getEik() + ")", null, utils.getRemoteIP(resourceRequest), false);
						ja.put("result", "1");
						ja.put("message", "Заявка с номер \"" + userProfileRequestId + "\" беше одобрена.");
						
						/*
						 * Register event in eJournal.
						 */
						eJournalCommunicator.sendRNU(utils.generateRNU(), UserProfileManagerConstants.E_JOURNAL_STAGE_INITIALIZE, UserProfileManagerConstants.E_JOURNAL_STATUS_CREATE_LE_PROFILE, currentDate.getTime());
					}
				}
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}	
		if (!success) {
			ja.put("result", "0");
			if (message == null) {
				message = "Неуспешно одобряване на заявка с номер " + userProfileRequestId + ".";
			}
			sessionBean.setError(message);			
			ja.put("message", message);
		}
		json.put("data", ja);
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	
	}

	/*
	 * This resource mapping is called from tab "Requests" and handles the cancel operation.
	 *
	 * @param requestId		the id of the request that will be cancel.
	 * @param cancelReason	the reason for the cancel.
	 * 
	 */
	@ResourceMapping(value = "cancelRequest")
	public void cancelRequest(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("requestId") Long userProfileRequestId,
			@RequestParam("cancelReason") String cancelReason)
	{
		loadPreferences(resourceRequest);		
		logger.message("cancelRequest");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONObject ja = new JSONObject();
		UserProfileRequest userProfileRequest = null;
		boolean success = false;
		try {
			userProfileRequest = userProfileRequestService.getUserProfileRequestById(userProfileRequestId);
			if (userProfileRequest != null) {
				Date dateCancel = new Date();
				userProfileRequest.setDateCanceled(dateCancel);
				userProfileRequest.setStatus(UserProfileManagerConstants.USER_PROFILE_REQUEST_STATUS_CANCELED);
				userProfileRequest.setCancelReason(cancelReason);
				if (userProfileRequestService.cancelUserProfileRequest(userProfileRequest)) {
					success = true;
					sessionBean.setMessage("Заявка с номер \"" + userProfileRequestId + "\" беше отказана.");
					 
					/*
					 *  Send email to the user, that created the request.
					 */
					// Load user personal profile.
					UserProfile userPersonalProfile = userProfileService.getUserProfileByUserUidAndProfileType(userProfileRequest.getUserUID(), UserProfileManagerConstants.USER_PROFILE_TYPE_PERSONAL);
					if (userPersonalProfile != null) {							
						// Load personal parameters.
						UserProfilePersonalParameters personalParameters = userProfilePersonalParametersService.getUserProfilePersonalParametersByUserProfileId(userPersonalProfile.getUserProfileId());
						try { 
							notificationManager.notifyUserForRequestLEProfileCancel(userProfileRequest, userPersonalProfile, personalParameters, dateCancel, cancelReason);
						} catch (Exception e) {
							String msg = sessionBean.getMessage();
							msg += " " + e.getMessage();
							sessionBean.setMessage(msg);
							e.printStackTrace();
						}							
					}
					
					/*
					 *  Register log event.
					 */
					esbCommunicator.sendEvent(sessionBean.getUserUID(), UserProfileManagerConstants.EVENT_LOG_PORTAL_CANCEL_PROFILE_REQUEST, "Отказване на заявка с номер \"" + userProfileRequestId + "\" за профил - \"" + userProfileRequest.getNameAndLegalForm() + "\" (" + userProfileRequest.getEik() + ")", null, utils.getRemoteIP(resourceRequest), false);
					ja.put("result", "1");
					ja.put("message", "Заявка с номер \"" + userProfileRequestId + "\" беше отказана.");
				}
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}	
		if (!success) {
			sessionBean.setError("Неуспешно отказване на заявка с номер " + userProfileRequestId + ".");
			ja.put("result", "0");
			ja.put("message", "Неуспешно отказване на заявка с номер " + userProfileRequestId + ".");
		}
		json.put("data", ja);
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	
	}
	
	/*
	 * This resource mapping is called from tab "Requests" and handles the delete operation.
	 *
	 * @param requestId		the id of the request that will be deleted.
	 * 
	 */
	@ResourceMapping(value = "deleteRequest")
	public void deleteRequest(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("requestId") Long userProfileRequestId)
	{
		loadPreferences(resourceRequest);		
		logger.message("deleteRequest");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONObject ja = new JSONObject();
		UserProfileRequest userProfileRequest = null;
		boolean success = false;
		if ("wpadmin".equalsIgnoreCase(sessionBean.getUserUID())) {
			try {
				userProfileRequest = userProfileRequestService.getUserProfileRequestById(userProfileRequestId);
				if (userProfileRequest != null) {
					if (userProfileRequestService.deleteUserProfileRequest(userProfileRequest)) {
						success = true;
						sessionBean.setMessage("Заявка с номер \"" + userProfileRequestId + "\" беше изтрита успешно.");
						ja.put("result", "1");
						ja.put("message", "Заявка с номер \"" + userProfileRequestId + "\" беше изтрита успешно.");
					}
				} 
			} catch (Exception e) {
				e.printStackTrace();
			}	
		}
		if (!success) {
			sessionBean.setError("Неуспешно изтриване на заявка с номер " + userProfileRequestId + ".");
			ja.put("result", "0");
			ja.put("message", "Неуспешно изтриване на заявка с номер " + userProfileRequestId + ".");
		}
		json.put("data", ja);
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	
	}
	
	
	/*
	 * This action is called from tab "Profiles" 
	 *
	 * @param id			the id of the profile.
	 * @param profileType 	the profile type.
	 * @param userUID	 	the user UID.
	 * @param name		 	name.
	 * @param status		boolean active/inactive.
	 * 
	 */
	@ActionMapping(value = "searchFilterProfiles")
	public void searchFilterProfiles(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "id", required = false) Long id,
			@RequestParam(value = "profileType", required = false) Integer profileType,
			@RequestParam(value = "profileStructureType", required = false) Integer profileStructureType,
			@RequestParam(value = "userUID", required = false) String userUID,
			@RequestParam(value = "name", required = false) String name,
			@RequestParam(value = "dateFrom", required = false) String dateFrom,
			@RequestParam(value = "dateTo", required = false) String dateTo,
			@RequestParam(value = "status", required = false) Integer status) 
	{
		loadPreferences(actionRequest);
		logger.message("searchFilterProfiles");
		logger.message("id=" + (id != null ? id : ""));
		logger.message("profileType=" + (profileType != null ? profileType : ""));
		logger.message("profileStructureType=" + (profileStructureType != null ? profileStructureType : ""));
		logger.message("userUID=" + (userUID != null ? userUID : ""));
		logger.message("name=" + (name != null ? name : ""));
		logger.message("dateFrom" + (dateFrom != null ? dateFrom : ""));
		logger.message("dateTo" + (dateTo != null ? dateTo : ""));
		logger.message("status=" + (status != null ? status : ""));
		if (sessionBean != null) {
			String currentPage = sessionBean.getCurrentPage();  
			Integer currentTab = sessionBean.getTabPerPage().get(currentPage);
			Container container = sessionBean.getContainer().get(currentPage + currentTab);
			if (container == null) {
				container = new Container();
			}
			
			container.setFilterId(id);
			container.setFilterType(profileType);
			container.setFilterStructureType(profileStructureType);
			container.setFilterName(name != null && name.trim().length() > 0 ? name.trim() : null);
			container.setFilterUserUID(userUID != null && userUID.trim().length() > 0 ? userUID.trim() : null);
			container.setFilterDateFrom(dateFrom != null && dateFrom.trim().length() > 0 ? dateFrom.trim() : null);
			container.setFilterDateTo(dateTo != null && dateTo.trim().length() > 0 ? dateTo.trim() : null);
			container.setFilterStatus(status);
			container.setStart(0);
			sessionBean.getContainer().put(currentPage + currentTab, container);
		}
		// Pass parameters to default view.
		//actionResponse.setRenderParameters(actionRequest.getParameterMap());
		// Returns control to default view.
	}
	
	/*
	 * This action is called from page "profile.jsp" to save profile form.
	 *
	 * @param userProfileId						the id of the profile.
	 * @param profileType						profile type.
	 * @param selectedProfileStructureTypes		profile structure types.
	 * 
	 */
	@ActionMapping(value = "saveProfile")
	public void saveProfile(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "userProfileId") Long userProfileId,			
			@RequestParam(value = "profileType") Integer profileType,
			@RequestParam(value = "selectedProfileStructureTypes", required = false) String selectedProfileStructureTypes) 
	{
		loadPreferences(actionRequest);		
		logger.message("saveProfile [" + userProfileId + "]");
		logger.message("profileType=" + profileType);
		logger.message("selectedProfileStructureTypes=" + selectedProfileStructureTypes);
		UserProfile userProfile = userProfileService.getUserProfileById(userProfileId);
		if (userProfile == null) {
			sessionBean.setError("Профил с номер \"" + userProfileId + "\" не е намерен в системата.");
			return;
		}
		userProfile.setProfileType(profileType);
		userProfile.setProfileStructureType(utils.formatMultipleFieldsToOne(selectedProfileStructureTypes));
		userProfile.setDateModified(new Date());
		boolean result = false;
		try {
			result = userProfileService.updateUserProfile(userProfile); 
		} catch (Exception e) {
			e.printStackTrace();
		}	
		String profileName = UserProfileManagerConstants.USER_PROFILE_TYPE_PERSONAL == userProfile.getProfileType() ? userProfile.getNames() : userProfile.getNameAndLegalForm();
		if (result) {			
			sessionBean.setMessage("Профил \"" + profileName + "\" беше редактиран успешно.");
			esbCommunicator.sendEvent(sessionBean.getUserUID(), UserProfileManagerConstants.EVENT_LOG_PORTAL_MODERATOR_EDIT_PROFILE, "Редактиране на профил - \"" + profileName + "\" (" + userProfileId + ")", null, utils.getRemoteIP(actionRequest), false);
		} else {
			sessionBean.setError("Възникна грешка при редактиране на профил \"" + profileName  + "\".");
		}
		if (result) {
			sessionBean.setCurrentPage(UserProfileManagerConstants.INDEX_PAGE);
		} else {
			// Pass parameters to default view and return control.
			actionResponse.setRenderParameters(actionRequest.getParameterMap());
		}
	}
	
	/*
	 * This action is called from page "profileAccess.jsp" to save profile access form.
	 *
	 * @param userProfileId						the id of the profile.
	 * @param selectedUsers						users UIDs.
	 * 
	 */
	@ActionMapping(value = "saveProfileAccess")
	public void saveProfileAccess(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "userProfileId") Long userProfileId,			
			@RequestParam(value = "selectedUsers") String selectedUsersStr) 
	{
		loadPreferences(actionRequest);		
		logger.message("saveProfileAccess [" + userProfileId + "][" + sessionBean.getProfileId() + "]");
		logger.message("selectedUsersStr=" + selectedUsersStr);
		if (userProfileId == null || sessionBean.getProfileId() == null || !userProfileId.equals(sessionBean.getProfileId())) {
			sessionBean.setError("Моля презаредете страницата, има несъвпадение между данните постъпили при запазвване и тези в сесията.");
			return;			
		}
		if (selectedUsersStr == null || selectedUsersStr.trim().length() == 0) {
			sessionBean.setError("Моля асоциирайте потребител(и) с профила.");
			return;			
		}
		UserProfile userProfile = userProfileService.getUserProfileById(userProfileId);
		if (userProfile == null) {
			sessionBean.setError("Профил с номер \"" + userProfileId + "\" не е намерен в системата.");
			return;
		}
		List<UserProfileRole> currentUsers = userProfileRoleService.getAllUserProfileRolesByUserProfileId(userProfileId);
		List<UserProfileRole> selectedUsers = utils.getSelectedRolesFromForm(actionRequest, selectedUsersStr);
		if (selectedUsers == null || selectedUsers.size() == 0) {
			sessionBean.setError("Не са намерени потребители с роли за асоцииране с профила.");
			return;
		}
		if (!utils.hasUserWithAdminRole(selectedUsers)) {
			sessionBean.setError("Моля задайте роля 'Администратор' поне на един потребител.");
			return;
		}
		int result = userProfileRoleService.updateAllUserProfileRolesForUserProfile(currentUsers, selectedUsers, userProfileId);
		String profileName = UserProfileManagerConstants.USER_PROFILE_TYPE_PERSONAL == userProfile.getProfileType() ? userProfile.getNames() : userProfile.getNameAndLegalForm();
		if (result != -1) {			
			sessionBean.setMessage("Достъпът до профил \"" + profileName + "\" беше редактиран успешно.");
			esbCommunicator.sendEvent(sessionBean.getUserUID(), UserProfileManagerConstants.EVENT_LOG_PORTAL_MODERATOR_EDIT_PROFILE_ACCESS, "Редактиране на достъп до профил - \"" + profileName + "\" (" + userProfileId + ")", null, utils.getRemoteIP(actionRequest), false);
		} else {
			sessionBean.setError("Възникна грешка при редактиране на достъп до профил \"" + profileName  + "\".");
		}
//		if (result) {
//			sessionBean.setCurrentPage(UserProfileManagerConstants.INDEX_PAGE);
//		} else {
			// Pass parameters to default view and return control.
			actionResponse.setRenderParameters(actionRequest.getParameterMap());
//		}
	}

	/*
	 * This action is called from page "addProfileREIK.jsp" to add profile EIK form.
	 *
	 * @param userProfileId						the id of the profile.
	 * @param profileType						profile type.
	 * @param selectedProfileStructureTypes		profile structure types.
	 * 
	 */
	@ActionMapping(value = "addProfileREIK")
	public void addProfileREIK(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "eik") String eik,			
			@RequestParam(value = "title") String title,
			@RequestParam(value = "adminProfileId") Long adminProfileId,
			@RequestParam(value = "selectedProfileStructureTypes", required = false) String selectedProfileStructureTypes) 
	{
		loadPreferences(actionRequest);		
		logger.message("addProfileREIK [" + eik + "]");
		logger.message("eik=" + eik);
		logger.message("title=" + title);
		logger.message("adminProfileId=" + adminProfileId);
		logger.message("selectedProfileStructureTypes=" + selectedProfileStructureTypes);
		
		UserProfile leUserProfile = userProfileService.getUserProfileByEik(eik);
		if (leUserProfile == null) {
			sessionBean.setError("Профилът на ЮЛ не е намерен в системата (" + eik + ").");
			return;
		}
		if (leUserProfile.getStatus() != UserProfileManagerConstants.USER_PROFILE_STATUS_ACTIVE) {
			sessionBean.setError("Профилът на ЮЛ не е активен.");
			return;
		}
		if (!(UserProfileManagerConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER == leUserProfile.getProfileType()
				|| UserProfileManagerConstants.USER_PROFILE_TYPE_LEGAL_ENTITY_AL2 == leUserProfile.getProfileType())) {			
			sessionBean.setError("Профилът на ЮЛ с ЕИК " + eik + " не е по чл. 1 ал. 1 или чл. 1 ал. 2 от ЗЕУ!");
			return;
		}
			
		UserProfile adminUserProfile = userProfileService.getUserProfileById(adminProfileId);
		if (adminUserProfile == null) {
			sessionBean.setError("Профилът на администратора не е намерен в системата.");
			return;
		}
		if (adminUserProfile.getStatus() != UserProfileManagerConstants.USER_PROFILE_STATUS_ACTIVE) {
			sessionBean.setError("Профилът на администратора не е активен.");
			return;
		}
		boolean success = false;
		try {
			if (selectedProfileStructureTypes != null && selectedProfileStructureTypes.trim().length() > 0) {
				selectedProfileStructureTypes = utils.formatMultipleFieldsToOne(selectedProfileStructureTypes.trim());
			}
			UserProfile newLEProfile = userProfileService.createLEUserProfileWithREIK(leUserProfile, adminUserProfile, title, selectedProfileStructureTypes);
			if (newLEProfile != null) {
				// Add user to group.
				if (newLEProfile.getGroupId() != null && newLEProfile.getGroupId().trim().length() > 0) {
					User user = pumaCommunicator.getUserByUID(adminUserProfile.getUserUID(), pumaHome);
					if (user != null) {
						String result = pumaCommunicator.addUserToGroupsIfNotAdded(user, newLEProfile.getGroupId(), pumaHome);
						logger.message("addProfileREIK() ->" + adminUserProfile.getUserUID() + "," + newLEProfile.getGroupId() + ") [ERROR] - result=" + result);
					}
				}	
				success = true;
				sessionBean.setMessage("Профил на ЮЛ '" + title + "' (" + newLEProfile.getEik() + ") беше добавен успешно.");

				/*
				 *  Send email to the user, that was assigned as administrator for the newly created profile with REIK.
				 */
				// Load user personal profile.
				UserProfile userPersonalProfile = userProfileService.getUserProfileByUserUidAndProfileType(adminUserProfile.getUserUID(), UserProfileManagerConstants.USER_PROFILE_TYPE_PERSONAL);
				if (userPersonalProfile != null) {							
					// Load personal parameters.
					UserProfilePersonalParameters personalParameters = userProfilePersonalParametersService.getUserProfilePersonalParametersByUserProfileId(userPersonalProfile.getUserProfileId());
					try { 
						notificationManager.notifyNewlyAdmininistratorUserForCreateLEProfileWithREIK(newLEProfile, personalParameters);
					} catch (Exception e) {
						String msg = sessionBean.getMessage();
						msg += " " + e.getMessage();
						sessionBean.setMessage(msg);
						e.printStackTrace();
					}							
				}
				/*
				 *  Register log event.
				 */
				esbCommunicator.sendEvent(sessionBean.getUserUID(), UserProfileManagerConstants.EVENT_LOG_PORTAL_MODERATOR_CREATE_LE_PROFILE_REIK, "Добавяне на профил на ЮЛ с РЕИК - \"" + title + "\" (" + newLEProfile.getEik() + ")", null, utils.getRemoteIP(actionRequest), false);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}	
		if (success) {
			sessionBean.setCurrentPage(UserProfileManagerConstants.INDEX_PAGE);
		} else {
			sessionBean.setError("Възникна грешка при добавяне на профил '" + title  + "'.");
			// Pass parameters to default view and return control.
			actionResponse.setRenderParameters(actionRequest.getParameterMap());
		}
	}
	
	
	/*
	 * This resource mapping is called from tab "Profiles" 
	 *
	 * @param draw				UI parameter from Datatables.
	 * @param start 			page number (started from 0).
	 * @param length			results per page.
	 * @param order[0][column]	order column index.
	 * @param order[0][dir]		order column direction.
	 * 
	 */
	@ResourceMapping(value = "getProfiles")
	public void getProfiles(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("draw") Integer draw,
			@RequestParam("start") Integer start,
			@RequestParam("length") Integer length,
			@RequestParam("order[0][column]") Integer orderColumn,
			@RequestParam("order[0][dir]") String order)
	{
		loadPreferences(resourceRequest);		
		logger.message("getProfiles");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONArray ja = new JSONArray();
		
		int totalResults = 0;
		if (sessionBean != null) {
			String currentPage = sessionBean.getCurrentPage();  
			Integer currentTab = sessionBean.getTabPerPage().get(currentPage);
			Container container = sessionBean.getContainer().get(currentPage + currentTab);
			if (container == null) {
				container = new Container();
			}
			
			container.setResultsPerPage(length);
			container.setStart(start);
			container.setOrderColumn(orderColumn);
			container.setOrder(order);
			sessionBean.getContainer().put(currentPage + currentTab, container);
			
			
			Long filterId = container.getFilterId();
			Integer filterType = container.getFilterType();
			Integer filterStructureType = container.getFilterStructureType();
			String filterUserUID = container.getFilterUserUID() != null && container.getFilterUserUID().trim().length() > 0 ? container.getFilterUserUID().trim() : null;
			String filterName = container.getFilterName() != null && container.getFilterName().trim().length() > 0 ? container.getFilterName().trim() : null;
			String filterDateFrom = container.getFilterDateFrom() != null && container.getFilterDateFrom().trim().length() > 0 ? container.getFilterDateFrom().trim() : null;
			String filterDateTo = container.getFilterDateTo() != null && container.getFilterDateTo().trim().length() > 0 ? container.getFilterDateTo().trim() : null;
			Integer filterStatus = container.getFilterStatus() != null ? container.getFilterStatus() : null;
			logger.message("getProfiles() -> length=" + length);
			logger.message("getProfiles() -> start=" + start);
			logger.message("getProfiles() -> orderColumn=" + orderColumn);
			logger.message("getProfiles() -> order=" + order);
			logger.message("getProfiles() -> filterId=" + filterId);
			logger.message("getProfiles() -> filterType=" + filterType);
			logger.message("getProfiles() -> filterStructureType=" + filterStructureType);
			logger.message("getProfiles() -> filterUserUID=" + filterUserUID);
			logger.message("getProfiles() -> filterName=" + filterName);
			logger.message("getProfiles() -> filterDateFrom=" + filterDateFrom);
			logger.message("getProfiles() -> filterDateTo=" + filterDateTo);
			logger.message("getProfiles() -> filterStatus=" + filterStatus);
  
			if (filterDateFrom != null) {
				filterDateFrom = utils.dateBGToTimestampDate(filterDateFrom, true);
				logger.message("getProfiles() -> filterDateFrom2=" + filterDateFrom);
			}
			if (filterDateTo != null) {
				filterDateTo = utils.dateBGToTimestampDate(filterDateTo, false);
				logger.message("getProfiles() -> filterDateTo2=" + filterDateTo);
			}
			totalResults = userProfileService.countUserProfilesByFilter(filterId, filterType, filterStructureType, filterUserUID, filterName, filterDateFrom, filterDateTo, filterStatus);
			if (totalResults > 0) {
				List<UserProfile> results = userProfileService.getAllUserProfilesByFilter(filterId, filterType, filterStructureType, filterUserUID, filterName, filterDateFrom, filterDateTo, filterStatus, start, length, orderColumn, order);
				if (results != null && results.size() > 0) {
					logger.message("getProfiles() -> results.size()=" + results.size());	
					JSONArray tmpJA = null; 
//					for (int i = 0; i < results.size(); i++) {
					for (int i = container.getStart(); i < results.size(); i++) {
						tmpJA = new JSONArray();
						tmpJA.put(results.get(i).getUserProfileId());
						tmpJA.put(results.get(i).getUserUID());
						tmpJA.put(results.get(i).getNames());
						tmpJA.put(results.get(i).getNameAndLegalForm() != null ? results.get(i).getNameAndLegalForm() : "");
						tmpJA.put(results.get(i).getEik() != null ? results.get(i).getEik() : "");
						tmpJA.put(results.get(i).getProfileType());						
						tmpJA.put(wcmCommunicator.getProfileTypeName(results.get(i).getProfileType() + ""));						
						tmpJA.put(utils.getProfileStructureTypeNames(results.get(i).getProfileStructureType()));						
						tmpJA.put(utils.timeMillisToDD_MM_YYYY_HH_MM_SS(results.get(i).getDateCreated().getTime()));
						tmpJA.put(utils.timeMillisToDD_MM_YYYY_HH_MM_SS(results.get(i).getDateModified().getTime()));
						tmpJA.put(utils.getProfileStatusName(results.get(i).getStatus(), resourceRequest));
						tmpJA.put(results.get(i).getUserProfileId());
						ja.put(tmpJA);						
					}				
				} else {
					logger.message("getProfiles() -> requests.length=0");
				}
			}
		} 
		json.put("draw", draw);	
		json.put("recordsTotal", totalResults);	
		json.put("recordsFiltered", totalResults);	
		json.put("data", ja);	
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	 
		
	}
	
	/*
	 * This resource mapping is called from tab "Profiles" and handle the block operation.
	 *
	 * @param profileId		the id of the profile that will be blocked.
	 * 
	 */
	@ResourceMapping(value = "blockProfile")
	public void blockProfile(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("profileId") Long userProfileId)
	{
		loadPreferences(resourceRequest);		
		logger.message("blockProfile");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONObject ja = new JSONObject();
		//UserProfile profile = null;
		boolean success = false;
//		try {
//			profile = registerGroupParameterService.getRegisterGroupParameterById(userProfileId);
//			if (profile != null) {
//				profile.setDateModified(new Date());
//				profile.setStatus(UserProfileManagerConstants.STATUS_BLOCKED);
//				if (registerGroupParameterService.updateStatusRegisterGroupParameter(profile)) {
//					success = true;
//					sessionBean.setMessage("Профил \"" + profile.getLabel() + "\" беше блокиран успешно.");
//					//esbCommunicator.sendEvent(sessionBean.getUserUID(), UserProfileManagerConstants.EVENT_LOG_PORTAL_DEACTIVATE_REGISTER_GROUP_PARAMETER, "Блокиране на профил - \"" + parameter.getLabel() + "\" (" + parameter.getRegisterGroupParameterId() + ")", null, utils.getRemoteIP(resourceRequest), false);
//					ja.put("result", "1");
//					ja.put("message", "Профил \"" + profile.getLabel() + "\" беше блокиран успешно.");
//				}
//			} 
//		} catch (Exception e) {
//			e.printStackTrace();
//		}	
		if (!success) {
			sessionBean.setError("Неуспешно блокиране на профил с номер " + userProfileId + ".");
			ja.put("result", "0");
			ja.put("message", "Неуспешно блокиране на профил с номер " + userProfileId + ".");
		}
		json.put("data", ja);
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	
	}
	
	/*
	 * This resource mapping is called from tab "New profile REIK" and handles the search EIK operation.
	 *
	 * @param eik		the EIK of LE that we need to find.
	 * 
	 */
	@ResourceMapping(value = "searchByEIKAddProfile")
	public void searchByEIKAddProfile(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("eik") String eik)
	{
		loadPreferences(resourceRequest);		
		logger.message("searchByEIKAddProfile");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONObject ja = new JSONObject();
		UserProfile userProfile = null;
		boolean success = false;
		try {
			// We do not support (REIK) more than 1 level for now.
			if (utils.isREIK(eik)) {
				ja.put("result", 0);
				ja.put("message", "Невалиден ЕИК " + eik + "!");
			} else {
				userProfile = userProfileService.getUserProfileByEik(eik); 
				if (userProfile != null) {
					success = true;
					if (UserProfileManagerConstants.USER_PROFILE_STATUS_ACTIVE == userProfile.getStatus()) {					
						if (UserProfileManagerConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER == userProfile.getProfileType() 
								|| UserProfileManagerConstants.USER_PROFILE_TYPE_LEGAL_ENTITY_AL2 == userProfile.getProfileType()) {
							ja.put("result", 1);
							JSONObject jo = new JSONObject();
							jo.put("name", userProfile.getNameAndLegalForm());
							jo.put("eik", userProfile.getEik());
							jo.put("type", UserProfileManagerConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER == userProfile.getProfileType() ? "Лице по чл. 1 ал. 1 от ЗЕУ" : "Лице по чл. 1 ал. 2 от ЗЕУ");
							ja.put("le", jo);
						} else {
							ja.put("result", 0);
							ja.put("message", "Профилът на ЮЛ с ЕИК " + eik + " не е по чл. 1 ал. 1 или чл. 1 ал. 2 от ЗЕУ!");
						}
					} else {
						ja.put("result", 0);
						ja.put("message", "Профилът на ЮЛ с ЕИК " + eik + " не е активен!");
					}
				} 
			}
		} catch (Exception e) {
			e.printStackTrace();
		}	
		if (!success) {
			ja.put("result", 0);
			ja.put("message", "ЮЛ с ЕИК " + eik + " не е намерено!");
		}
		json.put("data", ja);
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	
	}
	/*
	 * This resource mapping is called from tab "New profile REIK" and handles the search Personal Identifier operation.
	 *
	 * @param personalIdentifier		the personal Identifier of the user that we need to find.
	 * 
	 */
	@ResourceMapping(value = "searchByPersonalIdentifierAddProfile")
	public void searchByPersonalIdentifierAddProfile(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("personalIdentifier") String personalIdentifier)
	{
		loadPreferences(resourceRequest);		
		logger.message("searchByPersonalIdentifierAddProfile");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONObject ja = new JSONObject();
		UserProfile userProfile = null;
		boolean success = false;
		try {
			EncryptorAESGCM aesCls = new EncryptorAESGCM();
			String encryptedIdentfier = aesCls.encryptEgovIdentifier(personalIdentifier);
			userProfile = userProfileService.getUserProfileByIdentifierAndProfileType(encryptedIdentfier, UserProfileManagerConstants.USER_PROFILE_TYPE_PERSONAL);
			if (userProfile != null) {
				success = true;
				if (UserProfileManagerConstants.USER_PROFILE_STATUS_ACTIVE == userProfile.getStatus()) {					
					ja.put("result", 1);
					JSONObject jo = new JSONObject();
					jo.put("name", userProfile.getNames());
					jo.put("personalIdentifier", aesCls.decryptEgovIdentifier(userProfile.getIdentifier()));
					jo.put("profileId", userProfile.getUserProfileId());
					jo.put("userUID", userProfile.getUserUID());
					ja.put("user", jo);
				} else {
					ja.put("result", 0);
					ja.put("message", "Профилът на потребител с идентификатор " + personalIdentifier + " не е активен!");
				}
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}	
		if (!success) {
			ja.put("result", 0);
			ja.put("message", "Потребител с идентификатор " + personalIdentifier + " не е намерен!");
		}
		json.put("data", ja);
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	
	}
	

	/*
	 * This resource mapping is called from tab "Roles (XC)" 
	 *
	 * @param draw				UI parameter from Datatables.
	 * @param start 			page number (started from 0).
	 * @param length			results per page.
	 * @param order[0][column]	order column index.
	 * @param order[0][dir]		order column direction.
	 * 
	 */
	@ResourceMapping(value = "getHorizontalSystemRoles")
	public void getHorizontalSystemRoles(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("draw") Integer draw,
			@RequestParam("start") Integer start,
			@RequestParam("length") Integer length,
			@RequestParam("order[0][column]") Integer orderColumn,
			@RequestParam("order[0][dir]") String order)
	{
		loadPreferences(resourceRequest);		
		logger.message("getHorizontalSystemRoles");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONArray ja = new JSONArray();
		
		int totalResults = 0;
		if (sessionBean != null) {
			String currentPage = sessionBean.getCurrentPage();  
			Integer currentTab = sessionBean.getTabPerPage().get(currentPage);
			
			String uniquePath = currentPage + currentTab;
			Integer currentView = null;
			// We support views ONLY for tab "Roles (XC)".
			if (UserProfileManagerConstants.TAB_HS_ROLES == currentTab) {
				currentView = sessionBean.getViewPerTab().get(currentPage + currentTab);
				uniquePath += currentView.toString();				
			} 
			Container container = sessionBean.getContainer().get(uniquePath);
			if (container == null) {
				container = new Container();
			}			
			
			container.setResultsPerPage(length);
			container.setStart(start);
			container.setOrderColumn(orderColumn);
			container.setOrder(order);
			sessionBean.getContainer().put(uniquePath, container);
			
			String systemOID = container.getSystemOID();			
			logger.message("getHorizontalSystemRoles() -> length=" + length);
			logger.message("getHorizontalSystemRoles() -> start=" + start);
			logger.message("getHorizontalSystemRoles() -> orderColumn=" + orderColumn);
			logger.message("getHorizontalSystemRoles() -> order=" + order);
			logger.message("getHorizontalSystemRoles() -> systemOID=" + systemOID);
  			
			totalResults = hsRoleService.countAllBySystemOID(systemOID);
			if (totalResults > 0) {
				List<HorizontalSystemRole> results = hsRoleService.getAllBySystemOIDPaginated(systemOID, start, length, orderColumn, order);
				if (results != null && results.size() > 0) {
					logger.message("getHorizontalSystemRoles() -> results.size()=" + results.size());	
					JSONArray tmpJA = null; 
//					for (int i = 0; i < results.size(); i++) {
					for (int i = container.getStart(); i < results.size(); i++) {
						tmpJA = new JSONArray();
						tmpJA.put(results.get(i).getUid());
						tmpJA.put(results.get(i).getTitle());
						tmpJA.put(utils.getSystemNameByOID(results.get(i).getSystemOID()));						
						tmpJA.put(utils.timeMillisToDD_MM_YYYY_HH_MM_SS(results.get(i).getDateCreated().getTime()));
						tmpJA.put(utils.timeMillisToDD_MM_YYYY_HH_MM_SS(results.get(i).getDateModified().getTime()));
						ja.put(tmpJA);						
					}				
				} else {
					logger.message("getHorizontalSystemRoles() -> requests.length=0");
				}
			}
		} 
		json.put("draw", draw);	
		json.put("recordsTotal", totalResults);	
		json.put("recordsFiltered", totalResults);	
		json.put("data", ja);	
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	 
		
	}
	

	private void intializeBean() {
		System.out.println("in defaultView() !sessionBean.isInitialised()");
		try {
			String userUID = pumaCommunicator.getUserUID(pumaHome.getProfile().getCurrentUser(), pumaHome);
			sessionBean.setUserUID(userUID);
		} catch (PumaException e) {
			e.printStackTrace();
		}			
		sessionBean.setCurrentPage(UserProfileManagerConstants.INDEX_PAGE);
		HashMap<String, Integer> tabPerPage = sessionBean.getTabPerPage();
		tabPerPage.put(UserProfileManagerConstants.INDEX_PAGE, UserProfileManagerConstants.TAB_REQUESTS);
		sessionBean.setTabPerPage(tabPerPage);		
		sessionBean.setContainer(new HashMap<>());
		sessionBean.setInitialised(true);			
	}
	
	private void loadPreferences(PortletRequest request) {
		PortletPreferences prefs = request.getPreferences();		
		PortletViewController.resultsPerPage = Integer.parseInt(prefs.getValue(UserProfileManagerConstants.SETTING_PARAMETER_RESULTS_PER_PAGE, UserProfileManagerConstants.RESULTS_PER_PAGE + ""));
		PortletViewController.language = prefs.getValue(UserProfileManagerConstants.SETTING_PARAMETER_LANGUAGE, UserProfileManagerConstants.LANGUAGE_BG);
		PortletViewController.isDebug = "1".equalsIgnoreCase(prefs.getValue(UserProfileManagerConstants.SETTING_PARAMETER_DEBUG, ""));
		boolean test = !"PROD".equalsIgnoreCase(System.getProperty("environment")) && "TEST".equalsIgnoreCase(System.getProperty("environmentType"));
		PortletViewController.esbEventLogAddress = prefs.getValue(UserProfileManagerConstants.SETTING_PARAMETER_ESB_EVENT_LOGGER_ADDRESS, test ? UserProfileManagerConstants.ESB_LOGGING_URL_TEST : UserProfileManagerConstants.ESB_LOGGING_URL);		
		PortletViewController.mailSmtpHost = prefs.getValue(UserProfileManagerConstants.SETTING_PARAMETER_MAIL_SMTP_HOST, UserProfileManagerConstants.MAIL_SMTP_HOST);		
		PortletViewController.fromAddress = prefs.getValue(UserProfileManagerConstants.SETTING_PARAMETER_MAIL_FROM_ADDRESS, UserProfileManagerConstants.MAIL_FROM_ADDRESS);		
	}
		

}
