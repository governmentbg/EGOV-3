package bg.ibs.user.profile.manager.portlet.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class UserProfileRole {
	@Id	
	private Long userProfileRoleId;
	@Column(nullable = false)
	private Long userProfileId;
	@Column(nullable = false)
	private String userUID;	
	private Integer admin;
	private Integer editor;
	private Integer serviceManager;
	private Integer userRole;
	@Column(name = "dateCreated", nullable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
	private String email;
	private Integer confirm;
	private String code;
	
	public Long getUserProfileRoleId() {
		return userProfileRoleId;
	}
	public void setUserProfileRoleId(Long userProfileRoleId) {
		this.userProfileRoleId = userProfileRoleId;
	}
	public Long getUserProfileId() {
		return userProfileId;
	}
	public void setUserProfileId(Long userProfileId) {
		this.userProfileId = userProfileId;
	}
	public String getUserUID() {
		return userUID;
	}
	public void setUserUID(String userUID) {
		this.userUID = userUID;
	}
	public Integer getAdmin() {
		return admin;
	}
	public void setAdmin(Integer admin) {
		this.admin = admin;
	}
	public Integer getEditor() {
		return editor;
	}
	public void setEditor(Integer editor) {
		this.editor = editor;
	}
	public Integer getServiceManager() {
		return serviceManager;
	}
	public void setServiceManager(Integer serviceManager) {
		this.serviceManager = serviceManager;
	}
	public Integer getUserRole() {
		return userRole;
	}
	public void setUserRole(Integer userRole) {
		this.userRole = userRole;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Integer getConfirm() {
		return confirm;
	}
	public void setConfirm(Integer confirm) {
		this.confirm = confirm;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	
}
