package bg.ibs.user.profile.manager.portlet;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.web.context.annotation.SessionScope;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.InternalResourceView;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import bg.ibs.user.profile.manager.portlet.beans.UserProfileManagerSessionBean;

@Configuration 
@ComponentScan(basePackages = {"bg.ibs.user.profile.manager.portlet"})
public class AppConfig  {
		
	@Bean(name = "messageSource")
	public ReloadableResourceBundleMessageSource getMessageSource() {
      ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
      messageSource.setBasename("classpath:/bg/ibs/user/profile/manager/portlet/nl/UserProfileManagerPortletResource");
      messageSource.setFallbackToSystemLocale(false);
      //messageSource.setDefaultEncoding("UTF-8");
      messageSource.setUseCodeAsDefaultMessage(true);
      return messageSource;
	}
	
	@Bean(name = "viewResolver")
	public ViewResolver getViewResolver() {
	 InternalResourceViewResolver resolver = new InternalResourceViewResolver();
	 resolver.setViewClass(InternalResourceView.class);
	 resolver.setPrefix("/WEB-INF/jsp/");
	 resolver.setSuffix(".jsp");
	 resolver.setOrder(1);
//	 resolver.setViewClass(org.springframework.web.servlet.view.JstlView.class);
	 resolver.setContentType("text/html; charset=UTF-8");
	 resolver.setCache(true);
	 return resolver;
	}
	
//	@Bean(name = "dataSource")
//	DataSource dataSource() {
//		JndiDataSourceLookup dataSourceLookup = new JndiDataSourceLookup();
//		DataSource dataSource = dataSourceLookup.getDataSource(UserProfileManagerConstants.JNDI);
//        return dataSource;
//	}
	
	@Bean(name = "dataSource")
    public DataSource dataSource() {
		boolean isTestEnvironment = "TEST".equalsIgnoreCase(System.getProperty("environmentType"));
		if (isTestEnvironment) {
			JndiDataSourceLookup dataSourceLookup = new JndiDataSourceLookup();
			DataSource dataSource = dataSourceLookup.getDataSource(UserProfileManagerConstants.JNDI);
			return dataSource;
		}
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName("com.ibm.db2.jcc.DB2Driver");        
        dataSource.setUrl("_REPLACED_");
        dataSource.setUsername("_REPLACED_");
        dataSource.setPassword("_REPLACED_");
        return dataSource;
    }
	
	@Bean(name = "transactionManager")
    public DataSourceTransactionManager transactionManager() {
        return new DataSourceTransactionManager(dataSource());
    }
	
	@Bean
    @SessionScope
    public UserProfileManagerSessionBean sessionScopedBean() {
        return new UserProfileManagerSessionBean();
    }
}
