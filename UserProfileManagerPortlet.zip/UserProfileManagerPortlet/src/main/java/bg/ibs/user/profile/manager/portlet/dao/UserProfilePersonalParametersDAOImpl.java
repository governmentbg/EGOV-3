package bg.ibs.user.profile.manager.portlet.dao;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import bg.ibs.user.profile.manager.portlet.UserProfileManagerConstants;
import bg.ibs.user.profile.manager.portlet.model.UserProfilePersonalParameters;
import bg.ibs.user.profile.manager.portlet.model.UserProfilePersonalParametersMapper;
import bg.ibs.user.profile.manager.portlet.utils.UserProfileManagerLogger;

@Repository("UserProfilePersonalParametersDAO")
@Transactional
public class UserProfilePersonalParametersDAOImpl implements UserProfilePersonalParametersDAO { 
	private static final String TABLE_NAME = "UserProfilePersonalParameters";
	
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	UserProfileManagerLogger logger; 

	private final String SQL_FIND_PERSONAL_PARAMETERS = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userProfileId = ?";

	@Autowired
	public UserProfilePersonalParametersDAOImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public UserProfilePersonalParameters getUserProfilePersonalParametersByUserProfileId(final Long userProfileId) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_PERSONAL_PARAMETERS, new Object[] { userProfileId }, new UserProfilePersonalParametersMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
}
