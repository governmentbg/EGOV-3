package bg.ibs.user.profile.manager.portlet.model;

import java.util.Date;

public class UserProfileAndRole {
	private Long userProfileId;	
	private String identifier;
	private String names;
	private int status;
	private String deactivationReason;
	private String eik;
	private String nameAndLegalForm;
	private String qualityOfPhysicalPerson;
	private String methodOfRepresentation;
	private int profileType;	
	private String profileStructureType = null;
    private Date dateCreated;
    private Date dateModified;
	private String groupId;
	private String samlResponse;
	private String customSideNav;
	private String identifierPrefix;
	
	private Long userProfileRoleId;
	private String userUID;
	private Integer admin;
	private Integer editor;
	private Integer serviceManager;
	private Integer userRole;
	private String email;
	
	public Long getUserProfileId() {
		return userProfileId;
	}
	public void setUserProfileId(Long userProfileId) {
		this.userProfileId = userProfileId;
	}
	public String getIdentifier() {
		return identifier;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public String getNames() {
		return names;
	}
	public void setNames(String names) {
		this.names = names;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getDeactivationReason() {
		return deactivationReason;
	}
	public void setDeactivationReason(String deactivationReason) {
		this.deactivationReason = deactivationReason;
	}
	public String getEik() {
		return eik;
	}
	public void setEik(String eik) {
		this.eik = eik;
	}
	public String getNameAndLegalForm() {
		return nameAndLegalForm;
	}
	public void setNameAndLegalForm(String nameAndLegalForm) {
		this.nameAndLegalForm = nameAndLegalForm;
	}
	public String getQualityOfPhysicalPerson() {
		return qualityOfPhysicalPerson;
	}
	public void setQualityOfPhysicalPerson(String qualityOfPhysicalPerson) {
		this.qualityOfPhysicalPerson = qualityOfPhysicalPerson;
	}
	public String getMethodOfRepresentation() {
		return methodOfRepresentation;
	}
	public void setMethodOfRepresentation(String methodOfRepresentation) {
		this.methodOfRepresentation = methodOfRepresentation;
	}
	public int getProfileType() {
		return profileType;
	}
	public void setProfileType(int profileType) {
		this.profileType = profileType;
	}
	public String getProfileStructureType() {
		return profileStructureType;
	}
	public void setProfileStructureType(String profileStructureType) {
		this.profileStructureType = profileStructureType;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	public Date getDateModified() {
		return dateModified;
	}
	public void setDateModified(Date dateModified) {
		this.dateModified = dateModified;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getSamlResponse() {
		return samlResponse;
	}
	public void setSamlResponse(String samlResponse) {
		this.samlResponse = samlResponse;
	}
	public String getCustomSideNav() {
		return customSideNav;
	}
	public void setCustomSideNav(String customSideNav) {
		this.customSideNav = customSideNav;
	}	
	public String getIdentifierPrefix() {
		return identifierPrefix;
	}
	public void setIdentifierPrefix(String identifierPrefix) {
		this.identifierPrefix = identifierPrefix;
	}
	public Long getUserProfileRoleId() {
		return userProfileRoleId;
	}
	public void setUserProfileRoleId(Long userProfileRoleId) {
		this.userProfileRoleId = userProfileRoleId;
	}
	public String getUserUID() {
		return userUID;
	}
	public void setUserUID(String userUID) {
		this.userUID = userUID;
	}
	public int getAdmin() {
		return admin;
	}
	public void setAdmin(Integer admin) {
		this.admin = admin;
	}
	public int getEditor() {
		return editor;
	}
	public void setEditor(Integer editor) {
		this.editor = editor;
	}
	public int getServiceManager() {
		return serviceManager;
	}
	public void setServiceManager(Integer serviceManager) {
		this.serviceManager = serviceManager;
	}
	public int getUserRole() {
		return userRole;
	}
	public void setUserRole(Integer userRole) {
		this.userRole = userRole;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
}
