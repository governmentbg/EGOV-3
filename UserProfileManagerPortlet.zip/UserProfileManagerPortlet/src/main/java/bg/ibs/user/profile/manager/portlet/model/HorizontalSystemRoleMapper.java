package bg.ibs.user.profile.manager.portlet.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class HorizontalSystemRoleMapper implements RowMapper<HorizontalSystemRole> {

	public HorizontalSystemRole mapRow(ResultSet resultSet, int i) throws SQLException {

		HorizontalSystemRole role = new HorizontalSystemRole();
		role.setHorizontalSystemRoleId(resultSet.getLong("horizontalSystemRoleId"));
		role.setSystemOID(resultSet.getString("systemOID"));
		role.setUid(resultSet.getString("uid"));
		role.setTitle(resultSet.getString("title"));
		role.setDateCreated(resultSet.getDate("dateCreated"));
		role.setDateModified(resultSet.getDate("dateModified"));
		return role;
	}
}
