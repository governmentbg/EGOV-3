package bg.ibs.user.profile.manager.portlet.utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import javax.annotation.Resource;
import javax.portlet.ActionRequest;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequest;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import com.egov.wcm.cache.EgovEkatte;
import com.egov.wcm.cache.EgovWCMCache;

import bg.ibs.user.profile.manager.portlet.UserProfileManagerConstants;
import bg.ibs.user.profile.manager.portlet.beans.ProfileStructureTypeBean;
import bg.ibs.user.profile.manager.portlet.communicator.WCMCommunicator;
import bg.ibs.user.profile.manager.portlet.model.UserProfilePersonalParameters;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRole;

@Component
public class UserProfileManagerUtils {
	
	private static SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH);
	private static SimpleDateFormat dateTimeFormat_BG = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss", Locale.ENGLISH);
	private static SimpleDateFormat dateTimeFormat_bg = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.ENGLISH);
	
	@Resource(name = "messageSource")
	private MessageSource messageSource;
	
	@Autowired
	WCMCommunicator wcmCommunicator;
	
	@Autowired
	UserProfileManagerLogger logger;
	
	public String getRemoteIP(PortletRequest portletRequest) {
		String remoteIP = "localhost";	
		HttpServletRequest httpServletRequest = null;
		try {
			httpServletRequest = (HttpServletRequest) (com.ibm.ws.portletcontainer.portlet.PortletUtils.getHttpServletRequest(portletRequest));
			remoteIP = httpServletRequest.getHeader("X-FORWARDED-FOR");
			if (remoteIP == null) {
				remoteIP = httpServletRequest.getRemoteAddr();
			}				
		} catch (Exception e) {
			e.printStackTrace();
		}
		return remoteIP;
	}
	
	public String formatMultipleFieldsToOne(String str) {
		if (str == null || str.trim().length() == 0) {
			return null;
		}
		String[] types = str.split(",");
		String formatedTypes = "";
		for (int i = 0; i < types.length; i++) {
			formatedTypes += "^" + types[i] + "^";
		}
		return formatedTypes;
	}
	
	public Integer[] getArrayFromFormatedField(String str) {
		if (str != null && str.trim().length() > 0) {
			if (str.indexOf("^^") != -1) {
				String[] typeIds = str.split("\\^\\^");
				Integer[] types = new Integer[typeIds.length];
				for (int i = 0; i < typeIds.length; i++) {
					types[i] = Integer.parseInt(typeIds[i].replaceAll("\\^", ""));
				}
				return types;
			} else {
				return new Integer[] {Integer.parseInt(str.replaceAll("\\^", ""))};
			}
		}
		return null;
	}
	
	public String getRequestStatusName(int status, PortletRequest portletRequest) {
		if (UserProfileManagerConstants.USER_PROFILE_REQUEST_STATUS_APPROVED == status) { 
			return messageSource.getMessage("result.status.request.approved", null, getLocale(portletRequest));
		} else if (UserProfileManagerConstants.USER_PROFILE_REQUEST_STATUS_NOT_APPROVED == status) {
			return messageSource.getMessage("result.status.request.not.approved", null, getLocale(portletRequest));
		} else if (UserProfileManagerConstants.USER_PROFILE_REQUEST_STATUS_CANCELED == status) {
			return messageSource.getMessage("result.status.request.canceled", null, getLocale(portletRequest));
		}
		return "";
	}
	
	public String getProfileStatusName(int status, PortletRequest portletRequest) {
		if (UserProfileManagerConstants.USER_PROFILE_STATUS_ACTIVE == status) { 
			return messageSource.getMessage("result.status.active", null, getLocale(portletRequest));
		} else if (UserProfileManagerConstants.USER_PROFILE_STATUS_NOT_CONFIRMED == status) {
			return messageSource.getMessage("result.status.not.confirmed", null, getLocale(portletRequest));
		} else if (UserProfileManagerConstants.USER_PROFILE_STATUS_INACTIVE == status) {
			return messageSource.getMessage("result.status.inactive", null, getLocale(portletRequest));
		} else if (UserProfileManagerConstants.USER_PROFILE_STATUS_BLOCKED == status) {
			return messageSource.getMessage("result.status.blocked", null, getLocale(portletRequest));
		}
		return "";
	}
	
	public String getProfileStructureTypeNames(String profileStructureType) {
		if (profileStructureType != null && profileStructureType.trim().length() > 0) {
			if (profileStructureType.indexOf("^^") != -1) {
				String[] profileStructureTypeIds = profileStructureType.split("\\^\\^");
				String profileNames = "";
				for (int i = 0; i < profileStructureTypeIds.length; i++) {
					if (i > 0) {
						profileNames += ", ";
					}
					profileNames += wcmCommunicator.getProfileStructureTypeName(profileStructureTypeIds[i].replaceAll("\\^", ""));
				}
				return profileNames;
			} else {
				profileStructureType = profileStructureType.replaceAll("\\^", "");
				return wcmCommunicator.getProfileStructureTypeName(profileStructureType);
			}
		}
		return "";
	}
	
	public List<ProfileStructureTypeBean> getSelectedProfileStructureTypes(Object[] groupSelectedProfileStructureTypes) {
		List<ProfileStructureTypeBean> selectedProfileStructureTypes = new ArrayList<ProfileStructureTypeBean>();					
		String profileStructureTitle = null;
		ProfileStructureTypeBean tmpBean = null;
		if (groupSelectedProfileStructureTypes != null && groupSelectedProfileStructureTypes.length > 0) {
			for (int i = 0; i < groupSelectedProfileStructureTypes.length; i++) {
				profileStructureTitle = wcmCommunicator.getProfileStructureTypeName(groupSelectedProfileStructureTypes[i].toString());
				if (profileStructureTitle != null) {
					tmpBean = new ProfileStructureTypeBean();
					if (groupSelectedProfileStructureTypes[i] != null && groupSelectedProfileStructureTypes[i] instanceof Integer) {
						tmpBean.setName((Integer)groupSelectedProfileStructureTypes[i]);
					} else {
						tmpBean.setName(Integer.parseInt((String)groupSelectedProfileStructureTypes[i]));
					}
					tmpBean.setTitle(profileStructureTitle);
					selectedProfileStructureTypes.add(tmpBean);
				}
			}
		}
		return selectedProfileStructureTypes;
	}
	
	public List<UserProfileRole> getSelectedRolesFromForm(ActionRequest request, String selectedUsersStr) {
		logger.message("getSelectedRolesFromForm(" + selectedUsersStr + ") stared...");
		String[] selectedUsersArr = selectedUsersStr.split(",");
		List<UserProfileRole> selectedUsers = new ArrayList<>();
		UserProfileRole role = null;
		String userUID = null;
		String admin = null;
		String editor = null;
		String serviceManager = null;
		String user = null;
		for (int i = 0; i < selectedUsersArr.length; i++) {
			userUID = selectedUsersArr[i];
			admin = request.getParameter(userUID + "_admin");					
			editor = request.getParameter(userUID + "_editor");					
			serviceManager = request.getParameter(userUID + "_serviceManager");					
			user = request.getParameter(userUID + "_user");
			logger.message("getSelectedRolesFromForm [" + userUID + "] admin = " + admin);
			logger.message("getSelectedRolesFromForm [" + userUID + "] editor = " + editor);
			logger.message("getSelectedRolesFromForm [" + userUID + "] serviceManager = " + serviceManager);
			logger.message("getSelectedRolesFromForm [" + userUID + "] user = " + user);
			if (userUID != null && 
					(admin != null || editor != null || serviceManager != null || user != null)) {
				role = new UserProfileRole();
				role.setUserUID(userUID);
				role.setAdmin("1".equals(admin) ? 1 : null);
				role.setEditor("1".equals(editor) ? 1 : null);
				role.setServiceManager("1".equals(serviceManager) ? 1 : null);
				role.setUserRole("1".equals(user) ? 1 : null);
				selectedUsers.add(role);
			}
		}
		return selectedUsers;
	}
	
	public boolean hasUserWithAdminRole(List<UserProfileRole> users) {
		if (users != null && users.size() > 0) {
			for (int i = 0; i < users.size(); i++) {
				if (users.get(i).getAdmin() != null && users.get(i).getAdmin() == UserProfileManagerConstants.USER_PROFILE_ROLE_SELECTED) {
					return true;
				}
			}
		}
		return false;
	}

	public boolean hasRoleChange(UserProfileRole currentUser, UserProfileRole selectedUser) {
		logger.message("hasRoleChange() started...");
		if (currentUser != null && selectedUser != null) {
			if (!((currentUser.getAdmin() == 0 && selectedUser.getAdmin() == null)					
					|| (currentUser.getAdmin() != 0 && selectedUser.getAdmin() != null && currentUser.getAdmin() == selectedUser.getAdmin()))) {
				logger.message("hasRoleChange() - admin : true [" + currentUser.getAdmin() + "][" + selectedUser.getAdmin() + "]");
				return true;
			}
			if (!((currentUser.getEditor() == 0 && selectedUser.getEditor() == null)					
					|| (currentUser.getEditor() != 0 && selectedUser.getEditor() != null && currentUser.getEditor() == selectedUser.getEditor()))) {
				logger.message("hasRoleChange() - editor : true [" + currentUser.getEditor() + "][" + selectedUser.getEditor() + "]");
				return true;
			}
			if (!((currentUser.getServiceManager() == 0 && selectedUser.getServiceManager() == null)					
					|| (currentUser.getServiceManager() != 0 && selectedUser.getServiceManager() != null && currentUser.getServiceManager() == selectedUser.getServiceManager()))) {
				logger.message("hasRoleChange() - serviceManager : true [" + currentUser.getServiceManager() + "][" + selectedUser.getServiceManager() + "]");
				return true;
			}
			if (!((currentUser.getUserRole() == 0 && selectedUser.getUserRole() == null)					
					|| (currentUser.getUserRole() != 0 && selectedUser.getUserRole() != null && currentUser.getUserRole() == selectedUser.getUserRole()))) {
				logger.message("hasRoleChange() - user : true [" + currentUser.getUserRole() + "][" + selectedUser.getUserRole() + "]");
				return true;
			}
		}
		logger.message("hasRoleChange() return false");
		return false;
	}
	
	public String getFullAddress(final UserProfilePersonalParameters personalProfile) {
		String fullAddress = "";
		String divider = ", ";
		EgovEkatte ekatte = EgovWCMCache.getEkattesHm() != null ? EgovWCMCache.getEkattesHm().get(personalProfile.getEkatte()) : null;
		if (ekatte != null && ekatte.getParentCode() != null) {				
			String district = null;
			String municipality = null;
			String settlement = null;
			String area = null;
			while (ekatte != null && ekatte.getParentCode() != null) {
				if (EgovWCMCache.EKATTE_LEVEL_REGION.equalsIgnoreCase(ekatte.getLevel())) {						
					break;
				} else if (EgovWCMCache.EKATTE_LEVEL_DISTRICT.equalsIgnoreCase(ekatte.getLevel())) {
					district = ekatte.getName();
				} else if (EgovWCMCache.EKATTE_LEVEL_MUNICIPALITY.equalsIgnoreCase(ekatte.getLevel())) {
					municipality = ekatte.getName();
				} else if (EgovWCMCache.EKATTE_LEVEL_SETTLEMENT.equalsIgnoreCase(ekatte.getLevel())) {
					settlement = ekatte.getName();
				} else if (EgovWCMCache.EKATTE_LEVEL_AREA.equalsIgnoreCase(ekatte.getLevel())) {
					area = ekatte.getName();
				}
				ekatte = EgovWCMCache.getEkattesHm().get(ekatte.getParentCode());
			}
			if (district != null) {
				fullAddress += "Област: " + district;
			}
			if (municipality != null) {
				if (fullAddress.trim().length() > 0) {
					fullAddress += divider;
				}
				fullAddress += "Община: " + municipality;
			}				
			if (settlement != null) {
				if (fullAddress.trim().length() > 0) {
					fullAddress += divider;
				}
				fullAddress += "Населено място: " + settlement;
			}
			if (area != null) {
				if (fullAddress.trim().length() > 0) {
					fullAddress += divider;
				}
				fullAddress += "Район: " + area;
			}			
		}
		if (personalProfile.getAddressDescription() != null && personalProfile.getAddressDescription().trim().length() > 0) {
			if (fullAddress.trim().length() > 0) {
				fullAddress += divider;
			}
			fullAddress += personalProfile.getAddressDescription();
		} 
		if (personalProfile.getZipCode() != null && personalProfile.getZipCode().trim().length() > 0) {
			if (fullAddress.trim().length() > 0) {
				fullAddress += divider;
			}
			fullAddress += "п. код " + personalProfile.getZipCode();
		} 
		if (personalProfile.getMailBox() != null && personalProfile.getMailBox().trim().length() > 0) {
			if (fullAddress.trim().length() > 0) {
				fullAddress += divider;
			}
			fullAddress += "п. кутия " + personalProfile.getMailBox();
		} 
		return (fullAddress.trim().length() > 0) ? fullAddress : null;
	}	
	
	public Locale getLocale(PortletRequest request) {
		PortletPreferences prefs = request.getPreferences();
		return new Locale(prefs.getValue(UserProfileManagerConstants.SETTING_PARAMETER_LANGUAGE, UserProfileManagerConstants.LANGUAGE_BG));
	}
	
	// TODO get real data here.
	public String getSystemNameByOID(String systemOID) {
		if ("_REPLACED_".equals(systemOID)) {
			return "еВръчване";
		}
		return systemOID;
	}
	
	// Format is 
	// EIK [9 or 13 digits], REIK [17 digits]
	// REIK => EIK + 00000 + reikSeq = 17 digits
	public String generateREIK(String eik, String reikSeq) {
		String reik = "";
		int length = eik.length() + reikSeq.length();
		int maxLength = 17;
		if (length < maxLength) {
			reik = eik;
			for (int i = length; i < 17; i++) {
				reik += "0";
			}
			reik += reikSeq;
		} else {
			reik = eik + reikSeq;
		}
		return reik;
	}
	
	public boolean isREIK(String eik) {
		return eik != null && eik.trim().length() == 17;
	}
	
	public String timeMillisToYYYY_MM_DD_HH_MM_SS(final String timeMillis) {
		try {
			final Date date = new Date(Long.parseLong(timeMillis));
			return dateTimeFormat.format(date);
		} catch (Exception e) {
			System.out.println("Utils : timeMillisToYYYY_MM_DD_HH_MM_SS : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public String timeMillisToYYYY_MM_DD_HH_MM_SS(final long timeMillis) {
		try {
			final Date date = new Date(timeMillis);
			return dateTimeFormat.format(date);
		} catch (Exception e) {
			System.out.println("Utils : timeMillisToYYYY_MM_DD_HH_MM_SS : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}
	
	public String timeMillisToDD_MM_YYYY_HH_MM_SS(final long timeMillis) {
		try {
			final Date date = new Date(timeMillis);
			return dateTimeFormat_BG.format(date);
		} catch (Exception e) {
			System.out.println("Utils : timeMillisToDD_MM_YYYY_HH_MM_SS : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}
	
	public long date_TimestampToTimeMillis(final String s) {
		if (s != null) {
			try {
				return dateTimeFormat.parse(s).getTime();
			} catch (final Exception e) {
			}
		}
		return 0;
	}
	
	public String dateToDD_MM_YYYY_HH_MM_SS(final Date date) {
		try {
			return dateTimeFormat_bg.format(date);
		} catch (Exception e) {
			System.out.println("Utils : dateToDD_MM_YYYY_HH_MM_SS : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}


	public String timeMillisToTimestamp(final long millis) {
		try {

			return dateTimeFormat.format(new Date(millis));
		} catch (final Exception e) {
			System.out.println("Utils : timeMillisToTimestamp : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}
	
	public String dateBGToTimestampDate(final String date, final boolean begin) {
		if (date != null) {
			try {
				String[] parts = date.split("\\.");
				if (parts != null && parts.length == 3) {
					return parts[2] + "-" + parts[1] + "-" + parts[0] + " " + (begin ? "00:00:00" : "23:59:59");
				}
			} catch (final Exception e) {
				e.printStackTrace();
			}
		}
		return date;
	}
	
	// Generate a UUID compliant with RFC 4122.
	public String generateRNU() {
		return UUID.randomUUID().toString();
	}
	
	
}
