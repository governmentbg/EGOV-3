package bg.ibs.user.profile.manager.portlet.dao;

import java.util.Date;
import java.util.List;

import bg.ibs.user.profile.manager.portlet.beans.HorizontalSystemRoleESB;
import bg.ibs.user.profile.manager.portlet.model.HorizontalSystemRole;

public interface HorizontalSystemRoleDAO {	
	List<HorizontalSystemRole> getAllOrderBySystemOID();
	List<HorizontalSystemRole> getAllDistinctSystemOID();
	List<HorizontalSystemRole> getAllBySystemOID(String systemOID);	
	Integer countAllBySystemOID(String systemOID);	
	List<HorizontalSystemRole> getAllBySystemOIDPaginated(String systemOID, Integer start, Integer length, Integer orderColumn, String order);	
	Long createHorizontalSystemRole(HorizontalSystemRoleESB horizontalSystemRoleESB, Date currentDate);
	int updateHorizontalSystemRole(HorizontalSystemRole hsRole, HorizontalSystemRoleESB hsRoleESB, Date currentDate);
	void deleteAllByIds(List<Long> horizontalSystemRoleIds);
}
