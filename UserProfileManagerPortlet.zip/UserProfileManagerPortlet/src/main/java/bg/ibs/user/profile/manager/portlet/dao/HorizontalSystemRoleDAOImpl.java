package bg.ibs.user.profile.manager.portlet.dao;

import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Description;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import bg.ibs.user.profile.manager.portlet.UserProfileManagerConstants;
import bg.ibs.user.profile.manager.portlet.beans.HorizontalSystemRoleESB;
import bg.ibs.user.profile.manager.portlet.model.HorizontalSystemRole;
import bg.ibs.user.profile.manager.portlet.model.HorizontalSystemRoleDistinctMapper;
import bg.ibs.user.profile.manager.portlet.model.HorizontalSystemRoleMapper;
import bg.ibs.user.profile.manager.portlet.utils.UserProfileManagerLogger;
import bg.ibs.user.profile.manager.portlet.utils.UserProfileManagerUtils;

@Description("This class uses transaction from this article: https://www.tutorialspoint.com/spring/programmatic_management.htm")
@Repository("HorizontalSystemRoleDAO")
public class HorizontalSystemRoleDAOImpl implements HorizontalSystemRoleDAO { 
	private static final String TABLE_NAME = "HorizontalSystemRole";
	private static final String TABLE_USER_PROFILE_XC_ROLE_NAME = "UserProfileXCRole";
	private static final String HORIZONTAL_SYSTEM_ROLE_SEQUENCE_NAME = "SEQ_HORIZONTALSYSTEMROLE";
	
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	private PlatformTransactionManager transactionManager;
	
	@Autowired
	UserProfileManagerUtils utils; 
	
	@Autowired
	UserProfileManagerLogger logger; 

	private final String SQL_GET_ALL_ORDER_BY_SYSTEM_OID = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where 1=1 order by systemOID";
	private final String SQL_GET_ALL_DISTINCT_SYSTEM_OID = "select distinct systemOID from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where 1=1";
	private final String SQL_GET_ALL_BY_SYSTEM_OID = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where systemOID = ?";
	private final String SQL_COUNT = "select count(horizontalSystemRoleId) from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME;
	private final String SQL_SELECT_HORIZONTAL_SYSTEM_ROLE_SEQUENCE_NEXT_VAL = "select next value for " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + HORIZONTAL_SYSTEM_ROLE_SEQUENCE_NAME + " from SYSIBM.SYSDUMMY1";		
	private final String SQL_CREATE_HORIZONTAL_SYSTEM_ROLE = "insert into " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " (horizontalSystemRoleId, systemOID, uid, title, dateCreated, dateModified) values (?,?,?,?,?,?)";
	private final String SQL_UPDATE_HORIZONTAL_SYSTEM_ROLE = "update " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " set title = ?, dateModified = ? where horizontalSystemRoleId = ?";
	private final String SQL_DELETE_HORIZONTAL_SYSTEM_ROLE_BY_IDS = "delete from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where horizontalSystemRoleId in (%s)";
	private final String SQL_DELETE_USER_PROFILE_XC_ROLE_BY_HORIZONTALSYSTEMROLEIDS = "delete from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_USER_PROFILE_XC_ROLE_NAME + " where horizontalSystemRoleId in (%s)";

	@Autowired
	public HorizontalSystemRoleDAOImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public List<HorizontalSystemRole> getAllOrderBySystemOID() {
		return jdbcTemplate.query(SQL_GET_ALL_ORDER_BY_SYSTEM_OID, new HorizontalSystemRoleMapper());
	}
	
	public List<HorizontalSystemRole> getAllDistinctSystemOID() {
		return jdbcTemplate.query(SQL_GET_ALL_DISTINCT_SYSTEM_OID, new HorizontalSystemRoleDistinctMapper());
	}
	
	public List<HorizontalSystemRole> getAllBySystemOID(final String systemOID) {			
		return jdbcTemplate.query(SQL_GET_ALL_BY_SYSTEM_OID, new Object[] { systemOID }, new HorizontalSystemRoleMapper());
	}
	
	public Integer countAllBySystemOID(final String systemOID) {		
		String qWhere = " WHERE systemOID=?";		
		return jdbcTemplate.queryForObject(SQL_COUNT + qWhere, new Object[] { systemOID }, Integer.class);
	} 
	
	public List<HorizontalSystemRole> getAllBySystemOIDPaginated(final String systemOID, final Integer start, final Integer length, final Integer orderColumn, final String order) {
		String qOrder = "";
		if (orderColumn != null) {
			if (UserProfileManagerConstants.COLUMN_ID == orderColumn) {
				qOrder = " order by uid";
			} else if (UserProfileManagerConstants.COLUMN_HS_ROLES_TITLE == orderColumn) {
				qOrder = " order by title";			
			} else if (UserProfileManagerConstants.COLUMN_HS_ROLES_DATE_CREATED == orderColumn) {
				qOrder = " order by dateCreated";
			} else if (UserProfileManagerConstants.COLUMN_HS_ROLES_DATE_MODIFIED == orderColumn) {
				qOrder = " order by dateModified";		
			} else {
				qOrder = " order by title";
			}
		} 
		if (qOrder.trim().length() == 0) {
			qOrder = " order by title";
		}
		qOrder += " " + (UserProfileManagerConstants.ORDER_DESC.equalsIgnoreCase(order) ? UserProfileManagerConstants.ORDER_DESC : UserProfileManagerConstants.ORDER_ASC);
		
		// NOT SUPPORTED BY DB2, so we are doing workaround.
		//qOrder += " LIMIT " + start + ", " + length;				
		qOrder += " FETCH FIRST " + (start + length) + " ROWS ONLY";				
		return jdbcTemplate.query(SQL_GET_ALL_BY_SYSTEM_OID + qOrder, new Object[] { systemOID }, new HorizontalSystemRoleMapper());
	}
	
	private synchronized Long getHorizontalSystemRoleSequenceNextVal() {		
		return jdbcTemplate.queryForObject(SQL_SELECT_HORIZONTAL_SYSTEM_ROLE_SEQUENCE_NEXT_VAL + " where 1=1", Long.class);
	} // getNextVal

	public Long createHorizontalSystemRole(HorizontalSystemRoleESB hsRoleESB, Date currentDate) {
		//Date currentDate = new Date();
		// Insert role.
		Long horizontalSystemRoleId = getHorizontalSystemRoleSequenceNextVal();
		jdbcTemplate.update(SQL_CREATE_HORIZONTAL_SYSTEM_ROLE, new Object[] { 
				horizontalSystemRoleId,
				hsRoleESB.getSystemOID(),
				hsRoleESB.getUid(),
				hsRoleESB.getTitle(),
				currentDate,
				currentDate
		});	
		return horizontalSystemRoleId;
	}
	
	public int updateHorizontalSystemRole(HorizontalSystemRole hsRole, HorizontalSystemRoleESB hsRoleESB, Date currentDate) {
		//Date currentDate = new Date();
		// Update role.
		int result = jdbcTemplate.update(
				SQL_UPDATE_HORIZONTAL_SYSTEM_ROLE, 
				hsRoleESB.getTitle(),
				currentDate,
				hsRole.getHorizontalSystemRoleId()); 
		return result;
	}

	public void deleteAllByIds(final List<Long> horizontalSystemRoleIds) {
		if (horizontalSystemRoleIds == null || horizontalSystemRoleIds.size() == 0) return;	
		logger.message("deleteAllByIds() started...");
		TransactionDefinition def = new DefaultTransactionDefinition();
	    TransactionStatus status = transactionManager.getTransaction(def);
	    
	    try {
			String inSql = String.join(",", Collections.nCopies(horizontalSystemRoleIds.size(), "?"));
			// Delete all associations in user profile XC role table first.
			jdbcTemplate.update(String.format(SQL_DELETE_USER_PROFILE_XC_ROLE_BY_HORIZONTALSYSTEMROLEIDS, inSql), horizontalSystemRoleIds.toArray());
			// Delete from horizontal system role table.
			jdbcTemplate.update(String.format(SQL_DELETE_HORIZONTAL_SYSTEM_ROLE_BY_IDS, inSql), horizontalSystemRoleIds.toArray());
			transactionManager.commit(status);			
		} catch (Exception e) {
			e.printStackTrace();
			transactionManager.rollback(status);
		}
	}
	
}
