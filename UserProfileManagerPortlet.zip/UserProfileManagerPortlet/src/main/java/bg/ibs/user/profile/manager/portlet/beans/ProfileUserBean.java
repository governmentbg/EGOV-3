package bg.ibs.user.profile.manager.portlet.beans;

public class ProfileUserBean {
	String id = null;
	String name = null;
	boolean admin = false;
	boolean editor = false;
	boolean user = false;
	boolean serviceManager = false;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isAdmin() {
		return admin;
	}
	public void setAdmin(boolean admin) {
		this.admin = admin;
	}
	public boolean isEditor() {
		return editor;
	}
	public void setEditor(boolean editor) {
		this.editor = editor;
	}
	public boolean isUser() {
		return user;
	}
	public void setUser(boolean user) {
		this.user = user;
	}
	public boolean isServiceManager() {
		return serviceManager;
	}
	public void setServiceManager(boolean serviceManager) {
		this.serviceManager = serviceManager;
	}
	
}
