package bg.ibs.user.profile.manager.portlet.dao;

import java.util.Date;
import java.util.List;

import bg.ibs.user.profile.manager.portlet.model.UserProfile;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRequest;

public interface UserProfileRequestDAO {
	UserProfileRequest getUserProfileRequestById(Long id);
	UserProfileRequest getLastUserProfileRequestByUserUIDAndEIK(String userUID, String eik, boolean isREIK);
	UserProfileRequest getUserProfileRequestFileById(Long id);
	List<UserProfileRequest> getAllUserProfileRequests();  
	List<UserProfileRequest> getAllUserProfileRequestsByUserProfileId(Long userProfileId);  
	Integer countUserProfileRequestsByFilter(Long id, Long userProfileId, String name, Integer status);
	List<UserProfileRequest> getAllUserProfileRequestsByFilter(Long id, Long userProfileId, String name, Integer status, Integer start, Integer length, Integer orderColumn, String order);   	   
	UserProfile approveUserProfileRequest(UserProfileRequest userProfileRequest, String profileStructureType, Date currentDate);
	boolean cancelUserProfileRequest(UserProfileRequest userProfileRequest);
	boolean deleteUserProfileRequest(UserProfileRequest userProfileRequest);
	
}
