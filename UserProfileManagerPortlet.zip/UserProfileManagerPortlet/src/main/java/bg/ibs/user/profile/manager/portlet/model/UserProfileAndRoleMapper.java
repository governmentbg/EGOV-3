package bg.ibs.user.profile.manager.portlet.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class UserProfileAndRoleMapper implements RowMapper<UserProfileAndRole> {

	public UserProfileAndRole mapRow(ResultSet resultSet, int i) throws SQLException {
		UserProfileAndRole profileAndRole = new UserProfileAndRole();
		profileAndRole.setUserProfileId(resultSet.getLong(1));		
		profileAndRole.setIdentifier(resultSet.getString(2));
		profileAndRole.setNames(resultSet.getString(3));
		profileAndRole.setStatus(resultSet.getInt(4));
		profileAndRole.setDeactivationReason(resultSet.getString(5));
		profileAndRole.setEik(resultSet.getString(6));
		profileAndRole.setNameAndLegalForm(resultSet.getString(7));
		profileAndRole.setQualityOfPhysicalPerson(resultSet.getString(8));
		profileAndRole.setMethodOfRepresentation(resultSet.getString(9));
		profileAndRole.setProfileType(resultSet.getInt(10));
		profileAndRole.setProfileStructureType(resultSet.getString(11));
		profileAndRole.setDateCreated(resultSet.getDate(12));
		profileAndRole.setDateModified(resultSet.getDate(13));
		profileAndRole.setGroupId(resultSet.getString(14));
		profileAndRole.setSamlResponse(resultSet.getString(15));
		profileAndRole.setCustomSideNav(resultSet.getString(16));
		profileAndRole.setIdentifierPrefix(resultSet.getString(17));
       
		profileAndRole.setUserProfileRoleId(resultSet.getLong(18));
		profileAndRole.setUserUID(resultSet.getString(19));
		profileAndRole.setAdmin(resultSet.getInt(20));
		profileAndRole.setEditor(resultSet.getInt(21));
		profileAndRole.setServiceManager(resultSet.getInt(22));
		profileAndRole.setUserRole(resultSet.getInt(23));
		profileAndRole.setEmail(resultSet.getString(24));
		return profileAndRole;
	}
}
