package bg.ibs.user.profile.manager.portlet.model;

import java.sql.ResultSet;
//import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class UserProfileRequestMapper implements RowMapper<UserProfileRequest> {

	public UserProfileRequest mapRow(ResultSet resultSet, int i) throws SQLException {
//		ResultSetMetaData rsmd = resultSet.getMetaData();
//		for (int j = 1; j <= rsmd.getColumnCount(); j++) {
//			System.out.println("colName=" + rsmd.getColumnName(j));
//		}
		
		UserProfileRequest request = new UserProfileRequest();
		request.setUserProfileRequestId(resultSet.getLong("userProfileRequestId"));
		request.setUserProfileId(resultSet.getLong("userProfileId"));
		request.setProfileType(resultSet.getInt("profileType"));
		request.setEik(resultSet.getString("eik"));
		request.setNameAndLegalForm(resultSet.getString("nameAndLegalForm"));
		request.setOrderNumber(resultSet.getString("orderNumber"));
		request.setOrderDocumentName(resultSet.getString("orderDocumentName"));
		request.setOrderDocumentSize(resultSet.getInt("orderDocumentSize"));
		request.setOrderDocumentContentType(resultSet.getString("orderDocumentContentType"));
		request.setAccessKind(resultSet.getString("accessKind"));
		request.setStatus(resultSet.getInt("status"));
		request.setDateCreated(resultSet.getDate("dateCreated"));
		request.setDateApproved(resultSet.getDate("dateApproved"));
		request.setDateCanceled(resultSet.getDate("dateCanceled"));
		request.setCancelReason(resultSet.getString("cancelReason"));
		request.setUserUID(resultSet.getString("userUID"));
		request.setNames(resultSet.getString("names"));
		request.setProfileStructureType(resultSet.getString("profileStructureType"));
		request.setProfileStructureTypeOther(resultSet.getString("profileStructureTypeOther"));
		request.setLeUserProfileId(resultSet.getLong("leUserProfileId"));
		request.setReik(resultSet.getString("reik"));
		return request;
	}
}
