package bg.ibs.user.profile.manager.portlet.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import bg.ibs.user.profile.manager.portlet.dao.UserProfileRoleDAO;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRole;

@Service("UserProfileRoleService")
public class UserProfileRoleServiceImpl implements UserProfileRoleService {

	@Autowired
	@Qualifier("UserProfileRoleDAO")
	private UserProfileRoleDAO userProfileRoleDao; 
	
	public List<UserProfileRole> getAllUserProfileRolesByUserProfileId(Long userProfileId) {
		return userProfileRoleDao.getAllUserProfileRolesByUserProfileId(userProfileId);
	} 

	public List<UserProfileRole> getAllUserProfileRolesByUserProfileIdAndAdminRole(Long userProfileId) {
		return userProfileRoleDao.getAllUserProfileRolesByUserProfileIdAndAdminRole(userProfileId);
	} 
	
	public int updateAllUserProfileRolesForUserProfile(List<UserProfileRole> currentUsers, List<UserProfileRole> selectedUsers, Long userProfileId) {
		return userProfileRoleDao.updateAllUserProfileRolesForUserProfile(currentUsers, selectedUsers, userProfileId);
	}
}
