package bg.ibs.user.profile.manager.portlet.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Description;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import bg.ibs.user.profile.manager.portlet.UserProfileManagerConstants;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRef;
import bg.ibs.user.profile.manager.portlet.model.UserProfileRefMapper;
import bg.ibs.user.profile.manager.portlet.utils.UserProfileManagerLogger;
import bg.ibs.user.profile.manager.portlet.utils.UserProfileManagerUtils;

@Description("This class uses transaction from this article: https://www.tutorialspoint.com/spring/programmatic_management.htm")
@Repository("UserProfileRefDAO")
public class UserProfileRefDAOImpl implements UserProfileRefDAO { 
	private static final String TABLE_NAME = "UserProfileRef";
	
	JdbcTemplate jdbcTemplate;
	
	@Autowired
	UserProfileManagerUtils utils; 
	
	@Autowired
	UserProfileManagerLogger logger; 

	private final String SQL_GET_BY_ID = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userProfileRefId = ?";
	private final String SQL_GET_BY_USER_PROFILE_ID = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where userProfileId = ?";
	private final String SQL_GET_ALL_BY_PARENT_USER_PROFILE_ID = "select * from " + UserProfileManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where parentUserProfileId = ?";

	@Autowired
	public UserProfileRefDAOImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public UserProfileRef getById(final Long id) {
		return jdbcTemplate.queryForObject(SQL_GET_BY_ID, new Object[] { id }, new UserProfileRefMapper());
	}
	
	public UserProfileRef getByUserProfileId(final Long userProfileId) {
		return jdbcTemplate.queryForObject(SQL_GET_BY_USER_PROFILE_ID, new Object[] { userProfileId }, new UserProfileRefMapper());
	}
	
	public List<UserProfileRef> getAllByParentUserProfileId(final Long userProfileId) {
		return jdbcTemplate.query(SQL_GET_ALL_BY_PARENT_USER_PROFILE_ID, new Object[] { userProfileId }, new UserProfileRefMapper());
	}
	
}
