package bg.ibs.user.profile.manager.portlet.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class UserProfilePersonalParametersMapper implements RowMapper<UserProfilePersonalParameters> {

	public UserProfilePersonalParameters mapRow(ResultSet resultSet, int i) throws SQLException {

		UserProfilePersonalParameters personalParameters = new UserProfilePersonalParameters();
		personalParameters.setUserProfilePersonalParametersId(resultSet.getLong("userProfilePersonalParametersId"));
		personalParameters.setUserProfileId(resultSet.getLong("userProfileId"));
		personalParameters.setSecurityLevel(resultSet.getInt("securityLevel"));
		personalParameters.setConsentToUseAddress(resultSet.getInt("consentToUseAddress"));
		personalParameters.setEkatte(resultSet.getString("ekatte"));
		personalParameters.setAddressDescription(resultSet.getString("addressDescription"));
		personalParameters.setMailBox(resultSet.getString("mailBox"));
		personalParameters.setZipCode(resultSet.getString("zipCode"));
		personalParameters.setConsentToUsePhone(resultSet.getInt("consentToUsePhone"));
		personalParameters.setPhoneNumber(resultSet.getString("phoneNumber"));
		personalParameters.setConsentToUseEmail(resultSet.getInt("consentToUseEmail"));
		personalParameters.setEmail(resultSet.getString("email"));
		personalParameters.setGeneralConsent(resultSet.getInt("generalConsent"));
		
		return personalParameters;
	}
}
