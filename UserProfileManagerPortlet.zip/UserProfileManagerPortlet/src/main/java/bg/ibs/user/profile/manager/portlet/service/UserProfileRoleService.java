package bg.ibs.user.profile.manager.portlet.service;

import java.util.List;

import bg.ibs.user.profile.manager.portlet.model.UserProfileRole;

public interface UserProfileRoleService {
	List<UserProfileRole> getAllUserProfileRolesByUserProfileId(Long userProfileId);
	List<UserProfileRole> getAllUserProfileRolesByUserProfileIdAndAdminRole(Long userProfileId);
	int updateAllUserProfileRolesForUserProfile(List<UserProfileRole> currentUsers, List<UserProfileRole> selectedUsers, Long userProfileId);
}
