package bg.ibs.user.profile.manager.portlet.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class UserProfileRef {
	@Id	
	private Long userProfileRefId;
	@Column(nullable = false)
	private Long userProfileId;
	@Column(nullable = false)
	private String reik;	
	@Column(nullable = false)
	private String eik;	
	@Column(nullable = false)
	private Long parentUserProfileId;	
	@Column(nullable = false)
	private String parentUserProfileIds;		
	
	public Long getUserProfileRefId() {
		return userProfileRefId;
	}
	public void setUserProfileRefId(Long userProfileRefId) {
		this.userProfileRefId = userProfileRefId;
	}
	public Long getUserProfileId() {
		return userProfileId;
	}
	public void setUserProfileId(Long userProfileId) {
		this.userProfileId = userProfileId;
	}
	public String getReik() {
		return reik;
	}
	public void setReik(String reik) {
		this.reik = reik;
	}
	public String getEik() {
		return eik;
	}
	public void setEik(String eik) {
		this.eik = eik;
	}
	public Long getParentUserProfileId() {
		return parentUserProfileId;
	}
	public void setParentUserProfileId(Long parentUserProfileId) {
		this.parentUserProfileId = parentUserProfileId;
	}
	public String getParentUserProfileIds() {
		return parentUserProfileIds;
	}
	public void setParentUserProfileIds(String parentUserProfileIds) {
		this.parentUserProfileIds = parentUserProfileIds;
	}
	
}
