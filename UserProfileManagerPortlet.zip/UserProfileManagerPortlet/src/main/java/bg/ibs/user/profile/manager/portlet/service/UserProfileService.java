package bg.ibs.user.profile.manager.portlet.service;

import java.util.List;

import bg.ibs.user.profile.manager.portlet.model.UserProfile;
import bg.ibs.user.profile.manager.portlet.model.UserProfileAndRole;

public interface UserProfileService {
	UserProfile getUserProfileById(Long id);
	UserProfile getUserProfileByUserUidAndProfileType(String userUid, Integer profileType);
	List<UserProfile> getUserProfileByUserUidsAndProfileType(List<String> userUids, Integer profileType);
	List<UserProfile> getAllUserProfiles();
	Integer countUserProfilesByFilter(Long id, Integer profileType, Integer profileStructureType, String userUID, String name, Integer status);
	List<UserProfile> getAllUserProfilesByFilter(Long id, Integer profileType, Integer profileStructureType, String userUID, String name, Integer status, Integer start, Integer length, Integer orderColumn, String order);		
	UserProfile createUserProfile(UserProfile UserProfile);
	boolean updateUserProfile(UserProfile UserProfile);
	boolean deleteUserProfile(UserProfile userProfile);
	List<UserProfileAndRole> getUserProfileAndRolesByProfileId(Long profileId);
}
