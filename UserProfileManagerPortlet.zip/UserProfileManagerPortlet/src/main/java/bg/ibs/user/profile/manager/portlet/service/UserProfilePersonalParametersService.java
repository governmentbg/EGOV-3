package bg.ibs.user.profile.manager.portlet.service;

import bg.ibs.user.profile.manager.portlet.model.UserProfilePersonalParameters;

public interface UserProfilePersonalParametersService {
	UserProfilePersonalParameters getUserProfilePersonalParametersByUserProfileId(Long userProfileId);
}
