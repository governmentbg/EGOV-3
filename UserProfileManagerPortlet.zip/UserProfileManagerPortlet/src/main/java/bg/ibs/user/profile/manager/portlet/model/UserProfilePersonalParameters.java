package bg.ibs.user.profile.manager.portlet.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class UserProfilePersonalParameters {
	@Id	
	private Long userProfilePersonalParametersId;
	@Column(nullable = false)
	private Long userProfileId;
	private Integer securityLevel;
	private Integer consentToUseAddress;
	private String addressDescription;
	private String mailBox;
	private String zipCode;
	private Integer consentToUsePhone;
	private String phoneNumber;
	private Integer consentToUseEmail;
	private String email;
	private String ekatte;
	
	public Long getUserProfileId() {
		return userProfileId;
	}
	public void setUserProfileId(Long userProfileId) {
		this.userProfileId = userProfileId;
	}
	public Long getUserProfilePersonalParametersId() {
		return userProfilePersonalParametersId;
	}
	public void setUserProfilePersonalParametersId(Long userProfilePersonalParametersId) {
		this.userProfilePersonalParametersId = userProfilePersonalParametersId;
	}
	public Integer getSecurityLevel() {
		return securityLevel;
	}
	public void setSecurityLevel(Integer securityLevel) {
		this.securityLevel = securityLevel;
	}
	public Integer getConsentToUseAddress() {
		return consentToUseAddress;
	}
	public void setConsentToUseAddress(Integer consentToUseAddress) {
		this.consentToUseAddress = consentToUseAddress;
	}
	public String getAddressDescription() {
		return addressDescription;
	}
	public void setAddressDescription(String addressDescription) {
		this.addressDescription = addressDescription;
	}
	public String getMailBox() {
		return mailBox;
	}
	public void setMailBox(String mailBox) {
		this.mailBox = mailBox;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public Integer getConsentToUsePhone() {
		return consentToUsePhone;
	}
	public void setConsentToUsePhone(Integer consentToUsePhone) {
		this.consentToUsePhone = consentToUsePhone;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Integer getConsentToUseEmail() {
		return consentToUseEmail;
	}
	public void setConsentToUseEmail(Integer consentToUseEmail) {
		this.consentToUseEmail = consentToUseEmail;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getEkatte() {
		return ekatte;
	}
	public void setEkatte(String ekatte) {
		this.ekatte = ekatte;
	}
	
	
}
