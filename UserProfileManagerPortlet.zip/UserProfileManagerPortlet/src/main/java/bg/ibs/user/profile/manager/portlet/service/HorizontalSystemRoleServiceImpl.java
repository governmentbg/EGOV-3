package bg.ibs.user.profile.manager.portlet.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import bg.ibs.user.profile.manager.portlet.beans.HorizontalSystemRoleESB;
import bg.ibs.user.profile.manager.portlet.dao.HorizontalSystemRoleDAO;
import bg.ibs.user.profile.manager.portlet.model.HorizontalSystemRole;

@Service("HorizontalSystemRoleService")
public class HorizontalSystemRoleServiceImpl implements HorizontalSystemRoleService {

	@Autowired
	@Qualifier("HorizontalSystemRoleDAO")
	private HorizontalSystemRoleDAO horizontalSystemRoleDAO; 
	
	public List<HorizontalSystemRole> getAllOrderBySystemOID() {
		return horizontalSystemRoleDAO.getAllOrderBySystemOID();
	} 
	
	public List<HorizontalSystemRole> getAllDistinctSystemOID() {
		return horizontalSystemRoleDAO.getAllDistinctSystemOID();
	} 

	public List<HorizontalSystemRole> getAllBySystemOID(String systemOID) {
		return horizontalSystemRoleDAO.getAllBySystemOID(systemOID);
	} 
	
	public Integer countAllBySystemOID(String systemOID) {
		return horizontalSystemRoleDAO.countAllBySystemOID(systemOID);
	} 
	
	public List<HorizontalSystemRole> getAllBySystemOIDPaginated(String systemOID, Integer start, Integer length, Integer orderColumn, String order) {
		return horizontalSystemRoleDAO.getAllBySystemOIDPaginated(systemOID, start, length, orderColumn, order);
	} 

	public Long createHorizontalSystemRole(HorizontalSystemRoleESB hsRoleESB, Date currentDate) {
		return horizontalSystemRoleDAO.createHorizontalSystemRole(hsRoleESB, currentDate);
	}
	
	public int updateHorizontalSystemRole(HorizontalSystemRole hsRole, HorizontalSystemRoleESB hsRoleESB, Date currentDate) {
		return horizontalSystemRoleDAO.updateHorizontalSystemRole(hsRole, hsRoleESB, currentDate);
	}
	
	public void deleteAllByIds(List<Long> horizontalSystemRoleIds) {
		horizontalSystemRoleDAO.deleteAllByIds(horizontalSystemRoleIds);
	}
}
