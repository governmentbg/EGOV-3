package com.ibs.egov.rest.provider.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.egov.wcm.cache.EgovSearch;
import com.egov.wcm.cache.EgovService;
import com.egov.wcm.cache.EgovServiceProvider;
import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.Document;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentIterator;
import com.ibm.workplace.wcm.api.DocumentLibrary;
import com.ibm.workplace.wcm.api.DocumentTypes;
import com.ibm.workplace.wcm.api.Workspace;
import com.ibm.workplace.wcm.api.query.Conjunction;
import com.ibm.workplace.wcm.api.query.Disjunction;
import com.ibm.workplace.wcm.api.query.PageIterator;
import com.ibm.workplace.wcm.api.query.ProfileSelectors;
import com.ibm.workplace.wcm.api.query.Query;
import com.ibm.workplace.wcm.api.query.QueryDepth;
import com.ibm.workplace.wcm.api.query.ResultIterator;
import com.ibm.workplace.wcm.api.query.Selectors;
import com.ibm.workplace.wcm.api.query.SortDirection;
import com.ibm.workplace.wcm.api.query.Sorts;
import com.ibm.workplace.wcm.api.query.WorkflowSelectors;
import com.ibs.egov.rest.provider.EgovRestProviderContants;
import com.ibs.egov.rest.provider.communicator.EJournalCommunicator;
import com.ibs.egov.rest.provider.utils.EgovRestProviderUtils;
import com.ibs.egov.rest.provider.utils.EncryptorAESGCM;

@RestController
public class EgovRestController {
	
	@Autowired
	EJournalCommunicator eJournalCommunicator;
	@Autowired
	EncryptorAESGCM encryptorAESGCM;
	@Autowired
	EgovRestProviderUtils utils;
	
	private boolean isDebug = false;	
	private static final int RESULTS_PER_PAGE = 10;
	private static final int CURRENT_PAGE = 1;
	private static final int OFFSET = 5 * 60 * 1000; // 5 minutes.
	private Logger logger = LoggerFactory.getLogger(EgovRestController.class);
		
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@GetMapping("/get-service-providers-ar1-par2")
	public ResponseEntity<Object> getServiceProvidersArticle1Paragraph2(
			@RequestParam String path,
			@RequestParam("q") Optional<String> q,
			@RequestParam("rPP") Optional<Integer> resultsPerPage,
			@RequestParam("cP") Optional<Integer> currentPage,
			@RequestParam("debug") Optional<String> debug) {
		
		isDebug = (debug.isPresent() && "true".equalsIgnoreCase(debug.get()));		
		
		logMessage("getServiceProvidersArticle1Paragraph2() start...");
		logMessage("getServiceProvidersArticle1Paragraph2() -> path=" + path);
		logMessage("getServiceProvidersArticle1Paragraph2() -> rPP=" + (resultsPerPage.isPresent() ? resultsPerPage.get() : ""));
		logMessage("getServiceProvidersArticle1Paragraph2() -> cP=" + (currentPage.isPresent() ? currentPage.get() : ""));

		resultsPerPage = resultsPerPage.isPresent() ? resultsPerPage : Optional.of(RESULTS_PER_PAGE);
		currentPage = currentPage.isPresent() ? currentPage : Optional.of(CURRENT_PAGE);
		Map<String, Object> map = new HashMap<>();
		
		int totalResults = 0;
		int totalPages = 0;
		List<List<String>> results = new ArrayList<>();
		
		// Check we have data in cache.
		List<EgovServiceProvider> serviceProviders = EgovWCMCache.getServiceProviders();
		List<EgovServiceProvider> foundedServiceProviders = null;
		if (serviceProviders != null && serviceProviders.size() > 0) {
			logMessage("getServiceProvidersArticle1Paragraph2() has data in cache...");
			path = path.toLowerCase();
			foundedServiceProviders = new ArrayList<EgovServiceProvider>();
			for (int i = 0; i < serviceProviders.size(); i++) {
				if (serviceProviders.get(i).getContentPath() != null && serviceProviders.get(i).getContentPath().toLowerCase().indexOf(path) != -1) {
					foundedServiceProviders.add(serviceProviders.get(i));
				}
			}
			if (foundedServiceProviders == null || foundedServiceProviders.size() == 0) {
				// cache could be lazy, go get it from search collection.
				EgovSearch search = new EgovSearch();
				serviceProviders = search.searchServiceProviders(EgovWCMCache.SP_AUTHORING_TEMPLATE_SERVICE_PROVIDER_ARTICLE1_PARAGRAPH2_NAME, null, null, null, null, null, null, null, null);
				if (serviceProviders != null && serviceProviders.size() > 0) {
					for (int i = 0; i < serviceProviders.size(); i++) {
						if (serviceProviders.get(i).getContentPath() != null && serviceProviders.get(i).getContentPath().toLowerCase().indexOf(path) != -1) {
							foundedServiceProviders.add(serviceProviders.get(i));
						}
					}
				}
			}
			if (foundedServiceProviders != null && foundedServiceProviders.size() > 0) {
				results = new ArrayList<List<String>>();
				List<EgovServiceProvider> filtered = new ArrayList<EgovServiceProvider>();
				for (int i = (currentPage.get() - 1) * resultsPerPage.get(), j = 0; i < foundedServiceProviders.size(); i++, j++) {
					if (j == resultsPerPage.get()) {break;}
					filtered.add(foundedServiceProviders.get(i));					
				}
				if (q.isPresent() && q.get().trim().length() > 0) {
					filtered = utils.orderServiceProvidersBySearchTerm(filtered, q.get().toLowerCase());
				}
				results = utils.prepareJSONReponseForServiceProviders(filtered, null);
				totalResults = results.size();
				totalPages = (totalResults % resultsPerPage.get() == 0) ? totalResults / resultsPerPage.get() : (totalResults / resultsPerPage.get()) + 1;
			}  
			
		}
		// Load data from WCM DB.
		else {
			logMessage("getServiceProvidersArticle1Paragraph2() going to load through WCM API.");
			// Get target siteArea.
			DocumentId<Document> siteArea = null;
			DocumentIdIterator<Document> iterator = EgovWCMCache.getWorkspace().findAllByPath(path, DocumentTypes.SiteArea, Workspace.WORKFLOWSTATUS_PUBLISHED, new DocumentLibrary[] { EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)});
			if (iterator.hasNext()) { // Site area found.									
				siteArea = iterator.next(); 
				logMessage("getServiceProvidersArticle1Paragraph2(): SA founded!");
			}
			if (siteArea != null) { 
				Query query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
				query.addSelector(Selectors.libraryEquals(EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)));
				Conjunction and = new Conjunction();
				query.addParentId(siteArea, QueryDepth.CHILDREN);
				// Load only 'Published' contents.
				and.add(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
				// Load only providers with template article1paragraph2.
				and.add(
					Selectors.authoringTemplateIn(
						new DocumentId[] {
							EgovWCMCache.getATServiceProviderArticle1Paragraph2().getId()
						}
					)
				);
				// Load only 'Active' service providers.
				and.add(ProfileSelectors.categoriesContains(EgovWCMCache.getCategoryCommonActive().getId()));
				if (q.isPresent() && q.get().trim().length() > 0) {
					String searchTerm = q.get();
					if (searchTerm != null && searchTerm.trim().length() > 0) {
						// Stupid IBM function does not support case insensitive!
						Disjunction or = new Disjunction();
						or = new Disjunction();
						or.add(Selectors.titleLike("%" + searchTerm + "%"));
						or.add(Selectors.titleLike("%" + searchTerm.toLowerCase() + "%"));
						or.add(Selectors.titleLike("%" + searchTerm.toUpperCase() + "%"));
						if (searchTerm.trim().length() > 1) {
							if (!Character.isUpperCase(searchTerm.charAt(0))) {
								or.add(Selectors.titleLike("%" + searchTerm.substring(0, 1).toUpperCase() + searchTerm.substring(1) + "%"));
							}
							or.add(Selectors.titleLike("%" + utils.capitalizeString(searchTerm.trim()) + "%"));
						}
						or.add(Selectors.nameLike("%" + searchTerm + "%"));
						and.add(or);
					}
				} else {
					query.addSort(Sorts.byTitle(SortDirection.ASCENDING));
				}			
				query.addSelector(and);
				query.returnIds();
				PageIterator pageIterator;
				try {
					pageIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query, resultsPerPage.get(), currentPage.get());
					if (pageIterator != null && pageIterator.hasNext()) {					
						Content content = null;
						ArrayList<DocumentId> tmpIdArr = new ArrayList<>();
						ResultIterator docIterator = null;
						DocumentId contentDocId = null;
						int page = 0;
						docIterator = (ResultIterator) pageIterator.next();	
						logMessage("getServiceProvidersArticle1Paragraph2(): page=" + page);
						while (docIterator.hasNext()) {
							contentDocId = (DocumentId)docIterator.next();
							tmpIdArr.add(contentDocId);
							logMessage("getServiceProvidersArticle1Paragraph2(): name=" + contentDocId.getName());
						}
						DocumentId[] docIds = tmpIdArr.toArray(new DocumentId[tmpIdArr.size()]);
						DocumentIdIterator documentIdIterator = EgovWCMCache.getWorkspace().createDocumentIdIterator(docIds);
						DocumentIterator<Document> documentIterator = EgovWCMCache.getWorkspace().getByIds(documentIdIterator, true, false);
						int contents = 0;
						List<Content> founded = new ArrayList<Content>();
						while (documentIterator.hasNext()) {
							content = (Content) documentIterator.next();
							founded.add(content);												
							contents++;
						}
						results = utils.prepareJSONReponseForServiceProviders(null, founded);
						if (pageIterator.hasNext()) {
							contents = 0;
							while (pageIterator.hasNext()) {
								docIterator = (ResultIterator) pageIterator.next();
								page++;
								logMessage("getServiceProvidersArticle1Paragraph2(): page++=" + page);
							}
							while (docIterator.hasNext()) {
								logMessage("getServiceProvidersArticle1Paragraph2(): contents++=" + contents);
								docIterator.next();
								contents++;
							}					
						} 
						totalPages = currentPage.get() + page;
						totalResults = ((totalPages * resultsPerPage.get()) - resultsPerPage.get()) + contents;										
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		
		logMessage("getServiceProvidersArticle1Paragraph2(): totalPages=" + totalPages);
		logMessage("getServiceProvidersArticle1Paragraph2(): totalResults=" + totalResults);
		
		map.put("totalPages", totalPages);				
		map.put("totalResults", totalResults);
		map.put("data", results);
		
		logMessage("getServiceProvidersArticle1Paragraph2() end.");
		return ResponseEntity.ok(map);
	}
	
	@CrossOrigin(origins = {"https://testportal.egov.bg", "https://staging.egov.bg", "https://egov.bg"})
	@PostMapping("/ej")
	public ResponseEntity<Object> registerRequestServiceEventToEJournal(
			@RequestParam String token,
			@RequestParam("debug") Optional<String> debug,
			HttpServletRequest request,
	        HttpServletResponse response) {		
		Map<String, Object> map = new HashMap<>();
		// By Default Spring converts + to whitespace in the parameter, so we need to revert that.
		if (token != null) {
			token = token.replaceAll(" ", "+");
		}
		isDebug = (debug.isPresent() && "true".equalsIgnoreCase(debug.get()));
		if (!isDebug) {
			isDebug = "TEST".equalsIgnoreCase(System.getProperty("environmentType"));
		}
		if (debug != null && debug.isPresent()) {
			logger.info("token=" + token + ",remoteIP=" + utils.getRemoteIP(request));
		}
		
		if (token != null && token.trim().length() > 0) {
			String eJournalStrData = encryptorAESGCM.decryptEJournalData(token);
			if (eJournalStrData != null) {
				String[] eJournalData = eJournalStrData.split("_");
				if (eJournalData != null && eJournalData.length == 4) {
					try {
						long currentTime = System.currentTimeMillis();
						long operationTime = Long.parseLong(eJournalData[0]);
						String serviceName = eJournalData[1];
						// cut the milliseconds, as it looks like the search engine does not return them.
						long publishedTime = eJournalData[2].length() > 3 ? Long.parseLong(eJournalData[2].substring(0, eJournalData[2].length()-3)) : 0;
						String serviceID = eJournalData[3];
						
						// Check token is not expired!
						if (currentTime < operationTime + OFFSET) {
							logger.info("token is valid.");							
							EgovSearch search = new EgovSearch();
							logger.info("publishedTime=" + publishedTime);	
							EgovService service = search.searchServiceById(serviceID);
							if (service != null) {				
								// cut the milliseconds, as it looks like the search engine does not return them.
								long servicePublishedDate = service.getPublishedDate() != null ? Long.parseLong((String.valueOf(service.getPublishedDate().getTime()).substring(0, String.valueOf(service.getPublishedDate().getTime()).length() - 3))) : 0;
								logger.info("service is loaded.[" + servicePublishedDate + "]");	
								if (serviceName != null && serviceName.equalsIgnoreCase(service.getName()) 
										&& (publishedTime == 0 || publishedTime == servicePublishedDate)) {
									logger.info("All requisites match, proceed.");
									// All requisites match, proceed.
									eJournalCommunicator.sendRNU(utils.generateRNU(), EgovRestProviderContants.E_JOURNAL_STAGE_INITIALIZE, EgovRestProviderContants.E_JOURNAL_STATUS_REQUEST_SERVICE, operationTime, isDebug);
									
								}
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}					
				}				
				map.put("result", "ok");
				logger.info("ok.");
			} else {
				map.put("result", "error");
				map.put("errorCode", "404");
				map.put("message", "Invalid token!");
			}
		} else {
			map.put("result", "error");
			map.put("errorCode", "404");
			map.put("message", "Missing token!");	
		}		
		return ResponseEntity.ok(map);
	}
	
	@SuppressWarnings("unused")
	private void logError(String message) {
		logger.error(message);
	}
	private void logMessage(String message) {
//		logger.trace("A TRACE Message");
//      logger.debug("A DEBUG Message");
//      logger.info("An INFO Message");
//      logger.warn("A WARN Message");
//      logger.error("An ERROR Message");
		if (isDebug) {
			logger.info(message);
		}
	}
}
