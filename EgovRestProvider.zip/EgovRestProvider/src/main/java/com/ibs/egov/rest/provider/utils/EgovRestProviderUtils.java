package com.ibs.egov.rest.provider.utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Component;

import com.egov.wcm.cache.EgovServiceProvider;
import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.Content;
import com.ibs.egov.rest.provider.EgovRestProviderContants;

@Component
public class EgovRestProviderUtils {
	
	private static SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH);
	
	public String timeMillisToYYYY_MM_DD_HH_MM_SS(final long timeMillis) {
		try {
			final Date date = new Date(timeMillis);
			return dateTimeFormat.format(date);
		} catch (Exception e) {
			System.out.println("Utils : timeMillisToYYYY_MM_DD_HH_MM_SS : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}
	
	public ArrayList<EgovServiceProvider> orderServiceProvidersByTitle(List<EgovServiceProvider> services) {
		ArrayList<String> titles = new ArrayList<>();
		HashMap<String, ArrayList<EgovServiceProvider>> serviceProviderPerTitle = new HashMap<String, ArrayList<EgovServiceProvider>>(); 
		ArrayList<EgovServiceProvider> tmpServiceProviders = null;
		for (int i = 0; i < services.size(); i++) {
			if (!titles.contains(services.get(i).getTitle().toLowerCase())) {
				titles.add(services.get(i).getTitle().toLowerCase());
			}
			tmpServiceProviders = serviceProviderPerTitle.get(services.get(i).getTitle().toLowerCase());
			if (tmpServiceProviders == null) {
				tmpServiceProviders = new ArrayList<EgovServiceProvider>();
			}
			tmpServiceProviders.add(services.get(i));
			serviceProviderPerTitle.put(services.get(i).getTitle().toLowerCase(), tmpServiceProviders);
		}
		Collections.sort(titles);
		ArrayList<EgovServiceProvider> sortedServices = new ArrayList<>();
		for (int i = 0; i < titles.size(); i++) {
			tmpServiceProviders = serviceProviderPerTitle.get(titles.get(i));
			if (tmpServiceProviders != null && tmpServiceProviders.size() > 0) {
				for (int j = 0; j < tmpServiceProviders.size(); j++) {
					sortedServices.add(tmpServiceProviders.get(j));
				}
			}			
		}
		titles.clear();
		serviceProviderPerTitle.clear();
		if (tmpServiceProviders != null) {
			tmpServiceProviders.clear();
		}
		return sortedServices;
	}
	
	public ArrayList<EgovServiceProvider> orderServiceProvidersBySearchTerm(List<EgovServiceProvider> serviceProviders, String searchTerm) {
		int posTitle = -1;
		int posName = -1;
		ArrayList<Integer> positionsTitle = new ArrayList<>();
		ArrayList<Integer> positionsName = new ArrayList<>();
		HashMap<String, List<EgovServiceProvider>> servicePerPosTitle = new HashMap<String, List<EgovServiceProvider>>(); 
		HashMap<String, List<EgovServiceProvider>> servicePerPosName = new HashMap<String, List<EgovServiceProvider>>(); 
		List<EgovServiceProvider> tmpServiceProviders = null;
		for (int i = 0; i < serviceProviders.size(); i++) {
			posTitle = serviceProviders.get(i).getTitle().toLowerCase().indexOf(searchTerm);
			posName = serviceProviders.get(i).getName().toLowerCase().indexOf(searchTerm);
			if (posTitle != -1) {
				if (!positionsTitle.contains(posTitle)) {
					positionsTitle.add(posTitle);
				}
				tmpServiceProviders = servicePerPosTitle.get(posTitle + "");
				if (tmpServiceProviders == null) {
					tmpServiceProviders = new ArrayList<EgovServiceProvider>();
				}
				tmpServiceProviders.add(serviceProviders.get(i));
				servicePerPosTitle.put(posTitle + "", tmpServiceProviders);
			} else if (posName != -1) {
				if (!positionsName.contains(posName)) {
					positionsName.add(posName);
				}
				tmpServiceProviders = servicePerPosName.get(posName + "");
				if (tmpServiceProviders == null) {
					tmpServiceProviders = new ArrayList<EgovServiceProvider>();
				}
				tmpServiceProviders.add(serviceProviders.get(i));
				servicePerPosName.put(posName + "", tmpServiceProviders);
			}
			
		}
		Collections.sort(positionsTitle);
		Collections.sort(positionsName);
		ArrayList<EgovServiceProvider> sortedServices = new ArrayList<>();
		for (int i = 0; i < positionsTitle.size(); i++) {
			tmpServiceProviders = servicePerPosTitle.get(positionsTitle.get(i) + "");
			if (tmpServiceProviders != null && tmpServiceProviders.size() > 0) {
				if (tmpServiceProviders.size() > 1) {
					tmpServiceProviders = orderServiceProvidersByTitle(tmpServiceProviders);
				}
				for (int j = 0; j < tmpServiceProviders.size(); j++) {
					sortedServices.add(tmpServiceProviders.get(j));
				}
			}			
		}
		for (int i = 0; i < positionsName.size(); i++) {
			tmpServiceProviders = servicePerPosName.get(positionsName.get(i) + "");
			if (tmpServiceProviders != null && tmpServiceProviders.size() > 0) {
				for (int j = 0; j < tmpServiceProviders.size(); j++) {
					sortedServices.add(tmpServiceProviders.get(j));
				}
			}			
		}
		positionsTitle.clear();
		positionsName.clear();
		servicePerPosTitle.clear();
		servicePerPosName.clear();
		if (tmpServiceProviders != null) {
			tmpServiceProviders.clear();
		}
		return sortedServices;
	}
	
	public ArrayList<List<String>> prepareJSONReponseForServiceProviders(List<EgovServiceProvider> egovServiceProviders, List<Content> serviceProvidersWCM) {
		ArrayList<List<String>> results = new ArrayList<List<String>>(); 
		List<String> serviceProvider = null;
		if (egovServiceProviders != null && egovServiceProviders.size() > 0) {			
			EgovServiceProvider egovServiceProvider = null;
			for (int i = 0; i < egovServiceProviders.size(); i++) {
				egovServiceProvider = egovServiceProviders.get(i);
				serviceProvider = new ArrayList<String>();
				serviceProvider.add(egovServiceProvider.getId());
				serviceProvider.add(egovServiceProvider.getName());
				serviceProvider.add(egovServiceProvider.getTitle());
				try {
					serviceProvider.add(EgovRestProviderContants.dateFormat.format(egovServiceProvider.getPublishedDate()));
				} catch (Exception e) {
					serviceProvider.add("");
				}
				serviceProvider.add(EgovWCMCache.getATServiceProviderArticle1Paragraph2().getName());
				serviceProvider.add(egovServiceProvider.getParentName());
				results.add(serviceProvider);
			}
		} else if (serviceProvidersWCM != null && serviceProvidersWCM.size() > 0) {
			Content content = null;
			for (int i = 0; i < serviceProvidersWCM.size(); i++) {
				content = serviceProvidersWCM.get(i);
				serviceProvider = new ArrayList<String>();
				serviceProvider.add(content.getId().getID());
				serviceProvider.add(content.getName());
				serviceProvider.add(content.getTitle());
				try {
					serviceProvider.add(EgovRestProviderContants.dateFormat.format(content.getPublishedDate()));
				} catch (Exception e) {
					serviceProvider.add("");
				}
				serviceProvider.add(EgovWCMCache.getATServiceProviderArticle1Paragraph2().getName());
				serviceProvider.add(content.getParentId().getName());
				results.add(serviceProvider);	
			}
		}
		return results;
	}
	
	public String capitalizeString(String string) {
		char[] chars = string.toLowerCase().toCharArray();
		boolean found = false;
		for (int i = 0; i < chars.length; i++) {
			if (!found && Character.isLetter(chars[i])) {
				chars[i] = Character.toUpperCase(chars[i]);
				found = true;
			} else if (Character.isWhitespace(chars[i]) || chars[i] == '.' || chars[i] == '\'') { // You can add other
																									// chars here
				found = false;
			}
		}
		return String.valueOf(chars);
	} 
	
	// Generate a UUID compliant with RFC 4122.
	public String generateRNU() {
		return UUID.randomUUID().toString();
	}
	
	public String getRemoteIP(HttpServletRequest request) {
		String remoteIP = "localhost";	
		try {
			remoteIP = request.getHeader("X-FORWARDED-FOR");
			if (remoteIP == null) {
				remoteIP = request.getRemoteAddr();
			}				
		} catch (Exception e) {
			e.printStackTrace();
		}
		return remoteIP;
	}
	
}
