package com.ibs.egov.rest.provider;

import java.text.SimpleDateFormat;
import java.util.Locale;

public class EgovRestProviderContants {
	public static SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.ENGLISH);
}
