package com.ibs.egov.rest.provider;

import java.text.SimpleDateFormat;
import java.util.Locale;

public class EgovRestProviderContants {
	public static SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.ENGLISH);
	public static final String E_JOURNAL_SECRET_KEY_IN_BASE_64 = "_REPLACED_";
	
	
	public static final String PORTAL_OID = "_REPLACED_";
	
	// eJournal.
	public static final String E_JOURNAL_ADDRESS_PROD = "_REPLACED_";
	public static final String E_JOURNAL_ADDRESS_TEST = "_REPLACED_";
	
	public static final String E_JOURNAL_SYSTEM_OID_OWNER = "_REPLACED_";
	public static final int E_JOURNAL_ID_SERVICE_PARAM = _REPLACED_;
	
	public static final int E_JOURNAL_STAGE_INITIALIZE = 1;
	public static final int E_JOURNAL_STAGE_PAYMENT = 2;
	public static final int E_JOURNAL_STAGE_DELIVERY = 3;
	public static final int E_JOURNAL_STAGE_PROVISION = 4;
	public static final int E_JOURNAL_STAGE_CANCEL = 5;
	
	public static final int E_JOURNAL_STATUS_LOGIN_OR_CREATE_PE_PROFILE = 1;
	public static final int E_JOURNAL_STATUS_CREATE_LE_PROFILE = 2;
	public static final int E_JOURNAL_STATUS_ASSIGN_PE_PROFILE_TO_LE_PROFILE = 3;
	public static final int E_JOURNAL_STATUS_REMOVE_PE_PROFILE_FROM_LE_PROFILE = 4;
	public static final int E_JOURNAL_STATUS_CREATE_AUTHORIZATION = 5;
	public static final int E_JOURNAL_STATUS_CANCEL_AUTHORIZATION = 6;
	public static final int E_JOURNAL_STATUS_ACCESS_REGIX = 7;
	public static final int E_JOURNAL_STATUS_REQUEST_SERVICE = 8;
	public static final int E_JOURNAL_STATUS_PAYMENT_OF_OBLIGATION = 9;
	public static final int E_JOURNAL_STATUS_SEND_MESSAGE = 10;
	
}
