package com.ibs.egov.rest.provider.bean;

public class ServiceProvider {

}
