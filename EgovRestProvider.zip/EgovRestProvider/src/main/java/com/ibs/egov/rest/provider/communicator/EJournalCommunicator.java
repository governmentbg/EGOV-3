package com.ibs.egov.rest.provider.communicator;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ibs.egov.rest.provider.EgovRestProviderContants;
import com.ibs.egov.rest.provider.controller.EgovRestController;
import com.ibs.egov.rest.provider.utils.EgovRestProviderUtils;

/*
 * This Communicator exists also in MySpace, SignInEAvt & UserProfileManagerPortlet portlets app.
 */
@Component
public class EJournalCommunicator {
	//private static final String E_JOURNAL_TEST_ADDRESS = "http://172.23.101.81:9090/WsRNU/rest/test";
	
	@Autowired
	EgovRestProviderUtils utils;

	private Logger logger = LoggerFactory.getLogger(EgovRestController.class);
	
	public String sendRNU(String rnu, int stageId, int statusId, long operationTime, boolean isDebug) {	
		logMessage("EJournalCommunicator::sendRNU(" + rnu + "," + stageId + "," + statusId + "," + operationTime + ")", isDebug);		
		if (!"TEST".equalsIgnoreCase(System.getProperty("environmentType"))) {
			return "0";
		}
		String response = null;
		StringBuilder strBuf = new StringBuilder();	
		HttpURLConnection conn = null; 
		BufferedReader reader = null;
		boolean isProd = "PROD".equalsIgnoreCase(System.getProperty("environment"));
		String eJournalAddress = null;
		String jsonBody = ""					
				+ "{"
				+ "    \"serviceRefNumber\": \"" + rnu + "\","
				+ "    \"systemOID\": \"" + EgovRestProviderContants.PORTAL_OID + "\","
				+ "    \"subjectId\": \"\","
				+ "    \"subjectIdType\": \"\","
				+ "    \"subjectIdName\": \"\","
				+ "    \"systemOIDowner\": \"" + EgovRestProviderContants.E_JOURNAL_SYSTEM_OID_OWNER + "\","
				+ "    \"idStage\": \"" + stageId + "\",   "
				+ "    \"idService\": \"" + EgovRestProviderContants.E_JOURNAL_ID_SERVICE_PARAM + "\",   "
				+ "    \"idStatus\": \"" + statusId + "\",   "
				+ "    \"infoRelatedService\": \"\",   "
				+ "    \"timeStatusChange\": \"" + utils.timeMillisToYYYY_MM_DD_HH_MM_SS(operationTime) +  "\""
				+ "}";
		try {
			eJournalAddress = isProd ? EgovRestProviderContants.E_JOURNAL_ADDRESS_PROD : EgovRestProviderContants.E_JOURNAL_ADDRESS_TEST; 
			URL url = new URL(eJournalAddress); 
			conn = (HttpURLConnection) url.openConnection();
			
			byte[] postData = jsonBody.getBytes(StandardCharsets.UTF_8);
			int postDataLength = postData.length;			
			
			conn.setFixedLengthStreamingMode(postDataLength); 
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("Accept", "application/json");
			conn.setRequestProperty("Content-Length", Integer.toString(postDataLength));
			conn.setConnectTimeout(2000); //set timeout to 2 seconds
			conn.setReadTimeout(2000); //set timeout to 2 seconds
			conn.setDoOutput(true);
			conn.setUseCaches( false );
			
			try(OutputStream os = conn.getOutputStream()) {
				os.write(postData);
			}
			
			if (conn.getResponseCode() != 200) {
				System.err.println("ERROR calling -> [POST] eJournalAddress=" + eJournalAddress + " with jsonBody:" + jsonBody);
				throw new RuntimeException("HTTP POST Request Failed with Error code : " + conn.getResponseCode());
			}
			
			reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
			String output = null;
			while ((output = reader.readLine()) != null) {
				strBuf.append(output);
			}
			response = strBuf.toString();
			logMessage("EJournalCommunicator::sendRNU response:" + response, isDebug);
            if (response != null && response.trim().length() > 0) {
            	 JSONObject jo = new JSONObject(response);            
                 if (jo != null && jo.has("id")) {
                	 return jo.get("id").toString();
                 }
            }
		} catch (SocketTimeoutException e) {
			System.err.println("ERROR calling -> [POST] eJournalAddress=" + eJournalAddress + " with jsonBody:" + jsonBody);
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				conn.disconnect();
			}
		}
		return null;
	}
	
	@SuppressWarnings("unused")
	private void logError(String message) {
		logger.error(message);
	}
	private void logMessage(String message, boolean isDebug) {
		if (isDebug) {
			logger.info(message);
		}
	}

}
