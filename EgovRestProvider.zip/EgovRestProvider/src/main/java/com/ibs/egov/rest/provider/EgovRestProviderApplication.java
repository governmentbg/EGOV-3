package com.ibs.egov.rest.provider;

//import org.springframework.boot.SpringApplication;
//import org.springframework.boot.autoconfigure.SpringBootApplication;

//@SpringBootApplication
public class EgovRestProviderApplication {

//	public static void main(String[] args) {
//		SpringApplication.run(EgovRestProviderApplication.class, args);
//	}

}
