package bg.ibs.parameters.manager.portlet.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class RegisterGroup {
	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long registerGroupId;
	@Column(nullable = false)
	private String name;
	@Column(nullable = false)
	private String label;
	@Column(nullable = false)
	private String profileType;
	@Column(nullable = false)
	private String profileStructureType;
	@Column(nullable = false)
	private String weight;
	@Column(nullable = false)
	private int status;
	@Column(name = "dateCreated", nullable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
	
	@Column(name = "dateModified", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateModified;
	private String userId;
	
//	@OneToMany (mappedBy = "registerGroup")
//	private List<RegisterGroupParameter> registerGroupParameter;
	
	public Long getRegisterGroupId() {
		return registerGroupId;
	}
	public void setRegisterGroupId(Long registerGroupId) {
		this.registerGroupId = registerGroupId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getProfileType() {
		return profileType;
	}
	public void setProfileType(String profileType) {
		this.profileType = profileType;
	}
	public String getProfileStructureType() {
		return profileStructureType;
	}
	public void setProfileStructureType(String profileStructureType) {
		this.profileStructureType = profileStructureType;
	}
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	public Date getDateModified() {
		return dateModified;
	}
	public void setDateModified(Date dateModified) {
		this.dateModified = dateModified;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
}
