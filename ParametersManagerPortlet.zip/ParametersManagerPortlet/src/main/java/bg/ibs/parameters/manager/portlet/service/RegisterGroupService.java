package bg.ibs.parameters.manager.portlet.service;

import java.util.List;

import bg.ibs.parameters.manager.portlet.model.RegisterGroup;

public interface RegisterGroupService {
	RegisterGroup getRegisterGroupById(Long id);
	RegisterGroup getRegisterGroupByName(String name);
	RegisterGroup getRegisterGroupByNameExcId(String name, Long id);
	List<RegisterGroup> getAllRegisterGroupsByFilter(String label, Integer profileType, Integer profileStructureType, Integer status, Integer orderColumn, String order);		
	List<RegisterGroup> getAllRegisterGroups();		
	List<RegisterGroup> getAllRegisterGroupsByIds(List<Long> ids);		
	RegisterGroup createRegisterGroup(RegisterGroup registerGroup);
	boolean updateRegisterGroup(RegisterGroup registerGroup);
	boolean updateStatusRegisterGroup(RegisterGroup registerGroup);
	boolean deleteRegisterGroup(RegisterGroup registerGroup);	
}
