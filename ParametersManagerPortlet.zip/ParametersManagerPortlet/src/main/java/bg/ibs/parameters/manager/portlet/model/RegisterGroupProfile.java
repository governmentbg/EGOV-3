package bg.ibs.parameters.manager.portlet.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Deprecated
@Entity
public class RegisterGroupProfile {
	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long registerGroupProfileId;
	
	@Column(nullable = false)	
	@ManyToOne
    @JoinColumn(name = "registerGroupId")
    private RegisterGroup registerGroup;
	
	@Column(nullable = false)
	private int profileType;		
	@Column(nullable = false)
	private int weight;
	

	public Long getRegisterGroupProfileId() {
		return registerGroupProfileId;
	}
	public void setRegisterGroupProfileId(Long registerGroupProfileId) {
		this.registerGroupProfileId = registerGroupProfileId;
	}
	public RegisterGroup getRegisterGroup() {
		return registerGroup;
	}
	public void setRegisterGroup(RegisterGroup registerGroup) {
		this.registerGroup = registerGroup;
	}
	public int getProfileType() {
		return profileType;
	}
	public void setProfileType(int profileType) {
		this.profileType = profileType;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}

	
}
