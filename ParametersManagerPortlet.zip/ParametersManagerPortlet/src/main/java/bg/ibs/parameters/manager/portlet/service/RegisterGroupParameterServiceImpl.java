package bg.ibs.parameters.manager.portlet.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import bg.ibs.parameters.manager.portlet.dao.RegisterGroupParameterDAO;
import bg.ibs.parameters.manager.portlet.model.RegisterGroupParameter;

@Service("RegisterGroupParameterService")
public class RegisterGroupParameterServiceImpl implements RegisterGroupParameterService {

	@Autowired
	@Qualifier("RegisterGroupParameterDAO")
	private RegisterGroupParameterDAO registerGroupParameterDao; 
	
	public Integer countParametersByFilter(String label, Long groupId, Integer status) {
		return registerGroupParameterDao.countParametersByFilter(label, groupId, status);
	}
	
	public List<RegisterGroupParameter> getAllRegisterGroupParameters() {
		return registerGroupParameterDao.getAllRegisterGroupParameters();
	}
	
	public List<RegisterGroupParameter> getAllRegisterGroupParametersOrderByGroupIdAndWeight() {
		return registerGroupParameterDao.getAllRegisterGroupParametersOrderByGroupIdAndWeight();
	}

	public List<RegisterGroupParameter> getAllRegisterGroupParametersByFilter(String label, Long groupId, Integer status, Integer start, Integer length, Integer orderColumn, String order) {
		return registerGroupParameterDao.getAllRegisterGroupParametersByFilter(label, groupId, status, start, length, orderColumn, order);
	}
	
	public RegisterGroupParameter getRegisterGroupParameterById(Long id) {
		return registerGroupParameterDao.getRegisterGroupParameterById(id);
	}
	
	public RegisterGroupParameter getRegisterGroupParameterByName(String name) {
		return registerGroupParameterDao.getRegisterGroupParameterByName(name); 
	}
	
	public RegisterGroupParameter getRegisterGroupParameterByGroupIdAndName(Long groupId, String name) {
		return registerGroupParameterDao.getRegisterGroupParameterByGroupIdAndName(groupId, name); 
	}
	
	public RegisterGroupParameter getRegisterGroupParameterByGroupIdAndNameExcId(Long groupId, String name, Long parameterId) {
		return registerGroupParameterDao.getRegisterGroupParameterByGroupIdAndNameExcId(groupId, name, parameterId); 
	}
	
	public RegisterGroupParameter createRegisterGroupParameter(RegisterGroupParameter registerGroupParameter) {
		return registerGroupParameterDao.createRegisterGroupParameter(registerGroupParameter);
	}
	
	public boolean updateRegisterGroupParameter(RegisterGroupParameter registerGroupParameter) {
		return registerGroupParameterDao.updateRegisterGroupParameter(registerGroupParameter);
	}
	
	public boolean updateStatusRegisterGroupParameter(RegisterGroupParameter registerGroupParameter) {
		return registerGroupParameterDao.updateStatusRegisterGroupParameter(registerGroupParameter);
	}
	
	public boolean deleteRegisterGroupParameter(RegisterGroupParameter registerGroupParameter) {
		return registerGroupParameterDao.deleteRegisterGroupParameter(registerGroupParameter);
	}

}
