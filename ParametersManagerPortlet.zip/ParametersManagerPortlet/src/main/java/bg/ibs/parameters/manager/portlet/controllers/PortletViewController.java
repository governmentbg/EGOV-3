package bg.ibs.parameters.manager.portlet.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequest;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.portlet.ModelAndView;
import org.springframework.web.portlet.bind.annotation.ActionMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;
import org.springframework.web.portlet.bind.annotation.ResourceMapping;

import com.egov.wcm.cache.EgovProfileStructureType;
import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.portal.um.PumaHome;
import com.ibm.portal.um.exceptions.PumaException;
import com.ibm.workplace.wcm.api.Category;

import bg.ibs.parameters.manager.portlet.ParametersManagerConstants;
import bg.ibs.parameters.manager.portlet.beans.Container;
import bg.ibs.parameters.manager.portlet.beans.ParameterTypeBean;
import bg.ibs.parameters.manager.portlet.beans.ParametersManagerSessionBean;
import bg.ibs.parameters.manager.portlet.beans.ProfileTypeBean;
import bg.ibs.parameters.manager.portlet.communicator.ESBCommunicator;
import bg.ibs.parameters.manager.portlet.communicator.PumaCommunicator;
import bg.ibs.parameters.manager.portlet.communicator.WCMCommunicator;
import bg.ibs.parameters.manager.portlet.model.RegisterGroup;
import bg.ibs.parameters.manager.portlet.model.RegisterGroupParameter;
import bg.ibs.parameters.manager.portlet.service.RegisterGroupParameterService;
import bg.ibs.parameters.manager.portlet.service.RegisterGroupService;
import bg.ibs.parameters.manager.portlet.utils.ParametersManagerLogger;
import bg.ibs.parameters.manager.portlet.utils.ParametersManagerUtils;

@Controller
@RequestMapping("view")
public class PortletViewController {
	
	@Resource(name = "sessionScopedBean")
	ParametersManagerSessionBean sessionBean;
	
	@Resource(name = "messageSource")
	private MessageSource messageSource;
	
	@Autowired
	ParametersManagerLogger logger;
	@Autowired
	PumaCommunicator pumaCommunicator;
	@Autowired
	WCMCommunicator wcmCommunicator;
	@Autowired
	ESBCommunicator esbCommunicator;
	@Autowired
	ParametersManagerUtils utils;

	// Add ParametersCommunicator
	@Autowired
	RegisterGroupService registerGroupService;
	@Autowired
	RegisterGroupParameterService registerGroupParameterService;
	
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	
	private static PumaHome pumaHome = null;
	public static String language = ParametersManagerConstants.LANGUAGE_BG;
	public static String esbEventLogAddress = ParametersManagerConstants.ESB_LOGGING_URL;
	public static boolean isDebug = false;		
	
	
	@PostConstruct
	public void init() {
		InitialContext initialcontext;
		try {
			initialcontext = new InitialContext();
			pumaHome = (PumaHome) initialcontext.lookup("portal:service/usermanagement/Puma");
		} catch (NamingException namingexception) {
			namingexception.printStackTrace();
		}
	}
	
	@RenderMapping
	public ModelAndView defaultView(RenderRequest renderRequest, RenderResponse renderResponse) {
		loadPreferences(renderRequest);

		if (!sessionBean.isInitialised()) {
			intializeBean();				
		}			
		String currentPage = sessionBean.getCurrentPage();
		ModelAndView mv = new ModelAndView(currentPage);
		mv.addObject("userUID", sessionBean.getUserUID());					
		mv.addObject("language", language);					
		// Populate "ModelAndView" accordingly.
		if (ParametersManagerConstants.INDEX_PAGE.equals(currentPage)) {
			Integer currentTab = sessionBean.getTabPerPage().get(currentPage);
			String uniquePath = "";
			uniquePath = currentPage + currentTab;
			Integer currentView = null;
			if (ParametersManagerConstants.TAB_PROFILE_TYPES == currentTab) {
				currentView = sessionBean.getViewPerTab().get(currentPage + currentTab);
				uniquePath = currentPage + currentTab + currentView;
			}
			Container container = sessionBean.getContainer().get(uniquePath);			
			if (container == null) {
				container = new Container();
			}
			mv.addObject("currentTab", currentTab);
			
			if (ParametersManagerConstants.TAB_PROFILE_TYPES == currentTab) {
				mv.addObject("currentView", currentView);								
				if (ParametersManagerConstants.VIEW_PROFILE_TYPES == currentView) {
					mv.addObject("allProfileTypes", EgovWCMCache.getCategoriesProfileTypes());
				}
				if (ParametersManagerConstants.VIEW_GROUPS == currentView) {
					mv.addObject("currentProfileType", container.getProfileType());
					mv.addObject("currentProfileName", wcmCommunicator.getProfileTypeName(container.getProfileType() + ""));
					mv.addObject("filterLabel", container.getFilterLabel());
					mv.addObject("filterProfileType", container.getFilterProfileType());
					mv.addObject("filterProfileStructureType", container.getFilterProfileStructureType());
					mv.addObject("filterStatus", container.getFilterStatus());
					mv.addObject("allProfileStructureTypes", EgovWCMCache.getProfileStructureTypes());
				}
				if (ParametersManagerConstants.VIEW_PARAMETERS == currentView) {
					mv.addObject("currentProfileType", container.getProfileType());
					mv.addObject("currentProfileName", wcmCommunicator.getProfileTypeName(container.getProfileType() + ""));
					mv.addObject("currentGroup", container.getGroup());
					mv.addObject("filterLabel", container.getFilterLabel());
					mv.addObject("filterGroup", container.getFilterGroup());
					mv.addObject("filterStatus", container.getFilterStatus());
					mv.addObject("start", container.getStart());
					mv.addObject("resultsPerPage", container.getResultsPerPage());
					mv.addObject("allGroups", registerGroupService.getAllRegisterGroups());
				}
			} else if (ParametersManagerConstants.TAB_GROUPS == currentTab) {
				mv.addObject("filterLabel", container.getFilterLabel());
				mv.addObject("filterProfileType", container.getFilterProfileType());
				mv.addObject("filterProfileStructureType", container.getFilterProfileStructureType());
				mv.addObject("filterStatus", container.getFilterStatus());
				mv.addObject("allProfileTypes", EgovWCMCache.getCategoriesProfileTypes());
				mv.addObject("allProfileStructureTypes", EgovWCMCache.getProfileStructureTypes());
			} else if (ParametersManagerConstants.TAB_PARAMETERS == currentTab) {
				mv.addObject("currentGroup", new RegisterGroup());
				mv.addObject("filterLabel", container.getFilterLabel());
				mv.addObject("filterGroup", container.getFilterGroup());
				mv.addObject("filterStatus", container.getFilterStatus());
				mv.addObject("start", container.getStart());
				mv.addObject("resultsPerPage", container.getResultsPerPage());
				mv.addObject("allGroups", registerGroupService.getAllRegisterGroups());
			}
			
			mv.addObject("orderColumn", container.getOrderColumn());
			mv.addObject("order", container.getOrder().toLowerCase());
			
			
			
			System.out.println("in defaultView() userUID=" + sessionBean.getUserUID());
			System.out.println("in defaultView() currentPage=" + currentPage);
			System.out.println("in defaultView() currentTab=" + currentTab);
			
			System.out.println("in defaultView() currentView=" + currentView);				
			System.out.println("in defaultView() currentProfileType=" + container.getProfileType());
			System.out.println("defaultView() -> order=" + container.getOrder().toLowerCase());
			System.out.println("defaultView() -> orderColumn=" + container.getOrderColumn());
		} else if (ParametersManagerConstants.GROUP_PAGE.equals(currentPage)) {	
			mv = processGroupPage(renderRequest, renderResponse, mv);
		} else if (ParametersManagerConstants.PARAMETER_PAGE.equals(currentPage)) {	
			mv = processParameterPage(renderRequest, renderResponse, mv);
		}
		
		if (sessionBean.getError() != null) {
			mv.addObject("error", sessionBean.getError());
			sessionBean.setError(null);
		}
		if (sessionBean.getMessage() != null) {
			mv.addObject("message", sessionBean.getMessage());
			sessionBean.setMessage(null);
		}
		return mv;
	}
	
	/*
	 * This private method handles group page.	 
	 *
	 * @param renderRequest		render request.
	 * @param renderResponse	render response.
	 * @param mv		 		ModelAndView object.
	 * 
	 */
	private ModelAndView processGroupPage(RenderRequest renderRequest, RenderResponse renderResponse, ModelAndView mv) {
		List<Category> allProfileTypes = EgovWCMCache.getCategoriesProfileTypes();
		List<EgovProfileStructureType> allProfileStructureTypes = EgovWCMCache.getProfileStructureTypes();
		mv.addObject("allProfileTypes", allProfileTypes);
		mv.addObject("allProfileStructureTypes", allProfileStructureTypes);
		RegisterGroup group = new RegisterGroup();
		group.setStatus(ParametersManagerConstants.STATUS_ACTIVE);
		if (sessionBean.getId() != null) {
			group = registerGroupService.getRegisterGroupById(sessionBean.getId());	
			if (group == null || group.getRegisterGroupId() == null) {
				mv.addObject("error", "Група с номер \"" + sessionBean.getId() + "\" не е намерена в системата.");
				return mv;
			}				
			Integer[] groupProfileTypes = utils.getArrayFromFormatedField(group.getProfileType());
			if (groupProfileTypes != null && groupProfileTypes.length > 0) {
				Integer[] selectedProfileTypeWeights = utils.getArrayFromFormatedField(group.getWeight());
				if (selectedProfileTypeWeights == null || selectedProfileTypeWeights.length != groupProfileTypes.length) {
					mv.addObject("error", "Несъответствие между брой типове профили и поредност.");
					return mv;
				}															
				mv.addObject("selectedProfileTypes", utils.getSelectedProfileTypes(groupProfileTypes, selectedProfileTypeWeights));
			}
			mv.addObject("selectedProfileStructureTypes", utils.getSelectedProfileStructureTypes(utils.getArrayFromFormatedField(group.getProfileStructureType())));
			if (sessionBean.getMode() != null) {
				if (ParametersManagerConstants.MODE_EDIT == sessionBean.getMode()) {
					mv.addObject("edit", true);
					mv.addObject("read", false);												
				} else {
					mv.addObject("read", true);
					mv.addObject("edit", false);
				}
			}
		} else if (sessionBean.getProfileTypeId() != null) {
			ProfileTypeBean tmpBean = null;
			Category tmpCategoryProfileType = null;
			for (int i = 0; i < allProfileTypes.size(); i++) { 
				if (sessionBean.getProfileTypeId() == Integer.parseInt(allProfileTypes.get(i).getName())) {
					tmpCategoryProfileType = allProfileTypes.get(i);
					List<ProfileTypeBean> selectedProfileTypes = new ArrayList<ProfileTypeBean>();
					tmpBean = new ProfileTypeBean();
					tmpBean.setName(Integer.parseInt(tmpCategoryProfileType.getName()));
					tmpBean.setTitle(tmpCategoryProfileType.getTitle());
					tmpBean.setWeight(1);
					selectedProfileTypes.add(tmpBean);
					mv.addObject("selectedProfileTypes", selectedProfileTypes);
					break;
				}
			}
		}
		if (sessionBean.getError() != null) {
			group.setName(renderRequest.getParameter("name"));
			group.setLabel(renderRequest.getParameter("label"));
			if (renderRequest.getParameter("status") != null && renderRequest.getParameter("status").trim().length() > 0) {
				try {
					group.setStatus(Integer.parseInt(renderRequest.getParameter("status")));
				} catch (NumberFormatException e) {
					logger.error(e.getMessage());
				}
				
			}
			if (renderRequest.getParameter("selectedProfileTypes") != null && renderRequest.getParameter("selectedProfileTypes").trim().length() > 0) {
				String[] groupProfileTypes = renderRequest.getParameter("selectedProfileTypes").split(",");
				String[] selectedProfileTypeWeights = renderRequest.getParameter("selectedProfileTypeWeights").split(",");
				mv.addObject("selectedProfileTypes", utils.getSelectedProfileTypes(groupProfileTypes, selectedProfileTypeWeights));
			} 
			
			if (renderRequest.getParameter("selectedProfileStructureTypes") != null && renderRequest.getParameter("selectedProfileStructureTypes").trim().length() > 0) {
				mv.addObject("selectedProfileStructureTypes", utils.getSelectedProfileStructureTypes(renderRequest.getParameter("selectedProfileStructureTypes").split(",")));					
			} else {
				mv.addObject("selectedProfileStructureTypes", null);
			}
		}
		mv.addObject("group", group);
		mv.addObject("weights", new Integer[100]);
		return mv;
	}
	
	/*
	 * This private method handles parameter page.	 
	 *
	 * @param renderRequest		render request.
	 * @param renderResponse	render response.
	 * @param mv		 		ModelAndView object.
	 * 
	 */
	private ModelAndView processParameterPage(RenderRequest renderRequest, RenderResponse renderResponse, ModelAndView mv) {
		RegisterGroupParameter parameter = new RegisterGroupParameter();
		parameter.setStatus(ParametersManagerConstants.STATUS_ACTIVE);
		parameter.setRequired(ParametersManagerConstants.VALUE_NO);
		parameter.setConsent(ParametersManagerConstants.VALUE_YES);
		if (sessionBean.getId() != null) {
			parameter = registerGroupParameterService.getRegisterGroupParameterById(sessionBean.getId());	
			if (parameter == null || parameter.getRegisterGroupId() == null) {
				mv.addObject("error", "Параметър с номер \"" + sessionBean.getId() + "\" не е намерен в системата.");
				return mv;
			}				
			if (sessionBean.getMode() != null) {
				if (ParametersManagerConstants.MODE_EDIT == sessionBean.getMode()) {
					mv.addObject("edit", true);
					mv.addObject("read", false);												
				} else {
					mv.addObject("read", true);
					mv.addObject("edit", false);
				}
			}
		} else if (sessionBean.getGroupId() != null) {
			parameter.setRegisterGroupId(new Long(sessionBean.getGroupId()));
		}
		if (sessionBean.getError() != null) {
			parameter.setName(renderRequest.getParameter("name"));
			parameter.setLabel(renderRequest.getParameter("label"));
			
			if (renderRequest.getParameter("groupId") != null && renderRequest.getParameter("groupId").trim().length() > 0) {
				try {
					parameter.setRegisterGroupId(Long.parseLong(renderRequest.getParameter("groupId")));
				} catch (NumberFormatException e) {logger.error(e.getMessage());}
			}
			if (renderRequest.getParameter("parameterType") != null && renderRequest.getParameter("parameterType").trim().length() > 0) {
				try {
					parameter.setParameterType(Integer.parseInt(renderRequest.getParameter("parameterType")));
				} catch (NumberFormatException e) {logger.error(e.getMessage());}
			}
			if (renderRequest.getParameter("parameterTypeValue") != null && renderRequest.getParameter("parameterTypeValue").trim().length() > 0) {
				parameter.setParameterValue(renderRequest.getParameter("parameterTypeValue"));				
			}
			if (renderRequest.getParameter("defaultValue") != null && renderRequest.getParameter("defaultValue").trim().length() > 0) {
				parameter.setDefaultValue(renderRequest.getParameter("defaultValue"));				
			}
			if (renderRequest.getParameter("weight") != null && renderRequest.getParameter("weight").trim().length() > 0) {
				try {
					parameter.setWeight(Integer.parseInt(renderRequest.getParameter("weight")));
				} catch (NumberFormatException e) {logger.error(e.getMessage());}
			}
			if (renderRequest.getParameter("description") != null && renderRequest.getParameter("description").trim().length() > 0) {
				parameter.setDefaultValue(renderRequest.getParameter("description"));				
			}
			if (renderRequest.getParameter("header") != null && renderRequest.getParameter("header").trim().length() > 0) {
				parameter.setDefaultValue(renderRequest.getParameter("header"));				
			}
			if (renderRequest.getParameter("status") != null && renderRequest.getParameter("status").trim().length() > 0) {
				try {
					parameter.setStatus(Integer.parseInt(renderRequest.getParameter("status")));
				} catch (NumberFormatException e) {logger.error(e.getMessage());}
			}
			if (renderRequest.getParameter("required") != null && renderRequest.getParameter("required").trim().length() > 0) {
				try {
					parameter.setRequired(Integer.parseInt(renderRequest.getParameter("required")));
				} catch (NumberFormatException e) {logger.error(e.getMessage());}
			}
			if (renderRequest.getParameter("consent") != null && renderRequest.getParameter("consent").trim().length() > 0) {
				try {
					parameter.setConsent(Integer.parseInt(renderRequest.getParameter("consent")));
				} catch (NumberFormatException e) {logger.error(e.getMessage());}
			}
		}
		List<RegisterGroup> allGroups = registerGroupService.getAllRegisterGroups();
		mv.addObject("allGroups", allGroups);
		ParameterTypeBean[] parameterTypes = new ParameterTypeBean[ParametersManagerConstants.PARAMETER_TYPES_IDS.length];
		for (int i = 0; i < ParametersManagerConstants.PARAMETER_TYPES_IDS.length; i++) {
			parameterTypes[i] = new ParameterTypeBean();
			parameterTypes[i].setId(ParametersManagerConstants.PARAMETER_TYPES_IDS[i]);
			parameterTypes[i].setTitle(ParametersManagerConstants.PARAMETER_TYPES_NAMES[i]);
		}
		mv.addObject("parameterTypes", parameterTypes);
		mv.addObject("parameter", parameter);
		mv.addObject("weights", new Integer[100]);
		return mv;
	}
	
	/*
	 * This action is called from buttons "Add/Edit Group"
	 * and "Add/Edit Parameter". 
	 *
	 * @param page			the page name to switch to.
	 * @param id		 	the id of the object we will work with (group/parameter).
	 * 
	 */
	@ActionMapping(value = "changePage")
	public void changePage(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "page") String page,			
			@RequestParam(value = "id", required = false) Long id,
			@RequestParam(value = "profileTypeId", required = false) Integer profileTypeId,
			@RequestParam(value = "groupId", required = false) Long groupId,
			@RequestParam(value = "mode", required = false) Integer mode) {
		logger.message("changePage [" + page + "][" + id + "][" + mode + "]" + actionRequest.getParameter("id"));
		sessionBean.setCurrentPage(page);		
		sessionBean.setId(id);
		sessionBean.setProfileTypeId(profileTypeId);
		sessionBean.setGroupId(groupId);
		sessionBean.setMode(mode);
		// Returns control to default view.
	}
	
	/*
	 * This action is called from form "reloadPage"
	 *
	 */
	@ActionMapping(value = "reloadPage")
	public void reloadPage(
			ActionRequest actionRequest, ActionResponse actionResponse) {
		logger.message("reloadPage");		
		// Returns control to default view.
	}
	
	
	/*
	 * This action is called from main tabs.
	 *
	 * @param tab			the tab id to switch to.
	 * 
	 */
	@ActionMapping(value = "changeTab")
	public void changeTab(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "tab") Integer tab) {
		logger.message("changeTab [" + tab+ "]");
		String currentPage = sessionBean.getCurrentPage();
		sessionBean.getTabPerPage().put(currentPage, tab);
		// Returns control to default view.
	}
	
	
	/*
	 * This action is called from tab "Profiles"
	 * and is responsible for toggle among different views. 
	 *
	 * @param view			the view id to switch to.
	 * @param profileType 	the profile type to which the view will filter the results.
	 * 
	 */
	@ActionMapping(value = "changeView")
	public void changeView(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "view") Integer view,
			@RequestParam(value = "profileType", required = false) Integer profileType,
			@RequestParam(value = "groupId", required = false) Long groupId) {
		logger.message("changeView [" + view + "]");
		String currentPage = sessionBean.getCurrentPage();
		Integer currentTab = sessionBean.getTabPerPage().get(currentPage);
		try {
			HashMap<String, Integer> viewPerTab = sessionBean.getViewPerTab();
			viewPerTab.put(currentPage + currentTab, view);
			sessionBean.setViewPerTab(viewPerTab);
			Container container = sessionBean.getContainer().get(currentPage + currentTab + view);
			if (container == null) {
				container = new Container();	
				if (ParametersManagerConstants.VIEW_GROUPS == view) {
					container.setOrderColumn(ParametersManagerConstants.COLUMN_GROUPS_WEIGHT);
				} else {
					container.setOrderColumn(ParametersManagerConstants.COLUMN_PARAMETERS_WEIGHT);
				}
				container.setOrder(ParametersManagerConstants.ORDER_ASC);
			}
			if (ParametersManagerConstants.VIEW_GROUPS == view) {
				container.setFilterProfileType(profileType);
			}
			if (ParametersManagerConstants.VIEW_PARAMETERS == view) {
				container.setFilterGroup(groupId);
			}
			container.setProfileType(profileType);
			if (groupId != null) {
				// Load group.
				container.setGroup(registerGroupService.getRegisterGroupById(groupId));
			} else {
				container.setGroup(null);
			}
			sessionBean.getContainer().put(currentPage + currentTab + view, container);
			
			container = sessionBean.getContainer().get(currentPage + currentTab + view);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		// Returns control to default view.
	}
	
	
	/*
	 * This action is called from tab "Profiles" -> view "Groups"
	 * and also called from tab "Groups" 
	 *
	 * @param label			the label of the group.
	 * @param profileType 	the profile type to which the group is member of.
	 * @param status		boolean active/inactive.
	 * 
	 */
	@ActionMapping(value = "searchFilterGroups")
	public void searchFilterGroups(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "label", required = false) String label,
			@RequestParam(value = "profileType", required = false) Integer profileType,
			@RequestParam(value = "profileStructureType", required = false) Integer profileStructureType,
			@RequestParam(value = "status", required = false) Integer status) 
	{
		loadPreferences(actionRequest);
		logger.message("searchFilterGroups");
		logger.message("label=" + (label != null ? label : ""));
		logger.message("profileType=" + (profileType != null ? profileType : ""));
		logger.message("profileStructureType=" + (profileStructureType != null ? profileStructureType : ""));
		logger.message("status=" + (status != null ? status : ""));
		if (sessionBean != null) {
			String currentPage = sessionBean.getCurrentPage();  
			Integer currentTab = sessionBean.getTabPerPage().get(currentPage);
			String uniquePath = currentPage + currentTab;
			// We support views ONLY for tab "Profiles".
			if (ParametersManagerConstants.TAB_PROFILE_TYPES == currentTab) {
				Integer currentView = sessionBean.getViewPerTab().get(currentPage + currentTab);
				uniquePath += currentView.toString();
			} 
			Container container = sessionBean.getContainer().get(uniquePath);
			if (container == null) {
				container = new Container();
			}
			
			container.setFilterLabel(label != null && label.trim().length() > 0 ? label.trim() : null);
			container.setFilterProfileType(profileType); 
			container.setFilterProfileStructureType(profileStructureType); 
			container.setFilterStatus(status);
			container.setStart(0);
			logger.message("uniquePath=" + uniquePath);
			sessionBean.getContainer().put(uniquePath, container);
		}
		// Pass parameters to default view.
		//actionResponse.setRenderParameters(actionRequest.getParameterMap());
		// Returns control to default view.
	}
	
	/*
	 * This action is called from page "group.jsp" to save group form.
	 *
	 * @param groupId						the id of the group (if we are editing)
	 * @param name							the name of the group.
	 * @param label							the label of the group.
	 * @param selectedProfilesTypes			the profile type(s) to which the group is member of.
	 * @param selectedProfileTypeWeights 	the profile type(s) weight to which the group is member of.
	 * @param selectedProfileStructureTypes the profile structure type(s) to which the group is member of. 
	 * @param status						boolean active/inactive.
	 * 
	 */
	@ActionMapping(value = "saveGroup")
	public void saveGroup(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "groupId", required = false) Long groupId,
			@RequestParam(value = "name") String name,
			@RequestParam(value = "label") String label, 
			@RequestParam(value = "selectedProfileTypes") String selectedProfileTypes, 
			@RequestParam(value = "selectedProfileTypeWeights") String selectedProfileTypeWeights,
			@RequestParam(value = "selectedProfileStructureTypes", required = false) String selectedProfileStructureTypes, 			
			@RequestParam(value = "status") Integer status) 
	{
		loadPreferences(actionRequest);		
		logger.message("saveGroup [" + groupId + "]");
		logger.message("name=" + name);
		logger.message("label=" + label);
		logger.message("selectedProfileTypes=" + selectedProfileTypes);
		logger.message("selectedProfileStructureTypes=" + selectedProfileStructureTypes);
		logger.message("selectedProfileTypeWeights=" + selectedProfileTypeWeights);
		logger.message("status=" + status);
		if (sessionBean != null) {
			Date currentDate = new Date();
			RegisterGroup group = null;
			if (groupId != null) {
				group = registerGroupService.getRegisterGroupById(groupId);
				if (group == null || group.getRegisterGroupId() == null) {
					sessionBean.setError("Група с номер \"" + groupId + "\" не е намерена в системата.");
					return;
				}
			}
			if (group == null) {
				group = new RegisterGroup();
			}
			group.setName(name);
			group.setLabel(label);
			group.setProfileType(utils.formatMultipleFieldsToOne(selectedProfileTypes));
			group.setProfileStructureType(utils.formatMultipleFieldsToOne(selectedProfileStructureTypes));
			group.setWeight(utils.formatMultipleFieldsToOne(selectedProfileTypeWeights));
			group.setStatus(status);
			group.setDateModified(currentDate);
			group.setUserId(sessionBean.getUserUID());
			boolean result = false;
			// Edit group.
			if (groupId != null) {
				RegisterGroup existingGroup = registerGroupService.getRegisterGroupByNameExcId(name, groupId);
				if (existingGroup != null) {
					sessionBean.setError("Група със системно наименование \"" + name  + "\" вече съществува в системата.");
				} else {
					try {
						result = registerGroupService.updateRegisterGroup(group); 
					} catch (Exception e) {
						e.printStackTrace();
					}		
				}
				if (result) {
					sessionBean.setMessage("Групата \"" + label + "\" беше редактирана успешно.");
					esbCommunicator.sendEvent(sessionBean.getUserUID(), ParametersManagerConstants.EVENT_LOG_PORTAL_UPDATE_REGISTER_GROUP, "Редактиране на група - \"" + group.getLabel() + "\" (" + group.getRegisterGroupId() + ")", null, utils.getRemoteIP(actionRequest), false);
				} else {
					sessionBean.setError("Възникна грешка при редактиране на група \"" + label  + "\".");
				}
			} else { // Create group.
				group.setDateCreated(currentDate);
				try {
					RegisterGroup existingGroup = registerGroupService.getRegisterGroupByName(name);
					if (existingGroup != null) {
						sessionBean.setError("Група със системно наименование \"" + name  + "\" вече съществува в системата.");
					} else {
						group = registerGroupService.createRegisterGroup(group);
						if (group != null) {
							result = true;
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}					 
				if (result) {
					sessionBean.setMessage("Групата \"" + label + "\" беше добавена успешно.");
					esbCommunicator.sendEvent(sessionBean.getUserUID(), ParametersManagerConstants.EVENT_LOG_PORTAL_ADD_REGISTER_GROUP, "Добавяне на група - \"" + group.getLabel() + "\" (" + group.getRegisterGroupId() + ")", null, utils.getRemoteIP(actionRequest), false);
				} else if (sessionBean.getError() == null){
					sessionBean.setError("Възникна грешка при добавяне на група \"" + label  + "\".");
				}
				
			}
			if (result) {
				sessionBean.setCurrentPage(ParametersManagerConstants.INDEX_PAGE);
			} else {
				// Pass parameters to default view and return control.
				actionResponse.setRenderParameters(actionRequest.getParameterMap());
			}
		}
	}
	
	/*
	 * This resource mapping is called from tab "Profiles" -> view "Groups"
	 * and also called from tab "Groups" 
	 *
	 * @param label			the label of the group.
	 * @param profileType 	the profile type to which the group is member of.
	 * @param status		boolean active/inactive.
	 * 
	 */
	@ResourceMapping(value = "getGroups")
	public void getGroups(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("draw") Integer draw,
			@RequestParam("start") Integer start,
			@RequestParam("length") Integer length,
			@RequestParam("order[0][column]") Integer orderColumn,
			@RequestParam("order[0][dir]") String order)
	{
		loadPreferences(resourceRequest);		
		logger.message("getGroups");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONArray ja = new JSONArray();
		
		int totalResults = 0;
		if (sessionBean != null) {
			String currentPage = sessionBean.getCurrentPage();  
			Integer currentTab = sessionBean.getTabPerPage().get(currentPage);
			String uniquePath = currentPage + currentTab;
			Integer currentView = null;
			// We support views ONLY for tab "Profiles".
			if (ParametersManagerConstants.TAB_PROFILE_TYPES == currentTab) {
				currentView = sessionBean.getViewPerTab().get(currentPage + currentTab);
				uniquePath += currentView.toString();				
			} 
			Container container = sessionBean.getContainer().get(uniquePath);
			if (container == null) {
				container = new Container();
			}
			
			container.setResultsPerPage(length);
			container.setStart(start);
			container.setOrderColumn(orderColumn);
			container.setOrder(order);
			sessionBean.getContainer().put(uniquePath, container);
			
			
			String filterLabel = container.getFilterLabel();
			Integer filterProfileType = container.getFilterProfileType() != null ? container.getFilterProfileType() : null;
			Integer filterProfileStructureType = container.getFilterProfileStructureType() != null ? container.getFilterProfileStructureType() : null;
			Integer filterStatus = container.getFilterStatus() != null ? container.getFilterStatus() : null;
			logger.message("getGroups() -> length=" + length);
			logger.message("getGroups() -> start=" + start);
			logger.message("getGroups() -> orderColumn=" + orderColumn);
			logger.message("getGroups() -> order=" + order);
			logger.message("getGroups() -> filterLabel=" + filterLabel);
			logger.message("getGroups() -> filterProfileType=" + filterProfileType);
			logger.message("getGroups() -> filterProfileStructureType=" + filterProfileStructureType);
			logger.message("getGroups() -> filterStatus=" + filterStatus);
 
			List<RegisterGroup> results = registerGroupService.getAllRegisterGroupsByFilter(filterLabel, filterProfileType, filterProfileStructureType, filterStatus, orderColumn, order);
			if (results != null && results.size() > 0) {
				logger.message("getGroups() -> results.size()=" + results.size());	
				JSONArray tmpJA = null;
				// Handle custom weight order.
				if (orderColumn == null || ParametersManagerConstants.COLUMN_GROUPS_WEIGHT == orderColumn) {
					results = utils.orderGroupsByWeight(results, filterProfileType, order);
				}
				String multiple = "";
				boolean isGroupView = ParametersManagerConstants.TAB_PROFILE_TYPES == currentTab && currentView != null && ParametersManagerConstants.VIEW_GROUPS == currentView;
				for (int i = 0; i < results.size(); i++) {
					tmpJA = new JSONArray();
					if (isGroupView) {
						multiple = "";
						if (utils.hasMultipleProfileTypes(results.get(i).getProfileType())) {
							multiple = "*";
						}
					}
					tmpJA.put(results.get(i).getRegisterGroupId());
					tmpJA.put(results.get(i).getLabel() + multiple);
					tmpJA.put(utils.getProfileTypeNames(results.get(i).getProfileType()));
					tmpJA.put(utils.getProfileStructureTypeNames(results.get(i).getProfileStructureType()));
					tmpJA.put(utils.getStatusName(results.get(i).getStatus(), resourceRequest));
					if (isGroupView && filterProfileType != null) { 
						try {
							tmpJA.put(utils.getGroupWeightFromProfileTypeStr(results.get(i).getProfileType(), results.get(i).getWeight(), filterProfileType, results.get(i).getLabel()));
						} catch (Exception e) {
							logger.error(e.getMessage());
							e.printStackTrace();
							tmpJA.put(utils.getProfileTypeWeights(results.get(i).getWeight()));
						}
					} else {
						tmpJA.put(utils.getProfileTypeWeights(results.get(i).getWeight()));
					}
					tmpJA.put(results.get(i).getRegisterGroupId());
					ja.put(tmpJA);						
				}				
			} else {
				logger.message("getGroups() -> requests.length=0");
			}
			totalResults = results != null ? results.size() : 0;
		} 
		json.put("draw", draw);	
		json.put("recordsTotal", totalResults);	
		json.put("recordsFiltered", totalResults);	
		json.put("data", ja);	
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	 
		
	}
	
	
	/*
	 * This resource mapping is called from tab "Profiles" -> view "Groups"
	 * and also called from tab "Groups" and handle the deactivate operation.
	 *
	 * @param groupId		the id of the group that will be deactivated.
	 * 
	 */
	@ResourceMapping(value = "deactivateGroup")
	public void deactivateGroup(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("groupId") Long groupId)
	{
		loadPreferences(resourceRequest);		
		logger.message("deactivateGroup");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONObject ja = new JSONObject();
		RegisterGroup group = null;
		boolean success = false;
		try {
			group = registerGroupService.getRegisterGroupById(groupId);
			if (group != null) {
				group.setDateModified(new Date());
				group.setStatus(ParametersManagerConstants.STATUS_INACTIVE);
				if (registerGroupService.updateStatusRegisterGroup(group)) {
					success = true;
					sessionBean.setMessage("Група \"" + group.getLabel() + "\" беше деактивирана успешно.");
					esbCommunicator.sendEvent(sessionBean.getUserUID(), ParametersManagerConstants.EVENT_LOG_PORTAL_DEACTIVATE_REGISTER_GROUP, "Деактивиране на група - \"" + group.getLabel() + "\" (" + group.getRegisterGroupId() + ")", null, utils.getRemoteIP(resourceRequest), false);
					ja.put("result", "1");
					ja.put("message", "Група \"" + group.getLabel() + "\" беше деактивирана успешно.");
				}
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}	
		if (!success) {
			sessionBean.setError("Неуспешно деактивиране на група с номер " + groupId + ".");
			ja.put("result", "0");
			ja.put("message", "Неуспешно деактивиране на група с номер " + groupId + ".");
		}
		json.put("data", ja);
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	
	}

	/*
	 * This resource mapping is called from tab "Profiles" -> view "Groups"
	 * and also called from tab "Groups" and handle the activation operation.
	 *
	 * @param groupId		the id of the group that will be activated.
	 * 
	 */
	@ResourceMapping(value = "activateGroup")
	public void activateGroup(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("groupId") Long groupId)
	{
		loadPreferences(resourceRequest);		
		logger.message("activateGroup");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONObject ja = new JSONObject();
		RegisterGroup group = null;
		boolean success = false;
		try {
			group = registerGroupService.getRegisterGroupById(groupId);
			if (group != null) {
				group.setDateModified(new Date());
				group.setStatus(ParametersManagerConstants.STATUS_ACTIVE);
				if (registerGroupService.updateStatusRegisterGroup(group)) {
					success = true;
					sessionBean.setMessage("Група \"" + group.getLabel() + "\" беше активирана успешно.");
					esbCommunicator.sendEvent(sessionBean.getUserUID(), ParametersManagerConstants.EVENT_LOG_PORTAL_ACTIVATE_REGISTER_GROUP, "Активиране на група - \"" + group.getLabel() + "\" (" + group.getRegisterGroupId() + ")", null, utils.getRemoteIP(resourceRequest), false);
					ja.put("result", "1");
					ja.put("message", "Група \"" + group.getLabel() + "\" беше активирана успешно.");
				}
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}	
		if (!success) {
			sessionBean.setError("Неуспешно активиране на група с номер " + groupId + ".");
			ja.put("result", "0");
			ja.put("message", "Неуспешно активиране на група с номер " + groupId + ".");
		}
		json.put("data", ja);
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	
	}
	
	/*
	 * This resource mapping is called from tab "Profiles" -> view "Groups"
	 * and also called from tab "Groups" and handle the delete operation.
	 *
	 * @param groupId		the id of the group that will be deleted.
	 * 
	 */
	@ResourceMapping(value = "deleteGroup")
	public void deleteGroup(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("groupId") Long groupId)
	{
		loadPreferences(resourceRequest);		
		logger.message("deleteGroup");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONObject ja = new JSONObject();
		RegisterGroup group = null;
		boolean success = false;
		if ("wpadmin".equalsIgnoreCase(sessionBean.getUserUID())) {
			try {
				group = registerGroupService.getRegisterGroupById(groupId);
				if (group != null) {
					if (registerGroupService.deleteRegisterGroup(group)) {
						success = true;
						sessionBean.setMessage("Група \"" + group.getLabel() + "\" беше изтрита успешно.");
						ja.put("result", "1");
						ja.put("message", "Група \"" + group.getLabel() + "\" беше изтрита успешно.");
					}
				} 
			} catch (Exception e) {
				e.printStackTrace();
			}	
		}
		if (!success) {
			sessionBean.setError("Неуспешно изтриване на група с номер " + groupId + ".");
			ja.put("result", "0");
			ja.put("message", "Неуспешно изтриване на група с номер " + groupId + ".");
		}
		json.put("data", ja);
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	
	}
	
	
	/*
	 * This action is called from tab "Profiles" -> view "Groups"
	 * and also called from tab "Groups" 
	 *
	 * @param label			the label of the group.
	 * @param profileType 	the profile type to which the group is member of.
	 * @param status		boolean active/inactive.
	 * 
	 */
	@ActionMapping(value = "searchFilterParameters")
	public void searchFilterParameters(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "label", required = false) String label,
			@RequestParam(value = "group", required = false) Long group,
			@RequestParam(value = "status", required = false) Integer status) 
	{
		loadPreferences(actionRequest);
		logger.message("searchFilterParameters");
		logger.message("label=" + (label != null ? label : ""));
		logger.message("group=" + group);
		logger.message("status=" + (status != null ? status : ""));
		if (sessionBean != null) {
			String currentPage = sessionBean.getCurrentPage();  
			Integer currentTab = sessionBean.getTabPerPage().get(currentPage);
			String uniquePath = currentPage + currentTab;
			// We support views ONLY for tab "Profiles".
			if (ParametersManagerConstants.TAB_PROFILE_TYPES == currentTab) {
				Integer currentView = sessionBean.getViewPerTab().get(currentPage + currentTab);
				uniquePath += currentView.toString();
			} 
			Container container = sessionBean.getContainer().get(uniquePath);
			if (container == null) {
				container = new Container();
			}
			
			container.setFilterLabel(label != null && label.trim().length() > 0 ? label.trim() : null);
			container.setFilterGroup(group);
			container.setFilterStatus(status);
			container.setStart(0);
			logger.message("uniquePath=" + uniquePath);
			sessionBean.getContainer().put(uniquePath, container);
		}
		// Pass parameters to default view.
		//actionResponse.setRenderParameters(actionRequest.getParameterMap());
		// Returns control to default view.
	}
	
	/*
	 * This action is called from page "parameter.jsp" to save parameter form.
	 *
	 * @param parametertId			the id of the parameter (if we are editing).
	 * @param name					the name of the parameter.
	 * @param label					the label of the parameter.
	 * @param groupId				the id of the group to which the parameter belongs.
	 * @param parameterType 		the parameterType.
	 * @param parameterTypeValue	parameter type value (for list types only).
	 * @param defaultValue			default value (for list types only).
	 * @param weight		 		the order of the parameter in the group.
	 * @param description		 	description for the parameter.
	 * @param header		 		H2 text.
	 * @param required				boolean yes/no.
	 * @param consent				boolean yes/no.
	 * @param status				boolean active/inactive.
	 * 
	 */
	@ActionMapping(value = "saveParameter")
	public void saveParameter(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "parameterId", required = false) Long parameterId,			
			@RequestParam(value = "name") String name,
			@RequestParam(value = "label") String label, 
			@RequestParam(value = "groupId") Long groupId,
			@RequestParam(value = "parameterType") Integer parameterType, 
			@RequestParam(value = "parameterTypeValue", required = false) String parameterTypeValue, 
			@RequestParam(value = "defaultValue", required = false) String defaultValue, 
			@RequestParam(value = "weight") Integer weight,
			@RequestParam(value = "description", required = false) String description, 			
			@RequestParam(value = "header", required = false) String header,
			@RequestParam(value = "required") Integer required,
			@RequestParam(value = "consent") Integer consent,
			@RequestParam(value = "status") Integer status) 
	{
		loadPreferences(actionRequest);		
		logger.message("saveParameter [" + parameterId + "]");
		logger.message("name=" + name);
		logger.message("label=" + label);
		logger.message("groupId=" + groupId);
		logger.message("parameterType=" + parameterType);
		logger.message("parameterTypeValue=" + parameterTypeValue);
		logger.message("defaultValue=" + defaultValue);
		logger.message("weight=" + weight);
		logger.message("description=" + description);
		logger.message("header=" + header);
		logger.message("required=" + required);
		logger.message("consent=" + consent);
		logger.message("status=" + status);
		if (sessionBean != null) {
			Date currentDate = new Date();
			RegisterGroupParameter parameter = null;
			Integer originalRequired = -1;
			Integer originalConsent = -1;
			if (parameterId != null) {
				parameter = registerGroupParameterService.getRegisterGroupParameterById(parameterId);
				if (parameter == null || parameter.getRegisterGroupId() == null) {
					sessionBean.setError("Параметър с номер \"" + parameterId + "\" не е намерен в системата.");
					return;
				}
				originalRequired = parameter.getRequired();
				originalConsent = parameter.getConsent();
			}
			if (parameter == null) {
				parameter = new RegisterGroupParameter();
			}
			parameter.setName(name);
			parameter.setLabel(label);
			parameter.setRegisterGroupId(groupId);
			parameter.setParameterType(parameterType);
			if (ParametersManagerConstants.PARAMETER_TYPE_LIST_SINGLE == parameterType 
					|| ParametersManagerConstants.PARAMETER_TYPE_LIST_MULTIPLE == parameterType) {
				parameter.setParameterValue(parameterTypeValue);
				if (ParametersManagerConstants.PARAMETER_TYPE_LIST_SINGLE == parameterType) {
					parameter.setDefaultValue(defaultValue.trim());
				} else {
					parameter.setDefaultValue(null);
				}
			} else {
				parameter.setParameterValue(null);
				parameter.setDefaultValue(null);
			}
			parameter.setDescription(description != null && description.trim().length() > 0 ? description.trim() : null);
			parameter.setHeader(header != null && header.trim().length() > 0 ? header.trim() : null);
			parameter.setWeight(weight);
			parameter.setRequired(required);
			parameter.setConsent(consent);
			parameter.setStatus(status);
			parameter.setDateModified(currentDate);
			parameter.setUserId(sessionBean.getUserUID());
			boolean result = false;
			// Edit parameter.
			if (parameterId != null) { 
				RegisterGroupParameter existingParameter = registerGroupParameterService.getRegisterGroupParameterByGroupIdAndNameExcId(groupId, name, parameterId);
				if (existingParameter != null) {
					sessionBean.setError("Параметър със системно наименование \"" + name  + "\" вече съществува в системата.");
				} else {
					try {
						result = registerGroupParameterService.updateRegisterGroupParameter(parameter); 
					} catch (Exception e) {
						e.printStackTrace();
					}		
				}
				if (result) {
					sessionBean.setMessage("Параметърът \"" + label + "\" беше редактиран успешно.");
					esbCommunicator.sendEvent(sessionBean.getUserUID(), ParametersManagerConstants.EVENT_LOG_PORTAL_UPDATE_REGISTER_GROUP_PARAMETER, "Редактиране на параметър - \"" + parameter.getLabel() + "\" (" + parameter.getRegisterGroupParameterId() + ")", null, utils.getRemoteIP(actionRequest), false);
					if (originalRequired != parameter.getRequired()) {
						if (ParametersManagerConstants.VALUE_NO == parameter.getRequired()) {
							esbCommunicator.sendEvent(sessionBean.getUserUID(), ParametersManagerConstants.EVENT_LOG_PORTAL_UNMARK_REQUIRED_REGISTER_GROUP_PARAMETER, "Промяна на параметър - \"" + parameter.getLabel() + "\" (" + parameter.getRegisterGroupParameterId() + ") на незадължителен", null, utils.getRemoteIP(actionRequest), false);
						} else {
							esbCommunicator.sendEvent(sessionBean.getUserUID(), ParametersManagerConstants.EVENT_LOG_PORTAL_MARK_REQUIRED_REGISTER_GROUP_PARAMETER, "Промяна на параметър - \"" + parameter.getLabel() + "\" (" + parameter.getRegisterGroupParameterId() + ") на задължителен", null, utils.getRemoteIP(actionRequest), false);
						}
					}
					if (originalConsent != parameter.getConsent()) {
						if (ParametersManagerConstants.VALUE_NO == parameter.getConsent()) {
							esbCommunicator.sendEvent(sessionBean.getUserUID(), ParametersManagerConstants.EVENT_LOG_PORTAL_UNMARK_CONSENT_REGISTER_GROUP_PARAMETER, "Промяна на параметър - \"" + parameter.getLabel() + "\" (" + parameter.getRegisterGroupParameterId() + ") скриване на въпрос за съгласие за споделяне", null, utils.getRemoteIP(actionRequest), false);
						} else {
							esbCommunicator.sendEvent(sessionBean.getUserUID(), ParametersManagerConstants.EVENT_LOG_PORTAL_MARK_CONSENT_REGISTER_GROUP_PARAMETER, "Промяна на параметър - \"" + parameter.getLabel() + "\" (" + parameter.getRegisterGroupParameterId() + ") показване на въпрос за съгласие за споделяне", null, utils.getRemoteIP(actionRequest), false);
						}
					}
				} else {
					sessionBean.setError("Възникна грешка при редактиране на параметър \"" + label  + "\".");
				}
			} else { // Create parameter.
				parameter.setDateCreated(currentDate);
				try {
					RegisterGroupParameter existingParameter = registerGroupParameterService.getRegisterGroupParameterByGroupIdAndName(groupId, name);
					if (existingParameter != null) {
						sessionBean.setError("Параметър със системно наименование \"" + name  + "\" вече съществува в системата.");
					} else {
						parameter = registerGroupParameterService.createRegisterGroupParameter(parameter);
						if (parameter != null) {
							result = true;
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}					 
				if (result) {
					sessionBean.setMessage("Параметърът \"" + label + "\" беше добавен успешно.");
					esbCommunicator.sendEvent(sessionBean.getUserUID(), ParametersManagerConstants.EVENT_LOG_PORTAL_ADD_REGISTER_GROUP_PARAMETER, "Добавяне на параметър - \"" + parameter.getLabel() + "\" (" + parameter.getRegisterGroupParameterId() + ")", null, utils.getRemoteIP(actionRequest), false);
				} else if (sessionBean.getError() == null){
					sessionBean.setError("Възникна грешка при добавяне на параметър \"" + label  + "\".");
				}
				
			}
			if (result) {
				sessionBean.setCurrentPage(ParametersManagerConstants.INDEX_PAGE);
			} else {
				// Pass parameters to default view and return control.
				actionResponse.setRenderParameters(actionRequest.getParameterMap());
			}
		}
	}

	
	/*
	 * This resource mapping is called from tab "Profiles" -> view "Parameters"
	 * and also called from tab "Parameters" 
	 *
	 * @param draw				UI parameter from Datatables.
	 * @param start 			page number (started from 0).
	 * @param length			results per page.
	 * @param order[0][column]	order column index.
	 * @param order[0][dir]		order column direction.
	 * 
	 */
	@ResourceMapping(value = "getParameters")
	public void getParameters(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("draw") Integer draw,
			@RequestParam("start") Integer start,
			@RequestParam("length") Integer length,
			@RequestParam("order[0][column]") Integer orderColumn,
			@RequestParam("order[0][dir]") String order)
	{
		loadPreferences(resourceRequest);		
		logger.message("getParameters");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONArray ja = new JSONArray();
		
		int totalResults = 0;
		if (sessionBean != null) {
			String currentPage = sessionBean.getCurrentPage();  
			Integer currentTab = sessionBean.getTabPerPage().get(currentPage);
			String uniquePath = currentPage + currentTab;
			Integer currentView = null;
			// We support views ONLY for tab "Profiles".
			if (ParametersManagerConstants.TAB_PROFILE_TYPES == currentTab) {
				currentView = sessionBean.getViewPerTab().get(currentPage + currentTab);
				uniquePath += currentView.toString();				
			} 
			Container container = sessionBean.getContainer().get(uniquePath);
			if (container == null) {
				container = new Container();
			}
			
			container.setResultsPerPage(length);
			container.setStart(start);
			container.setOrderColumn(orderColumn);
			container.setOrder(order);
			sessionBean.getContainer().put(uniquePath, container);
			
			
			String filterLabel = container.getFilterLabel() != null && container.getFilterLabel().trim().length() > 0 ? container.getFilterLabel().trim() : null;
			Long filterGroup = container.getFilterGroup();
			Integer filterStatus = container.getFilterStatus() != null ? container.getFilterStatus() : null;
			logger.message("getParameters() -> length=" + length);
			logger.message("getParameters() -> start=" + start);
			logger.message("getParameters() -> orderColumn=" + orderColumn);
			logger.message("getParameters() -> order=" + order);
			logger.message("getParameters() -> filterLabel=" + filterLabel);
			logger.message("getParameters() -> filterGroup=" + filterGroup);
			logger.message("getParameters() -> filterStatus=" + filterStatus);
 
			totalResults = registerGroupParameterService.countParametersByFilter(filterLabel, filterGroup, filterStatus);
			if (totalResults > 0) {
				List<RegisterGroupParameter> results = registerGroupParameterService.getAllRegisterGroupParametersByFilter(filterLabel, filterGroup, filterStatus, start, length, orderColumn, order);
				if (results != null && results.size() > 0) {
					logger.message("getParameters() -> results.size()=" + results.size());	
					JSONArray tmpJA = null; 
					boolean isParametersView = ParametersManagerConstants.TAB_PROFILE_TYPES == currentTab && currentView != null && ParametersManagerConstants.VIEW_PARAMETERS == currentView;
					HashMap<Long, String> groupsHm = null;
					// Load groups names,
					if (!isParametersView) {
						groupsHm = new HashMap<Long, String>();
						List<Long> groupIds = new ArrayList<>(); 
						for (int i = 0; i < results.size(); i++) {
							groupIds.add(results.get(i).getRegisterGroupId());
						}
						List<RegisterGroup> groups = registerGroupService.getAllRegisterGroupsByIds(groupIds);
						if (groups != null && groups.size() > 0) {
							for (int i = 0; i < groups.size(); i++) {
								groupsHm.put(groups.get(i).getRegisterGroupId(), groups.get(i).getLabel());
							}
						}
					}
					for (int i = 0; i < results.size(); i++) {
						tmpJA = new JSONArray();
						tmpJA.put(results.get(i).getRegisterGroupParameterId());
						tmpJA.put(results.get(i).getLabel());
						if (!isParametersView) {
							tmpJA.put(groupsHm.get(results.get(i).getRegisterGroupId()));
						} else {
							tmpJA.put(container.getGroup().getLabel());
						}
						tmpJA.put(utils.getRequiredName(results.get(i).getRequired(), resourceRequest));
						tmpJA.put(utils.getStatusName(results.get(i).getStatus(), resourceRequest));
						tmpJA.put(results.get(i).getWeight());
						tmpJA.put(results.get(i).getRegisterGroupParameterId());
						ja.put(tmpJA);						
					}				
				} else {
					logger.message("getGroups() -> requests.length=0");
				}
			}
		} 
		json.put("draw", draw);	
		json.put("recordsTotal", totalResults);	
		json.put("recordsFiltered", totalResults);	
		json.put("data", ja);	
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	 
		
	}
	
	/*
	 * This resource mapping is called from tab "Profiles" -> view "Parameters"
	 * and also called from tab "Parameters" and handle the deactivate operation.
	 *
	 * @param groupParameterId		the id of the parameter that will be deactivated.
	 * 
	 */
	@ResourceMapping(value = "deactivateParameter")
	public void deactivateParameter(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("groupParameterId") Long groupParameterId)
	{
		loadPreferences(resourceRequest);		
		logger.message("deactivateParameter");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONObject ja = new JSONObject();
		RegisterGroupParameter parameter = null;
		boolean success = false;
		try {
			parameter = registerGroupParameterService.getRegisterGroupParameterById(groupParameterId);
			if (parameter != null) {
				parameter.setDateModified(new Date());
				parameter.setStatus(ParametersManagerConstants.STATUS_INACTIVE);
				if (registerGroupParameterService.updateStatusRegisterGroupParameter(parameter)) {
					success = true;
					sessionBean.setMessage("Параметърър \"" + parameter.getLabel() + "\" беше деактивиран успешно.");
					esbCommunicator.sendEvent(sessionBean.getUserUID(), ParametersManagerConstants.EVENT_LOG_PORTAL_DEACTIVATE_REGISTER_GROUP_PARAMETER, "Деактивиране на параметър - \"" + parameter.getLabel() + "\" (" + parameter.getRegisterGroupParameterId() + ")", null, utils.getRemoteIP(resourceRequest), false);
					ja.put("result", "1");
					ja.put("message", "Параметърър \"" + parameter.getLabel() + "\" беше деактивиран успешно.");
				}
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}	
		if (!success) {
			sessionBean.setError("Неуспешно деактивиране на параметър с номер " + groupParameterId + ".");
			ja.put("result", "0");
			ja.put("message", "Неуспешно деактивиране на параметър с номер " + groupParameterId + ".");
		}
		json.put("data", ja);
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	
	}

	/*
	 * This resource mapping is called from tab "Profiles" -> view "Parameters"
	 * and also called from tab "Parameters" and handle the activation operation.
	 *
	 * @param groupParameterId		the id of the parameter that will be activated.
	 * 
	 */
	@ResourceMapping(value = "activateParameter")
	public void activateParameter(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("groupParameterId") Long groupParameterId)
	{
		loadPreferences(resourceRequest);		
		logger.message("activateParameter");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONObject ja = new JSONObject();
		RegisterGroupParameter parameter = null;
		boolean success = false;
		try {
			parameter = registerGroupParameterService.getRegisterGroupParameterById(groupParameterId);
			if (parameter != null) {
				parameter.setDateModified(new Date());
				parameter.setStatus(ParametersManagerConstants.STATUS_ACTIVE);
				if (registerGroupParameterService.updateStatusRegisterGroupParameter(parameter)) {
					success = true;
					sessionBean.setMessage("Параметърът \"" + parameter.getLabel() + "\" беше активиран успешно.");
					esbCommunicator.sendEvent(sessionBean.getUserUID(), ParametersManagerConstants.EVENT_LOG_PORTAL_ACTIVATE_REGISTER_GROUP_PARAMETER, "Активиране на параметър - \"" + parameter.getLabel() + "\" (" + parameter.getRegisterGroupParameterId() + ")", null, utils.getRemoteIP(resourceRequest), false);
					ja.put("result", "1");
					ja.put("message", "Параметърът \"" + parameter.getLabel() + "\" беше активиран успешно.");
				}
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}	
		if (!success) {
			sessionBean.setError("Неуспешно активиране на параметър с номер " + groupParameterId + ".");
			ja.put("result", "0");
			ja.put("message", "Неуспешно активиране на параметър с номер " + groupParameterId + ".");
		}
		json.put("data", ja);
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	
	}
	
	/*
	 * This resource mapping is called from tab "Profiles" -> view "Parameters"
	 * and also called from tab "Parameters" and handle the delete operation.
	 *
	 * @param groupParamterId	the id of the parameter that will be deleted.
	 * 
	 */
	@ResourceMapping(value = "deleteParameter")
	public void deleteParameter(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("groupParameterId") Long groupParameterId)
	{
		loadPreferences(resourceRequest);		
		logger.message("deleteParameter");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONObject ja = new JSONObject();
		RegisterGroupParameter parameter = null;
		boolean success = false;
		if ("wpadmin".equalsIgnoreCase(sessionBean.getUserUID())) {
			try {
				parameter = registerGroupParameterService.getRegisterGroupParameterById(groupParameterId);
				if (parameter != null) {
					if (registerGroupParameterService.deleteRegisterGroupParameter(parameter)) {
						success = true;
						sessionBean.setMessage("Параметърът \"" + parameter.getLabel() + "\" беше изтрит успешно.");
						ja.put("result", "1");
						ja.put("message", "Параметърът \"" + parameter.getLabel() + "\" беше изтрит успешно.");
					}
				} 
			} catch (Exception e) {
				e.printStackTrace();
			}	
		}
		if (!success) {
			sessionBean.setError("Неуспешно изтриване на параметър с номер " + groupParameterId + ".");
			ja.put("result", "0");
			ja.put("message", "Неуспешно изтриване на параметър с номер " + groupParameterId + ".");
		}
		json.put("data", ja);
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	
	}

	/*
	 * This action mapping is called from button "Update cache".	 
	 * 
	 */
	@ActionMapping(value = "updateCache")
	public void updateCache(ActionRequest actionRequest, ActionResponse actionResponse)
	{			
		logger.message("updateCache");
		
		List<com.egov.wcm.cache.model.EgovRegisterGroup> groupsArr = null;
		HashMap<Integer, List<com.egov.wcm.cache.model.EgovRegisterGroup>> groupsHm = null;
		List<com.egov.wcm.cache.model.EgovRegisterGroupParameter> parametersArr = null;
		
		List<RegisterGroup> registerGroupsArr = null;
		HashMap<Integer, List<RegisterGroup>> registerGroupHm = null;
		
		List<RegisterGroup> groups = registerGroupService.getAllRegisterGroups();
		if (groups != null && groups.size() > 0) {		
			logger.message("updateCache -> groups.size() = " + groups.size());
			Integer[] profileTypes = null;
			registerGroupHm = new HashMap<Integer, List<RegisterGroup>>();
			for (int i = 0; i < groups.size(); i++) {				
				profileTypes = utils.getArrayFromFormatedField(groups.get(i).getProfileType());
				if (profileTypes != null && profileTypes.length > 0) {
					for (int j = 0; j < profileTypes.length; j++) {
						registerGroupsArr = registerGroupHm.get(profileTypes[j]);
						if (registerGroupsArr == null) {
							registerGroupsArr = new ArrayList<RegisterGroup>();
						}
						registerGroupsArr.add(groups.get(i)); 
						registerGroupHm.put(profileTypes[j], registerGroupsArr);
					}
				}
			}
			
			if (registerGroupHm != null && registerGroupHm.size() > 0) {
				// Order groups per profile type.
				List<Integer> profileTypeIds = new ArrayList<>(registerGroupHm.keySet());
				for (int i = 0; i < profileTypeIds.size(); i++) {
					registerGroupsArr = registerGroupHm.get(profileTypeIds.get(i));
					if (registerGroupsArr != null) {	 							
						registerGroupHm.put(profileTypeIds.get(i), utils.orderGroupsByWeight(registerGroupsArr, profileTypeIds.get(i), ParametersManagerConstants.ORDER_ASC));
					}	 										
				}
				
				// Move groups to cache groups object.				
				groupsHm = new HashMap<>();								
				for (int i = 0; i < profileTypeIds.size(); i++) {
					registerGroupsArr = registerGroupHm.get(profileTypeIds.get(i));
					if (registerGroupsArr != null) {
						groupsArr = new ArrayList<>();
						for (int j = 0; j < registerGroupsArr.size(); j++) {
							groupsArr.add(utils.populateCacheGroup(registerGroupsArr.get(j)));
						}						
						groupsHm.put(profileTypeIds.get(i), groupsArr);
					}	 										
				}
				
				// Load all parameters ordered by group id and weight.
				List<RegisterGroupParameter> registerParameters = registerGroupParameterService.getAllRegisterGroupParametersOrderByGroupIdAndWeight();
				if (registerParameters != null && registerParameters.size() > 0) {
					logger.message("updateCache -> registerParameters.size() = " + registerParameters.size());
					List<RegisterGroupParameter> registerParametersArr = new ArrayList<>();
					HashMap<Long, List<RegisterGroupParameter>> parametersPerGroup = new HashMap<Long, List<RegisterGroupParameter>>();
					for (int i = 0; i < registerParameters.size(); i++) {
						registerParametersArr = parametersPerGroup.get(registerParameters.get(i).getRegisterGroupId());
						if (registerParametersArr == null) {
							registerParametersArr = new ArrayList<RegisterGroupParameter>();
						}
						registerParametersArr.add(registerParameters.get(i));
						parametersPerGroup.put(registerParameters.get(i).getRegisterGroupId(), registerParametersArr);
					}
					// Populate loaded parameters in each group.
					if (parametersPerGroup != null && parametersPerGroup.size() > 0) {	
						for (int i = 0; i < profileTypeIds.size(); i++) {
							groupsArr = groupsHm.get(profileTypeIds.get(i));
							if (groupsArr != null) {
								for (int j = 0; j < groupsArr.size(); j++) {
									registerParametersArr = parametersPerGroup.get(groupsArr.get(j).getRegisterGroupId());
									if (registerParametersArr != null) {
										parametersArr = new ArrayList<com.egov.wcm.cache.model.EgovRegisterGroupParameter>();
										for (int k = 0; k < registerParametersArr.size(); k++) {
											parametersArr.add(utils.populateCacheParameter(registerParametersArr.get(k)));
										}
										groupsArr.get(j).setRegisterGroupParameters(parametersArr);
									}
								}
								groupsHm.put(profileTypeIds.get(i), groupsArr);
							}
						}
					}
				}
			}
		}
		
		if (groupsHm == null) {
			groupsHm = new HashMap<Integer, List<com.egov.wcm.cache.model.EgovRegisterGroup>>();
		}
		EgovWCMCache.cacheObject.put(EgovWCMCache.KEY_REGISTER_GROUPS_BY_PROFILE_TYPE_ID, groupsHm);
		sessionBean.setMessage("Актуализацията на кеша приключи успешно.");
		// Returns control to default view.
	}
	
	
	private void intializeBean() {
		System.out.println("in defaultView() !sessionBean.isInitialised()");
		try {
			String userUID = pumaCommunicator.getUserUID(pumaHome.getProfile().getCurrentUser(), pumaHome);
			sessionBean.setUserUID(userUID);
		} catch (PumaException e) {
			e.printStackTrace();
		}			
		sessionBean.setCurrentPage(ParametersManagerConstants.INDEX_PAGE);
		HashMap<String, Integer> tabPerPage = sessionBean.getTabPerPage();
		tabPerPage.put(ParametersManagerConstants.INDEX_PAGE, ParametersManagerConstants.TAB_PROFILE_TYPES);
		sessionBean.setTabPerPage(tabPerPage);
		HashMap<String, Integer> viewPerTab = sessionBean.getViewPerTab();
		viewPerTab.put(ParametersManagerConstants.INDEX_PAGE + ParametersManagerConstants.TAB_PROFILE_TYPES, ParametersManagerConstants.VIEW_PROFILE_TYPES);
		sessionBean.setViewPerTab(viewPerTab);
		sessionBean.setContainer(new HashMap<>());
		sessionBean.setInitialised(true);			
	}
	
	private void loadPreferences(PortletRequest request) {
		PortletPreferences prefs = request.getPreferences();		
		PortletViewController.language = prefs.getValue(ParametersManagerConstants.SETTING_PARAMETER_LANGUAGE, ParametersManagerConstants.LANGUAGE_BG);
		PortletViewController.isDebug = "1".equalsIgnoreCase(prefs.getValue(ParametersManagerConstants.SETTING_PARAMETER_DEBUG, ""));
		boolean test = !"PROD".equalsIgnoreCase(System.getProperty("environment")) && "TEST".equalsIgnoreCase(System.getProperty("environmentType"));
		PortletViewController.esbEventLogAddress = prefs.getValue(ParametersManagerConstants.SETTING_PARAMETER_ESB_EVENT_LOGGER_ADDRESS, test ? ParametersManagerConstants.ESB_LOGGING_URL_TEST : ParametersManagerConstants.ESB_LOGGING_URL);		
	}
	
//	private String getProfileTypeName(Integer profileType, PortletRequest portletRequest) {
//		if (profileType != null) {
//			if (ParametersManagerConstants.USER_PROFILE_TYPE_PERSONAL == profileType) {
//				return messageSource.getMessage("profile.type.personal", null, getLocale(portletRequest));
//			} else if (ParametersManagerConstants.USER_PROFILE_TYPE_LEGAL_ENTITY == profileType) {
//				return messageSource.getMessage("profile.type.legal.entity", null, getLocale(portletRequest));
//			} else if (ParametersManagerConstants.USER_PROFILE_TYPE_LEGAL_ENTITY_AL2 == profileType) {
//				return messageSource.getMessage("profile.type.legal.entity.al2", null, getLocale(portletRequest));
//			} else if (ParametersManagerConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER == profileType) {
//				return messageSource.getMessage("profile.type.service.supplier", null, getLocale(portletRequest));
//			}
//		}
//		return "";
//	}
//	
	

}
