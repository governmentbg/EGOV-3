package bg.ibs.parameters.manager.portlet.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import bg.ibs.parameters.manager.portlet.ParametersManagerConstants;
import bg.ibs.parameters.manager.portlet.model.RegisterGroup;
import bg.ibs.parameters.manager.portlet.model.RegisterGroupMapper;
import bg.ibs.parameters.manager.portlet.utils.ParametersManagerLogger;

@Repository("RegisterGroupDAO")
@Transactional
public class RegisterGroupDAOImpl implements RegisterGroupDAO { 
	private static final String TABLE_NAME = "RegisterGroup";
	private static final String TABLE_NAME_PARAMETERS = "RegisterGroupParameter";
	
	JdbcTemplate jdbcTemplate;
	SimpleJdbcInsert simpleJdbcInsert;
	
	@Autowired
	ParametersManagerLogger logger;	

	private final String SQL_FIND_GROUP = "select * from " + ParametersManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where registerGroupId = ?";
	private final String SQL_FIND_GROUP_BY_NAME = "select * from " + ParametersManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where LOWER(name) = ?";
	private final String SQL_FIND_GROUP_BY_NAME_EXC_ID = "select * from " + ParametersManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where LOWER(name) = ? AND registerGroupId <> ?";
	private final String SQL_UPDATE_STATUS_GROUP = "update " + ParametersManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " set status = ?, dateModified = ? where registerGroupId = ?";
	private final String SQL_DELETE_GROUP = "delete from " + ParametersManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where registerGroupId = ?";
	private final String SQL_DELETE_PARAMETERS = "delete from " + ParametersManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME_PARAMETERS + " where registerGroupId = ?";
	private final String SQL_UPDATE_GROUP = "update " + ParametersManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " set name = ?, label = ?, profileType = ?, profileStructureType = ?, weight = ?, status = ?, dateModified = ? where registerGroupId = ?";
	private final String SQL_GET_ALL = "select * from " + ParametersManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME;
	private final String SQL_GET_ALL_BY_IDS = "select * from " + ParametersManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where registerGroupId in (%s)";
	//private final String SQL_INSERT_GROUP = "insert into " +ParametersManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + "(name, label, profileType, weight, status, dateCreated, dateModified, userId) values(?,?,?,?,?,?,?,?)";

	@Autowired
	public RegisterGroupDAOImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		simpleJdbcInsert = new SimpleJdbcInsert(dataSource).
				withSchemaName(ParametersManagerConstants.DB_SCHEMA_NAME).
				withTableName(TABLE_NAME).
				usingColumns("name", "label", "profileType", "profileStructureType", "weight", "status", "dateCreated", "dateModified", "userId").
				usingGeneratedKeyColumns("registerGroupId");
	}

	public RegisterGroup getRegisterGroupById(final Long registerGroupId) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_GROUP, new Object[] { registerGroupId }, new RegisterGroupMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public RegisterGroup getRegisterGroupByName(final String name) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_GROUP_BY_NAME, new Object[] { name.toLowerCase() }, new RegisterGroupMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public RegisterGroup getRegisterGroupByNameExcId(final String name, final Long registerGroupId) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_GROUP_BY_NAME_EXC_ID, new Object[] { name.toLowerCase(), registerGroupId }, new RegisterGroupMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}

	public List<RegisterGroup> getAllRegisterGroups() {
		return jdbcTemplate.query(SQL_GET_ALL + " where 1=1 order by label " + ParametersManagerConstants.ORDER_ASC, new RegisterGroupMapper());
	}
	
	public List<RegisterGroup> getAllRegisterGroupsByIds(List<Long> ids) {
		String inSql = String.join(",", Collections.nCopies(ids.size(), "?"));
		return jdbcTemplate.query(String.format(SQL_GET_ALL_BY_IDS, inSql), ids.toArray() , new RegisterGroupMapper());
	}

	public List<RegisterGroup> getAllRegisterGroupsByFilter(final String label, final Integer profileType, final Integer profileStructureType, final Integer status, final Integer orderColumn, final String order) {
		String qOrder = "";
		if (orderColumn != null) {
			if (ParametersManagerConstants.COLUMN_ID == orderColumn) {
				qOrder = " order by registerGroupId";
			} else if (ParametersManagerConstants.COLUMN_GROUPS_LABEL == orderColumn) {
				qOrder = " order by label";
			} else if (ParametersManagerConstants.COLUMN_GROUPS_STATUS == orderColumn) {
				qOrder = " order by status";
			} else {
				qOrder = " order by registerGroupId";
			}
		} 
		if (qOrder.trim().length() == 0) {
			qOrder = " order by registerGroupId";
		}
		qOrder += " " + (ParametersManagerConstants.ORDER_DESC.equalsIgnoreCase(order) ? ParametersManagerConstants.ORDER_DESC : ParametersManagerConstants.ORDER_ASC);
		if ((label == null || label.trim().length() == 0) && profileType == null && status == null) {
			return jdbcTemplate.query(SQL_GET_ALL + " where 1=1" +  qOrder, new RegisterGroupMapper());
		}
		// We have filter(s) selected, so apply them.
		String qWhere = "";
		List<Object> filters = new ArrayList<>();
		if (label != null && label.trim().length() > 0) {
			qWhere += " WHERE LOWER(label) LIKE ?";
			filters.add("%" + label.toLowerCase() + "%");
		}
		if (profileType != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "profileType LIKE ?";
			filters.add("%^" + profileType + "^%");
		}
		if (profileStructureType != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "profileStructureType LIKE ?";
			filters.add("%^" + profileStructureType + "^%");
		}
		if (status != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "status = ?";
			filters.add(status);
		}
		return jdbcTemplate.query(SQL_GET_ALL + qWhere + qOrder, filters.toArray(new Object[filters.size()]), new RegisterGroupMapper());
	}
	
	public RegisterGroup createRegisterGroup(RegisterGroup registerGroup) {
		Map<String, Object> parameters = new HashMap<String, Object>();
	    parameters.put("name", registerGroup.getName());
	    parameters.put("label", registerGroup.getLabel());	    
	    parameters.put("profileType", registerGroup.getProfileType());
	    parameters.put("weight", registerGroup.getWeight());
	    parameters.put("profileStructureType", registerGroup.getProfileStructureType());
	    parameters.put("status", registerGroup.getStatus());
	    parameters.put("dateCreated", registerGroup.getDateCreated());
	    parameters.put("dateModified", registerGroup.getDateModified());
	    parameters.put("userId", registerGroup.getUserId());
		Long id = simpleJdbcInsert.executeAndReturnKey(parameters).longValue();
		logger.message("Generated id - " + id);
		registerGroup.setRegisterGroupId(id);
		return registerGroup;
//		return jdbcTemplate.update(SQL_INSERT_GROUP, registerGroup.getName(), registerGroup.getLabel(), registerGroup.getProfileType(),
//				registerGroup.getWeight(), registerGroup.getStatus(), registerGroup.getDateCreated(), 
//				registerGroup.getDateModified(), registerGroup.getUserId()) > 0;
	}
	
	public boolean updateRegisterGroup(RegisterGroup registerGroup) {
		return jdbcTemplate.update(SQL_UPDATE_GROUP, registerGroup.getName(), registerGroup.getLabel(), registerGroup.getProfileType(), 
				registerGroup.getProfileStructureType(), registerGroup.getWeight(), registerGroup.getStatus(), registerGroup.getDateModified(), registerGroup.getRegisterGroupId()) > 0;
	}

	public boolean updateStatusRegisterGroup(RegisterGroup registerGroup) {
		return jdbcTemplate.update(SQL_UPDATE_STATUS_GROUP, registerGroup.getStatus(), registerGroup.getDateModified(), registerGroup.getRegisterGroupId()) > 0;		
	}
	
	public boolean deleteRegisterGroup(RegisterGroup registerGroup) {
		// Delete all parameters for this group.
		jdbcTemplate.update(SQL_DELETE_PARAMETERS, registerGroup.getRegisterGroupId());		
		return jdbcTemplate.update(SQL_DELETE_GROUP, registerGroup.getRegisterGroupId()) > 0;		
	}
	
}
