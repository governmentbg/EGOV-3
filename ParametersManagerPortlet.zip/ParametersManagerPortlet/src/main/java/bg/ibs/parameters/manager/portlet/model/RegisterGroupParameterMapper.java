package bg.ibs.parameters.manager.portlet.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class RegisterGroupParameterMapper implements RowMapper<RegisterGroupParameter> {

	public RegisterGroupParameter mapRow(ResultSet resultSet, int i) throws SQLException {

		RegisterGroupParameter parameter = new RegisterGroupParameter();
		parameter.setRegisterGroupParameterId(resultSet.getLong("registerGroupParameterId"));
		parameter.setRegisterGroupId(resultSet.getLong("registerGroupId"));
		parameter.setName(resultSet.getString("name"));
		parameter.setLabel(resultSet.getString("label"));
		parameter.setParameterType(resultSet.getInt("parameterType"));
		parameter.setParameterValue(resultSet.getString("parameterValue"));
		parameter.setDefaultValue(resultSet.getString("defaultValue"));
		parameter.setDescription(resultSet.getString("description"));
		parameter.setHeader(resultSet.getString("header"));
		parameter.setRequired(resultSet.getInt("required"));
		parameter.setConsent(resultSet.getInt("consent"));
		parameter.setWeight(resultSet.getInt("weight"));
		parameter.setStatus(resultSet.getInt("status"));
		parameter.setDateCreated(resultSet.getDate("dateCreated"));
		parameter.setDateModified(resultSet.getDate("dateModified"));
		parameter.setUserId(resultSet.getString("userId"));
		return parameter;
	}
}
