package bg.ibs.parameters.manager.portlet.communicator;

import java.security.PrivilegedExceptionAction;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ibm.portal.um.PumaEnvironment;
import com.ibm.portal.um.PumaHome;
import com.ibm.portal.um.PumaProfile;
import com.ibm.portal.um.User;

import bg.ibs.parameters.manager.portlet.ParametersManagerConstants;
import bg.ibs.parameters.manager.portlet.utils.ParametersManagerLogger;

@Component
public class PumaCommunicator {
	@Autowired
	ParametersManagerLogger logger;
		
	@SuppressWarnings("rawtypes")
	public String getUserUID(final User user, final PumaHome pumaHome) {
		java.util.Map<String, Object> userInfo = getUserAttributesInfo(user, pumaHome, pumaHome.getProfile());
		if (userInfo != null) {
			Object attribute = userInfo.get(ParametersManagerConstants.LDAP_ATTRIBUTE_UID);
			if (attribute != null) {
				String currentUserUID = null;
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							currentUserUID += " ";
						}
						currentUserUID += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					currentUserUID = (String)attribute;
				}		
				return currentUserUID;
			}
		}
		return null;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public java.util.Map<String, Object> getUserAttributesInfo(final User user, final PumaHome pumaHome, final PumaProfile pumaProfile) {
		logger.message("getUserAttributesInfo(com.ibm.portal.um.User)");
		final java.util.List<String> attributesNamesList;
		try {
			final PumaEnvironment env = pumaHome.getEnvironment();
			attributesNamesList = new ArrayList<>();
			attributesNamesList.add(ParametersManagerConstants.LDAP_ATTRIBUTE_UID);
			java.util.Map<String, Object> userInfo = (java.util.Map<String, Object>) env.runUnrestricted(new PrivilegedExceptionAction() {
				public Object run() throws Exception {
					return pumaProfile.getAttributes((com.ibm.portal.um.Principal) user, attributesNamesList);
				}
			});
			return userInfo;
		} catch (Exception e) {
			logger.error("getUserAttributesInfo(user, pumaHome, pumaProfile) -> Exception: " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
}
