package bg.ibs.parameters.manager.portlet.beans;

import bg.ibs.parameters.manager.portlet.ParametersManagerConstants;
import bg.ibs.parameters.manager.portlet.model.RegisterGroup;

public class Container {
	
	private int currentTab = ParametersManagerConstants.TAB_PROFILE_TYPES;
	private int currentView = ParametersManagerConstants.VIEW_PROFILE_TYPES;
	private Integer profileType = null;
	private RegisterGroup group = null;
	private String filterLabel = null;
	// Used only for state "Groups".
	private Integer filterProfileType = null;
	private Integer filterProfileStructureType = null;
	// Used only for state "Parameters".
	private Long filterGroup = null;
	private Integer filterStatus = null;
	private boolean filterInitialised;
	private int resultsPerPage = 0;
	private int start = 0;
	private int orderColumn = ParametersManagerConstants.COLUMN_ID;
	private String order = ParametersManagerConstants.ORDER_ASC;	
	
	public int getCurrentTab() {
		return currentTab;
	}

	public void setCurrentTab(int currentTab) {
		this.currentTab = currentTab;
	}

	public int getCurrentView() {
		return currentView;
	}

	public void setCurrentView(int currentView) {
		this.currentView = currentView;
	}

	public Integer getProfileType() {
		return profileType;
	}

	public void setProfileType(Integer profileType) {
		this.profileType = profileType;
	}

	public RegisterGroup getGroup() {
		return group;
	}

	public void setGroup(RegisterGroup group) {
		this.group = group;
	}

	public String getFilterLabel() {
		return filterLabel;
	}

	public void setFilterLabel(String filterLabel) {
		this.filterLabel = filterLabel;
	}

	public Integer getFilterProfileType() {
		return filterProfileType;
	}

	public void setFilterProfileType(Integer filterProfileType) {
		this.filterProfileType = filterProfileType;
	}

	public Integer getFilterProfileStructureType() {
		return filterProfileStructureType;
	}

	public void setFilterProfileStructureType(Integer filterProfileStructureType) {
		this.filterProfileStructureType = filterProfileStructureType;
	}

	public Long getFilterGroup() {
		return filterGroup;
	}

	public void setFilterGroup(Long filterGroup) {
		this.filterGroup = filterGroup;
	}

	public Integer getFilterStatus() {
		return filterStatus;
	}

	public void setFilterStatus(Integer filterStatus) {
		this.filterStatus = filterStatus;
	}

	public boolean isFilterInitialised() {
		return filterInitialised;
	}

	public void setFilterInitialised(boolean filterInitialised) {
		this.filterInitialised = filterInitialised;
	}

	public int getResultsPerPage() {
		return resultsPerPage;
	}

	public void setResultsPerPage(int resultsPerPage) {
		this.resultsPerPage = resultsPerPage;
	}

	public int getStart() {
		return start;
	}

	public void setStart(int start) {
		this.start = start;
	}

	public int getOrderColumn() {
		return orderColumn;
	}

	public void setOrderColumn(int orderColumn) {
		this.orderColumn = orderColumn;
	}

	public String getOrder() {
		return order;
	}

	public void setOrder(String order) {
		this.order = order;
	}

}

