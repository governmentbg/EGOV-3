package bg.ibs.parameters.manager.portlet.dao;

import java.util.List;

import bg.ibs.parameters.manager.portlet.model.RegisterGroup;

public interface RegisterGroupDAO {
	RegisterGroup getRegisterGroupById(Long id);
	RegisterGroup getRegisterGroupByName(String name);
	RegisterGroup getRegisterGroupByNameExcId(String name, Long id);
	List<RegisterGroup> getAllRegisterGroups();  
	List<RegisterGroup> getAllRegisterGroupsByIds(List<Long> ids);  
	List<RegisterGroup> getAllRegisterGroupsByFilter(String label, Integer profileType, Integer profileStructureType, Integer status, Integer orderColumn, String order);   
	RegisterGroup createRegisterGroup(RegisterGroup registerGroup);
	boolean updateRegisterGroup(RegisterGroup registerGroup);
	boolean updateStatusRegisterGroup(RegisterGroup registerGroup);
	boolean deleteRegisterGroup(RegisterGroup registerGroup);
	
}
