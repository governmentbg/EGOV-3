package bg.ibs.parameters.manager.portlet.communicator; 

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.egov.wcm.cache.EgovProfileStructureType;
import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.Category;

import bg.ibs.parameters.manager.portlet.utils.ParametersManagerLogger;

@Component
public class WCMCommunicator {
	@Autowired
	ParametersManagerLogger logger;
	
	public Category getProfileTypeCategoryByName(String profileType) {
		if (profileType != null) {
			List<Category> categories = EgovWCMCache.getCategoriesProfileTypes();
			if (categories != null && categories.size() > 0) {
				for (int i = 0; i < categories.size(); i++) {
					if (profileType.equalsIgnoreCase(categories.get(i).getName())) {
						return categories.get(i);
					}
				}				
			}
		}
		return null;
	}
	public String getProfileTypeName(String profileType) {
		if (profileType != null) {
			List<Category> categories = EgovWCMCache.getCategoriesProfileTypes();
			if (categories != null && categories.size() > 0) {
				for (int i = 0; i < categories.size(); i++) {
					if (profileType.equalsIgnoreCase(categories.get(i).getName())) {
						return categories.get(i).getTitle();
					}
				}				
			}
		}
		return "";
	}
	
	public String getProfileStructureTypeName(String profileStructureType) {
		if (profileStructureType != null) {
			List<EgovProfileStructureType> profileStructureTypes = EgovWCMCache.getProfileStructureTypes();
			if (profileStructureTypes != null && profileStructureTypes.size() > 0) {
				for (int i = 0; i < profileStructureTypes.size(); i++) {
					if (profileStructureType.equalsIgnoreCase(profileStructureTypes.get(i).getName())) {
						return profileStructureTypes.get(i).getTitle();
					}
				}				
			}
		}
		return "";
	}
}
