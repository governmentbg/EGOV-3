package bg.ibs.parameters.manager.portlet.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class RegisterGroupMapper implements RowMapper<RegisterGroup> {

	public RegisterGroup mapRow(ResultSet resultSet, int i) throws SQLException {

		RegisterGroup group = new RegisterGroup();
		group.setRegisterGroupId(resultSet.getLong("registerGroupId"));
		group.setName(resultSet.getString("name"));
		group.setLabel(resultSet.getString("label"));
		group.setProfileType(resultSet.getString("profileType"));
		group.setProfileStructureType(resultSet.getString("profileStructureType"));
		group.setWeight(resultSet.getString("weight"));
		group.setStatus(resultSet.getInt("status"));
		group.setDateCreated(resultSet.getDate("dateCreated"));
		group.setDateModified(resultSet.getDate("dateModified"));
		group.setUserId(resultSet.getString("userId"));
		return group;
	}
}
