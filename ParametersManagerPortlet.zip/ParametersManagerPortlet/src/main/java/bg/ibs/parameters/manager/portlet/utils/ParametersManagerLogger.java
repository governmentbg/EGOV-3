package bg.ibs.parameters.manager.portlet.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import bg.ibs.parameters.manager.portlet.controllers.PortletViewController;

@Component
public class ParametersManagerLogger {
	
	private Logger logger = LoggerFactory.getLogger("ParametersManagerPortlet");
		
	public void error(String message) {
		logger.error(message);
	}
	public void message(String message) {
//		logger.trace("A TRACE Message");
//      logger.debug("A DEBUG Message");
//      logger.info("An INFO Message");
//      logger.warn("A WARN Message");
//      logger.error("An ERROR Message");
		if (PortletViewController.isDebug) {
			logger.info(message);
		}
	}
	
	public Logger getLogger() {
		return logger;
	}	
	
	public static void main(String[] args) {
		ParametersManagerLogger parametersManagerLogger = new ParametersManagerLogger();
		parametersManagerLogger.error("test");
	}
}
