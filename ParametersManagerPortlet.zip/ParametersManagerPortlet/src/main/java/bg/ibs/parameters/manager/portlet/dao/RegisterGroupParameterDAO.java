package bg.ibs.parameters.manager.portlet.dao;

import java.util.List;

import bg.ibs.parameters.manager.portlet.model.RegisterGroupParameter;

public interface RegisterGroupParameterDAO {
	Integer countParametersByFilter(String label, Long groupId, Integer status);
	RegisterGroupParameter getRegisterGroupParameterById(Long id);
	RegisterGroupParameter getRegisterGroupParameterByName(String name);
	RegisterGroupParameter getRegisterGroupParameterByGroupIdAndName(Long groupId, String name);
	RegisterGroupParameter getRegisterGroupParameterByGroupIdAndNameExcId(Long groupId, String name, Long parameterId);
	List<RegisterGroupParameter> getAllRegisterGroupParameters();
	List<RegisterGroupParameter> getAllRegisterGroupParametersOrderByGroupIdAndWeight();
	List<RegisterGroupParameter> getAllRegisterGroupParametersByFilter(String label, Long groupId, Integer status, Integer start, Integer length, Integer orderColumn, String order);		
	RegisterGroupParameter createRegisterGroupParameter(RegisterGroupParameter registerGroupParameter);
	boolean updateRegisterGroupParameter(RegisterGroupParameter registerGroupParameter);
	boolean updateStatusRegisterGroupParameter(RegisterGroupParameter registerGroupParameter);
	boolean deleteRegisterGroupParameter(RegisterGroupParameter registerGroupParameter);
}
