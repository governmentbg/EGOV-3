package bg.ibs.parameters.manager.portlet;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.web.context.annotation.SessionScope;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.InternalResourceView;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import bg.ibs.parameters.manager.portlet.beans.ParametersManagerSessionBean;

@Configuration 
@ComponentScan(basePackages = {"bg.ibs.parameters.manager.portlet"})
public class AppConfig  {
		
	@Bean(name = "messageSource")
	public ReloadableResourceBundleMessageSource getMessageSource() {
      ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
      messageSource.setBasename("classpath:/bg/ibs/parameters/manager/portlet/nl/ParametersManagerPortletResource");
      messageSource.setFallbackToSystemLocale(false);      
      messageSource.setUseCodeAsDefaultMessage(true);
      return messageSource;
	}
	
	@Bean(name = "viewResolver")
	public ViewResolver getViewResolver() {
	 InternalResourceViewResolver resolver = new InternalResourceViewResolver();
	 resolver.setViewClass(InternalResourceView.class);
	 resolver.setPrefix("/WEB-INF/jsp/");
	 resolver.setSuffix(".jsp");
	 resolver.setOrder(1);
	 resolver.setContentType("text/html; charset=UTF-8");
	 resolver.setCache(true);
	 return resolver;
	}
	
	
	@Bean(name = "dataSource")
    public DataSource dataSource() {		
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        return dataSource;
    }
	
	@Bean
    @SessionScope
    public ParametersManagerSessionBean sessionScopedBean() {
		System.out.println("ScopesConfig=sessionScopedBean");
        return new ParametersManagerSessionBean();
    }
}
