package bg.ibs.parameters.manager.portlet.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import bg.ibs.parameters.manager.portlet.dao.RegisterGroupDAO;
import bg.ibs.parameters.manager.portlet.model.RegisterGroup;

@Service("RegisterGroupService")
public class RegisterGroupServiceImpl implements RegisterGroupService {

	@Autowired
	@Qualifier("RegisterGroupDAO")
	private RegisterGroupDAO registerGroupDao; 
	
	public List<RegisterGroup> getAllRegisterGroupsByFilter(String label, Integer profileType, Integer profileStructureType, Integer status, Integer orderColumn, String order) {
		return registerGroupDao.getAllRegisterGroupsByFilter(label, profileType, profileStructureType, status, orderColumn, order);
	}
	
	public List<RegisterGroup> getAllRegisterGroups() {
		return registerGroupDao.getAllRegisterGroups();
	}
	
	public List<RegisterGroup> getAllRegisterGroupsByIds(List<Long> ids) {
		return registerGroupDao.getAllRegisterGroupsByIds(ids);
	}
	
	public RegisterGroup getRegisterGroupById(Long id) {
		return registerGroupDao.getRegisterGroupById(id);
	}
	
	public RegisterGroup getRegisterGroupByName(String name) {
		return registerGroupDao.getRegisterGroupByName(name); 
	}
	
	public RegisterGroup getRegisterGroupByNameExcId(String name, Long id) {
		return registerGroupDao.getRegisterGroupByNameExcId(name, id); 
	}
	
	public RegisterGroup createRegisterGroup(RegisterGroup registerGroup) {
		return registerGroupDao.createRegisterGroup(registerGroup);
	}
	
	public boolean updateRegisterGroup(RegisterGroup registerGroup) {
		return registerGroupDao.updateRegisterGroup(registerGroup);
	}
	
	public boolean updateStatusRegisterGroup(RegisterGroup registerGroup) {
		return registerGroupDao.updateStatusRegisterGroup(registerGroup);
	}
	
	public boolean deleteRegisterGroup(RegisterGroup registerGroup) {
		return registerGroupDao.deleteRegisterGroup(registerGroup);
	}

}
