package bg.ibs.parameters.manager.portlet.utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequest;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import com.ibm.workplace.wcm.api.Category;

import bg.ibs.parameters.manager.portlet.ParametersManagerConstants;
import bg.ibs.parameters.manager.portlet.beans.ProfileStructureTypeBean;
import bg.ibs.parameters.manager.portlet.beans.ProfileTypeBean;
import bg.ibs.parameters.manager.portlet.communicator.WCMCommunicator;
import bg.ibs.parameters.manager.portlet.model.RegisterGroup;
import bg.ibs.parameters.manager.portlet.model.RegisterGroupParameter;

@Component
public class ParametersManagerUtils {
	
	@Resource(name = "messageSource")
	private MessageSource messageSource;
	@Autowired
	WCMCommunicator wcmCommunicator;
	
	public String getRemoteIP(PortletRequest portletRequest) {
		String remoteIP = "localhost";	
		HttpServletRequest httpServletRequest = null;
		try {
			httpServletRequest = (HttpServletRequest) (com.ibm.ws.portletcontainer.portlet.PortletUtils.getHttpServletRequest(portletRequest));
			remoteIP = httpServletRequest.getHeader("X-FORWARDED-FOR");
			if (remoteIP == null) {
				remoteIP = httpServletRequest.getRemoteAddr();
			}				
		} catch (Exception e) {
			e.printStackTrace();
		}
		return remoteIP;
	}
	
	public String formatMultipleFieldsToOne(String str) {
		if (str == null || str.trim().length() == 0) {
			return null;
		}
		String[] profileTypes = str.split(",");
		String formatedProfileTypes = "";
		for (int i = 0; i < profileTypes.length; i++) {
			formatedProfileTypes += "^" + profileTypes[i] + "^";
		}
		return formatedProfileTypes;
	}
	
	public boolean hasMultipleProfileTypes(String profileType) {
		if (profileType != null) {
			return profileType.indexOf("^^") != -1;				
		}
		return false;
	}
	
	public String getProfileTypeNames(String profileType) {
		if (profileType != null) {
			if (profileType.indexOf("^^") != -1) {
				String[] profileTypeIds = profileType.split("\\^\\^");
				String profileNames = "";
				for (int i = 0; i < profileTypeIds.length; i++) {
					if (i > 0) {
						profileNames += ", ";
					}
					profileNames += wcmCommunicator.getProfileTypeName(profileTypeIds[i].replaceAll("\\^", ""));
				}
				return profileNames;
			} else {
				profileType = profileType.replaceAll("\\^", "");
				return wcmCommunicator.getProfileTypeName(profileType);
			}
		}
		return "";
	}
	
	public String getProfileStructureTypeNames(String profileStructureType) {
		if (profileStructureType != null) {
			if (profileStructureType.indexOf("^^") != -1) {
				String[] profileStructureTypeIds = profileStructureType.split("\\^\\^");
				String profileNames = "";
				for (int i = 0; i < profileStructureTypeIds.length; i++) {
					if (i > 0) {
						profileNames += ", ";
					}
					profileNames += wcmCommunicator.getProfileStructureTypeName(profileStructureTypeIds[i].replaceAll("\\^", ""));
				}
				return profileNames;
			} else {
				profileStructureType = profileStructureType.replaceAll("\\^", "");
				return wcmCommunicator.getProfileStructureTypeName(profileStructureType);
			}
		}
		return "";
	}
	
	public String getProfileTypeWeights(String weight) {
		if (weight != null) {
			if (weight.indexOf("^^") != -1) {
				String[] weights = weight.split("\\^\\^");
				String weightsStr = "";
				for (int i = 0; i < weights.length; i++) {
					if (i > 0) {
						weightsStr += ", ";
					}
					weightsStr += weights[i].replaceAll("\\^", "");
				}
				return weightsStr;
			} else {
				return weight.replaceAll("\\^", "");
			}
		}
		return "";
	}
	
	public List<ProfileStructureTypeBean> getSelectedProfileStructureTypes(Object[] groupSelectedProfileStructureTypes) {
		List<ProfileStructureTypeBean> selectedProfileStructureTypes = new ArrayList<ProfileStructureTypeBean>();					
		String profileStructureTitle = null;
		ProfileStructureTypeBean tmpBean = null;
		if (groupSelectedProfileStructureTypes != null && groupSelectedProfileStructureTypes.length > 0) {
			for (int i = 0; i < groupSelectedProfileStructureTypes.length; i++) {
				profileStructureTitle = wcmCommunicator.getProfileStructureTypeName(groupSelectedProfileStructureTypes[i].toString());
				if (profileStructureTitle != null) {
					tmpBean = new ProfileStructureTypeBean();
					if (groupSelectedProfileStructureTypes[i] != null && groupSelectedProfileStructureTypes[i] instanceof Integer) {
						tmpBean.setName((Integer)groupSelectedProfileStructureTypes[i]);
					} else {
						tmpBean.setName(Integer.parseInt((String)groupSelectedProfileStructureTypes[i]));
					}
					tmpBean.setTitle(profileStructureTitle);
					selectedProfileStructureTypes.add(tmpBean);
				}
			}
		}
		return selectedProfileStructureTypes;
	}
	
	public List<ProfileTypeBean> getSelectedProfileTypes(Object[] groupProfileTypes, Object[] selectedProfileTypeWeights) {
		List<ProfileTypeBean> selectedProfileTypes = new ArrayList<ProfileTypeBean>();					
		Category tmpCategoryProfileType = null;
		ProfileTypeBean tmpBean = null;
		if (groupProfileTypes != null && groupProfileTypes.length > 0) {
			for (int i = 0; i < groupProfileTypes.length; i++) {
				tmpCategoryProfileType = wcmCommunicator.getProfileTypeCategoryByName(groupProfileTypes[i].toString());
				if (tmpCategoryProfileType != null) {
					tmpBean = new ProfileTypeBean();
					tmpBean.setName(Integer.parseInt(tmpCategoryProfileType.getName()));
					tmpBean.setTitle(tmpCategoryProfileType.getTitle());
					if (selectedProfileTypeWeights[i] != null && selectedProfileTypeWeights[i] instanceof Integer) {
						tmpBean.setWeight((Integer)selectedProfileTypeWeights[i]);
					} else {
						tmpBean.setWeight(Integer.parseInt((String)selectedProfileTypeWeights[i]));
					}
					selectedProfileTypes.add(tmpBean);
				}
			}
		}
		return selectedProfileTypes;
	}
	
	public Integer[] getArrayFromFormatedField(String str) {
		if (str != null && str.trim().length() > 0) {
			if (str.indexOf("^^") != -1) {
				String[] profileTypeIds = str.split("\\^\\^");
				Integer[] profileTypes = new Integer[profileTypeIds.length];
				for (int i = 0; i < profileTypeIds.length; i++) {
					profileTypes[i] = Integer.parseInt(profileTypeIds[i].replaceAll("\\^", ""));
				}
				return profileTypes;
			} else {
				return new Integer[] {Integer.parseInt(str.replaceAll("\\^", ""))};
			}
		}
		return null;
	}
	
	public List<RegisterGroup> orderGroupsByWeight(List<RegisterGroup> groups, Integer profileType, String order) {
		if (profileType == null) {
			return groups;
		}
		List<RegisterGroup> orderedGroups = new ArrayList<>();
		RegisterGroup group = null;
		Integer weight = null;
		int fault = 10000;
		List<Integer> weights = new ArrayList<>(); 
		HashMap<Integer, List<RegisterGroup>> hm = new HashMap<Integer, List<RegisterGroup>>();
		List<RegisterGroup> arr = null;
		for (int i = 0; i < groups.size(); i++) {
			group = groups.get(i);
			try {
				weight = getGroupWeightPerProfileType(group, profileType);
			} catch (Exception e) {
				e.printStackTrace();
				weight = fault++;				
			}
			if (!weights.contains(weight)) {
				weights.add(weight);
			}
			arr = hm.get(weight);
			if (arr == null) {
				arr = new ArrayList<>();
			}
			arr.add(group);
			hm.put(weight, arr);
		}
		if (ParametersManagerConstants.ORDER_DESC.equalsIgnoreCase(order)) {
			Collections.sort(weights, Collections.reverseOrder());
		} else {
			Collections.sort(weights);
		}
		for (int i = 0; i < weights.size(); i++) {
			arr = hm.get(weights.get(i));
			if (arr != null) {
				for (int j = 0; j < arr.size(); j++) {
					orderedGroups.add(arr.get(j));
				}
			}
		}
		return orderedGroups;
	}
	
	private Integer getGroupWeightPerProfileType(RegisterGroup group, Integer currentProfileType) throws Exception {
		Integer[] profileTypes = getArrayFromFormatedField(group.getProfileType());
		if (profileTypes != null) {
			Integer[] weights = getArrayFromFormatedField(group.getWeight());
			if (weights == null || profileTypes.length != weights.length) {
				throw new Exception("Mismatch data for order/profiletypes in database for group '" + group.getLabel() + "'");
			}
			for (int i = 0; i < profileTypes.length; i++) {
				if (profileTypes[i] == currentProfileType) {
					return weights[i];
				}
			}
		}
		return null;
	}
	
	public Integer getGroupWeightFromProfileTypeStr(String currentProfileType, String currentProfileTypeWeight, Integer filterProfileType, String groupLabel) throws Exception {
		Integer[] profileTypes = getArrayFromFormatedField(currentProfileType);
		if (profileTypes != null) {
			Integer[] weights = getArrayFromFormatedField(currentProfileTypeWeight);
			if (weights == null || profileTypes.length != weights.length) {
				throw new Exception("Mismatch data for order/profiletypes in database for group '" + groupLabel + "'");
			}
			for (int i = 0; i < profileTypes.length; i++) {
				if (profileTypes[i] == filterProfileType) {
					return weights[i];
				}
			}
		}
		return null;
	}
	
	public com.egov.wcm.cache.model.EgovRegisterGroup populateCacheGroup(RegisterGroup registerGroup) {
		com.egov.wcm.cache.model.EgovRegisterGroup group = new com.egov.wcm.cache.model.EgovRegisterGroup();
		group.setRegisterGroupId(registerGroup.getRegisterGroupId());
		group.setName(registerGroup.getName());
		group.setLabel(registerGroup.getLabel());
		group.setProfileType(registerGroup.getProfileType());
		group.setProfileStructureType(registerGroup.getProfileStructureType());
		group.setWeight(registerGroup.getWeight());
		group.setStatus(registerGroup.getStatus());
		group.setDateCreated(registerGroup.getDateCreated());
		group.setDateModified(registerGroup.getDateModified());
		group.setUserId(registerGroup.getUserId());
		return group;
	}
	
	public com.egov.wcm.cache.model.EgovRegisterGroupParameter populateCacheParameter(RegisterGroupParameter registerParameter) {
		com.egov.wcm.cache.model.EgovRegisterGroupParameter parameter = new com.egov.wcm.cache.model.EgovRegisterGroupParameter();
		parameter.setRegisterGroupParameterId(registerParameter.getRegisterGroupParameterId());
		parameter.setRegisterGroupId(registerParameter.getRegisterGroupId());
		parameter.setName(registerParameter.getName());
		parameter.setLabel(registerParameter.getLabel());
		parameter.setParameterType(registerParameter.getParameterType());
		parameter.setParameterValue(registerParameter.getParameterValue());
		parameter.setDefaultValue(registerParameter.getDefaultValue());
		parameter.setDescription(registerParameter.getDescription());
		parameter.setHeader(registerParameter.getHeader());
		parameter.setRequired(registerParameter.getRequired());
		parameter.setConsent(registerParameter.getConsent());
		parameter.setWeight(registerParameter.getWeight());
		parameter.setStatus(registerParameter.getStatus());
		parameter.setDateCreated(registerParameter.getDateCreated());
		parameter.setDateModified(registerParameter.getDateModified());
		parameter.setUserId(registerParameter.getUserId());
		return parameter;
	}
	
	public String getStatusName(int status, PortletRequest portletRequest) {
		if (ParametersManagerConstants.STATUS_ACTIVE == status) {
			return messageSource.getMessage("status.active", null, getLocale(portletRequest));
		} else if (ParametersManagerConstants.STATUS_INACTIVE == status) {
			return messageSource.getMessage("status.inactive", null, getLocale(portletRequest));
		}
		return "";
	}
	
	public String getRequiredName(int required, PortletRequest portletRequest) {
		if (ParametersManagerConstants.VALUE_YES == required) {
			return messageSource.getMessage("common.yes", null, getLocale(portletRequest));
		} else if (ParametersManagerConstants.VALUE_NO == required) {
			return messageSource.getMessage("common.no", null, getLocale(portletRequest));
		}
		return "";
	}
	
	public Locale getLocale(PortletRequest request) {
		PortletPreferences prefs = request.getPreferences();
		return new Locale(prefs.getValue(ParametersManagerConstants.SETTING_PARAMETER_LANGUAGE, ParametersManagerConstants.LANGUAGE_BG));
	}
}
