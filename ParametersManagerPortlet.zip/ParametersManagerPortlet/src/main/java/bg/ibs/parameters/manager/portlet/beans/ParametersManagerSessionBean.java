package bg.ibs.parameters.manager.portlet.beans;

import java.util.HashMap;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import bg.ibs.parameters.manager.portlet.ParametersManagerConstants;

@SessionScope
@Component
public class ParametersManagerSessionBean {
	
	private String currentPage = ParametersManagerConstants.INDEX_PAGE;
	private HashMap<String, Container> container = null;
	private HashMap<String, Integer> tabPerPage = null;
	private HashMap<String, Integer> viewPerTab = null;
	private Long id = null;	
	private Integer profileTypeId = null;
	private Long groupId = null;
	private Integer mode = null;
	private String userUID = null;
	private String error = null;
	private String message = null;
	private int view = ParametersManagerConstants.VIEW_PROFILE_TYPES;
	private boolean initialised;
	
	public String getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}
	
	public HashMap<String, Container> getContainer() {
		return container != null ? container : new HashMap<String, Container>();
	}

	public void setContainer(HashMap<String, Container> container) {
		this.container = container;
	}

	public HashMap<String, Integer> getTabPerPage() {
		return tabPerPage != null ? tabPerPage : new HashMap<String, Integer>();
	}

	public void setTabPerPage(HashMap<String, Integer> tabPerPage) {
		this.tabPerPage = tabPerPage;
	}
	
	public HashMap<String, Integer> getViewPerTab() {
		return viewPerTab != null ? viewPerTab : new HashMap<String, Integer>();
	}

	public void setViewPerTab(HashMap<String, Integer> viewPerTab) {
		this.viewPerTab = viewPerTab;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getProfileTypeId() {
		return profileTypeId;
	}

	public void setProfileTypeId(Integer profileTypeId) {
		this.profileTypeId = profileTypeId;
	}

	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public Integer getMode() {
		return mode;
	}

	public void setMode(Integer mode) {
		this.mode = mode;
	}

	public String getUserUID() {
		return userUID;
	}

	public void setUserUID(String userUID) {
		this.userUID = userUID;
	}

	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getView() {
		return view;
	}

	public void setView(int view) {
		this.view = view;
	}

	public boolean isInitialised() {
		return initialised;
	}
	public void setInitialised(boolean initialised) {
		this.initialised = initialised;
	}
}
