package bg.ibs.parameters.manager.portlet.communicator;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.ibs.parameters.manager.portlet.controllers.PortletViewController;
import bg.ibs.parameters.manager.portlet.utils.ParametersManagerLogger;

@Component
public class ESBCommunicator {
	
	@Autowired
	ParametersManagerLogger logger;

	public int sendEvent(String userUID, String activityName, String activityDetails, String page, String remoteIP, boolean isForCentralAuditLog) {
		int result = 0;
		logger.message("sendEvent(" + userUID + "," + activityName + "," + activityDetails + "," + page + "," + remoteIP + ", " + isForCentralAuditLog + ")");
		
		// Create a trust manager that does not validate certificate chains
        TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {return null;}
            public void checkClientTrusted(X509Certificate[] certs, String authType) {}
            public void checkServerTrusted(X509Certificate[] certs, String authType) {}
        }
        };

        try {
        	// Install the all-trusting trust manager
	        SSLContext sc = SSLContext.getInstance("SSL");
	        sc.init(null, trustAllCerts, new java.security.SecureRandom());
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

	        // Create all-trusting host name verifier
	        HostnameVerifier allHostsValid = new HostnameVerifier() {
	            public boolean verify(String hostname, SSLSession session) {
	                return true;
	            }
	        };
	        // Install the all-trusting host verifier
	        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
			StringBuilder strBuf = new StringBuilder();
	        HttpsURLConnection conn = null;
	        BufferedReader reader = null;
	        try {
	        	if (page == null) {
	        		page = "";
	        	}
	        	JSONObject jsonObject = new JSONObject();
	        	jsonObject.put("userId", userUID);
	        	jsonObject.put("activity", activityName);
	        	jsonObject.put("activityDetails", activityDetails);
	        	jsonObject.put("page", page);
	        	jsonObject.put("ipAddress", remoteIP);
	        	String json = jsonObject.toString();
	        	 
	        	// Call for addEvent.	            
	            URL url = new URL(PortletViewController.esbEventLogAddress + "/addEvent");
	            conn = (HttpsURLConnection) url.openConnection();
	            conn.setRequestMethod("POST");
	            conn.setRequestProperty("Content-Type", "application/json; utf-8");
	            conn.setRequestProperty("Accept", "application/json");
	            conn.setRequestProperty("isForCentralAuditLog", String.valueOf(isForCentralAuditLog));
	            conn.setConnectTimeout(5000); // 5 seconds
	            conn.setReadTimeout(5000); // 5 seconds
	            conn.setDoOutput(true);	            
	
	            try (OutputStream os = conn.getOutputStream()) {
	                byte[] input = json.getBytes("utf-8");
	                os.write(input, 0, input.length);
	            }
	
	            if (conn.getResponseCode() != 200) {
	                throw new RuntimeException("HTTP POST Request Failed with Error code : "
	                        + conn.getResponseCode());
	            }
	
	            reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
	            String output = null;
	            while ((output = reader.readLine()) != null) {
	                strBuf.append(output);
	            }
	            result = 1;
	        } catch (IOException e) {
	            e.printStackTrace();
	        } finally {
	            if (reader != null) {
	                try {
	                    reader.close();
	                } catch (IOException e) {
	                    e.printStackTrace();
	                }
	            }
	            if (conn != null) {
	                conn.disconnect();
	            }
	        }
        
        } catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	

}