package bg.ibs.parameters.manager.portlet.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class RegisterGroupParameter {
	@Id	
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long registerGroupParameterId;
	@Column(nullable = false)
	private Long registerGroupId;
	@Column(nullable = false)
	private String name;
	@Column(nullable = false)
	private String label;
	@Column(nullable = false)
	private int parameterType;	
	private String parameterValue;
	private String defaultValue;
	private String description;
	private String header;
	private int required;
	private int consent;
	@Column(nullable = false)
	private int weight;
	@Column(nullable = false)
	private int status;
	@Column(name = "dateCreated", nullable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreated;
	
	@Column(name = "dateModified", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateModified;
	private String userId;
	
	public Long getRegisterGroupParameterId() {
		return registerGroupParameterId;
	}
	public void setRegisterGroupParameterId(Long registerGroupParameterId) {
		this.registerGroupParameterId = registerGroupParameterId;
	}
	public Long getRegisterGroupId() {
		return registerGroupId;
	}
	public void setRegisterGroupId(Long registerGroupId) {
		this.registerGroupId = registerGroupId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public int getParameterType() {
		return parameterType;
	}
	public void setParameterType(int parameterType) {
		this.parameterType = parameterType;
	}
	public String getParameterValue() {
		return parameterValue;
	}
	public void setParameterValue(String parameterValue) {
		this.parameterValue = parameterValue;
	}
	public String getDefaultValue() {
		return defaultValue;
	}
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getHeader() {
		return header;
	}
	public void setHeader(String header) {
		this.header = header;
	}
	public int getRequired() {
		return required;
	}
	public void setRequired(int required) {
		this.required = required;
	}
	public int getConsent() {
		return consent;
	}
	public void setConsent(int consent) {
		this.consent = consent;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	public Date getDateModified() {
		return dateModified;
	}
	public void setDateModified(Date dateModified) {
		this.dateModified = dateModified;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
}
