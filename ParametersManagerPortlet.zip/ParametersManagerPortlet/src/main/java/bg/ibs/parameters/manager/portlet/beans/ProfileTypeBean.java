package bg.ibs.parameters.manager.portlet.beans;

public class ProfileTypeBean {
	Integer name = null;
	String title = null;
	Integer weight = null;
	
	public Integer getName() {
		return name;
	}
	public void setName(Integer name) {
		this.name = name;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Integer getWeight() {
		return weight;
	}
	public void setWeight(Integer weight) {
		this.weight = weight;
	}
	
}
