package bg.ibs.parameters.manager.portlet;

public final class ParametersManagerConstants {
	
	// DB schema name.
	public static final String DB_SCHEMA_NAME = "EGOV";
	// JNDI name.
	public static final String JNDI = "jdbc/egovdbDS";
	
	// Portlet session bean name.
	public static final String SESSION_BEAN = "ParametersManagerSessionBean";
	
	// Portlet settings parameters.
	public static final String SETTING_PARAMETER_ESB_EVENT_LOGGER_ADDRESS = "esbEventLogAddress";
	public static final String SETTING_PARAMETER_LANGUAGE = "language";
	public static final String SETTING_PARAMETER_DEBUG = "debug";	

	// Supported language codes.
	public static final String LANGUAGE_BG = "bg";
	public static final String LANGUAGE_EN = "en";
	
	// Profile types.
	public static final int USER_PROFILE_TYPE_PERSONAL = 1;
	public static final int USER_PROFILE_TYPE_LEGAL_ENTITY = 2;
	public static final int USER_PROFILE_TYPE_SERVICE_SUPPLIER = 3;
	public static final int USER_PROFILE_TYPE_LEGAL_ENTITY_AL2 = 4;
	
	// Status codes.
	public static final int STATUS_INACTIVE = 0;
	public static final int STATUS_ACTIVE = 1;
	
	// Parameters.
	public static final int VALUE_NO = 0;
	public static final int VALUE_YES = 1;
	// Parameters types.
	public static final int PARAMETER_TYPE_TEXT = 1;
	public static final int PARAMETER_TYPE_TEXT_AREA = 2;
	public static final int PARAMETER_TYPE_NUMBER = 3;
	public static final int PARAMETER_TYPE_LIST_SINGLE = 4;
	public static final int PARAMETER_TYPE_LIST_MULTIPLE = 5;
	public static final Integer[] PARAMETER_TYPES_IDS = new Integer[] {
		PARAMETER_TYPE_TEXT, PARAMETER_TYPE_TEXT_AREA, PARAMETER_TYPE_NUMBER,
		PARAMETER_TYPE_LIST_SINGLE,PARAMETER_TYPE_LIST_MULTIPLE
	};
	public static final String[] PARAMETER_TYPES_NAMES = new String[] {
		"Текст", "Текстово поле (повече от един ред)", "Число", "Списък (единична стойност)", "Списък (множество стойности)"			
	};
	
	// Modes.
	public static final int MODE_READ = 0;
	public static final int MODE_EDIT = 1;
	

	
	// Pages.
	public static final String INDEX_PAGE = "index";
	public static final String GROUP_PAGE = "group";
	public static final String PARAMETER_PAGE = "parameter";
	
	// Tabs.
	public static final int TAB_PROFILE_TYPES = 0;
	public static final int TAB_GROUPS = 1;
	public static final int TAB_PARAMETERS = 2;
	
	public static final int VIEW_PROFILE_TYPES = 1;
	public static final int VIEW_GROUPS = 2;
	public static final int VIEW_PARAMETERS = 3;

	// Columns.
	public static final int COLUMN_ID = 0;
	
	public static final int COLUMN_GROUPS_LABEL = 1;
	public static final int COLUMN_GROUPS_PROFILE_TYPE = 2;
	public static final int COLUMN_GROUPS_PROFILE_STRUCTURE_TYPE = 3;
	public static final int COLUMN_GROUPS_STATUS = 4;
	public static final int COLUMN_GROUPS_WEIGHT = 5;

	public static final int COLUMN_PARAMETERS_LABEL = 1;
	public static final int COLUMN_PARAMETERS_GROUP = 2;
	public static final int COLUMN_PARAMETERS_REQUIRED = 3;
	public static final int COLUMN_PARAMETERS_STATUS = 4;
	public static final int COLUMN_PARAMETERS_WEIGHT = 5;
	// Order
	public static final String ORDER_ASC = "asc";
	public static final String ORDER_DESC = "desc";
	
	// LDAP.
	public static final String LDAP_ATTRIBUTE_UID = "_REPLACED_";
	
	// ESB.
	public static final String ESB_LOGGING_URL_TEST = "_REPLACED_";
	public static final String ESB_LOGGING_URL = "_REPLACED_";
	
	// AuditLog.
	public static final String EVENT_LOG_PORTAL_ADD_REGISTER_GROUP = "PORTAL_ADD_REGISTER_GROUP";
	public static final String EVENT_LOG_PORTAL_UPDATE_REGISTER_GROUP = "PORTAL_UPDATE_REGISTER_GROUP";
	public static final String EVENT_LOG_PORTAL_DEACTIVATE_REGISTER_GROUP = "PORTAL_DEACTIVATE_REGISTER_GROUP";
	public static final String EVENT_LOG_PORTAL_ACTIVATE_REGISTER_GROUP = "PORTAL_ACTIVATE_REGISTER_GROUP";
	public static final String EVENT_LOG_PORTAL_ADD_REGISTER_GROUP_PARAMETER = "PORTAL_ADD_REGISTER_GROUP_PARAMETER";
	public static final String EVENT_LOG_PORTAL_UPDATE_REGISTER_GROUP_PARAMETER = "PORTAL_UPDATE_REGISTER_GROUP_PARAMETER";
	public static final String EVENT_LOG_PORTAL_DEACTIVATE_REGISTER_GROUP_PARAMETER = "PORTAL_DEACTIVATE_REGISTER_GROUP_PARAMETER";
	public static final String EVENT_LOG_PORTAL_ACTIVATE_REGISTER_GROUP_PARAMETER = "PORTAL_ACTIVATE_REGISTER_GROUP_PARAMETER";
	public static final String EVENT_LOG_PORTAL_MARK_REQUIRED_REGISTER_GROUP_PARAMETER = "PORTAL_MARK_REQUIRED_REGISTER_GROUP_PARAMETER";
	public static final String EVENT_LOG_PORTAL_UNMARK_REQUIRED_REGISTER_GROUP_PARAMETER = "PORTAL_UNMARK_REQUIRED_REGISTER_GROUP_PARAMETER";
	public static final String EVENT_LOG_PORTAL_MARK_CONSENT_REGISTER_GROUP_PARAMETER = "PORTAL_MARK_CONSENT_REGISTER_GROUP_PARAMETER";
	public static final String EVENT_LOG_PORTAL_UNMARK_CONSENT_REGISTER_GROUP_PARAMETER = "PORTAL_UNMARK_CONSENT_REGISTER_GROUP_PARAMETER";
	
}
