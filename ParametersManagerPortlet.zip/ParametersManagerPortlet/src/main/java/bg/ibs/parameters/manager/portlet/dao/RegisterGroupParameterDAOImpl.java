package bg.ibs.parameters.manager.portlet.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import bg.ibs.parameters.manager.portlet.ParametersManagerConstants;
import bg.ibs.parameters.manager.portlet.model.RegisterGroupParameter;
import bg.ibs.parameters.manager.portlet.model.RegisterGroupParameterMapper;
import bg.ibs.parameters.manager.portlet.utils.ParametersManagerLogger;

@Repository("RegisterGroupParameterDAO")
@Transactional
public class RegisterGroupParameterDAOImpl implements RegisterGroupParameterDAO { 
	private static final String TABLE_NAME = "RegisterGroupParameter";
	
	JdbcTemplate jdbcTemplate;
	SimpleJdbcInsert simpleJdbcInsert;
	
	@Autowired
	ParametersManagerLogger logger; 

	private final String SQL_FIND_GROUP_PARAMETER = "select * from " + ParametersManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where registerGroupParameterId = ?";
	private final String SQL_FIND_GROUP_PARAMETER_BY_NAME = "select * from " + ParametersManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where LOWER(name) = ?";
	private final String SQL_FIND_GROUP_PARAMETER_BY_GROUPID_NAME = "select * from " + ParametersManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where registerGroupId =? AND LOWER(name) = ?";
	private final String SQL_FIND_GROUP_PARAMETER_BY_GROUPID_NAME_EXC_ID = "select * from " + ParametersManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where registerGroupId =? AND LOWER(name) = ? AND registerGroupParameterId <> ?";	
	private final String SQL_UPDATE_STATUS_PARAMETER = "update " + ParametersManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " set status = ?, dateModified = ? where registerGroupParameterId = ?";
	private final String SQL_DELETE_GROUP_PARAMETER = "delete from " + ParametersManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " where registerGroupParameterId = ?";
	private final String SQL_UPDATE_GROUP_PARAMETER = "update " + ParametersManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME + " set registerGroupId = ?, name = ?, label = ?, parameterType = ?, parameterValue = ?, defaultValue = ?, description = ?, header = ?, required = ?, consent = ?, weight = ?, status = ?, dateModified = ? where registerGroupParameterId = ?";
	private final String SQL_GET_ALL = "select * from " + ParametersManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME;
	private final String SQL_COUNT = "select count(registerGroupId) from " + ParametersManagerConstants.DB_SCHEMA_NAME + "." + TABLE_NAME;

	@Autowired
	public RegisterGroupParameterDAOImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
		simpleJdbcInsert = new SimpleJdbcInsert(dataSource).
				withSchemaName(ParametersManagerConstants.DB_SCHEMA_NAME).
				withTableName(TABLE_NAME).
				usingColumns(
						"registerGroupId", 
						"name", 
						"label", 
						"parameterType", 
						"parameterValue", 
						"defaultValue", 
						"description", 
						"header", 
						"required", 
						"consent", 
						"weight", 
						"status", 
						"dateCreated", 
						"dateModified", 
						"userId").
				usingGeneratedKeyColumns("registerGroupParameterId");
	}

	public Integer countParametersByFilter(final String label, final Long groupId, final Integer status) {
		if ((label == null || label.trim().length() == 0) && groupId == null && status == null) {
			return jdbcTemplate.queryForObject(SQL_COUNT + " where 1=1", Integer.class);
		}
		// We have filter(s) selected, so apply them.
		String qWhere = "";
		List<Object> filters = new ArrayList<>();
		if (label != null && label.trim().length() > 0) {
			qWhere += " WHERE LOWER(label) LIKE ?";
			filters.add("%" + label.toLowerCase() + "%");
		}
		if (groupId != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "registerGroupId = ?";
			filters.add(groupId);
		}
		if (status != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "status = ?";
			filters.add(status);
		}
		return jdbcTemplate.queryForObject(SQL_COUNT + qWhere, filters.toArray(new Object[filters.size()]), Integer.class);
	}
	
	public RegisterGroupParameter getRegisterGroupParameterById(final Long registerGroupParameterId) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_GROUP_PARAMETER, new Object[] { registerGroupParameterId }, new RegisterGroupParameterMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public RegisterGroupParameter getRegisterGroupParameterByName(final String name) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_GROUP_PARAMETER_BY_NAME, new Object[] { name.toLowerCase() }, new RegisterGroupParameterMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public RegisterGroupParameter getRegisterGroupParameterByGroupIdAndName(final Long registerGroupId, final String name) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_GROUP_PARAMETER_BY_GROUPID_NAME, new Object[] { registerGroupId, name.toLowerCase() }, new RegisterGroupParameterMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public RegisterGroupParameter getRegisterGroupParameterByGroupIdAndNameExcId(final Long registerGroupId, final String name, final Long parameterId) {
		try {
			return jdbcTemplate.queryForObject(SQL_FIND_GROUP_PARAMETER_BY_GROUPID_NAME_EXC_ID, new Object[] { registerGroupId, name.toLowerCase(), parameterId }, new RegisterGroupParameterMapper());
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
	
	public List<RegisterGroupParameter> getAllRegisterGroupParameters() {
		return jdbcTemplate.query(SQL_GET_ALL + " where 1=1 order by label " + ParametersManagerConstants.ORDER_ASC, new RegisterGroupParameterMapper());
	}
	
	public List<RegisterGroupParameter> getAllRegisterGroupParametersOrderByGroupIdAndWeight() {
		return jdbcTemplate.query(SQL_GET_ALL + " where 1=1 order by registerGroupId, weight " + ParametersManagerConstants.ORDER_ASC, new RegisterGroupParameterMapper());
	}
	
	public List<RegisterGroupParameter> getAllRegisterGroupParametersByFilter(final String label, final Long groupId, final Integer status, final Integer start, final Integer length, final Integer orderColumn, final String order) {
		String qOrder = "";
		if (orderColumn != null) {
			if (ParametersManagerConstants.COLUMN_ID == orderColumn) {
				qOrder = " order by registerGroupParameterId";
			} else if (ParametersManagerConstants.COLUMN_PARAMETERS_LABEL == orderColumn) {
				qOrder = " order by label";
			} else if (ParametersManagerConstants.COLUMN_PARAMETERS_REQUIRED == orderColumn) {
				qOrder = " order by required";
			} else if (ParametersManagerConstants.COLUMN_PARAMETERS_STATUS == orderColumn) {
				qOrder = " order by status";
			} else {
				qOrder = " order by weight";
			}
		} 
		if (qOrder.trim().length() == 0) {
			qOrder = " order by weight";
		}
		qOrder += " " + (ParametersManagerConstants.ORDER_DESC.equalsIgnoreCase(order) ? ParametersManagerConstants.ORDER_DESC : ParametersManagerConstants.ORDER_ASC);
		
		// NOT SUPPORTED BY DB2, so we are doing workaround.
		//qOrder += " LIMIT " + start + ", " + length;				
		qOrder += " FETCH FIRST " + (start + length) + " ROWS ONLY";
		
		if ((label == null || label.trim().length() == 0) && groupId == null && status == null) {
			logger.message("getAllRegisterGroupParametersByFilter SQL_GET_ALL");
			return jdbcTemplate.query(SQL_GET_ALL + " where 1=1" +  qOrder, new RegisterGroupParameterMapper());
		}
		// We have filter(s) selected, so apply them.
		String qWhere = "";
		List<Object> filters = new ArrayList<>();
		if (label != null && label.trim().length() > 0) {
			qWhere += " WHERE LOWER(label) LIKE ?";
			filters.add("%" + label.toLowerCase() + "%");
		}
		if (groupId != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "registerGroupId = ?";
			filters.add(groupId);
		}
		if (status != null) {
			if (qWhere.length() == 0) {
				qWhere += " WHERE ";
			} else {
				qWhere += " AND ";
			}
			qWhere += "status = ?";
			filters.add(status);
		}
		return jdbcTemplate.query(SQL_GET_ALL + qWhere + qOrder, filters.toArray(new Object[filters.size()]), new RegisterGroupParameterMapper());
	}

	public RegisterGroupParameter createRegisterGroupParameter(RegisterGroupParameter registerGroup) {
		Map<String, Object> parameters = new HashMap<String, Object>();
		parameters.put("registerGroupId", registerGroup.getRegisterGroupId());
	    parameters.put("name", registerGroup.getName());
	    parameters.put("label", registerGroup.getLabel());	    
	    parameters.put("parameterType", registerGroup.getParameterType());
	    parameters.put("parameterValue", registerGroup.getParameterValue());
	    parameters.put("defaultValue", registerGroup.getDefaultValue());
	    parameters.put("description", registerGroup.getDescription());
	    parameters.put("header", registerGroup.getHeader());
	    parameters.put("required", registerGroup.getRequired());
	    parameters.put("consent", registerGroup.getConsent());
	    parameters.put("weight", registerGroup.getWeight());
	    parameters.put("status", registerGroup.getStatus());
	    parameters.put("dateCreated", registerGroup.getDateCreated());
	    parameters.put("dateModified", registerGroup.getDateModified());
	    parameters.put("userId", registerGroup.getUserId());
		Long id = simpleJdbcInsert.executeAndReturnKey(parameters).longValue();
		logger.message("Generated id - " + id);
		registerGroup.setRegisterGroupParameterId(id);
		return registerGroup;
//		return jdbcTemplate.update(SQL_INSERT_GROUP, registerGroup.getName(), registerGroup.getLabel(), registerGroup.getProfileType(),
//				registerGroup.getWeight(), registerGroup.getStatus(), registerGroup.getDateCreated(), 
//				registerGroup.getDateModified(), registerGroup.getUserId()) > 0;
	}
	
	public boolean updateRegisterGroupParameter(RegisterGroupParameter registerGroupParameter) {
		return jdbcTemplate.update(SQL_UPDATE_GROUP_PARAMETER, 
				registerGroupParameter.getRegisterGroupId(), 
				registerGroupParameter.getName(), 
				registerGroupParameter.getLabel(), 
				registerGroupParameter.getParameterType(), 
				registerGroupParameter.getParameterValue(), 
				registerGroupParameter.getDefaultValue(), 
				registerGroupParameter.getDescription(), 
				registerGroupParameter.getHeader(),
				registerGroupParameter.getRequired(), 
				registerGroupParameter.getConsent(), 
				registerGroupParameter.getWeight(), 
				registerGroupParameter.getStatus(),
				registerGroupParameter.getDateModified(),
				registerGroupParameter.getRegisterGroupParameterId()) > 0;
	}
	
	public boolean updateStatusRegisterGroupParameter(RegisterGroupParameter registerGroupParameter) {
		return jdbcTemplate.update(SQL_UPDATE_STATUS_PARAMETER, registerGroupParameter.getStatus(), registerGroupParameter.getDateModified(), registerGroupParameter.getRegisterGroupParameterId()) > 0;		
	}
	
	public boolean deleteRegisterGroupParameter(RegisterGroupParameter registerGroupParameter) {
		return jdbcTemplate.update(SQL_DELETE_GROUP_PARAMETER, registerGroupParameter.getRegisterGroupParameterId()) > 0;
	}

}
