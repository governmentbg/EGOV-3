package com.ibm.kpimanager;

import java.util.ResourceBundle;

import javax.portlet.ActionRequest;

import com.ibm.kpi.bean.Container;
import com.ibm.kpi.bean.Message;
import com.ibm.kpi.management.IndicatorManagement;
import com.ibm.kpi.management.IndicatorValueManagement;
import com.ibm.kpi.management.OrganizationManagement;
import com.ibm.kpi.management.OrganizationUserManagement;
import com.ibm.kpi.management.SectorManagement;
import com.ibm.kpi.utils.KPIUtils;

public class KPIActionManager {
	public boolean processDelete(KPIPortletSessionBean sessionBean, ActionRequest request, ResourceBundle bundle) {
		String value = request.getParameter(KPIManagerPortlet.PARAMETER_VALUE);
		if (KPIManagerPortlet.ORGANIZATIONS_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			OrganizationManagement organizationManagement = new OrganizationManagement();
			return (1 == organizationManagement.removeKPIOrganization(value, sessionBean, bundle));
		} else if (KPIManagerPortlet.SECTORS_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			SectorManagement sectorManagement = new SectorManagement();
			return (1 == sectorManagement.removeKPISector(value, sessionBean, bundle));
		} else if (KPIManagerPortlet.INDICATORS_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			IndicatorManagement indicatorManagement = new IndicatorManagement();
			return (1 == indicatorManagement.removeKPIIndicator(value, sessionBean, bundle));
		} else if (KPIManagerPortlet.INDICATOR_VALUES_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			IndicatorValueManagement indicatorValueManagement = new IndicatorValueManagement();
			return (1 == indicatorValueManagement.removeKPIIndicatorValue(value, sessionBean, bundle));
		} else if (KPIManagerPortlet.ORGANIZATION_USERS_PAGE.equals(sessionBean.getCurrentPage())) {
			OrganizationUserManagement organizationUserManagement = new OrganizationUserManagement();
			return (1 == organizationUserManagement.removeOrganizationUser(value, sessionBean, bundle));
		}
		return false;
	}

	public boolean processAdd(KPIPortletSessionBean sessionBean, ActionRequest request, ResourceBundle bundle) {
		sessionBean.setParameterMap(null);
		if (KPIManagerPortlet.ORGANIZATION_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
			String organizationName = request.getParameter("organizationName");
			String organizationDescription = request.getParameter("organizationDescription");
			if (organizationName != null && organizationName.trim().length() > 0) {
				if (organizationDescription != null && organizationDescription.trim().length() > 250) {
					sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("organization.description.too.long")));
				} else {
					OrganizationManagement organizationManagement = new OrganizationManagement();
					if (organizationManagement.createKPIOrganization(organizationName, organizationDescription) == 1) {
						sessionBean.setCurrentPage(KPIManagerPortlet.ORGANIZATIONS_LIST_PAGE);
						sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_INFORMATION, "\"" + organizationName + "\" " + bundle.getString("added.successfully")));
						return true;
					} else {
						sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
					}
				}
				sessionBean.setParameterMap(request.getParameterMap());
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("organization.name.invalid")));
			}
		} else if (KPIManagerPortlet.SECTOR_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
			String sectorName = request.getParameter("sectorName");
			String sectorDescription = request.getParameter("sectorDescription");
			if (sectorName != null && sectorName.trim().length() > 0) {
				if (sectorDescription != null && sectorDescription.trim().length() > 250) {
					sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("sector.description.too.long")));
				} else {
					SectorManagement sectorManagement = new SectorManagement();
					if (sectorManagement.createKPISector(sectorName, sectorDescription) == 1) {
						sessionBean.setCurrentPage(KPIManagerPortlet.SECTORS_LIST_PAGE);
						sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_INFORMATION, "\"" + sectorName + "\" " + bundle.getString("added.successfully")));
						return true;
					} else {
						sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
					}
				}
				sessionBean.setParameterMap(request.getParameterMap());
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("sector.name.invalid")));
			}
		} else if (KPIManagerPortlet.ORGANIZATION_USERS_MEMBER_PAGE.equals(sessionBean.getCurrentPage())) {
			String[] memberIds = request.getParameterValues("member");
			if (memberIds != null && memberIds.length > 0) {
				Container container = sessionBean.getContainer().get(KPIManagerPortlet.ORGANIZATION_USERS_PAGE);
				OrganizationUserManagement organizationUserManagement = new OrganizationUserManagement();
				if (container != null) {
					if (organizationUserManagement.addOrganizationUsers(container.getId(), memberIds, sessionBean, bundle) == 1) {
						sessionBean.setCurrentPage(KPIManagerPortlet.ORGANIZATION_USERS_PAGE);
						return true;
					}
				}
				sessionBean.setParameterMap(request.getParameterMap());
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("invalid.parameters")));
			}
		} else if (KPIManagerPortlet.INDICATOR_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
			String name = request.getParameter("indicatorName");
			String organizationId = request.getParameter("organizationId");
			String responsibleUserId = request.getParameter("responsibleUserId");
			String period = request.getParameter("period");
			String description = request.getParameter("description");
			String targetValue = request.getParameter("targetValue");
			String targetType = request.getParameter("targetType");
			String[] sectors = request.getParameterValues("sectors");
			if (name != null && name.trim().length() > 0 && organizationId != null && organizationId.trim().length() > 0 && responsibleUserId != null && responsibleUserId.trim().length() > 0 && period != null && period.trim().length() > 0 && targetValue != null && targetValue.trim().length() > 0 && targetType != null && targetType.trim().length() > 0 && sectors != null && sectors.length > 0) {
				if (description != null && description.trim().length() > 250) {
					sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("indicator.description.too.long")));
				} else {
					IndicatorManagement indicatorManagement = new IndicatorManagement();
					if (indicatorManagement.createKPIIndicator(name, organizationId, responsibleUserId, period, description, KPIConstants.INDICATOR_INPUT_METHOD_MANUAL, targetValue, targetType, KPIManagerPortlet.currentUserDN, sectors, sessionBean, bundle) == 1) {
						sessionBean.setCurrentPage(KPIManagerPortlet.INDICATORS_LIST_PAGE);
						sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_INFORMATION, "\"" + name + "\" " + bundle.getString("added.successfully")));
						return true;
					} else {
						sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
					} 
				} 
				sessionBean.setParameterMap(request.getParameterMap());
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("invalid.parameters")));
			}
		} else if (KPIManagerPortlet.INDICATOR_VALUE_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
			String indicatorId = null;
			Container container = sessionBean.getContainer().get(KPIManagerPortlet.INDICATOR_VALUES_LIST_PAGE);
			if (container != null) {
				indicatorId = container.getId();
			}
			if (indicatorId != null) {
				IndicatorValueManagement indicatorValueManagement = new IndicatorValueManagement();
				if (indicatorValueManagement.createKPIIndicatorValue(request, indicatorId, KPIManagerPortlet.currentUserDN, sessionBean, bundle) == 1) {
					sessionBean.setCurrentPage(KPIManagerPortlet.INDICATOR_VALUES_LIST_PAGE);					
					return true;
				} //else {
					//sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
				//}
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
			}
			//sessionBean.setParameterMap(request.getParameterMap());
		}
		return false;
	}

	public boolean processEdit(KPIPortletSessionBean sessionBean, ActionRequest request, ResourceBundle bundle) {
		sessionBean.setParameterMap(null);
		if (KPIManagerPortlet.ORGANIZATION_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
			String organizationId = request.getParameter(KPIManagerPortlet.PARAMETER_ID);
			String organizationName = request.getParameter("organizationName");
			String organizationDescription = request.getParameter("organizationDescription");
			if (organizationId != null && organizationId.trim().length() > 0 && organizationName != null && organizationName.trim().length() > 0) {
				if (organizationDescription != null && organizationDescription.trim().length() > 250) {
					sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("organization.description.too.long")));
				} else {
					OrganizationManagement organizationManagement = new OrganizationManagement();
					if (organizationManagement.updateKPIOrganization(organizationId, organizationName, organizationDescription) == 1) {
						sessionBean.setCurrentPage(KPIManagerPortlet.ORGANIZATIONS_LIST_PAGE);
						sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_INFORMATION, "\"" + organizationName + "\" " + bundle.getString("edited.successfully")));
						return true;
					} else {
						sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
					}
				}
				sessionBean.setParameterMap(request.getParameterMap());
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("invalid.parameters")));
			}
			return false;
		} else if (KPIManagerPortlet.SECTOR_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
			String sectorId = request.getParameter(KPIManagerPortlet.PARAMETER_ID);
			String sectorName = request.getParameter("sectorName");
			String sectorDescription = request.getParameter("sectorDescription");
			if (sectorId != null && sectorId.trim().length() > 0 && sectorName != null && sectorName.trim().length() > 0) {
				if (sectorDescription != null && sectorDescription.trim().length() > 250) {
					sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("sector.description.too.long")));
				} else {
					SectorManagement sectorManagement = new SectorManagement();
					if (sectorManagement.updateKPISector(sectorId, sectorName, sectorDescription) == 1) {
						sessionBean.setCurrentPage(KPIManagerPortlet.SECTORS_LIST_PAGE);
						sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_INFORMATION, "\"" + sectorName + "\" " + bundle.getString("edited.successfully")));
						return true;
					} else {
						sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
					}
				}
				sessionBean.setParameterMap(request.getParameterMap());
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("invalid.parameters")));
			}
			return false;
		} else if (KPIManagerPortlet.INDICATOR_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
			String indicatorId = request.getParameter(KPIManagerPortlet.PARAMETER_ID);
			String name = request.getParameter("indicatorName");
			String organizationId = request.getParameter("organizationId");
			String responsibleUserId = request.getParameter("responsibleUserId");
			String period = request.getParameter("period");
			String description = request.getParameter("description");
			String targetValue = request.getParameter("targetValue");
			String targetType = request.getParameter("targetType");
			String[] sectors = request.getParameterValues("sectors");
			if (name != null && name.trim().length() > 0 && organizationId != null && organizationId.trim().length() > 0 && responsibleUserId != null && responsibleUserId.trim().length() > 0 && period != null && period.trim().length() > 0 && targetValue != null && targetValue.trim().length() > 0 && targetType != null && targetType.trim().length() > 0 && sectors != null && sectors.length > 0) {
				if (description != null && description.trim().length() > 250) {
					sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("indicator.description.too.long")));
				} else {
					IndicatorManagement indicatorManagement = new IndicatorManagement();
					if (indicatorManagement.updateKPIIndicator(indicatorId, name, organizationId, responsibleUserId, period, description, targetValue, targetType, sectors, sessionBean, bundle) == 1) {
						sessionBean.setCurrentPage(KPIManagerPortlet.INDICATORS_LIST_PAGE);
						sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_INFORMATION, "\"" + name + "\" " + bundle.getString("edited.successfully")));
						return true;
					} else {
						sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
					}
				}
				sessionBean.setParameterMap(request.getParameterMap());
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("invalid.parameters")));
			}
			return false;
		} else if (KPIManagerPortlet.INDICATOR_VALUE_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
			String indicatorValueId = null;
			Container container = sessionBean.getContainer().get(sessionBean.getCurrentPage());
			if (container != null) {
				indicatorValueId = container.getId();
			}
			if (indicatorValueId != null) {
				IndicatorValueManagement indicatorValueManagement = new IndicatorValueManagement();
				if (indicatorValueManagement.updateKPIIndicatorValue(request, indicatorValueId, sessionBean, bundle) == 1) {
					sessionBean.setCurrentPage(KPIManagerPortlet.INDICATOR_VALUES_LIST_PAGE);					
					return true;
				} else {
					sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
				}
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
			}
			return false;
		} else if (KPIManagerPortlet.ORGANIZATION_USER_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
			String organizationUserId = request.getParameter(KPIManagerPortlet.PARAMETER_ID);
			String userDN = request.getParameter("userDN");
			String role = request.getParameter("role");
			if (organizationUserId != null && organizationUserId.trim().length() > 0 && role != null) {
				OrganizationUserManagement organizationUserManagement = new OrganizationUserManagement();
				if (organizationUserManagement.updateOrganizationUser(organizationUserId, role) == 1) {
					sessionBean.setCurrentPage(KPIManagerPortlet.ORGANIZATION_USERS_PAGE);
					sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_INFORMATION, "\"" + KPIUtils.getUserFriendlyIDFromDN(userDN) + "\" " + bundle.getString("edited.successfully")));
					return true;
				} else {
					sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
				}
				sessionBean.setParameterMap(request.getParameterMap());
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("invalid.parameters")));
			}
			return false;
		}

		return false;
	}

	public boolean processUpload(KPIPortletSessionBean sessionBean, ActionRequest request, ResourceBundle bundle, String realPath) {
		sessionBean.setParameterMap(null);
		System.out.println("upload = " + sessionBean.getCurrentPage());
		if (KPIManagerPortlet.INDICATOR_VALUES_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			String indicatorId = null;
			Container container = sessionBean.getContainer().get(KPIManagerPortlet.INDICATOR_VALUES_LIST_PAGE);
			if (container != null) {
				indicatorId = container.getId();
			}
			if (indicatorId != null) {
				IndicatorValueManagement indicatorValueManagement = new IndicatorValueManagement();
				if (indicatorValueManagement.uploadFromFile(request, indicatorId, KPIManagerPortlet.currentUserDN, sessionBean, bundle, realPath) == 1) {
					sessionBean.setCurrentPage(KPIManagerPortlet.INDICATOR_VALUES_LIST_PAGE);					
					return true;
				} 
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
			}
		}
		return false;
	}
	public void processNavigator(KPIPortletSessionBean sessionBean, ActionRequest request) {
		Container container = sessionBean.getContainer().get(sessionBean.getCurrentPage());
		if (container != null) {
			String operation = request.getParameter(KPIManagerPortlet.PARAMETER_OPERATION);
			String value = request.getParameter(KPIManagerPortlet.PARAMETER_VALUE);
			int navigatorPage = container.getNavigatorPage();
			int navigatorTotalPages = container.getNavigatorTotalPages();
			if (operation != null && operation.trim().length() > 0) {
				if (KPIManagerPortlet.NAVIGATOR_OPERATION_FIRST.equals(operation)) {
					container.setNavigatorPage(1);
				} else if (KPIManagerPortlet.NAVIGATOR_OPERATION_PREVIOUS.equals(operation)) {
					if (navigatorPage > 1) {
						container.setNavigatorPage(navigatorPage - 1);
					}
				} else if (KPIManagerPortlet.NAVIGATOR_OPERATION_NEXT.equals(operation)) {
					if (navigatorPage < navigatorTotalPages) {
						container.setNavigatorPage(navigatorPage + 1);
					}
				} else if (KPIManagerPortlet.NAVIGATOR_OPERATION_LAST.equals(operation)) {
					container.setNavigatorPage(navigatorTotalPages);
				} else if (KPIManagerPortlet.NAVIGATOR_OPERATION_GOTO.equals(operation) && value != null && value.trim().length() > 0) {
					try {
						if (Integer.parseInt(value) > navigatorTotalPages) {
							container.setNavigatorPage(navigatorTotalPages);
						} else if (Integer.parseInt(value) < 1) {
							container.setNavigatorPage(1);
						} else {
							container.setNavigatorPage(Integer.parseInt(value));
						}
					} catch (NumberFormatException e) {
						e.printStackTrace();
					}
				}
				System.out.println("navPage = " + container.getNavigatorPage());
				sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
			}
		}
	}
}