package com.ibm.kpimanager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.ResourceBundle;

import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import com.ibm.kpi.bean.Container;
import com.ibm.kpi.bean.Message;
import com.ibm.kpi.dbo.KPIIndicator;
import com.ibm.kpi.dbo.KPIIndicatorHit;
import com.ibm.kpi.dbo.KPIIndicatorValue;
import com.ibm.kpi.dbo.KPIOrganization;
import com.ibm.kpi.dbo.KPIOrganizationUser;
import com.ibm.kpi.dbo.KPISector;
import com.ibm.kpi.management.IndicatorHitManagement;
import com.ibm.kpi.management.IndicatorManagement;
import com.ibm.kpi.management.IndicatorValueManagement;
import com.ibm.kpi.management.OrganizationManagement;
import com.ibm.kpi.management.OrganizationUserManagement;
import com.ibm.kpi.management.SectorManagement;
import com.ibm.kpi.utils.KPIUtils;
import com.ibm.portal.um.PumaLocator;

public class KPIContainerManager {

	public static void process(RenderRequest request, RenderResponse response, ResourceBundle bundle, KPIPortletSessionBean sessionBean) {
		Container container = sessionBean.getContainer().get(sessionBean.getCurrentPage());
		if (container == null) {
			container = new Container();
		}
		if (KPIManagerPortlet.INDEX_PAGE.equals(sessionBean.getCurrentPage())) {
			processIndexPage(container, sessionBean);
		} else if (KPIManagerPortlet.ORGANIZATIONS_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			processOrganizationListPage(container, sessionBean);
		} else if (KPIManagerPortlet.ORGANIZATION_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
			processOrganizationFormPage(container, bundle, sessionBean);
		} else if (KPIManagerPortlet.ORGANIZATION_USERS_PAGE.equals(sessionBean.getCurrentPage())) {
			processOrganizationUsersPage(container, sessionBean);
		} else if (KPIManagerPortlet.ORGANIZATION_USER_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
			processOrganizationUserFormPage(container, bundle, sessionBean);
		} else if (KPIManagerPortlet.ORGANIZATION_USERS_MEMBER_PAGE.equals(sessionBean.getCurrentPage())) {
			processOrganizationUsersMemberPage(container, sessionBean);
		} else if (KPIManagerPortlet.SECTORS_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			processSectorListPage(container, sessionBean);
		} else if (KPIManagerPortlet.SECTOR_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
			processSectorFormPage(container, bundle, sessionBean);
		} else if (KPIManagerPortlet.INDICATORS_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			processIndicatorListPage(container, sessionBean);
		} else if (KPIManagerPortlet.INDICATOR_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
			processIndicatorFormPage(container, bundle, sessionBean);
		} else if (KPIManagerPortlet.INDICATOR_PREVIEW_PAGE.equals(sessionBean.getCurrentPage())) {
			processIndicatorPreviewPage(container, bundle, sessionBean);
		} else if (KPIManagerPortlet.INDICATOR_STATISTICS_PAGE.equals(sessionBean.getCurrentPage())) {
			processIndicatorStatisticsPage(request, container, sessionBean);
		} else if (KPIManagerPortlet.INDICATOR_USAGE_REPORT_PAGE.equals(sessionBean.getCurrentPage())) {
			processIndicatorUsageReportPage(request, container, bundle, sessionBean);
		} else if (KPIManagerPortlet.INDICATOR_VALUES_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			processIndicatorValueListPage(container, sessionBean);
		} else if (KPIManagerPortlet.INDICATOR_VALUE_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
			processIndicatorValueFormPage(container, bundle, sessionBean);
		}
	}

	private static void processIndexPage(Container container, KPIPortletSessionBean sessionBean) {
	}

	private static void processOrganizationListPage(Container container, KPIPortletSessionBean sessionBean) {
		int navigatorPage = container.getNavigatorPage();
		int totalPages = container.getNavigatorTotalPages();
		container.clearObject();
		OrganizationManagement organizationManagement = new OrganizationManagement();
		if (organizationManagement.loadAllKPIOrganizationsByFilter(container.getFilterType(), container.getFilterValue()) > 0) {
			KPIOrganization[] kpiOrganizations = organizationManagement.getKPIOrganizations();
			navigatorPage = KPIUtils.getCurrentPageNumber(kpiOrganizations.length, navigatorPage, KPIManagerPortlet.resultsPerPage);
			totalPages = KPIUtils.getTotalPages(kpiOrganizations.length, KPIManagerPortlet.resultsPerPage);
			ArrayList<Object> filteredKPIOrganizations = KPINavigatorManager.filterResults(kpiOrganizations, KPIManagerPortlet.resultsPerPage, navigatorPage);
			container.setResults((KPIOrganization[]) filteredKPIOrganizations.toArray(new KPIOrganization[filteredKPIOrganizations.size()]));
		} else {
			navigatorPage = 1;
			totalPages = 1;
		}
		container.setNavigatorPage(navigatorPage);
		container.setNavigatorTotalPages(totalPages);
		sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
	}

	private static void processOrganizationFormPage(Container container, ResourceBundle bundle, KPIPortletSessionBean sessionBean) {
		if (container == null)
			container = new Container();
		container.setObject(null);
		String ordanizationId = container.getId();
		if (ordanizationId != null && ordanizationId.trim().length() > 0) {
			OrganizationManagement organizationManagement = new OrganizationManagement();
			if (organizationManagement.loadKPIOrganizationById(ordanizationId, null) == 1) {
				container.setObject(organizationManagement.getCurrentKPIOrganization());
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("organization.with.id.not.found" + " " + ordanizationId)));
				sessionBean.setCurrentPage(KPIManagerPortlet.ORGANIZATIONS_LIST_PAGE);
			}
		}
		sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
	}

	private static void processOrganizationUsersPage(Container container, KPIPortletSessionBean sessionBean) {
		int navigatorPage = container.getNavigatorPage();
		int totalPages = container.getNavigatorTotalPages();
		container.clearObject();
		OrganizationUserManagement organizationUserManagement = new OrganizationUserManagement();
		if (organizationUserManagement.loadAllOrganizationUsersByFilter(container.getId(), container.getFilterType(), container.getFilterValue()) > 0) {
			KPIOrganizationUser[] kpiOrganizationUsers = organizationUserManagement.getKPIOrganizationUsers();
			navigatorPage = KPIUtils.getCurrentPageNumber(kpiOrganizationUsers.length, navigatorPage, KPIManagerPortlet.resultsPerPage);
			totalPages = KPIUtils.getTotalPages(kpiOrganizationUsers.length, KPIManagerPortlet.resultsPerPage);
			ArrayList<Object> filteredKPIOrganizationUsers = KPINavigatorManager.filterResults(kpiOrganizationUsers, KPIManagerPortlet.resultsPerPage, navigatorPage);
			container.setResults((KPIOrganizationUser[]) filteredKPIOrganizationUsers.toArray(new KPIOrganizationUser[filteredKPIOrganizationUsers.size()]));
		} else {
			navigatorPage = 1;
			totalPages = 1;
		}
		container.setNavigatorPage(navigatorPage);
		container.setNavigatorTotalPages(totalPages);
		sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
	}

	private static void processOrganizationUserFormPage(Container container, ResourceBundle bundle, KPIPortletSessionBean sessionBean) {
		if (container == null)
			container = new Container();
		container.setObject(null);
		String ordanizationUserId = container.getId();
		if (ordanizationUserId != null && ordanizationUserId.trim().length() > 0) {
			OrganizationUserManagement organizationUserManagement = new OrganizationUserManagement();
			if (organizationUserManagement.loadOrganizationUserById(ordanizationUserId, null) == 1) {
				container.setObject(organizationUserManagement.getCurrentOrganizationUser());
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("user.with.id.not.found" + " " + ordanizationUserId)));
				sessionBean.setCurrentPage(KPIManagerPortlet.ORGANIZATION_USERS_PAGE);
			}
		}
		sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
	}

	private static void processOrganizationUsersMemberPage(Container container, KPIPortletSessionBean sessionBean) {
		int navigatorPage = container.getNavigatorPage();
		int totalPages = container.getNavigatorTotalPages();
		container.clearObject();
		PumaLocator pumaLocator = KPIManagerPortlet.getPumaHome().getLocator();
		java.util.List<com.ibm.portal.um.User> userList = null;
		try {
			userList = pumaLocator.findUsersByQuery("(cn != 'wp')");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		if (userList != null && userList.size() > 0) {
			com.ibm.portal.um.User[] portalUsers = (com.ibm.portal.um.User[]) userList.toArray(new com.ibm.portal.um.User[userList.size()]);
			;
			navigatorPage = KPIUtils.getCurrentPageNumber(portalUsers.length, navigatorPage, KPIManagerPortlet.resultsPerPage);
			totalPages = KPIUtils.getTotalPages(portalUsers.length, KPIManagerPortlet.resultsPerPage);
			ArrayList<Object> filteredPortalUsers = KPINavigatorManager.filterResults(portalUsers, KPIManagerPortlet.resultsPerPage, navigatorPage);
			container.setResults((com.ibm.portal.um.User[]) filteredPortalUsers.toArray(new com.ibm.portal.um.User[filteredPortalUsers.size()]));
		} else {
			navigatorPage = 1;
			totalPages = 1;
		}
		container.setNavigatorPage(navigatorPage);
		container.setNavigatorTotalPages(totalPages);
		sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
	}

	private static void processSectorListPage(Container container, KPIPortletSessionBean sessionBean) {
		int navigatorPage = container.getNavigatorPage();
		int totalPages = container.getNavigatorTotalPages();
		container.clearObject();
		SectorManagement sectorManagement = new SectorManagement();
		if (sectorManagement.loadAllKPISectorsByFilter(container.getFilterType(), container.getFilterValue(), container.getFilterValue2()) > 0) {
			KPISector[] kpiSectors = sectorManagement.getKPISectors();
			navigatorPage = KPIUtils.getCurrentPageNumber(kpiSectors.length, navigatorPage, KPIManagerPortlet.resultsPerPage);
			totalPages = KPIUtils.getTotalPages(kpiSectors.length, KPIManagerPortlet.resultsPerPage);
			ArrayList<Object> filteredKPISectors = KPINavigatorManager.filterResults(kpiSectors, KPIManagerPortlet.resultsPerPage, navigatorPage);
			container.setResults((KPISector[]) filteredKPISectors.toArray(new KPISector[filteredKPISectors.size()]));
		} else {
			navigatorPage = 1;
			totalPages = 1;
		}
		container.setNavigatorPage(navigatorPage);
		container.setNavigatorTotalPages(totalPages);
		sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
	}

	private static void processSectorFormPage(Container container, ResourceBundle bundle, KPIPortletSessionBean sessionBean) {
		if (container == null)
			container = new Container();
		container.setObject(null);
		String sectorId = container.getId();
		if (sectorId != null && sectorId.trim().length() > 0) {
			SectorManagement sectorManagement = new SectorManagement();
			if (sectorManagement.loadKPISectorById(sectorId, null) == 1) {
				container.setObject(sectorManagement.getCurrentKPISector());
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("sector.with.id.not.found" + " " + sectorId)));
				sessionBean.setCurrentPage(KPIManagerPortlet.SECTORS_LIST_PAGE);
			}
		}
		sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
	}

	private static void processIndicatorListPage(Container container, KPIPortletSessionBean sessionBean) {
		int navigatorPage = container.getNavigatorPage();
		int totalPages = container.getNavigatorTotalPages();
		container.clearObject();
		IndicatorManagement indicatorManagement = new IndicatorManagement();
		KPIUtils.println("sectorId = " + container.getId());
		if (indicatorManagement.loadAllKPIIndicatorsByFilter(container.getId(), container.getFilterType(), container.getFilterValue(), container.getFilterValue2()) > 0) {
			KPIIndicator[] kpiIndicators = indicatorManagement.getKPIIndicators();
			navigatorPage = KPIUtils.getCurrentPageNumber(kpiIndicators.length, navigatorPage, KPIManagerPortlet.resultsPerPage);
			totalPages = KPIUtils.getTotalPages(kpiIndicators.length, KPIManagerPortlet.resultsPerPage);
			ArrayList<Object> filteredKPIIndicators = KPINavigatorManager.filterResults(kpiIndicators, KPIManagerPortlet.resultsPerPage, navigatorPage);
			container.setResults((KPIIndicator[]) filteredKPIIndicators.toArray(new KPIIndicator[filteredKPIIndicators.size()]));
			HashMap<String, String> organizationNameById = new HashMap<String, String>();
			HashMap<String, KPIOrganizationUser> userById = new HashMap<String, KPIOrganizationUser>();
			OrganizationManagement organizationManagement = new OrganizationManagement();
			if (organizationManagement.loadAllKPIOrganizations() > 0) {
				for (int i = 0; i < organizationManagement.getKPIOrganizations().length; i++) {
					organizationNameById.put(organizationManagement.getKPIOrganizations()[i].getId(), organizationManagement.getKPIOrganizations()[i].getOrganizationName());
				}
			}
			OrganizationUserManagement organizationUserManagement = new OrganizationUserManagement();
			if (organizationUserManagement.loadAllOrganizationUsers() > 0) {
				for (int i = 0; i < organizationUserManagement.getKPIOrganizationUsers().length; i++) {
					userById.put(organizationUserManagement.getKPIOrganizationUsers()[i].getId(), organizationUserManagement.getKPIOrganizationUsers()[i]);
				}
			}
			ArrayList<Object> data = new ArrayList<Object>();
			data.add(organizationNameById);
			data.add(userById);
			container.setData(data);
		} else {
			navigatorPage = 1;
			totalPages = 1;
		}
		container.setNavigatorPage(navigatorPage);
		container.setNavigatorTotalPages(totalPages);
		sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
	}

	private static void processIndicatorFormPage(Container container, ResourceBundle bundle, KPIPortletSessionBean sessionBean) {
		if (container == null)
			container = new Container();
		container.setObject(null);
		container.setData(null);
		String indicatorId = container.getId();
		if (indicatorId != null && indicatorId.trim().length() > 0) {
			IndicatorManagement indicatorManagement = new IndicatorManagement();
			if (indicatorManagement.loadKPIIndicatorWithSectorsById(indicatorId, null) == 1) {
				container.setObject(indicatorManagement.getCurrentKPIIndicator());
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("indicator.with.id.not.found" + " " + indicatorId)));
				sessionBean.setCurrentPage(KPIManagerPortlet.INDICATORS_LIST_PAGE);
			}
		}
		if (sessionBean.getCurrentPage().equals(KPIManagerPortlet.INDICATOR_FORM_PAGE)) { // LOAD ORGANIZATIONS, LOAD ORGANIZATION USERS...
			KPIOrganization[] organizations = null;
			KPIOrganizationUser[] organizationUsers = null;
			KPISector[] sectors = null;
			OrganizationManagement organizationManagement = new OrganizationManagement();
			if (KPIManagerPortlet.isAdmin) {
				if (organizationManagement.loadAllKPIOrganizations() > 0) {
					organizations = organizationManagement.getKPIOrganizations();
				}
			} else if (KPIManagerPortlet.isManager) {
				if (organizationManagement.loadKPIOrganizationById(KPIManagerPortlet.currentUserOrganizationId, null) > 0) {
					organizations = new KPIOrganization[] { organizationManagement.getCurrentKPIOrganization() };
				}
			}
			if (organizations != null && organizations.length > 0) { // LOAD ORGANIZATION USERS...
				OrganizationUserManagement organizationUserManagement = new OrganizationUserManagement();
				if (organizationUserManagement.loadAllOrganizationUsers() > 0) {
					organizationUsers = organizationUserManagement.getKPIOrganizationUsers();
				}
			}
			SectorManagement sectorManagement = new SectorManagement();
			if (sectorManagement.loadAllKPISectors() > 0) {
				sectors = sectorManagement.getKPISectors();
			}
			ArrayList<Object> data = new ArrayList<Object>();
			data.add(organizations);
			data.add(organizationUsers);
			data.add(sectors);
			container.setData(data);
		}
		sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
	}

	private static void processIndicatorPreviewPage(Container container, ResourceBundle bundle, KPIPortletSessionBean sessionBean) {
		if (container == null)
			container = new Container();
		container.setObject(null);
		container.setData(null);
		String indicatorId = container.getId();
		if (indicatorId != null && indicatorId.trim().length() > 0) {
			IndicatorManagement indicatorManagement = new IndicatorManagement();
			if (indicatorManagement.loadKPIIndicatorWithSectorsById(indicatorId, null) == 1) {
				KPIOrganization organization = null;
				KPIOrganizationUser organizationUser = null;
				KPISector[] sectors = null;
				OrganizationManagement organizationManagement = new OrganizationManagement();
				if (organizationManagement.loadKPIOrganizationById(indicatorManagement.getCurrentKPIIndicator().getKpiOrganizationId(), null) == 1) {
					organization = organizationManagement.getCurrentKPIOrganization();
					OrganizationUserManagement organizationUserManagement = new OrganizationUserManagement();
					if (organizationUserManagement.loadOrganizationUserById(indicatorManagement.getCurrentKPIIndicator().getResponsibleUserId(), null) == 1) {
						organizationUser = organizationUserManagement.getCurrentOrganizationUser();
					}
				}
				SectorManagement sectorManagement = new SectorManagement();
				if (sectorManagement.loadAllKPISectors() > 0) {
					sectors = sectorManagement.getKPISectors();
				}
				container.setObject(indicatorManagement.getCurrentKPIIndicator());
				ArrayList<Object> data = new ArrayList<Object>();
				data.add(organization);
				data.add(organizationUser);
				data.add(sectors);
				container.setData(data);
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("indicator.with.id.not.found" + " " + indicatorId)));
				sessionBean.setCurrentPage(KPIManagerPortlet.INDICATORS_LIST_PAGE);
			}
		}
		sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
	}

	private static void processIndicatorStatisticsPage(RenderRequest request, Container container, KPIPortletSessionBean sessionBean) {
		container.clearObject();
		String[] indicatorIds = request.getParameterValues("indicatorId");
		if (indicatorIds != null && indicatorIds.length > 0) {
			StringBuffer indIds = new StringBuffer();
			for (int i = 0; i < indicatorIds.length; i++) {
				if (indIds.toString().length() > 0) {
					indIds.append(",");
				}
				indIds.append(indicatorIds[i]);
			}
			IndicatorManagement indicatorManagement = new IndicatorManagement();
			if (indicatorManagement.loadAllKPIIndicatorsByIds(indIds.toString(), null) > 0) {
				IndicatorValueManagement indicatorValueManagement = new IndicatorValueManagement();
				if (indicatorValueManagement.loadAllKPIIndicatorValuesByIndicatorIds(indIds.toString(), null) > 0) {
					HashMap<String, ArrayList<KPIIndicatorValue>> tmpHm = new HashMap<String, ArrayList<KPIIndicatorValue>>();
					ArrayList<KPIIndicatorValue> tmpArr = null;
					ArrayList<String> targetDatesArr = new ArrayList<String>();
					String currentTargetDate = null;
					for (int i = 0; i < indicatorValueManagement.getKPIIndicatorValues().length; i++) {
						tmpArr = tmpHm.get(indicatorValueManagement.getKPIIndicatorValues()[i].getKpiIndicatorId());
						if (tmpArr == null) {
							tmpArr = new ArrayList<KPIIndicatorValue>();
						}
						tmpArr.add(indicatorValueManagement.getKPIIndicatorValues()[i]);
						tmpHm.put(indicatorValueManagement.getKPIIndicatorValues()[i].getKpiIndicatorId(), tmpArr);
						currentTargetDate = KPIUtils.timeMillisToYYYY_MM_DD(indicatorValueManagement.getKPIIndicatorValues()[i].getTargetDate().getTime());
						if (!targetDatesArr.contains(currentTargetDate)) {
							targetDatesArr.add(currentTargetDate);
						}
					}
					for (int i = 0; i < indicatorManagement.getKPIIndicators().length; i++) {
						tmpArr = tmpHm.get(indicatorManagement.getKPIIndicators()[i].getId());
						if (tmpArr != null && tmpArr.size() > 0) {
							indicatorManagement.getKPIIndicators()[i].setIndicatorValues((KPIIndicatorValue[]) tmpArr.toArray(new KPIIndicatorValue[tmpArr.size()]));
						}
					}
					ArrayList<KPIIndicator> tmpIndicators = new ArrayList<KPIIndicator>();
					for (int i = 0; i < indicatorManagement.getKPIIndicators().length; i++) {
						if (indicatorManagement.getKPIIndicators()[i].getIndicatorValues() != null && indicatorManagement.getKPIIndicators()[i].getIndicatorValues().length > 0) {
							tmpIndicators.add(indicatorManagement.getKPIIndicators()[i]);
						}
					}
					indicatorManagement.setKPIIndicators((KPIIndicator[]) tmpIndicators.toArray(new KPIIndicator[tmpIndicators.size()]));
					container.setResults(prepareForStatistics(indicatorManagement.getKPIIndicators(), targetDatesArr));
					ArrayList<Object> data = new ArrayList<Object>();
					data.add(targetDatesArr);
					container.setData(data);
				}
			}
		}
		sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
	}

	private static void processIndicatorUsageReportPage(RenderRequest request, Container container, ResourceBundle bundle, KPIPortletSessionBean sessionBean) {
		container.clearObject();
		String[] indicatorIds = request.getParameterValues("indicatorId");
		if (indicatorIds != null && indicatorIds.length > 0) {
			StringBuffer indIds = new StringBuffer();
			for (int i = 0; i < indicatorIds.length; i++) {
				if (indIds.toString().length() > 0) {
					indIds.append(",");
				}
				indIds.append(indicatorIds[i]);
			}
			IndicatorManagement indicatorManagement = new IndicatorManagement();
			if (indicatorManagement.loadAllKPIIndicatorsByIds(indIds.toString(), null) > 0) {
				container.setResults(indicatorManagement.getKPIIndicators());
				HashMap<String, ArrayList<KPIIndicatorHit>> indicatorHitsByIndicatorId = new HashMap<String, ArrayList<KPIIndicatorHit>>();
				// LOAD INDICATORHITS...
				IndicatorHitManagement indicatorHitManagement = new IndicatorHitManagement();
				if (indicatorHitManagement.loadAllKPIIndicatorHitsByFilter(indIds.toString(), container.getFilterValue(), container.getFilterValue2()) > 0) {
					ArrayList<KPIIndicatorHit> tmpArr = null;
					for (int i = 0; i < indicatorHitManagement.getKPIIndicatorHits().length; i++) {
						tmpArr = indicatorHitsByIndicatorId.get(indicatorHitManagement.getKPIIndicatorHits()[i].getKpiIndicatorId());
						if (tmpArr == null) {
							tmpArr = new ArrayList<KPIIndicatorHit>();
						}
						tmpArr.add(indicatorHitManagement.getKPIIndicatorHits()[i]);
						indicatorHitsByIndicatorId.put(indicatorHitManagement.getKPIIndicatorHits()[i].getKpiIndicatorId(), tmpArr);
					}
				}
				container.setObject(indicatorHitsByIndicatorId);
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("indicators.not.found")));
				sessionBean.setCurrentPage(KPIManagerPortlet.INDICATORS_LIST_PAGE);
				return;
			}
		} else {
			sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("invalid.parameters")));
			sessionBean.setCurrentPage(KPIManagerPortlet.INDICATORS_LIST_PAGE);
			return;
		}
		sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
	}

	private static void processIndicatorValueListPage(Container container, KPIPortletSessionBean sessionBean) {
		int navigatorPage = container.getNavigatorPage();
		int totalPages = container.getNavigatorTotalPages();
		container.clearObject();
		String kpiIndicatorId = container.getId();
		IndicatorValueManagement indicatorValueManagement = new IndicatorValueManagement();
		if (indicatorValueManagement.loadAllKPIIndicatorValuesByFilter(kpiIndicatorId, container.getFilterType(), container.getFilterValue(), container.getFilterValue2()) > 0) {
			KPIIndicatorValue[] kpiIndicatorValues = indicatorValueManagement.getKPIIndicatorValues();
			navigatorPage = KPIUtils.getCurrentPageNumber(kpiIndicatorValues.length, navigatorPage, KPIManagerPortlet.resultsPerPage);
			totalPages = KPIUtils.getTotalPages(kpiIndicatorValues.length, KPIManagerPortlet.resultsPerPage);
			ArrayList<Object> filteredKPIIndicatorValues = KPINavigatorManager.filterResults(kpiIndicatorValues, KPIManagerPortlet.resultsPerPage, navigatorPage);
			container.setResults((KPIIndicatorValue[]) filteredKPIIndicatorValues.toArray(new KPIIndicatorValue[filteredKPIIndicatorValues.size()]));
		} else {
			navigatorPage = 1;
			totalPages = 1;
		}
		container.setNavigatorPage(navigatorPage);
		container.setNavigatorTotalPages(totalPages);
		sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
	}

	private static void processIndicatorValueFormPage(Container container, ResourceBundle bundle, KPIPortletSessionBean sessionBean) {
		if (container == null) {
			container = new Container();
		}
		container.setObject(null);
		container.setData(null);
		String indicatorValueId = container.getId();
		Container indicatorContainer = sessionBean.getContainer().get(KPIManagerPortlet.INDICATOR_VALUES_LIST_PAGE);
		String indicatorId = indicatorContainer.getId();
		KPIIndicator indicator = null;
		try {
			indicator = KPIIndicator.findById(indicatorId, null);
			if (indicator != null) {
				ArrayList<Object> data = new ArrayList<Object>();
				data.add(indicator);
				container.setData(data);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (indicatorValueId != null && indicatorValueId.trim().length() > 0) {
			IndicatorValueManagement indicatorValueManagement = new IndicatorValueManagement();
			if (indicatorValueManagement.loadKPIIndicatorValueWithAttachmentsById(indicatorValueId, null) == 1) {
				container.setObject(indicatorValueManagement.getCurrentKPIIndicatorValue());
			} else {
				container.setData(null);
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("indicator.value.with.id.not.found") + " " + indicatorValueId));
				sessionBean.setCurrentPage(KPIManagerPortlet.INDICATOR_VALUES_LIST_PAGE);
			}
		}
		sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
	}

	private static KPIIndicator[] prepareForStatistics(KPIIndicator[] indicators, ArrayList<String> targetDatesArr) {
		if (indicators != null && targetDatesArr != null && targetDatesArr.size() > 0) {
			KPIIndicator indicator = null;
			KPIIndicatorValue indicatorValue = null;
			KPIIndicatorValue tmpIndicatorValue = null;
			KPIIndicatorValue[] indicatorValues = null;
			HashMap<String, ArrayList<Object>> tmpHm = null;
			ArrayList<Object> tmpArr = null;
			ArrayList<KPIIndicatorValue> indicatorValuesArr = null;
			int index = 0;
			for (int i = 0; i < indicators.length; i++) {
				indicator = indicators[i];
				indicatorValues = indicator.getIndicatorValues();
				if (indicatorValues != null && indicatorValues.length > 0) {
					tmpHm = new HashMap<String, ArrayList<Object>>();
					for (int j = 0; j < indicatorValues.length; j++) {
						tmpArr = new ArrayList<Object>();
						tmpArr.add(j);
						tmpArr.add(indicatorValues[j]);
						tmpHm.put(KPIUtils.timeMillisToYYYY_MM_DD(indicatorValues[j].getTargetDate().getTime()), tmpArr);
					}
					indicatorValuesArr = new ArrayList<KPIIndicatorValue>();
					index = 0;
					for (int j = 0; j < targetDatesArr.size(); j++) {
						indicatorValue = null;
						if (tmpHm.get(targetDatesArr.get(j)) != null) { // DATE MATCH...
							tmpArr = tmpHm.get(targetDatesArr.get(j));
							indicatorValue = (KPIIndicatorValue) tmpArr.get(1);
							indicatorValuesArr.add(indicatorValue);
							index = (Integer) tmpArr.get(0);
						} else { // DATE NOT MATCH...
							if (KPIUtils.date_yyyy_MM_dd_ToTimeMillis(targetDatesArr.get(j), true) < indicatorValues[0].getTargetDate().getTime()) {
								indicatorValue = indicatorValues[index];
							} else {
								indicatorValue = (indicatorValuesArr.size() > 0) ? indicatorValuesArr.get(indicatorValuesArr.size() - 1) : indicatorValues[0];
							}
							tmpIndicatorValue = new KPIIndicatorValue();
							tmpIndicatorValue.setId(indicatorValue.getId());
							tmpIndicatorValue.setKpiIndicatorId(indicatorValue.getKpiIndicatorId());
							tmpIndicatorValue.setValue(indicatorValue.getValue());
							tmpIndicatorValue.setComments(indicatorValue.getComments());
							tmpIndicatorValue.setTargetDate(KPIUtils.timeMillisToTimestamp(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(targetDatesArr.get(j), true)));
							tmpIndicatorValue.setUserDN(indicatorValue.getUserDN());
							tmpIndicatorValue.setCreationDate(KPIUtils.timeMillisToTimestamp(indicatorValue.getCreationDate().getTime()));
							indicatorValuesArr.add(tmpIndicatorValue);
						}
					}
					indicators[i].setIndicatorValues((KPIIndicatorValue[]) indicatorValuesArr.toArray(new KPIIndicatorValue[indicatorValuesArr.size()]));
				}
			}
		}
		return indicators;
	}
}
