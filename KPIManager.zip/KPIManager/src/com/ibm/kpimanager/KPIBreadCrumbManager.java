package com.ibm.kpimanager;

import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import com.ibm.kpi.bean.BreadCrumbNode;
import com.ibm.kpi.bean.Container;
import com.ibm.kpi.management.IndicatorManagement;
import com.ibm.kpi.management.OrganizationManagement;
import com.ibm.kpi.management.SectorManagement;
import com.ibm.kpi.utils.KPIUtils;

public class KPIBreadCrumbManager {
	
	public static void buildBreadCrumb(RenderRequest request, RenderResponse response, ResourceBundle bundle, KPIPortletSessionBean sessionBean) {
		ArrayList<BreadCrumbNode> breadCrumb = new ArrayList<BreadCrumbNode>();				
		if (KPIManagerPortlet.isManager) {
			breadCrumb.add(getNode(response, bundle.getString("breadcrumb.root"), KPIManagerPortlet.INDEX_PAGE, null, null));
		}
		if (KPIManagerPortlet.ORGANIZATIONS_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			breadCrumb.add(getNode(response, bundle.getString("breadcrumb.organizations"), KPIManagerPortlet.ORGANIZATIONS_LIST_PAGE, null, null));
		} else if (KPIManagerPortlet.SECTORS_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			breadCrumb.add(getNode(response, bundle.getString("breadcrumb.sectors"), KPIManagerPortlet.SECTORS_LIST_PAGE, null, null));
		} else if (KPIManagerPortlet.INDICATORS_LIST_PAGE.equals(sessionBean.getCurrentPage()) || KPIManagerPortlet.INDICATOR_VALUES_LIST_PAGE.equals(sessionBean.getCurrentPage()) || KPIManagerPortlet.INDICATOR_STATISTICS_PAGE.equals(sessionBean.getCurrentPage()) || KPIManagerPortlet.INDICATOR_USAGE_REPORT_PAGE.equals(sessionBean.getCurrentPage())) {
			Container container = sessionBean.getContainer().get(KPIManagerPortlet.INDICATORS_LIST_PAGE);
			String sectorId = null;
			if (container != null && container.getId() != null) { // LOAD SECTOR
				SectorManagement sectorManagement = new SectorManagement();
				if (sectorManagement.loadKPISectorById(container.getId(), null) == 1) {
					sectorId = container.getId();
					ArrayList<String> extraParametersNames = new ArrayList<String>();
					ArrayList<String> extraParametersValues = new ArrayList<String>();
					extraParametersNames.add(KPIManagerPortlet.PARAMETER_ID);
					extraParametersValues.add(container.getId());
					breadCrumb.add(getNode(response, sectorManagement.getCurrentKPISector().getSectorName(), KPIManagerPortlet.SECTORS_LIST_PAGE, extraParametersNames, extraParametersValues));
				}
			}	
			if (KPIManagerPortlet.INDICATOR_STATISTICS_PAGE.equals(sessionBean.getCurrentPage())) {
				if (sectorId != null && sectorId.trim().length() > 0) {
					ArrayList<String> extraParametersNames = new ArrayList<String>();
					ArrayList<String> extraParametersValues = new ArrayList<String>();
					extraParametersNames.add(KPIManagerPortlet.PARAMETER_ID);
					extraParametersValues.add(sectorId);
					breadCrumb.add(getNode(response, bundle.getString("breadcrumb.indicators"), KPIManagerPortlet.INDICATORS_LIST_PAGE, extraParametersNames, extraParametersValues));
				} else {
					breadCrumb.add(getNode(response, bundle.getString("breadcrumb.indicators"), KPIManagerPortlet.INDICATORS_LIST_PAGE, null, null));
				}
				breadCrumb.add(getNode(response, bundle.getString("breadcrumb.graphic"), KPIManagerPortlet.INDICATOR_STATISTICS_PAGE, null, null));
			} else if (KPIManagerPortlet.INDICATOR_USAGE_REPORT_PAGE.equals(sessionBean.getCurrentPage())) {
				if (sectorId != null && sectorId.trim().length() > 0) {
					ArrayList<String> extraParametersNames = new ArrayList<String>();
					ArrayList<String> extraParametersValues = new ArrayList<String>();
					extraParametersNames.add(KPIManagerPortlet.PARAMETER_ID);
					extraParametersValues.add(sectorId);
					breadCrumb.add(getNode(response, bundle.getString("breadcrumb.indicators"), KPIManagerPortlet.INDICATORS_LIST_PAGE, extraParametersNames, extraParametersValues));
				} else {
					breadCrumb.add(getNode(response, bundle.getString("breadcrumb.indicators"), KPIManagerPortlet.INDICATORS_LIST_PAGE, null, null));
				}
				breadCrumb.add(getNode(response, bundle.getString("breadcrumb.usage.report"), KPIManagerPortlet.INDICATOR_USAGE_REPORT_PAGE, null, null));				
			} else if (KPIManagerPortlet.INDICATOR_VALUES_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
				container = sessionBean.getContainer().get(KPIManagerPortlet.INDICATOR_VALUES_LIST_PAGE);
				if (container != null && container.getId() != null) { // LOAD INDICATOR
					IndicatorManagement indicatorManagement = new IndicatorManagement();
					if (indicatorManagement.loadKPIIndicatorById(container.getId(), null) == 1) {
						if (sectorId != null && sectorId.trim().length() > 0) {
							ArrayList<String> extraParametersNames = new ArrayList<String>();
							ArrayList<String> extraParametersValues = new ArrayList<String>();
							extraParametersNames.add(KPIManagerPortlet.PARAMETER_ID);
							extraParametersValues.add(sectorId);
							breadCrumb.add(getNode(response, indicatorManagement.getCurrentKPIIndicator().getIndicatorName(), KPIManagerPortlet.INDICATORS_LIST_PAGE, extraParametersNames, extraParametersValues));
						} else {
							breadCrumb.add(getNode(response, indicatorManagement.getCurrentKPIIndicator().getIndicatorName(), KPIManagerPortlet.INDICATORS_LIST_PAGE, null, null));
						}
					} else {
						breadCrumb.add(getNode(response, bundle.getString("breadcrumb.indicators"), KPIManagerPortlet.INDICATORS_LIST_PAGE, null, null));
					}
				}					
				breadCrumb.add(getNode(response, bundle.getString("breadcrumb.indicator.values"), KPIManagerPortlet.INDICATOR_VALUES_LIST_PAGE, null, null));
			} else { 
				breadCrumb.add(getNode(response, bundle.getString("breadcrumb.indicators"), KPIManagerPortlet.INDICATORS_LIST_PAGE, null, null));
			}
		} else if (KPIManagerPortlet.ORGANIZATION_USERS_PAGE.equals(sessionBean.getCurrentPage()) || KPIManagerPortlet.ORGANIZATION_USERS_MEMBER_PAGE.equals(sessionBean.getCurrentPage())) {
			breadCrumb.add(getNode(response, bundle.getString("breadcrumb.organizations"), KPIManagerPortlet.ORGANIZATIONS_LIST_PAGE, null, null));
			Container container = sessionBean.getContainer().get(KPIManagerPortlet.ORGANIZATION_USERS_PAGE);
			if (container != null && container.getId() != null) {
				KPIUtils.println("ID = " + container.getId() + " PAGE " + sessionBean.getCurrentPage());
				OrganizationManagement organizationManagement = new OrganizationManagement();
				if (organizationManagement.loadKPIOrganizationById(container.getId(), null) == 1) {
					ArrayList<String> extraParametersNames = null;
					ArrayList<String> extraParametersValues = null;
					if (KPIManagerPortlet.ORGANIZATION_USERS_MEMBER_PAGE.equals(sessionBean.getCurrentPage())) {
						extraParametersNames = new ArrayList<String>();
						extraParametersValues = new ArrayList<String>();
						extraParametersNames.add(KPIManagerPortlet.PARAMETER_ID);
						extraParametersValues.add(container.getId());
					}
					breadCrumb.add(getNode(response, organizationManagement.getCurrentKPIOrganization().getOrganizationName(), KPIManagerPortlet.ORGANIZATION_USERS_PAGE, extraParametersNames, extraParametersValues));
					if (KPIManagerPortlet.ORGANIZATION_USERS_MEMBER_PAGE.equals(sessionBean.getCurrentPage())) {
						breadCrumb.add(getNode(response, bundle.getString("breadcrumb.organization.users.add.member"), KPIManagerPortlet.ORGANIZATION_USERS_PAGE, null, null));
					}
				}
			} else {			
				breadCrumb.add(getNode(response, bundle.getString("breadcrumb.organization.users"), KPIManagerPortlet.ORGANIZATION_USERS_PAGE, null, null));
			}
		}
		sessionBean.setBreadCrumb(breadCrumb);
	}

	private static BreadCrumbNode getNode(RenderResponse response, String nodeName, String nodePage, ArrayList<String> extraParametersNames, ArrayList<String> extraParametersValues) {
		BreadCrumbNode breadCrumbNode = new BreadCrumbNode();		
		breadCrumbNode.setName(nodeName);
		PortletURL breadCrumbActionUrl = response.createActionURL(); 
		breadCrumbActionUrl.setParameter(KPIManagerPortlet.PARAMETER_ACTION, KPIManagerPortlet.ACTION_NAVIGATE_TO_PAGE);
		breadCrumbActionUrl.setParameter(KPIManagerPortlet.PARAMETER_VALUE, nodePage);
		breadCrumbActionUrl.setParameter(KPIManagerPortlet.PARAMETER_SOURCE, KPIManagerPortlet.SOURCE_BREADCRUMB);
		if (extraParametersNames != null && extraParametersValues != null && extraParametersNames.size() == extraParametersValues.size()) {
			for (int i = 0; i < extraParametersNames.size(); i++) {
				breadCrumbActionUrl.setParameter(extraParametersNames.get(i), extraParametersValues.get(i));
			}
		}
		breadCrumbNode.setUrl(breadCrumbActionUrl.toString());
		return breadCrumbNode;
	}
	
}
