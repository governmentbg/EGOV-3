package com.ibm.kpimanager;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Locale;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.GenericPortlet;
import javax.portlet.PortletException;
import javax.portlet.PortletMode;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequest;
import javax.portlet.PortletRequestDispatcher;
import javax.portlet.PortletSession;
import javax.portlet.ReadOnlyException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.portlet.ValidatorException;
import javax.portlet.WindowState;

import org.apache.commons.fileupload.portlet.PortletFileUpload;

import com.ibm.kpi.bean.Container;
import com.ibm.kpi.bean.Message;
import com.ibm.kpi.db.DBPool;
import com.ibm.kpi.db.DBResources;
import com.ibm.kpi.management.AttachmentManagement;
import com.ibm.kpi.management.OrganizationUserManagement;
import com.ibm.kpi.utils.KPIUtils;
import com.ibm.portal.um.PumaHome;
import com.ibm.portal.um.PumaProfile;
import com.ibm.portal.um.exceptions.PumaException;
   
public class KPIManagerPortlet extends GenericPortlet {

	public static final String JSP_FOLDER = "/_KPIManager/jsp/"; // JSP folder name
  
	public static final String INDEX_PAGE = "index";
	public static final String ORGANIZATIONS_LIST_PAGE = "organizations";
	public static final String ORGANIZATION_FORM_PAGE = "organizationForm";
	public static final String ORGANIZATION_USERS_PAGE = "organizationUsers";
	public static final String ORGANIZATION_USER_FORM_PAGE = "organizationUserForm";
	public static final String ORGANIZATION_USERS_MEMBER_PAGE = "organizationUsersMember";
	public static final String SECTORS_LIST_PAGE = "sectors";
	public static final String SECTOR_FORM_PAGE = "sectorForm";
	public static final String INDICATORS_LIST_PAGE = "indicators";
	public static final String INDICATOR_FORM_PAGE = "indicatorForm";
	public static final String INDICATOR_PREVIEW_PAGE = "indicatorPreview";
	public static final String INDICATOR_STATISTICS_PAGE = "indicatorStatistics";
	public static final String INDICATOR_USAGE_REPORT_PAGE = "indicatorUsageReport";
	public static final String INDICATOR_VALUES_LIST_PAGE = "indicatorValues";
	public static final String INDICATOR_VALUE_FORM_PAGE = "indicatorValueForm";
	public static final String ERROR_PAGE = "errorPage";

	public static final String CONFIG_JSP = "KPIManagerPortletConfig"; // JSP file name to be rendered on the configure mode
	public static final String EDIT_DEFAULTS_JSP = "KPIManagerPortletEditDefaults"; // JSP file name to be rendered on the configure mode

	public static final String PARAMETER_SOURCE = "source";
	public static final String PARAMETER_ACTION = "action";
	public static final String PARAMETER_VALUE = "value";
	public static final String PARAMETER_ID = "id";
	public static final String PARAMETER_OPERATION = "operation";

	public static final String ACTION_NAVIGATE_TO_PAGE = "changePage";
	public static final String ACTION_NAVIGATOR = "navigator";
	public static final String ACTION_CHANGE_SEARCH_CRITERIA = "searchCriteria";
	public static final String ACTION_NEW = "new";
	public static final String ACTION_ADD = "add";
	public static final String ACTION_EDIT = "edit";
	public static final String ACTION_DELETE = "delete";
	public static final String ACTION_UPLOAD = "upload";

	public static final String SOURCE_BREADCRUMB = "breadcrumb";

	public static final String NAVIGATOR_OPERATION_FIRST = "1";
	public static final String NAVIGATOR_OPERATION_PREVIOUS = "2";
	public static final String NAVIGATOR_OPERATION_NEXT = "3";
	public static final String NAVIGATOR_OPERATION_LAST = "4";
	public static final String NAVIGATOR_OPERATION_GOTO = "5";

	public static final String SESSION_BEAN = "KPIPortletSessionBean"; // Bean name for the portlet session
	public static final String MESSAGE = "KPIMessage";
	public static final String MESSAGE_TYPE = "KPIMessageType";
	public static final String CONFIG_SUBMIT = "KPIManagerPortletConfigSubmit"; // Action name for submit form
	public static final String CONFIG_CANCEL = "KPIManagerPortletConfigCancel"; // Parameter name for the text input
	public static final String EDIT_DEFAULTS_SUBMIT = "KPIManagerPortletEditDefaultsSubmit"; // Action name for submit form
	public static final String EDIT_DEFAULTS_CANCEL = "KPIManagerPortletEditDefaultsCancel"; // Action name for submit form
	
	public static final String SETTING_PARAMETER_ADMIN_GROUP_NAME = "wps.admin.group.name";
	public static final String SETTING_PARAMETER_RESULTS_PER_PAGE = "wps.results.per.page";
	public static final String SETTING_PARAMETER_MAX_ITEMS = "wps.max.items";
	public static final String SETTING_PARAMETER_LANGUAGE = "wps.kpi.language";
	public static final String SETTING_PARAMETER_DEBUG = "wps.kpi.debug";

	public static final String GLOBAL_ADMIN_GROUP_CN = "*";

	public static String maxItems = null;
	public static String adminGroupName = null;
	// public static String usersGroupName = null;
	public static int resultsPerPage = 10;
	public static String language = KPIConstants.LANGUAGE_BG;
	public static boolean debug = false;
	public static com.ibm.portal.um.Group adminGroup = null;
	// public static com.ibm.portal.um.Group usersGroup = null;
	public static boolean preferencesLoaded = false;
	public static boolean groupsLoaded = false;
	private static PumaHome pumaHome = null;
	public static boolean userLoggedIn = false;
	public static boolean isAdmin = false;
	public static boolean isManager = false;
	public static boolean isUser = false;
	public static com.ibm.portal.um.User currentUser = null;
	public static String currentUserDN = null;
	public static String currentUserOrganizationId = null;
	public static String currentUserOrganizationUserId = null;

	private static final PortletMode CUSTOM_CONFIG_MODE = new PortletMode("config");
	private static final PortletMode CUSTOM_EDIT_DEFAULTS_MODE = new PortletMode("edit_defaults");

	public void init() throws PortletException {
		super.init();
		InitialContext initialcontext;
		try {
			initialcontext = new InitialContext();
			try {
				initialcontext.lookup("portletservice/com.ibm.portal.state.service.PortletStateManagerService");
			} catch (Exception exception) {
				System.out.println(exception.getMessage());
				exception.printStackTrace();
			}
		} catch (NamingException e) {
			System.out.println(e.getMessage());
		}
		try {
			initialcontext = new InitialContext();
			pumaHome = (PumaHome) initialcontext.lookup("portal:service/usermanagement/Puma");
		} catch (NamingException namingexception) {
			namingexception.printStackTrace();
		}
		String realPath = getPortletContext().getRealPath("/");
		if (DBResources.loadProps(realPath)) {
			System.out.print("------ APPLICATION STARTED NORMALLY: [ OK ]");
		}
	}

	public void doView(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		KPIUtils.println("|VIEW| userLoggedIn = " + userLoggedIn);
		// Set the MIME type for the render response
		response.setContentType(request.getResponseContentType());

		// Check if portlet session exists
		KPIPortletSessionBean sessionBean = getSessionBean(request);
		if (sessionBean == null) {
			response.getWriter().println("<b>NO PORTLET SESSION YET</b>");
			return;
		}

		PortletRequestDispatcher rd = null;
		//KPIUtils.loadPreferences(request);
		Locale locale = new Locale(language);
		if (!preferencesLoaded) {
			if (sessionBean.getMessage() == null) {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_WARNING, getPortletConfig().getResourceBundle(locale).getString("please.configure.portlet")));
			}
			rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, ERROR_PAGE));
		} else {
			if (!groupsLoaded) {
				KPIUtils.loadAdminGroup();
				// KPIUtils.loadUsersGroup();
				// if (KPIManagerPortlet.adminGroup == null || KPIManagerPortlet.usersGroup == null) {
				if (KPIManagerPortlet.adminGroup == null) {
					if (KPIManagerPortlet.adminGroup == null) {
						sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("group.not.found") + " " + adminGroupName + "!"));
					} // else {
						// sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("group.not.found") + " " + usersGroupName + "!"));
					// }
					rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, ERROR_PAGE));
					rd.include(request, response);
					return;
				}
			}
			isAdmin = false;
			isManager = false;
			isUser = false;
			if (userLoggedIn) {
				isUser = true;
				ArrayList<String> membership = KPIUtils.getUserGroupMembership(currentUser);
				if (membership != null && (membership.contains(GLOBAL_ADMIN_GROUP_CN) || membership.contains(KPIManagerPortlet.adminGroupName))) {
					isManager = true;
					isAdmin = true;
				} else {
					OrganizationUserManagement organizationUserManagement = new OrganizationUserManagement();
					if (organizationUserManagement.loadOrganizationUserByDN(currentUserDN, null) == 1) {
						if (KPIConstants.USER_ROLE_MANAGER.equals(organizationUserManagement.getCurrentOrganizationUser().getUserType())) {
							currentUserOrganizationId = organizationUserManagement.getCurrentOrganizationUser().getKpiOrganizationId();
							isManager = true;
						}
						currentUserOrganizationUserId = organizationUserManagement.getCurrentOrganizationUser().getId();
					} else {
						// CURRENT USER DOES NOT HAVE PERMISSIONS...
						sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("no.permissions")));
						rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, ERROR_PAGE));
						rd.include(request, response);
						return;
					}
				}
			}
			if (!isManager && sessionBean.getCurrentPage().equals(INDEX_PAGE)) {
				sessionBean.setCurrentPage(INDICATORS_LIST_PAGE);
			}
			// KPIUtils.removeUserFromGroup(currentUser, adminGroup);
			// KPIUtils.addUserToGroup(currentUser, adminGroup);
			// Invoke the JSP to render
			KPIUtils.println("isAdmin -> " + isAdmin + " | VIEW -> " + sessionBean.getCurrentPage());
			KPIContainerManager.process(request, response, getPortletConfig().getResourceBundle(locale), sessionBean);
			KPIBreadCrumbManager.buildBreadCrumb(request, response, getPortletConfig().getResourceBundle(locale), sessionBean);
			KPINavigatorManager.buildNavigator(request, response, getPortletConfig().getResourceBundle(locale), sessionBean);
			populateRequest(request, sessionBean);
			rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, sessionBean.getCurrentPage()));
		}
		rd.include(request, response);
	}

	protected void doDispatch(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		if (!WindowState.MINIMIZED.equals(request.getWindowState())) {
			KPIUtils.println("|DISPATCH|");
			Locale locale = new Locale(language);
			KPIUtils.loadPreferences(request, getPortletConfig().getResourceBundle(locale));
			userLoggedIn = false; 
			if (getPumaHome() != null) {
				com.ibm.portal.um.PumaProfile pumaProfile = getPumaHome().getProfile();
				if (pumaProfile != null) {
					try {
						com.ibm.portal.um.User user = pumaProfile.getCurrentUser();
						if (user != null) {
							// System.out.println("userID = " + KPIUtils.getStringObjectID(user.getObjectID()));
							userLoggedIn = true;
							currentUser = user;
							currentUserDN = pumaProfile.getIdentifier(user);
							KPIUtils.println("userDN = " + currentUserDN);
							// KPIUtils.printUserAttributes(user, pumaProfile);
							// User tmpUser = KPIUtils.findUserByDN(currentUserDN, pumaHome);
						}
					} catch (PumaException e) {
						System.out.println(e.getMessage());
						e.printStackTrace();
					}
				}
			}
			PortletMode mode = request.getPortletMode();
			if (CUSTOM_CONFIG_MODE.equals(mode)) {
				doCustomConfigure(request, response);
				return;
			} else if (CUSTOM_EDIT_DEFAULTS_MODE.equals(mode)) {
				doCustomEditDefaults(request, response);
				return;
			}
		}
		super.doDispatch(request, response);
	}

	public void processAction(ActionRequest request, ActionResponse response) throws PortletException, java.io.IOException {
		String action = request.getParameter(PARAMETER_ACTION);
		String value = request.getParameter(PARAMETER_VALUE);
		String id = request.getParameter(PARAMETER_ID);
		KPIPortletSessionBean sessionBean = getSessionBean(request);
		sessionBean.setMessage(null);
		Container container = sessionBean.getContainer().get(sessionBean.getCurrentPage());
		if (container == null) {
			container = new Container();
		}
		Locale locale = new Locale(language);
		KPIActionManager kpiActionManager = new KPIActionManager();

		KPIUtils.println("currentPage = " + sessionBean.getCurrentPage());
		// Check that we have a file upload request
		boolean isMultipart = PortletFileUpload.isMultipartContent(request);
		if (isMultipart) {
			if (INDICATOR_VALUE_FORM_PAGE.equals(sessionBean.getCurrentPage())) {
				if (container.getId() != null && container.getId().trim().length() > 0) {
					action = ACTION_EDIT;
				} else {
					action = ACTION_ADD;
				}
			} else if (INDICATOR_VALUES_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
				action = ACTION_UPLOAD;
			}
		}

		KPIUtils.println("action = " + action);
		KPIUtils.println("value = " + value);
		// SET PARAMETERS TO BE VISIBILE FOR doView()...
		response.setRenderParameters(request.getParameterMap());
		if (ACTION_NAVIGATE_TO_PAGE.equals(action)) {
			sessionBean.setCurrentPage(value);
			container = sessionBean.getContainer().get(value);
			if (container == null) {
				container = new Container();
			}
			if (id != null && id.trim().length() > 0) {
				container.setId(id.trim());
			} else {
				container.setId(null);
			}
			sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
		} else if (ACTION_NAVIGATOR.equals(action)) {
			kpiActionManager.processNavigator(sessionBean, request);
		} else if (ACTION_CHANGE_SEARCH_CRITERIA.equals(action)) {
			container.setFilterCriteria(request.getParameter("filterCriteria"));
			container.setFilterType(request.getParameter("filterType"));
			container.setFilterValue(request.getParameter("filterValue"));
			container.setFilterValue2(request.getParameter("filterValue2"));
			container.setNavigatorPage(1);
			container.setNavigatorTotalPages(1);
			String source = request.getParameter(PARAMETER_SOURCE);
			if (INDEX_PAGE.equals(source)) {
				if (container.getFilterCriteria() == null || "0".equals(container.getFilterCriteria())) { // ORGANIZATIONS
					sessionBean.setCurrentPage(ORGANIZATIONS_LIST_PAGE);
				} else if ("1".equals(container.getFilterCriteria())) { // SECTORS
					sessionBean.setCurrentPage(SECTORS_LIST_PAGE);
				} else if ("2".equals(container.getFilterCriteria())) { // INDICATORS
					sessionBean.setCurrentPage(INDICATORS_LIST_PAGE);
				}
			}
			sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
		} else if (ACTION_DELETE.equals(action)) {
			kpiActionManager.processDelete(sessionBean, request, getPortletConfig().getResourceBundle(locale));
		} else if (ACTION_ADD.equals(action)) {
			kpiActionManager.processAdd(sessionBean, request, getPortletConfig().getResourceBundle(locale));
		} else if (ACTION_EDIT.equals(action)) {
			kpiActionManager.processEdit(sessionBean, request, getPortletConfig().getResourceBundle(locale));
		} else if (ACTION_UPLOAD.equals(action)) {			
			kpiActionManager.processUpload(sessionBean, request, getPortletConfig().getResourceBundle(locale), getPortletContext().getRealPath("/"));
		}
		if (request.getParameter(CONFIG_SUBMIT) != null) {
			String adminGroupName = request.getParameter(SETTING_PARAMETER_ADMIN_GROUP_NAME);
			String resultsPerPage = request.getParameter(SETTING_PARAMETER_RESULTS_PER_PAGE);
			String maxItems = request.getParameter(SETTING_PARAMETER_MAX_ITEMS);
			PortletPreferences prefs = request.getPreferences();			
			try {   
				prefs.setValue(SETTING_PARAMETER_ADMIN_GROUP_NAME, adminGroupName);
				prefs.setValue(SETTING_PARAMETER_RESULTS_PER_PAGE, resultsPerPage);
				prefs.setValue(SETTING_PARAMETER_MAX_ITEMS, maxItems);
				prefs.store();
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("settings.were.saved")));
				response.setPortletMode(PortletMode.VIEW);
				response.setWindowState(WindowState.NORMAL);				
			} catch( ReadOnlyException roe ) {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, roe.getMessage()));
			} catch( ValidatorException ve ) { 
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, ve.getMessage()));
			}
		} else if (request.getParameter(CONFIG_CANCEL) != null) {			
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);
		} if (request.getParameter(EDIT_DEFAULTS_SUBMIT) != null) {
			String adminGroupName = request.getParameter(SETTING_PARAMETER_ADMIN_GROUP_NAME);
			String resultsPerPage = request.getParameter(SETTING_PARAMETER_RESULTS_PER_PAGE);
			String maxItems = request.getParameter(SETTING_PARAMETER_MAX_ITEMS);
			String language = request.getParameter(SETTING_PARAMETER_LANGUAGE);
			String debug = request.getParameter(SETTING_PARAMETER_DEBUG);
			PortletPreferences prefs = request.getPreferences();			
			try {
				prefs.setValue(SETTING_PARAMETER_ADMIN_GROUP_NAME, adminGroupName);
				prefs.setValue(SETTING_PARAMETER_RESULTS_PER_PAGE, resultsPerPage);
				prefs.setValue(SETTING_PARAMETER_MAX_ITEMS, maxItems);
				prefs.setValue(SETTING_PARAMETER_LANGUAGE, language);
				prefs.setValue(SETTING_PARAMETER_DEBUG, debug);
				prefs.store();
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("settings.were.saved")));
				response.setPortletMode(PortletMode.VIEW);
				response.setWindowState(WindowState.NORMAL);
			} catch( ReadOnlyException roe ) {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, roe.getMessage()));
			} catch( ValidatorException ve ) { 
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, ve.getMessage()));
			}
		} else if (request.getParameter(EDIT_DEFAULTS_CANCEL) != null) {			
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);
		}
	}

	public void serveResource(ResourceRequest request, ResourceResponse response) throws PortletException, IOException {
		String attachmentId = request.getParameter(PARAMETER_ID);
		AttachmentManagement attachmentManagement = new AttachmentManagement();
		OutputStream outputStream = response.getPortletOutputStream();

		if (attachmentManagement.loadKPIAttachmentById(attachmentId, null) == 1) {
			response.setContentType(attachmentManagement.getCurrentKPIAttachment().getContentType());
			response.setProperty("Content-disposition", "attachment; filename=\"" + attachmentManagement.getCurrentKPIAttachment().getFileName() + "\"");
			outputStream.write(attachmentManagement.getCurrentKPIAttachment().getAttachment(), 0, attachmentManagement.getCurrentKPIAttachment().getAttachment().length);
		} else {
			outputStream.write("<i>Unable to find the specified file</i>".getBytes());
		}
		outputStream.flush();
		outputStream.close();
	}

	private static void populateRequest(RenderRequest request, KPIPortletSessionBean sessionBean) {
		if (sessionBean != null && sessionBean.getParameterMap() != null && sessionBean.getParameterMap().size() > 0) {
			java.util.Map<String, String[]> map = sessionBean.getParameterMap();
			Iterator<String> it = map.keySet().iterator();
			String paramName = null;
			String[] paramValues = null;
			while (it.hasNext()) {
				paramName = (String) it.next();
				paramValues = map.get(paramName);
				if (paramValues != null) {
					if (paramValues.length > 1) {
						request.setAttribute(paramName, paramValues);
					} else {
						request.setAttribute(paramName, paramValues[0]);
					}
				}
				// KPIUtils.println(paramName + "=" + paramValues[0]);
			}
		}
	}

	public static String getUserDN(com.ibm.portal.um.User user) {
		if (user != null) {
			if (getPumaHome() != null) {
				com.ibm.portal.um.PumaProfile pumaProfile = getPumaHome().getProfile();
				if (pumaProfile != null) {
					try {
						return pumaProfile.getIdentifier(user);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}
		return null;
	}

	protected void doCustomConfigure(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		KPIPortletSessionBean sessionBean = getSessionBean(request);
		if (sessionBean != null) {
			sessionBean.setMessage(null);
		}
		// Set the MIME type for the render response
		response.setContentType(request.getResponseContentType());
		// Invoke the JSP to render
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, CONFIG_JSP));
		rd.include(request, response);
	}
 
	protected void doCustomEditDefaults(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		KPIPortletSessionBean sessionBean = getSessionBean(request);
		if (sessionBean != null) {
			sessionBean.setMessage(null);
		}
		// Set the MIME type for the render response
		response.setContentType(request.getResponseContentType());
		// Invoke the JSP to render
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, EDIT_DEFAULTS_JSP));
		rd.include(request, response);
	}

	public void destroy() {
		System.out.println("STOPPING THREADS STARTED");
		DBPool.shutdownDataSource();
		System.out.println("STOPPING THREADS FINISHED");
	}

	private static KPIPortletSessionBean getSessionBean(PortletRequest request) {
		PortletSession session = request.getPortletSession();
		if (session == null)
			return null;
		KPIPortletSessionBean sessionBean = (KPIPortletSessionBean) session.getAttribute(SESSION_BEAN);
		if (sessionBean == null) {
			sessionBean = new KPIPortletSessionBean();
			session.setAttribute(SESSION_BEAN, sessionBean);
		}
		return sessionBean;
	}

	private static String getJspFilePath(RenderRequest request, String jspFile) {
		String markup = request.getProperty("wps.markup");
		if (markup == null)
			markup = getMarkup(request.getResponseContentType());
		return JSP_FOLDER + markup + "/" + jspFile + "." + getJspExtension(markup);
	}

	private static String getMarkup(String contentType) {
		if ("text/vnd.wap.wml".equals(contentType))
			return "wml";
		else
			return "html";
	}

	private static String getJspExtension(String markupName) {
		return "jsp";
	}

	public static PumaHome getPumaHome() {
		return pumaHome;
	}

	public static PumaProfile getPumaProfile() {
		return pumaHome.getProfile();
	}

}