package com.ibm.kpimanager;

import java.util.ArrayList;
import java.util.HashMap;

import com.ibm.kpi.bean.BreadCrumbNode;
import com.ibm.kpi.bean.Container;
import com.ibm.kpi.bean.Message;

public class KPIPortletSessionBean {
	
	private String currentPage = KPIManagerPortlet.INDEX_PAGE;
	ArrayList<BreadCrumbNode> breadCrumb = null;
	HashMap<String, Container> container = new HashMap<String, Container>();
	String navigatorTop = null;
	String navigatorBottom = null;
	Message message = null;
	java.util.Map<String, String[]> parameterMap = null;

	public String getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}

	public ArrayList<BreadCrumbNode> getBreadCrumb() {
		return breadCrumb;
	}

	public void setBreadCrumb(ArrayList<BreadCrumbNode> breadCrumb) {
		this.breadCrumb = breadCrumb;
	}

	public HashMap<String, Container> getContainer() {
		return container;
	}

	public void setContainer(HashMap<String, Container> container) {
		this.container = container;
	}

	public String getNavigatorTop() {
		return navigatorTop;
	}

	public void setNavigatorTop(String navigatorTop) {
		this.navigatorTop = navigatorTop;
	}

	public String getNavigatorBottom() {
		return navigatorBottom;
	}

	public void setNavigatorBottom(String navigatorBottom) {
		this.navigatorBottom = navigatorBottom;
	}

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}

	public java.util.Map<String, String[]> getParameterMap() {
		return parameterMap;
	}

	public void setParameterMap(java.util.Map<String, String[]> parameterMap) {
		this.parameterMap = parameterMap;
	}

}
