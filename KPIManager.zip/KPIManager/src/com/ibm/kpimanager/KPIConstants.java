package com.ibm.kpimanager;

import java.io.File;

public class KPIConstants {	
	public static final String USER_ROLE_MANAGER = "6";
	public static final String USER_ROLE_USER = "4";
	public static final String MESSAGE_TYPE_INFORMATION = "I";
	public static final String MESSAGE_TYPE_WARNING = "W";
	public static final String MESSAGE_TYPE_ERROR = "E";
		
	public static final String INDICATOR_INPUT_METHOD_MANUAL = "0";
	public static final String INDICATOR_INPUT_METHOD_FROM_FILE = "1";
	
	public static final String INDICATOR_VALUE_XSD_FILENAME = "indicatorValues.xsd";
	public static final String INDICATOR_VALUE_XSD_FOLDER_LOCATION = File.separator + "WEB-INF" + File.separator + "xsd" + File.separator;
	
	public static final String LANGUAGE_BG = "bg";
	public static final String LANGUAGE_EN = "en";
	
	public static String _PRODUCT_NAME = "KPIManager";
	public static String _PRODUCT_VERSION = "1.0";
	public static String _OFFICIALMAILSENDER = null;
}
