package com.ibm.kpi.management;

import java.sql.SQLException;

import com.ibm.kpi.db.DBResources;
import com.ibm.kpi.db.DBTransaction;
import com.ibm.kpi.db.FinderException;
import com.ibm.kpi.db.QueryExecution;
import com.ibm.kpi.dbo.KPIIndicatorHit;
import com.ibm.kpi.utils.KPIUtils;
import com.ibm.kpimanager.KPIConstants;

public class IndicatorHitManagement {

	private KPIIndicatorHit[] indicatorHits = null;
	private int indicatorHitCounter = 0;
	private KPIIndicatorHit current = null;

	public int getKPIIndicatorHitCounter() {
		return indicatorHitCounter;
	}

	public void setKPIIndicatorHitCounter(int indicatorHitCounter) {
		this.indicatorHitCounter = indicatorHitCounter;
	}

	public void setCurrentKPIIndicatorHit(KPIIndicatorHit object) {
		current = object;
	}

	public KPIIndicatorHit getCurrentKPIIndicatorHit() {
		if (current == null)
			current = new KPIIndicatorHit();
		return current;
	}

	public boolean selectNextKPIIndicatorHit() {
		if (indicatorHits != null) {
			if (indicatorHitCounter < indicatorHits.length) {
				setCurrentKPIIndicatorHit(indicatorHits[indicatorHitCounter++]);
				return true;
			}
		}
		return false;
	}

	public int loadKPIIndicatorHitById(String kpiIndicatorValueId, DBTransaction transaction) {
		try {
			KPIIndicatorHit tmpKPIIndicatorHit = KPIIndicatorHit.findById(kpiIndicatorValueId, transaction);
			if (tmpKPIIndicatorHit != null) {
				setCurrentKPIIndicatorHit(tmpKPIIndicatorHit);
				return 1;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			System.out.println("KPIIndicatorHitManagement : loadKPIIndicatorHitById : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

	public int loadAllKPIIndicatorHits() {
		try {
			indicatorHitCounter = 0;
			indicatorHits = null;
			indicatorHits = KPIIndicatorHit.findAll(null);
			if (indicatorHits != null) {
				indicatorHitCounter = 0;
				return indicatorHits.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("KPIIndicatorHitManagement : loadAllKPIIndicatorHits : " + e.getMessage());
		}
		return -1;
	}

	public int loadAllKPIIndicatorHitsByIndicatorId(String indicatorId, DBTransaction transaction) {
		try {
			indicatorHitCounter = 0;
			indicatorHits = null;
			indicatorHits = KPIIndicatorHit.findAllByIndicatorId(indicatorId, transaction);
			if (indicatorHits != null) {
				indicatorHitCounter = 0;
				return indicatorHits.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("KPIIndicatorHitManagement : loadAllKPIIndicatorHitsByIndicatorId : " + e.getMessage());
		}
		return -1;
	}

	public int loadAllKPIIndicatorHitsByFilter(String indicatorIds, String filterValue, String filterValue2) {
		DBTransaction transaction = null;
		try {
			transaction = new DBTransaction();
			indicatorHitCounter = 0;
			indicatorHits = null;
			if (filterValue != null && filterValue.trim().length() > 0) {
				filterValue = KPIUtils.timeMillisToTimestamp(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(filterValue.trim(), true));
			}
			if (filterValue2 != null && filterValue2.trim().length() > 0) {
				filterValue2 = KPIUtils.timeMillisToTimestamp(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(filterValue2.trim(), false));
			}
			if (KPIConstants._DB_ORACLE.equalsIgnoreCase(DBResources._DB)) {
				QueryExecution.setSessionTimestampFormat(transaction);
			}
			indicatorHits = KPIIndicatorHit.findAllByFilter(indicatorIds, filterValue, filterValue2, transaction);
			transaction.commit();
			if (indicatorHits != null) {
				indicatorHitCounter = 0;
				return indicatorHits.length;
			}
		} catch (FinderException e) {
			if (transaction != null) {
				try {
					transaction.commit();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			return 0;
		} catch (Exception e) {
			if (transaction != null) {
				try {
					transaction.commit();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			e.printStackTrace();
			System.out.println("KPIIndicatorHitManagement : loadAllKPIIndicatorHits : " + e.getMessage());
		}
		return -1;
	}

	public KPIIndicatorHit[] getKPIIndicatorHits() {
		return indicatorHits;
	}

	public void setKPIIndicatorHits(KPIIndicatorHit[] indicatorHits) {
		this.indicatorHits = indicatorHits;
	}

}
