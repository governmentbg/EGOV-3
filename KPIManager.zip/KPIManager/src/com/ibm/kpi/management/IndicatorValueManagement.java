package com.ibm.kpi.management;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;

import javax.portlet.ActionRequest;
import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.bind.ValidationEvent;
import javax.xml.bind.ValidationEventLocator;
import javax.xml.bind.util.ValidationEventCollector;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.portlet.PortletFileUpload;
import org.xml.sax.SAXException;

import com.ibm.kpi.bean.Indicator;
import com.ibm.kpi.bean.Message;
import com.ibm.kpi.db.DBResources;
import com.ibm.kpi.db.DBTransaction;
import com.ibm.kpi.db.FinderException;
import com.ibm.kpi.db.QueryExecution;
import com.ibm.kpi.dbo.KPIAttachment;
import com.ibm.kpi.dbo.KPIIndicator;
import com.ibm.kpi.dbo.KPIIndicatorValue;
import com.ibm.kpi.utils.KPIUtils;
import com.ibm.kpimanager.KPIConstants;
import com.ibm.kpimanager.KPIPortletSessionBean;

public class IndicatorValueManagement {

	private KPIIndicatorValue[] indicatorValues = null;
	private int indicatorValueCounter = 0;
	private KPIIndicatorValue current = null;

	public int getKPIIndicatorValueCounter() {
		return indicatorValueCounter;
	}

	public void setKPIIndicatorValueCounter(int indicatorValueCounter) {
		this.indicatorValueCounter = indicatorValueCounter;
	}

	public void setCurrentKPIIndicatorValue(KPIIndicatorValue object) {
		current = object;
	}

	public KPIIndicatorValue getCurrentKPIIndicatorValue() {
		if (current == null)
			current = new KPIIndicatorValue();
		return current;
	}

	public boolean selectNextKPIIndicatorValue() {
		if (indicatorValues != null) {
			if (indicatorValueCounter < indicatorValues.length) {
				setCurrentKPIIndicatorValue(indicatorValues[indicatorValueCounter++]);
				return true;
			}
		}
		return false;
	}

	public int loadKPIIndicatorValueById(String kpiIndicatorValueId, DBTransaction transaction) {
		try {
			KPIIndicatorValue tmpKPIIndicatorValue = KPIIndicatorValue.findById(kpiIndicatorValueId, transaction);
			if (tmpKPIIndicatorValue != null) {
				setCurrentKPIIndicatorValue(tmpKPIIndicatorValue);
				return 1;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			System.out.println("KPIIndicatorValueManagement : loadKPIIndicatorValueById : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

	public int loadKPIIndicatorValueWithAttachmentsById(String kpiIndicatorValueId, DBTransaction transaction) {
		try {
			KPIIndicatorValue tmpKPIIndicatorValue = KPIIndicatorValue.findById(kpiIndicatorValueId, transaction);
			if (tmpKPIIndicatorValue != null) {
				KPIAttachment[] kpiAttachments = null;
				try {
					kpiAttachments = QueryExecution.findAllKPIAttachmentsByIndicatorValueId(kpiIndicatorValueId, transaction);
				} catch (FinderException e) {
				}
				if (kpiAttachments != null) {
					tmpKPIIndicatorValue.setAttachments(kpiAttachments);
					setCurrentKPIIndicatorValue(tmpKPIIndicatorValue);
					return 1;
				}
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			System.out.println("KPIIndicatorValueManagement : loadKPIIndicatorValueWithAttachmentsById : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

	public int loadAllKPIIndicatorValues() {
		try {
			indicatorValueCounter = 0;
			indicatorValues = null;
			indicatorValues = KPIIndicatorValue.findAll(null);
			if (indicatorValues != null) {
				indicatorValueCounter = 0;
				return indicatorValues.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("KPIIndicatorValueManagement : loadAllKPIIndicatorValues : " + e.getMessage());
		}
		return -1;
	}

	public int loadAllKPIIndicatorValuesByIndicatorIds(String indicatorIds, DBTransaction transaction) {
		try {
			indicatorValueCounter = 0;
			indicatorValues = null;
			indicatorValues = KPIIndicatorValue.findAllByIndicatorIds(indicatorIds, transaction);
			if (indicatorValues != null) {
				indicatorValueCounter = 0;
				return indicatorValues.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("KPIIndicatorValueManagement : loadAllKPIIndicatorValuesByIndicatorIds : " + e.getMessage());
		}
		return -1;
	}

	public int loadAllKPIIndicatorValuesByFilter(String indicatorId, String filterType, String filterValue, String filterValue2) {
		DBTransaction transaction = null;
		try {
			transaction = new DBTransaction();
			indicatorValueCounter = 0;
			indicatorValues = null;
			if ("2".equals(filterType)) {
				if (filterValue != null && filterValue.trim().length() > 0) {
					filterValue = KPIUtils.timeMillisToTimestamp(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(filterValue.trim(), true));
				}
				if (filterValue2 != null && filterValue2.trim().length() > 0) {
					filterValue2 = KPIUtils.timeMillisToTimestamp(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(filterValue2.trim(), false));
				}
				if (KPIConstants._DB_ORACLE.equalsIgnoreCase(DBResources._DB)) {
					QueryExecution.setSessionTimestampFormat(transaction);
				}
			}
			indicatorValues = KPIIndicatorValue.findAllByFilter(indicatorId, filterType, filterValue, filterValue2, transaction);
			transaction.commit();
			if (indicatorValues != null) {
				indicatorValueCounter = 0;
				return indicatorValues.length;
			}
		} catch (FinderException e) {
			if (transaction != null) {
				try {
					transaction.commit();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			return 0;
		} catch (Exception e) {
			if (transaction != null) {
				try {
					transaction.commit();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			e.printStackTrace();
			System.out.println("KPIIndicatorValueManagement : loadAllKPIIndicatorValues : " + e.getMessage());
		}
		return -1;
	}

	@SuppressWarnings("unchecked")
	public int createKPIIndicatorValue(ActionRequest request, String indicatorId, String userDN, KPIPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		KPIIndicatorValue kpiIndicatorValue = null;
		long currentTime = System.currentTimeMillis();
		try {
			// Create a factory for disk-based file items
			FileItemFactory factory = new DiskFileItemFactory();
			// Create a new file upload handler
			PortletFileUpload upload = new PortletFileUpload(factory);
			// Parse the request
			List<FileItem> items = upload.parseRequest(request);
			// Process the uploaded items
			Iterator<FileItem> iter = items.iterator();
			FileItem item = null;
			String name = null;

			transaction = new DBTransaction();
			KPIIndicator indicator = null;
			try {
				indicator = KPIIndicator.findById(indicatorId, transaction);
			} catch (FinderException e) {
			}
			if (indicator == null) {
				throw new Exception(bundle.getString("indicator.with.id.not.found") + " " + indicatorId + "!");
			}

			kpiIndicatorValue = new KPIIndicatorValue();
			kpiIndicatorValue.setKpiIndicatorId(indicatorId);
			ArrayList<KPIAttachment> attachmentsArr = new ArrayList<KPIAttachment>();
			KPIAttachment attachment = null;
			KPIIndicatorValue[] currentKpiIndicatorValues = null;
			HashMap<String, String> currentKpiIndicatorValuesHm = new HashMap<String, String>();
			try {
				currentKpiIndicatorValues = KPIIndicatorValue.findAllByIndicatorId(indicatorId, transaction);
			} catch (FinderException e) {				
			}
			if (currentKpiIndicatorValues != null && currentKpiIndicatorValues.length > 0) {
				for (int i = 0; i < currentKpiIndicatorValues.length; i++) { 
					currentKpiIndicatorValuesHm.put(String.valueOf(currentKpiIndicatorValues[i].getTargetDate().getTime()), "1");
				}				
			}
			String fileName = null;
			while (iter.hasNext()) {
				item = (FileItem) iter.next();
				if (item.isFormField()) {
					name = item.getFieldName();
					if ("indicatorValue".equals(name)) {						
						kpiIndicatorValue.setValue(item.getString());
					} else if ("comments".equals(name)) {
						kpiIndicatorValue.setComments((item.getString() != null) ? item.getString().trim() : null);
					} else if ("targetDate".equals(name)) {
						kpiIndicatorValue.setTargetDate(KPIUtils.timeMillisToTimestamp(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(item.getString(), true)));
						if (currentKpiIndicatorValuesHm.get(String.valueOf(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(item.getString(), true))) != null) {
							throw new Exception(bundle.getString("indicator.value.target.date.already.exists"));
						}
					}
				} else {
					fileName = item.getName();
					if (item.getSize() > 0 && fileName.trim().length() > 0) {
						attachment = new KPIAttachment();
						attachment.setFileName(fileName.trim());
						attachment.setContentType(item.getContentType());
						attachment.setAttachment(item.get());
						attachmentsArr.add(attachment);
						//boolean isInMemory = item.isInMemory();
						System.out.println("fileName=" + fileName);
					}
				}
			}

			if (kpiIndicatorValue.getValue() == null || kpiIndicatorValue.getValue().trim().length() == 0) {
				throw new Exception(bundle.getString("invalid.parameters"));
			}
			if (kpiIndicatorValue.getComments() != null && kpiIndicatorValue.getComments().trim().length() > 250) {
				throw new Exception(bundle.getString("indicator.value.comments.too.long"));
			}
			kpiIndicatorValue.setInputMethod(KPIConstants.INDICATOR_INPUT_METHOD_MANUAL);
			kpiIndicatorValue.setUserDN(userDN);
			kpiIndicatorValue.setCreationDate(KPIUtils.timeMillisToTimestamp(currentTime));
			kpiIndicatorValue.create(transaction);

			if (attachmentsArr.size() > 0) {
				for (int i = 0; i < attachmentsArr.size(); i++) {
					attachmentsArr.get(i).setKpiIndicatorValueId(kpiIndicatorValue.getId());
					attachmentsArr.get(i).create(transaction);
				}
			}

			transaction.commit();
			sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_INFORMATION, "\"" + kpiIndicatorValue.getValue() + "\" " + bundle.getString("added.successfully")));
			return 1;
		} catch (Exception e) {
			System.out.println("KPIIndicatorValueManagement : createKPIIndicatorValue : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
			if (kpiIndicatorValue != null && kpiIndicatorValue.getValue() != null) {
				java.util.Map<String, String[]> map = new HashMap<String, String[]>();
				String paramName = "indicatorValue";
				String[] paramValues = new String[]{kpiIndicatorValue.getValue()};
				map.put(paramName, paramValues);
				if (kpiIndicatorValue != null && kpiIndicatorValue.getComments() != null) {
					paramName = "comments";
					paramValues = new String[]{kpiIndicatorValue.getComments()};
					map.put(paramName, paramValues);
				}
				if (kpiIndicatorValue != null && kpiIndicatorValue.getTargetDate() != null) {
					paramName = "targetDate";
					paramValues = new String[]{KPIUtils.timeMillisToYYYY_MM_DD(kpiIndicatorValue.getTargetDate().getTime())};
					map.put(paramName, paramValues);
				}
				sessionBean.setParameterMap(map);
			}
		}
		return -1;
	}

	public int updateKPIIndicatorValue(ActionRequest request, String kpiIndicatorValueId, KPIPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		try {
			transaction = new DBTransaction();
			KPIIndicatorValue kpiIndicatorValue = null;
			try {
				kpiIndicatorValue = KPIIndicatorValue.findById(kpiIndicatorValueId, transaction);
			} catch (FinderException e) {
			}
			if (kpiIndicatorValue == null) {
				throw new Exception(bundle.getString("indicator.value.with.id.not.found") + " " + kpiIndicatorValueId + "!");
			}
			HashMap<String, String> currentKpiIndicatorValuesHm = new HashMap<String, String>();
			KPIIndicatorValue[] currentKpiIndicatorValues = null;
			try {
				currentKpiIndicatorValues = KPIIndicatorValue.findAllByIndicatorId(kpiIndicatorValue.getKpiIndicatorId(), transaction);
			} catch (FinderException e) {				
			}
			if (currentKpiIndicatorValues != null && currentKpiIndicatorValues.length > 0) {
				for (int i = 0; i < currentKpiIndicatorValues.length; i++) { 
					currentKpiIndicatorValuesHm.put(String.valueOf(currentKpiIndicatorValues[i].getTargetDate().getTime()), "1");
				}				
			}
			// Create a factory for disk-based file items
			FileItemFactory factory = new DiskFileItemFactory();
			// Create a new file upload handler
			PortletFileUpload upload = new PortletFileUpload(factory);
			// Parse the request
			@SuppressWarnings("unchecked")
			List<FileItem> items = upload.parseRequest(request);
			// Process the uploaded items
			Iterator<FileItem> iter = items.iterator();
			FileItem item = null;
			String name = null;
			StringBuffer removedFilesIds = new StringBuffer();
			ArrayList<KPIAttachment> attachmentsArr = new ArrayList<KPIAttachment>();
			KPIAttachment attachment = null;
			while (iter.hasNext()) {
				item = (FileItem) iter.next();
				if (item.isFormField()) {
					name = item.getFieldName();
					System.out.println("Name= " + name);
					if ("indicatorValue".equals(name)) {
						kpiIndicatorValue.setValue(item.getString());
					} else if ("comments".equals(name)) {
						kpiIndicatorValue.setComments((item.getString() != null) ? item.getString().trim() : null);
					} else if ("targetDate".equals(name)) {
						kpiIndicatorValue.setTargetDate(KPIUtils.timeMillisToTimestamp(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(item.getString(), true)));
						if (currentKpiIndicatorValuesHm.get(String.valueOf(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(item.getString(), true))) != null) {
							throw new Exception(bundle.getString("indicator.value.target.date.already.exists"));
						}
					} else if ("removedFiles".equals(name)) {
						if (removedFilesIds.toString().length() > 0 ) {
							removedFilesIds.append(",");
						}
						removedFilesIds.append(item.getString().trim());
					}
				} else {
					String fileName = item.getName();
					if (item.getSize() > 0 && fileName.trim().length() > 0) {
						attachment = new KPIAttachment();
						attachment.setFileName(fileName.trim());
						attachment.setContentType(item.getContentType());
						attachment.setAttachment(item.get());
						attachmentsArr.add(attachment);
						// boolean isInMemory = item.isInMemory();
						System.out.println("fileName=" + fileName);
					}
				}
			}

			if (kpiIndicatorValue.getValue() == null || kpiIndicatorValue.getValue().trim().length() == 0) {
				throw new Exception(bundle.getString("invalid.parameters"));
			}
			if (kpiIndicatorValue.getComments() != null && kpiIndicatorValue.getComments().trim().length() > 250) {
				throw new Exception(bundle.getString("indicator.value.comments.too.long"));
			}
			kpiIndicatorValue.store(transaction);

			if (removedFilesIds.toString().length() > 0) {
				KPIAttachment tmpAttachment = new KPIAttachment();
				tmpAttachment.removeConditional("KPIATTACHMENTID IN (" + removedFilesIds.toString() + ")" , transaction);
			}
			
			if (attachmentsArr.size() > 0) {
				for (int i = 0; i < attachmentsArr.size(); i++) {
					attachmentsArr.get(i).setKpiIndicatorValueId(kpiIndicatorValue.getId());
					attachmentsArr.get(i).create(transaction);
				}
			}

			transaction.commit();
			sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_INFORMATION, "\"" + kpiIndicatorValue.getValue() + "\" " + bundle.getString("edited.successfully")));
			return 1;
		} catch (Exception e) {
			System.out.println("KPIIndicatorValueManagement : updateKPIIndicatorValue : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return -1;
	}

	public int removeKPIIndicatorValue(String kpiIndicatorValueId, KPIPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		int result = -1;
		try {
			transaction = new DBTransaction();
			KPIIndicatorValue tmpKPIIndicatorValue = null;
			try {
				tmpKPIIndicatorValue = KPIIndicatorValue.findById(kpiIndicatorValueId, transaction);
			} catch (FinderException e) {
			}
			if (tmpKPIIndicatorValue != null) {
				KPIAttachment kpiAttachment = new KPIAttachment();
				kpiAttachment.removeConditional("kpiIndicatorValueId=" + kpiIndicatorValueId, transaction);
				tmpKPIIndicatorValue.remove(transaction);
				result = 1;
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_INFORMATION, "\"" + tmpKPIIndicatorValue.getValue() + "\" " + bundle.getString("deleted.successfully")));
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("indicator.value.with.id.not.found") + " " + kpiIndicatorValueId + "!"));
			}
			transaction.commit();
		} catch (Exception e) {
			sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
			e.printStackTrace();
			try {
				result = -1;
				if (transaction != null)
					transaction.rollback();
			} catch (SQLException e1) {
				System.out.println("KPIIndicatorValueManagement : removeKPIIndicatorValue : " + e1.getMessage());
			}
		}
		System.out.println("result = " + result);
		return result;
	}

	public int uploadFromFile(ActionRequest request, String indicatorId, String userDN, KPIPortletSessionBean sessionBean, ResourceBundle bundle, String realPath) {		
		DBTransaction transaction = null;
		long currentTime = System.currentTimeMillis();
		try {
			// Create a factory for disk-based file items
			FileItemFactory factory = new DiskFileItemFactory();
			// Create a new file upload handler
			PortletFileUpload upload = new PortletFileUpload(factory);
			// Parse the request
			@SuppressWarnings("unchecked")
			List<FileItem> items = upload.parseRequest(request);
			// Process the uploaded items
			Iterator<FileItem> iter = items.iterator();
			FileItem item = null; 
			transaction = new DBTransaction();
			KPIIndicator indicator = null;
			try {
				indicator = KPIIndicator.findById(indicatorId, transaction);
			} catch (FinderException e) {
			}
			if (indicator == null) {
				throw new Exception(bundle.getString("indicator.with.id.not.found") + " " + indicatorId + "!");
			}

			KPIIndicatorValue[] currentKpiIndicatorValues = null;
			HashMap<String, String> currentKpiIndicatorValuesHm = new HashMap<String, String>();
			try {
				currentKpiIndicatorValues = KPIIndicatorValue.findAllByIndicatorId(indicatorId, transaction);
			} catch (FinderException e) {				
			}
			if (currentKpiIndicatorValues != null && currentKpiIndicatorValues.length > 0) {
				for (int i = 0; i < currentKpiIndicatorValues.length; i++) { 
					currentKpiIndicatorValuesHm.put(String.valueOf(currentKpiIndicatorValues[i].getTargetDate().getTime()), "1");
				}				
			}
			String fileName = null;
			while (iter.hasNext()) {
				item = (FileItem) iter.next();
				if (item.isFormField()) {
					continue;
				} else {
					fileName = item.getName();
					if (item.getSize() > 0 && fileName.trim().length() > 0) {												
						break;
					}
				}
			}
			if (fileName != null && fileName.trim().length() > 0 && item != null && item.getSize() > 0) {
				try {
					File xsd = new File(realPath + KPIConstants.INDICATOR_VALUE_XSD_FOLDER_LOCATION + KPIConstants.INDICATOR_VALUE_XSD_FILENAME);	
					ValidationEventCollector vec = new ValidationEventCollector();
					SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
					Schema schema = sf.newSchema(xsd);
					JAXBContext jaxbContext = JAXBContext.newInstance(Indicator.class);
					Unmarshaller um = jaxbContext.createUnmarshaller();
					um.setSchema(schema);
					try {
						um.setEventHandler(vec);
						Indicator xmlIndicator = (Indicator) um.unmarshal(item.getInputStream());
						if (xmlIndicator != null && xmlIndicator.getValues() != null && xmlIndicator.getValues().size() > 0) {
							KPIIndicatorValue kpiIndicatorValue = null;
							for (int i = 0; i < xmlIndicator.getValues().size(); i++) {
								if (currentKpiIndicatorValuesHm.get(String.valueOf(xmlIndicator.getValues().get(i).getTargetDate().getTime())) != null) {
									throw new Exception(bundle.getString("indicator.values.target.date.already.exists") + " \"" + KPIUtils.timeMillisToYYYY_MM_DD(xmlIndicator.getValues().get(i).getTargetDate().getTime())  + "\"!");
								}
							}
							for (int i = 0; i < xmlIndicator.getValues().size(); i++) {
								kpiIndicatorValue = new KPIIndicatorValue();
								kpiIndicatorValue.setKpiIndicatorId(indicatorId);
								kpiIndicatorValue.setValue(String.valueOf(xmlIndicator.getValues().get(i).getValue()));
								kpiIndicatorValue.setComments(xmlIndicator.getValues().get(i).getComments());
								kpiIndicatorValue.setTargetDate(KPIUtils.timeMillisToTimestamp(xmlIndicator.getValues().get(i).getTargetDate().getTime()));
								kpiIndicatorValue.setUserDN(userDN);
								kpiIndicatorValue.setCreationDate(KPIUtils.timeMillisToTimestamp(currentTime));
								kpiIndicatorValue.setInputMethod(KPIConstants.INDICATOR_INPUT_METHOD_FROM_FILE);
								kpiIndicatorValue.create(transaction);
							}
						} else {
							throw new Exception(bundle.getString("indicator.values.no.xml.data.loaded"));
						}
					} catch (javax.xml.bind.UnmarshalException ex) {
						if (vec != null && vec.hasEvents()) {
							for (ValidationEvent ve : vec.getEvents()) {
								String msg = ve.getMessage();
								ValidationEventLocator vel = ve.getLocator();
								int numLigne = vel.getLineNumber();
								int numColonne = vel.getColumnNumber();
								throw new Exception(bundle.getString("indicator.values.xml.error.on.line") + " " + numLigne + " " + bundle.getString("indicator.values.xml.error.and.column") + " " + numColonne + " " + bundle.getString("indicator.values.xml.error.msg") + " " + msg);
							}
						}

					}
				} catch (SAXException e) {
					e.printStackTrace();
				} catch (JAXBException e) {
					e.printStackTrace();
				}
			} else {
				throw new Exception(bundle.getString("invalid.parameters"));
			}
			transaction.commit();
			sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_INFORMATION, "\"" + fileName + "\" " + bundle.getString("uploaded.successfully")));
			return 1;
		} catch (Exception e) {
			System.out.println("KPIIndicatorValueManagement : uploadFromFile : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
		}
		return -1;
	}

	public KPIIndicatorValue[] getKPIIndicatorValues() {
		return indicatorValues;
	}

	public void setKPIIndicatorValues(KPIIndicatorValue[] indicatorValues) {
		this.indicatorValues = indicatorValues;
	}

}
