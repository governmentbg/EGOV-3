package com.ibm.kpi.management;

import java.sql.SQLException;
import java.util.ResourceBundle;

import com.ibm.kpi.bean.Message;
import com.ibm.kpi.db.DBResources;
import com.ibm.kpi.db.DBTransaction;
import com.ibm.kpi.db.FinderException;
import com.ibm.kpi.db.QueryExecution;
import com.ibm.kpi.dbo.KPIIndicator;
import com.ibm.kpi.dbo.KPISector;
import com.ibm.kpi.dbo.KPISectorIndicator;
import com.ibm.kpi.utils.KPIUtils;
import com.ibm.kpimanager.KPIConstants;
import com.ibm.kpimanager.KPIPortletSessionBean;

public class SectorManagement {
	
	private KPISector[] sectors = null;
	private int sectorCounter = 0;
	private KPISector current = null;

	public int getKPISectorCounter() {
		return sectorCounter;
	}

	public void setKPISectorCounter(int sectorCounter) {
		this.sectorCounter = sectorCounter;
	}

	public void setCurrentKPISector(KPISector object) {
		current = object;
	}

	public KPISector getCurrentKPISector() {
		if (current == null)
			current = new KPISector();
		return current;
	}

	public boolean selectNextKPISector() {
		if (sectors != null) {
			if (sectorCounter < sectors.length) {
				setCurrentKPISector(sectors[sectorCounter++]);
				return true;
			}
		}
		return false;
	}

	public int loadKPISectorById(String kpiSectorId, DBTransaction transaction) {
		try {
			KPISector tmpKPISector = KPISector.findById(kpiSectorId, transaction);
			if (tmpKPISector != null) {
				setCurrentKPISector(tmpKPISector);
				return 1;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			System.out.println("KPISectorManagement : loadKPISectorById : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

	public int loadAllKPISectors() {
		try {
			sectorCounter = 0;
			sectors = null;
			sectors = KPISector.findAll(null);
			if (sectors != null) {
				sectorCounter = 0;
				return sectors.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("KPISectorManagement : loadAllKPISectors : " + e.getMessage());
		}
		return -1;
	}

	public int loadAllKPISectorsByFilter(String filterType, String filterValue, String filterValue2) {
		DBTransaction transaction = null;
		try {
			transaction = new DBTransaction();
			sectorCounter = 0;
			sectors = null;
			if ("2".equals(filterType)) {
				if (filterValue != null && filterValue.trim().length() > 0) {
					filterValue = KPIUtils.timeMillisToTimestamp(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(filterValue.trim(), true));
				}
				if (filterValue2 != null && filterValue2.trim().length() > 0) {
					filterValue2 = KPIUtils.timeMillisToTimestamp(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(filterValue2.trim(), false));
				}
				if (KPIConstants._DB_ORACLE.equalsIgnoreCase(DBResources._DB)) {
					QueryExecution.setSessionTimestampFormat(transaction);
				}
			}
			sectors = KPISector.findAllByFilter(filterType, filterValue, filterValue2, transaction);
			transaction.commit();
			if (sectors != null) {
				sectorCounter = 0;
				return sectors.length;
			}
		} catch (FinderException e) {
			if (transaction != null) {
				try {
					transaction.commit();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			return 0;
		} catch (Exception e) {
			if (transaction != null) {
				try {
					transaction.commit();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			e.printStackTrace();
			System.out.println("KPISectorManagement : loadAllKPISectors : " + e.getMessage());
		}
		return -1;
	}

	public int createKPISector(String name, String description) {
		DBTransaction transaction = null;
		long currentTime = System.currentTimeMillis();
		try {			
			transaction = new DBTransaction();
			KPISector kpiSector = new KPISector();
			kpiSector.setSectorName(name.trim());
			if (description != null) {
				kpiSector.setSectorDescription(description.trim());
			}
			kpiSector.setCreationDate(KPIUtils.timeMillisToTimestamp(currentTime));
			kpiSector.create(transaction);
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println("KPISectorManagement : createKPISector : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return -1;
	}

	public int updateKPISector(String kpiSectorId, String name, String description) {
		DBTransaction transaction = null;
		int result = -1;
		try {
			KPISector kpiSector = null;
			try {
				kpiSector = KPISector.findById(kpiSectorId, transaction);
			} catch (FinderException e) {
			} catch (Exception e) {
				return result;
			}
			if (kpiSector == null) {				
				return result;
			}
			
			transaction = new DBTransaction();
			kpiSector.setSectorName(name.trim());
			if (description != null) {
				kpiSector.setSectorDescription(description.trim());
			}
			kpiSector.store(transaction);
			transaction.commit();
			result = 1;
		} catch (Exception e) {
			System.out.println("KPISectorManagement : updateKPISector : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return result;
	}

	public int removeKPISector(String kpiSectorId, KPIPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		int result = -1;
		try {
			transaction = new DBTransaction();
			KPISector tmpKPISector = null;
			try {
				tmpKPISector = KPISector.findById(kpiSectorId, transaction);
			} catch (FinderException e) {
			}
			if (tmpKPISector != null) {
				KPISectorIndicator[] kpiSectorIndicators = null;
				try {
					kpiSectorIndicators = KPISectorIndicator.findAllBySectorId(kpiSectorId, transaction);
				} catch (FinderException e) {
				}
				if (kpiSectorIndicators != null && kpiSectorIndicators.length > 0) {
					KPIIndicator kpiIndicator = null;
					try {
						kpiIndicator = KPIIndicator.findById(kpiSectorIndicators[0].getKpiIndicatorId(), transaction);
					} catch (FinderException e) {
					}
					if (kpiIndicator != null) {
						sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, "\"" + kpiIndicator.getIndicatorName() + "\" " + bundle.getString("sector.indicator.exists.name")));
					} else {
						sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("sector.indicator.exists")));
					}
					throw new Exception("KPIINDICATORSECTOR EXISTS!");
				}
					
				tmpKPISector.remove(transaction);
				result = 1;
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_INFORMATION, "\"" + tmpKPISector.getSectorName() + "\" " + bundle.getString("deleted.successfully")));
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("sector.with.id.not.found") + " " + kpiSectorId + "!"));
			}
			transaction.commit();
		} catch (Exception e) {
			try {
				result = -1;
				//logger.debug( e.getMessage(), e);
				if (transaction != null)
					transaction.rollback();
			} catch (SQLException e1) {
				System.out.println("KPISectorManagement : removeKPISector : " + e1.getMessage());
			}
		}
		System.out.println("result = " + result);
		return result;
	}

	public KPISector[] getKPISectors() {
		return sectors;
	}

	public void setKPISectors(KPISector[] sectors) {
		this.sectors = sectors;
	}

}
