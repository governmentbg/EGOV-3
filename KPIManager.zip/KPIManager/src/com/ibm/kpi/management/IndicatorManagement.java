package com.ibm.kpi.management;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.ResourceBundle;

import com.ibm.kpi.bean.Message;
import com.ibm.kpi.db.DBResources;
import com.ibm.kpi.db.DBTransaction;
import com.ibm.kpi.db.FinderException;
import com.ibm.kpi.db.QueryExecution;
import com.ibm.kpi.dbo.KPIIndicator;
import com.ibm.kpi.dbo.KPIIndicatorHit;
import com.ibm.kpi.dbo.KPIIndicatorValue;
import com.ibm.kpi.dbo.KPIOrganization;
import com.ibm.kpi.dbo.KPIOrganizationUser;
import com.ibm.kpi.dbo.KPISector;
import com.ibm.kpi.dbo.KPISectorIndicator;
import com.ibm.kpi.utils.KPIUtils;
import com.ibm.kpimanager.KPIConstants;
import com.ibm.kpimanager.KPIManagerPortlet;
import com.ibm.kpimanager.KPIPortletSessionBean;

public class IndicatorManagement {

	private KPIIndicator[] indicators = null;
	private int indicatorCounter = 0;
	private KPIIndicator current = null;

	public int getKPIIndicatorCounter() {
		return indicatorCounter;
	}

	public void setKPIIndicatorCounter(int indicatorCounter) {
		this.indicatorCounter = indicatorCounter;
	}

	public void setCurrentKPIIndicator(KPIIndicator object) {
		current = object;
	}

	public KPIIndicator getCurrentKPIIndicator() {
		if (current == null)
			current = new KPIIndicator();
		return current;
	}

	public boolean selectNextKPIIndicator() {
		if (indicators != null) {
			if (indicatorCounter < indicators.length) {
				setCurrentKPIIndicator(indicators[indicatorCounter++]);
				return true;
			}
		}
		return false;
	}

	public int loadKPIIndicatorById(String kpiIndicatorId, DBTransaction transaction) {
		try {
			KPIIndicator tmpKPIIndicator = KPIIndicator.findById(kpiIndicatorId, transaction);
			if (tmpKPIIndicator != null) {
				setCurrentKPIIndicator(tmpKPIIndicator);
				return 1;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			System.out.println("KPIIndicatorManagement : loadKPIIndicatorById : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

	public int loadKPIIndicatorWithSectorsById(String kpiIndicatorId, DBTransaction transaction) {
		try {
			KPIIndicator tmpKPIIndicator = KPIIndicator.findById(kpiIndicatorId, transaction);
			if (tmpKPIIndicator != null) {
				KPISectorIndicator[] kpiSectorIndicators = null;
				try {
					kpiSectorIndicators = KPISectorIndicator.findAllByIndicatorIds(kpiIndicatorId, transaction);
				} catch (FinderException e) {
				}
				if (kpiSectorIndicators != null) {
					tmpKPIIndicator.setSectorIndicators(kpiSectorIndicators);
					setCurrentKPIIndicator(tmpKPIIndicator);
					return 1;
				}
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			System.out.println("KPIIndicatorManagement : loadKPIIndicatorWithSectorsById : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

	public int loadAllKPIIndicators() {
		try {
			indicatorCounter = 0;
			indicators = null;
			indicators = KPIIndicator.findAll(null);
			if (indicators != null) {
				indicatorCounter = 0;
				return indicators.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("KPIIndicatorManagement : loadAllKPIIndicators : " + e.getMessage());
		}
		return -1;
	}

	public int loadAllKPIIndicatorsByIds(String ids, DBTransaction transaction) {
		try {
			indicatorCounter = 0;
			indicators = null;
			indicators = KPIIndicator.findAllByIds(ids, transaction);
			if (indicators != null) {
				indicatorCounter = 0;
				return indicators.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("KPIIndicatorManagement : loadAllKPIIndicatorsByIds : " + e.getMessage());
		}
		return -1;
	}

	public int loadAllKPIIndicatorsByFilter(String sectorId, String filterType, String filterValue, String filterValue2) {
		DBTransaction transaction = null;
		try {
			transaction = new DBTransaction();
			indicatorCounter = 0;
			indicators = null;
			if ("4".equals(filterType)) {
				if (filterValue != null && filterValue.trim().length() > 0) {
					filterValue = KPIUtils.timeMillisToTimestamp(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(filterValue.trim(), true));
				}
				if (filterValue2 != null && filterValue2.trim().length() > 0) {
					filterValue2 = KPIUtils.timeMillisToTimestamp(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(filterValue2.trim(), false));
				}
				if (KPIConstants._DB_ORACLE.equalsIgnoreCase(DBResources._DB)) {
					QueryExecution.setSessionTimestampFormat(transaction);
				}
			}
			StringBuffer indicatorIds = null;
			if (sectorId != null && sectorId.trim().length() > 0) {
				indicatorIds = new StringBuffer();
				KPISectorIndicator[] kpiSectorIndicators = null;
				try {
					kpiSectorIndicators = KPISectorIndicator.findAllBySectorId(sectorId, transaction); 
				} catch (FinderException e) {
				}
				if (kpiSectorIndicators != null && kpiSectorIndicators.length > 0) {
					for (int i = 0; i < kpiSectorIndicators.length; i++) {
						if (indicatorIds.toString().length() > 0) {
							indicatorIds.append(",");
						}
						indicatorIds.append(kpiSectorIndicators[i].getKpiIndicatorId());
					}
				} else {
					indicatorIds.append("0"); // SET ID TO NON EXISTING WHEN THERE IS NO INDICATORS FOUND FOR CURRENT SECTOR
				}
			}
			indicators = KPIIndicator.findAllByFilter((indicatorIds != null) ? indicatorIds.toString() : null, filterType, filterValue, filterValue2, transaction);
			if (indicators != null) {
				ArrayList<KPIIndicator> kpiIndicatorArr = null;
				if ("2".equals(filterType) && filterValue != null && filterValue.trim().length() > 0) { // ORGANIZATION
					KPIOrganization[] organizations = null;
					try {
						organizations = KPIOrganization.findAllByName(filterValue, transaction);
					} catch (FinderException e) {
					}
					if (organizations != null) {
						HashMap<String, String> organizationsHm = new HashMap<String, String>();
						for (int i = 0; i < organizations.length; i++) {
							organizationsHm.put(organizations[i].getId(), organizations[i].getId());
						}
						kpiIndicatorArr = new ArrayList<KPIIndicator>();
						for (int i = 0; i < indicators.length; i++) {
							if (organizationsHm.get(indicators[i].getKpiOrganizationId()) != null) {
								kpiIndicatorArr.add(indicators[i]);
							}
						}
					}
					indicators = (kpiIndicatorArr != null && kpiIndicatorArr.size() > 0) ? (KPIIndicator[]) kpiIndicatorArr.toArray(new KPIIndicator[kpiIndicatorArr.size()]) : null;
				}
				if ("3".equals(filterType) && filterValue != null && filterValue.trim().length() > 0) { // RESPONSIBLE USER
					KPIOrganizationUser[] organizationUsers = null;
					try {
						organizationUsers = KPIOrganizationUser.findAllByUserUIDOrCN(filterValue, transaction);
					} catch (FinderException e) {
					}
					if (organizationUsers != null) {
						HashMap<String, String> organizationUsersHm = new HashMap<String, String>();
						for (int i = 0; i < organizationUsers.length; i++) {
							organizationUsersHm.put(organizationUsers[i].getId(), organizationUsers[i].getId());
						}
						kpiIndicatorArr = new ArrayList<KPIIndicator>();
						for (int i = 0; i < indicators.length; i++) {
							if (organizationUsersHm.get(indicators[i].getResponsibleUserId()) != null) {
								kpiIndicatorArr.add(indicators[i]);
							}
						}
					}
					indicators = (kpiIndicatorArr != null && kpiIndicatorArr.size() > 0) ? (KPIIndicator[]) kpiIndicatorArr.toArray(new KPIIndicator[kpiIndicatorArr.size()]) : null;
				}
				if (indicators != null) {
					if (!KPIManagerPortlet.isAdmin) {
						kpiIndicatorArr = new ArrayList<KPIIndicator>();
						if (KPIManagerPortlet.isManager) {
							for (int i = 0; i < indicators.length; i++) {
								if (indicators[i].getKpiOrganizationId().equals(KPIManagerPortlet.currentUserOrganizationId)) {
									kpiIndicatorArr.add(indicators[i]);
								}
							}
						} else { // isUser
							for (int i = 0; i < indicators.length; i++) {
								if (indicators[i].getResponsibleUserId().equals(KPIManagerPortlet.currentUserOrganizationUserId)) {
									kpiIndicatorArr.add(indicators[i]);
								}
							}
						}
						indicators = (kpiIndicatorArr.size() > 0) ? (KPIIndicator[]) kpiIndicatorArr.toArray(new KPIIndicator[kpiIndicatorArr.size()]) : null;
					}
				}
			}
			transaction.commit();
			if (indicators != null) {
				indicatorCounter = 0;
				return indicators.length;
			}
		} catch (FinderException e) {
			if (transaction != null) {
				try {
					transaction.commit();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			return 0;
		} catch (Exception e) {
			if (transaction != null) {
				try {
					transaction.commit();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			e.printStackTrace();
			System.out.println("KPIIndicatorManagement : loadAllKPIIndicators : " + e.getMessage());
		}
		return -1;
	}

	public int createKPIIndicator(String name, String organizationId, String responsibleUserId, String period, String description, String inputMethod, String targetValue, String targetType, String adminUserDN, String[] sectorsIds, KPIPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		long currentTime = System.currentTimeMillis();
		try {
			transaction = new DBTransaction();
			KPIOrganization organization = null;
			KPIOrganizationUser organizationUser = null;
			KPISector[] sectors = null;
			try {
				organization = KPIOrganization.findById(organizationId, transaction);
			} catch (FinderException e) {
			}
			if (organization == null) {
				throw new Exception(bundle.getString("organization.with.id.not.found") + " " + organizationId + "!");
			}
			try {
				organizationUser = KPIOrganizationUser.findById(responsibleUserId, transaction);
			} catch (FinderException e) {
			}
			if (organizationUser == null) {
				throw new Exception(bundle.getString("user.with.id.not.found") + " " + responsibleUserId + "!");
			}
			if (!organization.getId().equals(organizationUser.getKpiOrganizationId())) {
				throw new Exception(bundle.getString("user.not.from.organization") + " " + organization.getOrganizationName() + "!");
			}
			StringBuffer tmpSectorIds = new StringBuffer();
			for (int i = 0; i < sectorsIds.length; i++) {
				if (tmpSectorIds.toString().length() > 0) {
					tmpSectorIds.append(",");
				}
				tmpSectorIds.append(sectorsIds[i]);
			}
			try {
				sectors = KPISector.findAllByIds(tmpSectorIds.toString(), transaction);
			} catch (FinderException e) {
			}
			if (sectors == null || sectors.length != sectorsIds.length) {
				throw new Exception(bundle.getString("indicator.some.sectors.not.found"));
			}
			KPIIndicator kpiIndicator = new KPIIndicator();
			kpiIndicator.setIndicatorName(name.trim());
			kpiIndicator.setKpiOrganizationId(organizationId);
			kpiIndicator.setResponsibleUserId(responsibleUserId);
			kpiIndicator.setPeriod(period.trim());
			kpiIndicator.setDescription((description != null) ? description.trim() : null);
			kpiIndicator.setInputMethod(inputMethod);
			kpiIndicator.setTargetValue(targetValue.trim());
			kpiIndicator.setTargetType(targetType.trim());
			kpiIndicator.setAdminUserDN(adminUserDN);
			kpiIndicator.setCreationDate(KPIUtils.timeMillisToTimestamp(currentTime));
			kpiIndicator.create(transaction);

			KPISectorIndicator sectorIndicator = null;
			for (int i = 0; i < sectors.length; i++) {
				sectorIndicator = new KPISectorIndicator();
				sectorIndicator.setKpiSectorId(sectors[i].getId());
				sectorIndicator.setKpiIndicatorId(kpiIndicator.getId());
				sectorIndicator.create(transaction);
			}
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println("KPIIndicatorManagement : createKPIIndicator : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return -1;
	}

	public int updateKPIIndicator(String kpiIndicatorId, String name, String organizationId, String responsibleUserId, String period, String description, String targetValue, String targetType, String[] sectorsIds, KPIPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		try {
			transaction = new DBTransaction();
			KPIIndicator kpiIndicator = null;
			KPIOrganization organization = null;
			KPIOrganizationUser organizationUser = null;
			KPISector[] sectors = null;
			try {
				kpiIndicator = KPIIndicator.findById(kpiIndicatorId, transaction);
			} catch (FinderException e) {
			}
			if (kpiIndicator == null) {
				throw new Exception(bundle.getString("indicator.with.id.not.found") + " " + kpiIndicatorId + "!");
			}
			try {
				organization = KPIOrganization.findById(organizationId, transaction);
			} catch (FinderException e) {
			}
			if (organization == null) {
				throw new Exception(bundle.getString("organization.with.id.not.found") + " " + organizationId + "!");
			}
			try {
				organizationUser = KPIOrganizationUser.findById(responsibleUserId, transaction);
			} catch (FinderException e) {
			}
			if (organizationUser == null) {
				throw new Exception(bundle.getString("user.with.id.not.found") + " " + responsibleUserId + "!");
			}
			if (!organization.getId().equals(organizationUser.getKpiOrganizationId())) {
				throw new Exception(bundle.getString("user.not.from.organization") + " " + organization.getOrganizationName() + "!");
			}
			StringBuffer tmpSectorIds = new StringBuffer();
			for (int i = 0; i < sectorsIds.length; i++) {
				if (tmpSectorIds.toString().length() > 0) {
					tmpSectorIds.append(",");
				}
				tmpSectorIds.append(sectorsIds[i]);
			}
			try {
				sectors = KPISector.findAllByIds(tmpSectorIds.toString(), transaction);
			} catch (FinderException e) {
			}
			if (sectors == null || sectors.length != sectorsIds.length) {
				throw new Exception(bundle.getString("indicator.some.sectors.not.found"));
			}
			kpiIndicator.setIndicatorName(name.trim());
			kpiIndicator.setKpiOrganizationId(organizationId);
			kpiIndicator.setResponsibleUserId(responsibleUserId);
			kpiIndicator.setPeriod(period.trim());
			kpiIndicator.setDescription((description != null) ? description.trim() : null);
			kpiIndicator.setTargetValue(targetValue.trim());
			kpiIndicator.setTargetType(targetType.trim());
			kpiIndicator.store(transaction);

			KPISectorIndicator sectorIndicator = new KPISectorIndicator();
			sectorIndicator.removeConditional("kpiIndicatorId=" + kpiIndicatorId, transaction);
			for (int i = 0; i < sectors.length; i++) {
				sectorIndicator = new KPISectorIndicator();
				sectorIndicator.setKpiSectorId(sectors[i].getId());
				sectorIndicator.setKpiIndicatorId(kpiIndicator.getId());
				sectorIndicator.create(transaction);
			}
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println("KPIIndicatorManagement : updateKPIIndicator : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return -1;
	}

	public int removeKPIIndicator(String kpiIndicatorId, KPIPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		int result = -1;
		try {
			transaction = new DBTransaction();
			KPIIndicator tmpKPIIndicator = null;
			try {
				tmpKPIIndicator = KPIIndicator.findById(kpiIndicatorId, transaction);
			} catch (FinderException e) {
			}
			if (tmpKPIIndicator != null) {
				KPISectorIndicator kpiSectorIndicator = new KPISectorIndicator();
				kpiSectorIndicator.removeConditional("kpiIndicatorId=" + kpiIndicatorId, transaction);

				KPIIndicatorValue[] kpiIndicatorValues = null;
				try {
					kpiIndicatorValues = KPIIndicatorValue.findAllByIndicatorId(kpiIndicatorId, transaction);
				} catch (FinderException e) {
				}
				if (kpiIndicatorValues != null && kpiIndicatorValues.length > 0) {
					sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("indicator.values.exists")));
					throw new Exception("Indicator Values Exists For Current Indicator!");
				}
				KPIIndicatorHit kpiIndicatorHit = new KPIIndicatorHit();
				kpiIndicatorHit.removeConditional("kpiIndicatorId=" + kpiIndicatorId, transaction);
				
				tmpKPIIndicator.remove(transaction);
				result = 1;
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_INFORMATION, "\"" + tmpKPIIndicator.getIndicatorName() + "\" " + bundle.getString("deleted.successfully")));
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("indicator.with.id.not.found") + " " + kpiIndicatorId + "!"));
			}
			transaction.commit();
		} catch (Exception e) {
			if (sessionBean.getMessage() == null) {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("system.error")));
			}
			e.printStackTrace();
			try {
				result = -1;
				if (transaction != null)
					transaction.rollback();
			} catch (SQLException e1) {
				System.out.println("KPIIndicatorManagement : removeKPIIndicator : " + e1.getMessage());
			}
		}
		System.out.println("result = " + result);
		return result;
	}

	public KPIIndicator[] getKPIIndicators() {
		return indicators;
	}

	public void setKPIIndicators(KPIIndicator[] indicators) {
		this.indicators = indicators;
	}

}
