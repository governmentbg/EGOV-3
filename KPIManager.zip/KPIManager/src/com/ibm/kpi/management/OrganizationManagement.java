package com.ibm.kpi.management;

import java.sql.SQLException;
import java.util.ResourceBundle;

import com.ibm.kpi.bean.Message;
import com.ibm.kpi.db.DBTransaction;
import com.ibm.kpi.db.FinderException;
import com.ibm.kpi.dbo.KPIIndicator;
import com.ibm.kpi.dbo.KPIOrganization;
import com.ibm.kpi.dbo.KPIOrganizationUser;
import com.ibm.kpimanager.KPIConstants;
import com.ibm.kpimanager.KPIPortletSessionBean;

public class OrganizationManagement {

	private KPIOrganization[] organizations = null;
	private int organizationCounter = 0;
	private KPIOrganization current = null;

	public int getKPIOrganizationCounter() {
		return organizationCounter;
	}

	public void setKPIOrganizationCounter(int organizationCounter) {
		this.organizationCounter = organizationCounter;
	}

	public void setCurrentKPIOrganization(KPIOrganization object) {
		current = object;
	}

	public KPIOrganization getCurrentKPIOrganization() {
		if (current == null)
			current = new KPIOrganization();
		return current;
	}

	public boolean selectNextKPIOrganization() {
		if (organizations != null) {
			if (organizationCounter < organizations.length) {
				setCurrentKPIOrganization(organizations[organizationCounter++]);
				return true;
			}
		}
		return false;
	}

	public int loadKPIOrganizationById(String kpiOrganizationId, DBTransaction transaction) {
		try {
			KPIOrganization tmpKPIOrganization = KPIOrganization.findById(kpiOrganizationId, transaction);
			if (tmpKPIOrganization != null) {
				setCurrentKPIOrganization(tmpKPIOrganization);
				return 1;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			System.out.println("KPIOrganizationManagement : loadKPIOrganizationById : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

	public int loadAllKPIOrganizations() {
		try {
			organizationCounter = 0;
			organizations = null;
			organizations = KPIOrganization.findAll(null);
			if (organizations != null) {
				organizationCounter = 0;
				return organizations.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("KPIOrganizationManagement : loadAllKPIOrganizations : " + e.getMessage());
		}
		return -1;
	}

	public int loadAllKPIOrganizationsByFilter(String filterType, String filterValue) {
		try {
			organizationCounter = 0;
			organizations = null;
			organizations = KPIOrganization.findAllByFilter(filterType, filterValue, null);
			if (organizations != null) {
				organizationCounter = 0;
				return organizations.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("KPIOrganizationManagement : loadAllKPIOrganizations : " + e.getMessage());
		}
		return -1;
	}

	public int createKPIOrganization(String name, String description) {
		DBTransaction transaction = null;
		try {
			transaction = new DBTransaction();
			KPIOrganization kpiOrganization = new KPIOrganization();
			kpiOrganization.setOrganizationName(name.trim());
			if (description != null) {
				kpiOrganization.setOrganizationDescription(description.trim());
			}
			kpiOrganization.create(transaction);
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println("KPIOrganizationManagement : createKPIOrganization : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return -1;
	}

	public int updateKPIOrganization(String kpiOrganizationId, String name, String description) {
		DBTransaction transaction = null;
		int result = -1;
		try {
			KPIOrganization kpiOrganization = null;
			try {
				kpiOrganization = KPIOrganization.findById(kpiOrganizationId, transaction);
			} catch (FinderException e) {
			} catch (Exception e) {
				return result;
			}
			if (kpiOrganization == null) {
				return result;
			}

			transaction = new DBTransaction();
			kpiOrganization.setOrganizationName(name.trim());
			if (description != null) {
				kpiOrganization.setOrganizationDescription(description.trim());
			}
			kpiOrganization.store(transaction);
			transaction.commit();
			result = 1;
		} catch (Exception e) {
			System.out.println("KPIOrganizationManagement : updateKPIOrganization : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return result;
	}

	public int removeKPIOrganization(String kpiOrganizationId, KPIPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		int result = -1;
		try {
			transaction = new DBTransaction();
			KPIOrganization tmpKPIOrganization = null;
			try {
				tmpKPIOrganization = KPIOrganization.findById(kpiOrganizationId, transaction);
			} catch (FinderException e) {
			}
			if (tmpKPIOrganization != null) {
				KPIOrganizationUser[] kpiOrganizationUsers = null;
				try {
					kpiOrganizationUsers = KPIOrganizationUser.findAllByOrganizationId(kpiOrganizationId, transaction);
				} catch (FinderException e) {
				}
				if (kpiOrganizationUsers != null && kpiOrganizationUsers.length > 0) {
					throw new Exception(bundle.getString("organization.members.exists") + " " + tmpKPIOrganization.getOrganizationName() + "!");
				}

				KPIIndicator[] kpiIndicators = null;
				try {
					kpiIndicators = KPIIndicator.findAllByOrganizationId(kpiOrganizationId, transaction);
				} catch (FinderException e) {
				}
				if (kpiIndicators != null && kpiIndicators.length > 0) {
					throw new Exception(bundle.getString("organization.indicators.exists") + " \"" + tmpKPIOrganization.getOrganizationName() + "\"!");
				}
				tmpKPIOrganization.remove(transaction);
				result = 1;
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_INFORMATION, "\"" + tmpKPIOrganization.getOrganizationName() + "\" " + bundle.getString("deleted.successfully")));
			} else {
				throw new Exception(bundle.getString("organization.with.id.not.found") + " " + kpiOrganizationId + "!");
			}
			transaction.commit();
		} catch (Exception e) {
			sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
			try {
				result = 1;
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("KPIOrganizationManagement : removeKPIOrganization : " + e1.getMessage());
			}
		}
		return result;
	}

	public KPIOrganization[] getKPIOrganizations() {
		return organizations;
	}

	public void setKPIOrganizations(KPIOrganization[] organizations) {
		this.organizations = organizations;
	}

}
