package com.ibm.kpi.management;

import java.sql.SQLException;
import java.util.ResourceBundle;

import com.ibm.kpi.bean.Message;
import com.ibm.kpi.db.DBTransaction;
import com.ibm.kpi.db.FinderException;
import com.ibm.kpi.dbo.KPIOrganization;
import com.ibm.kpi.dbo.KPIOrganizationUser;
import com.ibm.kpi.utils.Base64;
import com.ibm.kpimanager.KPIConstants;
import com.ibm.kpimanager.KPIPortletSessionBean;

public class OrganizationUserManagement {
	
	private KPIOrganizationUser[] organizationUsers = null;
	private int organizationCounter = 0;
	private KPIOrganizationUser current = null;

	public int getOrganizationUserCounter() {
		return organizationCounter;
	}

	public void setOrganizationUserCounter(int organizationCounter) {
		this.organizationCounter = organizationCounter;
	}

	public void setCurrentOrganizationUser(KPIOrganizationUser object) {
		current = object;
	}

	public KPIOrganizationUser getCurrentOrganizationUser() {
		if (current == null)
			current = new KPIOrganizationUser();
		return current;
	}

	public boolean selectNextOrganizationUser() {
		if (organizationUsers != null) {
			if (organizationCounter < organizationUsers.length) {
				setCurrentOrganizationUser(organizationUsers[organizationCounter++]);
				return true;
			}
		}
		return false;
	}

	public int loadOrganizationUserById(String оrganizationUserId, DBTransaction transaction) {
		try {
			KPIOrganizationUser tmpKPIOrganizationUser = KPIOrganizationUser.findById(оrganizationUserId, transaction);
			if (tmpKPIOrganizationUser != null) {
				setCurrentOrganizationUser(tmpKPIOrganizationUser);
				return 1;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			System.out.println("KPIOrganizationUserManagement : loadOrganizationUserById : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

	public int loadOrganizationUserByDN(String оrganizationUserDN, DBTransaction transaction) {
		try {
			KPIOrganizationUser tmpKPIOrganizationUser = KPIOrganizationUser.findByUserDN(оrganizationUserDN, transaction);
			if (tmpKPIOrganizationUser != null) {
				setCurrentOrganizationUser(tmpKPIOrganizationUser);
				return 1;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			System.out.println("KPIOrganizationUserManagement : loadOrganizationUserByDN : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

	public int loadAllOrganizationUsers() {
		try {
			organizationCounter = 0;
			organizationUsers = null;
			organizationUsers = KPIOrganizationUser.findAll(null);
			if (organizationUsers != null) {
				organizationCounter = 0;
				return organizationUsers.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("KPIOrganizationUserManagement : loadAllOrganizationUsers : " + e.getMessage());
		}
		return -1;
	}

	public int loadAllOrganizationUsersByFilter(String organizationId, String filterType, String filterValue) {
		try {
			organizationCounter = 0;
			organizationUsers = null;
			organizationUsers = KPIOrganizationUser.findAllByFilter(organizationId, filterType, filterValue, null);
			if (organizationUsers != null) {
				organizationCounter = 0;
				return organizationUsers.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("KPIOrganizationUserManagement : loadAllOrganizationUsersByFilter : " + e.getMessage());
		}
		return -1;
	}

	public int addOrganizationUsers(String organizationId, String[] userDNs, KPIPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		KPIOrganization organization = null;
		try {			
			transaction = new DBTransaction();
			try {
				organization = KPIOrganization.findById(organizationId, transaction);
			} catch (FinderException e) {				
			}
			if (organization == null) {
				throw new Exception(bundle.getString("organization.with.id.not.found") + " " + organizationId);
			}
			KPIOrganizationUser[] organizationUsers = null;
			try {
				StringBuffer tmpUserDNs = new StringBuffer();
				for (int i = 0; i < userDNs.length; i++) {
					if (tmpUserDNs.toString().length() > 0) {
						tmpUserDNs.append(",");
					}
					tmpUserDNs.append("'" + Base64.decode(userDNs[i]) + "'");
				}
				organizationUsers = KPIOrganizationUser.findAllByUserDNs(tmpUserDNs.toString(), transaction);
			} catch (FinderException e) {				
			}
			if (organizationUsers != null && organizationUsers.length > 0) {
				KPIOrganization tmpOrganization = null;
				try {
					tmpOrganization = KPIOrganization.findById(organizationUsers[0].getKpiOrganizationId(), transaction);
				} catch (FinderException e) {
				}			
				throw new Exception(organizationUsers[0].getUserDN() + " " + bundle.getString("is.member.of.organization") + " " + ((tmpOrganization != null) ? "\"" + tmpOrganization.getOrganizationName() + "\"" : "") + "!");
			}
			KPIOrganizationUser organizationUser = null;
			String currentUserDN = null;
			for (int i = 0; i < userDNs.length; i++) {
				currentUserDN = Base64.decode(userDNs[i].trim());
				organizationUser = new KPIOrganizationUser();
				organizationUser.setKpiOrganizationId(organization.getId());
				organizationUser.setUserDN(currentUserDN);
				organizationUser.setUserType(KPIConstants.USER_ROLE_USER);
				organizationUser.create(transaction);
			}
			if (userDNs.length == 1) {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_INFORMATION, "\"" + bundle.getString("organization.user.member") + "\" " + bundle.getString("added.successfully")));
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_INFORMATION, "\"" + bundle.getString("organization.user.members") + "\" " + bundle.getString("multiple.added.successfully")));
			}
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println("KPIOrganizationUserManagement : addOrganizationUsers : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
		}
		return -1;
	}

	public int updateOrganizationUser(String kpiOrganizationId, String userType) {
		DBTransaction transaction = null;
		int result = -1;
		try {
			KPIOrganizationUser kpiOrganization = null;
			try {
				kpiOrganization = KPIOrganizationUser.findById(kpiOrganizationId, transaction);
			} catch (FinderException e) {
			} catch (Exception e) {
				return result;
			}
			if (kpiOrganization == null) {				
				return result;
			}
			
			transaction = new DBTransaction();
			kpiOrganization.setUserType(userType);
			kpiOrganization.store(transaction);
			transaction.commit();
			result = 1;
		} catch (Exception e) {
			System.out.println("KPIOrganizationUserManagement : updateOrganizationUser : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
		return result;
	}

	public int removeOrganizationUser(String kpiOrganizationUserId, KPIPortletSessionBean sessionBean, ResourceBundle bundle) {
		DBTransaction transaction = null;
		int result = -1;
		try {
			transaction = new DBTransaction();
			KPIOrganizationUser tmpKPIOrganizationUser = null;
			try {
				tmpKPIOrganizationUser = KPIOrganizationUser.findById(kpiOrganizationUserId, transaction);
			} catch (FinderException e) {
			}
			if (tmpKPIOrganizationUser != null) {
				tmpKPIOrganizationUser.remove(transaction);
				result = 1;
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_INFORMATION, tmpKPIOrganizationUser.getUserDN() + " " + bundle.getString("removed.successfully")));
			} else {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, bundle.getString("user.with.id.not.found") + " " + kpiOrganizationUserId + "!"));
			}
			transaction.commit();
		} catch (Exception e) {
			try {
				result = -1;
				if (transaction != null)
					transaction.rollback();
			} catch (SQLException e1) {
				System.out.println("KPIOrganizationUserManagement : removeOrganizationUser : " + e1.getMessage());
			}
		}
		System.out.println("result = " + result);
		return result;
	}

	public KPIOrganizationUser[] getKPIOrganizationUsers() {
		return organizationUsers;
	}

	public void setKPIOrganizationUsers(KPIOrganizationUser[] organizationUsers) {
		this.organizationUsers = organizationUsers;
	}

}
