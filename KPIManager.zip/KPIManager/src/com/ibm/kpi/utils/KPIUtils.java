package com.ibm.kpi.utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map.Entry;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import javax.portlet.PortletPreferences;
import javax.portlet.PortletSession;
import javax.portlet.RenderRequest;

import com.ibm.kpi.bean.Message;
import com.ibm.kpimanager.KPIConstants;
import com.ibm.kpimanager.KPIManagerPortlet;
import com.ibm.kpimanager.KPIPortletSessionBean;
import com.ibm.portal.serialize.SerializationException;
import com.ibm.portal.um.Group;
import com.ibm.portal.um.PumaController;
import com.ibm.portal.um.PumaLocator;
import com.ibm.portal.um.User;
import com.ibm.wps.services.identification.IdentificationMgr;

public class KPIUtils {

	private static SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH);
	private static SimpleDateFormat dateTimeFormatYYYY_MM_dd = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);

	public static long date_yyyy_MM_dd_ToTimeMillis(final String date, final boolean beginDay) {
		try {
			final StringTokenizer st = new StringTokenizer(date, "-");
			if (st.countTokens() != 3) {
				return 0;
			}
			final int year = Integer.parseInt(st.nextToken());
			final int month = Integer.parseInt(st.nextToken());
			final int day = Integer.parseInt(st.nextToken());
			final Calendar cal = Calendar.getInstance();
			cal.set(Calendar.DAY_OF_MONTH, day);
			cal.set(Calendar.MONTH, month - 1);
			cal.set(Calendar.YEAR, year);

			if (beginDay) {
				cal.set(Calendar.HOUR_OF_DAY, 0);
				cal.set(Calendar.MINUTE, 0);
				cal.set(Calendar.SECOND, 0);
				cal.set(Calendar.MILLISECOND, 0);
			} else {
				cal.set(Calendar.HOUR_OF_DAY, 23);
				cal.set(Calendar.MINUTE, 59);
				cal.set(Calendar.SECOND, 59);
				cal.set(Calendar.MILLISECOND, 999);
			}
			return cal.getTime().getTime();
		} catch (final NumberFormatException e) {
			e.printStackTrace();
		}
		return 0;
	}

	public static long date_TimestampToTimeMillis(final String s) {
		if (s != null) {
			try {
				return dateTimeFormat.parse(s).getTime();
			} catch (final Exception e) {
			}
		}
		return 0;
	}

	public static String timeMillisToTimestamp(final String millis) {
		try {
			final long l = Long.parseLong(millis);
			return dateTimeFormat.format(new Date(l));
		} catch (final Exception e) {
			System.out.println("KPIUtils : timeMillisToTimestamp : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static String timeMillisToTimestamp(final long millis) {
		try {

			return dateTimeFormat.format(new Date(millis));
		} catch (final Exception e) {
			System.out.println("KPIUtils : timeMillisToTimestamp : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static String timeMillisToYYYY_MM_DD_HH_MM_SS(final String timeMillis) {
		try {
			final Date date = new Date(Long.parseLong(timeMillis));
			return dateTimeFormat.format(date);
		} catch (Exception e) {
			System.out.println("KPIUtils : timeMillisToYYYY_MM_DD_HH_MM_SS : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static String timeMillisToYYYY_MM_DD_HH_MM_SS(final long timeMillis) {
		try {
			final Date date = new Date(timeMillis);
			return dateTimeFormat.format(date);
		} catch (Exception e) {
			System.out.println("KPIUtils : timeMillisToYYYY_MM_DD_HH_MM_SS : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static String timeMillisToYYYY_MM_DD(final long timeMillis) {
		try {
			final Date date = new Date(timeMillis);
			return dateTimeFormatYYYY_MM_dd.format(date);
		} catch (Exception e) {
			System.out.println("KPIUtils : timeMillisToYYYY_MM_DD : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static void loadPreferences(RenderRequest request, ResourceBundle bundle) {
		PortletPreferences portletPreferences = request.getPreferences();
		if (portletPreferences != null) {
			KPIManagerPortlet.adminGroupName = portletPreferences.getValue(KPIManagerPortlet.SETTING_PARAMETER_ADMIN_GROUP_NAME, null);
			KPIManagerPortlet.maxItems = portletPreferences.getValue(KPIManagerPortlet.SETTING_PARAMETER_MAX_ITEMS, null);
			KPIManagerPortlet.language = portletPreferences.getValue(KPIManagerPortlet.SETTING_PARAMETER_LANGUAGE, KPIConstants.LANGUAGE_BG);
			KPIManagerPortlet.debug = "1".equals(portletPreferences.getValue(KPIManagerPortlet.SETTING_PARAMETER_DEBUG, "0"));
			String resultsPerPage = portletPreferences.getValue(KPIManagerPortlet.SETTING_PARAMETER_RESULTS_PER_PAGE, "10");			
			if (KPIManagerPortlet.adminGroupName != null && KPIManagerPortlet.adminGroupName.trim().length() > 0) {
				if (resultsPerPage != null && resultsPerPage.trim().length() > 0) {
					try {
						KPIManagerPortlet.resultsPerPage = Integer.parseInt(resultsPerPage);
					} catch (NumberFormatException e) {
					}
				}
				if (KPIManagerPortlet.maxItems != null && KPIManagerPortlet.maxItems.trim().length() > 0) {
					int maxItems = 0;
					try {
						maxItems = Integer.parseInt(KPIManagerPortlet.maxItems);
						if (KPIManagerPortlet.resultsPerPage > maxItems) {
							KPIManagerPortlet.resultsPerPage = maxItems;
						}
					} catch (NumberFormatException e) {
					}
				} 
				Group adminGroup = getGroupByCN(KPIManagerPortlet.adminGroupName);
				if (adminGroup != null) {
					KPIManagerPortlet.adminGroup = adminGroup;
					KPIManagerPortlet.groupsLoaded = true;
					KPIManagerPortlet.preferencesLoaded = true;
				} else {
					PortletSession session = request.getPortletSession();
					if (session != null) {						
						KPIPortletSessionBean sessionBean = (KPIPortletSessionBean) session.getAttribute(KPIManagerPortlet.SESSION_BEAN);
						if (sessionBean == null) {
							sessionBean = new KPIPortletSessionBean();
							session.setAttribute(KPIManagerPortlet.SESSION_BEAN, sessionBean);
						}
						sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_WARNING, "\"" + KPIManagerPortlet.adminGroupName + "\" " + bundle.getString("configured.group.not.found")));
					}					
				}
				return;
			}
		}
		KPIManagerPortlet.groupsLoaded = false;
		KPIManagerPortlet.preferencesLoaded = false;
	}

	public static void loadAdminGroup() {
		Group adminGroup = getGroupByCN(KPIManagerPortlet.adminGroupName);
		if (adminGroup != null) {
			KPIManagerPortlet.adminGroup = adminGroup;
		}
	}

//	public static void loadUsersGroup() {
//		Group usersGroup = getGroupByCN(KPIManagerPortlet.usersGroupName);
//		if (usersGroup != null) {
//			KPIManagerPortlet.usersGroup = usersGroup;
//		}
//	}

	private static Group getGroupByCN(String name) {
		if (name == null || name.trim().length() == 0) {
			return null;
		}
		PumaLocator pumaLocator = KPIManagerPortlet.getPumaHome().getLocator();
		try {
			java.util.List<Group> groupList = pumaLocator.findGroupsByAttribute("cn", name.trim());
			if (groupList != null && groupList.size() > 0) {
				return (Group) groupList.get(0);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return null;
	}

	public static boolean addUserToGroup(com.ibm.portal.um.User user, com.ibm.portal.um.Group group) {
		if (user == null || group == null)
			return false;
		try {
			java.util.List<com.ibm.portal.um.User> list = new ArrayList<com.ibm.portal.um.User>();
			list.add(user);
			PumaController pumaController = KPIManagerPortlet.getPumaHome().getController();
			pumaController.addToGroup(group, list);
			return true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return false;
	}

	public static boolean removeUserFromGroup(com.ibm.portal.um.User user, com.ibm.portal.um.Group group) {
		if (user == null || group == null)
			return false;
		try {
			java.util.List<com.ibm.portal.um.User> list = new ArrayList<com.ibm.portal.um.User>();
			list.add(user);
			PumaController pumaController = KPIManagerPortlet.getPumaHome().getController();
			pumaController.removeFromGroup(group, list);
			return true;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		return false;
	}

	public static User findUserByDN(String dn, com.ibm.portal.um.PumaHome pumaHome) {
		User user = null;
		try {
			PumaLocator pumaLocator = pumaHome.getLocator();
			user = pumaLocator.findUserByIdentifier(dn);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}

	public static String getUserUID(com.ibm.portal.um.User user, com.ibm.portal.um.PumaProfile pumaProfile) {
		return (String) getUserAttribute(user, pumaProfile, "uid");
	}

	public static String getUserCN(com.ibm.portal.um.User user, com.ibm.portal.um.PumaProfile pumaProfile) {
		return (String) getUserAttribute(user, pumaProfile, "cn");
	}

	public static String getUserLastName(com.ibm.portal.um.User user, com.ibm.portal.um.PumaProfile pumaProfile) {
		return (String) getUserAttribute(user, pumaProfile, "sn");
	}

	public static Object getUserAttribute(com.ibm.portal.um.User user, com.ibm.portal.um.PumaProfile pumaProfile, String attributeName) {
		java.util.List<String> attributesNamesList;
		try {
			attributesNamesList = pumaProfile.getDefinedUserAttributeNames();
			java.util.Map<String, Object> userInfo = (java.util.Map<String, Object>) pumaProfile.getAttributes((com.ibm.portal.um.Principal) user, attributesNamesList);
			if (userInfo != null) {
				return userInfo.get(attributeName);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static void printUserAttributes(com.ibm.portal.um.User user, com.ibm.portal.um.PumaProfile pumaProfile) {
		java.util.List<String> attributesNamesList;
		try {
			attributesNamesList = pumaProfile.getDefinedUserAttributeNames();
			java.util.Map<String, Object> userInfo = (java.util.Map<String, Object>) pumaProfile.getAttributes((com.ibm.portal.um.Principal) user, attributesNamesList);
			if (userInfo != null) {
				KPIUtils.println("UID => " + userInfo.get("uid"));
				Iterator<Entry<String, Object>> it = userInfo.entrySet().iterator();
				Object tmp = null;
				while (it.hasNext()) {
					tmp = it.next();
					System.out.println(tmp);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static java.util.ArrayList<String> getUserGroupMembership(com.ibm.portal.um.User user) {
		PumaLocator pumaLocator = KPIManagerPortlet.getPumaHome().getLocator();
		java.util.List<com.ibm.portal.um.Group> userGroupsList;
		try {
			userGroupsList = pumaLocator.findGroupsByPrincipal(user, false);
			KPIUtils.println("userGroupsList=" + (userGroupsList != null ? userGroupsList.size() : "NULL"));
			if (userGroupsList != null && userGroupsList.size() > 0) {
				java.util.List<String> attribs = new java.util.ArrayList<String>();
				attribs.add("cn");
				java.util.Map<String, Object> groupAttr = null;
				String groupCN = null;
				com.ibm.portal.um.Group tmpGroup = null;
				java.util.Iterator<com.ibm.portal.um.Group> it = userGroupsList.iterator();
				java.util.ArrayList<String> groupsCN = new ArrayList<String>();
				while (it.hasNext()) {
					groupAttr = null;
					tmpGroup = (com.ibm.portal.um.Group) it.next();
					KPIUtils.println("tmpGroup=" + (tmpGroup != null ? tmpGroup.getObjectID().getUniqueName() : "NULL"));
					try {
						groupAttr = KPIManagerPortlet.getPumaHome().getProfile().getAttributes(tmpGroup, attribs);
					} catch (Exception e) {
						System.out.println(e.getMessage());
						e.printStackTrace();
					}
					KPIUtils.println("groupAttr.size=" + (groupAttr != null ? groupAttr.size() : "NULL"));
					if (groupAttr != null) {
						groupCN = (String) groupAttr.get((Object) "cn");
						KPIUtils.println("group cn: " + groupCN);
						groupsCN.add(groupCN);
					}
				}
				return groupsCN;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String getStringObjectID(com.ibm.portal.ObjectID objectid) {
		if (objectid == null)
			return "";
		try {
			return IdentificationMgr.getIdentification().serialize(objectid, false);
		} catch (SerializationException e) {
			e.printStackTrace();
		}
		return "";
	}

	public static com.ibm.portal.ObjectID getObjectIDFromString(String s) {
		if (s == null || s.trim().length() == 0) {
			return null;
		}
		try {
			return IdentificationMgr.getIdentification().deserialize(s);
		} catch (SerializationException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static com.ibm.portal.ObjectID getObjectIDFromUniquename(String s) {
		return IdentificationMgr.getIdentification().resolveUniqueName(s);
	}

	public static com.ibm.portal.ObjectType getObjectTypeFromString(String s) {
		return IdentificationMgr.getIdentification().getObjectType(s);
	}

	public static int getCurrentPageNumber(int total, int currentPage, int resultsPerPage) {
		if (total > 0 && resultsPerPage > 0) {
			int totalPages = getTotalPages(total, resultsPerPage);
			if (totalPages < currentPage) {
				currentPage = totalPages;
			}
			return currentPage;
		}
		return 1;
	}

	public static int getTotalPages(int total, int resultsPerPage) {
		if (total > 0 && resultsPerPage > 0) {
			try {
				return (int) Math.ceil((double) total / (double) resultsPerPage);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return 1;
	}
	
	public static String getUserFriendlyIDFromDN(String dn) {
		if (dn != null && dn.trim().length() > 0) {
			int pos = dn.indexOf(","); 
			if (pos != -1) {
				dn = dn.substring(0, pos);
			}
			if (dn.startsWith("uid=")) {
				dn = dn.substring(4);
			} else if (dn.startsWith("cn=")) {
				dn = dn.substring(3);
			}
		}
		return dn;
	}
	
	public static String getFileExtension(String fileName) {
		if (fileName != null && fileName.trim().length() > 0) {
			fileName = fileName.trim();
			int pos = fileName.lastIndexOf('.');
			if (pos != -1) {
				return fileName.substring(pos + 1);
			}
		}
		return fileName;
	}
	
	public static void println(Object text) {
		if (KPIManagerPortlet.debug) {
			System.out.println(text);
		}
	}
}
