package com.ibm.kpi.dbo;

import java.util.Hashtable;

import com.ibm.kpi.db.DBTransaction;
import com.ibm.kpi.db.FinderException;
import com.ibm.kpi.db.PersistentObject;
import com.ibm.kpi.db.QueryComposer;
import com.ibm.kpi.db.QuerySet;
import com.ibm.kpimanager.KPIConstants;


public class KPISectorIndicator extends PersistentObject {
	private static String CLASS_NAME = KPISectorIndicator.class.getName();
    protected static String schema = KPIConstants._SCHEMANAME;
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
    static {
        table = "KPISECTORINDICATOR";
        sequenceName = "SEQ_KPISECTORINDICATORID";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "KPISECTORINDICATORID");
        columnMap.put("kpiSectorId", "KPISECTORID");
        columnMap.put("kpiIndicatorId", "KPIINDICATORID");
        querySet = QueryComposer.composeAll(schema, table, sequenceName, columnMap);
    }
	
    public KPISectorIndicator() {
        super(querySet);
    }
    
	private String kpiSectorId = null;
	private String kpiIndicatorId = null;
	
	public String getKpiSectorId() {
		return kpiSectorId;
	}

	public void setKpiSectorId(String kpiSectorId) {
		this.kpiSectorId = kpiSectorId;
	}

	public String getKpiIndicatorId() {
		return kpiIndicatorId;
	}

	public void setKpiIndicatorId(String kpiIndicatorId) {
		this.kpiIndicatorId = kpiIndicatorId;
	}

	public static KPISectorIndicator findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
        return (KPISectorIndicator) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
    }

	public static KPISectorIndicator[] findAllByIndicatorIds(final String ids, final DBTransaction transaction) throws FinderException, Exception {
		return findKPISectorIndicators(columnMap.get("kpiIndicatorId") + " IN (" + ids + ")",  transaction);
	}

	public static KPISectorIndicator[] findAllBySectorId(final String sectorId, final DBTransaction transaction) throws FinderException, Exception {
		return findKPISectorIndicators(columnMap.get("kpiSectorId") + " = " + sectorId,  transaction);
	}
	
	public static KPISectorIndicator[] findKPISectorIndicators(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final KPISectorIndicator[] kpiSectorIndicators = new KPISectorIndicator[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				kpiSectorIndicators[i] = (KPISectorIndicator) tmp[i];
			}
			return kpiSectorIndicators;
		}
		return null;
	}
	
	public static KPISectorIndicator[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple("1=1", CLASS_NAME, transaction);
		if (tmp != null) {
			final KPISectorIndicator[] kpiSectorIndicators = new KPISectorIndicator[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				kpiSectorIndicators[i] = (KPISectorIndicator) tmp[i];
			} 
			return kpiSectorIndicators;
		} 
		return null;
	}
	
}
