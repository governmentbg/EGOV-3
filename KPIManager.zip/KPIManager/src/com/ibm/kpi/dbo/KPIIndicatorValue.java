package com.ibm.kpi.dbo;

import java.util.Hashtable;

import com.ibm.kpi.db.DBTransaction;
import com.ibm.kpi.db.FinderException;
import com.ibm.kpi.db.PersistentObject;
import com.ibm.kpi.db.QueryComposer;
import com.ibm.kpi.db.QuerySet;
import com.ibm.kpi.utils.KPIUtils;
import com.ibm.kpimanager.KPIConstants;

public class KPIIndicatorValue extends PersistentObject {
	private static String CLASS_NAME = KPIIndicatorValue.class.getName();
	protected static String schema = KPIConstants._SCHEMANAME;
	protected static String table;
	protected static Hashtable<String, String> columnMap;
	protected static String[] keyArray;
	protected static String sequenceName;
	public static QuerySet querySet;
	
	static {
		table = "KPIINDICATORVALUE";
		sequenceName = "SEQ_KPIINDICATORVALUEID";
		columnMap = new Hashtable<String, String>();
		columnMap.put("id", "KPIINDICATORVALUEID");
		columnMap.put("kpiIndicatorId", "KPIINDICATORID");
		columnMap.put("value", "VALUE");		
		columnMap.put("comments", "COMMENTS");
		columnMap.put("targetDate", "TARGETDATE");
		columnMap.put("inputMethod", "INPUTMETHOD");
		columnMap.put("userDN", "USERDN");
		columnMap.put("creationDate", "CREATIONDATE");
		querySet = QueryComposer.composeAll(schema, table, sequenceName, columnMap);
	}

	public KPIIndicatorValue() {
		super(querySet);
	}

	private String kpiIndicatorId = null;
	private String value = null;
	private String comments = null;
	private String targetDate = null;
	private String inputMethod = null;
	private String userDN = null;
	private String creationDate = null;
	private KPIAttachment[] attachments = null; // ONLY FOR BUSINESS PURPOSE...

	public String getKpiIndicatorId() {
		return kpiIndicatorId;
	}

	public void setKpiIndicatorId(String kpiIndicatorId) {
		this.kpiIndicatorId = kpiIndicatorId;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}
	
	public java.sql.Timestamp getTargetDate() {
		return (targetDate != null) ? new java.sql.Timestamp(Long.parseLong(targetDate)) : null;
	}

	public void setTargetDate(String targetDate) {
		this.targetDate = (targetDate != null) ? String.valueOf(KPIUtils.date_TimestampToTimeMillis(targetDate)) : null;
	}

	public String getInputMethod() {
		return inputMethod;
	}

	public void setInputMethod(String inputMethod) {
		this.inputMethod = inputMethod;
	}

	public String getUserDN() {
		return userDN;
	}

	public void setUserDN(String userDN) {
		this.userDN = userDN;
	}

	public java.sql.Timestamp getCreationDate() {
		return (creationDate != null) ? new java.sql.Timestamp(Long.parseLong(creationDate)) : null;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = (creationDate != null) ? String.valueOf(KPIUtils.date_TimestampToTimeMillis(creationDate)) : null;
	}
	
	public KPIAttachment[] getAttachments() {
		return attachments;
	}

	public void setAttachments(KPIAttachment[] attachments) {
		this.attachments = attachments;
	}

	public static KPIIndicatorValue findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (KPIIndicatorValue) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}

	public static KPIIndicatorValue[] findAllByIndicatorId(final String indicatorId, final DBTransaction transaction) throws FinderException, Exception {
		return findKPIIndicatorValues(columnMap.get("kpiIndicatorId") + " = " + indicatorId, transaction);
	}

	public static KPIIndicatorValue[] findAllByIndicatorIds(final String indicatorIds, final DBTransaction transaction) throws FinderException, Exception {
		return findKPIIndicatorValues(columnMap.get("kpiIndicatorId") + " IN (" + indicatorIds + ") ORDER BY " + columnMap.get("targetDate"), transaction);
	}

	public static KPIIndicatorValue[] findAllByFilter(String indicatorId, String filterType, String filterValue, String filterValue2, final DBTransaction transaction) throws FinderException, Exception {
		StringBuffer cond = new StringBuffer();
		cond.append(columnMap.get("kpiIndicatorId") + " = " + indicatorId);		
		if ("1".equals(filterType)) { // VALUE
			if (filterValue != null && filterValue.trim().length() > 0) {
				cond.append(" AND " + columnMap.get("value") + " LIKE '" + filterValue.trim().toLowerCase() + "%' ");
			}
		} else if ("2".equals(filterType)) { // TARGET DATE
			if (filterValue != null && filterValue.trim().length() > 0) {
				cond.append(" AND " + columnMap.get("targetDate") + ">='" + filterValue.trim() + "' ");
			}
			if (filterValue2 != null && filterValue2.trim().length() > 0) {
				cond.append(" AND " + columnMap.get("targetDate") + "<='" + filterValue2.trim() + "' ");
			}
		}
		cond.append(" ORDER BY " + columnMap.get("targetDate") + " DESC");
		return findKPIIndicatorValues(cond.toString(), transaction);
	}

	public static KPIIndicatorValue[] findKPIIndicatorValues(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final KPIIndicatorValue[] kpiIndicatorValues = new KPIIndicatorValue[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				kpiIndicatorValues[i] = (KPIIndicatorValue) tmp[i];
			}
			return kpiIndicatorValues;
		}
		return null;
	}

	public static KPIIndicatorValue[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple("1=1", CLASS_NAME, transaction);
		if (tmp != null) {
			final KPIIndicatorValue[] kpiIndicatorValues = new KPIIndicatorValue[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				kpiIndicatorValues[i] = (KPIIndicatorValue) tmp[i];
			}
			return kpiIndicatorValues;
		}
		return null;
	}

}
