package com.ibm.kpi.dbo;

import java.util.Hashtable;

import com.ibm.kpi.db.DBTransaction;
import com.ibm.kpi.db.FinderException;
import com.ibm.kpi.db.PersistentObject;
import com.ibm.kpi.db.QueryComposer;
import com.ibm.kpi.db.QuerySet;
import com.ibm.kpimanager.KPIConstants;


public class KPIAttachment extends PersistentObject {
	private static String CLASS_NAME = KPIAttachment.class.getName();
    protected static String schema = KPIConstants._SCHEMANAME;
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
    static {
        table = "KPIATTACHMENT";
        sequenceName = "SEQ_KPIATTACHMENTID";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "KPIATTACHMENTID");
        columnMap.put("kpiIndicatorValueId", "KPIINDICATORVALUEID");
        columnMap.put("fileName", "FILENAME");
        columnMap.put("attachment", "ATTACHMENT");
        columnMap.put("contentType", "CONTENTTYPE");
        querySet = QueryComposer.composeAll(schema, table, sequenceName, columnMap);
    }
	
    public KPIAttachment() {
        super(querySet);
    }
    
	private String kpiIndicatorValueId = null;
	private String fileName = null;
	private byte[] attachment = null;
	private String contentType = null;
	
	public String getKpiIndicatorValueId() {
		return kpiIndicatorValueId;
	}

	public void setKpiIndicatorValueId(String kpiIndicatorValueId) {
		this.kpiIndicatorValueId = kpiIndicatorValueId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public byte[] getAttachment() {
		return attachment;
	}

	public void setAttachment(byte[] attachment) {
		this.attachment = attachment;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public static KPIAttachment findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
        return (KPIAttachment) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
    }
	
	public static KPIAttachment[] findAllByIndicatorValueIds(final String indicatorValueIds, final DBTransaction transaction) throws FinderException, Exception {
		return  findKPIAttachments(columnMap.get("kpiIndicatorValueId") + " IN (" + indicatorValueIds + ")", transaction);
	}
	
	public static KPIAttachment[] findKPIAttachments(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final KPIAttachment[] kpiAttachments = new KPIAttachment[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				kpiAttachments[i] = (KPIAttachment) tmp[i];
			}
			return kpiAttachments;
		}
		return null;
	}
	
	public static KPIAttachment[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple("1=1", CLASS_NAME, transaction);
		if (tmp != null) {
			final KPIAttachment[] kpiAttachments = new KPIAttachment[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				kpiAttachments[i] = (KPIAttachment) tmp[i];
			} 
			return kpiAttachments;
		} 
		return null;
	}
	
}
