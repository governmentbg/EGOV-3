package com.ibm.kpi.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.ibm.kpi.dbo.KPIAttachment;
import com.ibm.kpimanager.KPIConstants;

public class QueryExecution {

	private static Connection getConnection() throws SQLException {

//		Connection con = DBconnection.getConnection();
		Connection con = DBPool.getConnection();
		if (con == null) {
			throw new SQLException("Connection is NULL");
		}
		return con;

	}

	public static void setSessionTimestampFormat(final DBTransaction transaction) throws FinderException, Exception {
		Connection connection = null;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				Statement statement = connection.createStatement();
				statement.executeUpdate("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH24:MI:SSXFF'");
				statement.close();
			} else {
				throw new Exception("Connection or query set is not initialized.");
			}
		} catch (final SQLException e) {
			throw new Exception(e.getMessage());
		} 
	}
	
	static public KPIAttachment[] findAllKPIAttachmentsByIndicatorValueId(String kpiIndicatorValueId, DBTransaction transaction) throws Exception {
		Connection con = null;
		try {
			if (transaction != null) {
				con = transaction.getConnection();
			} else {
				con = getConnection();
			}		
			if (con != null) {
				StringBuffer query = new StringBuffer();
				query.append("SELECT KPIATTACHMENTID, FILENAME FROM " + KPIConstants._SCHEMANAME + "KPIATTACHMENT WHERE KPIINDICATORVALUEID=" + kpiIndicatorValueId);
				System.out.println("QueryExecution: query => " + query.toString());

				Statement stmt = con.createStatement();

				ResultSet rs = stmt.executeQuery(query.toString());
				KPIAttachment[] attachments = null;

				if (rs != null) {
					KPIAttachment attachment = null;
					ArrayList<KPIAttachment> arr = new ArrayList<KPIAttachment>();
					while (rs.next()) {
						attachment = new KPIAttachment();
						attachment.setId(rs.getString("KPIATTACHMENTID"));
						attachment.setFileName(rs.getString("FILENAME"));
						arr.add(attachment);
					}
					attachments = (KPIAttachment[]) arr.toArray(new KPIAttachment[arr.size()]);
					rs.close();
				}
				stmt.close();
				return attachments;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		} finally {
			if (transaction == null) {
				try {
					releaseConnection(con);
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		}
		return null;
	}
	
	private static synchronized void releaseConnection(final Connection con) throws SQLException {
		try {
			con.close();
		} catch (SQLException e) {
			System.out.println("QueryExecution : releaseConnection : " + e.getMessage());
			throw e;
		}
	} // releaseConnection

}
