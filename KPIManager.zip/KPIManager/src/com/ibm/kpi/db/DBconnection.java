package com.ibm.kpi.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBconnection {
	
	static {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Error while loading the driver!!!");
			cnfe.printStackTrace();
		}
	}
	
	public static Connection getConnection() {
		String url		 = "*";
		String username  = "*";
		String password  = "*";
		try {
			Connection con = DriverManager.getConnection(url, username, password);
			con.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
			return con;
		} catch (SQLException sqle) {
			System.out.println("Error while connecting to the database!!!");
			sqle.printStackTrace();			
		}
		return null;
	}
}
