package com.ibm.kpi.db;

import java.util.Hashtable;

public class QuerySet {
    public QuerySet(String schema, String table, Hashtable columnMap, String[] keyArr) {
        this.schema = schema;
        this.table = table;
        this.columnMap = columnMap;
        this.keyArray = keyArr;
    }

    public Hashtable columnMap;
    public String schema;
    public String table;
    public String createQuery;
    public String loadQuery;
    public String storeQuery;
    public String removeQuery;
    public String findQuery;
    public String sequenceName;
    public String[] keyArray;
}
