package com.ibm.kpi.bean;

import java.util.Date;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(propOrder={"value", "comments", "targetDate"})
public class XMLValue {
	
	double value;
	String comments;
	Date targetDate;
	
	public double getValue() {
		return value;
	}

	@XmlElement
	public void setValue(double value) {
		this.value = value;
	}
	
	public String getComments() {
		return comments;
	}

	@XmlElement
	public void setComments(String comments) {
		this.comments = comments;
	}

	public Date getTargetDate() {
		return targetDate;
	}

	@XmlElement
	public void setTargetDate(Date targetDate) {
		this.targetDate = targetDate;
	}

}
