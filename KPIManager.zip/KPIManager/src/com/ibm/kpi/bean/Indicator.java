package com.ibm.kpi.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Indicator {
	
	List<XMLValue> values;

	@XmlElement(name="value")
	public List<XMLValue> getValues() {
		return values;
	}

	public void setValues(List<XMLValue> values) {
		this.values = values;
	}	    
}
