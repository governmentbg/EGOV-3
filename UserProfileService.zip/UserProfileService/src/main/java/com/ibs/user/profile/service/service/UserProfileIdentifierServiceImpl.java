package com.ibs.user.profile.service.service;

import java.util.Date;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ibs.user.profile.service.dao.db2.UserProfileIdentifierRepository;
import com.ibs.user.profile.service.model.db2.UserProfileIdentifier;
import com.ibs.user.profile.service.utils.EncryptorAESGCM;
import com.ibs.user.profile.service.utils.UserProfileServiceUtils;

@Service
public class UserProfileIdentifierServiceImpl implements UserProfileIdentifierService {
	
	@Autowired
	UserProfileIdentifierRepository userProfileIdentifierRepository;
	@Autowired
	UserProfileServiceUtils utils;
		
	@Override
	@Transactional
	public boolean updateUserProfileIdentifiers(List<UserProfileIdentifier> currentIdentifiers, Long userProfileId, String senderOID, JSONArray jsonIdentifiers, Date currentDate) {
		EncryptorAESGCM ascCls = new EncryptorAESGCM();
		UserProfileIdentifier userProfileIdentifier = null;
    	Long userProfileIdentifierId = null;
    	JSONObject jsonIdentifer = null;
		int type = 0;
		for (int i = 0; i < jsonIdentifiers.length(); i++) {	
			jsonIdentifer = jsonIdentifiers.getJSONObject(i);
			type = jsonIdentifer.getInt("identifierType");
			if (currentIdentifiers != null && currentIdentifiers.size() > 0) {
				for (int j = 0; j < currentIdentifiers.size(); j++) {
					if (type == currentIdentifiers.get(j).getIdentifierType()) {
						// Remove current identifier.
						userProfileIdentifierRepository.deleteById(currentIdentifiers.get(j).getUserProfileIdentifierId());
						break;
					}
					
				}
			}
			userProfileIdentifier = new UserProfileIdentifier();
			userProfileIdentifierId = userProfileIdentifierRepository.getSequenceNextVal();
			userProfileIdentifier.setUserProfileIdentifierId(userProfileIdentifierId);
			userProfileIdentifier.setUserProfileId(userProfileId);
			userProfileIdentifier.setIdentifier(ascCls.encryptEgovIdentifier(jsonIdentifer.getString("identifier")));
			userProfileIdentifier.setIdentifierCountryCode(jsonIdentifer.getString("identifierCountryCode"));
			userProfileIdentifier.setIdentifierType(jsonIdentifer.getInt("identifierType"));
			//userProfileIdentifier.setRnu(senderOID + "_" + currentDate.getTime());
			userProfileIdentifier.setRnu(utils.generateRNU());
			userProfileIdentifier.setDateCreated(currentDate);
			userProfileIdentifierRepository.save(userProfileIdentifier);
		}		
		return true;
	}
}
