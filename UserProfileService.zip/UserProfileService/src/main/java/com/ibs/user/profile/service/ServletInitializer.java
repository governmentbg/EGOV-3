package com.ibs.user.profile.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.context.MessageSourceAutoConfiguration;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication(exclude = MessageSourceAutoConfiguration.class)
public class ServletInitializer extends SpringBootServletInitializer {
	public static final boolean TEST_ENVIRONMENT = "TEST".equalsIgnoreCase(System.getProperty("environmentType"));
	public static final boolean STAGING_ENVIRONMENT = "STAGING".equalsIgnoreCase(System.getProperty("environment")) && !TEST_ENVIRONMENT;
	public static final boolean PRODUCTION_ENVIRONMENT = "PROD".equalsIgnoreCase(System.getProperty("environment"));
 
   public static void main(String[] args) {
	   SpringApplication.run(ServletInitializer.class, args);
   }
 
   @Override
   protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
      return application.sources(ServletInitializer.class);
   } 
}
