package com.ibs.user.profile.service;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ibs.user.profile.service.model.db2.UserProfile;
import com.ibs.user.profile.service.model.db2.UserProfilePersonalParameters;
import com.ibs.user.profile.service.utils.AllCountries;
import com.ibs.user.profile.service.utils.MailMessage;
import com.ibs.user.profile.service.utils.UserProfileServiceUtils;

@Component
public class NotificationsManager {
	private static final String FROM_ADDRESS = "feedback.egov@egov.bg";
	
	@Autowired
	UserProfileServiceUtils utils;
	
	public boolean notifyUserForIdentifierAdded(UserProfile profile, UserProfilePersonalParameters profilePersonalParameters, String identifier, String identifierCountryCode, int identifierType, Date date) {
		try {
			notifyUserForIdentifierCreated(profile, profilePersonalParameters, identifier, identifierCountryCode, identifierType, date);			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}					
		return true;
	}
	
	private boolean notifyUserForIdentifierCreated(UserProfile profile, UserProfilePersonalParameters profilePersonalParameters, String identifier, String identifierCountryCode, int identifierType, Date date) throws Exception {
		if (profilePersonalParameters != null) {
			// Notify by email.
			String email = profilePersonalParameters.getEmail();
			if (email != null && email.trim().length() > 0) {
				String senderNames = profile.getNames();
				String subject = "Добавяне на нов идентификатор към профил на " + senderNames;				
				String body = emailBodyAddIdentifier(senderNames, identifier, identifierCountryCode, identifierType, date);
				try {
					if (MailMessage.sendEmail(FROM_ADDRESS, email, null, subject, body, false)) {
						//System.out.println("Mail send successfully to " + email + "!");
						return true;
					}
				} catch (Exception e) {
					e.printStackTrace();
					throw new Exception("Неуспешно изпращане на е-поща до " + email);					
				}
			}
		}		
		return false; 
	}
	
	public boolean notifyUserForIdentifierRemoved(UserProfile profile, UserProfilePersonalParameters profilePersonalParameters, String identifier, String identifierCountryCode, int identifierType, Date date) {
		try {
			notifyUserForIdentifierDeleted(profile, profilePersonalParameters, identifier, identifierCountryCode, identifierType, date);			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}					
		return true;
	}
	
	private boolean notifyUserForIdentifierDeleted(UserProfile profile, UserProfilePersonalParameters profilePersonalParameters, String identifier, String identifierCountryCode, int identifierType, Date date) throws Exception {
		if (profilePersonalParameters != null) {
			// Notify by email.
			String email = profilePersonalParameters.getEmail();
			if (email != null && email.trim().length() > 0) {
				String senderNames = profile.getNames();
				String subject = "Премахване на идентификатор от профил на " + senderNames;				
				String body = emailBodyRemoveIdentifier(senderNames, identifier, identifierCountryCode, identifierType, date);
				try {
					if (MailMessage.sendEmail(FROM_ADDRESS, email, null, subject, body, false)) {
						//System.out.println("Mail send successfully to " + email + "!");
						return true;
					}
				} catch (Exception e) {
					e.printStackTrace();
					throw new Exception("Неуспешно изпращане на е-поща до " + email);					
				}
			}
		}		
		return false; 
	}
	
	private String emailBodyAddIdentifier (String names, String identifier, String identifierCountryCode, int identifierType, Date date) {
		String html = "<div>Добавен е следния идентификатор към профил <strong>" + names + "</strong>.</div><br/>";
		html += "<div>Вид:</div><div><strong>" + utils.getIdentifierTypeName(identifierType, true) + "</strong></div><br/>";
		html += "<div>Идентификатор:</div><div><strong>" + identifier + "</strong></div><br/>";
		html += "<div>Държава:</div><div><strong>" + AllCountries.getCountryCodesISO3166Hm().get(identifierCountryCode) + "</strong></div><br/>";
		html += "<div>Дата на операцията:</div><div><strong>" + utils.timeMillisToDD_MM_YYYY_HH_mm_ss(date.getTime()) + "</strong></div><br/><br/>";
		html += "<div style=\"font-style: italic;color:#888;\">Моля не отговаряйте, автоматично съобщение.</div>";
		return html;
	}
	
	private String emailBodyRemoveIdentifier (String names, String identifier, String identifierCountryCode, int identifierType, Date date) {
		String html = "<div>Премахнат е следния идентификатор от профил <strong>" + names + "</strong>.</div><br/>";
		html += "<div>Вид:</div><div><strong>" + utils.getIdentifierTypeName(identifierType, true) + "</strong></div><br/>";
		html += "<div>Идентификатор:</div><div><strong>" + identifier + "</strong></div><br/>";
		html += "<div>Държава:</div><div><strong>" + AllCountries.getCountryCodesISO3166Hm().get(identifierCountryCode) + "</strong></div><br/>";
		html += "<div>Дата на операцията:</div><div><strong>" + utils.timeMillisToDD_MM_YYYY_HH_mm_ss(date.getTime()) + "</strong></div><br/><br/>";
		html += "<div style=\"font-style: italic;color:#888;\">Моля не отговаряйте, автоматично съобщение.</div>";
		return html;
	}

}
