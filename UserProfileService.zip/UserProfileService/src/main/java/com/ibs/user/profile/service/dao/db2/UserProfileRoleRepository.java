package com.ibs.user.profile.service.dao.db2;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ibs.user.profile.service.model.db2.UserProfileRole;

@Repository
public interface UserProfileRoleRepository extends JpaRepository<UserProfileRole, Long> {
	
	List<UserProfileRole> findByUserUid(String userUid);
	List<UserProfileRole> findAllByUserProfileIdAndUserUid(Long userProfileId, String userUid);
	List<UserProfileRole> findAllByUserProfileIdAndAdmin(Long userProfileId, String admin);
	
	@Query(value = "SELECT next value for egov.SEQ_USERPROFILEROLE from SYSIBM.SYSDUMMY1", nativeQuery = true)
    public Long getSequenceNextVal();
}
