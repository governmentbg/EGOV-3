package com.ibs.user.profile.service.model.db2;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.CreatedDate;

@Entity
public class UserProfileIdentifier {
	
	@Id
	private Long userProfileIdentifierId;
	@Column(nullable = false)
	private Long userProfileId;
	@Column(nullable = false)
	private String identifier;
	@Column(nullable = false)
	private String identifierCountryCode;
	@Column(nullable = false)
	private int identifierType;
	@Column(nullable = false)
	private String rnu;
	@Column(name = "dateCreated", nullable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate    
    private Date dateCreated;		
	
	public Long getUserProfileIdentifierId() {
		return userProfileIdentifierId;
	}
	public void setUserProfileIdentifierId(Long userProfileIdentifierId) {
		this.userProfileIdentifierId = userProfileIdentifierId;
	}
	public Long getUserProfileId() {
		return userProfileId;
	}
	public void setUserProfileId(Long userProfileId) {
		this.userProfileId = userProfileId;
	}
	public String getIdentifier() {
		return identifier;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public String getIdentifierCountryCode() {
		return identifierCountryCode;
	}
	public void setIdentifierCountryCode(String identifierCountryCode) {
		this.identifierCountryCode = identifierCountryCode;
	}
	public int getIdentifierType() {
		return identifierType;
	}
	public void setIdentifierType(int identifierType) {
		this.identifierType = identifierType;
	}	
	public String getRnu() {
		return rnu;
	}
	public void setRnu(String rnu) {
		this.rnu = rnu;
	}
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
}
