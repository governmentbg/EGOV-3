package com.ibs.user.profile.service.bean;

public class UserAdministrationsXCRole {
	String uid = null;
	String title = null;
	
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
}
