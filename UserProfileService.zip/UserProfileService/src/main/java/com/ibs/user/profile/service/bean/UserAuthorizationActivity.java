package com.ibs.user.profile.service.bean;

public class UserAuthorizationActivity {
	String code = null;	
	String description = null;
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}	
}
