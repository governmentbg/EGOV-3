package com.ibs.user.profile.service.dao.db2;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ibs.user.profile.service.model.db2.UserProfile;

@Repository
public interface UserProfileRepository extends JpaRepository<UserProfile, Long> {
	List<UserProfile> findByIdentifier(String identifier);
	UserProfile findByIdentifierAndProfileType(String identifier, int profileType);
	UserProfile findByUserUidAndProfileType(String userUid, int profileType);
	UserProfile findByEik(String eik);
}
