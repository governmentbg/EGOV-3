package com.ibs.user.profile.service.model.db2;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class UserProfilePersonalParameters {
	
	@Id
	private Long userProfilePersonalParametersId;
	@Column(nullable = false)
	private Long userProfileId;
	private String securityLevel;
	private String consentToUseAddress;
	private String ekatte;
	private String addressDescription;
	private String mailBox;
	private String zipCode;
	private String consentToUsePhone;
	private String phoneNumber;
	private String consentToUseEmail;
	private String email;
//	private String consentToUseRequestChannel;
//	private String preferredRequestChannel;
//	private String consentToUseResponseChannel;
//	private String preferredResponseChannel;
//	private String consentToUsePaymentChannel;
//	private String preferredPaymentChannel;
	@Column(nullable = false)
	private int maxFavoriteServices;
	private String generalConsent;

	public Long getUserProfilePersonalParametersId() {
		return userProfilePersonalParametersId;
	}
	public void setUserProfilePersonalParametersId(Long userProfilePersonalParametersId) {
		this.userProfilePersonalParametersId = userProfilePersonalParametersId;
	}
	public Long getUserProfileId() {
		return userProfileId;
	}
	public void setUserProfileId(Long userProfileId) {
		this.userProfileId = userProfileId;
	}
	public String getSecurityLevel() {
		return securityLevel;
	}
	public void setSecurityLevel(String securityLevel) {
		this.securityLevel = securityLevel;
	}
	public String getConsentToUseAddress() {
		return consentToUseAddress;
	}
	public void setConsentToUseAddress(String consentToUseAddress) {
		this.consentToUseAddress = consentToUseAddress;
	}
	public String getEkatte() {
		return ekatte;
	}
	public void setEkatte(String ekatte) {
		this.ekatte = ekatte;
	}
	public String getAddressDescription() {
		return addressDescription;
	}
	public void setAddressDescription(String addressDescription) {
		this.addressDescription = addressDescription;
	}
	public String getMailBox() {
		return mailBox;
	}
	public void setMailBox(String mailBox) {
		this.mailBox = mailBox;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	public String getConsentToUsePhone() {
		return consentToUsePhone;
	}
	public void setConsentToUsePhone(String consentToUsePhone) {
		this.consentToUsePhone = consentToUsePhone;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getConsentToUseEmail() {
		return consentToUseEmail;
	}
	public void setConsentToUseEmail(String consentToUseEmail) {
		this.consentToUseEmail = consentToUseEmail;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
//	public String getConsentToUseRequestChannel() {
//		return consentToUseRequestChannel;
//	}
//	public void setConsentToUseRequestChannel(String consentToUseRequestChannel) {
//		this.consentToUseRequestChannel = consentToUseRequestChannel;
//	}
//	public String getPreferredRequestChannel() {
//		return preferredRequestChannel;
//	}
//	public void setPreferredRequestChannel(String preferredRequestChannel) {
//		this.preferredRequestChannel = preferredRequestChannel;
//	}
//	public String getConsentToUseResponseChannel() {
//		return consentToUseResponseChannel;
//	}
//	public void setConsentToUseResponseChannel(String consentToUseResponseChannel) {
//		this.consentToUseResponseChannel = consentToUseResponseChannel;
//	}
//	public String getPreferredResponseChannel() {
//		return preferredResponseChannel;
//	}
//	public void setPreferredResponseChannel(String preferredResponseChannel) {
//		this.preferredResponseChannel = preferredResponseChannel;
//	}
//	public String getConsentToUsePaymentChannel() {
//		return consentToUsePaymentChannel;
//	}
//	public void setConsentToUsePaymentChannel(String consentToUsePaymentChannel) {
//		this.consentToUsePaymentChannel = consentToUsePaymentChannel;
//	}
//	public String getPreferredPaymentChannel() {
//		return preferredPaymentChannel;
//	}
//	public void setPreferredPaymentChannel(String preferredPaymentChannel) {
//		this.preferredPaymentChannel = preferredPaymentChannel;
//	}
	public int getMaxFavoriteServices() {
		return maxFavoriteServices;
	}
	public void setMaxFavoriteServices(int maxFavoriteServices) {
		this.maxFavoriteServices = maxFavoriteServices;
	}
	public String getGeneralConsent() {
		return generalConsent;
	}
	public void setGeneralConsent(String generalConsent) {
		this.generalConsent = generalConsent;
	}
	
	
}
