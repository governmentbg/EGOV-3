package com.ibs.user.profile.service.dao.db2;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ibs.user.profile.service.model.db2.UserProfileInvitation;

@Repository
public interface UserProfileInvitationRepository extends JpaRepository<UserProfileInvitation, Long> {
	
	UserProfileInvitation findByCode(String code);
	List<UserProfileInvitation> findByUserUid(String userUid);
}
