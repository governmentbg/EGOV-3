package com.ibs.user.profile.service.model.db2;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

@Entity
public class UserProfile {
	
	@Id
	private Long userProfileId;
	@Column(nullable = false)
	private String userUid;
	@Column(nullable = false)
	private String identifier;
	@Column(nullable = false)
	private String names;
	@Column(nullable = false)
	private int status;
	private String deactivationReason;
	private String eik;
	private String nameAndLegalForm;
	private String qualityOfPhysicalPerson;
	private String methodOfRepresentation;
	@Column(nullable = false)
	private int profileType;
	
	@Column(name = "dateCreated", nullable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate    
    private Date createdAt;
	
    @Column(name = "dateModified", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date updatedAt;
    private String samlResponse;
    private String groupId;
    private String customSideNav;
    private String profileStructureType;
    
	public Long getUserProfileId() {
		return userProfileId;
	}
	public void setUserProfileId(Long userProfileId) {
		this.userProfileId = userProfileId;
	}
	public String getUserUid() {
		return userUid;
	}
	public void setUserUid(String userUid) {
		this.userUid = userUid;
	}
	public String getIdentifier() {
		return identifier;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public String getNames() {
		return names;
	}
	public void setNames(String names) {
		this.names = names;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getDeactivationReason() {
		return deactivationReason;
	}
	public void setDeactivationReason(String deactivationReason) {
		this.deactivationReason = deactivationReason;
	}
	public String getEik() {
		return eik;
	}
	public void setEik(String eik) {
		this.eik = eik;
	}
	public String getNameAndLegalForm() {
		return nameAndLegalForm;
	}
	public void setNameAndLegalForm(String nameAndLegalForm) {
		this.nameAndLegalForm = nameAndLegalForm;
	}
	public String getQualityOfPhysicalPerson() {
		return qualityOfPhysicalPerson;
	}
	public void setQualityOfPhysicalPerson(String qualityOfPhysicalPerson) {
		this.qualityOfPhysicalPerson = qualityOfPhysicalPerson;
	}
	public String getMethodOfRepresentation() {
		return methodOfRepresentation;
	}
	public void setMethodOfRepresentation(String methodOfRepresentation) {
		this.methodOfRepresentation = methodOfRepresentation;
	}
	public int getProfileType() {
		return profileType;
	}
	public void setProfileType(int profileType) {
		this.profileType = profileType;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}
	public String getSamlResponse() {
		return samlResponse;
	}
	public void setSamlResponse(String samlResponse) {
		this.samlResponse = samlResponse;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getCustomSideNav() {
		return customSideNav;
	}
	public void setCustomSideNav(String customSideNav) {
		this.customSideNav = customSideNav;
	}
	public String getProfileStructureType() {
		return profileStructureType;
	}
	public void setProfileStructureType(String profileStructureType) {
		this.profileStructureType = profileStructureType;
	}
	
}
