package com.ibs.user.profile.service.bean;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

public class UserContactData {
	String result = null;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	String errorCode = null;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	String message = null;
	@JsonProperty("profile")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	UserContactProfile userContactProfile = null;
	
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public UserContactProfile getUserContactProfile() {
		return userContactProfile;
	}
	public void setUserContactProfile(UserContactProfile userContactProfile) {
		this.userContactProfile = userContactProfile;
	}
	
}
