package com.ibs.user.profile.service.controller;

import java.security.PrivilegedExceptionAction;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.naming.InitialContext;
import javax.naming.NamingException;
//import javax.annotation.PostConstruct;
//import javax.naming.InitialContext;
//import javax.naming.NamingException;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.egov.wcm.cache.EgovEkatte;
import com.egov.wcm.cache.EgovProfile;
import com.egov.wcm.cache.EgovProfileStructureType;
import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.portal.um.PumaEnvironment;
import com.ibm.portal.um.PumaHome;
import com.ibm.portal.um.PumaProfile;
import com.ibm.portal.um.User;
import com.ibm.portal.um.exceptions.PumaException;
import com.ibs.user.profile.service.UserProfileServiceConstants;
import com.ibs.user.profile.service.bean.UserAdministrationsAdministration;
import com.ibs.user.profile.service.bean.UserAdministrationsProfile;
import com.ibs.user.profile.service.bean.UserAdministrationsProfileStructureType;
import com.ibs.user.profile.service.bean.UserAuthorizationActivity;
import com.ibs.user.profile.service.bean.UserAuthorizationPeople;
import com.ibs.user.profile.service.bean.UserAuthorizationProfile;
import com.ibs.user.profile.service.bean.UserAuthorizationSystem;
import com.ibs.user.profile.service.bean.UserContactData;
import com.ibs.user.profile.service.bean.UserContactProfile;
import com.ibs.user.profile.service.bean.UserContactProfileAddressEkatte;
import com.ibs.user.profile.service.dao.db2.UserProfileInvitationRepository;
import com.ibs.user.profile.service.dao.db2.UserProfilePersonalParametersRepository;
import com.ibs.user.profile.service.dao.db2.UserProfileRepository;
import com.ibs.user.profile.service.dao.db2.UserProfileRoleRepository;
import com.ibs.user.profile.service.dao.mariadb.ActionsRepository;
import com.ibs.user.profile.service.dao.mariadb.AuthorizationsRepository;
import com.ibs.user.profile.service.dao.mariadb.SystemsRepository;
import com.ibs.user.profile.service.model.db2.UserProfile;
import com.ibs.user.profile.service.model.db2.UserProfileInvitation;
import com.ibs.user.profile.service.model.db2.UserProfilePersonalParameters;
import com.ibs.user.profile.service.model.db2.UserProfileRole;
import com.ibs.user.profile.service.model.mariadb.Actions;
import com.ibs.user.profile.service.model.mariadb.Authorizations;
import com.ibs.user.profile.service.model.mariadb.Systems;
import com.ibs.user.profile.service.utils.EncryptorAESGCM;
import com.ibs.user.profile.service.utils.MailMessage;
import com.ibs.user.profile.service.utils.UserProfileServiceUtils;


@RestController
public class UserProfileController {
	
	@Autowired
	UserProfileRepository userProfileRepository;
	@Autowired
	UserProfilePersonalParametersRepository userProfilePersonalParametersRepository;
	@Autowired
	UserProfileRoleRepository userProfileRoleRepository;
	@Autowired
	UserProfileInvitationRepository userProfileInvitationRepository;
	@Autowired
	AuthorizationsRepository authorizationsRepository;
	@Autowired
	SystemsRepository systemsRepository;
	@Autowired
	ActionsRepository actionsRepository;
	
	@Autowired
	UserProfileServiceUtils utils;
	
	private static PumaHome pumaHome = null;
	//private static String sessionProfileIdKey = "_currentProfileId";
	private boolean isDebug = false;	
	private Logger logger = LoggerFactory.getLogger(UserProfileController.class);
		
	@PostConstruct
	public void init() {
		InitialContext initialcontext;
		try {
			// Maven install throws javax.naming.NoInitialContextException, but build is ok, so ignore it.
			initialcontext = new InitialContext();
			pumaHome = (PumaHome) initialcontext.lookup("portal:service/usermanagement/Puma");
		} catch (NamingException namingexception) {
			namingexception.printStackTrace();
		}
	}
	
	@GetMapping("/GetEGOVUserContactData")
	public UserContactData getUserContactData(
			@RequestParam String identifier,
			@RequestParam("phone") Optional<String> phone,
			@RequestParam("address") Optional<String> address,
			@RequestParam("email") Optional<String> email,
			@RequestParam("divider") Optional<String> divider,
			@RequestParam("debug") Optional<String> debug) {
		
		isDebug = (debug.isPresent() && "true".equalsIgnoreCase(debug.get()));		
		boolean hasSpecific = phone.isPresent() || address.isPresent() || email.isPresent();
		
		logMessage("getUserContactData() start...");
		UserContactData contactData = new UserContactData();
		EncryptorAESGCM ascCls = new EncryptorAESGCM();
		String encryptedIdentifier = ascCls.encryptEgovIdentifier(identifier);		
		EgovProfile personalProfile = EgovWCMCache.getEgovPersonalProfileHm() != null ? EgovWCMCache.getEgovPersonalProfileHm().get(encryptedIdentifier) : null;
		//EgovPersonalProfile personalProfile = EgovWCMCache.getEgovPersonalProfileHm() != null ? EgovWCMCache.getEgovPersonalProfileHm().get(identifier) : null;
		if (personalProfile != null) {					
			contactData.setResult("success");
			UserContactProfile profile = new UserContactProfile();
			profile.setIdentifier(identifier);
			if (!hasSpecific || phone.isPresent()) {
				if ("1".equals(personalProfile.getConsentToUsePhone())) {
					profile.setPhone((personalProfile.getPhone() != null ? personalProfile.getPhone() : ""));					
				} else {
					profile.setPhone("Not authorised");					
				}
			}
			
			if (!hasSpecific || address.isPresent()) { 
				Map<String, Object> userContactProfileAddress = new HashMap<String,Object>();
				if ("1".equals(personalProfile.getConsentToUseAddress())) {					
					String fullAddress = "";
					divider = divider.isPresent() ? divider : Optional.of(", ");
					UserContactProfileAddressEkatte userContactProfileAddressEkatte = new UserContactProfileAddressEkatte();
					if (personalProfile.getEkatte() != null) {								
						if (EgovWCMCache.getEkattesHm() != null) {
							EgovEkatte ekatte = EgovWCMCache.getEkattesHm() != null ? EgovWCMCache.getEkattesHm().get(personalProfile.getEkatte()) : null;
							if (ekatte != null && ekatte.getParentCode() != null) {				
								String district = null;
								String municipality = null;
								String settlement = null;
								String area = null;
								while (ekatte != null && ekatte.getParentCode() != null) {
									if (EgovWCMCache.EKATTE_LEVEL_REGION.equalsIgnoreCase(ekatte.getLevel())) {						
										break;
									} else if (EgovWCMCache.EKATTE_LEVEL_DISTRICT.equalsIgnoreCase(ekatte.getLevel())) {
										district = ekatte.getName();
									} else if (EgovWCMCache.EKATTE_LEVEL_MUNICIPALITY.equalsIgnoreCase(ekatte.getLevel())) {
										municipality = ekatte.getName();
									} else if (EgovWCMCache.EKATTE_LEVEL_SETTLEMENT.equalsIgnoreCase(ekatte.getLevel())) {
										settlement = ekatte.getName();
									} else if (EgovWCMCache.EKATTE_LEVEL_AREA.equalsIgnoreCase(ekatte.getLevel())) {
										area = ekatte.getName();
									}
									ekatte = EgovWCMCache.getEkattesHm().get(ekatte.getParentCode());
								}
								userContactProfileAddressEkatte.setEkatte(personalProfile.getEkatte());
								if (district != null) {
									fullAddress += "Област: " + district;
									userContactProfileAddressEkatte.setDistrict(district);
								}
								if (municipality != null) {
									if (fullAddress.trim().length() > 0) {
										fullAddress += divider.get();
									}
									fullAddress += "Община: " + municipality;
									userContactProfileAddressEkatte.setMunicipality(municipality);
								}				
								if (settlement != null) {
									if (fullAddress.trim().length() > 0) {
										fullAddress += divider.get();
									}
									fullAddress += "Населено място: " + settlement;
									userContactProfileAddressEkatte.setSettlement(settlement);
								}
								if (area != null) {
									if (fullAddress.trim().length() > 0) {
										fullAddress += divider.get();
									}
									fullAddress += "Район: " + area;
									userContactProfileAddressEkatte.setArea(area);
								}
								
							}
						}																					
					} 
					userContactProfileAddress.put("ekatte", userContactProfileAddressEkatte);
					if (personalProfile.getAddressDescription() != null && personalProfile.getAddressDescription().trim().length() > 0) {
						userContactProfileAddress.put("description", personalProfile.getAddressDescription());
						if (fullAddress.trim().length() > 0) {
							fullAddress += divider.get();
						}
						fullAddress += personalProfile.getAddressDescription();
					} else {
						userContactProfileAddress.put("description","");
					}
					if (personalProfile.getZipCode() != null && personalProfile.getZipCode().trim().length() > 0) {
						userContactProfileAddress.put("zipCode", personalProfile.getZipCode());
						if (fullAddress.trim().length() > 0) {
							fullAddress += divider.get();
						}
						fullAddress += "п. код " + personalProfile.getZipCode();
					} else {
						userContactProfileAddress.put("zipCode","");
					}
					if (personalProfile.getMailBox() != null && personalProfile.getMailBox().trim().length() > 0) {
						userContactProfileAddress.put("mailBox", personalProfile.getMailBox());
						if (fullAddress.trim().length() > 0) {
							fullAddress += divider.get();
						}
						fullAddress += "п. кутия " + personalProfile.getMailBox();
					} else {
						userContactProfileAddress.put("mailBox","");
					}
					userContactProfileAddress.put("full", fullAddress);
				} else {
					userContactProfileAddress.put("ekatte", "Not authorised");
					userContactProfileAddress.put("description", "Not authorised");					
					userContactProfileAddress.put("zipCode", "Not authorised");
					userContactProfileAddress.put("mailBox", "Not authorised");																
					userContactProfileAddress.put("description", "Not authorised");						
					userContactProfileAddress.put("full", "Not authorised");						
				}
				profile.setUserContactProfileAddress(userContactProfileAddress);
			}
			
			if (!hasSpecific || email.isPresent()) {
				if ("1".equals(personalProfile.getConsentToUseEmail())) {
					profile.setEmail(personalProfile.getEmail() != null ? personalProfile.getEmail() : "");
				} else {
					profile.setEmail("Not authorised");
				}
			}			
			contactData.setUserContactProfile(profile);
		} else {
			contactData.setResult("error");
			contactData.setMessage("Profile not found!");
			contactData.setErrorCode("404");
		}
		
		
//		UserContactProfile profile = new UserContactProfile();
//		profile.setIdentifier(identifier);
//		profile.setEmail("joly24@abv.bg");
//		profile.setPhone("0894749717");
//		Map<String, Object> userContactProfileAddressMap = new HashMap<String,Object>();		
//		userContactProfileAddressMap.put("description", "ж.к. Христо Смирнернски\\r\\nбл.5, вх.Д, ет.4, ап.108");
//		userContactProfileAddressMap.put("full", "Област: София (столица), Община: Столична, Населено място: Балша, ж.к. Христо Смирнернски\r\nбл.5, вх.Д, ет.4, ап.108");
//		userContactProfileAddressMap.put("ekatte", "Not authorised");
//		UserContactProfileAddressEkatte ekatte = new UserContactProfileAddressEkatte();
//		ekatte.setDistrict("София (столица)");
//		ekatte.setMunicipality("Столична");
//		ekatte.setSettlement("Балша");
//		ekatte.setEkatte("02511");
//		userContactProfileAddressMap.put("ekatte", ekatte);
//		profile.setUserContactProfileAddress(userContactProfileAddressMap);
//		contactData.setUserContactProfile(profile);
		
		logMessage("getUserContactData() end.");
		return contactData;
	}
	
	/*
	 * If the required parameter is not passed (personalIdentifier) this is the response:
	 * {
     *   "timestamp": "2021-07-30T08:46:43.387+00:00",
     *   "status": 400,
     *   "error": "Bad Request",
     *   "path": "/GetEGOVUserAdministrationsAuthorization"
     * }
	 */
	@GetMapping("/GetEGOVUserAdministrationsAuthorization")
	public ResponseEntity<Object> getUserAdministrationsAuthorization(
			@RequestParam("personalIdentifier") String personalIdentifier,
			@RequestParam("debug") Optional<String> debug) {		
		isDebug = (debug.isPresent() && "true".equalsIgnoreCase(debug.get()));		
		Map<String, Object> map = new HashMap<>();
		
		EncryptorAESGCM ascCls = new EncryptorAESGCM();
		String encryptedPersonalIdentifier = ascCls.encryptEgovIdentifier(personalIdentifier);	
		// From "UserProfile" table load all profiles by given personalIdentifier.
		List<UserProfile> userProfiles = userProfileRepository.findByIdentifier(encryptedPersonalIdentifier);
		//List<UserProfile> userProfiles = userProfileRepository.findByIdentifier(personalIdentifier);
		if (userProfiles != null && userProfiles.size() > 0) {
			logMessage("profiles="+userProfiles.size());
			String userUID = null;
			boolean profileIsActive = true;
			UserProfile userProfile = null;
			for (int i = 0; i < userProfiles.size(); i++) {
				userProfile = userProfiles.get(i); 
				userUID = userProfile.getUserUid();
				if (UserProfileServiceConstants.USER_PROFILE_TYPE_PERSONAL == userProfile.getProfileType()) {
					//if (EgovWCMCache.EGOV_PROFILE_TYPE_PERSONAL.equalsIgnoreCase(userProfiles.get(i).getProfileType())) {
					// Check we have "Active" profile.
					if (UserProfileServiceConstants.USER_PROFILE_STATUS_ACTIVE != userProfile.getStatus()) {
						profileIsActive = false;
						break;
					}
				}
			}
			if (profileIsActive) {
				UserAdministrationsProfile userAdministrationsProfile = new UserAdministrationsProfile();
				ArrayList<UserAdministrationsAdministration> administartionsArr = new ArrayList<UserAdministrationsAdministration>();
				logMessage("userUID="+userUID);
				List<UserProfileRole> userProfileRoles = userProfileRoleRepository.findByUserUid(userUID);
				if (userProfileRoles != null && userProfileRoles.size() > 0) {
					Map<Long, UserProfileRole> rolesHm = new HashMap<Long, UserProfileRole>();
					List<Long> profileIds = new ArrayList<Long>();
					UserProfileRole role = null;
					for (int i = 0; i < userProfileRoles.size(); i++) {
						role = userProfileRoles.get(i);
						rolesHm.put(role.getUserProfileId(), userProfileRoles.get(i));
						profileIds.add(role.getUserProfileId());
					}
					List<UserProfile> profiles = userProfileRepository.findAllById(profileIds);					
					if (profiles != null && profiles.size() > 0) {						
						UserAdministrationsAdministration administration = null;
						ArrayList<String> roles = null;
						String userProfileStructureType = null;
						for (int i = 0; i < profiles.size(); i++) {
							userProfile = profiles.get(i);							
							administration = new UserAdministrationsAdministration();
							administration.setTitle(userProfile.getNameAndLegalForm());
							administration.setEik(userProfile.getEik());
							administration.setProfileType(userProfile.getProfileType());
							userProfileStructureType = userProfile.getProfileStructureType();
							if (userProfileStructureType != null && userProfileStructureType.trim().length() > 0) {
								administration.setProfileStructureType(populateProfileStructureTypeBean(utils.getArrayFromFormatedField(userProfileStructureType.trim())));
							}
							role = rolesHm.get(userProfile.getUserProfileId());
							if (role != null) {
								roles = new ArrayList<>();
								if (UserProfileServiceConstants.USER_PROFILE_ROLE_SELECTED.equalsIgnoreCase(role.getAdmin())) {
									roles.add("Admin");
								}
								if (UserProfileServiceConstants.USER_PROFILE_ROLE_SELECTED.equalsIgnoreCase(role.getEditor())) {
									roles.add("Editor");
								}
								if (UserProfileServiceConstants.USER_PROFILE_ROLE_SELECTED.equalsIgnoreCase(role.getServiceManager())) {
									roles.add("Service Manager");
								}
								if (UserProfileServiceConstants.USER_PROFILE_ROLE_SELECTED.equalsIgnoreCase(role.getUserRole())) {
									roles.add("User");
								}
								administration.setRoles(roles);
							}
							administartionsArr.add(administration);
						}						
					} 			
				} 
				map.put("result", "success");					
				userAdministrationsProfile.setPersonalIdentifier(personalIdentifier);
				userAdministrationsProfile.setProfileIdType(UserProfileServiceConstants.USER_PROFILE_ID_TYPE_EGN);
				userAdministrationsProfile.setAdministrations(administartionsArr);
				map.put("profile", userAdministrationsProfile);	
			} else {
				map.put("result", "error");
				map.put("errorCode", "403");
				map.put("message", "Profile is not active!");	
			}
		} else {
			map.put("result", "error");
			map.put("errorCode", "404");
			map.put("message", "Profile not found!");	
		}
		
		
		// If records founded check all NOT PERSONAL profiles (by default the user is with role "admin"
		// From UserProfileRole, load all by useruid (loaded from the previous query)
		
		
		
		return ResponseEntity.ok(map);
	}
	
	@GetMapping("/GetEGOVUserPersonAuthorization")
	public ResponseEntity<Object> getAuthorization(
		@RequestParam("personalIdentifier") Optional<String> personalIdentifierParam,
		@RequestParam("eik") Optional<String> eikParam,
		@RequestParam("orn") Optional<String> ornParam,
		@RequestParam("oid") String oid,
		@RequestParam("debug") Optional<String> debug) {		
		logMessage("GetEGOVUserPersonAuthorization: oid=" + oid);
		
		isDebug = (debug.isPresent() && "true".equalsIgnoreCase(debug.get()));	
		String personalIdentifier = personalIdentifierParam.isPresent() ? personalIdentifierParam.get() : null;
		String eik = eikParam.isPresent() ? eikParam.get() : null;
		String orn = ornParam.isPresent() ? ornParam.get() : null;
		
		logMessage("GetEGOVUserPersonAuthorization: personalIdentifier=" + personalIdentifier);
		logMessage("GetEGOVUserPersonAuthorization: eik=" + eik);
		logMessage("GetEGOVUserPersonAuthorization: orn=" + orn);
		
		Map<String, Object> map = new HashMap<>();
		if (personalIdentifier != null && personalIdentifier.trim().length() > 0
				|| eik != null && eik.trim().length() > 0
				|| orn != null && orn.trim().length() > 0) {
			Systems system = null;
			// Load system by oid.
			system = systemsRepository.findByOid(oid);
			if (system != null) {
				logMessage("GetEGOVUserPersonAuthorization: system=" + system.getTitle() + "(" + system.getSystemsId() + ")");							
				UserProfile userProfile = null;
				String identifier = null;
				String pureIndetifier = null;
				EncryptorAESGCM ascCls = new EncryptorAESGCM();
				Authorizations ornAuthorization = null;
				
				if (orn != null && orn.trim().length() > 0) {
					ornAuthorization = authorizationsRepository.findByOrnAndStatusAndSystemsLike(orn, UserProfileServiceConstants.AUTHORIZATION_STATUS_ACTIVE, "%^" + system.getSystemsId() + ":%");
					if (ornAuthorization != null) {
						if (UserProfileServiceConstants.AUTHORIZATION_USER_TYPE_PERSON == ornAuthorization.getUserType()) {
							personalIdentifier = ascCls.decryptEgovIdentifier(ornAuthorization.getUserIdentifier());
						} else {
							eik = ornAuthorization.getUserIdentifier();
						}
					}
				}
				if (personalIdentifier != null && personalIdentifier.trim().length() > 0) {					
					identifier = ascCls.encryptEgovIdentifier(personalIdentifier);
					// From "UserProfile" table load all profiles by given personalIdentifier.		
					userProfile = userProfileRepository.findByIdentifierAndProfileType(identifier, UserProfileServiceConstants.USER_PROFILE_TYPE_PERSONAL);
					pureIndetifier = personalIdentifier;
				} else if (eik != null && eik.trim().length() > 0) {
					identifier = eik;
					userProfile = userProfileRepository.findByEik(identifier);
					pureIndetifier = eik;
				}
				if (userProfile != null && UserProfileServiceConstants.USER_PROFILE_STATUS_ACTIVE == userProfile.getStatus()) {
					UserAuthorizationProfile profile = new UserAuthorizationProfile();		
					List<UserAuthorizationPeople> peopleList = new ArrayList<UserAuthorizationPeople>();
					List<Authorizations> authorizations = null;
					profile.setIdentifier(pureIndetifier);
					profile.setPeople(peopleList);
					
					logMessage("GetEGOVUserPersonAuthorization -> profile loaded and active.");
					if (ornAuthorization != null) {
						authorizations = new ArrayList<Authorizations>();
						authorizations.add(ornAuthorization);
					} else {
						authorizations = authorizationsRepository.findAllByUserIdentifierAndStatusAndSystemsLike(identifier, UserProfileServiceConstants.AUTHORIZATION_STATUS_ACTIVE, "%^" + system.getSystemsId() + ":%");
					}
					//List<Authorizations> authorizations = authorizationsRepository.findAllByUserIdentifierAndStatus(encryptedPersonalIdentifier, UserProfileServiceConstants.AUTHORIZATION_STATUS_ACTIVE);
					if (authorizations != null && authorizations.size() > 0) {
						logMessage("GetEGOVUserPersonAuthorization -> authorizations.size()="+authorizations.size());
						Authorizations authorization = null;
						String[] data = null;
						String[] pair = null;
						List<Long> actionsIds = null;
						List<Long> allActionsIds = new ArrayList<Long>();
						Map<Long, List<Long>> actionsPerAuthorization = new HashMap<>();
						for (int i = 0; i < authorizations.size(); i++) {
							authorization = authorizations.get(i);
							if (utils.isAuthorizationActive(authorization.getStatus(), authorization.getValidFrom(), authorization.getValidTo())) {
								data = utils.getArrayFromFormatedField(authorization.getSystems());
								if (data != null) {		
									actionsIds = null;
									for (int j = 0; j < data.length; j++) {
										System.out.println(data[j]);
										pair = data[j].split(":");
										// Get only actionId(s) for given systemId.
										if (system.getSystemsId().toString().equals(pair[0])) {										
											System.out.println(pair[0] + "<>" + pair[1]);										
											if (actionsIds == null) {
												actionsIds = new ArrayList<Long>();
											}
											actionsIds.add(Long.parseLong(pair[1]));
										}
									}			
									if (actionsIds != null) {
										actionsPerAuthorization.put(authorization.getAuthorizationsId(), actionsIds);
										allActionsIds.addAll(actionsIds);
									}
								}
							}
						}
						if (allActionsIds != null && allActionsIds.size() > 0) {
							// Load all actions by ids.
							List<Actions> actions = actionsRepository.findAllByActionsIdIn(allActionsIds);
							Map<Long, Actions> actionsHm = new HashMap<Long, Actions>();
							Actions action = null;
							if (actions != null && actions.size() > 0) {
								for (int i = 0; i < actions.size(); i++) {
									action = actions.get(i);
									actionsHm.put(action.getActionsId(), action);
								}
							}
							UserAuthorizationPeople people = null;
							UserAuthorizationSystem systemObj = null;
							UserAuthorizationActivity activity = null;
							List<UserAuthorizationActivity> activities = null;
							for (int i = 0; i < authorizations.size(); i++) {
								authorization = authorizations.get(i);
								actionsIds = actionsPerAuthorization.get(authorization.getAuthorizationsId());
								if (actionsIds != null) {
									people = new UserAuthorizationPeople();
									people.setName(authorization.getAuthorizedNames());
									people.setOrn(authorization.getOrn());
									people.setProfileType(authorization.getAuthorizedType());
									if (UserProfileServiceConstants.AUTHORIZATION_AUTHORIZED_TYPE_PERSON == authorization.getAuthorizedType()) {
										people.setPid(ascCls.decryptEgovIdentifier(authorization.getAuthorizedIdentifier()));
									} else {
										people.setPid(authorization.getAuthorizedIdentifier());
									}
									systemObj = new UserAuthorizationSystem();
									//systemObj.setOID(oid);
									activities = new ArrayList<UserAuthorizationActivity>();
									for (int j = 0; j < actionsIds.size(); j++) {
										action = actionsHm.get(actionsIds.get(j));
										if (action != null) {
											activity = new UserAuthorizationActivity();
											activity.setCode(action.getCode());
											activity.setDescription(action.getDescription());
											activities.add(activity);
										}
									}
									systemObj.setActivities(activities);
									people.setSystem(systemObj);
									peopleList.add(people);
								}
							}
						}
						
						map.put("result", "success");					
						map.put("profile", profile);	
					} else {
						map.put("result", "success");
						map.put("profile", profile);				
					}
				} else {
					map.put("result", "error");
					map.put("errorCode", "404");
					map.put("message", "Profile not found!");	
				}
			} else {
				map.put("result", "error");
				map.put("errorCode", "404");
				map.put("message", "System with OID \"" + oid + "\" not found!");				
			}
		} else {
			map.put("result", "error");
			map.put("errorCode", "404");
			map.put("message", "Invalid parameters!");							
		}
		return ResponseEntity.ok(map);
	}
	
	@SuppressWarnings("rawtypes")
	@GetMapping("/GetEGOVServiceRequestParameters")
	public ResponseEntity<Object> getServiceRequestParameters(
		HttpServletRequest request,
		@RequestParam("debug") Optional<String> debug) {		
		logMessage("GetEGOVServiceRequestParameters: debug=" + debug);
		
		isDebug = (debug.isPresent() && "true".equalsIgnoreCase(debug.get()));
		Map<String, Object> map = new HashMap<>();
		if (!(request.getUserPrincipal() != null && request.getUserPrincipal().getName() != null && request.getUserPrincipal().getName().trim().length() > 0)) {
			// No logged in, return;
			logMessage("GetEGOVServiceRequestParameters: user not logged in, exit.");
			return ResponseEntity.ok(map);
		}
		String profileId = null;
//		Changing the LDAP value can interfere with the session, so this is useless.
//		if (request.getSession() != null) {
//			profileId = (String)request.getSession().getAttribute(sessionProfileIdKey);	
//			logMessage("GetEGOVServiceRequestParameters: profileId from session =" + profileId);
//		}
		if (profileId == null && pumaHome != null) {
			PumaProfile pumaProfile = pumaHome.getProfile();
			if (pumaProfile != null) {
				try {
					User user = pumaProfile.getCurrentUser();
					if (user != null) {
						java.util.Map<String, Object> userInfo = getUserAttributesInfo(user, pumaHome, pumaProfile);
						if (userInfo != null) {
							Object attribute = userInfo.get(UserProfileServiceConstants.LDAP_ATTRIBUTE_ROOM_NUMBER);
							if (attribute != null) {
								String activeProfileId = "";
								if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
									for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
										if (i > 0) {
											activeProfileId += " ";
										}
										activeProfileId += (String)((ArrayList)attribute).get(i);
									}
								} else if (attribute instanceof String) {
									activeProfileId = (String)attribute;
								}				
								profileId = activeProfileId != null && activeProfileId.trim().length() > 0 ? activeProfileId : null;
							}
							// If we log in without going through "My Space" - we need to default it to PERSONAL TYPE
							if (profileId == null) {
								logMessage("GetEGOVServiceRequestParameters: profileId is null, we switch to PERSONAL profile.");
								attribute = userInfo.get(UserProfileServiceConstants.LDAP_ATTRIBUTE_UID);
								if (attribute != null) {
									String currentUserUID = "";
									if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
										for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
											if (i > 0) {
												currentUserUID += " ";
											}
											currentUserUID += (String)((ArrayList)attribute).get(i);
										}
									} else if (attribute instanceof String) {
										currentUserUID = (String)attribute;
									}		
									if (currentUserUID != null && currentUserUID.trim().length() > 0) {
										logMessage("GetEGOVServiceRequestParameters: currentUserUID=" + currentUserUID);
										UserProfile personalProfile = userProfileRepository.findByUserUidAndProfileType(currentUserUID, UserProfileServiceConstants.USER_PROFILE_TYPE_PERSONAL);
										if (personalProfile != null) {
											profileId = String.valueOf(personalProfile.getUserProfileId());
										}
									}	
								}								
							}
						}
					}
				} catch (PumaException e) {
					System.out.println(e.getMessage());
					e.printStackTrace();
				}
			}
		}		
		if (profileId != null) {
			//request.getSession().setAttribute(sessionProfileIdKey, profileId);
			logMessage("GetEGOVServiceRequestParameters: profileId=" + profileId);
			
			ArrayList<com.egov.wcm.cache.EgovProfile> profiles = EgovWCMCache.getEgovProfiles();
			if (profiles != null && profiles.size() > 0) {
				com.egov.wcm.cache.EgovProfile profile = null;
				for (int i = 0; i < profiles.size(); i++) {
					profile = profiles.get(i);
					if (profileId.equals(profile.getId())) {						
						break;
					}
				}
				if (profile != null) {
					int profileTypeInt = Integer.parseInt(profile.getProfileType());
					String profileID = null;
					String[] profileStructureTypes = utils.getArrayFromFormatedField(profile.getProfileStructureType());
					map.put("profileType", profileTypeInt);
					if (profileStructureTypes != null) { 
						map.put("profileStructureType", profileStructureTypes);
					} else {
						map.put("profileStructureType", new String[0]);
					}
					map.put("profileIDType", UserProfileServiceConstants.USER_PROFILE_ID_TYPE_EGN);
					EncryptorAESGCM aesCls = new EncryptorAESGCM(); 
					if (UserProfileServiceConstants.USER_PROFILE_TYPE_PERSONAL == profileTypeInt) {
					  if (profile.getIdentifier() != null) {
						  profileID = aesCls.encryptPersonalIdentifier(aesCls.decryptEgovIdentifier(profile.getIdentifier()), UserProfileServiceConstants.E_FORMS_SECRET_KEY_IN_BASE_64);
					  }
					} else if (profile.getEik() != null) {
						profileID = aesCls.encryptPersonalIdentifier(profile.getEik(), UserProfileServiceConstants.E_FORMS_SECRET_KEY_IN_BASE_64);
					}
					map.put("profileID", profileID);
					logMessage("GetEGOVServiceRequestParameters: profileType=" + profileTypeInt);
					logMessage("GetEGOVServiceRequestParameters: profileStructureType=" + profile.getProfileStructureType());
					logMessage("GetEGOVServiceRequestParameters: profileIDType=" + UserProfileServiceConstants.USER_PROFILE_ID_TYPE_EGN);
					logMessage("GetEGOVServiceRequestParameters: profileID=" + profileID);
				}
			}
		}
		return ResponseEntity.ok(map);
	}
	
	@GetMapping("/GetEGOVUserInvitation")
	public ModelAndView getInivitation(
		@RequestParam("code") String code,
		@RequestParam("action") String action,		
		@RequestParam("debug") Optional<String> debug) {						
		isDebug = (debug.isPresent() && "true".equalsIgnoreCase(debug.get()));	
		
		logMessage("GetEGOVUserInvitation: code=" + code);
		logMessage("GetEGOVUserInvitation: action=" + action);
		
		ModelAndView mv = new ModelAndView();
		if (code != null && code.trim().length() > 0
				|| action != null && action.trim().length() > 0) {
			UserProfileInvitation invitation = null;
			// Load invitation by code.
			invitation = userProfileInvitationRepository.findByCode(code);
			if (invitation != null) {
				logMessage("GetEGOVUserInvitation: status=" + invitation.getStatus());		
				if (UserProfileServiceConstants.INVITATION_STATUS_CANCELED == invitation.getStatus()) {
					mv.addObject("message", "Поканата не е активна!");
					mv.setViewName("invitation_cancel");
					return mv;							
				}
				if ("cancel".equalsIgnoreCase(action)) {
					if (UserProfileServiceConstants.INVITATION_STATUS_CANCELED != invitation.getStatus()) {
						invitation.setUpdatedAt(new Date());
						invitation.setStatus(UserProfileServiceConstants.INVITATION_STATUS_CANCELED);
						userProfileInvitationRepository.save(invitation);
						// Send mail to the administrator that sent the invitation.
						String senderUID = invitation.getUserUid();
						UserProfile profile = userProfileRepository.findByUserUidAndProfileType(senderUID, UserProfileServiceConstants.USER_PROFILE_TYPE_PERSONAL);
						if (profile != null) {
							UserProfilePersonalParameters pp = userProfilePersonalParametersRepository.findByUserProfileId(profile.getUserProfileId());
							if (pp != null && pp.getEmail() != null && pp.getEmail().trim().length() > 0) {
								String subject = "Поканата до " + invitation.getFirstName() + " " + invitation.getLastName() + " беше отказана!";
								String body = "";
								body += "<div>"
										+ "<h1>EGOV.BG</h1>"
										+ "<div><p style=\"font-size:16px;\">Поканата до " + invitation.getFirstName() + " " + invitation.getLastName() + ", от дата " + utils.timeMillisToDD_MM_YYYY(invitation.getCreatedAt().getTime()) + "г., беше отказана.</p></div>"										
										+ "<br/>"
										+ "<br/>"
										+ "<div style=\"font-style: italic;color:#888;\">Моля не отговаряйте, автоматично съобщение.</div>";
								try {
									if (MailMessage.sendEmail("feedback.egov@egov.bg", pp.getEmail().trim(), null, subject, body, isDebug)) {
										logMessage("Mail send successfully to " + pp.getEmail().trim() + "!");
									}
								} catch (Exception e) {
									e.printStackTrace();
									logError("Неуспешно изпращане на е-поща до " + pp.getEmail().trim());					
								}
							}
						}
					}
					mv.addObject("message", "Поканата беше отказана!");
					mv.setViewName("invitation_cancel");
					return mv;							
				} else {
					if (UserProfileServiceConstants.INVITATION_STATUS_NOT_CONFIRMED == invitation.getStatus()) {						
						invitation.setUpdatedAt(new Date());
						invitation.setStatus(UserProfileServiceConstants.INVITATION_STATUS_CONFIRMED);
						userProfileInvitationRepository.save(invitation);
					}
				}				
			} else {
				mv.addObject("error", "Поканата не е активна.");
				mv.setViewName("invitation_error");
				return mv;					
			}
		} else {
			mv.addObject("error", "Некоректни параметри");
			mv.setViewName("invitation_error");
			return mv;							
		}		
		boolean testEnvironment = "TEST".equalsIgnoreCase(System.getProperty("environmentType"));
		boolean isProd = "PROD".equalsIgnoreCase(System.getProperty("environment"));
		String prefix = "";
		if (testEnvironment) {
			prefix = "https://testportal.egov.bg";
		} else if (isProd) {
			prefix = "https://egov.bg";		
		} else {
			prefix = "https://staging.egov.bg";
		}
		return new ModelAndView("redirect:" + prefix + "/wps/portal/egov/vhod");
	}

	private List<UserAdministrationsProfileStructureType> populateProfileStructureTypeBean(String[] currentStructureTypes) {
		List<EgovProfileStructureType> profileStructureTypes = EgovWCMCache.getProfileStructureTypes();
		List<UserAdministrationsProfileStructureType> bean = new ArrayList<UserAdministrationsProfileStructureType>();
		if (profileStructureTypes != null && profileStructureTypes.size() > 0) {
			UserAdministrationsProfileStructureType type = null; 
			for (int i = 0; i < currentStructureTypes.length; i++) {
				for (int j = 0; j < profileStructureTypes.size(); j++) {
					if (currentStructureTypes[i].equals(profileStructureTypes.get(j).getName())) {
						type = new UserAdministrationsProfileStructureType();
						type.setCode(profileStructureTypes.get(j).getName());						
						type.setTitle(profileStructureTypes.get(j).getDescription() != null && profileStructureTypes.get(j).getDescription().trim().length() > 0 ? profileStructureTypes.get(j).getDescription() : profileStructureTypes.get(j).getTitle());
						bean.add(type);
					}
				}
			}
		}
		return bean;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private java.util.Map<String, Object> getUserAttributesInfo(final User user, final PumaHome pumaHome, final PumaProfile pumaProfile) {
		logMessage("getUserAttributesInfo(com.ibm.portal.um.User)");
		final java.util.List<String> attributesNamesList;
		try {
			final PumaEnvironment env = pumaHome.getEnvironment();
			attributesNamesList = pumaProfile.getDefinedUserAttributeNames();
			java.util.Map<String, Object> userInfo = (java.util.Map<String, Object>) env.runUnrestricted(new PrivilegedExceptionAction() {
				public Object run() throws Exception {
					return pumaProfile.getAttributes((com.ibm.portal.um.Principal) user, attributesNamesList);
				}
			});
			return userInfo;
		} catch (Exception e) {
			logMessage("getUserAttribute(com.ibm.portal.um.User) -> Exception: " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
//	@GetMapping("/profiles")	
	// Response will be automatically in JSON format, because of jackson-core-2.12.3.jar that we have in maven repository.
	// When using POSTMAN the response can be returned in xml too, because of dependancy added in pom.xml -> jackson-dataformat-xml
	// Use this annotation when you do not want to return a view and when the class has annotation @Controller.
	//@ResponseBody
//	public List<UserProfile> getProfiles() {
//		return userProfileRepository.findAll();
//	}
	
	

	private void logError(String message) {
		logger.error(message);
	}
	private void logMessage(String message) {
//		logger.trace("A TRACE Message");
//      logger.debug("A DEBUG Message");
//      logger.info("An INFO Message");
//      logger.warn("A WARN Message");
//      logger.error("An ERROR Message");
		if (isDebug) {
			logger.info(message);
		}
	}
}
