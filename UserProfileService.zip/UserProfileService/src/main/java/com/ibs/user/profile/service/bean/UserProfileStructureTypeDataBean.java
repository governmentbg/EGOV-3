package com.ibs.user.profile.service.bean;

public class UserProfileStructureTypeDataBean {
	String id = null;
	String name = null;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
}
