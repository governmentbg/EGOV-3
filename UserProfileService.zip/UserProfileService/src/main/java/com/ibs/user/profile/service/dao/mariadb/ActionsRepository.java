package com.ibs.user.profile.service.dao.mariadb;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ibs.user.profile.service.model.mariadb.Actions;

@Repository
public interface ActionsRepository extends JpaRepository<Actions, Long> {
	List<Actions> findAllByActionsIdIn(List<Long> actionsId);
}
