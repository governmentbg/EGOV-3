package com.ibs.user.profile.service.model.db2;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

@Entity
public class HorizontalSystemRole {
	@Id	
	private Long horizontalSystemRoleId;
	@Column(nullable = false)
	private String systemOID;
	@Column(nullable = false)
	private String uid;	
	private String title;
	@Column(name = "dateCreated", nullable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate    
    private Date createdAt;	
	@Column(name = "dateModified", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @LastModifiedDate
    private Date updatedAt;
	
	public Long getHorizontalSystemRoleId() {
		return horizontalSystemRoleId;
	}
	public void setHorizontalSystemRoleId(Long horizontalSystemRoleId) {
		this.horizontalSystemRoleId = horizontalSystemRoleId;
	}
	public String getSystemOID() {
		return systemOID;
	}
	public void setSystemOID(String systemOID) {
		this.systemOID = systemOID;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
	public Date getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(Date updatedAt) {
		this.updatedAt = updatedAt;
	}	
}
