package com.ibs.user.profile.service.utils;

import java.util.HashMap;
import java.util.Map;

/*
 * https://gist.github.com/marijn/396531/188caa065e3cd319fed7913ee3eecf5eec541918
 */
public class AllCountries {
	private static final String[] ALL_COUNTRY_CODES_ISO3166 = new String[] {
			"AF",
			"AL",
			"DZ",
			"AS",
			"AD",
			"AO",
			"AI",
			"AQ",
			"AG",
			"AR",
			"AM",
			"AW",
			"AU",
			"AT",
			"AZ",
			"BS",
			"BH",
			"BD",
			"BB",
			"BY",
			"BE",
			"BZ",
			"BJ",
			"BM",
			"BT",
			"BO",
			"BA",
			"BW",
			"BV",
			"BR",
			"IO",
			"BN",
			"BG",
			"BF",
			"BI",
			"KH",
			"CM",
			"CA",
			"CV",
			"KY",
			"CF",
			"TD",
			"CL",
			"CN",
			"CX",
			"CC",
			"CO",
			"KM",
			"CG",
			"CD",
			"CK",
			"CR",
			"CI",
			"HR",
			"CU",
			"CY",
			"CZ",
			"DK",
			"DJ",
			"DM",
			"DO",
			"TP",
			"EC",
			"EG",
			"SV",
			"GQ",
			"ER",
			"EE",
			"ET",
			"FK",
			"FO",
			"FJ",
			"FI",
			"FR",
			"GF",
			"PF",
			"TF",
			"GA",
			"GM",
			"GE",
			"DE",
			"GH",
			"GI",
			"GR",
			"GL",
			"GD",
			"GP",
			"GU",
			"GT",
			"GN",
			"GW",
			"GY",
			"HT",
			"HM",
			"VA",
			"HN",
			"HK",
			"HU",
			"IS",
			"IN",
			"ID",
			"IR",
			"IQ",
			"IE",
			"IL",
			"IT",
			"JM",
			"JP",
			"JO",
			"KZ",
			"KE",
			"KI",
			"KP",
			"KR",
			"KV",
			"KW",
			"KG",
			"LA",
			"LV",
			"LB",
			"LS",
			"LR",
			"LY",
			"LI",
			"LT",
			"LU",
			"MO",			
			"MG",
			"MW",
			"MY",
			"MV",
			"ML",
			"MT",
			"MH",
			"MQ",
			"MR",
			"MU",
			"YT",
			"MX",
			"FM",
			"MD",
			"MC",
			"MN",
			"MS",
			"ME",
			"MA",
			"MZ",
			"MM",
			"NA",
			"NR",
			"NP",
			"NL",
			"AN",
			"NC",
			"NZ",
			"NI",
			"NE",
			"NG",
			"NU",
			"NF",
			"MK",
			"MP",
			"NO",
			"OM",
			"PK",
			"PW",
			"PS",
			"PA",
			"PG",
			"PY",
			"PE",
			"PH",
			"PN",
			"PL",
			"PT",
			"PR",
			"QA",
			"RE",
			"RO",
			"RU",
			"RW",
			"SH",
			"KN",
			"LC",
			"PM",
			"VC",
			"WS",
			"SM",
			"ST",
			"SA",
			"SN",
			"RS",
			"SC",
			"SL",
			"SG",
			"SK",
			"SI",
			"SB",
			"SO",
			"ZA",
			"GS",
			"ES",
			"LK",
			"SD",
			"SR",
			"SJ",
			"SZ",
			"SE",
			"CH",
			"SY",
			"TW",
			"TJ",
			"TZ",
			"TH",
			"TG",
			"TK",
			"TO",
			"TT",
			"TN",
			"TR",
			"TM",
			"TC",
			"TV",
			"UG",
			"UA",
			"AE",
			"GB",
			"US",
			"UM",
			"UY",
			"UZ",
			"VU",
			"VE",
			"VN",
			"VG",
			"VI",
			"WF",
			"EH",
			"YE",
			"ZM",
			"ZW"
			};
	
	private static Map<String, String> countryCodeISO3166Hm = null;	
	static {
		countryCodeISO3166Hm = new HashMap<String, String>();
		countryCodeISO3166Hm.put("AF", "Afghanistan");
		countryCodeISO3166Hm.put("AL", "Albania");
		countryCodeISO3166Hm.put("DZ", "Algeria");
		countryCodeISO3166Hm.put("AS", "American Samoa");
		countryCodeISO3166Hm.put("AD", "Andorra");
		countryCodeISO3166Hm.put("AO", "Angola");
		countryCodeISO3166Hm.put("AI", "Anguilla");
		countryCodeISO3166Hm.put("AQ", "Antarctica");
		countryCodeISO3166Hm.put("AG", "Antigua And Barbuda");
		countryCodeISO3166Hm.put("AR", "Argentina");
		countryCodeISO3166Hm.put("AM", "Armenia");
		countryCodeISO3166Hm.put("AW", "Aruba");
		countryCodeISO3166Hm.put("AU", "Australia");
		countryCodeISO3166Hm.put("AT", "Austria");
		countryCodeISO3166Hm.put("AZ", "Azerbaijan");
		countryCodeISO3166Hm.put("BS", "Bahamas");
		countryCodeISO3166Hm.put("BH", "Bahrain");
		countryCodeISO3166Hm.put("BD", "Bangladesh");
		countryCodeISO3166Hm.put("BB", "Barbados");
		countryCodeISO3166Hm.put("BY", "Belarus");
		countryCodeISO3166Hm.put("BE", "Belgium");
		countryCodeISO3166Hm.put("BZ", "Belize");
		countryCodeISO3166Hm.put("BJ", "Benin");
		countryCodeISO3166Hm.put("BM", "Bermuda");
		countryCodeISO3166Hm.put("BT", "Bhutan");
		countryCodeISO3166Hm.put("BO", "Bolivia");
		countryCodeISO3166Hm.put("BA", "Bosnia And Herzegovina");
		countryCodeISO3166Hm.put("BW", "Botswana");
		countryCodeISO3166Hm.put("BV", "Bouvet Island");
		countryCodeISO3166Hm.put("BR", "Brazil");
		countryCodeISO3166Hm.put("IO", "British Indian Ocean Territory");
		countryCodeISO3166Hm.put("BN", "Brunei Darussalam");
		countryCodeISO3166Hm.put("BG", "България");
		//countryCodeISO3166Hm.put("BG", "Bulgaria");
		countryCodeISO3166Hm.put("BF", "Burkina Faso");
		countryCodeISO3166Hm.put("BI", "Burundi");
		countryCodeISO3166Hm.put("KH", "Cambodia");
		countryCodeISO3166Hm.put("CM", "Cameroon");
		countryCodeISO3166Hm.put("CA", "Canada");
		countryCodeISO3166Hm.put("CV", "Cape Verde");
		countryCodeISO3166Hm.put("KY", "Cayman Islands");
		countryCodeISO3166Hm.put("CF", "Central African Republic");
		countryCodeISO3166Hm.put("TD", "Chad");
		countryCodeISO3166Hm.put("CL", "Chile");
		countryCodeISO3166Hm.put("CN", "China");
		countryCodeISO3166Hm.put("CX", "Christmas Island");
		countryCodeISO3166Hm.put("CC", "Cocos (keeling) Islands");
		countryCodeISO3166Hm.put("CO", "Colombia");
		countryCodeISO3166Hm.put("KM", "Comoros");
		countryCodeISO3166Hm.put("CG", "Congo");
		countryCodeISO3166Hm.put("CD", "Congo, The Democratic Republic Of The");
		countryCodeISO3166Hm.put("CK", "Cook Islands");
		countryCodeISO3166Hm.put("CR", "Costa Rica");
		countryCodeISO3166Hm.put("CI", "Cote D'ivoire");
		countryCodeISO3166Hm.put("HR", "Croatia");
		countryCodeISO3166Hm.put("CU", "Cuba");
		countryCodeISO3166Hm.put("CY", "Cyprus");
		countryCodeISO3166Hm.put("CZ", "Czech Republic");
		countryCodeISO3166Hm.put("DK", "Denmark");
		countryCodeISO3166Hm.put("DJ", "Djibouti");
		countryCodeISO3166Hm.put("DM", "Dominica");
		countryCodeISO3166Hm.put("DO", "Dominican Republic");
		countryCodeISO3166Hm.put("TP", "East Timor");
		countryCodeISO3166Hm.put("EC", "Ecuador");
		countryCodeISO3166Hm.put("EG", "Egypt");
		countryCodeISO3166Hm.put("SV", "El Salvador");
		countryCodeISO3166Hm.put("GQ", "Equatorial Guinea");
		countryCodeISO3166Hm.put("ER", "Eritrea");
		countryCodeISO3166Hm.put("EE", "Estonia");
		countryCodeISO3166Hm.put("ET", "Ethiopia");
		countryCodeISO3166Hm.put("FK", "Falkland Islands (malvinas)");
		countryCodeISO3166Hm.put("FO", "Faroe Islands");
		countryCodeISO3166Hm.put("FJ", "Fiji");
		countryCodeISO3166Hm.put("FI", "Finland");
		countryCodeISO3166Hm.put("FR", "France");
		countryCodeISO3166Hm.put("GF", "French Guiana");
		countryCodeISO3166Hm.put("PF", "French Polynesia");
		countryCodeISO3166Hm.put("TF", "French Southern Territories");
		countryCodeISO3166Hm.put("GA", "Gabon");
		countryCodeISO3166Hm.put("GM", "Gambia");
		countryCodeISO3166Hm.put("GE", "Georgia");
		countryCodeISO3166Hm.put("DE", "Germany");
		countryCodeISO3166Hm.put("GH", "Ghana");
		countryCodeISO3166Hm.put("GI", "Gibraltar");
		countryCodeISO3166Hm.put("GR", "Greece");
		countryCodeISO3166Hm.put("GL", "Greenland");
		countryCodeISO3166Hm.put("GD", "Grenada");
		countryCodeISO3166Hm.put("GP", "Guadeloupe");
		countryCodeISO3166Hm.put("GU", "Guam");
		countryCodeISO3166Hm.put("GT", "Guatemala");
		countryCodeISO3166Hm.put("GN", "Guinea");
		countryCodeISO3166Hm.put("GW", "Guinea-bissau");
		countryCodeISO3166Hm.put("GY", "Guyana");
		countryCodeISO3166Hm.put("HT", "Haiti");
		countryCodeISO3166Hm.put("HM", "Heard Island And Mcdonald Islands");
		countryCodeISO3166Hm.put("VA", "Holy See (vatican City State)");
		countryCodeISO3166Hm.put("HN", "Honduras");
		countryCodeISO3166Hm.put("HK", "Hong Kong");
		countryCodeISO3166Hm.put("HU", "Hungary");
		countryCodeISO3166Hm.put("IS", "Iceland");
		countryCodeISO3166Hm.put("IN", "India");
		countryCodeISO3166Hm.put("ID", "Indonesia");
		countryCodeISO3166Hm.put("IR", "Iran, Islamic Republic Of");
		countryCodeISO3166Hm.put("IQ", "Iraq");
		countryCodeISO3166Hm.put("IE", "Ireland");
		countryCodeISO3166Hm.put("IL", "Israel");
		countryCodeISO3166Hm.put("IT", "Italy");
		countryCodeISO3166Hm.put("JM", "Jamaica");
		countryCodeISO3166Hm.put("JP", "Japan");
		countryCodeISO3166Hm.put("JO", "Jordan");
		countryCodeISO3166Hm.put("KZ", "Kazakstan");
		countryCodeISO3166Hm.put("KE", "Kenya");
		countryCodeISO3166Hm.put("KI", "Kiribati");
		countryCodeISO3166Hm.put("KP", "Korea, Democratic People's Republic Of");
		countryCodeISO3166Hm.put("KR", "Korea, Republic Of");
		countryCodeISO3166Hm.put("KV", "Kosovo");
		countryCodeISO3166Hm.put("KW", "Kuwait");
		countryCodeISO3166Hm.put("KG", "Kyrgyzstan");
		countryCodeISO3166Hm.put("LA", "Lao People's Democratic Republic");
		countryCodeISO3166Hm.put("LV", "Latvia");
		countryCodeISO3166Hm.put("LB", "Lebanon");
		countryCodeISO3166Hm.put("LS", "Lesotho");
		countryCodeISO3166Hm.put("LR", "Liberia");
		countryCodeISO3166Hm.put("LY", "Libyan Arab Jamahiriya");
		countryCodeISO3166Hm.put("LI", "Liechtenstein");
		countryCodeISO3166Hm.put("LT", "Lithuania");
		countryCodeISO3166Hm.put("LU", "Luxembourg");
		countryCodeISO3166Hm.put("MO", "Macau");		
		countryCodeISO3166Hm.put("MG", "Madagascar");
		countryCodeISO3166Hm.put("MW", "Malawi");
		countryCodeISO3166Hm.put("MY", "Malaysia");
		countryCodeISO3166Hm.put("MV", "Maldives");
		countryCodeISO3166Hm.put("ML", "Mali");
		countryCodeISO3166Hm.put("MT", "Malta");
		countryCodeISO3166Hm.put("MH", "Marshall Islands");
		countryCodeISO3166Hm.put("MQ", "Martinique");
		countryCodeISO3166Hm.put("MR", "Mauritania");
		countryCodeISO3166Hm.put("MU", "Mauritius");
		countryCodeISO3166Hm.put("YT", "Mayotte");
		countryCodeISO3166Hm.put("MX", "Mexico");
		countryCodeISO3166Hm.put("FM", "Micronesia, Federated States Of");
		countryCodeISO3166Hm.put("MD", "Moldova, Republic Of");
		countryCodeISO3166Hm.put("MC", "Monaco");
		countryCodeISO3166Hm.put("MN", "Mongolia");
		countryCodeISO3166Hm.put("MS", "Montserrat");
		countryCodeISO3166Hm.put("ME", "Montenegro");
		countryCodeISO3166Hm.put("MA", "Morocco");
		countryCodeISO3166Hm.put("MZ", "Mozambique");
		countryCodeISO3166Hm.put("MM", "Myanmar");
		countryCodeISO3166Hm.put("NA", "Namibia");
		countryCodeISO3166Hm.put("NR", "Nauru");
		countryCodeISO3166Hm.put("NP", "Nepal");
		countryCodeISO3166Hm.put("NL", "Netherlands");
		countryCodeISO3166Hm.put("AN", "Netherlands Antilles");
		countryCodeISO3166Hm.put("NC", "New Caledonia");
		countryCodeISO3166Hm.put("NZ", "New Zealand");
		countryCodeISO3166Hm.put("NI", "Nicaragua");
		countryCodeISO3166Hm.put("NE", "Niger");
		countryCodeISO3166Hm.put("NG", "Nigeria");
		countryCodeISO3166Hm.put("NU", "Niue");
		countryCodeISO3166Hm.put("NF", "Norfolk Island");
		countryCodeISO3166Hm.put("MK", "North Macedonia");
		countryCodeISO3166Hm.put("MP", "Northern Mariana Islands");
		countryCodeISO3166Hm.put("NO", "Norway");
		countryCodeISO3166Hm.put("OM", "Oman");
		countryCodeISO3166Hm.put("PK", "Pakistan");
		countryCodeISO3166Hm.put("PW", "Palau");
		countryCodeISO3166Hm.put("PS", "Palestinian Territory, Occupied");
		countryCodeISO3166Hm.put("PA", "Panama");
		countryCodeISO3166Hm.put("PG", "Papua New Guinea");
		countryCodeISO3166Hm.put("PY", "Paraguay");
		countryCodeISO3166Hm.put("PE", "Peru");
		countryCodeISO3166Hm.put("PH", "Philippines");
		countryCodeISO3166Hm.put("PN", "Pitcairn");
		countryCodeISO3166Hm.put("PL", "Poland");
		countryCodeISO3166Hm.put("PT", "Portugal");
		countryCodeISO3166Hm.put("PR", "Puerto Rico");
		countryCodeISO3166Hm.put("QA", "Qatar");
		countryCodeISO3166Hm.put("RE", "Reunion");
		countryCodeISO3166Hm.put("RO", "Romania");
		countryCodeISO3166Hm.put("RU", "Russian Federation");
		countryCodeISO3166Hm.put("RW", "Rwanda");
		countryCodeISO3166Hm.put("SH", "Saint Helena");
		countryCodeISO3166Hm.put("KN", "Saint Kitts And Nevis");
		countryCodeISO3166Hm.put("LC", "Saint Lucia");
		countryCodeISO3166Hm.put("PM", "Saint Pierre And Miquelon");
		countryCodeISO3166Hm.put("VC", "Saint Vincent And The Grenadines");
		countryCodeISO3166Hm.put("WS", "Samoa");
		countryCodeISO3166Hm.put("SM", "San Marino");
		countryCodeISO3166Hm.put("ST", "Sao Tome And Principe");
		countryCodeISO3166Hm.put("SA", "Saudi Arabia");
		countryCodeISO3166Hm.put("SN", "Senegal");
		countryCodeISO3166Hm.put("RS", "Serbia");
		countryCodeISO3166Hm.put("SC", "Seychelles");
		countryCodeISO3166Hm.put("SL", "Sierra Leone");
		countryCodeISO3166Hm.put("SG", "Singapore");
		countryCodeISO3166Hm.put("SK", "Slovakia");
		countryCodeISO3166Hm.put("SI", "Slovenia");
		countryCodeISO3166Hm.put("SB", "Solomon Islands");
		countryCodeISO3166Hm.put("SO", "Somalia");
		countryCodeISO3166Hm.put("ZA", "South Africa");
		countryCodeISO3166Hm.put("GS", "South Georgia And The South Sandwich Islands");
		countryCodeISO3166Hm.put("ES", "Spain");
		countryCodeISO3166Hm.put("LK", "Sri Lanka");
		countryCodeISO3166Hm.put("SD", "Sudan");
		countryCodeISO3166Hm.put("SR", "Suriname");
		countryCodeISO3166Hm.put("SJ", "Svalbard And Jan Mayen");
		countryCodeISO3166Hm.put("SZ", "Swaziland");
		countryCodeISO3166Hm.put("SE", "Sweden");
		countryCodeISO3166Hm.put("CH", "Switzerland");
		countryCodeISO3166Hm.put("SY", "Syrian Arab Republic");
		countryCodeISO3166Hm.put("TW", "Taiwan, Province Of China");
		countryCodeISO3166Hm.put("TJ", "Tajikistan");
		countryCodeISO3166Hm.put("TZ", "Tanzania, United Republic Of");
		countryCodeISO3166Hm.put("TH", "Thailand");
		countryCodeISO3166Hm.put("TG", "Togo");
		countryCodeISO3166Hm.put("TK", "Tokelau");
		countryCodeISO3166Hm.put("TO", "Tonga");
		countryCodeISO3166Hm.put("TT", "Trinidad And Tobago");
		countryCodeISO3166Hm.put("TN", "Tunisia");
		countryCodeISO3166Hm.put("TR", "Turkey");
		countryCodeISO3166Hm.put("TM", "Turkmenistan");
		countryCodeISO3166Hm.put("TC", "Turks And Caicos Islands");
		countryCodeISO3166Hm.put("TV", "Tuvalu");
		countryCodeISO3166Hm.put("UG", "Uganda");
		countryCodeISO3166Hm.put("UA", "Ukraine");
		countryCodeISO3166Hm.put("AE", "United Arab Emirates");
		countryCodeISO3166Hm.put("GB", "United Kingdom");
		countryCodeISO3166Hm.put("US", "United States");
		countryCodeISO3166Hm.put("UM", "United States Minor Outlying Islands");
		countryCodeISO3166Hm.put("UY", "Uruguay");
		countryCodeISO3166Hm.put("UZ", "Uzbekistan");
		countryCodeISO3166Hm.put("VU", "Vanuatu");
		countryCodeISO3166Hm.put("VE", "Venezuela");
		countryCodeISO3166Hm.put("VN", "Viet Nam");
		countryCodeISO3166Hm.put("VG", "Virgin Islands, British");
		countryCodeISO3166Hm.put("VI", "Virgin Islands, U.s.");
		countryCodeISO3166Hm.put("WF", "Wallis And Futuna");
		countryCodeISO3166Hm.put("EH", "Western Sahara");
		countryCodeISO3166Hm.put("YE", "Yemen");
		countryCodeISO3166Hm.put("ZM", "Zambia");
		countryCodeISO3166Hm.put("ZW", "Zimbabwe");
	}
	
	public static String[] getAllCountryCodesISO3166() {
		return ALL_COUNTRY_CODES_ISO3166;
	}
	
	public static Map<String, String> getCountryCodesISO3166Hm() {
		return countryCodeISO3166Hm;
	}
}
