package com.ibs.user.profile.service.bean;

public class UserProfileIdentifierBean {
	String identifier = null;
	String identifierCountryCode = null;
	int identifierType = 0;
	
	public String getIdentifier() {
		return identifier;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public String getIdentifierCountryCode() {
		return identifierCountryCode;
	}
	public void setIdentifierCountryCode(String identifierCountryCode) {
		this.identifierCountryCode = identifierCountryCode;
	}
	public int getIdentifierType() {
		return identifierType;
	}
	public void setIdentifierType(int identifierType) {
		this.identifierType = identifierType;
	}

}
