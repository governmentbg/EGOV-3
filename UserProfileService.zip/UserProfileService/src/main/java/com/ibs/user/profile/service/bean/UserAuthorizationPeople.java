package com.ibs.user.profile.service.bean;

import com.ibs.user.profile.service.UserProfileServiceConstants;

public class UserAuthorizationPeople {
	String name = null;
	String pid = null;
	String rnu = null;
	int profileType = UserProfileServiceConstants.USER_PROFILE_TYPE_PERSONAL;
	UserAuthorizationSystem system = null;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getRnu() {
		return rnu;
	}
	public void setRnu(String rnu) {
		this.rnu = rnu;
	}
	public int getProfileType() {
		return profileType;
	}
	public void setProfileType(int profileType) {
		this.profileType = profileType;
	}
	public UserAuthorizationSystem getSystem() {
		return system;
	}
	public void setSystem(UserAuthorizationSystem system) {
		this.system = system;
	}

}
