package com.ibs.user.profile.service.bean;

import java.util.ArrayList;

import com.ibs.user.profile.service.UserProfileServiceConstants;

public class UserAdministrationsProfile {
	String personalIdentifier = null;
	int profileIdType = UserProfileServiceConstants.USER_PROFILE_ID_TYPE_EGN;
	ArrayList<UserAdministrationsAdministration> administrations = null;
	
	public String getPersonalIdentifier() {
		return personalIdentifier;
	}
	public void setPersonalIdentifier(String personalIdentifier) {
		this.personalIdentifier = personalIdentifier;
	}
	public int getProfileIdType() {
		return profileIdType;
	}
	public void setProfileIdType(int profileIdType) {
		this.profileIdType = profileIdType;
	}
	public ArrayList<UserAdministrationsAdministration> getAdministrations() {
		return administrations;
	}
	public void setAdministrations(ArrayList<UserAdministrationsAdministration> administrations) {
		this.administrations = administrations;
	}

}
