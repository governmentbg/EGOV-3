package com.ibs.user.profile.service.bean;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UserContactProfile {
	String identifier = null;
	@JsonProperty("address")
	Map<String, Object> userContactProfileAddress = null;
	String phone = null;
	String email = null;
	
	public String getIdentifier() {
		return identifier;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public Map<String, Object> getUserContactProfileAddress() {
		return userContactProfileAddress;
	}
	public void setUserContactProfileAddress(Map<String, Object> userContactProfileAddress) {
		this.userContactProfileAddress = userContactProfileAddress;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
}
