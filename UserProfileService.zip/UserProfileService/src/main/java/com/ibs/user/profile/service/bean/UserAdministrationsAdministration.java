package com.ibs.user.profile.service.bean;

import java.util.ArrayList;
import java.util.List;

import com.ibs.user.profile.service.UserProfileServiceConstants;

public class UserAdministrationsAdministration {
	String title = null;
	String eik = null;
	int profileType = UserProfileServiceConstants.USER_PROFILE_TYPE_PERSONAL;
	List<UserAdministrationsProfileStructureType> profileStructureType = new ArrayList<UserAdministrationsProfileStructureType>();
	List<String> roles = null;
	List<UserAdministrationsXCRole> xcRoles = null;
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getEik() {
		return eik;
	}	
	public void setEik(String eik) {
		this.eik = eik;
	}
	public int getProfileType() {
		return profileType;
	}
	public void setProfileType(int profileType) {
		this.profileType = profileType;
	}	
	public List<UserAdministrationsProfileStructureType> getProfileStructureType() {
		return profileStructureType;
	}
	public void setProfileStructureType(List<UserAdministrationsProfileStructureType> profileStructureType) {
		this.profileStructureType = profileStructureType;
	}
	public List<String> getRoles() {
		return roles;
	}
	public void setRoles(List<String> roles) {
		this.roles = roles;
	}
	public List<UserAdministrationsXCRole> getXcRoles() {
		return xcRoles;
	}
	public void setXcRoles(List<UserAdministrationsXCRole> xcRoles) {
		this.xcRoles = xcRoles;
	}
}
