package com.ibs.user.profile.service;

public class UserProfileServiceConstants {
	public static final int USER_PROFILE_TYPE_PERSONAL = 1;
	public static final int USER_PROFILE_TYPE_LEGAL_ENTITY = 2;
	public static final int USER_PROFILE_TYPE_SERVICE_SUPPLIER = 3;
	public static final int USER_PROFILE_TYPE_LEGAL_ENTITY_AL2 = 4;
	
	public static final int USER_PROFILE_ID_TYPE_EGN = 1;
	public static final int USER_PROFILE_ID_TYPE_LNC = 2;
	public static final int USER_PROFILE_ID_TYPE_EIK = 3;
	public static final int USER_PROFILE_ID_TYPE_BULSTAT = 4;

	public static final int USER_PROFILE_STATUS_ACTIVE = 1;
	
	// User types.
	public static final int AUTHORIZATION_USER_TYPE_PERSON = 1;
	public static final int AUTHORIZATION_USER_TYPE_LE = 2;	
		
	// Authorized identifier types.
	public static final int AUTHORIZATION_AUTHORIZED_IDENTIFIER_TYPE_EGN = 1;
	public static final int AUTHORIZATION_AUTHORIZED_IDENTIFIER_TYPE_EIK = 3;
	
	// Authorized types.
	public static final int AUTHORIZATION_AUTHORIZED_TYPE_PERSON = 1;
	public static final int AUTHORIZATION_AUTHORIZED_TYPE_LE = 2;
	
	public static final int AUTHORIZATION_STATUS_INACTIVE = 0; //virtual.
	public static final int AUTHORIZATION_STATUS_ACTIVE = 1;
	public static final int AUTHORIZATION_STATUS_CANCELED = 2;
	public static final int AUTHORIZATION_STATUS_EXPIRED = 9; //virtual.
	
	public static final String USER_PROFILE_ROLE_SELECTED = "1";	
	
	
	public static final int INVITATION_STATUS_NOT_CONFIRMED = 0;
	public static final int INVITATION_STATUS_CONFIRMED = 1;
	public static final int INVITATION_STATUS_CANCELED = 2;
	
}
