package com.ibs.user.profile.service;

public class UserProfileServiceConstants {
	public static final int USER_PROFILE_TYPE_PERSONAL = 1;
	public static final int USER_PROFILE_TYPE_LEGAL_ENTITY = 2;
	public static final int USER_PROFILE_TYPE_SERVICE_SUPPLIER = 3;
	public static final int USER_PROFILE_TYPE_LEGAL_ENTITY_AL2 = 4;
	
	public static final int USER_PROFILE_ID_TYPE_EGN = 1;
	public static final int USER_PROFILE_ID_TYPE_LNC = 2;
	public static final int USER_PROFILE_ID_TYPE_EIK = 3;
	public static final int USER_PROFILE_ID_TYPE_BULSTAT = 4;

	public static final int USER_PROFILE_STATUS_ACTIVE = 1;
	
	// User types.
	public static final int AUTHORIZATION_USER_TYPE_PERSON = 1;
	public static final int AUTHORIZATION_USER_TYPE_LE = 2;	
		
	// Authorized identifier types.
	public static final int AUTHORIZATION_AUTHORIZED_IDENTIFIER_TYPE_EGN = 1;
	public static final int AUTHORIZATION_AUTHORIZED_IDENTIFIER_TYPE_EIK = 3;
	
	// Authorized types.
	public static final int AUTHORIZATION_AUTHORIZED_TYPE_PERSON = 1;
	public static final int AUTHORIZATION_AUTHORIZED_TYPE_LE = 2;
	
	public static final int AUTHORIZATION_STATUS_INACTIVE = 0; //virtual.
	public static final int AUTHORIZATION_STATUS_ACTIVE = 1;
	public static final int AUTHORIZATION_STATUS_CANCELED = 2;
	public static final int AUTHORIZATION_STATUS_EXPIRED = 9; //virtual.
	
	public static final String USER_PROFILE_ROLE_SELECTED = "1";
	public static final String USER_PROFILE_CHANGE_EMAIL_CONFIRMED = "1";
	
	public static final String _EGOV_IDENTIFIER_KEY = "_REPLACED_";
	public static final String _EGOV_IDENTIFIER_IV_KEY = "_REPLACED_";
	
	public static final String LDAP_ATTRIBUTE_UID = "_REPLACED_";
	public static final String LDAP_ATTRIBUTE_ROOM_NUMBER = "_REPLACED_";
	public static final String LDAP_ATTRIBUTE_EGOV_IDENTIFIER = "_REPLACED_";
	// We store identifier prefix.
	public static final String LDAP_ATTRIBUTE_DEPARTMENT_NUMBER = "_REPLACED_";
	// We store the invitation id. (only during the request)
	public static final String LDAP_ATTRIBUTE_INVITATION_ID = "_REPLACED_";
	public static final String E_FORMS_SECRET_KEY_IN_BASE_64 = "_REPLACED_";
	
	// Identifiers prefixes.
	public static final String IDENTIFIER_PREFIX_EGN = "_REPLACED_";
	public static final String IDENTIFIER_PREFIX_LNC = "_REPLACED_";	
	public static final String IDENTIFIER_PREFIX_CARD_NUMBER = "_REPLACED_";
	
	public static final String IDENTIFIER_TYPE_PERSONAL_CARD_NUMBER = "1";
	public static final String IDENTIFIER_TYPE_PASSPORT = "2";
	public static final String IDENTIFIER_TYPE_PIK_NRA = "3";
	public static final String IDENTIFIER_TYPE_PIK_NOI = "4";
	public static final String IDENTIFIER_TYPE_EORI = "5";
	public static final String IDENTIFIER_TYPE_NATIONAL_IDENTIFIER_FOREIGNER = "6";
	
	public static final int OPERATION_TYPE_REMOVE_IDENTIFIER = 0;
	public static final int OPERATION_TYPE_ADD_IDENTIFIER = 1;	
	
	public static final String COUNTRY_CODE_BG = "BG";
	
	public static final String EVENT_LOG_PORTAL_ADD_PROFILE_IDENTIFIER = "PORTAL_ADD_PROFILE_IDENTIFIER";
	public static final String EVENT_LOG_PORTAL_REMOVE_PROFILE_IDENTIFIER = "PORTAL_REMOVE_PROFILE_IDENTIFIER";
	
	public static final String ESB_LOGGING_URL_TEST = "_REPLACED_";
	public static final String ESB_LOGGING_URL = "_REPLACED_";

	public static final int INVITATION_STATUS_NOT_CONFIRMED = 0;
	public static final int INVITATION_STATUS_CONFIRMED = 1;
	public static final int INVITATION_STATUS_CANCELED = 2;
	
	public static final int INVITATION_PROCESSED_YES = 1;
	
	public static final String EMAIL_FROM_ADDRESS = "_REPLACED_";
	
	public static final String ESB_PROD_IP_LOAD_BALANCER = "_REPLACED_";
	public static final String ESB_PROD_IP_NODE1 = "_REPLACED_";
	public static final String ESB_PROD_IP_NODE2 = "_REPLACED_";	
	
	public static final String[] ALLOWED_IP_ADDRESSES = {ESB_PROD_IP_LOAD_BALANCER, ESB_PROD_IP_NODE1, ESB_PROD_IP_NODE2};
}
