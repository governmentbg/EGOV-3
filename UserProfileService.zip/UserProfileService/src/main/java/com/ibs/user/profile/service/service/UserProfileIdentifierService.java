package com.ibs.user.profile.service.service;

import java.util.Date;
import java.util.List;

import org.json.JSONArray;

import com.ibs.user.profile.service.model.db2.UserProfileIdentifier;

public interface UserProfileIdentifierService {
	boolean updateUserProfileIdentifiers(List<UserProfileIdentifier> currentIdentifiers, Long userProfileId, String senderOID, JSONArray jsonIdentifiers, Date currentDate);	
}
