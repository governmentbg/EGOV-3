package com.ibs.user.profile.service.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ibs.user.profile.service.UserProfileServiceConstants;
import com.ibs.user.profile.service.communicator.WCMCommunicator;

@Component
public class UserProfileServiceUtils {
	
	@Autowired
	WCMCommunicator wcmCommunicator;

	private final static SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH);
	private final static SimpleDateFormat dateFormat_bg = new SimpleDateFormat("dd.MM.yyyy", Locale.ENGLISH);
	private final static SimpleDateFormat dateTimeFormat_bg = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.ENGLISH);
	private final static SimpleDateFormat dateTimeFormatLog = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss:SSS", Locale.ENGLISH);
	
	public boolean isAuthorizationActive(int status, Date validFrom, Date validTo) {
		if (UserProfileServiceConstants.AUTHORIZATION_STATUS_ACTIVE == status) {
			Date today = new Date();
			if (today.compareTo(validFrom) < 0) { // not active yet.
				return false;
            } else if (today.compareTo(validTo) > 0) { // expired.
            	return false;
            } 
			return true;
		} else if (UserProfileServiceConstants.AUTHORIZATION_STATUS_CANCELED == status) {
			return false;
		}
		return false;
	}

	public String[] getArrayFromFormatedField(String str) {
		if (str != null && str.trim().length() > 0) {
			str = str.trim();
			if (str.indexOf("^^") != -1) {
				String[] systemsAndActionsStr = str.split("\\^\\^");
				String[] systemsAndActions = new String[systemsAndActionsStr.length];
				for (int i = 0; i < systemsAndActionsStr.length; i++) {
					systemsAndActions[i] = systemsAndActionsStr[i].replaceAll("\\^", "");
				}
				return systemsAndActions;
			} else {
				return new String[] {str.replaceAll("\\^", "")};
			}
		}
		return null;
	}
	
	public String timeMillisToDD_MM_YYYY(final long timeMillis) {
		try {
			final Date date = new Date(timeMillis);
			return dateFormat_bg.format(date);
		} catch (Exception e) {
			System.out.println("Utils : timeMillisToDD_MM_YYYY : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}
	
	public String timeMillisToDD_MM_YYYY_HH_mm_ss(final long timeMillis) {
		try {
			final Date date = new Date(timeMillis);
			return dateTimeFormat_bg.format(date);
		} catch (Exception e) {
			System.out.println("Utils : timeMillisToDD_MM_YYYY_HH_mm_ss : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}
	
	public String timeMillisToLogFormat(final long timeMillis) {
		try {
			final Date date = new Date(timeMillis);
			return dateTimeFormatLog.format(date);
		} catch (Exception e) {
			System.out.println("Utils : timeMillisToLogFormat : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}
	
	public static String timeMillisToYYYY_MM_DD_HH_MM_SS(final long timeMillis) {
		try {
			final Date date = new Date(timeMillis);
			return dateTimeFormat.format(date);
		} catch (Exception e) {
			System.out.println("Utils : timeMillisToYYYY_MM_DD_HH_MM_SS : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}
	
	public String getIdentifierTypeName(String type, boolean shortName) {
		if (UserProfileServiceConstants.IDENTIFIER_TYPE_PERSONAL_CARD_NUMBER.equals(type)) {
			return shortName ? "Лична карта" : "Номер на лична карта";
		} else if (UserProfileServiceConstants.IDENTIFIER_TYPE_PASSPORT.equals(type)) {
			return shortName ? "Паспорт" : "Номер на паспорт";
		} else if (UserProfileServiceConstants.IDENTIFIER_TYPE_PIK_NRA.equals(type)) {
			return "ПИК на НАП";
		} else if (UserProfileServiceConstants.IDENTIFIER_TYPE_PIK_NOI.equals(type)) {
			return "ПИК на НОИ";
		} else if (UserProfileServiceConstants.IDENTIFIER_TYPE_EORI.equals(type)) {
			return shortName ? "EORI" : "EORI номер от Агенция \"Митници\"";
		} else if (UserProfileServiceConstants.IDENTIFIER_TYPE_NATIONAL_IDENTIFIER_FOREIGNER.equals(type)) {
			return "Национален идентификатор (ЕГН)";
		} 
		return type;
	}
	
	public String getIdentifierTypeName(Integer type, boolean shortName) {
		return this.getIdentifierTypeName(String.valueOf(type), shortName);
	}
	
	public String getProfileTypeName(Integer type) {
		if (UserProfileServiceConstants.USER_PROFILE_TYPE_PERSONAL == type) {
			return "Физическо лице";
		} else if (UserProfileServiceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY == type) {
			return "Юридическо лице";
		} else if (UserProfileServiceConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER == type) {
			return "Лице по чл. 1 ал. 1 от ЗЕУ";
		} else if (UserProfileServiceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY_AL2 == type) {
			return "Лице по чл. 1 ал. 2 от ЗЕУ";
		} 
		return "N/A";
	}
	
	public String getProfileStructureTypeNames(String profileStructureType) {
		if (profileStructureType != null && profileStructureType.trim().length() > 0) {
			if (profileStructureType.indexOf("^^") != -1) {
				String[] profileStructureTypeIds = profileStructureType.split("\\^\\^");
				String profileNames = "";
				for (int i = 0; i < profileStructureTypeIds.length; i++) {
					if (i > 0) {
						profileNames += ", ";
					}
					profileNames += wcmCommunicator.getProfileStructureTypeName(profileStructureTypeIds[i].replaceAll("\\^", ""));
				}
				return profileNames;
			} else {
				profileStructureType = profileStructureType.replaceAll("\\^", "");
				return wcmCommunicator.getProfileStructureTypeName(profileStructureType);
			}
		}
		return "";
	}
	
	// Generate a UUID compliant with RFC 4122.
	public String generateRNU() {
		return UUID.randomUUID().toString();
	}


}
