package com.ibs.user.profile.service.model.db2;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.data.annotation.CreatedDate;

@Entity
public class UserProfileXCRole {
	
	@Id
	private Long userProfileXCRoleId;
	@Column(nullable = false)
	private Long userProfileId;
	@Column(nullable = false)
	private String userUid;
	@Column(nullable = false)
	private Long horizontalSystemRoleId;
	@Column(name = "dateCreated", nullable = false, updatable = false)
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate    
    private Date createdAt;	
    
	public Long getUserProfileXCRoleId() {
		return userProfileXCRoleId;
	}
	public void setUserProfileXCRoleId(Long userProfileXCRoleId) {
		this.userProfileXCRoleId = userProfileXCRoleId;
	}
	public Long getUserProfileId() {
		return userProfileId;
	}
	public void setUserProfileId(Long userProfileId) {
		this.userProfileId = userProfileId;
	}
	public String getUserUid() {
		return userUid;
	}
	public void setUserUid(String userUid) {
		this.userUid = userUid;
	}
	public Long getHorizontalSystemRoleId() {
		return horizontalSystemRoleId;
	}
	public void setHorizontalSystemRoleId(Long horizontalSystemRoleId) {
		this.horizontalSystemRoleId = horizontalSystemRoleId;
	}
	public Date getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(Date createdAt) {
		this.createdAt = createdAt;
	}
}
