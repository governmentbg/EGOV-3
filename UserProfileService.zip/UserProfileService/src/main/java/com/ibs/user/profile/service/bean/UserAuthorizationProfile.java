package com.ibs.user.profile.service.bean;

import java.util.List;

public class UserAuthorizationProfile {
	String identifier = null;
	List<UserAuthorizationPeople> people = null;
	
	public String getIdentifier() {
		return identifier;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public List<UserAuthorizationPeople> getPeople() {
		return people;
	}
	public void setPeople(List<UserAuthorizationPeople> people) {
		this.people = people;
	}

}
