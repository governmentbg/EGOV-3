package com.ibs.user.profile.service.bean;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

public class UserContactProfileAddressEkatte {
	@JsonProperty("Област")
	String district = null;
	@JsonProperty("Община")
	String municipality = null;
	@JsonProperty("Населено място")
	String settlement = null;
	@JsonProperty("Район")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	String area = null;
	@JsonProperty("ЕКАТТЕ")
	String ekatte = null;
	
	public String getDistrict() {
		return district;
	}
	public void setDistrict(String district) {
		this.district = district;
	}
	public String getMunicipality() {
		return municipality;
	}
	public void setMunicipality(String municipality) {
		this.municipality = municipality;
	}
	public String getSettlement() {
		return settlement;
	}
	public void setSettlement(String settlement) {
		this.settlement = settlement;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getEkatte() {
		return ekatte;
	}
	public void setEkatte(String ekatte) {
		this.ekatte = ekatte;
	}
	
}
