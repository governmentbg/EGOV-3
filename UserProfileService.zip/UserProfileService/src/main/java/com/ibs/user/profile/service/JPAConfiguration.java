package com.ibs.user.profile.service;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.jpa.HibernatePersistenceProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
//import org.springframework.jdbc.datasource.DriverManagerDataSource;
//import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
//import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
//import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.ibm.db2.jcc.DB2SimpleDataSource;

//@Configuration
//@EnableTransactionManagement
//@DependsOn("hibernatePersistenceProviderResolver")
@Deprecated
public class JPAConfiguration {
	
	@Autowired
	private Environment env;
    
    @Bean
    @Primary
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(db2DataSource());
        em.setPersistenceProviderClass(HibernatePersistenceProvider.class);

        em.setPackagesToScan(new String[] { "com.ibs.user.profile.service.model.db2"});        
        em.setPersistenceUnitName("org.hibernate.jpa.HibernatePersistenceProvider");

        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        vendorAdapter.setGenerateDdl(false);
        em.setJpaVendorAdapter(vendorAdapter);
        
        Properties properties = new Properties();
        if (env.containsProperty("spring.jpa.hibernate.ddl-auto")) {
        	properties.setProperty("javax.persistence.schema-generation.database.action", env.getProperty("spring.jpa.hibernate.ddl-auto"));
        	//jpaProperties.put("hibernate.hbm2ddl.auto", env.getProperty("hibernate.hbm2ddl.auto"));
        }
        if (env.containsProperty("spring.jpa.database-platform")) {
        	properties.setProperty("hibernate.dialect", env.getProperty("spring.jpa.database-platform"));
        }
        if (env.containsProperty("spring.jpa.show-sql")) {
        	properties.setProperty("hibernate.show_sql", env.getProperty("spring.jpa.show-sql"));
        }
        if (env.containsProperty("spring.jpa.properties.hibernate.format_sql")) {
        	properties.setProperty("hibernate.format_sql", env.getProperty("spring.jpa.properties.hibernate.format_sql"));
        }
        em.setJpaProperties(properties);
        return em;
    }
    
//    @Bean
//    @Primary
//    public DataSource h2DataSource() {
//        return new EmbeddedDatabaseBuilder().setType(EmbeddedDatabaseType.H2).build();
//    }
    
//    @Bean
//    @Primary
//    public DataSource dataSource(){
//    	DriverManagerDataSource dataSource = new DriverManagerDataSource();   
//    	dataSource.setDriverClassName(env.getProperty("spring.datasource.driver-class-name"));
//    	dataSource.setUrl(env.getProperty("spring.datasource.url"));
//    	dataSource.setUsername(env.getProperty("spring.datasource.username"));
//    	dataSource.setPassword(env.getProperty("spring.datasource.password"));
//    	return dataSource;
//    }
    
    @Bean
    @Primary
    public DataSource db2DataSource(){
    	DB2SimpleDataSource dataSource = new DB2SimpleDataSource();     
    	dataSource.setUser(env.getProperty("spring.datasource.username"));
    	dataSource.setPassword(env.getProperty("spring.datasource.password"));
    	dataSource.setServerName(env.getProperty("spring.datasource.oracleucp.server-name"));
    	dataSource.setDatabaseName(env.getProperty("spring.datasource.oracleucp.database-name"));
    	dataSource.setPortNumber(Integer.parseInt(env.getProperty("spring.datasource.oracleucp.port-number")));
    	dataSource.setDriverType(4);  
    	dataSource.setCurrentSchema(env.getProperty("spring.datasource.oracleucp.database-name").toUpperCase());
    	return dataSource;
    }
    
    @Bean
    public DataSource mariaDataSource(){
    	DriverManagerDataSource dataSource = new DriverManagerDataSource();  
    	dataSource.setDriverClassName(env.getProperty("spring.secondDatasource.driverClassName"));                        
		dataSource.setUrl(env.getProperty("spring.secondDatasource.url"));        
		dataSource.setUsername(env.getProperty("spring.secondDatasource.username"));
		dataSource.setPassword(env.getProperty("spring.secondDatasource.password"));  
        return dataSource;
    }
        
    @Bean
    @Primary
    public PlatformTransactionManager transactionManager() {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory().getObject());
        return transactionManager;
    }
}