package com.ibs.user.profile.service.dao.mariadb;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ibs.user.profile.service.model.mariadb.Authorizations;

@Repository
public interface AuthorizationsRepository extends JpaRepository<Authorizations, Long> {
	Authorizations findByRnu(String rnu);	
	List<Authorizations> findAllByUserIdentifierAndStatus(String userIdentifier, int status);	
	List<Authorizations> findAllByUserIdentifierAndStatusAndSystemsLike(String userIdentifier, int status, String systemId);
	Authorizations findByRnuAndStatusAndSystemsLike(String rnu, int status, String systemId);
}
