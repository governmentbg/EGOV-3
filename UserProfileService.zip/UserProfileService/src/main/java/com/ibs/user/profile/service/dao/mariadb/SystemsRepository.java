package com.ibs.user.profile.service.dao.mariadb;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ibs.user.profile.service.model.mariadb.Systems;

@Repository
public interface SystemsRepository extends JpaRepository<Systems, Long> {
	Systems findByOid(String oid);
}
