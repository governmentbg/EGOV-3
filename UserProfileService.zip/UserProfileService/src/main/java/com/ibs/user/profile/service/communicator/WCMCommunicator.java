package com.ibs.user.profile.service.communicator; 

import java.util.List;

import org.springframework.stereotype.Component;

import com.egov.wcm.cache.EgovProfileStructureType;
import com.egov.wcm.cache.EgovWCMCache;


@Component
public class WCMCommunicator {
	
	public String getProfileStructureTypeName(String profileStructureType) {
		if (profileStructureType != null) {
			List<EgovProfileStructureType> profileStructureTypes = EgovWCMCache.getProfileStructureTypes();
			if (profileStructureTypes != null && profileStructureTypes.size() > 0) {
				for (int i = 0; i < profileStructureTypes.size(); i++) {
					if (profileStructureType.equalsIgnoreCase(profileStructureTypes.get(i).getName())) {
						return profileStructureTypes.get(i).getDescription() != null && profileStructureTypes.get(i).getDescription().trim().length() > 0 ? profileStructureTypes.get(i).getDescription() : profileStructureTypes.get(i).getTitle();
					}
				}				
			}
		}
		return "";
	}
}
