package com.ibs.user.profile.service.dao.db2;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ibs.user.profile.service.model.db2.UserProfilePersonalParameters;

@Repository
public interface UserProfilePersonalParametersRepository extends JpaRepository<UserProfilePersonalParameters, Long> {
	UserProfilePersonalParameters findByUserProfileId(Long userProfileId);
	List<UserProfilePersonalParameters> findAllByUserProfileIdIn(List<Long> userProfileIds);
}
