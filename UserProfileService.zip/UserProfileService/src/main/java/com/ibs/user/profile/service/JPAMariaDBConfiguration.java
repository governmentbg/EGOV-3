package com.ibs.user.profile.service;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.jpa.HibernatePersistenceProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
//import org.springframework.jdbc.datasource.DriverManagerDataSource;
//import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
//import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableTransactionManagement
@DependsOn("hibernatePersistenceProviderResolver")
@EnableJpaRepositories(
		basePackages = "com.ibs.user.profile.service.dao.mariadb", 
		entityManagerFactoryRef = "mariaDBEntityManager", 
	    transactionManagerRef = "mariaDBTransactionManager"
)
public class JPAMariaDBConfiguration {
	
	@Autowired
	private Environment env;
    
    @Bean
    public LocalContainerEntityManagerFactoryBean mariaDBEntityManager() {
        LocalContainerEntityManagerFactoryBean em = new LocalContainerEntityManagerFactoryBean();
        em.setDataSource(mariaDataSource());
        em.setPersistenceProviderClass(HibernatePersistenceProvider.class);

        em.setPackagesToScan(new String[] { "com.ibs.user.profile.service.model.mariadb"});        
        em.setPersistenceUnitName("org.hibernate.jpa.HibernatePersistenceProvider");

        HibernateJpaVendorAdapter vendorAdapter = new HibernateJpaVendorAdapter();
        vendorAdapter.setGenerateDdl(false);
        em.setJpaVendorAdapter(vendorAdapter);
        
        Properties properties = new Properties();
        if (env.containsProperty("spring.jpa.hibernate.ddl-auto")) {
        	properties.setProperty("javax.persistence.schema-generation.database.action", env.getProperty("spring.jpa.hibernate.ddl-auto"));
        	//jpaProperties.put("hibernate.hbm2ddl.auto", env.getProperty("hibernate.hbm2ddl.auto"));
        }
        if (env.containsProperty("spring.jpa.database-platform")) {
        	properties.setProperty("hibernate.dialect", env.getProperty("spring.jpa.database-platform-maria-db"));
        }
        if (env.containsProperty("spring.jpa.show-sql")) {
        	properties.setProperty("hibernate.show_sql", env.getProperty("spring.jpa.show-sql"));
        }
        if (env.containsProperty("spring.jpa.properties.hibernate.format_sql")) {
        	properties.setProperty("hibernate.format_sql", env.getProperty("spring.jpa.properties.hibernate.format_sql"));
        }
        em.setJpaProperties(properties);
        return em;
    }
    
    @Bean
    public DataSource mariaDataSource(){
    	DriverManagerDataSource dataSource = new DriverManagerDataSource();  
    	dataSource.setDriverClassName(env.getProperty("spring.secondDatasource.driverClassName"));   
    	if (ServletInitializer.TEST_ENVIRONMENT) {
    		dataSource.setUrl(env.getProperty("spring.secondDatasource.test.url"));        
    		dataSource.setUsername(env.getProperty("spring.secondDatasource.test.username"));
    		dataSource.setPassword(env.getProperty("spring.secondDatasource.test.password"));    		
    	} else {
    		dataSource.setUrl(env.getProperty("spring.secondDatasource.url"));        
    		dataSource.setUsername(env.getProperty("spring.secondDatasource.username"));
    		dataSource.setPassword(env.getProperty("spring.secondDatasource.password"));
    	}
        return dataSource;
    }
        
    @Bean
    public PlatformTransactionManager mariaDBTransactionManager() {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(mariaDBEntityManager().getObject());
        return transactionManager;
    }
}