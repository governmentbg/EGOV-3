package com.ibs.user.profile.service.bean;

import java.util.List;

public class UserAuthorizationSystem {
	//String OID = null;	
	List<UserAuthorizationActivity> activities = null;
	
//	public String getOID() {
//		return OID;
//	}
//	public void setOID(String oID) {
//		OID = oID;
//	}
	public List<UserAuthorizationActivity> getActivities() {
		return activities;
	}
	public void setActivities(List<UserAuthorizationActivity> activities) {
		this.activities = activities;
	}

}
