package com.ibs.myspace.portlet.bean;

public class StateOfPlayResponse {
	private int type;
	private String uic;
	private String egn;
	private String cyrillicFullName;
	private String cyrillicShortName;
	private String latinFullName;	
	private StateOfPlayResponseManager manager;
	
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public String getUic() {
		return uic;
	}
	public void setUic(String uic) {
		this.uic = uic;
	}
	public String getEgn() {
		return egn;
	}
	public void setEgn(String egn) {
		this.egn = egn;
	}
	public String getCyrillicFullName() {
		return cyrillicFullName;
	}
	public void setCyrillicFullName(String cyrillicFullName) {
		this.cyrillicFullName = cyrillicFullName;
	}
	public String getCyrillicShortName() {
		return cyrillicShortName;
	}
	public void setCyrillicShortName(String cyrillicShortName) {
		this.cyrillicShortName = cyrillicShortName;
	}
	public String getLatinFullName() {
		return latinFullName;
	}
	public void setLatinFullName(String latinFullName) {
		this.latinFullName = latinFullName;
	}
	
	public StateOfPlayResponseManager getManager() {
		return manager;
	}
	public void setManager(StateOfPlayResponseManager manager) {
		this.manager = manager;
	}
	@Override
	public String toString() {
		return "StateOfPlayResponse [type=" + type + ", uic=" + uic + ", egn=" + egn + ", cyrillicFullName=" + cyrillicFullName + ", cyrillicShortName="
				+ cyrillicShortName + ", latinFullName=" + latinFullName + "][manager=" + (manager != null ? manager.toString() : "null") + "]";
	}
	
}
