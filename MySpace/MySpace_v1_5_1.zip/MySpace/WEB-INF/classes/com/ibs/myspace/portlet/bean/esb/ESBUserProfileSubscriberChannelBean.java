package com.ibs.myspace.portlet.bean.esb;

public class ESBUserProfileSubscriberChannelBean {
	private String type = null;
	private String destination = null;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
}
