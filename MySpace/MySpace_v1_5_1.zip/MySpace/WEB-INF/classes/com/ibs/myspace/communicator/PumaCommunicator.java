package com.ibs.myspace.communicator;

import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ibm.portal.um.Group;
import com.ibm.portal.um.PumaController;
import com.ibm.portal.um.PumaEnvironment;
import com.ibm.portal.um.PumaHome;
import com.ibm.portal.um.PumaLocator;
import com.ibm.portal.um.PumaProfile;
import com.ibm.portal.um.User;
import com.ibm.portal.um.exceptions.MemberAlreadyExistsException;
import com.ibm.portal.um.exceptions.MemberNotFoundException;
import com.ibm.portal.um.exceptions.PumaAttributeException;
import com.ibm.portal.um.exceptions.PumaMissingAccessRightsException;
import com.ibm.portal.um.exceptions.PumaModelException;
import com.ibm.portal.um.exceptions.PumaSystemException;
import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.MySpacePortlet;
import com.ibs.myspace.portlet.utils.Logger;

public class PumaCommunicator {

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Object createUserAccount(final String uid, final Map userInputMap) {
    	Logger.log(Logger.DEBUG_LEVEL, "createUserAccount(" + uid + ", userInputMap) entering...");
		Object retVal = null;
		try {
			final PumaEnvironment pumaEnvironment = MySpacePortlet.getPumaHome().getEnvironment();
			final PumaController controller = MySpacePortlet.getPumaController();

			retVal = pumaEnvironment.runUnrestricted(new PrivilegedExceptionAction() {
				Object retValL = null;

				public Object run() {					
					User user = null;
					try {
						user = controller.createUser(uid, MySpaceConstants.LDAP_USERS_DN, userInputMap);
						Logger.log(Logger.DEBUG_LEVEL, "createUserAccount(" + uid + ", userInputMap) USER [" + uid + "] WAS CREATED SUCCSESSFULLY!");
						retValL = user;
					} catch (PumaAttributeException e) {
						retValL = "Attribute_Exception";
						Logger.log(Logger.ERROR_LEVEL, "createUserAccount(" + uid + ", userInputMap) [ERROR] - retValL :" + retValL + "---" + e.getMessage());
					} catch (PumaSystemException e) {
						retValL = "System_Exception";
						Logger.log(Logger.ERROR_LEVEL, "createUserAccount(" + uid + ", userInputMap) [ERROR] - retValL :" + retValL + "---" + e.getMessage());
					} catch (MemberAlreadyExistsException e) {
						retValL = "Member_Already_Exists";
						Logger.log(Logger.ERROR_LEVEL, "createUserAccount(" + uid + ", userInputMap) [ERROR] - retValL :" + retValL + "---" + e.getMessage());
					} catch (PumaModelException e) {
						retValL = "Data_Model_Exception";
						Logger.log(Logger.ERROR_LEVEL, "createUserAccount(" + uid + ", userInputMap) [ERROR] - retValL :" + retValL + "---" + e.getMessage());
					} catch (PumaMissingAccessRightsException e) {
						retValL = "Missing_Access_Rights";
						Logger.log(Logger.ERROR_LEVEL, "createUserAccount(" + uid + ", userInputMap) [ERROR] - retValL :" + retValL + "---" + e.getMessage());
					} catch (Exception e) {
						retValL = "Cannot_Create_Account";
						Logger.log(Logger.ERROR_LEVEL, "createUserAccount(" + uid + ", userInputMap) [ERROR] - retValL :" + retValL + "---" + e.getMessage());
					}
					return retValL;
				}
			});

		} catch (Exception e) {
			retVal = "Cannot_Create_Account";
			Logger.log(Logger.ERROR_LEVEL, "createUserAccount(" + uid + ", userInputMap) [ERROR] - retVal :" + retVal + "---" + e.getMessage());
			e.printStackTrace();
		}
		Logger.log(Logger.DEBUG_LEVEL, "createUserAccount(" + uid + ", userInputMap) exiting, retVal : " + retVal);
		return retVal;
	}
    
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String addUserToGroups(User user, String[] groupsArr) {	
		Logger.log(Logger.DEBUG_LEVEL, "addUserToGroups(user, groupsArr) entering...");
		if (user == null || groupsArr == null || groupsArr.length == 0) return null;
		String retVal = null;
		final ArrayList<Group> groups = new ArrayList<Group>();
		Group tmpGroup = null;
		for (int i = 0; i < groupsArr.length; i++) {
			tmpGroup = getGroup(groupsArr[i]);
			if (tmpGroup != null) {
				groups.add(tmpGroup);
			}
		}	
		Logger.log(Logger.DEBUG_LEVEL, "addUserToGroups(user, groupsArr) founded groups = " + groups.size());
		try {
			final PumaEnvironment pumaEnvironment = MySpacePortlet.getPumaHome().getEnvironment();
			final PumaController controller = MySpacePortlet.getPumaController();
			

			retVal = (String) pumaEnvironment.runUnrestricted(new PrivilegedExceptionAction() {
				String retValL = null;

				public Object run() {
					List<User> users = new ArrayList<User>();
					users.add(user);
					try {
						for (int i = 0; i < groups.size(); i++) {
							controller.addToGroup(groups.get(i), users);
							Logger.log(Logger.DEBUG_LEVEL, "addUserToGroups(user, groupsArr) USER ADDED TO GROUP = " + groups.get(i));
						}						
					} catch (PumaSystemException e) {
						retValL = "System_Exception";
						Logger.log(Logger.ERROR_LEVEL, "addUserToGroups() [ERROR] - retValL :" + retValL + "---" + e.getMessage());
					} catch (MemberAlreadyExistsException e) {
						retValL = "Group_Already_Exists";
						Logger.log(Logger.ERROR_LEVEL, "addUserToGroups() [ERROR] - retValL :" + retValL + "---" + e.getMessage());
					} catch (PumaModelException e) {
						retValL = "Data_Model_Exception";
						Logger.log(Logger.ERROR_LEVEL, "addUserToGroups() [ERROR] - retValL :" + retValL + "---" + e.getMessage());
					} catch (PumaMissingAccessRightsException e) {
						retValL = "Missing_Access_Rights";
						Logger.log(Logger.ERROR_LEVEL, "addUserToGroups() [ERROR] - retValL :" + retValL + "---" + e.getMessage());
					}
					return retValL;
				}
			});

		} catch (Exception e) {
			retVal = "Cannot_Add_Member_To_Group";
			Logger.println("addUserToGroup_new Exception " + retVal + " ---" + e.getMessage());
			e.printStackTrace();
		}
		Logger.log(Logger.DEBUG_LEVEL, "addUserToGroups(user, groupsArr) exiting, retVal: " + retVal);
		return retVal;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Group getGroup(final String groupId) {
		Logger.log(Logger.DEBUG_LEVEL, "getGroup(" + groupId + ") entering...");
		Group group = null;
		try {			
			final PumaEnvironment pumaEnvironment = MySpacePortlet.getPumaHome().getEnvironment(); 
			final PumaLocator locatorService = MySpacePortlet.getPumaHome().getLocator();
			List<Group> groups = (List<Group>) pumaEnvironment.runUnrestricted(new PrivilegedExceptionAction() {
				public Object run() throws Exception {
					return locatorService.findGroupsByDefaultAttribute(groupId);
				}
			});
			if (groups != null && groups.size() > 0) {
				group = (Group) groups.get(0);
				Logger.log(Logger.DEBUG_LEVEL, "getGroup(" + groupId + ") Successfully retrieved group - " + groupId + "!");
			}
		} catch (PrivilegedActionException e) {
			Logger.log(Logger.ERROR_LEVEL, "getGroup(" + groupId + ") [ERROR] -> " + e.getMessage());
		}
		Logger.log(Logger.DEBUG_LEVEL, "getGroup(" + groupId + ") exiting...");
		return group;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String removeUserAccount(User user) {
		Logger.log(Logger.DEBUG_LEVEL, "removeUserAccount() entering...");
		if (user == null) return null;		

		String retVal = null;
		try {
			final PumaEnvironment environment = MySpacePortlet.getPumaHome().getEnvironment();
			final PumaController controller = MySpacePortlet.getPumaController();
			retVal = (String) environment.runUnrestricted(new PrivilegedExceptionAction() {
				String retValL = null;

				public Object run() {
					try {
						controller.deleteUser(user);
					} catch (PumaSystemException e) {
						retValL = "System_Exception";
						Logger.log(Logger.ERROR_LEVEL, "removeUserAccount() [ERROR] - retValL :" + retValL + "---" + e.getMessage());
					} catch (PumaModelException e) {
						retValL = "Data_Model_Exception";
						Logger.log(Logger.ERROR_LEVEL, "removeUserAccount() [ERROR] - retValL :" + retValL + "---" + e.getMessage());
					} catch (PumaMissingAccessRightsException e) {
						retValL = "Missing_Access_Rights";
						Logger.log(Logger.ERROR_LEVEL, "removeUserAccount() [ERROR] - retValL :" + retValL + "---" + e.getMessage());
					}
					return retValL;
				}
			});
		} catch (Exception e) {
			retVal = "Cannot_Remove_User";
			Logger.log(Logger.ERROR_LEVEL, "removeUserAccount() [ERROR] - retVal :" + retVal + "---" + e.getMessage());
			e.printStackTrace();
		}
		Logger.log(Logger.DEBUG_LEVEL, "removeUserAccount() exiting..., retVal: " + retVal);
		return retVal;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String removeUserFromGroups(User user, String[] groupsArr) {
		Logger.log(Logger.DEBUG_LEVEL, "removeUserFromGroups() entering...");
		String retVal = null;
		if (groupsArr == null) return null;
		final ArrayList<Group> groups = new ArrayList<Group>();
		Group tmpGroup = null;
		for (int i = 0; i < groupsArr.length; i++) {
			tmpGroup = getGroup(groupsArr[i]);
			if (tmpGroup != null) {
				groups.add(tmpGroup);
			}
		}
		if (groups.size() == 0) {
			retVal = "Group_Not_Found";
			Logger.log(Logger.ERROR_LEVEL, "removeUserFromGroups() [ERROR] - retValL :" + retVal);
			return retVal;
		}
		try {
			final PumaEnvironment environment = MySpacePortlet.getPumaHome().getEnvironment();
			final PumaController controller = MySpacePortlet.getPumaController();
			
			
			retVal = (String) environment.runUnrestricted(new PrivilegedExceptionAction() {
				String retValL = null;
				public Object run() {
					List<User> users = new ArrayList<User>();
					users.add(user);
					try {
						for (int i = 0; i < groups.size(); i++) {
							controller.removeFromGroup(groups.get(i), users);
							Logger.log(Logger.DEBUG_LEVEL, "removeUserFromGroups() User removed from group[" + groups.get(i) + "]!");
						}	
					} catch (PumaSystemException e) {
						retValL = "System_Exception";
						Logger.log(Logger.ERROR_LEVEL, "removeUserFromGroups() [ERROR] - retValL :" + retValL + "---" + e.getMessage());
					} catch (MemberNotFoundException e) {
						retValL = "Cannot_Remove_Member_From_Group";
						Logger.log(Logger.ERROR_LEVEL, "removeUserFromGroups() [ERROR] - retValL :" + retValL + "---" + e.getMessage());
					} catch (PumaModelException e) {
						retValL = "Data_Model_Exception";
						Logger.log(Logger.ERROR_LEVEL, "removeUserFromGroups() [ERROR] - retValL :" + retValL + "---" + e.getMessage());
					} catch (PumaMissingAccessRightsException e) {
						retValL = "Missing_Access_Rights";
						Logger.log(Logger.ERROR_LEVEL, "removeUserFromGroups() [ERROR] - retValL :" + retValL + "---" + e.getMessage());
					}
					return retValL;
				}
			});

		} catch (Exception e) {
			retVal = "Cannot_Remove_Member_From_Group";
			Logger.log(Logger.ERROR_LEVEL, "removeUserFromGroups() [ERROR] - retVal :" + retVal + "---" + e.getMessage());
			e.printStackTrace();
		}
		Logger.log(Logger.DEBUG_LEVEL, "removeUserFromGroups() exiting..., retVal: " + retVal);
		return retVal;
	}
	
	@SuppressWarnings("rawtypes")
	public String[] getUserNamesPersonalIdentifierAndEmailByUID(final String userAttribute, final PumaHome pumaHome) {
		Logger.log(Logger.DEBUG_LEVEL, "getUserNamesPersonalIdentifierAndEmailByUID(" + userAttribute + ")");
		List<User> users = getUsersByAttribute(pumaHome, userAttribute, MySpaceConstants.LDAP_ATTRIBUTE_UID);
		if (users != null && users.size() > 0) {
			Logger.log(Logger.DEBUG_LEVEL, "getUserNamesPersonalIdentifierAndEmailByUID(" + userAttribute + ") -> users.size() = " + users.size());
			if (users.size() > 1) {
				Logger.log(Logger.DEBUG_LEVEL, "getUserNamesPersonalIdentifierAndEmailByUID() -> " + "Warning: Using non-unique attribute for User. Attribute Name=" + MySpaceConstants.LDAP_ATTRIBUTE_UID + " Value =" + userAttribute);
			} else {
				Object attribute = getUserAttribute(pumaHome, (User) users.get(0), MySpaceConstants.LDAP_ATTRIBUTE_COMMON_NAME);
				String userCN = "";
				String userPersonalIdentifier = "";
				String userEmail = "";
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							userCN += " ";
						}
						userCN += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					userCN = (String)attribute;
				}
				attribute = getUserAttribute(pumaHome, (User) users.get(0), MySpaceConstants.LDAP_ATTRIBUTE_EGOV_IDENTIFIER);
				//attribute = getUserAttribute(pumaHome, (User) users.get(0), MySpaceConstants.LDAP_ATTRIBUTE_EMPLOYEE_NUMBER);
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							userPersonalIdentifier += " ";
						}
						userPersonalIdentifier += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					userPersonalIdentifier = (String)attribute;
				}
				attribute = getUserAttribute(pumaHome, (User) users.get(0), MySpaceConstants.LDAP_ATTRIBUTE_PORTAL_EMAIL);
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							userEmail += " ";
						}
						userEmail += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					userEmail = (String)attribute;
				}
				return new String[] {userCN, userPersonalIdentifier, userEmail};
			}
		} else {
			Logger.log(Logger.DEBUG_LEVEL, "getUserNamesPersonalIdentifierAndEmailByUID(" + userAttribute + ") -> No User was found!");
		}
		return null;
	}
	
	@SuppressWarnings("rawtypes")
	public String getUserNamesByUID(final String userAttribute, final PumaHome pumaHome) {
		Logger.log(Logger.DEBUG_LEVEL, "getUserNamesByUID(" + userAttribute + ")");
		List<User> users = getUsersByAttribute(pumaHome, userAttribute, MySpaceConstants.LDAP_ATTRIBUTE_UID);
		if (users != null && users.size() > 0) {
			Logger.log(Logger.DEBUG_LEVEL, "getUserNamesByUID(" + userAttribute + ") -> users.size() = " + users.size());
			if (users.size() > 1) {
				Logger.log(Logger.DEBUG_LEVEL, "getUserNamesByUID() -> " + "Warning: Using non-unique attribute for User. Attribute Name=" + MySpaceConstants.LDAP_ATTRIBUTE_UID + " Value =" + userAttribute);
			} else {
				Object attribute = getUserAttribute(pumaHome, (User) users.get(0), MySpaceConstants.LDAP_ATTRIBUTE_COMMON_NAME);
				String userCN = "";
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							userCN += " ";
						}
						userCN += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					userCN = (String)attribute;
				}		
				return userCN;
			}
		} else {
			Logger.log(Logger.DEBUG_LEVEL, "getUserNamesByUID(" + userAttribute + ") -> No User was found!");
		}
		return null;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private List<User> getUsersByAttribute(final PumaHome pumaHome, final String userAttributeValue, final String searchAttribute) {
		Logger.log(Logger.DEBUG_LEVEL, "getUsersByAttribute(" + userAttributeValue + "," + searchAttribute + ")");
		List<User> users = null;
		try {
			final PumaEnvironment env = pumaHome.getEnvironment();
			final PumaLocator locatorService = pumaHome.getLocator();
			users = (List<User>) env.runUnrestricted(new PrivilegedExceptionAction() {
				public Object run() throws Exception {
					return locatorService.findUsersByAttribute(searchAttribute, userAttributeValue);
				}
			});
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "getUsersByAttribute(" + userAttributeValue + "," + searchAttribute + ") -> Exception: " + e.getMessage());
			e.printStackTrace();
		}		
		return users;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Object getUserAttribute(final PumaHome pumaHome, final User user, String attributeName) {
		Logger.log(Logger.DEBUG_LEVEL, "getUserAttribute(com.ibm.portal.um.User, " + attributeName + ")");
		final java.util.List<String> attributesNamesList;
		try {
			final PumaEnvironment env = pumaHome.getEnvironment();
			final PumaProfile pumaProfile = pumaHome.getProfile();
			attributesNamesList = pumaProfile.getDefinedUserAttributeNames();
			Logger.log(Logger.DEBUG_LEVEL, "getUserAttribute(com.ibm.portal.um.User," + attributeName + ") -> attributesNamesList = " +  + (attributesNamesList != null ? attributesNamesList.size() : 0));
//			if (attributesNamesList != null && attributesNamesList.size() > 0) {
//				for (int i = 0; i < attributesNamesList.size(); i++) {
//					Logger.log(Logger.DEBUG_LEVEL, "getUserAttribute(com.ibm.portal.um.User," + attributeName + ") -> attributesNamesList[" + i + "] = " + attributesNamesList.get(i));
//				}
//			}
			java.util.Map<String, Object> userInfo = (java.util.Map<String, Object>) env.runUnrestricted(new PrivilegedExceptionAction() {
				public Object run() throws Exception {
					return pumaProfile.getAttributes((com.ibm.portal.um.Principal) user, attributesNamesList);
				}
			});
			if (userInfo != null) {
				Logger.log(Logger.DEBUG_LEVEL, "getUserAttribute(com.ibm.portal.um.User, " + attributeName + ") -> userInfo.size() = " + userInfo.size());
				return userInfo.get(attributeName);
			}
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "getUserAttribute(com.ibm.portal.um.User, " + attributeName + ") -> Exception: " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void removeAttribute(User user, String attributeName) {	
		Logger.log(Logger.DEBUG_LEVEL, "removeAttribute(com.ibm.portal.um.User, " + attributeName + ") -> started...");
		try {
			final PumaEnvironment pumaEnvironment = MySpacePortlet.getPumaHome().getEnvironment();
			final PumaController controller = MySpacePortlet.getPumaController();
			pumaEnvironment.runUnrestricted(new PrivilegedExceptionAction() {
				public Object run() {
					Map<String, String> userInputMap = new HashMap<String, String>();
					userInputMap.put(attributeName, null);
					try {
						controller.setAttributes(user, userInputMap);
					} catch (Exception e) {
						e.printStackTrace();
					}
					return null;
				}
			});
        } catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();                    
        }
	}
}