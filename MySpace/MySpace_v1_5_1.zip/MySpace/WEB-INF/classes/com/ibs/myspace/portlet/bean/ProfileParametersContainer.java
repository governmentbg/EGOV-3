package com.ibs.myspace.portlet.bean;

import java.util.HashMap;
import java.util.Map;

import com.ibs.myspace.portlet.dbo.UserProfileParameters;

public class ProfileParametersContainer {
	
	private UserProfileParameters[] userProfileParameters = null;
	private Map<Long, UserProfileParameters> parametersByParameterIdHm = null;
	private String currentRegisterGroupName = null;
	private boolean initInitalized = false;

	public UserProfileParameters[] getUserProfileParameters() {
		return userProfileParameters;
	}

	public void setUserProfileParameters(UserProfileParameters[] userProfileParameters) {
		this.userProfileParameters = userProfileParameters;
	}

	public Map<Long, UserProfileParameters> getParametersByParameterIdHm() {
		return parametersByParameterIdHm != null ? parametersByParameterIdHm : new HashMap<Long, UserProfileParameters>();
	}

	public void setParametersByParameterIdHm(Map<Long, UserProfileParameters> parametersByParameterIdHm) {
		this.parametersByParameterIdHm = parametersByParameterIdHm;
	}

	public String getCurrentRegisterGroupName() {
		return currentRegisterGroupName;
	}

	public void setCurrentRegisterGroupName(String currentRegisterGroupName) {
		this.currentRegisterGroupName = currentRegisterGroupName;
	}
	
	public boolean isInitInitalized() {
		return initInitalized;
	}

	public void setInitInitalized(boolean initInitalized) {
		this.initInitalized = initInitalized;
	}
	
}

