package com.ibs.myspace.portlet.dbo;

import java.util.Hashtable;

import com.ibs.myspace.portlet.db.DBTransaction;
import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.db.PersistentObject;
import com.ibs.myspace.portlet.db.QueryComposer;
import com.ibs.myspace.portlet.db.QuerySet;


public class UserProfileRef extends PersistentObject {

	private static String CLASS_NAME = UserProfileRef.class.getName();
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "USERPROFILEREF";
        sequenceName = "SEQ_USERPROFILEREF";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "USERPROFILEREFID");
        columnMap.put("userProfileId", "USERPROFILEID");
        columnMap.put("reik", "REIK");
        columnMap.put("eik", "EIK");
        columnMap.put("parentUserProfileId", "PARENTUSERPROFILEID");
        columnMap.put("parentUserProfileIds", "PARENTUSERPROFILEIDS");

        querySet = QueryComposer.composeAll(table, sequenceName, columnMap);
    }
	
    public UserProfileRef() {
        super(querySet);
    }
    
    private String userProfileId = null;
    private String reik = null;
    private String eik = null;
    private String parentUserProfileId = null;
    private String parentUserProfileIds = null;    
	
	
	public String getUserProfileId() {
		return userProfileId;
	}

	public void setUserProfileId(String userProfileId) {
		this.userProfileId = userProfileId;
	}

	public String getReik() {
		return reik;
	}

	public void setReik(String reik) {
		this.reik = reik;
	}

	public String getEik() {
		return eik;
	}

	public void setEik(String eik) {
		this.eik = eik;
	}

	public String getParentUserProfileId() {
		return parentUserProfileId;
	}

	public void setParentUserProfileId(String parentUserProfileId) {
		this.parentUserProfileId = parentUserProfileId;
	}

	public String getParentUserProfileIds() {
		return parentUserProfileIds;
	}

	public void setParentUserProfileIds(String parentUserProfileIds) {
		this.parentUserProfileIds = parentUserProfileIds;
	}

	public static UserProfileRef findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileRef) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}
	
	public static UserProfileRef findByUserProfileId(final String userProfileId, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileRef) findSingle(columnMap.get("userProfileId") + "='" + userProfileId + "'", CLASS_NAME, transaction);
	}
	
	public static UserProfileRef findByREIK(final String reik, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileRef) findSingle(columnMap.get("reik") + "='" + reik + "'", CLASS_NAME, transaction);
	}
	
	public static UserProfileRef[] findAllByEIK(final String eik, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileRefs(columnMap.get("eik") + "='" + eik + "'", transaction);
	}
	
	public static UserProfileRef[] findAllByParentUserProfileIdsIn(final String userProfileId, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileRefs(columnMap.get("parentUserProfileIds") + " IN (" + userProfileId + ")", transaction);
	}
	
	public static UserProfileRef[] findAllByParentUserProfileId(final String userProfileId, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileRefs(columnMap.get("parentUserProfileId") + " = " + userProfileId, transaction);
	}
	
	public static void removeByUserProfileId(String userProfileId, DBTransaction transaction) throws FinderException, Exception {
		UserProfileRef userProfileRef = new UserProfileRef();
		String cond = columnMap.get("userProfileId") + "='" + userProfileId + "'";
		userProfileRef.removeConditional(cond, transaction);			
	}

	public static UserProfileRef[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileRefs("1=1", transaction);
	}

	public static UserProfileRef[] findAllUserProfileRefs(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final UserProfileRef[] userProfileRefs = new UserProfileRef[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				userProfileRefs[i] = (UserProfileRef) tmp[i];
			}
			return userProfileRefs;
		} 
		return null;
	}
	
}
