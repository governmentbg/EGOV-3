package com.ibs.myspace.portlet.bean;

import java.util.List;

public class ActualStateResponseV3 {
	List<ActualStateResponseV3Manager> managers = null;

	public List<ActualStateResponseV3Manager> getManagers() {
		return managers;
	}

	public void setManagers(List<ActualStateResponseV3Manager> managers) {
		this.managers = managers;
	}		
	
	@Override
	public String toString() {
		return "ActualStateResponseV3 [managers.size()=" + (managers != null ? managers.size() : 0) + "]";
	}
	
}
