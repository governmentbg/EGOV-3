package com.ibs.myspace.portlet.dbo;

import java.util.Hashtable;

import com.ibs.myspace.portlet.db.DBTransaction;
import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.db.PersistentObject;
import com.ibs.myspace.portlet.db.QueryComposer;
import com.ibs.myspace.portlet.db.QuerySet;


public class UserProfileSystemParameters extends PersistentObject {

	private static String CLASS_NAME = UserProfileSystemParameters.class.getName();
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "USERPROFILESYSTEMPARAMETERS";
        sequenceName = "SEQ_USERPROFILESYSTEMPARAMETERS";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "USERPROFILESYSTEMPARAMETERSID");
        columnMap.put("userProfileId", "USERPROFILEID");
        columnMap.put("servicesCount", "SERVICESCOUNT");
        columnMap.put("serviceId", "SERVICEID");
        columnMap.put("serviceName", "SERVICENAME");
        columnMap.put("notificationId", "NOTIFICATIONID");
        columnMap.put("notificationName", "NOTIFICATIONNAME");
        columnMap.put("requiredDataForChannel", "REQUIREDDATAFORCHANNEL");
        querySet = QueryComposer.composeAll(table, sequenceName, columnMap);
    }
	
    public UserProfileSystemParameters() {
        super(querySet);
    }
    
    private String userProfileId = null;
    private String servicesCount = null;
    private String serviceId = null;
    private String serviceName = null;
    private String notificationId = null;
    private String notificationName = null;
    private String requiredDataForChannel = null;
	
	public String getUserProfileId() {
		return userProfileId;
	}

	public void setUserProfileId(String userProfileId) {
		this.userProfileId = userProfileId;
	}

	public String getServicesCount() {
		return servicesCount;
	}

	public void setServicesCount(String servicesCount) {
		this.servicesCount = servicesCount;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}

	public String getNotificationName() {
		return notificationName;
	}

	public void setNotificationName(String notificationName) {
		this.notificationName = notificationName;
	}

	public String getRequiredDataForChannel() {
		return requiredDataForChannel;
	}

	public void setRequiredDataForChannel(String requiredDataForChannel) {
		this.requiredDataForChannel = requiredDataForChannel;
	}

	public static UserProfileSystemParameters findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileSystemParameters) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}
	
	public static UserProfileSystemParameters findByUserProfileId(final String userProfileId, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileSystemParameters) findSingle(columnMap.get("userProfileId") + "='" + userProfileId + "'", CLASS_NAME, transaction);
	}
	
	public static UserProfileSystemParameters[] findAllByUserProfileId(final String userProfileId, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileSystemParameters(columnMap.get("userProfileId") + "='" + userProfileId + "'", transaction);
	}
				
	public static void removeAllByUserProfileId(String userProfileId, DBTransaction transaction) throws FinderException, Exception {
		UserProfileSystemParameters userProfileSystemParameters = new UserProfileSystemParameters();
		String cond = columnMap.get("userProfileId") + "='" + userProfileId + "'";
		userProfileSystemParameters.removeConditional(cond, transaction);			
	}
	
	public static UserProfileSystemParameters[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileSystemParameters("1=1", transaction);
	}

	public static UserProfileSystemParameters[] findAllUserProfileSystemParameters(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final UserProfileSystemParameters[] userProfileSystemParameters = new UserProfileSystemParameters[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				userProfileSystemParameters[i] = (UserProfileSystemParameters) tmp[i];
			}
			return userProfileSystemParameters;
		} 
		return null;
	}
	
}
