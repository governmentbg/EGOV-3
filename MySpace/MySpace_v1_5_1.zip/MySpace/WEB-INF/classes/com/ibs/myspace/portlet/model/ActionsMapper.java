package com.ibs.myspace.portlet.model;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ActionsMapper {
	public Actions getAction(ResultSet resultSet) throws SQLException {
		Actions action = new Actions();
		action.setActionsId(resultSet.getLong("actionsId"));
		action.setSystemsId(resultSet.getLong("systemsId"));
		action.setCode(resultSet.getString("code"));
		action.setDescription(resultSet.getString("description"));
		action.setOperationTime(resultSet.getTimestamp("operationTime"));
		action.setUserId(resultSet.getString("userId"));
		return action;
	}
}
