package com.ibs.myspace.portlet.utils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.StringWriter;
import java.math.BigInteger;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;
import java.util.UUID;
import java.util.regex.Pattern;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequest;
import javax.portlet.PortletResponse;
import javax.portlet.RenderRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.egov.wcm.cache.model.EgovRegisterGroup;
import com.ibm.portal.portlet.service.PortletServiceHome;
import com.ibm.portal.state.Constants.Clone;
import com.ibm.portal.state.EngineURL;
import com.ibm.portal.state.PortletStateManager;
import com.ibm.portal.state.URLFactory;
import com.ibm.portal.state.accessors.portlet.PortletAccessorController;
import com.ibm.portal.state.accessors.portlet.PortletAccessorFactory;
import com.ibm.portal.state.accessors.selection.SelectionAccessorController;
import com.ibm.portal.state.accessors.selection.SelectionAccessorFactory;
import com.ibm.portal.state.service.PortletStateManagerService;
import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.MySpacePortlet;
import com.ibs.myspace.portlet.MySpacePortletSessionBean;
import com.ibs.myspace.portlet.bean.AuthorizationBean;
import com.ibs.myspace.portlet.bean.ProfileIdentifierBean;
import com.ibs.myspace.portlet.bean.SelectedActionBean;
import com.ibs.myspace.portlet.bean.SelectedSystemBean;
import com.ibs.myspace.portlet.bean.UserProfileBean;
import com.ibs.myspace.portlet.bean.esb.ESBMDTBean;
import com.ibs.myspace.portlet.db.Base;
import com.ibs.myspace.portlet.dbo.HorizontalSystemRole;
import com.ibs.myspace.portlet.dbo.UserProfile;
import com.ibs.myspace.portlet.dbo.UserProfileIdentifier;
import com.ibs.myspace.portlet.dbo.UserProfileRole;
import com.ibs.myspace.portlet.dbo.UserProfileXCRole;
import com.ibs.myspace.portlet.interfaces.DateValidator;
import com.ibs.myspace.portlet.management.AuthorizationsManagement;
import com.ibs.myspace.portlet.management.UserProfileManagement;
import com.ibs.myspace.portlet.model.Actions;
import com.ibs.myspace.portlet.model.Authorizations;
import com.ibs.myspace.portlet.model.Systems;

public class MySpaceUtils {

	private final static SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH);
	private final static SimpleDateFormat dateTimeFormat_bg = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.ENGLISH);
	private final static SimpleDateFormat dateFormat_bg = new SimpleDateFormat("dd.MM.yyyy", Locale.ENGLISH);
	private final static SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss", Locale.ENGLISH);
	//private final static DateTimeFormatter dateFormatter_bg = DateTimeFormatter.ofPattern("dd.MM.yyyy");
	// 2021-01-08T16:02:20.777+02:00
	private final static DateTimeFormatter DATE_TIME_DD_MM_UUUU_HH_MM = DateTimeFormatter.ofPattern("dd.MM.uuuu HH:mm");
    
    public static void loadPreferences(RenderRequest request) {
		PortletPreferences portletPreferences = request.getPreferences(); 
		
		if (portletPreferences != null) {	
			MySpacePortlet.mailSmtpHost = portletPreferences.getValue(MySpacePortlet.SETTING_PARAMETER_MAIL_SMTP_HOST, "mail");
			MySpacePortlet.fromAddress = portletPreferences.getValue(MySpacePortlet.SETTING_PARAMETER_FROM_ADDRESS, "");
			MySpacePortlet.toAddress = portletPreferences.getValue(MySpacePortlet.SETTING_PARAMETER_TO_ADDRESS, "");
			MySpacePortlet.ePaymentURL = portletPreferences.getValue(MySpacePortlet.SETTING_PARAMETER_E_PAYMENT_URL, MySpaceConstants.E_PAYMENT_URL);
			MySpacePortlet.regixURL = portletPreferences.getValue(MySpacePortlet.SETTING_PARAMETER_REGIX_URL, MySpaceConstants.REGIX_PROD_URL);
			MySpacePortlet.ahuURL = portletPreferences.getValue(MySpacePortlet.SETTING_PARAMETER_AHU_URL, MySpaceConstants.AHU_URL); 
			MySpacePortlet.seacrhScopeId = portletPreferences.getValue(MySpacePortlet.SETTING_PARAMETER_SEARCH_SCOPE_ID, MySpaceConstants.SEARCH_SCOPE_EGOV_ID);
			MySpacePortlet.esbEventLogAddress = portletPreferences.getValue(MySpacePortlet.SETTING_PARAMETER_ESB_EVENT_LOGGER_ADDRESS, "");
			MySpacePortlet.esbRegixAddress = portletPreferences.getValue(MySpacePortlet.SETTING_PARAMETER_ESB_REGIX_ADDRESS, "");
			MySpacePortlet.esbEDeliveryAddress = portletPreferences.getValue(MySpacePortlet.SETTING_PARAMETER_ESB_EDELIVERY_ADDRESS, "");
			MySpacePortlet.ornAddress = portletPreferences.getValue(MySpacePortlet.SETTING_PARAMETER_ORN_ADDRESS, Base.TEST_ENVIRONMENT ? MySpaceConstants.ORN_TEST_URL : MySpaceConstants.ORN_PROD_URL);
			MySpacePortlet.communicationEFormsVersion = portletPreferences.getValue(MySpacePortlet.SETTING_PARAMETER_COMMUNICATION_E_FORMS_VERSION, MySpaceConstants.COMMUNICATION_HS_VERSION_1);
			MySpacePortlet.communicationEPaymentVersion = portletPreferences.getValue(MySpacePortlet.SETTING_PARAMETER_COMMUNICATION_E_PAYMENT_VERSION, MySpaceConstants.COMMUNICATION_HS_VERSION_1);
			MySpacePortlet.communicationEDeliveryVersion = portletPreferences.getValue(MySpacePortlet.SETTING_PARAMETER_COMMUNICATION_E_DELIVERY_VERSION, MySpaceConstants.COMMUNICATION_HS_VERSION_1);
			MySpacePortlet.ghostThreadExecution = "true".equals(portletPreferences.getValue(MySpacePortlet.SETTING_PARAMETER_GHOST_THREAD_EXECUTION, "false"));
			MySpacePortlet.logEvents = "true".equals(portletPreferences.getValue(MySpacePortlet.SETTING_PARAMETER_LOG_EVENTS, "false"));
			MySpacePortlet.language = portletPreferences.getValue(MySpacePortlet.SETTING_PARAMETER_LANGUAGE, MySpaceConstants.LANGUAGE_BG);				
			MySpacePortlet.debug = "true".equals(portletPreferences.getValue(MySpacePortlet.SETTING_PARAMETER_DEBUG, "false"));	
			MySpacePortlet.sendEmail = "1".equals(portletPreferences.getValue(MySpacePortlet.SETTING_PARAMETER_SEND_EMAIL, "true"));	
			MySpacePortlet.preferencesLoaded = true;
			return;
		}
		MySpacePortlet.preferencesLoaded = false;
	}
    
	public static long date_TimestampToTimeMillis(final String s) {
		if (s != null) {
			try {
				return dateTimeFormat.parse(s).getTime();
			} catch (final Exception e) {
				System.out.println("date_TimestampToTimeMillis = " + e.getMessage());
			}
		}
		return 0;
	}
	
	public static String timeMillisToTimestamp(final long millis) {
		try {

			return dateTimeFormat.format(new Date(millis));
		} catch (final Exception e) {
			System.out.println("Utils : timeMillisToTimestamp : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static String timeMillisToYYYY_MM_DD_HH_MM_SS(final String timeMillis) {
		try {
			final Date date = new Date(Long.parseLong(timeMillis));
			return dateTimeFormat.format(date);
		} catch (Exception e) {
			System.out.println("Utils : timeMillisToYYYY_MM_DD_HH_MM_SS : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static String timeMillisToYYYY_MM_DD_HH_MM_SS(final long timeMillis) {
		try {
			final Date date = new Date(timeMillis);
			return dateTimeFormat.format(date);
		} catch (Exception e) {
			System.out.println("Utils : timeMillisToYYYY_MM_DD_HH_MM_SS : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}
	
	public static String timeMillisToDD_MM_YYYY_HH_MM_SS(final long timeMillis) {
		try {
			final Date date = new Date(timeMillis);
			return dateTimeFormat_bg.format(date);
		} catch (Exception e) {
			System.out.println("Utils : timeMillisToDD_MM_YYYY_HH_MM_SS : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}
	
	public static String timeMillisToDD_MM_YYYY(final long timeMillis) {
		try {
			final Date date = new Date(timeMillis);
			return dateFormat_bg.format(date);
		} catch (Exception e) {
			System.out.println("Utils : timeMillisToDD_MM_YYYY : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}
	
	public static String timeMillisToHH_mm_ss(final long timeMillis) {
		try {
			final Date date = new Date(timeMillis);
			return timeFormat.format(date);
		} catch (Exception e) {
			System.out.println("Utils : timeMillisToHH_mm_ss : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}
	
	public String dateToDD_MM_YYYY_HH_MM_SS(final Date date) {
		try {
			return dateTimeFormat_bg.format(date);
		} catch (Exception e) {
			System.out.println("Utils : dateToDD_MM_YYYY_HH_MM_SS : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}
	
	public static String getDashboardPageByProfileType(String profileType) {
		if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(profileType)) {
			return MySpacePortlet.INDEX_PAGE;
		} else if (MySpaceConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER.equals(profileType)) {
			return MySpacePortlet.DASHBOARD_SERVICE_SUPPLIER_PAGE;
		} else if (MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY.equals(profileType)
				|| MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY_AL2.equals(profileType)) {
			return MySpacePortlet.DASHBOARD_LEGAL_ENTITY_PAGE;
		} 
		return MySpacePortlet.INDEX_PAGE;		
	}
	
	// Generate a UUID compliant with RFC 4122.
	public String generateRNU() {
		return UUID.randomUUID().toString();
	}
	
	public Integer[] getArrayFromFormatedField(String str) {
		if (str != null && str.trim().length() > 0) {
			if (str.indexOf("^^") != -1) {
				String[] profileTypeIds = str.split("\\^\\^");
				Integer[] profileTypes = new Integer[profileTypeIds.length];
				for (int i = 0; i < profileTypeIds.length; i++) {
					profileTypes[i] = Integer.parseInt(profileTypeIds[i].replaceAll("\\^", ""));
				}
				return profileTypes;
			} else {
				return new Integer[] {Integer.parseInt(str.replaceAll("\\^", ""))};
			}
		}
		return null;
	}
	
	public String[] getSystemsArrayFromFormatedField(String str) {
		if (str != null && str.trim().length() > 0) {
			if (str.indexOf("^^") != -1) {
				String[] systemsAndActionsStr = str.split("\\^\\^");
				String[] systemsAndActions = new String[systemsAndActionsStr.length];
				for (int i = 0; i < systemsAndActionsStr.length; i++) {
					systemsAndActions[i] = systemsAndActionsStr[i].replaceAll("\\^", "");
				}
				return systemsAndActions;
			} else {
				return new String[] {str.replaceAll("\\^", "")};
			}
		}
		return null;
	}
	
	public String getSystemsStringFromLoadedBean(List<SelectedSystemBean> systems) {
		StringBuffer str = new StringBuffer();
		if (systems != null && systems.size() > 0) {
			SelectedSystemBean system = null;
			List<SelectedActionBean> actions = null;
			for (int i = 0; i < systems.size(); i++) {
				system = systems.get(i);
				actions = system.getActions();
				for (int j = 0; j < actions.size(); j++) {
					str.append("^" + system.getSystemsId() + ":" + actions.get(j).getActionsId() + "^");
				}
			}			
		}
		return str.toString();
	}

	public boolean checkProfileHasGroupProfileStructureType(UserProfile profile, EgovRegisterGroup group) {
		Logger.log(Logger.DEBUG_LEVEL, "MySpaceUtils -> checkProfileHasGroupProfileStructureType()...");		 		
		if (group == null || group.getProfileStructureType() == null || group.getProfileStructureType().trim().length() == 0) {
			Logger.log(Logger.DEBUG_LEVEL, "MySpaceUtils -> checkProfileHasGroupProfileStructureType()... return true");
			return true;
		} 
		Logger.log(Logger.DEBUG_LEVEL, "MySpaceUtils -> checkProfileHasGroupProfileStructureType() [" + group.getLabel() + "-group.getProfileStructureType()] =>" + group.getProfileStructureType() + "<");
		Integer[] profileStructureTypes = getArrayFromFormatedField(profile.getProfileStructureType());
		
		// If profile is type PERSONAL, skip profileStructureType validation.
		if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(profile.getProfileType())) return true;
		
		// If current profile is not associated with any profile structure type, skip the group.
		if (profileStructureTypes != null && profileStructureTypes.length > 0) {
			Logger.log(Logger.DEBUG_LEVEL, "MySpaceUtils -> checkProfileHasGroupProfileStructureType()... profileStructureTypes.length=" + profileStructureTypes.length);
			Integer[] groupProfileStructureTypes = getArrayFromFormatedField(group.getProfileStructureType());
			if (groupProfileStructureTypes != null && groupProfileStructureTypes.length > 0) {
				for (int i = 0; i < groupProfileStructureTypes.length; i++) {
					// Check group's profile structure type(s) match one of the profile structure types.
					for (int j = 0; j < profileStructureTypes.length; j++) {
						if (groupProfileStructureTypes[i] == profileStructureTypes[j]) {
							return true;
						}
					}
				}
			}
		}
		Logger.log(Logger.DEBUG_LEVEL, "MySpaceUtils -> checkProfileHasGroupProfileStructureType()... return true, exit");
		return false;
	}
	
	public boolean authorizationIsActive(Authorizations authorization) {
		if (authorization != null) {
			if (MySpaceConstants.AUTHORIZATIONS_STATUS_ACTIVE == authorization.getStatus()) {
				Date today = new Date();
				if (today.compareTo(authorization.getValidFrom()) < 0) { // not active yet.
					return false; 
				} else if (today.compareTo(authorization.getValidTo()) > 0) { // expired.
					return false;
				} 
				return true;
			} 
		}
		return false;
	}
	
	public boolean authorizationIsExpired(Authorizations authorization) {
		if (authorization != null) {
			if (MySpaceConstants.AUTHORIZATIONS_STATUS_ACTIVE == authorization.getStatus()) {
				Date today = new Date();
				// expired.
				return today.compareTo(authorization.getValidTo()) > 0; 
			} 
		}
		return false;
	}
	
	public boolean authorizationIsCanceled(Authorizations authorization) {
		if (authorization != null) {
			return MySpaceConstants.AUTHORIZATIONS_STATUS_CANCELED == authorization.getStatus();
		}
		return false;
	}
	
	public boolean authorizationIsBlocked(Authorizations authorization) {
		if (authorization != null) {
			return MySpaceConstants.AUTHORIZATIONS_STATUS_BLOCKED == authorization.getStatus();
		}
		return false;
	}
	
	public boolean authorizationIsInactive(Authorizations authorization) {
		if (authorization != null) {
			if (MySpaceConstants.AUTHORIZATIONS_STATUS_ACTIVE == authorization.getStatus()) {
				Date today = new Date();
				// not active yet.
				return today.compareTo(authorization.getValidFrom()) < 0; 
			} 
		}
		return false;
	}
	
	public boolean checkPageCanShowProfileParameters(String pageName) {
		return !(MySpacePortlet.PROFILE_SELECTOR_PAGE.equals(pageName)					
				|| MySpacePortlet.PROFILE_REGISTRATION_PAGE.equals(pageName)
				|| MySpacePortlet.LEGAL_ENTITY_REQUEST_PROFILE_PAGE.equals(pageName)
				|| MySpacePortlet.LEGAL_ENTITY_REQUEST_PROFILE_REIK_PAGE.equals(pageName)
				|| MySpacePortlet.DEACTIVATE_PROFILE_PAGE.equals(pageName));
	}
	
	public long randomLong() {
		Random random = new Random();
		return Math.abs(random.nextLong());
	}
	
	public String getAuthorizationStatusName(Authorizations authorization) {
		if (MySpaceConstants.AUTHORIZATIONS_STATUS_ACTIVE == authorization.getStatus()) {
			Date today = new Date();
			if (today.compareTo(authorization.getValidFrom()) < 0) { // not active yet.
				return "Неактивно"; 
            } else if (today.compareTo(authorization.getValidTo()) > 0) { // expired.
            	return "Изтекло";
            } 
			return "Активно";
		} else if (MySpaceConstants.AUTHORIZATIONS_STATUS_BLOCKED == authorization.getStatus()) {
			return "Блокирано";
		} else if (MySpaceConstants.AUTHORIZATIONS_STATUS_CANCELED == authorization.getStatus()) {
			return "Оттеглено";
		}
		return "";
	}
	
	public String formatDate(String date) {
		DateTimeFormatter customFormatter = DateTimeFormatter.ofPattern(MySpaceConstants.AUTHORIZATION_DATE_FORMAT);
		LocalDate formatedDate = LocalDate.parse(date, customFormatter);
		return formatedDate.toString();
	}
	
	public ZonedDateTime getZonedDateTimeFromTimestamp(String timeStamp) {
		return ZonedDateTime.parse(timeStamp);
	}
	
	public String getFormatedZoneDateTimeWithOffset(String timeStamp) {
		ZonedDateTime zdtGiven = ZonedDateTime.parse(timeStamp);
		
		// Date-time adjusted with Zone-Offset (i.e. date-time at UTC)
		ZonedDateTime zdtAtUTC = zdtGiven.withZoneSameInstant(ZoneId.of("Etc/UTC"));
		return zdtAtUTC.format(DATE_TIME_DD_MM_UUUU_HH_MM);
	}
	
	public String getFormatedZoneDateTime(String timeStamp) {
		// If passed, remove the dateTimeOffset suffix ex. [2022-06-24T01:06:45.813+03:00]
		if (timeStamp != null && timeStamp.indexOf("+") != -1) {
			timeStamp = timeStamp.substring(0, timeStamp.indexOf("+"));
		}
		if (timeStamp != null && timeStamp.indexOf("-") != -1) {
			return this.getFormatedDateTimeWithMillis(timeStamp);
		}
		ZonedDateTime zdtGiven = ZonedDateTime.parse(timeStamp);
		return zdtGiven.format(DATE_TIME_DD_MM_UUUU_HH_MM);
	}
	
	public String getFormatedDateTimeWithMillis(String timeStamp) {
		int pos = timeStamp.lastIndexOf(".");
		String s = "";
		if (pos != -1) {
			int length = timeStamp.substring(pos + 1).length();
			for (int i = 0; i < length; i++) {
				s += "S";
			}
		}
		DateTimeFormatter formatter = null;
		if (pos != -1) {
			formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss." + s);
		} else {
			formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss");
		}
		LocalDateTime ldt1 = LocalDateTime.parse(timeStamp, formatter);
		DateTimeFormatter shortFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm");		
		return shortFormatter.format(ldt1);
	}
	
	public boolean isValidDate(String dateString, String format) {
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern(format, Locale.US).withResolverStyle(ResolverStyle.STRICT);
		DateValidator validator = new DateValidatorUsingDateTimeFormatter(dateFormatter);
		return validator.isValid(dateString);
	}
		
	public boolean isValidTime(String time) {
		if (time == null || time.trim().length() == 0) {
			return false;
		}
		String regex = "([01]?[0-9]|2[0-3]):[0-5][0-9]";
		return time.matches(regex);
	}
	
	public boolean compareDates(String firstDateString, String secondDateString, String firstTimeString, String secondTimeString, String format) {
		DateTimeFormatter customFormatter = DateTimeFormatter.ofPattern(format);
		LocalDate firstDate= LocalDate.parse(firstDateString, customFormatter);
		LocalDate secondDate= LocalDate.parse(secondDateString, customFormatter);
		if (!firstDateString.equalsIgnoreCase(secondDateString)) {
			return secondDate.isAfter(firstDate);
		} else {
			// Compare times.
			if (firstTimeString != null && secondTimeString != null) {
				String[] firstTimeArr = firstTimeString.split(":");
				String[] secondTimeArr = secondTimeString.split(":");
				if (firstTimeArr != null && firstTimeArr.length == 2
						&& secondTimeArr != null && secondTimeArr.length == 2) {
					try {
						int firstHour = Integer.parseInt(firstTimeArr[0]);
						int secondHour = Integer.parseInt(secondTimeArr[0]);
						if (firstHour == secondHour) {							
							int firstMinutes = Integer.parseInt(firstTimeArr[1]);
							int secondMinutes = Integer.parseInt(secondTimeArr[1]);
							return firstMinutes <= secondMinutes;
						}
					} catch (NumberFormatException e) {
						e.printStackTrace();
					}
				}
			}
		}		
		return true;
	}
	
	public UserProfile getPersonalProfile(UserProfile[] profiles) {
		if (profiles != null && profiles.length > 0) {
			for (int i = 0; i < profiles.length; i++) {
				if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(profiles[i].getProfileType())) {
					return profiles[i];
				}
			}
		}
		return null;
	}
	
	public Integer getIntegerParameterValue(String value) {
		if (value == null) return null;
		try {
			return Integer.parseInt(value);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public String getCurrentTime() {
		LocalDateTime dateTime = LocalDateTime.now();
		return dateTime.format(DateTimeFormatter.ofPattern(MySpaceConstants.AUTHORIZATION_DATE_TIME_FORMAT));
	}
	
	public AuthorizationBean populateAuthorizationBeanFromDB(Authorizations authorization) {
		AuthorizationBean bean = new AuthorizationBean();
		bean.setAuthorizedType(authorization.getAuthorizedType());
		bean.setAuthorizedIdentifierType(authorization.getAuthorizedIdentifierType());		
		bean.setAuthorizedIdentifier(authorization.getAuthorizedIdentifier());
		if (MySpaceConstants.AUTHORIZATIONS_AUTHORIZED_TYPE_PERSON == authorization.getAuthorizedType()) {
			bean.setEncryptedAuthorizedIdentifier(authorization.getAuthorizedIdentifier());
			EncryptorAESGCM aesCls = new EncryptorAESGCM();
			bean.setAuthorizedIdentifier(aesCls.decryptEgovIdentifier(authorization.getAuthorizedIdentifier()));
		}
		bean.setAuthorizedNames(authorization.getAuthorizedNames());		
		bean.setLoadedSystemBeans(parseSystemsToBean(authorization.getSystems(), null, null));
		bean.setValidFromDate(dateFormat_bg.format(authorization.getValidFrom()));
		bean.setValidToDate(dateFormat_bg.format(authorization.getValidTo()));
		String validDateTimeFrom = dateTimeFormat_bg.format(authorization.getValidFrom());
		String validDateTimeTo = dateTimeFormat_bg.format(authorization.getValidTo());
		bean.setValidFromTime(validDateTimeFrom.substring(11, 16));
		bean.setValidToTime(validDateTimeTo.substring(11, 16));
		if (MySpaceConstants.AUTHORIZATIONS_STATUS_CANCELED == authorization.getStatus()) {
			bean.setRnu(authorization.getRnuCancel());
		} else {
			bean.setRnu(authorization.getRnu());
		}		
		return bean;
	}
	
	/*
	 * This method loads systems and actions from "Systems" field of the authorization.	 
	 * 
	 */
	public List<SelectedSystemBean> parseSystemsToBean(final String systemsStr, List<Systems> selectedSystems, List<Actions> selectedActions) {
		String[] actionsPerSystem = this.getSystemsArrayFromFormatedField(systemsStr);
		if (actionsPerSystem != null && actionsPerSystem.length > 0) {
			List<Long> systems = new ArrayList<>();
			List<Long> actions = new ArrayList<>();
			Map<Long, List<SelectedActionBean>> systemsHm = new HashMap<>();
			String[] pair = null;
			Long systemsId = null;
			Long actionsId = null;
			List<SelectedActionBean> selectedActionsBean = null;
			SelectedActionBean actionBean = null;
			for (int i = 0; i < actionsPerSystem.length; i++) {
				pair = actionsPerSystem[i].split(":");
				systemsId = Long.parseLong(pair[0]);
				actionsId = Long.parseLong(pair[1]);
				if (!systems.contains(systemsId)) {
					systems.add(systemsId);
				}
				if (!actions.contains(actionsId)) {
					actions.add(actionsId);
				}
				selectedActionsBean = systemsHm.get(systemsId);
				if (selectedActionsBean == null) {
					selectedActionsBean = new ArrayList<SelectedActionBean>();
				}
				actionBean = new SelectedActionBean();
				actionBean.setActionsId(actionsId);
				selectedActionsBean.add(actionBean);
				systemsHm.put(systemsId, selectedActionsBean);
			}
			if (systems == null || systems.size() == 0 || actions == null || actions.size() == 0) {
				return null;
			}
			AuthorizationsManagement management = new AuthorizationsManagement();
			if (selectedSystems == null) {
				// Load all systems and actions by ids.			
				selectedSystems = management.getAllSystemsByIds(systems);
				selectedActions = management.getAllActionsByIds(actions);
			}
			if (selectedSystems == null || selectedActions == null) {
				Logger.log(Logger.ERROR_LEVEL, "No systems or actions found for current authorization.");
				return null;
			}
			
			List<SelectedSystemBean> loadedSystemBeans = new ArrayList<>();
			SelectedSystemBean loadedSystemBean = null;
			SelectedActionBean loadedActionBean = null;
			List<SelectedActionBean> loadedActionsBean = null;
			Systems tmpSystem = null;
			for (int i = 0; i < systems.size(); i++) {
				tmpSystem = null;
				for (int j = 0; j < selectedSystems.size(); j++) {
					if (systems.get(i) == selectedSystems.get(j).getSystemsId()) {
						tmpSystem = selectedSystems.get(j);
						break;
					}
				}
				if (tmpSystem == null) {
					continue;
				}
				systemsId = tmpSystem.getSystemsId();
				selectedActionsBean = systemsHm.get(systemsId);
				if (selectedActionsBean != null) {
					loadedSystemBean = new SelectedSystemBean();
					loadedSystemBean.setSystemsId(systemsId);
					loadedSystemBean.setTitle(tmpSystem.getTitle());
					loadedSystemBean.setOid(tmpSystem.getOid());
					loadedActionsBean = new ArrayList<SelectedActionBean>();
					for (int j = 0; j < selectedActionsBean.size(); j++) {
						loadedActionBean = selectedActionsBean.get(j);
						for (int k = 0; k < selectedActions.size(); k++) {
							if (selectedActions.get(k).getActionsId() == loadedActionBean.getActionsId()) {
								loadedActionBean.setDescription(selectedActions.get(k).getDescription());
								loadedActionBean.setCode(selectedActions.get(k).getCode());
								loadedActionsBean.add(loadedActionBean);
								break;
							}
						}						
					}
					loadedSystemBean.setActions(loadedActionsBean);
					loadedSystemBeans.add(loadedSystemBean);
				}
			}
			systemsHm.clear();
			selectedActionsBean.clear();
			return loadedSystemBeans; 
		}
		return null;
	}
	
	public String populateXMLForAuthorizationSign(AuthorizationBean bean, MySpacePortletSessionBean sessionBean, String currentTime) {
		StringBuffer xml = new StringBuffer();
		UserProfile profile = sessionBean.getProfile();
		UserProfileBean userProfile = sessionBean.getUserProfile();
		String identifier = profile.getEik();
		String name = profile.getNameAndLegalForm();		
		if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(profile.getProfileType())) {
			EncryptorAESGCM aesCls = new EncryptorAESGCM();
			identifier = aesCls.decryptEgovIdentifier(profile.getIdentifier());
			name = profile.getNames();
		}
		if (identifier == null) {
			identifier = userProfile.getCurrentUserUID();
		}
		xml.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		xml.append("<authorization>");
		xml.append("<authorizing>");
		xml.append("<idType>" + profile.getProfileType() + "</idType>");
		xml.append("<id>" + encodeXML(identifier) + "</id>");
		xml.append("<name>" + encodeXML(name) + "</name>");
		xml.append("</authorizing>");
		xml.append("<authorized>");
			xml.append("<type>" + bean.getAuthorizedType() + "</type>");
			xml.append("<idType>" + bean.getAuthorizedIdentifierType() + "</idType>");
			xml.append("<id>" + encodeXML(bean.getAuthorizedIdentifier()) + "</id>");
			xml.append("<name>" + encodeXML(bean.getAuthorizedNames()) + "</name>");
		xml.append("</authorized>");
		List<SelectedSystemBean> systems = bean.getLoadedSystemBeans();
		if (systems != null && systems.size() > 0) {
			SelectedSystemBean system = null;
			List<SelectedActionBean> actions = null;
			xml.append("<systems>");
			for (int i = 0; i < systems.size(); i++) {
				system = systems.get(i);
				actions = system.getActions();
				xml.append("<system>");
					xml.append("<oid>" + encodeXML(system.getOid()) + "</oid>");
					xml.append("<name>" + encodeXML(system.getTitle()) + "</name>");
					xml.append("<actions>");
					for (int j = 0; j < actions.size(); j++) {
						xml.append("<actionId>" + encodeXML(actions.get(j).getCode()) + "</actionId>");
						xml.append("<actionName>" + encodeXML(actions.get(j).getDescription()) + "</actionName>");
					}
					xml.append("</actions>");
				xml.append("</system>");
			}
			xml.append("</systems>");			
		}
		xml.append("<period>");
			xml.append("<from>" + getValidFrom(bean) + "</from>");
			xml.append("<to>" + getValidTo(bean) + "</to>");
		xml.append("</period>");		
		xml.append("<dateIssued>" + currentTime + "</dateIssued>");	
		xml.append("<rnu>" + bean.getRnu() + "</rnu>");	
		xml.append("</authorization>");
		return xml.toString();
	}
	
	public ProfileIdentifierBean populateProfileIdentifierBeanFromDB(UserProfileIdentifier profileIdentifier) {
		ProfileIdentifierBean bean = new ProfileIdentifierBean();
		bean.setId(profileIdentifier.getId());
		bean.setIdentifierType(String.valueOf(profileIdentifier.getIdentifierType()));
		bean.setIdentifierCountryCode(profileIdentifier.getIdentifierCountryCode());		
		bean.setIdentifier(profileIdentifier.getIdentifier());
		bean.setRnu(profileIdentifier.getRnu()); 
		return bean;
	}
	

	public String populateXMLForProfileIdentifierSign(ProfileIdentifierBean bean, MySpacePortletSessionBean sessionBean, String currentTime) {
		StringBuffer xml = new StringBuffer();
		UserProfile profile = sessionBean.getProfile();
		UserProfileBean userProfile = sessionBean.getUserProfile();
		String identifier = profile.getEik();
		String name = profile.getNameAndLegalForm();		
		if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(profile.getProfileType())) {
			EncryptorAESGCM aesCls = new EncryptorAESGCM();
			identifier = aesCls.decryptEgovIdentifier(profile.getIdentifier());
			name = profile.getNames();
		}
		if (identifier == null) {
			identifier = userProfile.getCurrentUserUID();
		}
		xml.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
		xml.append("<identifier>");
		xml.append("<type>" + bean.getIdentifierType() + "</type>");
		xml.append("<countryCode>" + bean.getIdentifierCountryCode() + "</countryCode>");
		xml.append("<id>" + encodeXML(bean.getIdentifier()) + "</id>");
		xml.append("<owner>" + encodeXML(name) + "</owner>");
		xml.append("<dateIssued>" + currentTime + "</dateIssued>");	
		xml.append("<rnu>" + bean.getRnu() + "</rnu>");	
		xml.append("</identifier>");
		return xml.toString();
	}
	
	public String getValidFrom(AuthorizationBean bean) {
		return bean.getValidFromDate() + " " + (bean.getValidFromTime() != null ? bean.getValidFromTime() + ":00" : "00:00:00");
	}
	
	public String getValidTo(AuthorizationBean bean) {
		return bean.getValidToDate() + " " + (bean.getValidToTime() != null ? bean.getValidToTime() + ":00" : "23:59:59");
	}
	
	public String getPathFromUrlString(String urlString) {
		try {
			URL url = new URL(urlString);
			return url.getPath();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return null; 
	}
	
	public static String escapeStringForDB(String text) {
		if (text == null) return "";
		String tmp = text.replaceAll("\\\\", "\\\\\\\\\\\\\\\\");
		return tmp.replaceAll("'", "\\\\'");
	}
	
	public String encodeXML(CharSequence s) {
		if (s == null) return "";
		StringBuilder sb = new StringBuilder();
	    int len = s.length();
	    for (int i=0;i<len;i++) {
	        int c = s.charAt(i);
            switch(c) {
              case '&':  sb.append("&amp;"); break;
              case '>':  sb.append("&gt;"); break;
              case '<':  sb.append("&lt;"); break;
              // Uncomment next two if encoding for an XML attribute
//	                  case '\''  sb.append("&apos;"); break;
//	                  case '\"'  sb.append("&quot;"); break;
              // Uncomment next three if you prefer, but not required
//	                  case '\n'  sb.append("&#10;"); break;
//	                  case '\r'  sb.append("&#13;"); break;
//	                  case '\t'  sb.append("&#9;"); break;

              default:   sb.append((char)c);
            }
	    }
	    return sb.toString();
	}
	
	public String encodeXMLAdvanced(CharSequence s) {
		if (s == null) return ""; 
	    StringBuilder sb = new StringBuilder();
	    int len = s.length();
	    for (int i=0;i<len;i++) {
	        int c = s.charAt(i);
	        if (c >= 0xd800 && c <= 0xdbff && i + 1 < len) {
	            c = ((c-0xd7c0)<<10) | (s.charAt(++i)&0x3ff);    // UTF16 decode
	        }
	        if (c < 0x80) {      // ASCII range: test most common case first
	            if (c < 0x20 && (c != '\t' && c != '\r' && c != '\n')) {
	                // Illegal XML character, even encoded. Skip or substitute
	                sb.append("&#xfffd;");   // Unicode replacement character
	            } else {
	                switch(c) {
	                  case '&':  sb.append("&amp;"); break;
	                  case '>':  sb.append("&gt;"); break;
	                  case '<':  sb.append("&lt;"); break;
	                  // Uncomment next two if encoding for an XML attribute
//	                  case '\''  sb.append("&apos;"); break;
//	                  case '\"'  sb.append("&quot;"); break;
	                  // Uncomment next three if you prefer, but not required
//	                  case '\n'  sb.append("&#10;"); break;
//	                  case '\r'  sb.append("&#13;"); break;
//	                  case '\t'  sb.append("&#9;"); break;

	                  default:   sb.append((char)c);
	                }
	            }
	        } else if ((c >= 0xd800 && c <= 0xdfff) || c == 0xfffe || c == 0xffff) {
	            // Illegal XML character, even encoded. Skip or substitute
	            sb.append("&#xfffd;");   // Unicode replacement character
	        } else {
	            sb.append("&#x");
	            sb.append(Integer.toHexString(c));
	            sb.append(';');
	        }
	    }
	    return sb.toString();
	}

	public static String getMd5(String input) {
        try {
            // Static getInstance method is called with hashing MD5
            MessageDigest md = MessageDigest.getInstance("MD5");

            // digest() method is called to calculate message digest
            //  of an input digest() return array of byte
            byte[] messageDigest = md.digest(input.getBytes());

            // Convert byte array into signum representation
            BigInteger no = new BigInteger(1, messageDigest);

            // Convert message digest into hex value
            String hashtext = no.toString(16);
            while (hashtext.length() < 32) {
                hashtext = "0" + hashtext;
            }
            return hashtext;
        }

        // For specifying wrong message digest algorithms
        catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
	
	public static boolean eTranslationFileHasValidExtension(String extension) {
		switch (extension) {
		case "odt": return true;			
		case "ods": return true;			
		case "odp": return true;			
		case "odg": return true;			
		case "ott": return true;			
		case "ots": return true;			
		case "otp": return true;			
		case "otg": return true;			
		case "rtf": return true;			
		case "doc": return true;			
		case "docx": return true;			
		case "xls": return true;			
		case "xlsx": return true;			
		case "ppt": return true;			
		case "ppts": return true;			
		case "pdf": return true;			
		case "txt": return true;			
		case "htm": return true;			
		case "html": return true;			
		case "xhtml": return true;			
		case "xml": return true;			
		case "xlf": return true;			
		case "xliff": return true;			
		case "sdlxliff": return true;			
		case "tmx": return true;			
		case "rdf": return true;			
		default:
			return false;
		}
	}
	
	public String getEPaymentStatus(String status) {
		if ("PENDING".equalsIgnoreCase(status)) {
			return "Очаква плащане";
		} else if ("AUTHORIZED".equalsIgnoreCase(status)) {
			return "Получена авторизация";
		} else if ("ORDERED".equalsIgnoreCase(status)) {
			return "Наредено";
		} else if ("PAID".equalsIgnoreCase(status)) {
			return "Получено по сметката";
		} else if ("EXPIRED".equalsIgnoreCase(status)) {
			return "Изтекло";
		} else if ("CANCELED".equalsIgnoreCase(status)) {
			return "Отказано от потребител";
		} else if ("SUSPENDED".equalsIgnoreCase(status)) {
			return "Отказано от АИС";
		}		
		return status;
	}
	
	public String getIdentifierTypeName(String type, boolean shortName) {
		if (MySpaceConstants.IDENTIFIER_TYPE_PERSONAL_CARD_NUMBER.equals(type)) {
			return shortName ? "Лична карта" : "Номер на лична карта";
		} else if (MySpaceConstants.IDENTIFIER_TYPE_PASSPORT.equals(type)) {
			return shortName ? "Паспорт" : "Номер на паспорт";
		} else if (MySpaceConstants.IDENTIFIER_TYPE_PIK_NRA.equals(type)) {
			return "ПИК на НАП";
		} else if (MySpaceConstants.IDENTIFIER_TYPE_PIK_NOI.equals(type)) {
			return "ПИК на НОИ";
		} else if (MySpaceConstants.IDENTIFIER_TYPE_EORI.equals(type)) {
			return shortName ? "EORI" : "EORI номер от Агенция \"Митници\"";
		} else if (MySpaceConstants.IDENTIFIER_TYPE_NATIONAL_IDENTIFIER_FOREIGNER.equals(type)) {
			return "Национален идентификатор";
		} 
		return type;
	}
	
	public String getIdentifierTypeName(Integer type, boolean shortName) {
		return this.getIdentifierTypeName(String.valueOf(type), shortName);
	}
	
	public String generateChangeEmailCode() {
		String uuid = UUID.randomUUID().toString() + UUID.randomUUID().toString(); 
		uuid = uuid.replaceAll("-", "");
		if (uuid.length() > 47) {
			uuid = uuid.substring(0, 47);
		}		
		uuid += System.currentTimeMillis();
		if (uuid.length() > 60) {
			return uuid.substring(0, 60);
		}
		return uuid;
	}
	
	public String createPagePortletUrlWithParameters(PortletRequest request, PortletResponse response, final int mode, final String confirmationCode, final String pageID, final String portletID) throws Exception {
		Logger.println("Adding following parameters to activation url. confirmation code:" + confirmationCode + " page id=" + pageID + " portlet id=" + portletID);
		final Context ctx = new InitialContext();
		PortletServiceHome serviceHome = (PortletServiceHome) ctx.lookup(MySpaceConstants.JNDI_PORTLET_STATE);
		PortletStateManagerService service = (PortletStateManagerService) serviceHome.getPortletService(PortletStateManagerService.class);
		String finalUrl = "";
		final PortletStateManager mgr = service.getPortletStateManager(request, response);
		final URLFactory urlFactory = mgr.getURLFactory();
		try {
			final EngineURL url = urlFactory.newURL(Clone.EMPTY_COPY); // save no navigation state
			// Set the page this URL should point to
			final SelectionAccessorFactory selectionFactory = (SelectionAccessorFactory) mgr.getAccessorFactory(SelectionAccessorFactory.class);
			// Request the selection controller to set the page; pass in the state associated with the created URL
			final SelectionAccessorController selectionCtrl = selectionFactory.getSelectionAccessorController(url.getState());
			selectionCtrl.setSelection(pageID);
			selectionCtrl.dispose();
			if (portletID != null) {
				final PortletAccessorFactory portletAccessorFactory = (PortletAccessorFactory) mgr.getAccessorFactory(PortletAccessorFactory.class);
				// Get the portlet controller to set render parameters - pass in the state associated with rge created URL
				final PortletAccessorController portletCtrl = portletAccessorFactory.getPortletAccessorController(portletID, url.getState());
				java.util.Map<String, String[]> map = portletCtrl.getParameters();				
				if (confirmationCode != null) {
					map.put(MySpaceConstants.EMAIL_CONFIRM_CONFIRMATION_CODE_PARM, new String[] { confirmationCode });
				}	
				map.put(MySpaceConstants.EMAIL_CONFIRM_TYPE_PARM, new String[] { String.valueOf(mode) });
				portletCtrl.dispose();
			}
			finalUrl = url.writeDispose(new StringWriter()).toString();
		} finally {
			urlFactory.dispose();
			mgr.dispose();
			ctx.close();
		}
		Logger.println("Activation url is:" + finalUrl);
		return finalUrl;
	}
	
	public int countActiveProfiles (MySpacePortletSessionBean sessionBean) {
		int countActiveProfiles = 0;
		
		UserProfile[] profiles = sessionBean.getProfiles();
		UserProfile[] profilesParticipation = sessionBean.getProfilesParticipation();
		if (profiles != null && profiles.length > 0) {
			for (int i = 0; i < profiles.length; i++) {
				if (MySpaceConstants.USER_PROFILE_STATUS_ACTIVE.equals(profiles[i].getStatus())) {
					countActiveProfiles++;
				}
			}
		}
		if (profilesParticipation != null) {
			for (int i = 0; i < profilesParticipation.length; i++) {
				if (MySpaceConstants.USER_PROFILE_STATUS_ACTIVE.equals(profilesParticipation[i].getStatus())) {
					countActiveProfiles++;
				}
			}
		}
		return countActiveProfiles;
	}
	
	public UserProfile[] updatePersonalParameterEmailWithRoleEmail(UserProfile[] profiles, UserProfileRole[] roles) {
		if (profiles != null && profiles.length > 0 && roles != null && roles.length > 0) {
			UserProfile profile = null;
			for (int i = 0; i < profiles.length; i++) {
				profile = profiles[i];
				if (profile.getPersonalParameters() != null) {
					for (int j = 0; j < roles.length; j++) {
						if (profile.getUserUID().equalsIgnoreCase(roles[j].getUserUID())) {
							if (roles[j].getEmail() != null && roles[j].getEmail().trim().length() > 0) {
								profiles[i].getPersonalParameters().setEmail(roles[j].getEmail());
							}
							break;
						}
					}
				}
			}
		}
		return profiles;
	}
	
	public UserProfile[] removeProfileFromProfiles(UserProfile[] allProfiles, UserProfile profile) {
		UserProfile[] filteredProfiles = new UserProfile[allProfiles.length-1];
		for (int i = 0; i < allProfiles.length; i++) {
			if (!allProfiles[i].getId().equals(profile.getId())) {
				filteredProfiles[filteredProfiles.length] = allProfiles[i];
			}
		}
		return filteredProfiles;
	}
	
	public UserProfile[] loadProfileParticipations(String currentUserUID, List<String> currentProfileIds) {
		UserProfileManagement management = new UserProfileManagement();
		// Load profiles participation through the UserProfileRole table.
		UserProfileRole[] roles = management.loadAllProfileRolesByUserUID(currentUserUID);
		if (roles != null && roles.length > 0) {
			String userProfileIds = "";
			for (int i = 0; i < roles.length; i++) {
				// Skip current loaded profiles.
				if (!currentProfileIds.contains(roles[i].getUserProfileId())) {
					if (userProfileIds.trim().length() > 0) {
						userProfileIds += ",";
					}
					userProfileIds += roles[i].getUserProfileId(); 
				}
			}
			if (userProfileIds.length() > 0) {
				return management.loadAllProfilesByIds(userProfileIds);
			}
		}
		return null;
	}
	
	public List<String> getCurrentProfileIds(UserProfile[] profiles) {		
		List<String> currentProfileIds = new ArrayList<>();
		if (profiles != null && profiles.length > 0) {
			for (int i = 0; i < profiles.length; i++) {
				currentProfileIds.add(profiles[i].getId());
			}
		}
		return currentProfileIds;
	}
	
	public String[] distinctXCSystemOIDs(HorizontalSystemRole[] horizontalSystemRoles) {
		List<String> oids = new ArrayList<String>();
		if (horizontalSystemRoles != null && horizontalSystemRoles.length > 0) {
			for (int i = 0; i < horizontalSystemRoles.length; i++) {
				if (!oids.contains(horizontalSystemRoles[i].getSystemOID())) {
					oids.add(horizontalSystemRoles[i].getSystemOID());
				}
			}
		}
		return oids != null && oids.size() > 0 ? (String[])oids.toArray(new String[oids.size()]) : null;
	}
	
	public boolean isHorizontalSystemRoleSelected(UserProfileXCRole[] xcRoles, String horizontalSystemRoleId) {
		if (horizontalSystemRoleId == null || xcRoles == null || xcRoles.length == 0) return false;
		for (int i = 0; i < xcRoles.length; i++) {
			if (xcRoles[i].getHorizontalSystemRoleId().equals(horizontalSystemRoleId)) {
				return true;
			}
		}
		return false;
	}
	
	public String addSpaces(String str, int step) {
		String strWithSpaces = "";
		try {
			while (str.length() > step) {		
				strWithSpaces += str.substring(0, step) + " ";
				str = str.substring(step);
			}			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return strWithSpaces;
	}
	
	public boolean isREIK(String eik) {
		return eik != null && eik.trim().length() == 17;
	}
	
	public static int getCurrentHour() {
		return LocalDateTime.now().getHour();	
	}
	
	public static String getConfigValueFromFile(String filePath, String configParamName) {
		Scanner scanner = null;
		try {
			scanner = new Scanner(new File(filePath));
			if (scanner.hasNext()) {
				String line = null;
				String[] paramValues = null;
				while(scanner.hasNext()) {
					line = scanner.nextLine();
					if (line != null && line.trim().length() > 0) {
						if (line.indexOf(configParamName) != -1) {
							paramValues = line.split("=");
							if (paramValues != null && paramValues.length == 2) {								
								return paramValues[1].trim();
							}
						}
					}					
				}				
			}			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				if (scanner != null) {
					scanner.close();
				}
			} catch (Exception e) {}
		}		
		return null;
	}
	
	public static String setValueToConfigFile(String filePath, String configParamName, String value) {
		System.out.println("setValueToConfigFile(" + filePath + "," + configParamName + ", " + value + ")");
		Scanner scanner = null;
		boolean found = false;
		StringBuffer inputBuffer = null;
		try {
			scanner = new Scanner(new File(filePath));
			if (scanner.hasNext()) {
				String line = null;
				inputBuffer = new StringBuffer();
				while(scanner.hasNext()) {
					line = scanner.nextLine();
					if (line != null && line.trim().length() > 0) {
						System.out.println("setValueToConfigFile(): line=" + line);
						if (line.indexOf(configParamName) != -1) {
							line = configParamName + "=" + value;
							System.out.println("setValueToConfigFile(): found: line=" + line);
							found = true;
						}
						inputBuffer.append(line);
			            inputBuffer.append('\n');
					}					
				}
				if (!found) {
					System.out.println("setValueToConfigFile(): not_found");
					inputBuffer.append(configParamName + "=" + value);
		            inputBuffer.append('\n');					
				}
			}			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				if (scanner != null) {
					scanner.close();
				}
			} catch (Exception e) {}
	    }		
		if (inputBuffer != null) {
			System.out.println("inputBuffer != null:" + inputBuffer.toString());
			FileOutputStream fileOut = null;
			// write the new string with the replaced line OVER the same file
	        try {
				fileOut = new FileOutputStream(filePath);
				fileOut.write(inputBuffer.toString().getBytes());
				fileOut.close();
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				try {
					if (fileOut != null) {
						fileOut.close();
					}
				} catch (Exception e) {}
		    }
		}
		return null;
	}
	
	public String getMunicipalityIdListFromESBMDTBeanList(List<ESBMDTBean> mdts) {
		String municipalityIdList = ""; 
		if (mdts != null) {
			List<String> processed = new ArrayList<String>();
			for (int i = 0; i < mdts.size(); i++) {
				if (!processed.contains(mdts.get(i).getMunicipalityId())) {
					if (municipalityIdList.trim().length() > 0) {
						municipalityIdList += ",";
					}
					municipalityIdList += mdts.get(i).getMunicipalityId();
					processed.add(mdts.get(i).getMunicipalityId());
				}
			}
			processed.clear();
		}
		return municipalityIdList;
	}
	
	public String getRepresentedPersonId(UserProfile profile, String personalIdentifier) {
		if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(profile.getProfileType())) {
			return MySpaceConstants.ESB_IDENTIFIER_TYPE_PREFIX_EGN + "-" + personalIdentifier;
		} 
		return MySpaceConstants.ESB_IDENTIFIER_TYPE_PREFIX_LE + "-" + profile.getEik();
				
	}
	
	public boolean isValidJSON(String test) {
		if (test == null || test.trim().length() == 0) return false;
	    try {
	        new JSONObject(test);
	    } catch (JSONException ex) {
	        try {
	            new JSONArray(test);
	        } catch (JSONException ex1) {
	            return false;
	        }
	    }
	    return true;
	}
	
	public boolean isValidEmail(String email) {
		if (email == null || email.trim().length() == 0) return false;
		String regexPattern = "^(?=.{1,64}@)[A-Za-z0-9_-]+(\\.[A-Za-z0-9_-]+)*@" 
		        + "[^-][A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";
		return Pattern.compile(regexPattern).matcher(email).matches();
	}
	
	public String getTicketForPaymentType(String type) {
		return MySpaceConstants.ESB_TICKETS_BY_PERSON_TYPE_PENAL_DECREE.equalsIgnoreCase(type) ? "НП" : "Фиш";
	}
	
}
