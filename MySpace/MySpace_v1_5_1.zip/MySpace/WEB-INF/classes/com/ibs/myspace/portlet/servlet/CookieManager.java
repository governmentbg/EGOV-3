package com.ibs.myspace.portlet.servlet;

import java.io.IOException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import com.ibm.portal.um.PumaController;
import com.ibm.portal.um.PumaHome;
import com.ibm.portal.um.PumaProfile;
import com.ibm.portal.um.exceptions.PumaException;
import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.db.Base;
import com.ibs.myspace.portlet.utils.Logger;

@WebServlet("/cookie-manager")
public class CookieManager extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	public static final String OPERATION_ADD = "add";
	public static final String OPERATION_REMOVE = "remove";	
	public static final String OPERATION_GET = "get";	
	public boolean userLoggedIn = false;
	public boolean debug = false;
	private static PumaHome pumaHome = null;	
	public String operation = null;
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;

	
	public void init(ServletConfig config) throws ServletException {
		super.init();
		InitialContext initialcontext;
		try {
			initialcontext = new InitialContext();
			pumaHome = (PumaHome) initialcontext.lookup("portal:service/usermanagement/Puma");
		} catch (NamingException namingexception) {
			namingexception.printStackTrace();
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		if (!Base.TEST_ENVIRONMENT) {
			response.setHeader("Cache-Control", "no-cache");
			request.setCharacterEncoding("utf8");		
			response.setContentType("application/json; charset=UTF-8");
			return;
		}
		debug = "true".equalsIgnoreCase(request.getParameter("debug"));
		String operation = request.getParameter("op");
		
		Logger.log(Logger.DEBUG_LEVEL, "CookieManager -> doGet(" + operation + ") start...");
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");		
		response.setContentType("application/json; charset=UTF-8");
		
		JSONObject json = new JSONObject();
		
		if (getPumaHome() != null) {
			PumaProfile pumaProfile = getPumaHome().getProfile();
			if (pumaProfile != null) {
				try {
					com.ibm.portal.um.User user = pumaProfile.getCurrentUser();
					if (user != null) {
						String demo = "demo";
						String sec = "sec";
						if (OPERATION_ADD.equalsIgnoreCase(operation)) {							 						   
						    Cookie demoC = new Cookie(demo, "1");
						    Cookie secC = new Cookie(sec, "1");
						    demoC.setDomain(".egov.bg");
						    demoC.setPath("/");
						    demoC.setMaxAge(60*30);
						    secC.setDomain(".egov.bg");
						    secC.setPath("/");
						    secC.setMaxAge(60*30);
						    secC.setHttpOnly(true);
						    response.addCookie(demoC);
						    response.addCookie(secC);
						    
						    json.put("data", "add");
							String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
							response.getWriter().print(jsonPrettyPrintString);
							response.getWriter().flush();
							response.getWriter().close();	
							return;
						} else if (OPERATION_REMOVE.equalsIgnoreCase(operation)) {
							Cookie ck[]=request.getCookies();  
							for (int i = 0; i < ck.length; i++) {  
						    	System.out.println(ck[i].getName() + " " + ck[i].getValue());  
						    	if (MySpaceConstants.EAUTH_COOKIE_NAME.equalsIgnoreCase(ck[i].getName())) {
						    		System.out.println("REMOVING COOKIE:" + ck[i].getName() + " " + ck[i].getValue());  
						    		Cookie auth = new Cookie(MySpaceConstants.EAUTH_COOKIE_NAME, "");	
						    		auth.setDomain(".egov.bg");
						    		auth.setPath("/");
						    		auth.setMaxAge(0);
						    		auth.setHttpOnly(true);
								    response.addCookie(auth);
						    		
						    	}
						    	if (demo.equalsIgnoreCase(ck[i].getName())) {
						    		System.out.println("REMOVING COOKIE:" + ck[i].getName() + " " + ck[i].getValue());
						    		Cookie demoC = new Cookie(demo, "");	
						    		demoC.setDomain(".egov.bg");
								    demoC.setPath("/");
						    		demoC.setMaxAge(0);
						    		response.addCookie(demoC);
						    		
						    	}
						    	if (sec.equalsIgnoreCase(ck[i].getName())) {
						    		System.out.println("REMOVING COOKIE:" + ck[i].getName() + " " + ck[i].getValue());
						    		Cookie secC = new Cookie(sec, "");	
						    		secC.setDomain(".egov.bg");
								    secC.setPath("/");
								    secC.setMaxAge(0);
								    secC.setHttpOnly(true);
						    		response.addCookie(secC);
						    	}
						    }  
							json.put("data", "removed");
							String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
							response.getWriter().print(jsonPrettyPrintString);
							response.getWriter().flush();
							response.getWriter().close();	
							return;
						} else {
							Cookie ck[]=request.getCookies();  
							JSONArray tmpJA = null; 
							JSONArray jarr = new JSONArray(); 
							for (int i = 0; i < ck.length; i++) {
								tmpJA = new JSONArray();
								tmpJA.put(ck[i].getName());
								tmpJA.put(ck[i].getValue());
								tmpJA.put(ck[i].getDomain());							
								tmpJA.put(ck[i].getPath());							
								tmpJA.put(ck[i].isHttpOnly());							
								tmpJA.put(ck[i].getSecure());							
								jarr.put(tmpJA);					
							}	
							json.put("data", jarr);
							String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
							response.getWriter().print(jsonPrettyPrintString);
							response.getWriter().flush();
							response.getWriter().close();	
							return;
						}
					}
				} catch (PumaException e) {
					System.out.println(e.getMessage());
					e.printStackTrace();
				}
			}
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public static PumaHome getPumaHome() {
		return pumaHome;
	}

	public static PumaProfile getPumaProfile() {
		return pumaHome.getProfile();
	}

	public static PumaController getPumaController() {
		return pumaHome.getController();
	}
	
}
