package com.ibs.myspace.portlet.db;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.dbo.ETranslationRequest;
import com.ibs.myspace.portlet.dbo.UserProfile;
import com.ibs.myspace.portlet.dbo.UserProfilePersonalParameters;
import com.ibs.myspace.portlet.dbo.UserProfileRequest;
import com.ibs.myspace.portlet.dbo.UserProfileRole;
import com.ibs.myspace.portlet.model.Actions;
import com.ibs.myspace.portlet.model.ActionsMapper;
import com.ibs.myspace.portlet.model.Authorizations;
import com.ibs.myspace.portlet.model.AuthorizationsMapper;
import com.ibs.myspace.portlet.model.Systems;
import com.ibs.myspace.portlet.model.SystemsMapper;
import com.ibs.myspace.portlet.model.UserProfileMapper;
import com.ibs.myspace.portlet.utils.Logger;
import com.ibs.myspace.portlet.utils.MySpaceUtils;

public class QueryExecution {

	private static Connection getConnection() throws SQLException {
		
		Connection con = DBPool.getConnection();
		if (con == null) {
			throw new SQLException("Connection is NULL");
		}
		return con;
		
	} 
	
	private static Connection getMariaDBConnection() throws SQLException {

		Connection con = DBPool.getMariaDBConnection();
		if (con == null) {
			throw new SQLException("Maria DB connection is NULL");
		}
		return con;

	} 
	
	public int getMaxFavoriteServicesByUserUIDAndProfileType(final String userUID, final String profileType, final DBTransaction transaction) {
		Connection connection = null;
		int max = 0;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "SELECT";
				query += " " + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS.MAXFAVORITESERVICES";										
				query += " FROM " + DBResources._SCHEMANAME + "USERPROFILE";
				query += " LEFT JOIN " + DBResources._SCHEMANAME  + "USERPROFILEPERSONALPARAMETERS ON " + DBResources._SCHEMANAME + "USERPROFILE.USERPROFILEID = " + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS.USERPROFILEID";				
				query += " WHERE ";
				query += DBResources._SCHEMANAME + "USERPROFILE.USERUID = ?";				
				query += " AND " + DBResources._SCHEMANAME + "USERPROFILE.PROFILETYPE = ?";				
				Logger.log(Logger.DEBUG_LEVEL, "query=" + query);
				
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, userUID);
				preparedStatement.setString(2, profileType);
				
				ResultSet rs = preparedStatement.executeQuery();
				while (rs.next()) { 
					max = rs.getInt(1);
					break;
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		}
		return max;
	}
	
	public String[] loadAllActiveUserDataForAliveCheck(final DBTransaction transaction) {
		Logger.log(Logger.DEBUG_LEVEL, "loadAllActiveUserDataForAliveCheck(transaction) start...");
		List<String> userData = null;
		Connection connection = null;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "SELECT";
				query += " " + DBResources._SCHEMANAME + "USERPROFILE.USERUID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.IDENTIFIER";											
				query += " FROM " + DBResources._SCHEMANAME + "USERPROFILE";
				query += " WHERE ";
				query += DBResources._SCHEMANAME + "USERPROFILE.PROFILETYPE = ?";
				query += " AND " + DBResources._SCHEMANAME + "USERPROFILE.STATUS = ?";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				int col = 1;				
				preparedStatement.setString(col++, MySpaceConstants.USER_PROFILE_TYPE_PERSONAL);
				preparedStatement.setString(col++, MySpaceConstants.USER_PROFILE_STATUS_ACTIVE);
				ResultSet rs = preparedStatement.executeQuery();
				userData = new ArrayList<>();				
				while (rs.next()) { 
					col = 1;
					userData.add(rs.getString(col++) + "^^" + rs.getString(col++));										
				}
				Logger.log(Logger.DEBUG_LEVEL, "QE -> loadAllActiveUserDataForAliveCheck(transaction) size=" + userData.size());
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		}
		if (userData != null && userData.size() > 0) {
			return userData.toArray(new String[userData.size()]);
		}
		return null;
	}
	
	public UserProfile[] loadAllProfilesAndPersonalProfilesByUserUIDProfileTypeIdentifierEik(final String userUID, final String profileType, final String identifier, final String eik, final String userUIDs, final DBTransaction transaction) {
		Logger.log(Logger.DEBUG_LEVEL, "loadAllProfilesAndPersonalProfilesByUserUIDProfileTypeIdentifierEik(" + userUID + "," + profileType + "," + identifier + "," + eik + "," + userUIDs + ") start...");
		UserProfile[] userProfiles = null;	
		ArrayList<UserProfile> userProfilesArr = null;
		Connection connection = null;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "SELECT";
				query += " " + DBResources._SCHEMANAME + "USERPROFILE.USERPROFILEID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.USERUID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.IDENTIFIER";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.NAMES";				
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.STATUS";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.DEACTIVATIONREASON";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.EIK";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.NAMEANDLEGALFORM";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.QUALITYOFPHYSICALPERSON";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.METHODOFREPRESENTATION";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.PROFILETYPE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.PROFILESTRUCTURETYPE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.DATECREATED";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.DATEMODIFIED";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.GROUPID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.SAMLRESPONSE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.CUSTOMSIDENAV";	
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.IDENTIFIERPREFIX";	
				query += "," + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS.USERPROFILEPERSONALPARAMETERSID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS.SECURITYLEVEL";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS.CONSENTTOUSEADDRESS";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS.EKATTE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS.ADDRESSDESCRIPTION";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS.MAILBOX";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS.ZIPCODE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS.CONSENTTOUSEPHONE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS.PHONENUMBER";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS.CONSENTTOUSEEMAIL";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS.EMAIL";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS.MAXFAVORITESERVICES";										
				query += "," + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS.GENERALCONSENT";										
				query += "," + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS.DEFAULTUSERPROFILEID";										
				query += "," + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS.GTCONFIRMEDDATE";										
				query += " FROM " + DBResources._SCHEMANAME + "USERPROFILE";
				
				query += " LEFT JOIN " + DBResources._SCHEMANAME  + "USERPROFILEPERSONALPARAMETERS ON " + DBResources._SCHEMANAME + "USERPROFILE.USERPROFILEID = " + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS.USERPROFILEID";				
				query += " WHERE ";
				String where = "";
				if (userUID != null) {
					where += DBResources._SCHEMANAME + "USERPROFILE.USERUID = ?";
				}
				if (profileType != null) {
					if (where.length() > 0) {
						where += " AND ";
					}
					where += DBResources._SCHEMANAME + "USERPROFILE.PROFILETYPE = ?";
				}
				if (identifier != null) {
					if (where.length() > 0) {
						where += " AND ";
					}
					where += DBResources._SCHEMANAME + "USERPROFILE.IDENTIFIER = ?";
				}
				if (eik != null) {
					if (where.length() > 0) {
						where += " AND ";
					}
					where += DBResources._SCHEMANAME + "USERPROFILE.EIK = ?";
				}
				if (userUIDs != null) {
					if (where.length() > 0) {
						where += " AND ";
					}
					where += DBResources._SCHEMANAME + "USERPROFILE.USERUID IN (%s)";
				}
				query += where;
				Logger.log(Logger.DEBUG_LEVEL, "query=" + query);
				if (userUIDs != null) {
					String[] userUids = userUIDs.split(",");
					String inSql = String.join(",", Collections.nCopies(userUids.length, "?"));
					query = String.format(query, inSql);
				}
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				int col = 1;
				if (userUID != null) { 
					preparedStatement.setString(col++, userUID);
				}
				if (profileType != null) {
					preparedStatement.setString(col++, profileType);
				}
				if (identifier != null) {
					preparedStatement.setString(col++, identifier);
				}
				if (eik != null) {
					preparedStatement.setString(col++, eik);
				}
				if (userUIDs != null) {
					String[] userUids = userUIDs.split(",");
					for (int i = 0; i < userUids.length; i++) {						
						preparedStatement.setString(col++,  userUids[i]);
			        }	
				}
				ResultSet rs = preparedStatement.executeQuery();
				UserProfile userProfile = null;
				UserProfilePersonalParameters userProfileParameters = null;
				userProfilesArr = new ArrayList<>();				
				while (rs.next()) { 
					col = 1;
					userProfile = new UserProfile();
					userProfileParameters = new UserProfilePersonalParameters();
					userProfile.setId(rs.getString(col++));
					userProfile.setUserUID(rs.getString(col++));
					userProfile.setIdentifier(rs.getString(col++));
					userProfile.setNames(rs.getString(col++));
					userProfile.setStatus(rs.getString(col++));
					userProfile.setDeactivationReason(rs.getString(col++));
					userProfile.setEik(rs.getString(col++));
					userProfile.setNameAndLegalForm(rs.getString(col++));
					userProfile.setQualityOfPhysicalPerson(rs.getString(col++));
					userProfile.setMethodOfRepresentation(rs.getString(col++));
					userProfile.setProfileType(rs.getString(col++));
					userProfile.setProfileStructureType(rs.getString(col++));
					userProfile.setDateCreated(rs.getString(col++));
					userProfile.setDateModified(rs.getString(col++));
					userProfile.setGroupId(rs.getString(col++));
					userProfile.setSamlResponse(rs.getString(col++));
					userProfile.setCustomSideNav(rs.getString(col++));
					userProfile.setIdentifierPrefix(rs.getString(col++));
					userProfileParameters.setId(rs.getString(col++));
					userProfileParameters.setUserProfileId(userProfile.getId());
					userProfileParameters.setSecurityLevel(rs.getString(col++));
					userProfileParameters.setConsentToUseAddress(rs.getString(col++));
					userProfileParameters.setEkatte(rs.getString(col++));
					userProfileParameters.setAddressDescription(rs.getString(col++));
					userProfileParameters.setMailBox(rs.getString(col++));
					userProfileParameters.setZipCode(rs.getString(col++));
					userProfileParameters.setConsentToUsePhone(rs.getString(col++));
					userProfileParameters.setPhoneNumber(rs.getString(col++));
					userProfileParameters.setConsentToUseEmail(rs.getString(col++));
					userProfileParameters.setEmail(rs.getString(col++));
					userProfileParameters.setMaxFavoriteServices(rs.getString(col++));					
					userProfileParameters.setGeneralConsent(rs.getString(col++));					
					userProfileParameters.setDefaultUserProfileId(rs.getString(col++));					
					userProfileParameters.setGtConfirmedDate(rs.getString(col++));					
					userProfile.setPersonalParameters(userProfileParameters);
					userProfilesArr.add(userProfile);
				}
				Logger.log(Logger.DEBUG_LEVEL, "QE -> loadAllProfilesAndPersonalProfilesByUserUID(" + userUID + ") size=" + userProfilesArr.size());
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		}
		if (userProfilesArr != null && userProfilesArr.size() > 0) {
			return userProfilesArr.toArray(new UserProfile[userProfilesArr.size()]);
		}
		return userProfiles;
	}
	
	public UserProfileRole[] loadAllProfileRolesAndProfilesByUserUID(final String userUID, final DBTransaction transaction) {
		ArrayList<UserProfileRole> userProfileRolesArr = null;
		Connection connection = null;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "SELECT";
				query += " " + DBResources._SCHEMANAME + "USERPROFILEROLE.USERPROFILEROLEID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEROLE.USERPROFILEID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEROLE.USERUID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEROLE.ADMIN";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEROLE.EDITOR";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEROLE.SERVICEMANAGER";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEROLE.USERROLE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEROLE.DATECREATED";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEROLE.EMAIL";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEROLE.CONFIRM";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEROLE.CODE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.USERPROFILEID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.USERUID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.IDENTIFIER";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.NAMES";				
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.STATUS";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.DEACTIVATIONREASON";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.EIK";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.NAMEANDLEGALFORM";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.QUALITYOFPHYSICALPERSON";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.METHODOFREPRESENTATION";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.PROFILETYPE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.PROFILESTRUCTURETYPE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.DATECREATED";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.DATEMODIFIED";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.GROUPID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.SAMLRESPONSE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.CUSTOMSIDENAV";	
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.IDENTIFIERPREFIX";	
													
				query += " FROM " + DBResources._SCHEMANAME + "USERPROFILEROLE";
				
				query += " LEFT JOIN " + DBResources._SCHEMANAME  + "USERPROFILE ON " + DBResources._SCHEMANAME + "USERPROFILEROLE.USERPROFILEID = " + DBResources._SCHEMANAME + "USERPROFILE.USERPROFILEID";				
				query += " WHERE ";
				query += DBResources._SCHEMANAME + "USERPROFILEROLE.USERUID = ?";				
				Logger.log(Logger.DEBUG_LEVEL, "query=" + query);
				
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, userUID);
				
				ResultSet rs = preparedStatement.executeQuery();
				UserProfileRole userProfileRole = null;
				UserProfile userProfile = null;
				userProfileRolesArr = new ArrayList<>();				
				int col = 1;
				while (rs.next()) { 
					col = 1;
					userProfileRole = new UserProfileRole();
					userProfile = new UserProfile();
					userProfileRole.setId(rs.getString(col++));
					userProfileRole.setUserProfileId(rs.getString(col++));
					userProfileRole.setUserUID(rs.getString(col++));
					userProfileRole.setAdmin(rs.getString(col++));
					userProfileRole.setEditor(rs.getString(col++));
					userProfileRole.setServiceManager(rs.getString(col++));
					userProfileRole.setUser(rs.getString(col++));
					userProfileRole.setDateCreated(rs.getString(col++));
					userProfileRole.setEmail(rs.getString(col++));
					userProfileRole.setConfirm(rs.getString(col++));
					userProfileRole.setCode(rs.getString(col++));
					userProfile.setId(rs.getString(col++));
					userProfile.setUserUID(rs.getString(col++));
					userProfile.setIdentifier(rs.getString(col++));
					userProfile.setNames(rs.getString(col++));
					userProfile.setStatus(rs.getString(col++));
					userProfile.setDeactivationReason(rs.getString(col++));
					userProfile.setEik(rs.getString(col++));
					userProfile.setNameAndLegalForm(rs.getString(col++));
					userProfile.setQualityOfPhysicalPerson(rs.getString(col++));
					userProfile.setMethodOfRepresentation(rs.getString(col++));
					userProfile.setProfileType(rs.getString(col++));
					userProfile.setProfileStructureType(rs.getString(col++));
					userProfile.setDateCreated(rs.getString(col++));
					userProfile.setDateModified(rs.getString(col++));
					userProfile.setGroupId(rs.getString(col++));
					userProfile.setSamlResponse(rs.getString(col++));
					userProfile.setCustomSideNav(rs.getString(col++));
					userProfile.setIdentifierPrefix(rs.getString(col++));
									
					userProfileRole.setUserProfile(userProfile);
					userProfileRolesArr.add(userProfileRole);
				}
				Logger.log(Logger.DEBUG_LEVEL, "QE -> loadAllProfileRolesAndProfilesByUserUID(" + userUID + ") size=" + userProfileRolesArr.size());
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		}
		return userProfileRolesArr != null && userProfileRolesArr.size() > 0 ? userProfileRolesArr.toArray(new UserProfileRole[userProfileRolesArr.size()]) : null;
	}

	
	//https://www.ibm.com/developerworks/data/library/techarticle/0310bhogal/0310bhogal.html
	public String createUserProfileRequest(
			final String userProfileId, 
			final String profileType, 
			final String eik, 
			final String nameAndLegalForm, 
			final String orderNumber, 
			final InputStream document, 
			final String documentName, 
			final String documentContentType, 
			final long documentSize, 
			final String accessKind, 
			final String currentTime, 
			final String userUID, 
			final String personalIdentifier, 
			final String names,
			final String profileStructureType,
			final String profileStructureTypeOther,
			final String leUserProfileId,
			final String managersJson,
			final DBTransaction transaction
			) {
		String id = null;
		Connection connection = null;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO " + DBResources._SCHEMANAME + "USERPROFILEREQUEST VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
				id = Sequence.getNextVal("SEQ_USERPROFILEREQUEST", connection);
				preparedStatement.setString(1, id); 
				preparedStatement.setString(2, userProfileId); 
				preparedStatement.setString(3, profileType);
				preparedStatement.setString(4, eik);
				preparedStatement.setString(5, nameAndLegalForm);
				preparedStatement.setString(6, orderNumber);
				preparedStatement.setBinaryStream(7, document, (int)documentSize); 				
				//preparedStatement.setBytes(7, document);				
				preparedStatement.setString(8, documentName);
				if (documentSize > 0) {
					preparedStatement.setInt(9, (int)documentSize);
				} else {
					preparedStatement.setString(9, null);
				}
				preparedStatement.setString(10, documentContentType);				
				preparedStatement.setString(11, accessKind);
				// Status.
				preparedStatement.setString(12, MySpaceConstants.USER_PROFILE_REQUEST_STATUS_NOT_APPROVED);
				// Date created.
				preparedStatement.setString(13, currentTime);
				// Date approved.
				preparedStatement.setString(14, null);
				// Date canceled.
				preparedStatement.setString(15, null);
				// Cancel reason.
				preparedStatement.setString(16, null); 
				// UserUID.
				preparedStatement.setString(17, userUID); 
				// Names.
				preparedStatement.setString(18, names); 
				// Profile Structure Type.
				preparedStatement.setString(19, profileStructureType);
				// Profile Structure Type Other.
				preparedStatement.setString(20, profileStructureTypeOther);
				// When we make request for REIK, we populate this field with the parent LE profileId.
				preparedStatement.setString(21, leUserProfileId);
				// REIK.
				preparedStatement.setString(22, null);
				// personalIdentifier.
				preparedStatement.setString(23, personalIdentifier);
				// managersJson.
				preparedStatement.setString(24, managersJson != null && managersJson.trim().length() > 0 ? managersJson : null);
				preparedStatement.executeUpdate();
				preparedStatement.close();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			id = null;
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 
		return id;
	}
	
	
	public UserProfileRequest loadNotApprovedUserProfileRequestByUserProfileIdAndEIK(final String userProfileId, final String eik, final DBTransaction transaction) {
		return loadNotApprovedUserProfileRequestByUserProfileIdEIKLeUserProfileIdAndName(userProfileId, eik, null, null, transaction);
	}
	public UserProfileRequest loadNotApprovedUserProfileRequestByUserProfileIdEIKLeUserProfileIdAndName(final String userProfileId, final String eik, final String leUserProfileId, final String nameAndLegalForm, final DBTransaction transaction) {
		UserProfileRequest userProfileRequest = null;	
		Connection connection = null;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "SELECT";
				query += " " + DBResources._SCHEMANAME + "USERPROFILEREQUEST.USERPROFILEREQUESTID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEREQUEST.USERPROFILEID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEREQUEST.PROFILETYPE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEREQUEST.EIK";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEREQUEST.NAMEANDLEGALFORM";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEREQUEST.STATUS";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEREQUEST.PROFILESTRUCTURETYPE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEREQUEST.PROFILESTRUCTURETYPEOTHER";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEREQUEST.LEUSERPROFILEID";
				query += " FROM " + DBResources._SCHEMANAME + "USERPROFILEREQUEST";
				query += " WHERE ";
				query += DBResources._SCHEMANAME + "USERPROFILEREQUEST.STATUS = '" + MySpaceConstants.USER_PROFILE_REQUEST_STATUS_NOT_APPROVED + "'";
				int column = 1;
				HashMap<String, String> tmpHm = new HashMap<String, String>(); 
				if (userProfileId != null && userProfileId.trim().length() > 0) {
					query += " AND ";
					query += DBResources._SCHEMANAME + "USERPROFILEREQUEST.USERPROFILEID = ?";
					tmpHm.put(column + "", userProfileId);
					column++;
				}
				if (eik != null && eik.trim().length() > 0) {
					query += " AND ";
					query += DBResources._SCHEMANAME + "USERPROFILEREQUEST.EIK = ?";
					tmpHm.put(column + "", eik);
					column++;
				}
				if (leUserProfileId != null && leUserProfileId.trim().length() > 0) {
					query += " AND ";
					query += DBResources._SCHEMANAME + "USERPROFILEREQUEST.LEUSERPROFILEID = ?";
					tmpHm.put(column + "", leUserProfileId);
					column++;
				}
				if (nameAndLegalForm != null && nameAndLegalForm.trim().length() > 0) {
					query += " AND ";
					query += "LOWER(" + DBResources._SCHEMANAME + "USERPROFILEREQUEST.NAMEANDLEGALFORM) = ?";
					tmpHm.put(column + "", nameAndLegalForm);
					column++;
				}
				Logger.log(Logger.DEBUG_LEVEL, "query=" + query);
				
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				Logger.log(Logger.DEBUG_LEVEL, "column=" + column);
				if (column > 1) {
					String param = null;
					for (int i = 1; i < column; i++) {
						param = tmpHm.get(i + "");
						Logger.log(Logger.DEBUG_LEVEL, "get(" + i + ")");
						if (param != null) {
							preparedStatement.setString(i, param);
							Logger.log(Logger.DEBUG_LEVEL, "setString(" + i + "," + param + ")");
						} else {
							Logger.log(Logger.DEBUG_LEVEL, "param is NULL [" + i + "]");
						}
					}
				}				
				
				ResultSet rs = preparedStatement.executeQuery();
				while (rs.next()) { 
					userProfileRequest = new UserProfileRequest();
					userProfileRequest.setId(rs.getString(1));
					userProfileRequest.setUserProfileId(rs.getString(2));
					userProfileRequest.setProfileType(rs.getString(3));
					userProfileRequest.setEik(rs.getString(4));
					userProfileRequest.setNameAndLegalForm(rs.getString(5));
					userProfileRequest.setStatus(rs.getString(6));
					userProfileRequest.setProfileStructureType(rs.getString(7));
					userProfileRequest.setProfileStructureTypeOther(rs.getString(8));
					userProfileRequest.setLeUserProfileId(rs.getString(9));
					break;
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		}
		return userProfileRequest;
	}
	
	public UserProfileRequest[] loadAllNotApprovedUserProfileRequestsByUserProfileId(final String userProfileId, final DBTransaction transaction) {
		UserProfileRequest[] userProfileRequests = null;
		ArrayList<UserProfileRequest> userProfileRequestsArr = null;
		Connection connection = null;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "SELECT";
				query += " " + DBResources._SCHEMANAME + "USERPROFILEREQUEST.USERPROFILEREQUESTID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEREQUEST.USERPROFILEID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEREQUEST.PROFILETYPE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEREQUEST.EIK";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEREQUEST.NAMEANDLEGALFORM";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEREQUEST.STATUS";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEREQUEST.PROFILESTRUCTURETYPE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEREQUEST.PROFILESTRUCTURETYPEOTHER";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEREQUEST.LEUSERPROFILEID";
				query += " FROM " + DBResources._SCHEMANAME + "USERPROFILEREQUEST";
				query += " WHERE ";
				query += DBResources._SCHEMANAME + "USERPROFILEREQUEST.STATUS = '" + MySpaceConstants.USER_PROFILE_REQUEST_STATUS_NOT_APPROVED + "'";
				int column = 1;
				HashMap<String, String> tmpHm = new HashMap<String, String>(); 
				if (userProfileId != null && userProfileId.trim().length() > 0) {
					query += " AND ";
					query += DBResources._SCHEMANAME + "USERPROFILEREQUEST.USERPROFILEID = ?";
					tmpHm.put(column + "", userProfileId);
					column++;
				}
				query += " ORDER BY ";
				query += DBResources._SCHEMANAME + "USERPROFILEREQUEST.NAMEANDLEGALFORM ASC";
				Logger.log(Logger.DEBUG_LEVEL, "query=" + query);
				
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				Logger.log(Logger.DEBUG_LEVEL, "column=" + column);
				if (column > 1) {
					String param = null;
					for (int i = 1; i < column; i++) {
						param = tmpHm.get(i + "");
						Logger.log(Logger.DEBUG_LEVEL, "get(" + i + ")");
						if (param != null) {
							preparedStatement.setString(i, param);
							Logger.log(Logger.DEBUG_LEVEL, "setString(" + i + "," + param + ")");
						} else {
							Logger.log(Logger.DEBUG_LEVEL, "param is NULL [" + i + "]");
						}
					}
				}				
				
				ResultSet rs = preparedStatement.executeQuery();
				UserProfileRequest userProfileRequest = null;
				userProfileRequestsArr = new ArrayList<UserProfileRequest>();
				while (rs.next()) { 
					userProfileRequest = new UserProfileRequest();
					userProfileRequest.setId(rs.getString(1));
					userProfileRequest.setUserProfileId(rs.getString(2));
					userProfileRequest.setProfileType(rs.getString(3));
					userProfileRequest.setEik(rs.getString(4));
					userProfileRequest.setNameAndLegalForm(rs.getString(5));
					userProfileRequest.setStatus(rs.getString(6));
					userProfileRequest.setProfileStructureType(rs.getString(7));
					userProfileRequest.setProfileStructureTypeOther(rs.getString(8));
					userProfileRequest.setLeUserProfileId(rs.getString(9));
					userProfileRequestsArr.add(userProfileRequest);
				}
				Logger.log(Logger.DEBUG_LEVEL, "QE -> loadAllNotApprovedUserProfileRequestsByIds() size=" + userProfileRequestsArr.size());				
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		}
		if (userProfileRequestsArr != null && userProfileRequestsArr.size() > 0) {
			return userProfileRequestsArr.toArray(new UserProfileRequest[userProfileRequestsArr.size()]);
		}
		return userProfileRequests;
	}
	
	public int deactivateAllProfiles(final String userUID, final String deactivationReason, final DBTransaction transaction) {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> deactivateAllProfiles(" + userUID  + ") start...");	
		Connection connection = null;
		long currentTime = System.currentTimeMillis();
		int result = 0;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "UPDATE " + DBResources._SCHEMANAME + "USERPROFILE SET STATUS=?,DEACTIVATIONREASON=?,DATEMODIFIED=? WHERE USERUID=? AND STATUS <>?";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, MySpaceConstants.USER_PROFILE_STATUS_INACTIVE);
				preparedStatement.setString(2, deactivationReason);
				preparedStatement.setString(3, MySpaceUtils.timeMillisToTimestamp(currentTime));
				preparedStatement.setString(4, userUID);
				preparedStatement.setString(5, MySpaceConstants.USER_PROFILE_STATUS_INACTIVE);
				result = preparedStatement.executeUpdate();				
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> deactivateProfile(): UPDATE RESULT = " + result);
				preparedStatement.close();				
			}			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 	
		return result;
	}
	
	public int deactivateProfile(final String userProfileId, final String currentUserUID, final String names, final String identifier, final String identifierPrefix, final String deactivationReason, final DBTransaction transaction) {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> deactivateProfile(" + userProfileId  + "," + currentUserUID + "," + names + ") start...");	
		Connection connection = null;
		int result = -1;
		long currentTime = System.currentTimeMillis();
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "UPDATE " + DBResources._SCHEMANAME + "USERPROFILE SET STATUS=?,USERUID=?,NAMES=?,IDENTIFIER=?,IDENTIFIERPREFIX=?,DEACTIVATIONREASON=?,DATEMODIFIED=? WHERE USERPROFILEID=?";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(8, userProfileId);
				preparedStatement.setString(1, MySpaceConstants.USER_PROFILE_STATUS_INACTIVE);
				preparedStatement.setString(2, currentUserUID);
				preparedStatement.setString(3, names);
				preparedStatement.setString(4, identifier);
				preparedStatement.setString(5, identifierPrefix);
				preparedStatement.setString(6, deactivationReason);
				preparedStatement.setString(7, MySpaceUtils.timeMillisToTimestamp(currentTime));
				result = preparedStatement.executeUpdate();				
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> deactivateProfile(): UPDATE RESULT = " + result);
				preparedStatement.close();				
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 	
		return result;
	}
	
	public int activateProfile(final String userProfileId, final String currentUserUID, final String names, final String identifier, final String identifierPrefix, final DBTransaction transaction) {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> activateProfile(" + userProfileId  + "," + currentUserUID + "," + names + ") start...");	
		Connection connection = null;
		long currentTime = System.currentTimeMillis();
		int result = -1;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "UPDATE " + DBResources._SCHEMANAME + "USERPROFILE SET STATUS=?,USERUID=?,NAMES=?,IDENTIFIER=?,IDENTIFIERPREFIX=?,DEACTIVATIONREASON=?,DATEMODIFIED=? WHERE USERPROFILEID=?";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(8, userProfileId);
				preparedStatement.setString(1, MySpaceConstants.USER_PROFILE_STATUS_ACTIVE);
				preparedStatement.setString(2, currentUserUID);
				preparedStatement.setString(3, names);
				preparedStatement.setString(4, identifier);
				preparedStatement.setString(5, identifierPrefix);
				preparedStatement.setString(6, null);
				preparedStatement.setString(7, MySpaceUtils.timeMillisToTimestamp(currentTime));
				result = preparedStatement.executeUpdate();				
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> activateProfile(): UPDATE RESULT = " + result);
				preparedStatement.close();				
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 
		return result;
	}
	
	public int confirmProfile(final String userProfileId, final DBTransaction transaction) {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> confirmProfile(" + userProfileId  + ") start...");	
		Connection connection = null;
		long currentTime = System.currentTimeMillis();
		int result = -1;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "UPDATE " + DBResources._SCHEMANAME + "USERPROFILE SET STATUS=?,DEACTIVATIONREASON=?,DATEMODIFIED=? WHERE USERPROFILEID=?";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(4, userProfileId);
				preparedStatement.setString(1, MySpaceConstants.USER_PROFILE_STATUS_ACTIVE);
				preparedStatement.setString(2, null);
				preparedStatement.setString(3, MySpaceUtils.timeMillisToTimestamp(currentTime));
				result = preparedStatement.executeUpdate();				
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> confirmProfile(): UPDATE RESULT = " + result);
				
				// Update GTConfirmedDate too.
				query = "UPDATE " + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS SET GTCONFIRMEDDATE=? WHERE USERPROFILEID=?";
				preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(2, userProfileId);							
				preparedStatement.setString(1, MySpaceUtils.timeMillisToTimestamp(currentTime));
				result = preparedStatement.executeUpdate();				
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> confirmProfile GT(): UPDATE RESULT = " + result);
				preparedStatement.close();				
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 
		return result;
	}
	
	public int confirmGeneralTerms(final String userProfileId, final DBTransaction transaction) {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> confirmGeneralTerms(" + userProfileId  + ") start...");	
		Connection connection = null;
		long currentTime = System.currentTimeMillis();
		int result = -1;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {								
				// Update GTConfirmedDate too.
				String query = "UPDATE " + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS SET GTCONFIRMEDDATE=? WHERE USERPROFILEID=?";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(2, userProfileId);							
				preparedStatement.setString(1, MySpaceUtils.timeMillisToTimestamp(currentTime));
				result = preparedStatement.executeUpdate();				
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> confirmGeneralTerms(): UPDATE RESULT = " + result);
				preparedStatement.close();				
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 
		return result;
	}
	
	public int removeDefaultProfileId(final String userProfileId, final DBTransaction transaction) {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> removeDefaultProfileId(" + userProfileId  + ") start...");	
		Connection connection = null;
		int result = -1;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "UPDATE " + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS SET DEFAULTUSERPROFILEID=? WHERE USERPROFILEID=?";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(2, userProfileId);
				preparedStatement.setString(1, null);
				result = preparedStatement.executeUpdate();				
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> removeDefaultProfileId(): UPDATE RESULT = " + result);
				preparedStatement.close();				
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 
		return result;
	}
	
	public int removeAllDefaultProfileId(final String defaultProfileId, final DBTransaction transaction) {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> removeAllDefaultProfileId(" + defaultProfileId  + ") start...");	
		Connection connection = null;
		int result = -1;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "UPDATE " + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS SET DEFAULTUSERPROFILEID=? WHERE DEFAULTUSERPROFILEID=?";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(2, defaultProfileId);
				preparedStatement.setString(1, null);
				result = preparedStatement.executeUpdate();				
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> removeAllDefaultProfileId(): UPDATE RESULT = " + result);
				preparedStatement.close();				
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 
		return result;
	}
	
	public int setDefaultProfileId(final String personalUserProfileId, final String defaultUserProfileId, final DBTransaction transaction) {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> setDefaultProfileId(" + personalUserProfileId  + "," + defaultUserProfileId + ") start...");	
		Connection connection = null;
		int result = -1;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "UPDATE " + DBResources._SCHEMANAME + "USERPROFILEPERSONALPARAMETERS SET DEFAULTUSERPROFILEID=? WHERE USERPROFILEID=?";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(2, personalUserProfileId);
				preparedStatement.setString(1, defaultUserProfileId);
				result = preparedStatement.executeUpdate();				
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> setDefaultProfileId(): UPDATE RESULT = " + result);
				preparedStatement.close();				
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 
		return result;
	}
	
	public int removeAllUserRoleAssociations(final String userUID, final DBTransaction transaction) {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> removeAllUserAssociations(" + userUID + ") start...");	
		Connection connection = null;
		int result = -1;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "DELETE FROM " + DBResources._SCHEMANAME + "USERPROFILEROLE WHERE USERUID=?";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, userUID);
				result = preparedStatement.executeUpdate();				
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> removeAllUserAssociations(): UPDATE RESULT = " + result);
				preparedStatement.close();				
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 
		return result;
	}
	
	public int removeAllUserInvitationAssociations(final String userUID, final DBTransaction transaction) {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> removeAllUserInvitationAssociations(" + userUID + ") start...");	
		Connection connection = null;
		int result = -1;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "DELETE FROM " + DBResources._SCHEMANAME + "USERPROFILEINVITATION WHERE USERUID=?";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, userUID);
				result = preparedStatement.executeUpdate();				
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> removeAllUserInvitationAssociations(): UPDATE RESULT = " + result);
				preparedStatement.close();				
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 
		return result;
	}
	

	
	public int removeAllProfileAssociations(final String userProfileId, final DBTransaction transaction) {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> removeAllProfileAssociations(" + userProfileId + ") start...");	
		Connection connection = null;
		int result = -1;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "DELETE FROM " + DBResources._SCHEMANAME + "USERPROFILEROLE WHERE USERPROFILEID=?";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, userProfileId);
				result = preparedStatement.executeUpdate();				
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> removeAllProfileAssociations(): UPDATE RESULT = " + result);
				preparedStatement.close();				
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 
		return result;
	}
	
	public int removeAllUserProfileXCRoleByIds(final String userProfileXCRoleIds, final DBTransaction transaction) {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> removeAllUserProfileXCRoleByIds(" + userProfileXCRoleIds + ") start...");	
		Connection connection = null;
		int result = -1;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String[] ids = userProfileXCRoleIds.split(",");
				String query = "DELETE FROM " + DBResources._SCHEMANAME + "USERPROFILEXCROLE WHERE USERPROFILEXCROLEID IN ";
				query += "(";
				for (int i = 0; i < ids.length; i++) {
					if (i > 0) {
						query += ",";
					}
					query += "?";
				}
				query += ")";
				
				int col = 1;
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				for (int i = 0; i < ids.length; i++) {						
					preparedStatement.setString(col++, ids[i]);
		        }						
				result = preparedStatement.executeUpdate();				
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> removeAllUserProfileXCRoleByIds(): UPDATE RESULT = " + result);
				preparedStatement.close();				
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 
		return result;
	}
	
	public int removeAllUserProfileXCRoleAssociationsForUser(final String userProfileId, final String userUID, final DBTransaction transaction) {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> removeAllUserProfileXCRoleAssociationsForUser(" + userProfileId + "," + userUID + ") start...");	
		Connection connection = null;
		int result = -1;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "DELETE FROM " + DBResources._SCHEMANAME + "USERPROFILEXCROLE WHERE USERPROFILEID=? AND USERUID=?";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, userProfileId);
				preparedStatement.setString(2, userUID);
				result = preparedStatement.executeUpdate();				
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> removeAllUserProfileXCRoleAssociationsForUser(): UPDATE RESULT = " + result);
				preparedStatement.close();				
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 
		return result;
	}
	
	public int removeAllUserProfileXCRoleAssociations(final String userProfileId, final DBTransaction transaction) {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> removeAllUserProfileXCRoleAssociations(" + userProfileId + ") start...");	
		Connection connection = null;
		int result = -1;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "DELETE FROM " + DBResources._SCHEMANAME + "USERPROFILEXCROLE WHERE USERPROFILEID=?";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, userProfileId);
				result = preparedStatement.executeUpdate();				
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> removeAllUserProfileXCRoleAssociations(): UPDATE RESULT = " + result);
				preparedStatement.close();				
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 
		return result;
	}
	
	public int removeAllInvitationsForProfile(final String userProfileId, final DBTransaction transaction) {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> removeAllInvitationsForProfile(" + userProfileId + ") start...");	
		Connection connection = null;
		int result = -1;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "DELETE FROM " + DBResources._SCHEMANAME + "USERPROFILEINVITATION WHERE USERPROFILEID=?";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, userProfileId);
				result = preparedStatement.executeUpdate();				
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> removeAllInvitationsForProfile(): UPDATE RESULT = " + result);
				preparedStatement.close();				
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 
		return result;
	}
	
	public UserProfile loadUserProfileByTypeIdentifierAndName(final int type, final String identifier, final String name, final DBTransaction transaction) {
		UserProfile userProfile = null;
		Connection connection = null;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "SELECT";
				query += " " + DBResources._SCHEMANAME + "USERPROFILE.USERPROFILEID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.USERUID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.IDENTIFIER";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.NAMES";				
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.STATUS";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.DEACTIVATIONREASON";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.EIK";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.NAMEANDLEGALFORM";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.QUALITYOFPHYSICALPERSON";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.METHODOFREPRESENTATION";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.PROFILETYPE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.PROFILESTRUCTURETYPE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.DATECREATED";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.DATEMODIFIED";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.GROUPID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.SAMLRESPONSE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.CUSTOMSIDENAV";					
				query += " FROM " + DBResources._SCHEMANAME + "USERPROFILE";
				query += " WHERE ";				
				if (MySpaceConstants.AUTHORIZATIONS_AUTHORIZED_TYPE_PERSON == type) {
					query += DBResources._SCHEMANAME + "USERPROFILE.PROFILETYPE = '" + MySpaceConstants.USER_PROFILE_TYPE_PERSONAL + "'";
					query += " AND ";
					query += DBResources._SCHEMANAME + "USERPROFILE.IDENTIFIER = ?";
					query += " AND ";
					query += "UPPER(" + DBResources._SCHEMANAME + "USERPROFILE.NAMES) = ?";
				} else {
					query += DBResources._SCHEMANAME + "USERPROFILE.PROFILETYPE <> '" + MySpaceConstants.USER_PROFILE_TYPE_PERSONAL + "'";
					query += " AND ";
					query += DBResources._SCHEMANAME + "USERPROFILE.EIK = ?";
					query += " AND ";
					query += "UPPER(" + DBResources._SCHEMANAME + "USERPROFILE.NAMEANDLEGALFORM) = ?";
				}
				Logger.log(Logger.DEBUG_LEVEL, "query=" + query);
				
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, identifier);
				preparedStatement.setString(2, name.toUpperCase());
				
				
				ResultSet rs = preparedStatement.executeQuery();
				UserProfileMapper mapper = new UserProfileMapper();
				while (rs.next()) { 
					userProfile = mapper.getUserProfile(rs);
					break;
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		}
		return userProfile;
	}
	
	
	public UserProfile loadUserProfileByTypeIdentifierOrName(final int type, final String identifier, final String name, final DBTransaction transaction) {
		UserProfile userProfile = null;
		Connection connection = null;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "SELECT";
				query += " " + DBResources._SCHEMANAME + "USERPROFILE.USERPROFILEID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.USERUID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.IDENTIFIER";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.NAMES";				
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.STATUS";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.DEACTIVATIONREASON";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.EIK";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.NAMEANDLEGALFORM";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.QUALITYOFPHYSICALPERSON";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.METHODOFREPRESENTATION";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.PROFILETYPE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.PROFILESTRUCTURETYPE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.DATECREATED";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.DATEMODIFIED";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.GROUPID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.SAMLRESPONSE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILE.CUSTOMSIDENAV";					
				query += " FROM " + DBResources._SCHEMANAME + "USERPROFILE";
				query += " WHERE ";				
				if (MySpaceConstants.AUTHORIZATIONS_AUTHORIZED_TYPE_PERSON == type) {
					query += DBResources._SCHEMANAME + "USERPROFILE.PROFILETYPE = '" + MySpaceConstants.USER_PROFILE_TYPE_PERSONAL + "'";
					query += " AND (";
					query += DBResources._SCHEMANAME + "USERPROFILE.IDENTIFIER = ?";
					query += " OR ";
					query += "UPPER(" + DBResources._SCHEMANAME + "USERPROFILE.NAMES) = ?)";
				} else {
					query += DBResources._SCHEMANAME + "USERPROFILE.PROFILETYPE <> '" + MySpaceConstants.USER_PROFILE_TYPE_PERSONAL + "'";
					query += " AND (";
					query += DBResources._SCHEMANAME + "USERPROFILE.EIK = ?";
					query += " OR ";
					query += "UPPER(" + DBResources._SCHEMANAME + "USERPROFILE.NAMEANDLEGALFORM) = ?)";
				}
				Logger.log(Logger.DEBUG_LEVEL, "query=" + query);
				
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, identifier);
				preparedStatement.setString(2, name.toUpperCase());
					
				
				ResultSet rs = preparedStatement.executeQuery();
				UserProfileMapper mapper = new UserProfileMapper();
				while (rs.next()) { 
					userProfile = mapper.getUserProfile(rs);
					break;
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		}
		return userProfile;
	}
	
	public String createETranslationRequestFile(
			final String requestId,
			final String sourceLanguage, 
			final String targetLanguage,
			final byte[] document,
			final long documentSize,
			final String documentName,
			final String documentContentType,			 
			final String userProfileId,			 
			final long currentTime, 
			final DBTransaction transaction
			) {
		String id = null;
		Connection connection = null;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO " + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
				id = Sequence.getNextVal("SEQ_ETRANSLATIONREQUEST", connection);
				// ETRANSLATIONREQUESTID
				preparedStatement.setString(1, id);
				// REQUESTID
				preparedStatement.setString(2, requestId);
				// TRANSLATION
				preparedStatement.setString(3, null); 
				preparedStatement.setString(4, sourceLanguage); 
				preparedStatement.setString(5, targetLanguage); 
				preparedStatement.setString(6, documentName); 
				preparedStatement.setString(7, documentContentType);
				// ORIGINALDOCUMENT
				preparedStatement.setBinaryStream(8, new ByteArrayInputStream(document), document.length);
				// ORIGINALDOCUMENTSIZE
				preparedStatement.setInt(9, document.length);
				// TRANSLATEDDOCUMENT
				preparedStatement.setNull(10, java.sql.Types.BLOB);
				// TRANSLATEDDOCUMENTSIZE
				preparedStatement.setString(11, null);
				// ERRORCODE
				preparedStatement.setString(12, null);
				// ERRORMESSAGE
				preparedStatement.setString(13, null);				
				preparedStatement.setString(14, userProfileId);
				// Date created.
				preparedStatement.setString(15, MySpaceUtils.timeMillisToTimestamp(currentTime));
				// Response time.
				preparedStatement.setString(16, null);
//				System.out.println("id=" + id);
//				System.out.println("requestId=" + requestId);
//				System.out.println("sourceLanguage=" + sourceLanguage);
//				System.out.println("targetLanguage" + targetLanguage);
//				System.out.println("documentName=" + documentName);
//				System.out.println("documentContentType=" + documentContentType);
//				System.out.println("document.length=" + document.length);
//				System.out.println("userProfileId=" + userProfileId);
//				System.out.println("creationDate=" + MySpaceUtils.timeMillisToTimestamp(currentTime));
				preparedStatement.executeUpdate();
				preparedStatement.close();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 
		return id;
	}
	
	public int updateETranslationRequestFile(
			final String requestId, 
			final byte[] translatedDocument, 
			final String targetLanguage, 
			final String currentTime, 
			final DBTransaction transaction
			) {
		int update = -1;
		Connection connection = null;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				PreparedStatement preparedStatement = connection.prepareStatement("UPDATE " + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST SET TRANSLATEDDOCUMENT = ?, TRANSLATEDDOCUMENTSIZE = ?, TARGETLANGUAGE = ?, RESPONSETIME = ? WHERE REQUESTID = ?");
				preparedStatement.setBinaryStream(1, new ByteArrayInputStream(translatedDocument), translatedDocument.length);
				preparedStatement.setInt(2, translatedDocument.length);
				preparedStatement.setString(3, targetLanguage); 
				preparedStatement.setString(4, currentTime);
				preparedStatement.setString(5, requestId); 
				update = preparedStatement.executeUpdate();
				preparedStatement.close();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 
		return update;
	}
	
	public List<ETranslationRequest> findETranslationRequestsNoBLOB(final String requestId, final String userProfileId, final boolean isDocument, final DBTransaction transaction) {
		ETranslationRequest translationRequest = null;
		List<ETranslationRequest> translationRequests = new ArrayList<ETranslationRequest>();
		Connection connection = null;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "SELECT";
				query += " " + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.ETRANSLATIONREQUESTID";
				query += "," + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.REQUESTID";
				query += "," + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.TRANSLATION";
				query += "," + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.SOURCELANGUAGE";
				query += "," + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.TARGETLANGUAGE";
				query += "," + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.DOCUMENTNAME";
				query += "," + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.DOCUMENTCONTENTTYPE";
				query += "," + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.ORIGINALDOCUMENTSIZE";
				query += "," + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.TRANSLATEDDOCUMENTSIZE";
				query += "," + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.ERRORCODE";
				query += "," + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.ERRORMESSAGE";
				query += "," + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.USERPROFILEID";
				query += "," + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.CREATIONDATE";
				query += "," + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.RESPONSETIME";
				query += " FROM " + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST";
				query += " WHERE ";
				if (isDocument) {
					query += " DOCUMENTNAME IS NOT NULL AND ";
				}
				if (requestId != null) {
					query += DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.REQUESTID = ?";
				} else {
					if (userProfileId == null) {
						query += DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.USERPROFILEID IS NULL";
					} else {
						query += DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.USERPROFILEID = ?";
					}
					query += " ORDER BY " + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.CREATIONDATE" + " DESC";
				}
				Logger.log(Logger.DEBUG_LEVEL, "query=" + query);
				
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				if (requestId != null || userProfileId != null) {
					preparedStatement.setString(1, requestId != null ? requestId : userProfileId);
				}
				ResultSet rs = preparedStatement.executeQuery();
				while (rs.next()) { 
					translationRequest = new ETranslationRequest();
					translationRequest.setId(rs.getString(1));
					translationRequest.setRequestId(rs.getString(2));
					translationRequest.setTranslation(rs.getString(3));
					translationRequest.setSourceLanguage(rs.getString(4));
					translationRequest.setTargetLanguage(rs.getString(5));
					translationRequest.setDocumentName(rs.getString(6));
					translationRequest.setDocumentContentType(rs.getString(7));
					translationRequest.setOriginalDocumentSize(rs.getString(8));
					translationRequest.setTranslatedDocumentSize(rs.getString(9));
					translationRequest.setErrorCode(rs.getString(10));
					translationRequest.setErrorMessage(rs.getString(11));
					translationRequest.setUserProfileId(rs.getString(12));
					translationRequest.setCreationDate(rs.getString(13));
					translationRequest.setResponseTime(rs.getString(14));
					translationRequests.add(translationRequest);					
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		}
		return translationRequests != null && translationRequests.size() > 0 ? translationRequests : null;
	}
	
	public ETranslationRequest findETranslationRequestFile(final long eTranslationRequestId, final int type, final DBTransaction transaction) {
		ETranslationRequest translationRequest = null;
		Connection connection = null;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "SELECT";
				query += " " + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.ETRANSLATIONREQUESTID";				
				query += "," + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.TARGETLANGUAGE";
				query += "," + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.DOCUMENTNAME";
				query += "," + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.DOCUMENTCONTENTTYPE";
				query += "," + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.ORIGINALDOCUMENTSIZE";
				query += "," + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.TRANSLATEDDOCUMENTSIZE";
				if (MySpaceConstants.ETRANSLATION_REQUEST_ORIGINAL_FILE == type) {
					query += "," + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.ORIGINALDOCUMENT";
				} else {
					query += "," + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.TRANSLATEDDOCUMENT";
				}
				query += " FROM " + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST";
				query += " WHERE ";
				query += DBResources._SCHEMANAME + "ETRANSLATIONREQUEST.ETRANSLATIONREQUESTID = ?";
				Logger.log(Logger.DEBUG_LEVEL, "query=" + query);
				
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setLong(1, eTranslationRequestId);
				ResultSet rs = preparedStatement.executeQuery();
				while (rs.next()) { 
					Blob blob = rs.getBlob(MySpaceConstants.ETRANSLATION_REQUEST_ORIGINAL_FILE == type ? "ORIGINALDOCUMENT" : "TRANSLATEDDOCUMENT");
					if (blob != null) {
						InputStream inputStream = null;
						translationRequest = new ETranslationRequest();
						try {
							inputStream = blob.getBinaryStream(); 
						    ByteBuffer bbuffer = new ByteBuffer();
							int bytesread = 0;
							byte[] tmparr = new byte[1024];
							while (-1 != (bytesread = inputStream.read(tmparr, 0, 1024))) {
								bbuffer.append(tmparr, bytesread);
							}
							if (MySpaceConstants.ETRANSLATION_REQUEST_ORIGINAL_FILE == type) {
								translationRequest.setOriginalDocument(bbuffer.getBytes());
								translationRequest.setOriginalDocumentSize(rs.getString("ORIGINALDOCUMENTSIZE"));	
							} else {
								translationRequest.setTranslatedDocument(bbuffer.getBytes());
								translationRequest.setTranslatedDocumentSize(rs.getString("TRANSLATEDDOCUMENTSIZE"));
							}
							inputStream.close();
						} catch (Exception e) {
							try {
								if (inputStream != null) {
									inputStream.close();
								}
							} catch (Exception e2) {}
							e.printStackTrace();				
						}
						translationRequest.setId(eTranslationRequestId + "");
						translationRequest.setTargetLanguage(rs.getString("TARGETLANGUAGE"));
						translationRequest.setDocumentName(rs.getString("DOCUMENTNAME"));
						translationRequest.setDocumentContentType(rs.getString("DOCUMENTCONTENTTYPE"));
					    break;
					}					
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		}
		return translationRequest;
	}
	
	public int clearExpiredETranslationRequests(
			final String time, 
			final DBTransaction transaction
			) {
		int update = -1;
		Connection connection = null;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM " + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST WHERE CREATIONDATE < ?");
				preparedStatement.setString(1, time);
				update = preparedStatement.executeUpdate();
				preparedStatement.close();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 
		return update;
	}
	
	public int deleteETranslationRequest(
			final String eTranslationRequestId, 
			final DBTransaction transaction
			) {
		int update = -1;
		Connection connection = null;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM " + DBResources._SCHEMANAME + "ETRANSLATIONREQUEST WHERE ETRANSLATIONREQUESTID = ?");
				preparedStatement.setString(1, eTranslationRequestId);
				update = preparedStatement.executeUpdate();
				preparedStatement.close();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 
		return update;
	}
	
	public String addProfileIdentifierLog(
			final String userProfileId,
			final String identifier,
			final String identifierCountryCode,
			final String identifierType,
			final int operationType,
			final InputStream document,		 	
			final String documentName,
			final long documentSize,
			final String documentContentType,			 
			final String rnu,			 
			final long currentTime, 
			final DBTransaction transaction
			) {
		String id = null;
		Connection connection = null;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO " + DBResources._SCHEMANAME + "USERPROFILEIDENTIFIERLOG VALUES (?,?,?,?,?,?,?,?,?,?,?,?)");
				id = Sequence.getNextVal("SEQ_USERPROFILEIDENTIFIERLOG", connection);
				// USERPROFILEIDENTIFIERLOGID
				preparedStatement.setString(1, id);
				// USERPROFILEID
				preparedStatement.setString(2, userProfileId);
				// IDENTIFIER
				preparedStatement.setString(3, identifier); 
				preparedStatement.setString(4, identifierCountryCode); 
				preparedStatement.setString(5, identifierType); 
				preparedStatement.setInt(6, operationType); 
				
				// DOCUMENT
				preparedStatement.setBinaryStream(7, document, (int)documentSize);
				preparedStatement.setString(8, documentName);
				preparedStatement.setInt(9, (int)documentSize);
				preparedStatement.setString(10, documentContentType);								
				// RNU
				preparedStatement.setString(11, rnu);
				// DATECREATED.
				preparedStatement.setString(12, MySpaceUtils.timeMillisToTimestamp(currentTime));
				preparedStatement.executeUpdate();
				preparedStatement.close();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 
		return id;
	}

	
	///////////////////////////////////////////////////////////////////
	//////////////////// -----  MARIA DB  ----- ///////////////////////
	///////////////////////////////////////////////////////////////////
	
	public List<Authorizations> getAllAuthorizationsByUserIdentifier(final String userIdentifier) {
		Connection connection = null;
		List<Authorizations> authorizations = null;
		try {
			connection = getMariaDBConnection();
			if (connection != null) {
				String query = "select";
				query += " authorizationsId";
				query += ",rnu";
				query += ",rnuCancel";
				query += ",userId";
				query += ",userIdentifier";
				query += ",userType";
				query += ",userNames";
				query += ",authorizedType";
				query += ",authorizedIdentifierType";
				query += ",authorizedIdentifier";
				query += ",authorizedNames";
				query += ",validFrom";
				query += ",validTo";
				query += ",systems";
				query += ",status";
				query += ",authorizedDocumentName";
				query += ",cancelDocumentName";
				query += ",cancelUserId";
				query += ",cancelUserNames";
				query += ",cancelReason";
				query += ",creationTime";
				query += ",cancelTime";
				query += ",operationTime";
				query += " from Authorizations";
				query += " where";
				query += " userIdentifier = ?";
				query += " or authorizedIdentifier = ?";
				Logger.log(Logger.DEBUG_LEVEL, "query=" + query + " [" + userIdentifier + "]");
				
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, userIdentifier);
				preparedStatement.setString(2, userIdentifier);
				
				ResultSet resultSet = preparedStatement.executeQuery();
				authorizations = new ArrayList<Authorizations>();
				AuthorizationsMapper mapper = new AuthorizationsMapper();
				while (resultSet.next()) { 
					Logger.log(Logger.DEBUG_LEVEL, "getAllAuthorizationsByUserIdentifier -> has authorizations");
					authorizations.add(mapper.getAuthorization(resultSet));
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {}
		}
		return authorizations != null && authorizations.size() > 0 ? authorizations : null;
	}
	
	public Authorizations getAuthorizationById(final Long authorizationsId) {
		Connection connection = null;
		Authorizations authorization = null;
		try {
			connection = getMariaDBConnection();
			if (connection != null) {
				String query = "select";
				query += " authorizationsId";
				query += ",rnu";
				query += ",rnuCancel";
				query += ",userId";
				query += ",userIdentifier";
				query += ",userType";
				query += ",userNames";
				query += ",authorizedType";
				query += ",authorizedIdentifierType";
				query += ",authorizedIdentifier";
				query += ",authorizedNames";
				query += ",validFrom";
				query += ",validTo";
				query += ",systems";
				query += ",status";
				query += ",authorizedDocumentName";
				query += ",cancelDocumentName";
				query += ",cancelUserId";
				query += ",cancelUserNames";
				query += ",cancelReason";
				query += ",creationTime";
				query += ",cancelTime";
				query += ",operationTime";
				query += " from Authorizations";
				query += " where";
				query += " authorizationsId = ?";
				Logger.log(Logger.DEBUG_LEVEL, "query=" + query + " [" + authorizationsId + "]");
				
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setLong(1, authorizationsId);
				
				ResultSet resultSet = preparedStatement.executeQuery();
				AuthorizationsMapper mapper = null;
				while (resultSet.next()) { 
					Logger.log(Logger.DEBUG_LEVEL, "getAuthorizationById -> has authorization");					
					mapper = new AuthorizationsMapper();
					authorization = mapper.getAuthorization(resultSet); 
					break;
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {}
		}
		return authorization;
	}
	
	public List<Systems> getAllSystems() {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution -> getAllSystems()");
		Connection connection = null;
		List<Systems> systems = null;
		try {
			connection = getMariaDBConnection();
			if (connection != null) {
				String query = "select";
				query += " systemsId";
				query += ",title";
				query += ",oid";
				query += ",operationTime";
				query += ",userId";
				query += " from Systems";
				query += " where 1=1 order by title asc";				
				Logger.log(Logger.DEBUG_LEVEL, "query=" + query);
				
				PreparedStatement preparedStatement = connection.prepareStatement(query);				
				ResultSet resultSet = preparedStatement.executeQuery();
				systems = new ArrayList<Systems>();
				SystemsMapper mapper = new SystemsMapper();
				while (resultSet.next()) { 										
					systems.add(mapper.getSystem(resultSet));
				}
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution -> getAllSystems: has systems [" + systems.size() + "]");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {}
		}
		return systems != null && systems.size() > 0 ? systems : null;
	}
	
	public List<Systems> getAllSystemsByIds(final List<Long> systemIds) {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution -> getAllSystemsByIds(" + systemIds + ")");
		Connection connection = null;
		List<Systems> systems = null;
		try {
			connection = getMariaDBConnection();
			if (connection != null) {
				String query = "select";
				query += " systemsId";
				query += ",title";
				query += ",oid";
				query += ",operationTime";
				query += ",userId";
				query += " from Systems";
				query += " where";
				query += " systemsId in (%s)";
				query += " order by title asc";
				Logger.log(Logger.DEBUG_LEVEL, "query=" + query);
				
				String inSql = String.join(",", Collections.nCopies(systemIds.size(), "?"));				
				PreparedStatement preparedStatement = connection.prepareStatement(String.format(query, inSql));
				for (int i = 1; i < systemIds.size() + 1; i++) {
					preparedStatement.setLong(i, systemIds.get(i - 1));
		        }				
				
				ResultSet resultSet = preparedStatement.executeQuery();
				systems = new ArrayList<Systems>();
				SystemsMapper mapper = new SystemsMapper();
				while (resultSet.next()) { 										
					systems.add(mapper.getSystem(resultSet));
				}
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution -> getAllSystemsByIds: has systems [" + systems.size() + "]");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {}
		}
		return systems != null && systems.size() > 0 ? systems : null;
	}
	
	public List<Actions> getAllActions() {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution -> getAllActions()");
		Connection connection = null;
		List<Actions> actions = null;
		try {
			connection = getMariaDBConnection();
			if (connection != null) {
				String query = "select";
				query += " actionsId";
				query += ",systemsId";
				query += ",code";
				query += ",description";
				query += ",operationTime";
				query += ",userId";
				query += " from Actions";
				query += " where 1=1 order by systemsId, description asc";
				Logger.log(Logger.DEBUG_LEVEL, "query=" + query);
				
				PreparedStatement preparedStatement = connection.prepareStatement(query);

				ResultSet resultSet = preparedStatement.executeQuery();
				ActionsMapper mapper = new ActionsMapper();
				actions = new ArrayList<Actions>();
				while (resultSet.next()) { 
					actions.add(mapper.getAction(resultSet));
				}
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution -> getAllActions: has actions [" + actions.size() + "]");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {}
		}
		return actions != null && actions.size() > 0 ? actions : null;
	}
	
	public List<Actions> getAllActionsByIds(final List<Long> actionsIds) {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution -> getAllActionsByIds(" + actionsIds + ")");
		Connection connection = null;
		List<Actions> actions = null;
		try {
			connection = getMariaDBConnection();
			if (connection != null) {
				String query = "select";
				query += " actionsId";
				query += ",systemsId";
				query += ",code";
				query += ",description";
				query += ",operationTime";
				query += ",userId";
				query += " from Actions";
				query += " where";
				query += " actionsId in (%s)";
				query += " order by description asc";
				Logger.log(Logger.DEBUG_LEVEL, "query=" + query);
				
				String inSql = String.join(",", Collections.nCopies(actionsIds.size(), "?"));				
				PreparedStatement preparedStatement = connection.prepareStatement(String.format(query, inSql));
				for (int i = 1; i < actionsIds.size() + 1; i++) {
					preparedStatement.setLong(i, actionsIds.get(i - 1));
		        }	
				
				ResultSet resultSet = preparedStatement.executeQuery();
				ActionsMapper mapper = new ActionsMapper();
				actions = new ArrayList<Actions>();
				while (resultSet.next()) { 
					actions.add(mapper.getAction(resultSet));
				}
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution -> getAllActionsByIds: has actions [" + actions.size() + "]");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {}
		}
		return actions != null && actions.size() > 0 ? actions : null;
	}
	
	public int createAuthorization(
			final String rnu, 
			final String userId, 
			final String userIdentifier, 
			final int userType, 
			final String userNames, 
			final int authorizedType, 
			final int authorizedIdentifierType, 
			final String authorizedIdentifier, 
			final String authorizedNames, 
			final String validFrom, 
			final String validTo, 
			final String systems, 
			final InputStream authorizedDocument, 
			final String authorizedDocumentName, 
			final long authorizedDocumentSize, 
			final String authorizedDocumentContentType, 			
			final int status,
			final Date date) {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> createAuthorization() start...");
		Connection connection = null;		
		int result = -1;
		try {
			connection = getMariaDBConnection();
			if (connection != null) {
				PreparedStatement preparedStatement = connection.prepareStatement("insert into Authorizations ("
						+ "rnu, "
						+ "userId, "
						+ "userIdentifier,"
						+ "userType,"
						+ "userNames,"
						+ "authorizedType,"
						+ "authorizedIdentifierType,"
						+ "authorizedIdentifier,"
						+ "authorizedNames,"
						+ "validFrom,"
						+ "validTo,"
						+ "systems,"
						+ "authorizedDocument,"
						+ "authorizedDocumentName,"
						+ "authorizedDocumentSize,"
						+ "authorizedDocumentContentType,"
						+ "status,"
						+ "creationTime,"						
						+ "operationTime"
						+ ") values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);
				preparedStatement.setString(1, rnu); 
				preparedStatement.setString(2, userId); 
				preparedStatement.setString(3, userIdentifier); 
				preparedStatement.setInt(4, userType);
				preparedStatement.setString(5, userNames);
				preparedStatement.setInt(6, authorizedType);
				preparedStatement.setInt(7, authorizedIdentifierType);
				preparedStatement.setString(8, authorizedIdentifier);
				preparedStatement.setString(9, authorizedNames);
				preparedStatement.setString(10, validFrom);
				preparedStatement.setString(11, validTo);
				preparedStatement.setString(12, systems);
				preparedStatement.setBinaryStream(13, authorizedDocument, (int)authorizedDocumentSize); 				
				preparedStatement.setString(14, authorizedDocumentName);
				if (authorizedDocumentSize > 0) {
					preparedStatement.setInt(15, (int)authorizedDocumentSize);
				} else {
					preparedStatement.setString(15, null);
				}
				preparedStatement.setString(16, authorizedDocumentContentType);				
				// Status.
				preparedStatement.setInt(17, status);
				// Creation time.
				preparedStatement.setTimestamp(18, new java.sql.Timestamp(date.getTime()));
				// Operation time.
				preparedStatement.setTimestamp(19, new java.sql.Timestamp(date.getTime()));
				result = preparedStatement.executeUpdate();
				ResultSet rs = preparedStatement.getGeneratedKeys();
				if (rs.next()) {
					result = rs.getInt(1);
				}
				preparedStatement.close();
			}
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, e.getMessage());			
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {}
		} 
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> createAuthorization(): " + result);
		return result;
	}
	
	public int cancelAuthorization(
			final Long authorizationsId,
			final String rnuCancel,
			final String userId, 
			final String userNames, 
			final InputStream cancelDocument, 
			final String cancelDocumentName, 
			final long cancelDocumentSize, 
			final String cancelDocumentContentType, 			
			final int status,
			Date date) {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> cancelAuthorization() start...");
		Connection connection = null;
		int result = -1;
		try {
			connection = getMariaDBConnection();
			if (connection != null) {
				PreparedStatement preparedStatement = connection.prepareStatement("update Authorizations set "
						+ "rnuCancel = ?, "
						+ "cancelDocument = ?, "
						+ "cancelDocumentName = ?, "
						+ "cancelDocumentSize = ?, "
						+ "cancelDocumentContentType = ?, "						
						+ "cancelUserId = ?,"
						+ "cancelUserNames = ?,"
						+ "status = ?, "
						+ "cancelTime = ?,"						
						+ "operationTime = ? "
						+ "where authorizationsId = ?", Statement.RETURN_GENERATED_KEYS);
				preparedStatement.setString(1, rnuCancel); 				
				preparedStatement.setBinaryStream(2, cancelDocument, (int)cancelDocumentSize); 				
				preparedStatement.setString(3, cancelDocumentName);
				if (cancelDocumentSize > 0) {
					preparedStatement.setInt(4, (int)cancelDocumentSize);
				} else {
					preparedStatement.setString(4, null);
				}
				preparedStatement.setString(5, cancelDocumentContentType);							
				preparedStatement.setString(6, userId); 
				preparedStatement.setString(7, userNames);
				preparedStatement.setInt(8, status);
				// Cancel time.
				preparedStatement.setTimestamp(9, new java.sql.Timestamp(date.getTime()));
				// Operation time.
				preparedStatement.setTimestamp(10, new java.sql.Timestamp(date.getTime()));
				preparedStatement.setLong(11, authorizationsId);
				
				result = preparedStatement.executeUpdate();
				preparedStatement.close();
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {}
		} 
		return result;
	}
	
	public Authorizations getAuthorizationAuthorizedFile(final Long authorizationsId) {
		Authorizations authorization = null;	
		Connection connection = null;
		try { 
			connection = getMariaDBConnection();
			if (connection != null) {
				PreparedStatement preparedStatement = connection.prepareStatement("select authorizedDocument,authorizedDocumentName,authorizedDocumentSize,authorizedDocumentContentType from Authorizations where authorizationsId=?");
				preparedStatement.setLong(1, authorizationsId);
				ResultSet resultSet = preparedStatement.executeQuery(); 
				while (resultSet.next()) { 
					Blob blob = resultSet.getBlob("authorizedDocument");
					if (blob != null) {
						InputStream inputStream = null;
						authorization = new Authorizations();
						try {
							inputStream = blob.getBinaryStream(); 
						    ByteBuffer bbuffer = new ByteBuffer();
							int bytesread = 0;
							byte[] tmparr = new byte[1024];
							while (-1 != (bytesread = inputStream.read(tmparr, 0, 1024))) {
								bbuffer.append(tmparr, bytesread);
							}
							authorization.setAuthorizedDocument(bbuffer.getBytes());
							inputStream.close();
						} catch (Exception e) {
							try {
								if (inputStream != null) {
									inputStream.close();
								}
							} catch (Exception e2) {}
							e.printStackTrace();				
						}
						authorization.setAuthorizedDocumentName(resultSet.getString("authorizedDocumentName"));
					    authorization.setAuthorizedDocumentSize(resultSet.getInt("authorizedDocumentSize"));
					    authorization.setAuthorizedDocumentContentType(resultSet.getString("authorizedDocumentContentType"));
					    authorization.setAuthorizationsId(authorizationsId);
					    break;
					}					
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {}
		}
		return authorization;
	}
	
	public Authorizations getAuthorizationCancelFile(final Long authorizationsId) {
		Authorizations authorization = null;	
		Connection connection = null;
		try { 
			connection = getMariaDBConnection();
			if (connection != null) {
				PreparedStatement preparedStatement = connection.prepareStatement("select cancelDocument,cancelDocumentName,cancelDocumentSize,cancelDocumentContentType from Authorizations where authorizationsId=?");
				preparedStatement.setLong(1, authorizationsId);
				ResultSet resultSet = preparedStatement.executeQuery(); 
				while (resultSet.next()) { 
					Blob blob = resultSet.getBlob("cancelDocument");
					if (blob != null) {
						InputStream inputStream = null;
						authorization = new Authorizations();
						try {
							inputStream = blob.getBinaryStream(); 
						    ByteBuffer bbuffer = new ByteBuffer();
							int bytesread = 0;
							byte[] tmparr = new byte[1024];
							while (-1 != (bytesread = inputStream.read(tmparr, 0, 1024))) {
								bbuffer.append(tmparr, bytesread);
							}
							authorization.setCancelDocument(bbuffer.getBytes());
							inputStream.close();
						} catch (Exception e) {
							try {
								if (inputStream != null) {
									inputStream.close();
								}
							} catch (Exception e2) {}
							e.printStackTrace();				
						}
						authorization.setCancelDocumentName(resultSet.getString("cancelDocumentName"));
					    authorization.setCancelDocumentSize(resultSet.getInt("cancelDocumentSize"));
					    authorization.setCancelDocumentContentType(resultSet.getString("cancelDocumentContentType"));
					    authorization.setAuthorizationsId(authorizationsId);
					    break;
					}					
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {}
		}
		return authorization;
	}
	
	public boolean hasDuplicateAuthorization(final String userIdentifier, final String authorizedIdentifier, final String validFrom, final String validTo, final int status, final String actionsIds) {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution -> hasDuplicateAuthorization(" + userIdentifier + "," + userIdentifier + "," + validFrom + "," + validTo + "," + status + ",[" + actionsIds + "])");
		Connection connection = null; 
		boolean hasDuplicate = false;
		try {
			String[] actionIdsArr = actionsIds.split(",");
			connection = getMariaDBConnection();
			if (connection != null) {
				String query = "select";
				query += " authorizationsId";
				query += ",rnu";
				query += ",rnuCancel";
				query += ",userId";
				query += ",userIdentifier";
				query += ",userType";
				query += ",userNames";
				query += ",authorizedType";
				query += ",authorizedIdentifierType";
				query += ",authorizedIdentifier";
				query += ",authorizedNames";
				query += ",validFrom";
				query += ",validTo";
				query += ",systems";
				query += ",status";
				query += ",authorizedDocumentName";
				query += ",cancelDocumentName";
				query += ",cancelUserId";
				query += ",cancelUserNames";
				query += ",cancelReason";
				query += ",creationTime";
				query += ",cancelTime";
				query += ",operationTime";
				query += " from Authorizations";
				query += " where ";
				query += "userIdentifier = ? ";
				query += "and ";
				query += "authorizedIdentifier = ? ";
				query += "and (";
				// Inside.
				query += "(validFrom >= ? and validTo <= ?)"; // from, to
				// Outside.
				query += " or ";
				query += "(validFrom <= ? and validTo >= ?)"; // from, to
				// Overlap from.
				query += " or ";
				query += "(validFrom <= ? and validTo >= ?)"; // from, from
				// Overlap to.
				query += " or ";
				query += "(validFrom <= ? and validTo >= ?)"; // to, to
				
				query += ")";
				query += "and ";
				query += "status = ? ";
				query += "and (";
				for (int i = 0; i < actionIdsArr.length; i++) {
					if (i > 0) {
						query += " or ";
					}
					query += "systems like ? ";
				};
				query += ")";
				Logger.log(Logger.DEBUG_LEVEL, "query=" + query);
				
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, userIdentifier);
				preparedStatement.setString(2, authorizedIdentifier);
				// Inside.
				preparedStatement.setString(3, validFrom);
				preparedStatement.setString(4, validTo);
				// Outside.
				preparedStatement.setString(5, validFrom);
				preparedStatement.setString(6, validTo);
				// Overlap from.
				preparedStatement.setString(7, validFrom);
				preparedStatement.setString(8, validFrom);
				// Overlap to.
				preparedStatement.setString(9, validTo);
				preparedStatement.setString(10, validTo);
				preparedStatement.setInt(11, status);
				
				// actions.
				for (int i = 0,j=12; i < actionIdsArr.length; i++,j++) {
					preparedStatement.setString(j, "%:" + actionIdsArr[i] + "^%");
				};
				
				ResultSet resultSet = preparedStatement.executeQuery();
				Authorizations authorization = null;
				AuthorizationsMapper mapper = new AuthorizationsMapper();
				while (resultSet.next()) {
					authorization = mapper.getAuthorization(resultSet);
					hasDuplicate = true;
					break;
				}
				if (hasDuplicate) {
					Logger.log(Logger.DEBUG_LEVEL, "QueryExecution -> hasDuplicateAuthorization: duplicate id [" + (authorization != null ? authorization.getAuthorizationsId() + "," + authorization.getValidFrom().toString() + "," + authorization.getValidTo().toString() : "null")  + "]");
				}
			}
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "QueryExecution -> hasDuplicateAuthorization(): " + e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (connection != null) {
					connection.close();
				}
			} catch (SQLException e) {}
		}
		return hasDuplicate;
	}

		
}
