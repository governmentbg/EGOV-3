package com.ibs.myspace.portlet.management;

import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.portlet.ActionRequest;
import javax.portlet.PortletMode;
import javax.portlet.PortletURL;
import javax.portlet.RenderResponse;
import javax.portlet.WindowState;
import javax.servlet.http.HttpServletRequest;

import com.egov.wcm.cache.EgovWCMCache;
import com.egov.wcm.cache.model.EgovRegisterGroup;
import com.egov.wcm.cache.model.EgovRegisterGroupParameter;
import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.MySpacePortlet;
import com.ibs.myspace.portlet.MySpacePortletSessionBean;
import com.ibs.myspace.portlet.bean.Container;
import com.ibs.myspace.portlet.bean.Message;
import com.ibs.myspace.portlet.bean.ProfileParametersContainer;
import com.ibs.myspace.portlet.bean.UserProfileBean;
import com.ibs.myspace.portlet.db.DBTransaction;
import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.dbo.UserProfile;
import com.ibs.myspace.portlet.dbo.UserProfileParameters;
import com.ibs.myspace.portlet.dbo.UserProfilePersonalParameters;
import com.ibs.myspace.portlet.utils.Logger;
import com.ibs.myspace.portlet.utils.MySpaceUtils;

public class UserProfileParametersManagement {
	
	public HashMap<String, ProfileParametersContainer> initializeSessionBean (MySpacePortletSessionBean sessionBean) {
		Logger.log(Logger.DEBUG_LEVEL, "UserProfileParametersManagement -> initializeSessionBean()");
		ProfileParametersContainer parametersContainer = new ProfileParametersContainer();
		UserProfileParameters[] userProfileParameters = loadAllProfileParametersByUserProfileId(sessionBean.getProfile().getId());
		parametersContainer.setUserProfileParameters(userProfileParameters);
		Map<Long, UserProfileParameters> parametersByIdHm = new HashMap<Long, UserProfileParameters>();
		if (userProfileParameters != null && userProfileParameters.length > 0) {
			for (int i = 0; i < userProfileParameters.length; i++) {
				parametersByIdHm.put(userProfileParameters[i].getParameterId(), userProfileParameters[i]);
			}
			Logger.log(Logger.DEBUG_LEVEL, "UserProfileParametersManagement -> initializeSessionBean(): userProfileParameters.length=" + userProfileParameters.length);
		} else {
			Logger.log(Logger.DEBUG_LEVEL, "UserProfileParametersManagement -> initializeSessionBean(): userProfileParameters.length=null");
		}
		parametersContainer.setParametersByParameterIdHm(parametersByIdHm);
		parametersContainer.setInitInitalized(true);
		HashMap<String, ProfileParametersContainer> containerHm = sessionBean.getProfileParametersContainer();
		containerHm.put(sessionBean.getProfile().getProfileType(), parametersContainer);
		return containerHm; 
	}
	
	public void updateSessionBean (MySpacePortletSessionBean sessionBean) {
		Logger.log(Logger.DEBUG_LEVEL, "UserProfileParametersManagement -> updateSessionBean()");
		ProfileParametersContainer parametersContainer = sessionBean.getProfileParametersContainer().get(sessionBean.getProfile().getProfileType());
		UserProfileParameters[] userProfileParameters = loadAllProfileParametersByUserProfileId(sessionBean.getProfile().getId());
		parametersContainer.setUserProfileParameters(userProfileParameters);
		Map<Long, UserProfileParameters> parametersByIdHm = new HashMap<Long, UserProfileParameters>();
		if (userProfileParameters != null && userProfileParameters.length > 0) {
			for (int i = 0; i < userProfileParameters.length; i++) {
				parametersByIdHm.put(userProfileParameters[i].getParameterId(), userProfileParameters[i]);
			}
			Logger.log(Logger.DEBUG_LEVEL, "UserProfileParametersManagement -> updateSessionBean(): userProfileParameters.length=" + userProfileParameters.length);
		} else {
			Logger.log(Logger.DEBUG_LEVEL, "UserProfileParametersManagement -> updateSessionBean(): userProfileParameters.length=null");
		}
		parametersContainer.setParametersByParameterIdHm(parametersByIdHm);
		sessionBean.getProfileParametersContainer().put(sessionBean.getProfile().getProfileType(), parametersContainer);
	}
	
	public boolean checkForNotPopulatedRequiredFields(MySpacePortletSessionBean sessionBean, RenderResponse renderResponse, ResourceBundle bundle) {
		Logger.log(Logger.DEBUG_LEVEL, "UserProfileParametersManagement -> checkForNotPopulatedRequiredFields()");
		UserProfile profile = sessionBean.getProfile();
		if (profile != null) {
			// Check "email" is populated as it is a required field!
			if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equalsIgnoreCase(profile.getProfileType())) {
				UserProfilePersonalParameters personalParameters = profile.getPersonalParameters();
				if (personalParameters != null && (personalParameters.getEmail() == null || personalParameters.getEmail().trim().length() == 0)) {
					sessionBean.setHasNotPopulatedRequiredEmail(true);
					List<Message> messages = sessionBean.getMessages();
					Message message = new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, bundle.getString("profile.missing.required.email.field"));
					message.setHtml(true);
					messages.add(message);																					
					sessionBean.setMessages(messages);
					//Initialize session container.
					Map<String, Container> sessionContainer = sessionBean.getContainer();
					sessionBean.setCurrentPage(MySpacePortlet.PROFILE_PAGE);
					Container container = sessionContainer.get(sessionBean.getCurrentPage());
					if (container == null) {
						container = new Container();
					}
					sessionContainer.put(sessionBean.getCurrentPage(), container);
					return true;
				}
			}
			// Check parameters.
			ProfileParametersContainer parametersContainer = sessionBean.getProfileParametersContainer().get(profile.getProfileType());
			List<EgovRegisterGroup> allRegisterGroups = EgovWCMCache.getRegisterGroupsByProfileTypeId().get(Integer.parseInt(profile.getProfileType()));
			if (allRegisterGroups != null && allRegisterGroups.size() > 0) {
				EgovRegisterGroup group = null;
				List<EgovRegisterGroupParameter> templateParameters = null;
				EgovRegisterGroupParameter templateParameter = null;
				UserProfileParameters currentParameter = null;
				MySpaceUtils utils = new MySpaceUtils();
				for (int i = 0; i < allRegisterGroups.size(); i++) {
					group = allRegisterGroups.get(i);
					if (group != null && MySpaceConstants.STATUS_ACTIVE == group.getStatus()) {
						
						if (!utils.checkProfileHasGroupProfileStructureType(profile, group)) {
							Logger.log(Logger.DEBUG_LEVEL, "UserProfileParametersManagement -> utils.checkProfileHasGroupProfileStructureType() is FALSE, continue");
							continue;
						}
						
						templateParameters = group.getRegisterGroupParameters();
						if (templateParameters != null && templateParameters.size() > 0) {
							for (int j = 0; j < templateParameters.size(); j++) {
								templateParameter = templateParameters.get(j);
								if (MySpaceConstants.STATUS_ACTIVE == templateParameter.getStatus() && MySpaceConstants.VALUE_YES == templateParameter.getRequired()) {
									currentParameter = parametersContainer.getParametersByParameterIdHm().get(templateParameter.getRegisterGroupParameterId());
									if (currentParameter == null || currentParameter.getParameterValue() == null || currentParameter.getParameterValue().trim().length() == 0) {
										Logger.log(Logger.DEBUG_LEVEL, "UserProfileParametersManagement -> checkForNotPopulatedRequiredFields(), found:" + group.getLabel() + "," + templateParameter.getLabel());
										sessionBean.setHasNotPopulatedRequiredParameters(true);
										List<Message> messages = sessionBean.getMessages();
										/*
										if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equalsIgnoreCase(profile.getProfileType())) {
											messages.add(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, MessageFormat.format(bundle.getString("profile.parameters.my.space.populate.required.fields"), group.getLabel())));
										} else {
											messages.add(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, MessageFormat.format(bundle.getString("profile.parameters.my.space.le.populate.required.fields"), group.getLabel())));
										}
										*/
										PortletURL actionUrl = null;
										if (renderResponse != null) {											
											try {
												actionUrl = renderResponse.createActionURL();
												actionUrl.setWindowState(WindowState.NORMAL);
												actionUrl.setPortletMode(PortletMode.VIEW);
												actionUrl.setParameter(MySpacePortlet.PARAMETER_ACTION, MySpacePortlet.ACTION_CHANGE_PAGE);
												actionUrl.setParameter(MySpacePortlet.PARAMETER_VALUE, MySpacePortlet.PROFILE_PARAMETERS_PAGE);
											} catch (Exception e) {											
												e.printStackTrace();
											}
											Message message = new Message(MySpaceConstants.MESSAGE_TYPE_WARNING, bundle.getString("profile.parameters.my.space.generic.message.required.fields") + (actionUrl != null ? " <a href=\"" + actionUrl + "\" style=\"text-decoration:underline\">тук.</a>" : "."));
											message.setHtml(true);
											messages.add(message);																					
											sessionBean.setMessages(messages);
										}										
										//sessionBean.setPersistMessage(true);
										parametersContainer.setCurrentRegisterGroupName(group.getName());
										Map<String, ProfileParametersContainer> sessionParametersContainer = sessionBean.getProfileParametersContainer();
										sessionParametersContainer.put(sessionBean.getProfile().getProfileType(), parametersContainer);
										//sessionBean.setCurrentPage(MySpacePortlet.PROFILE_PARAMETERS_PAGE);
										
										//Initialize session container.
										Map<String, Container> sessionContainer = sessionBean.getContainer();		
										Container container = sessionContainer.get(sessionBean.getCurrentPage());
										container = sessionContainer.get(MySpacePortlet.PROFILE_PARAMETERS_PAGE);
										if (container == null) {
											container = new Container();
										}
										sessionContainer.put(sessionBean.getCurrentPage(), container);
										return true;
									}
								}
							}
						}
					}
				}
			}
		} 
		sessionBean.setHasNotPopulatedRequiredParameters(false);
		//sessionBean.setPersistMessage(false);
		return false;
	}
	
	@SuppressWarnings("unused")
	private String getRequiredFieldsForMessage(List<EgovRegisterGroupParameter> templateParameters, ProfileParametersContainer templateParametersContainer) {
		String requiredParameters = "";
		if (templateParameters != null && templateParameters.size() > 0) {
			EgovRegisterGroupParameter templateParameter = null;
			UserProfileParameters currentParameter = null;
			for (int j = 0; j < templateParameters.size(); j++) {
				templateParameter = templateParameters.get(j);
				if (MySpaceConstants.STATUS_ACTIVE == templateParameter.getStatus() && MySpaceConstants.VALUE_YES == templateParameter.getRequired()) {
					currentParameter = templateParametersContainer.getParametersByParameterIdHm().get(templateParameter.getRegisterGroupParameterId());
					if (currentParameter == null || currentParameter.getParameterValue() == null || currentParameter.getParameterValue().trim().length() == 0) {
						//if (requiredParameters.length() > 0) {
							requiredParameters += "<br/>";
						//}
						requiredParameters += "&nbps;&bull&nbps;" + templateParameter.getLabel();
					}
				}
			}
		}
		return requiredParameters;
	}
	
	public UserProfileParameters[] loadAllProfileParametersByUserProfileId(String userProfileId) {
		try {
			return UserProfileParameters.findAllByUserProfileId(userProfileId, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public UserProfileParameters[] loadAllProfileParameterssByUserUID(String userUID) {
		try {
			return UserProfileParameters.findAllByUserUID(userUID, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	/**
	* Save profile parameters form. 
	* 
	* @param sessionBean			Portlet session bean.
	* @param userProfileBean		User profile session bean.
	* @param request				Action request.
	* @param httpServletRequest		HTTP Servlet Request.
	* @param remoteIP				Remote IP address.
	* @param bundle					resource bundle.
	* @throws Exception          	If exception occurs. 
	*
	*/
	public String saveProfileParameters(MySpacePortletSessionBean sessionBean, UserProfileBean userProfileBean, ActionRequest request, HttpServletRequest httpServletRequest, String remoteIP, ResourceBundle bundle) throws Exception {		
		DBTransaction transaction = null;
		String currentGroup = request.getParameter("pageName");
		Logger.log(Logger.DEBUG_LEVEL, "saveProfileParameters() -> currentGroup = " + currentGroup);
		Date currentTime = new Date();		
		try {
			
			UserProfile profile = sessionBean.getProfile();
			EgovRegisterGroup group = null;
			if (currentGroup != null) {
				List<EgovRegisterGroup> allRegisterGroups = EgovWCMCache.getRegisterGroupsByProfileTypeId().get(Integer.parseInt(profile.getProfileType()));
				if (allRegisterGroups != null && allRegisterGroups.size() > 0) {
					for (int i = 0; i < allRegisterGroups.size(); i++) {
						if (currentGroup.equalsIgnoreCase(allRegisterGroups.get(i).getName())) {
							group = allRegisterGroups.get(i);
							break;
						}
					}
				}
				if (group != null && group.getRegisterGroupParameters() != null && group.getRegisterGroupParameters().size() > 0) {
					transaction = new DBTransaction();
					EgovRegisterGroupParameter parameter = null;
					List<EgovRegisterGroupParameter> templateParameters = group.getRegisterGroupParameters();
					String ids = "";
					for (int i = 0; i < templateParameters.size(); i++) {
						parameter = templateParameters.get(i);
						if (ids.length() > 0) {
							ids += ",";
						}
						ids += parameter.getRegisterGroupParameterId();
					}
					// Load all parameters for this profile type and group.					
					UserProfileParameters[] currentParameters = null;
					UserProfileParameters currentParameter = null;
					String value = null;
					int consent = -1;
					try {
						currentParameters = UserProfileParameters.findAllByUserProfileIdAndParametersIds(profile.getId(), ids, transaction);
					} catch (FinderException e) {}
					
					// Process parameters one by one.					
					for (int i = 0; i < templateParameters.size(); i++) {
						parameter = templateParameters.get(i);
						currentParameter = parameterExists(parameter.getRegisterGroupParameterId(), currentParameters);
						value = getParameterValueFromRequest(parameter, request);
						// If parameter has no value populated, skip it (or delete it if exists)
						if (value == null) {
							if (currentParameter != null) {
								// Delete old value from DB.
								currentParameter.remove(transaction);
							}
							continue;
						}
						consent = getConsentFromRequest(parameter, request);
						// Add parameter to DB.
						if (currentParameter == null) {
							currentParameter = new UserProfileParameters();
							currentParameter.setUserProfileId(Long.parseLong(sessionBean.getProfile().getId()));
							currentParameter.setParameterId(parameter.getRegisterGroupParameterId());
							currentParameter.setParameterValue(value);
							currentParameter.setConsent(consent);
							currentParameter.setOperationTime(currentTime);
							currentParameter.setUserUID(userProfileBean.getCurrentUserUID());
							currentParameter.create(transaction);
						} else { // Update parameter if it has a new value.
							if (!value.equalsIgnoreCase(currentParameter.getParameterValue()) || consent != currentParameter.getConsent()) {
								currentParameter.setParameterValue(value);
								currentParameter.setConsent(consent);
								currentParameter.setOperationTime(currentTime);
								currentParameter.setUserUID(userProfileBean.getCurrentUserUID());
								currentParameter.store(transaction);
							}
						}
					}
				}
			}
			transaction.commit();
			
			// Update session data.
			updateSessionBean(sessionBean);	
			
			if (MySpacePortlet.logEvents) {
				// Register event in the log.
				AuditLogManagement alManagement = new AuditLogManagement();
				String profileName = MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equalsIgnoreCase(sessionBean.getProfile().getProfileType()) ? sessionBean.getProfile().getNames() : sessionBean.getProfile().getNameAndLegalForm();
				alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_EDIT_PROFILE_PARAMETERS, "Редактиране на параметри от група \"" + group.getLabel() + "\" за профил \"" + profileName + "\"", null, remoteIP, false);
			}		
			
			return group.getLabel();
		} catch (Exception e) {
			System.out.println("UserProfileParametersManagement : saveProfileParameters : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("UserProfileParametersManagement : saveProfileParameters : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			throw new Exception(bundle.getString("profile.parameters.save.error"));
		}
	}
	
	private UserProfileParameters parameterExists(Long parameterId, UserProfileParameters[] currentParameters) {
		if (parameterId == null || currentParameters == null || currentParameters.length == 0) {
			return null;
		}
		for (int i = 0; i < currentParameters.length; i++) {
			if (currentParameters[i].getParameterId() == parameterId) {
				return currentParameters[i];
			}
		}
		return null;
	}
	
	private String getParameterValueFromRequest(EgovRegisterGroupParameter templateParameter, ActionRequest request) {
		if (templateParameter == null) {
			return null;
		}
		if (MySpaceConstants.PARAMETER_TYPE_TEXT == templateParameter.getParameterType() || 
				MySpaceConstants.PARAMETER_TYPE_TEXT_AREA == templateParameter.getParameterType() ||
				MySpaceConstants.PARAMETER_TYPE_NUMBER == templateParameter.getParameterType()) {
			String parameter = request.getParameter(templateParameter.getRegisterGroupParameterId() + "");
			return (parameter != null && parameter.trim().length() > 0) ? parameter.trim() : null;
		} else if (MySpaceConstants.PARAMETER_TYPE_LIST_SINGLE == templateParameter.getParameterType()) {
			String[] templateValues = templateParameter.getParameterValue().replaceAll("\\r", "").split("\n");
			String parameter = request.getParameter(templateParameter.getRegisterGroupParameterId() + "");
			if (templateValues != null && templateValues.length > 0 && parameter != null && parameter.trim().length() > 0) {
				for (int i = 0; i < templateValues.length; i++) {
					if (parameter.equalsIgnoreCase(i + "")) {
						return templateValues[i].trim();
					}
				}
			}
		} else if (MySpaceConstants.PARAMETER_TYPE_LIST_MULTIPLE == templateParameter.getParameterType()) {
			String[] templateValues = templateParameter.getParameterValue().replaceAll("\\r", "").split("\n");
			String list = "";
			String paramValue = null;
			if (templateValues != null && templateValues.length > 0) {
				for (int i = 0; i < templateValues.length; i++) {
					paramValue = request.getParameter(templateParameter.getRegisterGroupParameterId() + "_" + i);
					if (paramValue != null && paramValue.trim().length() > 0) {
						if (list.length() > 0) {
							list += "\n";
						}
						list += templateValues[i].trim();
					}
				}
				if (list.length() > 0) {
					return list;
				}
			}			
		} 
		return null; 
	}
	
	private int getConsentFromRequest(EgovRegisterGroupParameter templateParameter, ActionRequest request) {
		if (templateParameter == null) {
			return MySpaceConstants.VALUE_NO;
		}
		if (MySpaceConstants.VALUE_YES == templateParameter.getConsent()) {
			String consent = request.getParameter("consent" + templateParameter.getRegisterGroupParameterId());
			if (consent != null && consent.equalsIgnoreCase(MySpaceConstants.VALUE_YES + "")) {
				return MySpaceConstants.VALUE_YES;
			}
		} 
		return MySpaceConstants.VALUE_NO;
	}
	
	
	
	public boolean renderRegisterGroup (EgovRegisterGroup group) {
		if (group == null || MySpaceConstants.STATUS_INACTIVE == group.getStatus() || group.getRegisterGroupParameters() == null || group.getRegisterGroupParameters().size() == 0) {
			return false;
		}
		for (int i = 0; i < group.getRegisterGroupParameters().size(); i++) {
			if (MySpaceConstants.STATUS_ACTIVE == group.getRegisterGroupParameters().get(i).getStatus()) {
				return true;
			}
		}
		return false;
	}

}
