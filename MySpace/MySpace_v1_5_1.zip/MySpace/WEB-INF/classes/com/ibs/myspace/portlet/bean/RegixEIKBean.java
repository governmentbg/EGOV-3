package com.ibs.myspace.portlet.bean;

/**
 * Class to store regix eik data.
 * @deprecated
 * This class is no longer acceptable as it was designed to work with ESB to maintain Regix response.
 * The Regix call was redeveloped to be done directly, not through ESB.
 * <p> Use {@link com.ibs.myspace.portlet.bean.ValidUICResponse} instead.
 *
 */
@Deprecated
public class RegixEIKBean {
	String uic = null;
	String company = null;
	String legalFormAbbr = null;
	String legalFormName = null;
	String status = null;
	
	public String getUic() {
		return uic;
	}
	
	public void setUic(String uic) {
		this.uic = uic;
	}
	
	public String getCompany() {
		return company;
	}
	
	public void setCompany(String company) {
		this.company = company;
	}
	
	public String getLegalFormAbbr() {
		return legalFormAbbr;
	}
	
	public void setLegalFormAbbr(String legalFormAbbr) {
		this.legalFormAbbr = legalFormAbbr;
	}
	
	public String getLegalFormName() {
		return legalFormName;
	}
	
	public void setLegalFormName(String legalFormName) {
		this.legalFormName = legalFormName;
	}
	
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
}
