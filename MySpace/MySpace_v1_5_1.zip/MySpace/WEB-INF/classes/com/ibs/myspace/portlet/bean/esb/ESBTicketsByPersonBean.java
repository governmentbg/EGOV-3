package com.ibs.myspace.portlet.bean.esb;

public class ESBTicketsByPersonBean {
	private String documentType = null;
	private String documentSeries = null;
	private String documentNumber = null;
	private String initialAmount = null;
	private String paymentAmount = null;
	private String breachDate = null;
	private String documentIdentifier = null;
	
	public String getDocumentType() {
		return documentType;
	}
	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
	public String getDocumentSeries() {
		return documentSeries;
	}
	public void setDocumentSeries(String documentSeries) {
		this.documentSeries = documentSeries;
	}
	public String getDocumentNumber() {
		return documentNumber;
	}
	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}
	public String getInitialAmount() {
		return initialAmount;
	}
	public void setInitialAmount(String initialAmount) {
		this.initialAmount = initialAmount;
	}
	public String getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	public String getBreachDate() {
		return breachDate;
	}
	public void setBreachDate(String breachDate) {
		this.breachDate = breachDate;
	}
	public String getDocumentIdentifier() {
		return documentIdentifier;
	}
	public void setDocumentIdentifier(String documentIdentifier) {
		this.documentIdentifier = documentIdentifier;
	}

	
}
