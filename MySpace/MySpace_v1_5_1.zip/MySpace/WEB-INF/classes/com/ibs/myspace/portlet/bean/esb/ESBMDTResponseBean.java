package com.ibs.myspace.portlet.bean.esb;

import java.util.List;

public class ESBMDTResponseBean {
	private boolean initialized = false;
	private boolean error = false;
	private List<ESBMDTBean> mdts = null; 	 
	private List<String> failed = null;
	
	public boolean isInitialized() {
		return initialized;
	}
	public void setInitialized(boolean initialized) {
		this.initialized = initialized;
	}
	public boolean isError() {
		return error;
	}
	public void setError(boolean error) {
		this.error = error;
	}
	public List<ESBMDTBean> getMdts() {
		return mdts;
	}
	public void setMdts(List<ESBMDTBean> mdts) {
		this.mdts = mdts;
	}
	public List<String> getFailed() {
		return failed;
	}
	public void setFailed(List<String> failed) {
		this.failed = failed;
	} 	 
	
}
