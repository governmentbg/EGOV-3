package com.ibs.myspace.portlet.bean.esb;

import java.util.List;

public class ESBEPaymentResponseBean {
	private List<ESBEPaymentBean> payments = null;	
	private int count = 0;
	
	public List<ESBEPaymentBean> getPayments() {
		return payments;
	}
	public void setPayments(List<ESBEPaymentBean> payments) {
		this.payments = payments;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}	
	
}
