package com.ibs.myspace.portlet.bean.esb;

import java.util.List;

public class ESBEDeliveryResponseBean {
	private long messageId = 0;	 
	private List<ESBEDeliveryBean> messages = null;	
	private String messageType = null;
	private int count = 0;
	
	public long getMessageId() {
		return messageId;
	}
	public void setMessageId(long messageId) {
		this.messageId = messageId;
	}
	public List<ESBEDeliveryBean> getMessages() {
		return messages;
	}
	public void setMessages(List<ESBEDeliveryBean> messages) {
		this.messages = messages;
	}
	public String getMessageType() {
		return messageType;
	}
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}	
	
}
