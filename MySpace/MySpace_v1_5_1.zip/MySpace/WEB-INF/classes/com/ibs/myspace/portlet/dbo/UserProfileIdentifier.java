package com.ibs.myspace.portlet.dbo;

import java.util.Date;
import java.util.Hashtable;

import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.db.DBTransaction;
import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.db.PersistentObject;
import com.ibs.myspace.portlet.db.QueryComposer;
import com.ibs.myspace.portlet.db.QuerySet;
import com.ibs.myspace.portlet.utils.MySpaceUtils;


public class UserProfileIdentifier extends PersistentObject {

	private static String CLASS_NAME = UserProfileIdentifier.class.getName();
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "USERPROFILEIDENTIFIER";
        sequenceName = "SEQ_USERPROFILEIDENTIFIER";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "USERPROFILEIDENTIFIERID");
        columnMap.put("userProfileId", "USERPROFILEID");
        columnMap.put("identifier", "IDENTIFIER");
        columnMap.put("identifierCountryCode", "IDENTIFIERCOUNTRYCODE");
        columnMap.put("identifierType", "IDENTIFIERTYPE");
        columnMap.put("rnu", "RNU");
        columnMap.put("dateCreated", "DATECREATED");

        querySet = QueryComposer.composeAll(table, sequenceName, columnMap);
    }
	
    public UserProfileIdentifier() {
        super(querySet);
    }
    
    private Long userProfileId = null;       
    private String identifier = null;
    private String identifierCountryCode = null;
    private Integer identifierType = null;
    private String rnu = null;
    private Date dateCreated = null;

	public Long getUserProfileId() {
		return userProfileId;
	}

	public void setUserProfileId(Long userProfileId) {
		this.userProfileId = userProfileId;
	}
	
	public void setUserProfileId(String userProfileId) {
		this.userProfileId = Long.parseLong(userProfileId);
	}
	
	public String getIdentifierCountryCode() {
		return identifierCountryCode;
	}

	public void setIdentifierCountryCode(String identifierCountryCode) {
		this.identifierCountryCode = identifierCountryCode;
	}

	public Integer getIdentifierType() {
		return identifierType;
	}

	public void setIdentifierType(Integer identifierType) {
		this.identifierType = identifierType;
	}
	
	public void setIdentifierType(int identifierType) {
		this.identifierType = identifierType;
	}
	
	public void setIdentifierType(String identifierType) {
		if (identifierType == null) {
			this.identifierType = null;
			return;
		}
		try {
			this.identifierType = Integer.parseInt(identifierType);
		} catch (Exception e) {}
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	
	public String getRnu() {
		return rnu;
	}

	public void setRnu(String rnu) {
		this.rnu = rnu;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	
	public void setDateCreated(String dateCreated) {
		this.dateCreated = new Date(MySpaceUtils.date_TimestampToTimeMillis(dateCreated));
	}
	
	public static UserProfileIdentifier findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileIdentifier) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}
	
	public static UserProfileIdentifier[] findAllByIdentifier(final String identifier, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileIdentifiers(columnMap.get("identifier") + " = '" + identifier + "'", transaction);
	}	
	
	public static UserProfileIdentifier findByIdentifierAndProfileId(final String identifier, final String userProfileId, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileIdentifier) findSingle(columnMap.get("identifier") + " = '" + identifier + "' AND " + columnMap.get("userProfileId") + "=" + userProfileId, CLASS_NAME, transaction);
	}	
	
	public static UserProfileIdentifier findByIdentifierAndProfileIdAndType(final String identifier, final String identifierCC, final String userProfileId, final int identifierType, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileIdentifier) findSingle(columnMap.get("identifier") + " = '" + identifier + "' AND " + columnMap.get("identifierCountryCode") + (identifierCC != null ? " ='" + identifierCC + "'" : " IS NULL") + " AND " + columnMap.get("userProfileId") + "=" + userProfileId + " AND " + columnMap.get("identifierType") + "=" + identifierType, CLASS_NAME, transaction);
	}	
	
	public static UserProfileIdentifier[] findAllByUserProfileId(final String userProfileId, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileIdentifiers(columnMap.get("userProfileId") + "=" + userProfileId + " order by " + columnMap.get("dateCreated") + " asc", transaction);
	}
	
	public static UserProfileIdentifier[] findAllByUserProfileIdExceptPIKNRAAndPIKNOI(final String userProfileId, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileIdentifiers(columnMap.get("userProfileId") + "=" + userProfileId + " AND " + columnMap.get("identifierType") + " NOT IN (" + MySpaceConstants.IDENTIFIER_TYPE_PIK_NRA + "," + MySpaceConstants.IDENTIFIER_TYPE_PIK_NOI + ") order by " + columnMap.get("dateCreated") + " asc", transaction);
	}

	public static void removeAllByUserProfileId(String userProfileId, DBTransaction transaction) throws FinderException, Exception {
		UserProfileIdentifier invitation = new UserProfileIdentifier();
		String cond = columnMap.get("userProfileId") + "=" + userProfileId;
		invitation.removeConditional(cond, transaction);			
	}
	
	public static void removeAllByIdentifier(String identifier, DBTransaction transaction) throws FinderException, Exception {
		UserProfileIdentifier invitation = new UserProfileIdentifier();
		String cond = columnMap.get("identifier") + "='" + identifier + "'";
		invitation.removeConditional(cond, transaction);			
	}

	public static UserProfileIdentifier[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileIdentifiers("1=1", transaction);
	}

	public static UserProfileIdentifier[] findAllUserProfileIdentifiers(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final UserProfileIdentifier[] identifiers = new UserProfileIdentifier[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				identifiers[i] = (UserProfileIdentifier) tmp[i];
			}
			return identifiers;
		} 
		return null;
	}
	
}
