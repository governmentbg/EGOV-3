package com.ibs.myspace.portlet.servlet;

import java.io.IOException;
import java.security.PrivilegedExceptionAction;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import com.ibm.portal.um.PumaController;
import com.ibm.portal.um.PumaEnvironment;
import com.ibm.portal.um.PumaHome;
import com.ibm.portal.um.PumaProfile;
import com.ibm.portal.um.User;
import com.ibm.portal.um.exceptions.PumaException;
import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.dbo.UserProfileMyFavorites;
import com.ibs.myspace.portlet.management.AuditLogManagement;
import com.ibs.myspace.portlet.management.MyFavoriteServicesManagement;
import com.ibs.myspace.portlet.utils.Logger;
import com.ibs.myspace.portlet.utils.MySpaceUtils;

@WebServlet("/my-favorite-services")
public class MyFavoriteServices extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	public static final String OPERATION_ADD = "add";
	public static final String OPERATION_REMOVE = "remove";
	public static final String OPERATION_REMOVE_ALL = "removeAll";
	public static final String OPERATION_GET = "get";
	public static final String OPERATION_CHECK = "check";
	public boolean userLoggedIn = false;
	public boolean debug = false;
	public static com.ibm.portal.um.User currentUser = null;
	private static PumaHome pumaHome = null;	
	public static String currentUserDN = null;
	public static String currentUserUID = null;
	public String operation = null;
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	public static final String LDAP_ATTRIBUTE_UID = "uid";

	
	public void init(ServletConfig config) throws ServletException {
		super.init();
		InitialContext initialcontext;
		try {
			initialcontext = new InitialContext();
			pumaHome = (PumaHome) initialcontext.lookup("portal:service/usermanagement/Puma");
		} catch (NamingException namingexception) {
			namingexception.printStackTrace();
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		debug = "true".equalsIgnoreCase(request.getParameter("debug"));
		
		Logger.log(Logger.DEBUG_LEVEL, "MyFavoriteServices -> doGet() start...");
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");		
		response.setContentType("application/json; charset=UTF-8");
		
		JSONObject json = new JSONObject();
		JSONObject ja = new JSONObject(); 	
		
		userLoggedIn = false;
		if (getPumaHome() != null) {
			PumaProfile pumaProfile = getPumaHome().getProfile();
			if (pumaProfile != null) {
				try {
					com.ibm.portal.um.User user = pumaProfile.getCurrentUser();
					if (user != null) {
						userLoggedIn = true;
						currentUser = user;
						currentUserDN = pumaProfile.getIdentifier(user);
						Object uid = getUserAttribute(user, LDAP_ATTRIBUTE_UID);
						if (uid != null) {
							currentUserUID = "";
							if (uid instanceof ArrayList && ((ArrayList)uid).size() > 0) {
								for (int i = 0; i < ((ArrayList)uid).size(); i++) {
									if (i > 0) {
										currentUserUID += " ";
									}
									currentUserUID = (String)((ArrayList)uid).get(i);
								}
							} else if (uid instanceof String) {
								currentUserUID = (String)uid;
							}									
						}
						System.out.println("userDN = " + currentUserDN);
						System.out.println("userUID = " + currentUserUID);
					}
				} catch (PumaException e) {
					System.out.println(e.getMessage());
					e.printStackTrace();
				}
			}
		}
		
		if (userLoggedIn && currentUserUID != null) {		
			ArrayList<String> myFavoritesInSession = (ArrayList<String>)request.getSession().getAttribute(MySpaceConstants._USER_PROFILE_MY_FAVORITE_SERVICES_SESSION_KEY);
			if (myFavoritesInSession == null) {
				Logger.log(Logger.DEBUG_LEVEL, "MyFavoriteServices -> doGet() NO SessionKey, initialize data from DB...");
				myFavoritesInSession = new ArrayList<String>();
				MyFavoriteServicesManagement management = new MyFavoriteServicesManagement();
				UserProfileMyFavorites[] myFavorites = management.loadAllContentUUIDsByUserUID(currentUserUID);
				if (myFavorites != null && myFavorites.length > 0) {
					for (int i = 0; i < myFavorites.length; i++) {
						myFavoritesInSession.add(myFavorites[i].getContentUUID());
					}
				}
				Logger.log(Logger.DEBUG_LEVEL, "MyFavoriteServices -> doGet() loaded from DB = " + myFavoritesInSession.size());
				request.getSession().setAttribute(MySpaceConstants._USER_PROFILE_MY_FAVORITE_SERVICES_SESSION_KEY, myFavoritesInSession);
			}
			
			String operation = request.getParameter("op");
			String contentUUID = request.getParameter("uuid");
			String remoteIP = request.getHeader("X-FORWARDED-FOR");
			if (remoteIP == null) {
				remoteIP = request.getRemoteAddr();
			}
			Logger.log(Logger.DEBUG_LEVEL, "MyFavoriteServices -> doGet() userLoggedIn, currentUserUID=" + currentUserUID + ", op=" + operation + ", uuid=" + contentUUID);
			int result = 0;
			String message = "Възникна грешка!";
			if (OPERATION_ADD.equalsIgnoreCase(operation)) {
				if (contentUUID != null && contentUUID.trim().length() > 0) {
					if (myFavoritesInSession.contains(contentUUID)) {
						result = 1;
					} else {
						MyFavoriteServicesManagement management = new MyFavoriteServicesManagement();
						result = management.addToMyFavorites(currentUserUID, contentUUID);
						if (result == 1) {
							
							if (request.getSession() != null) {
								// Update session object.
								myFavoritesInSession = new ArrayList<String>();
								UserProfileMyFavorites[] myFavorites = management.loadAllContentUUIDsByUserUID(currentUserUID);
								if (myFavorites != null && myFavorites.length > 0) {
									for (int i = 0; i < myFavorites.length; i++) {
										myFavoritesInSession.add(myFavorites[i].getContentUUID());
									}
								}
								Logger.log(Logger.DEBUG_LEVEL, "MyFavoriteServices -> doGet() loaded from DB = " + myFavoritesInSession.size());
								request.getSession().setAttribute(MySpaceConstants._USER_PROFILE_MY_FAVORITE_SERVICES_SESSION_KEY, myFavoritesInSession);
							}
							
							
							// Register event in the log.
							AuditLogManagement alManagement = new AuditLogManagement();
							alManagement.sendEvent(currentUserUID, MySpaceConstants.EVENT_LOG_PORTAL_ADD_FAVOURITE_SERVICE, contentUUID, null, remoteIP, false);
							
//							if (request.getSession() != null) {
//								if (!myFavoritesInSession.contains(contentUUID)) {
//									myFavoritesInSession.add(contentUUID);
//									// Put in user session.
//									request.getSession().setAttribute(MySpaceConstants._USER_PROFILE_MY_FAVORITE_SERVICES_SESSION_KEY, myFavoritesInSession);
//								}
//								
//							}
						}
					}
				}
			} else if (OPERATION_REMOVE.equalsIgnoreCase(operation)) {
				if (contentUUID != null && contentUUID.trim().length() > 0) {
					MyFavoriteServicesManagement management = new MyFavoriteServicesManagement();
					result = management.removeFromMyFavorites(currentUserUID, contentUUID);
					if (result == 1) {
						// Register event in the log.
						AuditLogManagement alManagement = new AuditLogManagement();
						alManagement.sendEvent(currentUserUID, MySpaceConstants.EVENT_LOG_PORTAL_REMOVE_FAVOURITE_SERVICE, contentUUID, null, remoteIP, false);
						if (request.getSession() != null) {
							if (myFavoritesInSession.contains(contentUUID)) {
								myFavoritesInSession.remove(contentUUID);
								// Put in user session.
								request.getSession().setAttribute(MySpaceConstants._USER_PROFILE_MY_FAVORITE_SERVICES_SESSION_KEY, myFavoritesInSession);
							}
							//if (myFavorites.size() == 0) {
								//request.getSession().removeAttribute(MySpaceConstants._USER_PROFILE_MY_FAVORITE_SERVICES_SESSION_KEY);
							//}
							
						}
					}
				}
			} else if (OPERATION_REMOVE_ALL.equalsIgnoreCase(operation)) {
				MyFavoriteServicesManagement management = new MyFavoriteServicesManagement();
				result = management.removeAllFromMyFavorites(currentUserUID);
				if (result == 1) {
					if (request.getSession() != null) {
						// Put in user session.
						//request.getSession().removeAttribute(MySpaceConstants._USER_PROFILE_MY_FAVORITE_SERVICES_SESSION_KEY);
						request.getSession().setAttribute(MySpaceConstants._USER_PROFILE_MY_FAVORITE_SERVICES_SESSION_KEY, new ArrayList<String>());
					}
				}
			} else if (OPERATION_GET.equalsIgnoreCase(operation)) {
				MyFavoriteServicesManagement management = new MyFavoriteServicesManagement();
				UserProfileMyFavorites[] myFavorites = management.loadAllContentUUIDsByUserUID(currentUserUID);
				if (myFavorites != null && myFavorites.length > 0) {
					if (myFavorites != null && myFavorites.length > 0) {
						Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> myFavorites.length=" + myFavorites.length);
						JSONArray tmpJA = null; 
						JSONArray jarr = new JSONArray(); 
						for (int i = 0; i < myFavorites.length; i++) {
							tmpJA = new JSONArray();
							tmpJA.put(myFavorites[i].getId());
							tmpJA.put(myFavorites[i].getContentUUID());
							tmpJA.put((myFavorites[i].getCreationDate() != null) ? MySpaceUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(myFavorites[i].getCreationDate().getTime()) : "");							
							jarr.put(tmpJA);					
						}	
						json.put("data", jarr);
						String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
						response.getWriter().print(jsonPrettyPrintString);
						response.getWriter().flush();
						response.getWriter().close();	
						return;
					} else {
						Logger.log(Logger.DEBUG_LEVEL, "MyFavoriteServices -> doGet(): myFavorites.length=0");
					}
				}				
			} else if (OPERATION_CHECK.equalsIgnoreCase(operation)) {
				if (contentUUID != null && myFavoritesInSession.contains(contentUUID)) {
					result = 1;
				}						
			}
			if (result == 1) {
				message = "";
			}
			ja.put("result", result);
			ja.put("message", message);			
		} else {
			Logger.log(Logger.DEBUG_LEVEL, "MyFavoriteServices -> doGet() userLoggedIn=false, exiting with error 403!");
			ja.put("result", "403");
			ja.put("message", "Отказан достъп!");
		}
		
		json.put("data", ja);
		String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
		response.getWriter().print(jsonPrettyPrintString);
		response.getWriter().flush();
		response.getWriter().close();	
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Object getUserAttribute(final User user, String attributeName) {
		Logger.log(Logger.DEBUG_LEVEL, "getUserAttribute(com.ibm.portal.um.User, " + attributeName + ")");
		final java.util.List<String> attributesNamesList;
		try {
			final PumaHome pumaHome = getPumaHome();
			final PumaEnvironment env = pumaHome.getEnvironment();
			final PumaProfile pumaProfile = getPumaProfile();
			attributesNamesList = getPumaProfile().getDefinedUserAttributeNames();
			Logger.log(Logger.DEBUG_LEVEL, "getUserAttribute(com.ibm.portal.um.User," + attributeName + ") -> attributesNamesList = " +  + (attributesNamesList != null ? attributesNamesList.size() : 0));
//			if (attributesNamesList != null && attributesNamesList.size() > 0) {
//				for (int i = 0; i < attributesNamesList.size(); i++) {
//					Logger.log(Logger.DEBUG_LEVEL, "getUserAttribute(com.ibm.portal.um.User," + attributeName + ") -> attributesNamesList[" + i + "] = " + attributesNamesList.get(i));
//				}
//			}
//			To use this implementation you need to defined Anonymous User access to Virtual Resource USER_GROUPS!
//			java.util.Map<String, Object> userInfo = (java.util.Map<String, Object>) getPumaProfile().getAttributes((com.ibm.portal.um.Principal) user, attributesNamesList);
			java.util.Map<String, Object> userInfo = (java.util.Map<String, Object>) env.runUnrestricted(new PrivilegedExceptionAction() {
				public Object run() throws Exception {
					return pumaProfile.getAttributes((com.ibm.portal.um.Principal) user, attributesNamesList);
				}
			});
			
			if (userInfo != null) {
				Logger.log(Logger.DEBUG_LEVEL, "getUserAttribute(com.ibm.portal.um.User, " + attributeName + ") -> userInfo.size() = " + userInfo.size());
				return userInfo.get(attributeName);
			}
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "getUserAttribute(com.ibm.portal.um.User, " + attributeName + ") -> Exception: " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public static PumaHome getPumaHome() {
		return pumaHome;
	}

	public static PumaProfile getPumaProfile() {
		return pumaHome.getProfile();
	}

	public static PumaController getPumaController() {
		return pumaHome.getController();
	}
	
}
