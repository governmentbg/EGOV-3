package com.ibs.myspace.portlet.bean;

import org.json.JSONObject;

public class ActualStateResponseV3Manager {
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	private String indent = null;
	private String name = null;
	private String indentType = null;
	private String countryId = null;
	private String countryName = null;
	
	
	public String getIndent() {
		return indent;
	}
	public void setIndent(String indent) {
		this.indent = indent;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIndentType() {
		return indentType;
	}
	public void setIndentType(String indentType) {
		this.indentType = indentType;
	}
	public String getCountryId() {
		return countryId;
	}
	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}
	public JSONObject toJson() {
		JSONObject jo = new JSONObject();
		jo.put("Indent", indent);
		jo.put("Name", name);
		jo.put("IndentType", indentType);
		jo.put("CountryID", countryId);
		jo.put("CountryName", countryName);		
		return jo;
	}
	public String toJsonString() {
		return toJson().toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
	}
	@Override
	public String toString() {
		return "ActualStateResponseV3Manager [indent=" + indent + ", name=" + name + ", indentType=" + indentType + ", countryId="
				+ countryId + ", countryName=" + countryName + "]";
	}
}
