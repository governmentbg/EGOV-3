package com.ibs.myspace.portlet.bean.esb;

public class ESBEPaymentProviderInfoBean {
	private String name = null;	 
	private String bank = null;
	private String bic = null;	
	private String iban = null;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBank() {
		return bank;
	}
	public void setBank(String bank) {
		this.bank = bank;
	}
	public String getBic() {
		return bic;
	}
	public void setBic(String bic) {
		this.bic = bic;
	}
	public String getIban() {
		return iban;
	}
	public void setIban(String iban) {
		this.iban = iban;
	}	
		
	
}
