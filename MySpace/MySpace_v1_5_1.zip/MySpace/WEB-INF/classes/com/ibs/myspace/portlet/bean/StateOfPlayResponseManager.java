package com.ibs.myspace.portlet.bean;

import org.json.JSONArray;
import org.json.JSONObject;

import com.ibs.myspace.portlet.MySpaceConstants;

public class StateOfPlayResponseManager {
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	private String countryCode;
	private String egn;
	private String cyrillicName;	
	private String birthDate;	
	
	public String getCountryCode() {
		return countryCode;
	}

	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}

	public String getEgn() {
		return egn;
	}

	public void setEgn(String egn) {
		this.egn = egn;
	}

	public String getCyrillicName() {
		return cyrillicName;
	}

	public void setCyrillicName(String cyrillicName) {
		this.cyrillicName = cyrillicName;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}
	
	public JSONObject toJson() {
		JSONObject json = new JSONObject();
		JSONArray ja = new JSONArray();
		JSONObject jo = new JSONObject();			
		jo.put("CountryCode", countryCode);
		jo.put("EGN", egn);
		jo.put("CyrillicName", cyrillicName);
		jo.put("BirthDate", birthDate);
		ja.put(jo);
		json.put("total", 1);
		json.put("type", MySpaceConstants.REGIX_SERVICE_TYPE_REGISTER_BULSTAT);
		json.put("managers", ja);
		return json;
	}
	public String toJsonString() {
		return toJson().toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
	}

	@Override
	public String toString() {
		return "StateOfPlayResponseManager [countryCode=" + countryCode + ", egn=" + egn + ", cyrillicName=" + cyrillicName + ", birthDate=" + birthDate + "]";
	}
}
