package com.ibs.myspace.portlet;

import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.servlet.http.HttpServletRequest;

import com.egov.wcm.cache.EgovWCMCache;
import com.egov.wcm.cache.model.EgovRegisterGroup;
import com.ibm.portal.um.PumaHome;
import com.ibm.workplace.wcm.api.Category;
import com.ibm.workplace.wcm.api.Content;
import com.ibs.myspace.communicator.ESBCommunicator;
import com.ibs.myspace.communicator.ESBUtils;
import com.ibs.myspace.communicator.LDAPCommunicator;
import com.ibs.myspace.communicator.PumaCommunicator;
import com.ibs.myspace.communicator.WCMCommunicator;
import com.ibs.myspace.portlet.bean.AuditLogBean;
import com.ibs.myspace.portlet.bean.AuthorizationBean;
import com.ibs.myspace.portlet.bean.Container;
import com.ibs.myspace.portlet.bean.Message;
import com.ibs.myspace.portlet.bean.ProfileIdentifierBean;
import com.ibs.myspace.portlet.bean.ProfileParametersContainer;
import com.ibs.myspace.portlet.bean.SelectedSystemBean;
import com.ibs.myspace.portlet.bean.UserProfileBean;
import com.ibs.myspace.portlet.bean.esb.ESBEDeliveryBean;
import com.ibs.myspace.portlet.bean.esb.ESBEDeliveryResponseBean;
import com.ibs.myspace.portlet.bean.esb.ESBEPaymentResponseBean;
import com.ibs.myspace.portlet.bean.esb.ESBMDTResponseBean;
import com.ibs.myspace.portlet.bean.esb.ESBUserProfileSubscriberBean;
import com.ibs.myspace.portlet.db.Base;
import com.ibs.myspace.portlet.dbo.ETranslationRequest;
import com.ibs.myspace.portlet.dbo.HorizontalSystemRole;
import com.ibs.myspace.portlet.dbo.UserProfile;
import com.ibs.myspace.portlet.dbo.UserProfileIdentifier;
import com.ibs.myspace.portlet.dbo.UserProfileInvitation;
import com.ibs.myspace.portlet.dbo.UserProfileMyFavorites;
import com.ibs.myspace.portlet.dbo.UserProfileRef;
import com.ibs.myspace.portlet.dbo.UserProfileRequest;
import com.ibs.myspace.portlet.dbo.UserProfileRole;
import com.ibs.myspace.portlet.management.AuditLogManagement;
import com.ibs.myspace.portlet.management.AuthorizationsManagement;
import com.ibs.myspace.portlet.management.ETranslationRequestManagement;
import com.ibs.myspace.portlet.management.HorizontalSystemRoleManagement;
import com.ibs.myspace.portlet.management.MyFavoriteServicesManagement;
import com.ibs.myspace.portlet.management.UserProfileManagement;
import com.ibs.myspace.portlet.management.UserProfileParametersManagement;
import com.ibs.myspace.portlet.management.UserProfileXCRoleManagement;
import com.ibs.myspace.portlet.management.WebContentManagement;
import com.ibs.myspace.portlet.model.Actions;
import com.ibs.myspace.portlet.model.Authorizations;
import com.ibs.myspace.portlet.model.Systems;
import com.ibs.myspace.portlet.utils.EncryptorAESGCM;
import com.ibs.myspace.portlet.utils.Logger;
import com.ibs.myspace.portlet.utils.MySpaceUtils;


public class MySpaceViewEngine {
	
	private MySpaceUtils utils = null;
	private ESBCommunicator esbCommunicator = null;
	private PumaCommunicator pumaCommunicator = null;
	private WCMCommunicator wcmCommunicator = null;
	
	public MySpaceViewEngine() {
		utils = new MySpaceUtils();
		esbCommunicator = new ESBCommunicator();
		pumaCommunicator = new PumaCommunicator();
		wcmCommunicator = new WCMCommunicator();
	}
	
	@SuppressWarnings({ "unchecked" })
	public void prepareRenderingData(MySpacePortletSessionBean sessionBean, RenderRequest renderRequest, RenderResponse renderResponse, final PumaHome pumaHome, ResourceBundle bundle) {
		Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> prepareRenderingData() started... [" + sessionBean.getCurrentPage() + "]");

		HttpServletRequest request = (HttpServletRequest) (com.ibm.ws.portletcontainer.portlet.PortletUtils.getHttpServletRequest(renderRequest));		
		Container container = sessionBean.getContainer().get(sessionBean.getCurrentPage());
		UserProfileBean userProfileBean = sessionBean.getUserProfile();
		if (container != null && userProfileBean != null && userProfileBean.getCurrentUser() != null) {		
			Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> prepareRenderingData() has Session Container");
			UserProfile[] profiles = null;
			boolean processInvitation = false;
			boolean newRegistration = false;
//			boolean profileSelectorMode = false;
			// Load Profile, if it is empty.
			if (sessionBean.getProfile() == null) {
				Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> prepareRenderingData() profile is empty, loading from db...[" + userProfileBean.getCurrentUserUID() + "]");
				UserProfileManagement management = new UserProfileManagement();
				UserProfile profile = null;
				if (userProfileBean.getCurrentUserIdentifier() != null && userProfileBean.getCurrentUserIdentifier().trim().length() > 0) {
					Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> prepareRenderingData() 1.QUERY before loadAllProfilesByUserUID()]");
					//profiles = management.loadAllProfilesByUserUID(userProfileBean.getCurrentUserUID());
					profiles = management.loadAllProfilesAndPersonalProfilesByUserUID(userProfileBean.getCurrentUserUID());
					Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> prepareRenderingData() 1.QUERY after loadAllProfilesByUserUID()]");
					if (profiles != null && profiles.length > 0) {
						for (int i = 0; i < profiles.length; i++) {
							if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(profiles[i].getProfileType())) {
								profile = profiles[i];
								// ReLogin after profile was deactivated, so we activate it again.
								if (MySpaceConstants.USER_PROFILE_STATUS_INACTIVE.equals(profile.getStatus())) {
									Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> prepareRenderingData() personal profile is inactive!");
									profile.setStatus(MySpaceConstants.USER_PROFILE_STATUS_ACTIVE);
									profile.setDeactivationReason(null);
									try {
										Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> prepareRenderingData() activating the profile...");
										profile.store();
									} catch (Exception e) {e.printStackTrace();}
									profiles[i].setStatus(MySpaceConstants.USER_PROFILE_STATUS_ACTIVE);
									profiles[i].setDeactivationReason(null);
								}								
								break;								
							}
						}
						Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> prepareRenderingData() total loaded profiles [" + profiles.length + "]");
					}
					if (profile != null) {
						Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> prepareRenderingData() profile loaded!");
						sessionBean.setProfile(profile);
						
						// Check generalTerms are accepted.
						if (profile.getPersonalParameters() != null && MySpaceGeneralTermsReleaseDate.releaseDate != null) {
							if (profile.getPersonalParameters().getGtConfirmedDate() == null 
									|| profile.getPersonalParameters().getGtConfirmedDate().getTime() < MySpaceGeneralTermsReleaseDate.releaseDate.getTime()) {
								// Show generalTerms page, after accept we will reset the profile and cause loading again!
								sessionBean.setCurrentPage(MySpacePortlet.GENERAL_TERMS_PAGE);
								return;
							}
						}
						
						sessionBean.setProfiles(profiles); 
						sessionBean.setHasProfile(true);						
						sessionBean.setPersonalParameters(profile.getPersonalParameters());
						sessionBean.setUserProfileIdPersonal(profile.getId());
						sessionBean.setDefaultUserProfileId(profile.getPersonalParameters() != null ? profile.getPersonalParameters().getDefaultUserProfileId() : null);
						
						// Check for new registrations (this object is populate in SignInEavt portlet when new profile is created).
						if (MySpacePortlet.cacheUtilsObject != null) {																			
							Map<String, String> newProfilesMap = null;
							try {
								newProfilesMap = (Map<String, String>) MySpacePortlet.cacheUtilsObject.get(MySpaceConstants.EGOV_CACHE_UTILS_NEW_PROFILES);												
							} catch (ClassCastException e) {
								MySpacePortlet.cacheUtilsObject.clear();
								e.printStackTrace();
							}
							if (newProfilesMap != null && newProfilesMap.get(profile.getId()) != null) {
								newRegistration = true;
								newProfilesMap.remove(profile.getId());								
								MySpacePortlet.cacheUtilsObject.put(MySpaceConstants.EGOV_CACHE_UTILS_NEW_PROFILES, newProfilesMap);
							}
						}
					} else {
						Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> prepareRenderingData() profile not found, auto create new with type=PERSONAL");
						// IF profile is not created, we do not have data in DB yet, so create it.
						profile = management.autoCreateProfile(userProfileBean);					
						sessionBean.setProfile(profile);
						sessionBean.setUserProfileIdPersonal(profile.getId());
					}
				} else {
					Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> prepareRenderingData() profile not found, create temp profile with type=PERSONAL");
					profile = new UserProfile();
					profile.setProfileType(MySpaceConstants.USER_PROFILE_TYPE_PERSONAL);
					profile.setNames(userProfileBean.getCurrentUserCN());
					sessionBean.setProfile(profile);
				}				
			} 
				
			// Load profiles and requests.
			if (sessionBean.getUserProfileIdPersonal() != null && sessionBean.getUserProfileIdPersonal().trim().length() > 0) {
				UserProfileManagement management = new UserProfileManagement();
				if (!sessionBean.isInitialized()) {
					List<Message> messages = null;
					if (Base.TEST_ENVIRONMENT) {
						// Set default WARNING message to the client for REGIX autoupte service call.
						messages = sessionBean.getMessages();
						if (messages == null) {
							messages = new ArrayList<>();
						}
						messages.add(new Message(MySpaceConstants.MESSAGE_TYPE_WARNING, "Запознат/а съм, че за целите на идентификацията ми като потребител на Единния портал за достъп до електронни административни услуги, данните ми автоматично ще бъдат удостоверени и попълнени от регистрите на държавната администрация."));
						sessionBean.setMessages(messages);
					}
					
					Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> prepareRenderingData() loading requests for profile with id " + sessionBean.getUserProfileIdPersonal());					
					UserProfileRequest[] requests = management.loadAllNotApprovedUserProfileRequestsByUserProfileId(sessionBean.getUserProfileIdPersonal());
					sessionBean.setRequests(requests);
					
					sessionBean.setProfilesParticipation(null);
					List<String> currentProfileIds = new ArrayList<>();
	
					// If we introduce "block" profile mechanism we need to remove the 'if' clause. 
					//if (requests != null && requests.length > 0) {
					if (profiles == null) {
//							profiles = management.loadAllProfilesByUserUID(userProfileBean.getCurrentUserUID());
						profiles = management.loadAllProfilesAndPersonalProfilesByUserUID(userProfileBean.getCurrentUserUID());
					}
					sessionBean.setProfiles(profiles);	
					currentProfileIds = utils.getCurrentProfileIds(profiles);
					//}
					
					UserProfile[] profilesParticipation = null;
					// Load profiles participation through the UserProfileRole table.
					UserProfileRole[] roles = management.loadAllProfileRolesByUserUID(userProfileBean.getCurrentUserUID());
					if (roles != null && roles.length > 0) {
						String userProfileIds = "";
						for (int i = 0; i < roles.length; i++) {
							// Skip current loaded profiles.
							if (!currentProfileIds.contains(roles[i].getUserProfileId())) {
								if (userProfileIds.trim().length() > 0) {
									userProfileIds += ",";
								}
								userProfileIds += roles[i].getUserProfileId(); 
							}
						}
						if (userProfileIds.length() > 0) {
//							UserProfile[] profilesParticipation = management.loadAllProfilesByIdsAndStatus(userProfileIds, MySpaceConstants.USER_PROFILE_STATUS_ACTIVE);
							profilesParticipation = management.loadAllProfilesByIds(userProfileIds);
							if (profilesParticipation != null && profilesParticipation.length > 0) {
								sessionBean.setProfilesParticipation(profilesParticipation);
								// If we have been invited to LE, when we log back we load the personal profile, no matter it is not confirmed.
								// That's why we need to switch to the LE profile.
								System.out.println("sessionBean.getProfile().getStatus()=" + sessionBean.getProfile().getStatus());
								if (MySpaceConstants.USER_PROFILE_STATUS_NOT_CONFIRMED.equals(sessionBean.getProfile().getStatus())) {
									System.out.println("SETING PROFILE=>" + profilesParticipation[0].getId());
									sessionBean.setProfile(profilesParticipation[0]);
								}
//								for (int i = 0; i < profilesParticipation.length; i++) {
//									if (MySpaceConstants.USER_PROFILE_STATUS_ACTIVE.equals(profilesParticipation[i].getStatus())) {
//										countActiveProfiles++;
//									}
//								}
							}
						}
					}
					// Try to load selected 'Default' profile.
					if (sessionBean.getDefaultUserProfileId() != null) {
						boolean defaultProfileLoaded = false;
						if (profiles != null && profiles.length > 0) {
							for (int i = 0; i < profiles.length; i++) {
								if (profiles[i].getId().equals(sessionBean.getDefaultUserProfileId())) {
									sessionBean.setProfile(profiles[i]);
									defaultProfileLoaded = true;
									break;
								}
							}
						}
						if (!defaultProfileLoaded) {
							if (profilesParticipation != null && profilesParticipation.length > 0) {
								for (int i = 0; i < profilesParticipation.length; i++) {
									if (MySpaceConstants.USER_PROFILE_STATUS_ACTIVE.equals(profilesParticipation[i].getStatus())
											&& profilesParticipation[i].getId().equals(sessionBean.getDefaultUserProfileId())) {
										sessionBean.setProfile(profilesParticipation[i]);
										defaultProfileLoaded = true;
										break;
									}
								}
							}
						}
						if (!defaultProfileLoaded) {
							// Looks like the 'Default' profile is NOT active, so remove the reference.
							management.removeDefaultUserProfileId(sessionBean.getPersonalParameters().getUserProfileId());
							sessionBean.setDefaultUserProfileId(null);
						}
					}
//					// Load profiles from eDelivery.
//					EDeliveryManagement eDeliveryManagement = new EDeliveryManagement();
//					EDeliveryProfileBean[] eDeliveryProfileBeans = eDeliveryManagement.loadAllProfiles(userProfileBean.getCurrentUserEGN());
//					if (MySpaceConstants.DS_IDENTIFIER.equals(userProfileBean.getCurrentUserIdentifier())) {
//						eDeliveryProfileBeans = eDeliveryManagement.loadAllProfiles("8812066630");
//					}
//					if (eDeliveryProfileBeans != null && eDeliveryProfileBeans.length > 0) {
//						sessionBean.seteDeliveryProfileBeans(eDeliveryProfileBeans);
//					}
					
					
					// Load unRead messages count in current session.
					sessionBean.setUnReadReceivedMessagesCount(esbCommunicator.getUnReadReceivedMessagesCounter(sessionBean));									
					sessionBean.setInitialized(true);
					
					// Check for invitation.
					if (sessionBean.getUserProfile().getInvitationId() != null && sessionBean.getUserProfile().getInvitationId().trim().length() > 0) {
						UserProfileInvitation invitation = management.loadInvitationById(sessionBean.getUserProfile().getInvitationId());
						if (invitation != null) {							
							boolean founded = false;
							if (profilesParticipation != null && profilesParticipation.length > 0){
								for (int i = 0; i < profilesParticipation.length; i++) {
									if (profilesParticipation[i].getId().equalsIgnoreCase(String.valueOf(invitation.getUserProfileId()))) {
										founded = true;
										if (sessionBean.getProfile() != null 
												&& MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(sessionBean.getProfile().getProfileType())
												&& MySpaceConstants.USER_PROFILE_STATUS_ACTIVE.equals(sessionBean.getProfile().getStatus())) {
											// Show message ONLY for user that has personal profile.
											messages = sessionBean.getMessages();
											if (messages == null) {
												messages = new ArrayList<>();
											}
											messages.add(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, "Вашият профил на ФЛ е успешно асоцииран с профила на " + profilesParticipation[i].getNameAndLegalForm() + "."));
											sessionBean.setMessages(messages);
										}
										// Set active profile to be the invited one for.
										sessionBean.setProfile(profilesParticipation[i]);
										// Remove LDAP key (as we do not need it, anymore)
										pumaCommunicator.removeAttribute(userProfileBean.getCurrentUser(), MySpaceConstants.LDAP_ATTRIBUTE_INVITATION_ID);
										// Clear 'invitationId' from the session. 
										sessionBean.getUserProfile().setInvitationId(null);
										processInvitation = true;
										break;
									}
								}
							}
							if (!founded) {
								if (profiles != null && profiles.length > 0) {
									for (int i = 0; i < profiles.length; i++) {
										if (profiles[i].getId().equalsIgnoreCase(String.valueOf(invitation.getUserProfileId()))) {
											founded = true;
											if (sessionBean.getProfile() != null 
													&& MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(sessionBean.getProfile().getProfileType())
													&& MySpaceConstants.USER_PROFILE_STATUS_ACTIVE.equals(sessionBean.getProfile().getStatus())) {
												// Show message ONLY for user that has personal profile.
												messages = sessionBean.getMessages();
												if (messages == null) {
													messages = new ArrayList<>();
												}
												messages.add(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, "Вашият профил на ФЛ е успешно асоцииран с профила на " + profiles[i].getNameAndLegalForm() + "."));
												sessionBean.setMessages(messages);
											}
											// Set active profile to be the invited one for.
											sessionBean.setProfile(profiles[i]);
											// Remove LDAP key (as we do not need it, anymore)
											pumaCommunicator.removeAttribute(userProfileBean.getCurrentUser(), MySpaceConstants.LDAP_ATTRIBUTE_INVITATION_ID);
											processInvitation = true;
											break;
										}
									}
								}
							}
						}
					} 					
					
					// Check we have active & confirmed profile. 
					// (user could have not confirmed personal profile, check it was assigned to LE profile)
					// If - yes, load the LE, 
					// If - no, keep personal profile as current, but show message on the home page.
					if (sessionBean.getProfile() != null 
							&& sessionBean.getProfile().getStatus() != MySpaceConstants.USER_PROFILE_STATUS_ACTIVE) {
						// Try to load active profile.
						if (profilesParticipation != null && profilesParticipation.length > 0) {
							for (int i = 0; i < profilesParticipation.length; i++) {
								if (MySpaceConstants.USER_PROFILE_STATUS_ACTIVE == profilesParticipation[i].getStatus()) {									
									sessionBean.setProfile(profilesParticipation[i]);
									break;
								}
							}
						}
					}
					
					// Update LDAP with active profile.
					MySpaceActiveProfileManager activeProfileManager = new MySpaceActiveProfileManager();
					activeProfileManager.registerProfileInLdap(userProfileBean, sessionBean.getProfile());
					
					if (!MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equalsIgnoreCase(sessionBean.getProfile().getProfileType())) {
						sessionBean.setRedirectToPage(MySpaceUtils.getDashboardPageByProfileType(sessionBean.getProfile().getProfileType()));
						if (sessionBean.getDefaultUserProfileId() != null) {
							sessionBean.setCurrentPage(MySpaceUtils.getDashboardPageByProfileType(sessionBean.getProfile().getProfileType()));
						} 
					}
				} else {
					// Handle actions happend in the background when user is already logged in. (for ex. invitation acceptance)
					// Check invitation (as PUMA cache it, we will use direct LDAP)					
					LDAPCommunicator ldapCommunicator = new LDAPCommunicator();
					String invitationId = ldapCommunicator.getInvitationId(sessionBean.getUserProfile().getCurrentUserUID());
					if (invitationId != null && invitationId.trim().length() > 0) {
						UserProfileInvitation invitation = management.loadInvitationById(invitationId);
						if (invitation != null) {	
							// Load profiles participation through the UserProfileRole table.
							UserProfileRole[] roles = management.loadAllProfileRolesByUserUID(userProfileBean.getCurrentUserUID());
							if (roles != null && roles.length > 0) {
								String userProfileIds = "";
								for (int i = 0; i < roles.length; i++) {
									if (userProfileIds.trim().length() > 0) {
										userProfileIds += ",";
									}
									userProfileIds += roles[i].getUserProfileId(); 
								}
								if (userProfileIds.length() > 0) {									
									sessionBean.setProfilesParticipation(management.loadAllProfilesByIds(userProfileIds));
								}
							}
							boolean founded = false;
							if (sessionBean.getProfilesParticipation() != null && sessionBean.getProfilesParticipation().length > 0) {
								for (int i = 0; i < sessionBean.getProfilesParticipation().length; i++) {
									if (sessionBean.getProfilesParticipation()[i].getId().equalsIgnoreCase(String.valueOf(invitation.getUserProfileId()))) {
										founded = true;
										if (sessionBean.getProfile() != null 
												&& MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(sessionBean.getProfile().getProfileType())
												&& MySpaceConstants.USER_PROFILE_STATUS_ACTIVE.equals(sessionBean.getProfile().getStatus())) {
											// Show message ONLY for user that has personal profile.
											List<Message> messages = sessionBean.getMessages();
											if (messages == null) {
												messages = new ArrayList<>();
											}
											messages.add(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, "Вашият профил на ФЛ е успешно асоцииран с профила на " + sessionBean.getProfilesParticipation()[i].getNameAndLegalForm() + "."));
											sessionBean.setMessages(messages);
										}
										// Set active profile to be the invited one for.
										sessionBean.setProfile(sessionBean.getProfilesParticipation()[i]);
										// Remove LDAP key (as we do not need it, anymore)
										ldapCommunicator.removeInvitationId(sessionBean.getUserProfile().getCurrentUserUID());										
										processInvitation = true;
										break;
									}
								}
							}
							if (founded) {
								// Update LDAP with active profile.
								MySpaceActiveProfileManager activeProfileManager = new MySpaceActiveProfileManager();
								activeProfileManager.registerProfileInLdap(userProfileBean, sessionBean.getProfile());
								sessionBean.setRedirectToPage(MySpaceUtils.getDashboardPageByProfileType(sessionBean.getProfile().getProfileType()));
							}
						}
					}
					
				}
			}
						
			// Handle multiple profiles.
			if (!processInvitation) {
				if (newRegistration) {
					sessionBean.setCurrentPage(MySpacePortlet.PROFILE_PAGE);
				} else {
					if (sessionBean.getDefaultUserProfileId() == null) {
						if (utils.countActiveProfiles(sessionBean) > 1) { 
	//						String egovIdentifier = userProfileBean.getCurrentUserIdentifier();
	//						EncryptorAESGCM aesCls = new EncryptorAESGCM();
	//						egovIdentifier = aesCls.decryptEgovIdentifier(userProfileBean.getCurrentUserIdentifier());					
	//						if (MySpaceConstants.DS_IDENTIFIER.equals(egovIdentifier)) {
								sessionBean.setCurrentPage(MySpacePortlet.PROFILE_SELECTOR_PAGE);
	//							profileSelectorMode = true;
	//						}
						}
					}
				}
			}			
			// Check profile status is 'active', and we are not rendering 'support' pages.
			if (MySpaceConstants.USER_PROFILE_STATUS_ACTIVE.equalsIgnoreCase(sessionBean.getProfile().getStatus())
					&& utils.checkPageCanShowProfileParameters(sessionBean.getCurrentPage())) {
				// Initialize profile parameters container for loaded profile type.
				ProfileParametersContainer parametersContainer = sessionBean.getProfileParametersContainer().get(sessionBean.getProfile().getProfileType());
				UserProfileParametersManagement parametersManagement = new UserProfileParametersManagement();	
				// It should be null, if not initialized yet.
				if (parametersContainer == null) {
					Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> parametersContainer == null, going to intialize...");										
					sessionBean.setProfileParametersContainer(parametersManagement.initializeSessionBean(sessionBean));								
				}
				boolean check = false;					
				if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equalsIgnoreCase(sessionBean.getProfile().getProfileType())) {
					check = true;
				} else {			
					UserProfileRole role = sessionBean.getProfileRoles();
					if (role == null) {
						UserProfileManagement management = new UserProfileManagement();
						sessionBean.setProfileRoles(management.loadRolesByProfileIdAndUserUID(sessionBean.getProfile().getId(), userProfileBean.getCurrentUserUID()));
						role = sessionBean.getProfileRoles();					
					}
					//
					if (role != null && MySpaceConstants.USER_PROFILE_ROLE_SELECTED.equalsIgnoreCase(role.getAdmin())) {
						check = true;
						// This flag is used to show the 'profile page' link. (as it should be visible ONLY for 'Admins').
						container.setShowProfilePage(true);
					}
				}
				if (check) {
					parametersManagement.checkForNotPopulatedRequiredFields(sessionBean, renderResponse, bundle);
				}		
			}
			
			// If we want to load roles on demand - uncomment below:
			//if (sessionBean.getProfile() != null && MySpaceConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER.equals(sessionBean.getProfile().getProfileType())) {
				//UserProfileManagement management = new UserProfileManagement();
				//sessionBean.setProfileRoles(management.loadRolesByProfileIdAndUserUID(sessionBean.getProfile().getId(), userProfileBean.getCurrentUserUID()));
			//}
			
			if (MySpacePortlet.INDEX_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage()) 
					|| MySpacePortlet.ADD_FAVORITE_SERVICE_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())
					|| MySpacePortlet.MY_FAVORITE_SERVICES_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())
					|| MySpacePortlet.MY_VISITED_SERVICES_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {				
				if (!MySpacePortlet.MY_VISITED_SERVICES_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
					if (request.getSession() != null) {
						Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> prepareRenderingData() hasSession");
						if ((ArrayList<String>)request.getSession().getAttribute(MySpaceConstants._USER_PROFILE_MY_FAVORITE_SERVICES_SESSION_KEY) == null) {
							Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> prepareRenderingData() NO SessionKey, initialize data from DB...");
							ArrayList<String> myFavoritesArrList = new ArrayList<String>();
							MyFavoriteServicesManagement management = new MyFavoriteServicesManagement();
							UserProfileMyFavorites[] myFavorites = management.loadAllContentUUIDsByUserUID(userProfileBean.getCurrentUserUID());
							if (myFavorites != null && myFavorites.length > 0) {
								for (int i = 0; i < myFavorites.length; i++) {
									myFavoritesArrList.add(myFavorites[i].getContentUUID());
								}
							}
							Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> prepareRenderingData() loaded \"My Favorites\" from DB = " + myFavoritesArrList.size());
							request.getSession().setAttribute(MySpaceConstants._USER_PROFILE_MY_FAVORITE_SERVICES_SESSION_KEY, myFavoritesArrList);
						}
						container.setFavoriteServices((ArrayList<String>)request.getSession().getAttribute(MySpaceConstants._USER_PROFILE_MY_FAVORITE_SERVICES_SESSION_KEY));
					}
				} else {
					ArrayList<String> visitedServicesArrList = new ArrayList<String>();
					AuditLogManagement management = new AuditLogManagement();
					int limit = 0;
					AuditLogBean[] auditLogs = management.loadAllAuditLogs(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_LAST_VISITED_SERVICE, null, null, null, limit, true);
					if (auditLogs != null && auditLogs.length > 0) {
						for (int i = 0; i < auditLogs.length; i++) {
							visitedServicesArrList.add(auditLogs[i].getActivityDescription());
						}
					}
					container.setVisitedServices(visitedServicesArrList);
				}
			} else if (MySpacePortlet.PROFILE_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
				renderRequest.removeAttribute("additionalIdentifiers");
				String egovIdentifier = userProfileBean.getCurrentUserIdentifier();
				if (userProfileBean.getCurrentUserIdentifier() != null) {
					EncryptorAESGCM aesCls = new EncryptorAESGCM();
					egovIdentifier = aesCls.decryptEgovIdentifier(userProfileBean.getCurrentUserIdentifier());
				}
				// TODO ask for ESB eDelivery service?
//				if (container.geteDeliverySubjectBean() == null) {
//					EDeliveryManagement eDeliveryManagement = new EDeliveryManagement();					
//					if (egovIdentifier != null) {
//						EDeliverySubjectBean eDeliverySubjectBean = eDeliveryManagement.loadSubjectInfo(egovIdentifier);
//						// Populate subjectInfo from eDelivery (ESB).
//						container.seteDeliverySubjectBean(eDeliverySubjectBean);
//						if (MySpaceConstants.DS_IDENTIFIER.equals(egovIdentifier)) {
//							container.seteDeliverySubjectBean(eDeliveryManagement.loadSubjectInfo("8812066630"));
//						} 
//					}
//				}				
				if (sessionBean.getProfile().getId() != null) {
					// Load additional identifiers.
					UserProfileManagement profileManagement = new UserProfileManagement();
					UserProfileIdentifier[] additionalIdentifiers = profileManagement.loadAllProfileIdentifiersByProfileIdExceptPIKNRAAndPIKNOI(sessionBean.getProfile().getId());
					renderRequest.setAttribute("additionalIdentifiers", additionalIdentifiers);
					
					renderRequest.removeAttribute("profilesParticipation");
					renderRequest.removeAttribute("profilesParticipationRoles");
					// Load profiles participation through the UserProfileRole table.
					UserProfileRole[] profilesParticipationRoles = profileManagement.loadAllProfileRolesByUserUID(userProfileBean.getCurrentUserUID());
					if (profilesParticipationRoles != null && profilesParticipationRoles.length > 0) {
						String userProfileIds = "";
						for (int i = 0; i < profilesParticipationRoles.length; i++) {
							if (userProfileIds.trim().length() > 0) {
								userProfileIds += ",";
							}
							userProfileIds += profilesParticipationRoles[i].getUserProfileId(); 
						}
						if (userProfileIds.length() > 0) {
							// Load all 'Active' Not personal profiles per current user.
							UserProfile[] profilesParticipation = profileManagement.loadAllNotPersonalProfilesByIdsAndStatus(userProfileIds, MySpaceConstants.USER_PROFILE_STATUS_ACTIVE);
							if (profilesParticipation != null && profilesParticipation.length > 0) {
								renderRequest.setAttribute("profilesParticipation", profilesParticipation);
								renderRequest.setAttribute("profilesParticipationRoles", profilesParticipationRoles);
								
							}
						} 
					} 
				}
				
			} else if (MySpacePortlet.PROFILE_REMOVE_IDENTIFIER_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
				System.out.println("MySpaceViewEngine:" + MySpacePortlet.PROFILE_REMOVE_IDENTIFIER_PAGE);
				Long profileIdentifierId = container.getProfileIdentifierId();
				System.out.println("MySpaceViewEngine:profileIdentifierId=" + profileIdentifierId);
				if (profileIdentifierId != null) {					
					UserProfileManagement management = new UserProfileManagement();
					UserProfileIdentifier userProfileIdentifier = management.loadProfileIdentifierById(String.valueOf(profileIdentifierId));
					if (userProfileIdentifier != null) {
						renderRequest.setAttribute("profileIdentifier", userProfileIdentifier);
						ProfileIdentifierBean pIBean = utils.populateProfileIdentifierBeanFromDB(userProfileIdentifier);
						pIBean.setRnu(utils.generateRNU());
						String currentTime = utils.getCurrentTime();							
						String xml = utils.populateXMLForProfileIdentifierSign(pIBean, sessionBean, currentTime);					
						if (xml != null && xml.length() > 0) {		
							String encodedString = Base64.getEncoder().withoutPadding().encodeToString(xml.getBytes());						
							String fileName = "Премахване_на_идентификатор_" + pIBean.getIdentifier() + "_";
							String time = currentTime.replaceAll("\\.", "_").replaceAll(" ", "_").replaceAll("\\:", "_");
							fileName += time;
							fileName += ".xml";
							pIBean.setXmlBase64(encodedString);
							pIBean.setXmlBase64FileName(fileName);
							Logger.log(Logger.DEBUG_LEVEL, "xmlBase64=" + encodedString);
							Logger.log(Logger.DEBUG_LEVEL, "fileName=" + fileName);
						}
						container.setProfileIdentifierBean(pIBean);
					}
				}
			} else if (MySpacePortlet.PROFILE_ADD_IDENTIFIER_SIGN_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
				ProfileIdentifierBean pIBean = container.getProfileIdentifierBean();
				if (pIBean != null && pIBean.getIdentifierType() != null && pIBean.getIdentifierCountryCode() != null
						&& pIBean.getIdentifier() != null && pIBean.getIdentifier().trim().length() > 0) {
    				String rnu = utils.generateRNU();					
					String currentTime = utils.getCurrentTime();
					pIBean.setRnu(rnu);
					String xml = utils.populateXMLForProfileIdentifierSign(pIBean, sessionBean, currentTime);					
					if (xml != null && xml.length() > 0) {		
						String encodedString = Base64.getEncoder().withoutPadding().encodeToString(xml.getBytes());						
						String fileName = "Добавяне_на_идентификатор_" + pIBean.getIdentifier() + "_";
						String time = currentTime.replaceAll("\\.", "_").replaceAll(" ", "_").replaceAll("\\:", "_");
						fileName += time;
						fileName += ".xml";
						pIBean.setXmlBase64(encodedString);
						pIBean.setXmlBase64FileName(fileName);
						Logger.log(Logger.DEBUG_LEVEL, "xmlBase64=" + encodedString);
						Logger.log(Logger.DEBUG_LEVEL, "fileName=" + fileName);
					}
					container.setProfileIdentifierBean(pIBean);
				}
			} else if (MySpacePortlet.LEGAL_ENTITY_REQUEST_PROFILE_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage()) || 
					MySpacePortlet.LEGAL_ENTITY_REQUEST_PROFILE_REIK_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
				renderRequest.setAttribute("allProfileStructureTypes", EgovWCMCache.getProfileStructureTypes());
			} else if (MySpacePortlet.EDELIVERY_SYNC_PROFILE_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
				UserProfileManagement management = new UserProfileManagement();				
				HashMap<String, UserProfile> isMemberOfProfileHm = management.loadIsMemberOfProfile(sessionBean);
				container.setIsMemberOfProfileHm(isMemberOfProfileHm); 
			} else if (MySpacePortlet.DEACTIVATE_PROFILE_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
				renderRequest.removeAttribute("subProfiles");
				UserProfileManagement management = new UserProfileManagement();	
				UserProfileRef[] profileRefs = management.loadAllProfileRefsByParentUserProfileId(sessionBean.getProfile().getId());
				if (profileRefs != null && profileRefs.length > 0) {
					String userProfileIds = "";
					for (int i = 0; i < profileRefs.length; i++) {
						if (userProfileIds.length() > 0) {
							userProfileIds += ",";
						}
						userProfileIds += profileRefs[i].getUserProfileId();
					}
					UserProfile[] subProfiles = management.loadAllProfilesByIdsAndStatus(userProfileIds, MySpaceConstants.USER_PROFILE_STATUS_ACTIVE);
					if (subProfiles != null && subProfiles.length > 0) {
						renderRequest.setAttribute("subProfiles", subProfiles);
					}
				}
			} else if (MySpacePortlet.AUDIT_LOG_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
				AuditLogManagement management = new AuditLogManagement();
				AuditLogBean[] auditLogs = management.loadAllAuditLogs(userProfileBean.getCurrentUserUID(), null, null, null, null, 0, false);
				if (auditLogs != null && auditLogs.length > 0) {
					container.setAuditLogs(auditLogs);
				}
			} else if (MySpacePortlet.ACCESS_MANAGEMENT_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
				renderRequest.removeAttribute("userProfileInvitations");
				UserProfileManagement management = new UserProfileManagement();
				UserProfileRole[] roles = management.loadAllProfileRolesByProfileId(sessionBean.getProfile().getId());
				if (roles != null && roles.length > 0) {
					String names = null;
					for (int i = 0; i < roles.length; i++) {
						names = pumaCommunicator.getUserNamesByUID(roles[i].getUserUID(), pumaHome);
						if (names != null) {
							roles[i].setNames(names);
						}
					}
					container.setUserProfileRoles(roles);
				}
				//if (MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY_AL2.equals(sessionBean.getProfile().getProfileType())) {
					// Check for invitations.
					UserProfileInvitation[] invitations = management.loadAllInvitationsByProfileId(sessionBean.getProfile().getId());
					renderRequest.setAttribute("userProfileInvitations", invitations);
				//}
			} else if (MySpacePortlet.AUTHORIZATIONS_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
				AuthorizationsManagement management = new AuthorizationsManagement();
				String identifier = MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equalsIgnoreCase(sessionBean.getProfile().getProfileType()) ? sessionBean.getProfile().getIdentifier() : sessionBean.getProfile().getEik();
				if (identifier == null) {
					identifier = sessionBean.getUserProfile().getCurrentUserUID();
				}
				List<Authorizations> allAuthorizations = management.loadAllAuthorizationsByUserIdentifier(identifier);
				if (allAuthorizations != null && allAuthorizations.size() > 0) {
					List<Authorizations> allAuthorizationsFromMe = new ArrayList<Authorizations>();
					List<Authorizations> allAuthorizationsForMe = new ArrayList<Authorizations>();
					List<Authorizations> inActiveAuthorizations = new ArrayList<Authorizations>();
					List<Authorizations> canceledAuthorizations = new ArrayList<Authorizations>();
					Authorizations authorization = null;
					String sysmtesStr = "";					
					for (int i = 0; i < allAuthorizations.size(); i++) {
						authorization = allAuthorizations.get(i);
						if (authorization.getUserIdentifier().equalsIgnoreCase(identifier) && !utils.authorizationIsBlocked(authorization)) {
							allAuthorizationsFromMe.add(authorization);
						} else if (utils.authorizationIsActive(authorization)) {
							allAuthorizationsForMe.add(authorization);
						}												
						if (utils.authorizationIsInactive(authorization)) {
							inActiveAuthorizations.add(authorization);
						} else if (utils.authorizationIsCanceled(authorization) 
								|| utils.authorizationIsExpired(authorization)
								|| utils.authorizationIsBlocked(authorization)) {
							canceledAuthorizations.add(authorization);
						}						
						sysmtesStr += authorization.getSystems();
					}
					if (sysmtesStr.trim().length() > 0) {
						renderRequest.setAttribute("authorizationSystemsHm", populateAuthorizationSystemsHm(allAuthorizations, sysmtesStr));
					}
					if (allAuthorizationsFromMe != null && allAuthorizationsFromMe.size() > 0) {						
						renderRequest.setAttribute("allAuthorizationsFromMe", allAuthorizationsFromMe);
					}
					if (allAuthorizationsForMe != null && allAuthorizationsForMe.size() > 0) {
						renderRequest.setAttribute("allAuthorizationsForMe", allAuthorizationsForMe);
					}
					if (inActiveAuthorizations != null && inActiveAuthorizations.size() > 0) {
						renderRequest.setAttribute("inActiveAuthorizations", inActiveAuthorizations);
					}
					if (canceledAuthorizations != null && canceledAuthorizations.size() > 0) {
						renderRequest.setAttribute("canceledAuthorizations", canceledAuthorizations);
					}
				}
			} else if (MySpacePortlet.AUTHORIZATION_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())
					|| MySpacePortlet.CANCEL_AUTHORIZATION_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
				System.out.println("MySpaceViewEngine:" + MySpacePortlet.CANCEL_AUTHORIZATION_PAGE);
				Long authorizationsId = container.getAuthorizationsId();
				System.out.println("MySpaceViewEngine:authorizationsId=" + authorizationsId);
				if (authorizationsId != null) {					
					AuthorizationsManagement management = new AuthorizationsManagement();
					Authorizations authorization = management.getAuthorizationById(authorizationsId);
					if (authorization != null) {
						renderRequest.setAttribute("authorization", authorization);
						if (MySpacePortlet.AUTHORIZATION_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
							renderRequest.setAttribute("selectedSystems", utils.parseSystemsToBean(authorization.getSystems(), null, null));
							String identifier = MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equalsIgnoreCase(sessionBean.getProfile().getProfileType()) ? sessionBean.getProfile().getIdentifier() : sessionBean.getProfile().getEik();
							if (identifier == null) {
								identifier = sessionBean.getUserProfile().getCurrentUserUID();
							}
							if (!utils.authorizationIsExpired(authorization) &&
									!utils.authorizationIsCanceled(authorization) && 
									authorization.getUserIdentifier().equalsIgnoreCase(identifier)) {
								renderRequest.setAttribute("showCancelButton", "1");
							} else {
								renderRequest.setAttribute("showCancelButton", "0");
							}
							renderRequest.setAttribute("status", utils.getAuthorizationStatusName(authorization));
						} else if (MySpacePortlet.CANCEL_AUTHORIZATION_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
							AuthorizationBean aBean = utils.populateAuthorizationBeanFromDB(authorization);	
							aBean.setRnu(utils.generateRNU());
							String currentTime = utils.getCurrentTime();							
							String xml = utils.populateXMLForAuthorizationSign(aBean, sessionBean, currentTime);					
							if (xml != null && xml.length() > 0) {		
								String encodedString = Base64.getEncoder().withoutPadding().encodeToString(xml.getBytes());						
								String fileName = "Оттегляне_на_овластяване_на_" + aBean.getAuthorizedNames().replaceAll(" ", "_") + "_";
								String time = currentTime.replaceAll("\\.", "_").replaceAll(" ", "_").replaceAll("\\:", "_");
								fileName += time;
								fileName += ".xml";
								aBean.setXmlBase64(encodedString);
								aBean.setXmlBase64FileName(fileName);
								Logger.log(Logger.DEBUG_LEVEL, "xmlBase64=" + encodedString);
								Logger.log(Logger.DEBUG_LEVEL, "fileName=" + fileName);
							}
							container.setAuthorizationBean(aBean);
						}
					}
				}
			} else if (MySpacePortlet.ADD_AUTHORIZATION_PREVIEW_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
			} else if (MySpacePortlet.ADD_AUTHORIZATION_SIGN_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
				renderRequest.removeAttribute("manualSign");
				AuthorizationBean aBean = container.getAuthorizationBean();
				if (aBean != null && aBean.getActionIds() != null && aBean.getActionIds().trim().length() > 0) {
					String rnu = utils.generateRNU();
					
					String currentTime = utils.getCurrentTime();
					aBean.setRnu(rnu);
					String xml = utils.populateXMLForAuthorizationSign(aBean, sessionBean, currentTime);					
					if (xml != null && xml.length() > 0) {		
						String encodedString = Base64.getEncoder().withoutPadding().encodeToString(xml.getBytes());						
						String fileName = "Овластяване_на_" + aBean.getAuthorizedNames().replaceAll(" ", "_") + "_";
						String time = currentTime.replaceAll("\\.", "_").replaceAll(" ", "_").replaceAll("\\:", "_");
						fileName += time;
						fileName += ".xml";
						aBean.setXmlBase64(encodedString);
						aBean.setXmlBase64FileName(fileName);
						Logger.log(Logger.DEBUG_LEVEL, "xmlBase64=" + encodedString);
						Logger.log(Logger.DEBUG_LEVEL, "fileName=" + fileName);
					}
					container.setAuthorizationBean(aBean);
				}
				renderRequest.setAttribute("manualSign", Base.TEST_ENVIRONMENT && (MySpacePortlet.isAdmin || "de33f3831e504acb33f79be8e7856d6816".equals(userProfileBean.getCurrentUserUID())));
			} else if (MySpacePortlet.ACCESS_ADD_USER_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())					
						|| MySpacePortlet.ACCESS_EDIT_USER_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
				renderRequest.removeAttribute("horizontalSystemRoles");
				renderRequest.removeAttribute("userProfileXCRoles");
				renderRequest.removeAttribute("systemOIDs");
				// Load horizontalSystemRoles.
				HorizontalSystemRoleManagement hsRoleManagement = new HorizontalSystemRoleManagement();
				HorizontalSystemRole[] hsRoles = hsRoleManagement.loadAll();
				renderRequest.setAttribute("horizontalSystemRoles", hsRoles);
				Map<String, String> systemOIDsHM = new HashMap<String, String>();
				// eDelivery -> 2.16.100.1.1.292.1.5.1.3
				systemOIDsHM.put("2.16.100.1.1.292.1.5.1.3", "еВръчване");
				renderRequest.setAttribute("systemOIDs", systemOIDsHM);
				if (MySpacePortlet.ACCESS_EDIT_USER_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
					container.setUserProfileRole(null);
					String id = renderRequest.getParameter(MySpacePortlet.PARAMETER_ID);
					if (id != null) {
						UserProfileManagement management = new UserProfileManagement();
						UserProfileRole role = management.loadRolesById(id);
						if (role != null) {
							EncryptorAESGCM aesCls = new EncryptorAESGCM();
							PumaCommunicator communicator = new PumaCommunicator();
							String[] namesAndPersonalIdentifier = communicator.getUserNamesPersonalIdentifierAndEmailByUID(role.getUserUID(), pumaHome);
							if (namesAndPersonalIdentifier.length == 3) {
								role.setNames(namesAndPersonalIdentifier[0]);
								role.setPersonalIdentifier(aesCls.decryptEgovIdentifier(namesAndPersonalIdentifier[1]));
								role.setUserEmail(namesAndPersonalIdentifier[2]);
							}
							container.setUserProfileRole(role);
							if (hsRoles != null && hsRoles.length > 0) {					
								UserProfileXCRoleManagement userProfileXCRoleManagement = new UserProfileXCRoleManagement();
								renderRequest.setAttribute("userProfileXCRoles", userProfileXCRoleManagement.loadAllXCRolesByUserProfileIdAndUserUID(sessionBean.getProfile().getId(), role.getUserUID()));								
							}
						}
					}
				}
			} else if (MySpacePortlet.CONTENT_MANAGEMENT_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
				container.setEditSupplierLink(null);
				container.setEditSupplierServicesLink(null);
				if (sessionBean.getProfile().getGroupId() != null && sessionBean.getProfile().getGroupId().trim().length() > 0) {
					WebContentManagement wcmManagement = new WebContentManagement();
					Content supplier = wcmManagement.getSupplier(sessionBean.getProfile().getGroupId());					
					if (supplier != null) {
						try {
							String supplierPath = EgovWCMCache.getWorkspace().getPathById(supplier.getId(), false, true);
							container.setEditSupplierLink(supplierPath.substring(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME.length()));
							//System.out.println("sPAth =" + container.getEditSupplierLink());
							String parentPath = container.getEditSupplierLink().substring(0, container.getEditSupplierLink().length() - sessionBean.getProfile().getGroupId().trim().length());
							// Central administration.
							if (supplier.getAuthoringTemplateID().getId().equalsIgnoreCase(EgovWCMCache.getATServiceProviderCentralAdministration().getId().getId())) {
								container.setEditSupplierServicesLink(parentPath + "uslugi?supplierId=" + sessionBean.getProfile().getGroupId());
							} else {
								if (parentPath.indexOf("/oblastni administratsii/") != -1) {
									container.setEditSupplierServicesLink(parentPath + "uslugi/oblast?rId=" + sessionBean.getProfile().getGroupId());
								} else if (parentPath.indexOf("/obshtinski administratsii/") != -1) {
									container.setEditSupplierServicesLink(parentPath + "uslugi/obshtina?mId=" + sessionBean.getProfile().getGroupId());
								} else if (parentPath.indexOf("/obshtinski administratsii na rayoni/") != -1) {
									container.setEditSupplierServicesLink(parentPath + "uslugi/rayon?amId=" + sessionBean.getProfile().getGroupId());
								} else if (parentPath.indexOf("/spetsializirani teritorialni administratsii/") != -1) {
									container.setEditSupplierServicesLink(parentPath + "uslugi/teritorialna administratsia?aId=" + sessionBean.getProfile().getGroupId());	
								}
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
						
					}
				}
			} else if (MySpacePortlet.MESSAGES_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())
					|| MySpacePortlet.PAYMENTS_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())
					|| MySpacePortlet.MANAGE_E_FORMS_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())
					|| MySpacePortlet.MY_HEALTH_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
				renderRequest.removeAttribute("encryptedProfileId");
				renderRequest.removeAttribute("profileStructureTypeParam");
				UserProfile profile = sessionBean.getProfile();
				EncryptorAESGCM aesCls = new EncryptorAESGCM(); 
				String key = MySpacePortlet.PAYMENTS_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage()) ? MySpaceConstants.E_PAYMENT_SECRET_KEY_IN_BASE_64 : MySpaceConstants.E_DELIVERY_SECRET_KEY_IN_BASE_64;
				if (MySpacePortlet.MANAGE_E_FORMS_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
					key = MySpaceConstants.E_FORMS_SECRET_KEY_IN_BASE_64;
				}
				if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(profile.getProfileType())) {
					if (profile.getIdentifier() != null) {
						renderRequest.setAttribute("encryptedProfileId", aesCls.encryptPersonalIdentifier(aesCls.decryptEgovIdentifier(profile.getIdentifier()), key));
					}
				} else if (profile.getEik() != null) {
					renderRequest.setAttribute("encryptedProfileId", aesCls.encryptPersonalIdentifier(profile.getEik(), key));					
				}				
				if (profile.getProfileStructureType() != null && profile.getProfileStructureType().trim().length() > 0) {
					Integer[] profileStructureTypes = utils.getArrayFromFormatedField(profile.getProfileStructureType().trim());
					if (profileStructureTypes != null && profileStructureTypes.length > 0) {
						String pStructureTypesParam = "";
						for (int i = 0; i < profileStructureTypes.length; i++) {
							pStructureTypesParam += "&profileStructureType=" + profileStructureTypes[i];
						}
						renderRequest.setAttribute("profileStructureTypeParam", pStructureTypesParam);
					}
				}
				if (MySpacePortlet.MESSAGES_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
					ESBEDeliveryResponseBean responseReceived = null;
					ESBEDeliveryResponseBean responseSent = null;
					List<ESBEDeliveryBean> receivedMessages = null;					
					String personalIdentifier = userProfileBean.getCurrentUserIdentifier() != null ? aesCls.decryptEgovIdentifier(userProfileBean.getCurrentUserIdentifier()) : null;
					String representedPersonId = utils.getRepresentedPersonId(profile, personalIdentifier);
					// TODO Remove.
					if (Base.TEST_ENVIRONMENT && 
							(MySpacePortlet.isAdmin || userProfileBean.getCurrentUserEmail().equalsIgnoreCase(MySpaceConstants.DS_EMAIL))) {
						personalIdentifier = MySpaceConstants.MD_IDENTIFIER;
						if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(profile.getProfileType())) {
							representedPersonId = "PNOBG-" + MySpaceConstants.MD_IDENTIFIER;
						}
					}
					System.out.println("MESSAGES_PAGE [" + representedPersonId + "," + personalIdentifier + "]");
					try {									
						responseReceived = esbCommunicator.getEDelivery(sessionBean, representedPersonId, personalIdentifier, MySpaceConstants.ESB_E_DELIVERY_DIRECTION_RECEIVED, 1, 10);	
					} catch (Exception e) {
						e.printStackTrace();
						sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, bundle.getString("esb.edelivery.communication.error")));
						renderRequest.setAttribute("eDeliveryError", "1");
					}
					int unReadMessagesCount = 0;
					if (responseReceived != null && responseReceived.getMessages() != null 
							&& responseReceived.getMessages().size() > 0) {
						receivedMessages = responseReceived.getMessages();
						for (int i = 0; i < receivedMessages.size(); i++) {
							if (receivedMessages.get(i).getDateReceived() == null) {
								unReadMessagesCount++;
							}
						}
					}
					// Load unRead messages count in current session.
					sessionBean.setUnReadReceivedMessagesCount(unReadMessagesCount);
					try {
						responseSent = esbCommunicator.getEDelivery(sessionBean, representedPersonId, personalIdentifier, MySpaceConstants.ESB_E_DELIVERY_DIRECTION_SENT, 1, 10);
					} catch (Exception e) {
						e.printStackTrace();
					}
					renderRequest.setAttribute("responseReceived", responseReceived);
					renderRequest.setAttribute("responseSent", responseSent);
				} else if (MySpacePortlet.PAYMENTS_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
					ESBEPaymentResponseBean paymentsPending = null;
					//ESBEPaymentResponseBean paymentsAllRest = null;					
					String personalIdentifier = userProfileBean.getCurrentUserIdentifier() != null ? aesCls.decryptEgovIdentifier(userProfileBean.getCurrentUserIdentifier()) : null;
					String representedPersonId = utils.getRepresentedPersonId(profile, personalIdentifier);
					// TODO Remove.
					if (Base.TEST_ENVIRONMENT && MySpacePortlet.isAdmin) {
						personalIdentifier = MySpaceConstants.BULSI_IDENTIFIER;
					}
					Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> PAYMENTS_PAGE [" + personalIdentifier + "]");
					try {					 	 			
						paymentsPending = esbCommunicator.getEPayment(sessionBean, representedPersonId, personalIdentifier, MySpaceConstants.ESB_E_PAYMENT_STATUS_PENDING, 1, 10);	
					} catch (Exception e) {
						e.printStackTrace();
						sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, bundle.getString("esb.epayment.communication.error")));
						renderRequest.setAttribute("ePaymentError", "1");
					}		
//					We do not need to preload the all rest, as it took too much time.
//					try {
//						String status = MySpaceConstants.ESB_E_PAYMENT_STATUS_AUTHORIZED + "," + MySpaceConstants.ESB_E_PAYMENT_STATUS_ORDERED + "," + MySpaceConstants.ESB_E_PAYMENT_STATUS_PAID + "," + MySpaceConstants.ESB_E_PAYMENT_STATUS_EXPIRED + "," + MySpaceConstants.ESB_E_PAYMENT_STATUS_CANCELED + "," + MySpaceConstants.ESB_E_PAYMENT_STATUS_SUSPENDED;						
//						paymentsAllRest = esbCommunicator.getEPayment(sessionBean, representedPersonId, personalIdentifier, status, 1, 10);
//					} catch (Exception e) {
//						e.printStackTrace();
//					}
					// We preload the data as the ajax of DataTable gives issue when we have multiple calls onload.
					// We clear them after the first ajax call.
					sessionBean.setEPaymentsPending(paymentsPending);
					//sessionBean.setEPaymentsAllRest(paymentsAllRest);
				}
			} else if (MySpacePortlet.SUBSCRIPTIONS_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
				Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> SUBSCRIPTIONS_PAGE [start]");
				ESBUserProfileSubscriberBean rootBean = sessionBean.getSubscriptionRootBean();
				if (rootBean == null) {
					UserProfile profile = sessionBean.getProfile();
					EncryptorAESGCM aesCls = new EncryptorAESGCM(); 
					String personalIdentifier = userProfileBean.getCurrentUserIdentifier() != null ? aesCls.decryptEgovIdentifier(userProfileBean.getCurrentUserIdentifier()) : null;
					String representedPersonId = utils.getRepresentedPersonId(profile, personalIdentifier);
					if (Base.TEST_ENVIRONMENT && MySpacePortlet.isAdmin) {
						personalIdentifier = MySpaceConstants.MD_IDENTIFIER;
						if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(profile.getProfileType())) {
							representedPersonId = "PNOBG-" + MySpaceConstants.MD_IDENTIFIER;
						}
					}
					try {	
						// Load data from ESB.						
						rootBean = esbCommunicator.getSubscriptions(sessionBean, representedPersonId, personalIdentifier, profile.getProfileType(), profile.getProfileStructureType());
					} catch (Exception e) {
						e.printStackTrace();
						sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, bundle.getString("esb.subscriptions.communication.error")));
						renderRequest.setAttribute("esbSubscriptionError", "1");
					}	
					if (rootBean == null) {
						sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, bundle.getString("esb.subscriptions.communication.error")));
						renderRequest.setAttribute("esbSubscriptionError", "1");
					}
					//ESBTokenManager esbTokenManager = new ESBTokenManager();
					//rootBean = esbTokenManager.getPredefinedSupsData();
				}
				sessionBean.setSubscriptionRootBean(rootBean);
			} else if (MySpacePortlet.ADD_SUBSCRIPTION_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {				
				System.out.println("MySpaceViewEngine:" + MySpacePortlet.ADD_SUBSCRIPTION_PAGE);
				renderRequest.removeAttribute("topSubscriptions");
				ESBUserProfileSubscriberBean rootBean = sessionBean.getSubscriptionRootBean();
				if (rootBean == null) {
					UserProfile profile = sessionBean.getProfile();
					EncryptorAESGCM aesCls = new EncryptorAESGCM(); 
					String personalIdentifier = userProfileBean.getCurrentUserIdentifier() != null ? aesCls.decryptEgovIdentifier(userProfileBean.getCurrentUserIdentifier()) : null;
					String representedPersonId = utils.getRepresentedPersonId(profile, personalIdentifier);
					if (Base.TEST_ENVIRONMENT && MySpacePortlet.isAdmin) {
						personalIdentifier = MySpaceConstants.MD_IDENTIFIER;
						if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(profile.getProfileType())) {
							representedPersonId = "PNOBG-" + MySpaceConstants.MD_IDENTIFIER;
						}
					}
					try {	
						// Load data from ESB.
						rootBean = esbCommunicator.getSubscriptions(sessionBean, representedPersonId, personalIdentifier, profile.getProfileType(), profile.getProfileStructureType());
					} catch (Exception e) {
						e.printStackTrace();
						sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, bundle.getString("esb.subscriptions.communication.error")));
						renderRequest.setAttribute("esbSubscriptionError", "1");
					}	
					//ESBTokenManager esbTokenManager = new ESBTokenManager();
					//rootBean = esbTokenManager.getPredefinedSupsData();
				}
				sessionBean.setSubscriptionRootBean(rootBean);
				if (rootBean != null) {
					ESBUtils esbUtils = new ESBUtils();
					renderRequest.setAttribute("topSubscriptions", esbUtils.getTopSubscriptions(rootBean, true));
				}
			} else if (MySpacePortlet.MDT_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
				Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> MDT_PAGE [start]");
				UserProfile profile = sessionBean.getProfile();
				EncryptorAESGCM aesCls = new EncryptorAESGCM(); 
				String personalIdentifier = userProfileBean.getCurrentUserIdentifier() != null ? aesCls.decryptEgovIdentifier(userProfileBean.getCurrentUserIdentifier()) : null;
				// TODO Remove.
				if (MySpacePortlet.isAdmin) {
					personalIdentifier = MySpaceConstants.BULSI_IDENTIFIER_2;
				}
				String representedPersonId = utils.getRepresentedPersonId(profile, personalIdentifier);
				Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> MDT_PAGE [representedPersonId=" + representedPersonId + "]");
				ESBMDTResponseBean mdtResponse = sessionBean.getMdtResponse(representedPersonId);
				if (mdtResponse != null && mdtResponse.isInitialized() && mdtResponse.getMdtResponseLoadTime() > 0) {
					Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> MDT_PAGE [has cached data]");
					if (System.currentTimeMillis() > mdtResponse.getMdtResponseLoadTime() + MySpaceConstants.MDT_CACHE_EXPIRATION_TIME) {
						Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> MDT_PAGE [Cache expired! Clear the data.]");						
						sessionBean.setMdtResponse(representedPersonId, null);
					} else {
						Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> MDT_PAGE [Cache duration still valid.]");
					}
				} else {
					Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> MDT_PAGE [no data, yet]");
				}
			} else if (MySpacePortlet.PROFILE_PERSONALIZATION_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
				renderRequest.removeAttribute("allPagesHTML");
				renderRequest.removeAttribute("selectedPagesHTML");
				UserProfile profile = sessionBean.getProfile();
				MySpaceSideNavManager sideNavManager = new MySpaceSideNavManager();
				if (profile != null && profile.getCustomSideNav() != null && profile.getCustomSideNav().trim().length() > 0) {
					String[] customSideNav = profile.getCustomSideNav().trim().split(",");					
					renderRequest.setAttribute("allPagesHTML", sideNavManager.buildAllPagesForSelectHTML(customSideNav, bundle));
					renderRequest.setAttribute("selectedPagesHTML", sideNavManager.buildSelectedPagesForSelectHTML(customSideNav, bundle));
				} else {
					renderRequest.setAttribute("allPagesHTML", null);
					renderRequest.setAttribute("selectedPagesHTML", sideNavManager.buildAllPagesForSelectHTML(null, bundle));
				}
			} else if (MySpacePortlet.PROFILE_PARAMETERS_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
				System.out.println("MySpaceViewEngine -> PROFILE_PARAMETERS_PAGE");
				renderRequest.removeAttribute("group");								
				UserProfile profile = sessionBean.getProfile();
				if (profile != null) {
					System.out.println("MySpaceViewEngine -> PROFILE_PARAMETERS_PAGE: hasProfile");
					ProfileParametersContainer parametersContainer = sessionBean.getProfileParametersContainer().get(profile.getProfileType());
					String currentGroup = parametersContainer.getCurrentRegisterGroupName();
					if (currentGroup != null) {
						System.out.println("MySpaceViewEngine -> PROFILE_PARAMETERS_PAGE: hasGroup - OK");
						List<EgovRegisterGroup> allRegisterGroups = EgovWCMCache.getRegisterGroupsByProfileTypeId().get(Integer.parseInt(profile.getProfileType()));
						if (allRegisterGroups != null && allRegisterGroups.size() > 0) {
							for (int i = 0; i < allRegisterGroups.size(); i++) {
								if (!utils.checkProfileHasGroupProfileStructureType(profile, allRegisterGroups.get(i))) {
									continue;
								}
								if (currentGroup.equalsIgnoreCase(allRegisterGroups.get(i).getName())) {
									renderRequest.setAttribute("group", allRegisterGroups.get(i));									
									break;
								}
							}
						}
					} else {
						System.out.println("MySpaceViewEngine -> PROFILE_PARAMETERS_PAGE: hasGroup - NULL");
					}
				} else {
					renderRequest.setAttribute("group", null);
				}
			} else if (MySpacePortlet.INTERNAL_E_SERVICES_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
				List<Category> internalEServicesCategories = sessionBean.getInternalEServicesCategories();
				if (internalEServicesCategories == null) {
					sessionBean.setInternalEServicesCategories(wcmCommunicator.getInternalAdministrativeServicesCategories());
					renderRequest.setAttribute("reinitLS", "1");		
				} else {
					renderRequest.removeAttribute("reinitLS");
				}
			} else if (MySpacePortlet.TRANSLATE_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {
				ETranslationRequestManagement management = new ETranslationRequestManagement();
				List<ETranslationRequest> translationRequests = management.findAllETranslationRequestsByUserProfileId(sessionBean.getProfile().getId());
				renderRequest.setAttribute("translationRequests", translationRequests);
				System.out.println("MySpaceViewEngine->translationRequests=" + (translationRequests != null ? translationRequests.size() : 0));				
				System.out.println("sourceLang=" + renderRequest.getParameter(MySpacePortlet.FORM_PARAMETER_SOURCE_LANGUAGE));
				System.out.println("targetLang=" + renderRequest.getParameter(MySpacePortlet.FORM_PARAMETER_TARGET_LANGUAGE));
				System.out.println("sendTrToEmail=" + renderRequest.getParameter(MySpacePortlet.FORM_PARAMETER_SEND_TRANSLATED_FILE_TO_EMAIL));
			} else if (MySpacePortlet.SERVICES_CATALOG_PAGE.equalsIgnoreCase(sessionBean.getCurrentPage())) {				
			} 
			HashMap<String, Container> containerHm = sessionBean.getContainer();
			containerHm.put(sessionBean.getCurrentPage(), container);			
			sessionBean.setContainer(containerHm);
		}
	}
	
	private Map<Long, List<SelectedSystemBean>> populateAuthorizationSystemsHm(final List<Authorizations> authorizations, final String allSystemsStr) {
		Map<Long, List<SelectedSystemBean>> authorizationSystemsHm = new HashMap<Long, List<SelectedSystemBean>>();	
		String[] actionsPerSystem = utils.getSystemsArrayFromFormatedField(allSystemsStr);
		if (actionsPerSystem != null && actionsPerSystem.length > 0) {
			String[] pair = null;
			List<Long> systems = new ArrayList<>();
			List<Long> actions = new ArrayList<>();
			Long systemsId = null;
			Long actionsId = null;
			for (int i = 0; i < actionsPerSystem.length; i++) {
				pair = actionsPerSystem[i].split(":");
				systemsId = Long.parseLong(pair[0]);
				actionsId = Long.parseLong(pair[1]);
				if (!systems.contains(systemsId)) {
					systems.add(systemsId);
				}
				if (!actions.contains(actionsId)) {
					actions.add(actionsId);
				}				
			}
			AuthorizationsManagement management = new AuthorizationsManagement();
			// Load all systems & actions founded.
			List<Systems> selectedSystems = management.getAllSystemsByIds(systems);
			List<Actions> selectedActions = management.getAllActionsByIds(actions);
			Authorizations authorization = null;
			List<SelectedSystemBean> loadedSystemBeans = null;
			// Split systems & actions by authorization id.
			for (int i = 0; i < authorizations.size(); i++) {
				authorization = authorizations.get(i);
				loadedSystemBeans = utils.parseSystemsToBean(authorization.getSystems(), selectedSystems, selectedActions);
				authorizationSystemsHm.put(authorization.getAuthorizationsId(), loadedSystemBeans);
			}
		}
		return authorizationSystemsHm;
	}
	
//	/*
//	 * This method loads systems and actions from "Systems" field of the authorization.	 
//	 * 
//	 */
//	private List<SelectedSystemBean> parseSystemsToBean(final String systemsStr, List<Systems> selectedSystems, List<Actions> selectedActions) {
//		String[] actionsPerSystem = utils.getSystemsArrayFromFormatedField(systemsStr);
//		if (actionsPerSystem != null && actionsPerSystem.length > 0) {
//			List<Long> systems = new ArrayList<>();
//			List<Long> actions = new ArrayList<>();
//			Map<Long, List<SelectedActionBean>> systemsHm = new HashMap<>();
//			String[] pair = null;
//			Long systemsId = null;
//			Long actionsId = null;
//			List<SelectedActionBean> selectedActionsBean = null;
//			SelectedActionBean actionBean = null;
//			for (int i = 0; i < actionsPerSystem.length; i++) {
//				pair = actionsPerSystem[i].split(":");
//				systemsId = Long.parseLong(pair[0]);
//				actionsId = Long.parseLong(pair[1]);
//				if (!systems.contains(systemsId)) {
//					systems.add(systemsId);
//				}
//				if (!actions.contains(actionsId)) {
//					actions.add(actionsId);
//				}
//				selectedActionsBean = systemsHm.get(systemsId);
//				if (selectedActionsBean == null) {
//					selectedActionsBean = new ArrayList<SelectedActionBean>();
//				}
//				actionBean = new SelectedActionBean();
//				actionBean.setActionsId(actionsId);
//				selectedActionsBean.add(actionBean);
//				systemsHm.put(systemsId, selectedActionsBean);
//			}
//			if (systems == null || systems.size() == 0 || actions == null || actions.size() == 0) {
//				return null;
//			}
//			AuthorizationsManagement management = new AuthorizationsManagement();
//			if (selectedSystems == null) {
//				// Load all systems and actions by ids.			
//				selectedSystems = management.getAllSystemsByIds(systems);
//				selectedActions = management.getAllActionsByIds(actions);
//			}
//			if (selectedSystems == null || selectedActions == null) {
//				Logger.log(Logger.ERROR_LEVEL, "No systems or actions found for current authorization.");
//				return null;
//			}
//			
//			List<SelectedSystemBean> loadedSystemBeans = new ArrayList<>();
//			SelectedSystemBean loadedSystemBean = null;
//			SelectedActionBean loadedActionBean = null;
//			List<SelectedActionBean> loadedActionsBean = null;
//			Systems tmpSystem = null;
//			for (int i = 0; i < systems.size(); i++) {
//				tmpSystem = null;
//				for (int j = 0; j < selectedSystems.size(); j++) {
//					if (systems.get(i) == selectedSystems.get(j).getSystemsId()) {
//						tmpSystem = selectedSystems.get(j);
//						break;
//					}
//				}
//				if (tmpSystem == null) {
//					continue;
//				}
//				systemsId = tmpSystem.getSystemsId();
//				selectedActionsBean = systemsHm.get(systemsId);
//				if (selectedActionsBean != null) {
//					loadedSystemBean = new SelectedSystemBean();
//					loadedSystemBean.setSystemsId(systemsId);
//					loadedSystemBean.setTitle(tmpSystem.getTitle());
//					loadedSystemBean.setOid(tmpSystem.getOid());
//					loadedActionsBean = new ArrayList<SelectedActionBean>();
//					for (int j = 0; j < selectedActionsBean.size(); j++) {
//						loadedActionBean = selectedActionsBean.get(j);
//						for (int k = 0; k < selectedActions.size(); k++) {
//							if (selectedActions.get(k).getActionsId() == loadedActionBean.getActionsId()) {
//								loadedActionBean.setDescription(selectedActions.get(k).getDescription());
//								loadedActionBean.setCode(selectedActions.get(k).getCode());
//								loadedActionsBean.add(loadedActionBean);
//								break;
//							}
//						}						
//					}
//					loadedSystemBean.setActions(loadedActionsBean);
//					loadedSystemBeans.add(loadedSystemBean);
//				}
//			}
//			systemsHm.clear();
//			selectedActionsBean.clear();
//			return loadedSystemBeans; 
//		}
//		return null;
//	}
}
