package com.ibs.myspace.portlet.bean.esb;

public class ESBMDTBean {
	private String municipality = null;	 
	private String municipalityId = null;	 
	private String municipalityStatus = null;	 
	private String reason = null;
	private String partida = null;
	private String period = null;
	private String installment = null;
	private String amount = null;
	private String paymentStatus = null;
	
	public String getMunicipality() {
		return municipality;
	}
	public void setMunicipality(String municipality) {
		this.municipality = municipality;
	}
	public String getMunicipalityId() {
		return municipalityId;
	}
	public void setMunicipalityId(String municipalityId) {
		this.municipalityId = municipalityId;
	}
	public String getMunicipalityStatus() {
		return municipalityStatus;
	}
	public void setMunicipalityStatus(String municipalityStatus) {
		this.municipalityStatus = municipalityStatus;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getPartida() {
		return partida;
	}
	public void setPartida(String partida) {
		this.partida = partida;
	}
	public String getPeriod() {
		return period;
	}
	public void setPeriod(String period) {
		this.period = period;
	}
	public String getInstallment() {
		return installment;
	}
	public void setInstallment(String installment) {
		this.installment = installment;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}
	
}
