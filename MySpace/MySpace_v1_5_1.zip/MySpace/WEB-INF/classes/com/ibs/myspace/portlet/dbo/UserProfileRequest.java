package com.ibs.myspace.portlet.dbo;

import java.sql.Timestamp;
import java.util.Hashtable;

import com.ibs.myspace.portlet.db.DBTransaction;
import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.db.PersistentObject;
import com.ibs.myspace.portlet.db.QueryComposer;
import com.ibs.myspace.portlet.db.QuerySet;
import com.ibs.myspace.portlet.utils.MySpaceUtils;


public class UserProfileRequest extends PersistentObject {

	private static String CLASS_NAME = UserProfileRequest.class.getName();
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "USERPROFILEREQUEST";
        sequenceName = "SEQ_USERPROFILEREQUEST";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "USERPROFILEREQUESTID");
        columnMap.put("userProfileId", "USERPROFILEID");
        columnMap.put("profileType", "PROFILETYPE");
        columnMap.put("eik", "EIK");
        columnMap.put("nameAndLegalForm", "NAMEANDLEGALFORM");
        columnMap.put("orderNumber", "ORDERNUMBER");
        columnMap.put("orderDocument", "ORDERDOCUMENT");
        columnMap.put("orderDocumentName", "ORDERDOCUMENTNAME");
        columnMap.put("orderDocumentSize", "ORDERDOCUMENTSIZE");
        columnMap.put("orderDocumentContentType", "ORDERDOCUMENTCONTENTTYPE");
        columnMap.put("accessKind", "ACCESSKIND");        
        columnMap.put("status", "STATUS");
        columnMap.put("dateCreated", "DATECREATED");
        columnMap.put("dateApproved", "DATEAPPROVED");
        columnMap.put("dateCanceled", "DATECANCELED");
        columnMap.put("cancelReason", "CANCELREASON");
        columnMap.put("userUID", "USERUID");
        columnMap.put("names", "NAMES");
        columnMap.put("profileStructureType", "PROFILESTRUCTURETYPE");
        columnMap.put("profileStructureTypeOther", "PROFILESTRUCTURETYPEOTHER");
        columnMap.put("leUserProfileId", "LEUSERPROFILEID");
        columnMap.put("reik", "REIK");

        querySet = QueryComposer.composeAll(table, sequenceName, columnMap);
    }
	
    public UserProfileRequest() {
        super(querySet);
    }
    
    private String userProfileId = null;
    private String profileType = null;
    private String eik = null;
    private String nameAndLegalForm = null;    
    private String orderNumber = null;
    private byte[] orderDocument = null;
    private String orderDocumentName = null;
    private String orderDocumentSize = null;
    private String orderDocumentContentType = null;
    private String accessKind = null;    
	private String status = null;
	private String dateCreated = null;
	private String dateApproved = null;
	private String dateCanceled = null;
	private String cancelReason = null;
	private String userUID = null;
	private String names = null;
	private String profileStructureType = null;
	private String profileStructureTypeOther = null;
	private String leUserProfileId = null;
	private String reik = null;
	
	
	public String getUserProfileId() {
		return userProfileId;
	}

	public void setUserProfileId(String userProfileId) {
		this.userProfileId = userProfileId;
	}

	public String getProfileType() {
		return profileType;
	}

	public void setProfileType(String profileType) {
		this.profileType = profileType;
	}

	public String getEik() {
		return eik;
	}

	public void setEik(String eik) {
		this.eik = eik;
	}

	public String getNameAndLegalForm() {
		return nameAndLegalForm;
	}

	public void setNameAndLegalForm(String nameAndLegalForm) {
		this.nameAndLegalForm = nameAndLegalForm;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public byte[] getOrderDocument() {
		return orderDocument;
	}

	public void setOrderDocument(byte[] orderDocument) {
		this.orderDocument = orderDocument;
	}

	public String getOrderDocumentName() {
		return orderDocumentName;
	}

	public void setOrderDocumentName(String orderDocumentName) {
		this.orderDocumentName = orderDocumentName;
	}

	public String getOrderDocumentSize() {
		return orderDocumentSize;
	}

	public void setOrderDocumentSize(String orderDocumentSize) {
		this.orderDocumentSize = orderDocumentSize;
	}

	public String getOrderDocumentContentType() {
		return orderDocumentContentType;
	}

	public void setOrderDocumentContentType(String orderDocumentContentType) {
		this.orderDocumentContentType = orderDocumentContentType;
	}

	public String getAccessKind() {
		return accessKind;
	}

	public void setAccessKind(String accessKind) {
		this.accessKind = accessKind;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Timestamp getDateCreated() {
		return (dateCreated != null) ? new Timestamp(Long.parseLong(dateCreated)) : null;
	}
	
	public void setDateCreated(String dateCreated) {  
		this.dateCreated = (dateCreated != null) ? String.valueOf(MySpaceUtils.date_TimestampToTimeMillis(dateCreated)) : null;
	}	
	
	public Timestamp getDateApproved() {
		return (dateApproved != null) ? new Timestamp(Long.parseLong(dateApproved)) : null;
	}
	
	public void setDateApproved(String dateApproved) {  
		this.dateApproved = (dateApproved != null) ? String.valueOf(MySpaceUtils.date_TimestampToTimeMillis(dateApproved)) : null;
	}	

	public Timestamp getDateCanceled() {
		return (dateCanceled != null) ? new Timestamp(Long.parseLong(dateCanceled)) : null;
	}
	
	public void setDateCanceled(String dateCanceled) {  
		this.dateCanceled = (dateCanceled != null) ? String.valueOf(MySpaceUtils.date_TimestampToTimeMillis(dateCanceled)) : null;
	}	

	public String getCancelReason() {
		return cancelReason;
	}

	public void setCancelReason(String cancelReason) {
		this.cancelReason = cancelReason;
	}
	
	public String getUserUID() {
		return userUID;
	}

	public void setUserUID(String userUID) {
		this.userUID = userUID;
	}

	public String getNames() {
		return names;
	}

	public void setNames(String names) {
		this.names = names;
	}

	public String getProfileStructureType() {
		return profileStructureType;
	}

	public void setProfileStructureType(String profileStructureType) {
		this.profileStructureType = profileStructureType;
	}

	public String getProfileStructureTypeOther() {
		return profileStructureTypeOther;
	}

	public void setProfileStructureTypeOther(String profileStructureTypeOther) {
		this.profileStructureTypeOther = profileStructureTypeOther;
	}

	public String getLeUserProfileId() {
		return leUserProfileId;
	}

	public void setLeUserProfileId(String leUserProfileId) {
		this.leUserProfileId = leUserProfileId;
	}

	public String getReik() {
		return reik;
	}

	public void setReik(String reik) {
		this.reik = reik;
	}

	public static UserProfileRequest findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileRequest) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}
	
	public static UserProfileRequest findByUserProfileId(final String userProfileId, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileRequest) findSingle(columnMap.get("userProfileId") + "='" + userProfileId + "'", CLASS_NAME, transaction);
	}

	public static void removeAllByUserProfileId(String userProfileId, DBTransaction transaction) throws FinderException, Exception {
		UserProfileRequest userProfileRequest = new UserProfileRequest();
		String cond = columnMap.get("userProfileId") + "='" + userProfileId + "'";
		userProfileRequest.removeConditional(cond, transaction);			
	}

	public static UserProfileRequest[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileRequests("1=1", transaction);
	}

	public static UserProfileRequest[] findAllUserProfileRequests(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final UserProfileRequest[] userProfileRequests = new UserProfileRequest[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				userProfileRequests[i] = (UserProfileRequest) tmp[i];
			}
			return userProfileRequests;
		} 
		return null;
	}
	
}
