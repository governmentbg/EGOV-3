package com.ibs.myspace.portlet.bean.esb;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ESBUserProfileSubscriberBean {
	private Long subscriberId = null;
	private String uid = null;
	private int profileType = 0;
	private int profileSubType = 0;
	private Map<String, ESBUserProfileSubscriptionBean> subscriptionsMap = null;
	private Map<String, List<ESBUserProfileSubscriptionBean>> subscriptionsParentMap = null;
	private ESBUserProfileSubscriptionBean rootSubscription = null;
	private List<ESBUserProfileSubscriptionBean> subscriptions = null;
	private Map<String, String> channelTitles = null;
	
	public Long getSubscriberId() {
		return subscriberId;
	}
	public void setSubscriberId(Long subscriberId) {
		this.subscriberId = subscriberId;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public int getProfileType() {
		return profileType;
	}
	public void setProfileType(int profileType) {
		this.profileType = profileType;
	}
	public int getProfileSubType() {
		return profileSubType;
	}
	public void setProfileSubType(int profileSubType) {
		this.profileSubType = profileSubType;
	}
	public Map<String, ESBUserProfileSubscriptionBean> getSubscriptionsMap() {
		return subscriptionsMap != null ? subscriptionsMap : new HashMap<String, ESBUserProfileSubscriptionBean>();
	}
	public void setSubscriptionsMap(Map<String, ESBUserProfileSubscriptionBean> subscriptionsMap) {
		this.subscriptionsMap = subscriptionsMap;
	}
	public Map<String, List<ESBUserProfileSubscriptionBean>> getSubscriptionsParentMap() {
		return subscriptionsParentMap != null ? subscriptionsParentMap : new HashMap<String, List<ESBUserProfileSubscriptionBean>>();
	}
	public void setSubscriptionsParentMap(Map<String, List<ESBUserProfileSubscriptionBean>> subscriptionsParentMap) {
		this.subscriptionsParentMap = subscriptionsParentMap;
	}
	public ESBUserProfileSubscriptionBean getRootSubscription() {
		return rootSubscription;
	}
	public void setRootSubscription(ESBUserProfileSubscriptionBean rootSubscription) {
		this.rootSubscription = rootSubscription;
	}
	public List<ESBUserProfileSubscriptionBean> getSubscriptions() {
		return subscriptions;
	}
	public void setSubscriptions(List<ESBUserProfileSubscriptionBean> subscriptions) {
		this.subscriptions = subscriptions;
	}
	public Map<String, String> getChannelTitles() {
		return channelTitles != null ? channelTitles : new HashMap<String, String>();
	}
	public void setChannelTitles(Map<String, String> channelTitles) {
		this.channelTitles = channelTitles;
	}
	
}
