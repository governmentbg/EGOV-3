package com.ibs.myspace.portlet.model;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SystemsMapper {
	public Systems getSystem(ResultSet resultSet) throws SQLException {
		Systems system = new Systems();
		system.setSystemsId(resultSet.getLong("systemsId"));
		system.setTitle(resultSet.getString("title"));
		system.setOid(resultSet.getString("oid"));
		system.setOperationTime(resultSet.getTimestamp("operationTime"));
		system.setUserId(resultSet.getString("userId"));
		return system;
	}
}
