package com.ibs.myspace.portlet;

import java.time.Instant;

import com.ibs.myspace.portlet.management.ETranslationRequestManagement;
//import com.ibs.myspace.portlet.utils.Logger;

public class MySpaceETranslationRequestCleaner {

	private static int sleepTime = 8 * 60 * 60 * 1000; // 8 hours
	private static int validPeriod = 24 * 60 * 60 * 1000; // 24 hours
	private static boolean enableMySpaceETranslationRequestCleanerThread = false;
	private static boolean startMySpaceETranslationRequestCleanerThread = true;
	public static boolean isRunning = false;
	public static boolean initialized = false;
	private static MySpaceETranslationRequestCleanerThread mySpaceETranslationRequestCleanerThread = null;

	public MySpaceETranslationRequestCleaner() {}

	public static class MySpaceETranslationRequestCleanerThread extends Thread {

		public void run() {
			ETranslationRequestManagement management = new ETranslationRequestManagement();
			long startTime = Instant.now().getEpochSecond();
			long expireTime = System.currentTimeMillis();
			int results = 0;
			System.out.println("------ MySpaceETranslationRequestCleanerThread start");
			//Logger.log(Logger.DEBUG_LEVEL, "------ MySpaceETranslationRequestCleanerThread start");
			while (MySpaceETranslationRequestCleaner.startMySpaceETranslationRequestCleanerThread) {				
				if (MySpaceETranslationRequestCleaner.enableMySpaceETranslationRequestCleanerThread) {
					try {							
						MySpaceETranslationRequestCleaner.isRunning = true;							
						startTime = Instant.now().getEpochSecond();
						expireTime = System.currentTimeMillis() - validPeriod;						
						
						// Clear all expired translation requests.
						results = management.clearExpiredETranslationRequests(expireTime, null);
						if (results > 0) {
							System.out.println("------ MySpaceETranslationRequestCleanerThread cleared [" + results + "]");							
							//Logger.log(Logger.DEBUG_LEVEL, "------ MySpaceETranslationRequestCleanerThread cleared [" + results + "]");							
						}																
						MySpaceETranslationRequestCleaner.isRunning = false;
						
						double duration = Instant.now().getEpochSecond() - startTime;
						System.out.println("------ MySpaceETranslationRequestCleanerThread completed for " + duration + " seconds.");
						//Logger.log(Logger.DEBUG_LEVEL, "------ MySpaceETranslationRequestCleanerThread completed for " + duration + " minutes.");
					} catch (Exception e) {
						e.printStackTrace();
						MySpaceETranslationRequestCleaner.isRunning = false;
					}
				}
				try {
					System.out.println("------ MySpaceETranslationRequestCleanerThread will sleep for another: 8 hours.");
					//Logger.log(Logger.DEBUG_LEVEL, "------ MySpaceETranslationRequestCleanerThread will sleep for another: " + (MySpaceETranslationRequestCleaner.sleepTime / 60 * 60 * 1000) + " hours.");
					MySpaceETranslationRequestCleaner.isRunning = false;
					sleep(MySpaceETranslationRequestCleaner.sleepTime);
				} catch (InterruptedException e) {
				}
			}
			MySpaceETranslationRequestCleaner.isRunning = false;
			System.out.println("------ MySpaceETranslationRequestCleanerThread stop");
			//Logger.log(Logger.DEBUG_LEVEL, "------ MySpaceETranslationRequestCleanerThread stop");
		}
	}

	public static synchronized void init() {
		enableMySpaceETranslationRequestCleanerThread = true;
		mySpaceETranslationRequestCleanerThread = new MySpaceETranslationRequestCleanerThread();
		mySpaceETranslationRequestCleanerThread.start();
	}

	public static void shutdown() {
		enableMySpaceETranslationRequestCleanerThread = false;
		startMySpaceETranslationRequestCleanerThread = false;
		mySpaceETranslationRequestCleanerThread.interrupt();
		long startTime = Instant.now().getEpochSecond();
		while (isRunning) {
			System.out.println("------ Waiting MySpaceETranslationRequestCleaner for stop signal...");
//			Logger.log(Logger.DEBUG_LEVEL, "------ Waiting MySpaceETranslationRequestCleaner for stop signal...");
			// if we wait for more than 1 minute, it looks like it hangs, so break from here.
			if (Instant.now().getEpochSecond() - startTime > 60) {
				break;
			}
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			}
		}
		System.out.println("------ MySpaceETranslationRequestCleaner HAS BEEN KILLED SUCCESSFULLY!");
//		Logger.log(Logger.DEBUG_LEVEL, "------ MySpaceETranslationRequestCleaner HAS BEEN KILLED SUCCESSFULLY!");
	}
		
}
