package com.ibs.myspace.portlet.dbo;

import java.sql.Timestamp;
import java.util.Hashtable;

import com.ibs.myspace.portlet.db.DBTransaction;
import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.db.PersistentObject;
import com.ibs.myspace.portlet.db.QueryComposer;
import com.ibs.myspace.portlet.db.QuerySet;
import com.ibs.myspace.portlet.utils.MySpaceUtils;


public class UserProfileMyFavorites extends PersistentObject {

	private static String CLASS_NAME = UserProfileMyFavorites.class.getName();
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "USERPROFILEMYFAVORITES";
        sequenceName = "SEQ_USERPROFILEMYFAVORITES";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "USERPROFILEMYFAVORITESID");
        columnMap.put("userUID", "USERUID");
        columnMap.put("contentUUID", "CONTENTUUID");
        columnMap.put("creationDate", "CREATIONDATE");
        querySet = QueryComposer.composeAll(table, sequenceName, columnMap);
    }
	
    public UserProfileMyFavorites() {
        super(querySet);
    }
    
    private String userUID = null;
	private String contentUUID = null;
	private String creationDate = null;
	
	public String getUserUID() {
		return userUID;
	}

	public void setUserUID(String userUID) {
		this.userUID = userUID;
	}


	public String getContentUUID() {
		return contentUUID;
	}

	public void setContentUUID(String contentUUID) {
		this.contentUUID = contentUUID;
	}

	public Timestamp getCreationDate() {
		return (creationDate != null) ? new Timestamp(Long.parseLong(creationDate)) : null;
	}
	
	public void setCreationDate(String creationDate) {  
		this.creationDate = (creationDate != null) ? String.valueOf(MySpaceUtils.date_TimestampToTimeMillis(creationDate)) : null;
	}	
	
	public static UserProfileMyFavorites findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileMyFavorites) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}
	
	public static UserProfileMyFavorites[] findAllByUserUID(final String userUID, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileMyFavorites(columnMap.get("userUID") + "='" + userUID + "' ORDER BY " + columnMap.get("creationDate") + " DESC", transaction);
	}
	
	public static UserProfileMyFavorites[] findAllByContentUID(final String contentUUID, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileMyFavorites(columnMap.get("contentUUID") + "='" + contentUUID + "'", transaction);
	}
	
	public static UserProfileMyFavorites findByUserUIDAndContentUUID(final String userUID, final String contentUUID, final DBTransaction transaction) throws FinderException, Exception {
		String query = columnMap.get("userUID") + "='" + userUID + "'";
		query += " AND ";
		query += columnMap.get("contentUUID") + "='" + contentUUID + "'";
		return (UserProfileMyFavorites) findSingle(query, CLASS_NAME, transaction);
	}
	
	public static void removeAllByIds(String ids, DBTransaction transaction) throws FinderException, Exception {
		UserProfileMyFavorites userProfileMyFavorites = new UserProfileMyFavorites();
		String cond = columnMap.get("id") + " IN (" + ids + ")";
		userProfileMyFavorites.removeConditional(cond, transaction);			
	}
	
	public static void removeAllByUserUID(String userUID, DBTransaction transaction) throws FinderException, Exception {
		UserProfileMyFavorites userProfileMyFavorites = new UserProfileMyFavorites();
		String cond = columnMap.get("userUID") + "='" + userUID + "'";
		userProfileMyFavorites.removeConditional(cond, transaction);			
	}
	
	public static void removeByUserUIDAndContentUUID(String userUID, String contentUUID, DBTransaction transaction) throws FinderException, Exception {
		UserProfileMyFavorites userProfileMyFavorites = new UserProfileMyFavorites();
		String cond = columnMap.get("userUID") + "='" + userUID + "' AND " + columnMap.get("contentUUID") + "='" + contentUUID + "'";
		userProfileMyFavorites.removeConditional(cond, transaction);			
	}

	
	public static UserProfileMyFavorites[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileMyFavorites("1=1", transaction);
	}

	public static UserProfileMyFavorites[] findAllUserProfileMyFavorites(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final UserProfileMyFavorites[] userProfileMyFavorites = new UserProfileMyFavorites[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				userProfileMyFavorites[i] = (UserProfileMyFavorites) tmp[i];
			}
			return userProfileMyFavorites;
		} 
		return null;
	}
	
}
