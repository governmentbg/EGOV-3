package com.ibs.myspace.portlet.management;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.ibs.myspace.communicator.ESBCommunicator;
import com.ibs.myspace.portlet.bean.EDeliveryProfileBean;
import com.ibs.myspace.portlet.bean.EDeliverySubjectBean;
import com.ibs.myspace.portlet.utils.Logger;


public class EDeliveryManagement {
	
	public EDeliveryProfileBean[] loadAllProfiles(String personalIdentifier) {	
		Logger.log(Logger.DEBUG_LEVEL, "EDeliveryManagement -> loadAllProfiles(" + personalIdentifier + ")");
		try {
			Logger.log(Logger.DEBUG_LEVEL, "EDeliveryManagement -> loadAllProfiles() call ESBCommunicator -> eDeliveryPersonHasRegistration(" + personalIdentifier + ")...");
			ESBCommunicator communicator = new ESBCommunicator();			
	        String result = communicator.eDeliveryPersonHasRegistration(personalIdentifier);
	        Logger.log(Logger.DEBUG_LEVEL, "EDeliveryManagement -> loadAllProfiles() eDeliveryPersonHasRegistration Result: " + result);	        
	        try {
	        	if (result != null && result.trim().length() > 0) {
		        	JSONObject jsonObject = new JSONObject(result);
		            JSONObject jo = null;
		            boolean hasRegistration = "true".equalsIgnoreCase(jsonObject.get("HasRegistration").toString());
		            if (jsonObject.has("AccessibleProfiles")) {
			            JSONArray ja = jsonObject.getJSONArray("AccessibleProfiles");
			            if (hasRegistration && ja != null && ja.length() > 0) {
			            	Logger.log(Logger.DEBUG_LEVEL, "EDeliveryManagement -> loadAllProfiles(): total:" + ja.length());
			            	// add one extra for tests.
	//		            	EDeliveryProfileBean[] eDeliveryProfileBeans = new EDeliveryProfileBean[ja.length() + 1];		            	
			            	EDeliveryProfileBean[] eDeliveryProfileBeans = new EDeliveryProfileBean[ja.length()];		            	
			            	EDeliveryProfileBean eDeliveryProfileBean = null;
			            	for (int i = 0; i < ja.length(); i++) {
			            		jo = ja.getJSONObject(i);
			            		Logger.log(Logger.DEBUG_LEVEL, "EDeliveryManagement -> loadAllProfiles():EIK=" + jo.get("EIK").toString());
			            		Logger.log(Logger.DEBUG_LEVEL, "EDeliveryManagement -> loadAllProfiles():Name=" + jo.get("Name").toString());
			            		Logger.log(Logger.DEBUG_LEVEL, "EDeliveryManagement -> loadAllProfiles():ProfileType=" + jo.get("ProfileType").toString());
			            		eDeliveryProfileBean = new EDeliveryProfileBean();
			            		eDeliveryProfileBean.setEik(jo.get("EIK").toString());
			            		eDeliveryProfileBean.setName(jo.get("Name").toString());
			            		eDeliveryProfileBean.setProfileType(jo.get("ProfileType").toString());
			            		eDeliveryProfileBeans[i] = eDeliveryProfileBean;
							}
			            	// add one extra for tests.
	//		            	eDeliveryProfileBean = new EDeliveryProfileBean();
	//	            		eDeliveryProfileBean.setEik("000627597");
	//	            		eDeliveryProfileBean.setName("Агенция \"Митници\"");
	//		            	eDeliveryProfileBeans[ja.length()] = eDeliveryProfileBean;
			            	return eDeliveryProfileBeans;		            	
			            }
		            }
	        	}
	       } catch (JSONException err){
	           err.printStackTrace();
	       }
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public EDeliverySubjectBean loadSubjectInfo(String personalIdentifier) {
		Logger.log(Logger.DEBUG_LEVEL, "EDeliveryManagement -> loadSubjectInfo(" + personalIdentifier + ")");
		try {
			Logger.log(Logger.DEBUG_LEVEL, "EDeliveryManagement -> loadSubjectInfo() call ESBCommunicator -> eDeliverySubjectHasRegistration(" + personalIdentifier + ")...");
			ESBCommunicator communicator = new ESBCommunicator();			
	        String result = communicator.eDeliverySubjectHasRegistration(personalIdentifier);
	        Logger.log(Logger.DEBUG_LEVEL, "EDeliveryManagement -> loadSubjectInfo() eDeliverySubjectHasRegistration Result: " + result);	        
	        try {
	        	if (result != null && result.trim().length() > 0) {
		        	JSONObject jsonObject = new JSONObject(result);
		            EDeliverySubjectBean eDeliverySubjectBean = null;
		            boolean hasRegistration = "true".equalsIgnoreCase(jsonObject.get("HasRegistration").toString());
		            if (hasRegistration) {
		            	eDeliverySubjectBean = new EDeliverySubjectBean();
		            	eDeliverySubjectBean.setHasRegistration(hasRegistration);
		            	eDeliverySubjectBean.setIdentificator(jsonObject.get("Identificator").toString());
		            	if (jsonObject.get("SubjectInfo") != null) {
		            		JSONObject joInfo = new JSONObject(jsonObject.get("SubjectInfo").toString());  
		            		eDeliverySubjectBean.setElectronicSubjectId(joInfo.get("ElectronicSubjectId").toString());
		            		eDeliverySubjectBean.setElectronicSubjectName(joInfo.get("ElectronicSubjectName").toString());
		            		eDeliverySubjectBean.setEmail(joInfo.get("Email").toString());
		            		eDeliverySubjectBean.setActivated("true".equalsIgnoreCase(joInfo.get("IsActivated").toString()));
		            		eDeliverySubjectBean.setPhoneNumber(joInfo.get("PhoneNumber").toString());
		            		eDeliverySubjectBean.setProfileType(joInfo.get("ProfileType").toString());
		            		// Extra save for later comparison logic.
		            		if (eDeliverySubjectBean.getElectronicSubjectName() == null) {
		            			eDeliverySubjectBean.setElectronicSubjectName("");
		            		}
		            		if (eDeliverySubjectBean.getEmail() == null) {
		            			eDeliverySubjectBean.setEmail("");
		            		}
		            		if (eDeliverySubjectBean.getPhoneNumber() == null) {
		            			eDeliverySubjectBean.setPhoneNumber("");
		            		}
		            	}
		            }
		            return eDeliverySubjectBean;
	        	}
	       } catch (JSONException err){
	           err.printStackTrace();
	       }
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
}
