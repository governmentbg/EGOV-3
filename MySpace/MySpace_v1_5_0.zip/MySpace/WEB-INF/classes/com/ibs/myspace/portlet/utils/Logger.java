package com.ibs.myspace.portlet.utils;

import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.MySpacePortlet;

public class Logger {

    public final static int ERROR_LEVEL = 0;
    public final static int DEBUG_LEVEL = 2;

    public synchronized static void log(String logMessage) {
        System.err.println(logMessage);
    }

    public synchronized static void log(int logLevel, String logMessage) {
        String message = MySpaceConstants._PRODUCT_NAME + " " + MySpaceConstants._PRODUCT_VERSION + " | ";
        if (logLevel == ERROR_LEVEL || (MySpacePortlet.debug && logLevel == DEBUG_LEVEL)) {
             message += logMessage;
             System.err.println(message);
        }        
    }
    
    public synchronized static void println(String message) {
    	log(ERROR_LEVEL, message);
    }
}
