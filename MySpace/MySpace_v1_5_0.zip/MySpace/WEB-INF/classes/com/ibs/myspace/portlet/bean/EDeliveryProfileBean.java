package com.ibs.myspace.portlet.bean;

public class EDeliveryProfileBean {
	private String eik = null;
	private String name = null;
	private String profileType = null;
	
	public String getEik() {
		return eik;
	}
	
	public void setEik(String eik) {
		this.eik = eik;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getProfileType() {
		return profileType;
	}
	
	public void setProfileType(String profileType) {
		this.profileType = profileType;
	}
    
}
