package com.ibs.myspace.portlet.db;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;

import com.ibs.myspace.portlet.utils.Logger;

@SuppressWarnings("rawtypes")
public class DBPool extends Object {

    private static BasicDataSource dbcpSource = null;
    private static DataSource source = null;
    private static boolean flag = true;
    private static boolean status = true;
    private static Thread poolMonitor = null;
    private static PrintWriter logWriter = null;

    static {

        try {
            logWriter = new PrintWriter(new FileOutputStream(new File("pool.log")));
        } catch (FileNotFoundException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        if (DBResources._DO_POOLING) {
        	Logger.log(Logger.DEBUG_LEVEL, "------ DB starting using pooling");
        	Logger.log(Logger.DEBUG_LEVEL, "------ used pool is '" + DBResources._POOLNAME + "'");
            if ("DBCP".equals(DBResources._POOLNAME)) {
                dbcpSource = setupDataSourcePDCP();
                if (poolMonitor == null) {
                    poolMonitor = new Thread(new Runnable() {
                        public void run() {
                            monitor();
                        }
                    });
                    poolMonitor.start();
                }
            } else {
                source = setupDataSource();
            }
        } else {
        	Logger.log(Logger.DEBUG_LEVEL, "------ DB starting, no pooling");
            try {
                Class driverClass = null;
                try {
                    driverClass = Class.forName(DBResources._DRIVERCLASS);
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
                Object drv = driverClass.newInstance();
                DriverManager.registerDriver((java.sql.Driver) drv);
                DriverManager.setLogWriter(logWriter);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        // MariaDB loading...
        try {
            Class driverClass = null;
            try {
                driverClass = Class.forName(DBResources._MARIADB_DRIVERCLASS);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            Object drv = driverClass.newInstance();
            DriverManager.registerDriver((java.sql.Driver) drv);
            DriverManager.setLogWriter(logWriter);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Logger.log(Logger.DEBUG_LEVEL, "------ DB end");
    } // static

    public static DataSource setupDataSource() {
        DataSource ds = null;
        try {
            InitialContext ctx = new InitialContext();
            ds = (DataSource) ctx.lookup(DBResources._POOLNAME);
        } catch (NamingException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        try {
            ds.setLogWriter(logWriter);
        } catch (SQLException e) {
            e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
        }
        return ds;
    }

    public static BasicDataSource setupDataSourcePDCP() {

        BasicDataSource ds = new BasicDataSource();
        ds.setDriverClassName(DBResources._DRIVERCLASS);
        ds.setUsername(DBResources._USER);
        ds.setPassword(DBResources._PASSWORD);
        ds.setUrl(DBResources._URL);

        // The initial number of connections that are created when the pool is started.
        ds.setInitialSize(DBResources._INITIALCONNECTIONS);

        // The maximum number of active connections that can be allocated from this pool at the same time, or zero for no limit.
        ds.setMaxActive(DBResources._MAXACTIVECONNECTIONS);

        // The minimum number of active connections that can remain idle in the pool, without extra ones being created, or 0 to create none.
        ds.setMinIdle(DBResources._MINIDLECONNECTIONS);

        // The maximum number of active connections that can remain idle in the pool, without extra ones being released, or zero for no limit.
        ds.setMaxIdle(DBResources._MAXIDLECONNECTIONS);

        // The maximum number of milliseconds that the pool will wait (when there are no available connections) for a connection to be returned before throwing an exception, or -1 to wait indefinitely.
        ds.setMaxWait(DBResources._MAXWAITFORPOOLEDCONNECTION);

        // The indication of whether objects will be validated before being borrowed from the pool.
        ds.setTestOnBorrow(DBResources._TESTBEFORE);
        // The indication of whether objects will be validated before being returned to the pool.
        ds.setTestOnReturn(DBResources._TESTAFTER);
        // The SQL query that will be used to validate connections from this pool before returning them to the caller.
        ds.setValidationQuery(DBResources._SQLVALIDATIONSTRING);
        // The default auto-commit state of connections created by this pool.
        ds.setDefaultAutoCommit(true);

        return ds;
    }

    public static synchronized Connection getConnection() {
    	
    	Connection con = null;
    	if (DBResources._DO_POOLING) {
    		try {
    			if ("DBCP".equals(DBResources._POOLNAME)) {
    				con = dbcpSource.getConnection();
    			} else {
    				con = source.getConnection();
    				con.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
    			}
    		} catch (SQLException e) {
    			e.printStackTrace();
    			Logger.log(Logger.ERROR_LEVEL, e.getMessage());
    		}
    	} else {
    		try {
    			con = DriverManager.getConnection(DBResources._URL, DBResources._USER, DBResources._PASSWORD);
    			con.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
    			con.setAutoCommit(true);
    		} catch (Exception e) {
    			e.printStackTrace();
    			Logger.log(Logger.ERROR_LEVEL, "------ DBPool : getConnection : " + e.getMessage());
    		}
    	}
    	return con;
    }
    
    public static synchronized Connection getMariaDBConnection() {

        Connection con = null;
        try {
        	if (Base.TEST_ENVIRONMENT) {
        		con = DriverManager.getConnection(DBResources._MARIADB_TEST_URL, DBResources._MARIADB_TEST_USER, DBResources._MARIADB_TEST_PASSWORD);
        	} else {
        		con = DriverManager.getConnection(DBResources._MARIADB_URL, DBResources._MARIADB_USER, DBResources._MARIADB_PASSWORD);
        	}
            con.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
            con.setAutoCommit(true);
        } catch (Exception e) {
            e.printStackTrace();
            Logger.log(Logger.ERROR_LEVEL, "------ DBPool : getMariaDBConnection : " + e.getMessage());
        }
        return con;
    }

    public static void monitor() {
        while (flag) {
            if ("DBCP".equals(DBResources._POOLNAME)) {
            	Logger.log(Logger.DEBUG_LEVEL, "------ Connections  ACTIVE : " + dbcpSource.getNumActive() + "\tConnections IDLE : " + dbcpSource.getNumIdle());
            }
            try {
                Thread.sleep(DBResources._CONNECTIONMONITOR);
            } catch (InterruptedException e) {
            } catch (Exception e) {
            	Logger.log(Logger.DEBUG_LEVEL, "------ DBPool : monitor : " + e.getMessage());
            }
        }
        status = false;
    }

    public static void shutdownDataSource() {
        if (!DBResources._DO_POOLING)
            return;

        flag = false;
        poolMonitor.interrupt();
        while (status) {
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
            }
        }
        if (!status) Logger.log(Logger.DEBUG_LEVEL, "------ POOL MONITOR THREAD HAS BEEN KILLED SUCCESSFULLY!");
        if ("DBCP".equals(DBResources._POOLNAME)) {
            try {
                dbcpSource.close();
            } catch (SQLException e) {
                e.printStackTrace();
                Logger.log(Logger.DEBUG_LEVEL, "------ DBPool : shutdownDataSource : " + e.getMessage());
            }
        }
        Logger.log(Logger.DEBUG_LEVEL, "------ DataSource is closed!");
    }

}