package com.ibs.myspace.portlet.dbo;

import java.sql.Timestamp;
import java.util.Hashtable;

import com.ibs.myspace.portlet.db.DBTransaction;
import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.db.PersistentObject;
import com.ibs.myspace.portlet.db.QueryComposer;
import com.ibs.myspace.portlet.db.QuerySet;
import com.ibs.myspace.portlet.utils.MySpaceUtils;


public class UserProfileAuditLog extends PersistentObject {

	private static String CLASS_NAME = UserProfileAuditLog.class.getName();
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "USERPROFILEAUDITLOG";
        sequenceName = "SEQ_USERPROFILEAUDITLOG";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "USERPROFILEAUDITLOGID");
        columnMap.put("userUID", "USERUID");
        columnMap.put("contentUUID", "CONTENTUUID");
        columnMap.put("type", "OPERATIONTYPE");
        columnMap.put("remoteIPAddress", "REMOTEIPADDRESS");
        columnMap.put("creationDate", "CREATIONDATE");
        querySet = QueryComposer.composeAll(table, sequenceName, columnMap);
    }
	
    public UserProfileAuditLog() {
        super(querySet);
    }
    
    private String userUID = null;
    private String contentUUID = null;
    private String type = null;
	private String remoteIPAddress = null;
	private String creationDate = null;
	
	public String getUserUID() {
		return userUID;
	}

	public void setUserUID(String userUID) {
		this.userUID = userUID;
	}


	public String getContentUUID() {
		return contentUUID;
	}

	public void setContentUUID(String contentUUID) {
		this.contentUUID = contentUUID;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getRemoteIPAddress() {
		return remoteIPAddress;
	}

	public void setRemoteIPAddress(String remoteIPAddress) {
		this.remoteIPAddress = remoteIPAddress;
	}

	public Timestamp getCreationDate() {
		return (creationDate != null) ? new Timestamp(Long.parseLong(creationDate)) : null;
	}
	
	public void setCreationDate(String creationDate) {  
		this.creationDate = (creationDate != null) ? String.valueOf(MySpaceUtils.date_TimestampToTimeMillis(creationDate)) : null;
	}	
	
	public static UserProfileAuditLog findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileAuditLog) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}
	
	public static UserProfileAuditLog[] findAllByUserUID(final String userUID, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileAuditLogs(columnMap.get("userUID") + "='" + userUID + "'", transaction);
	}
	
	public static UserProfileAuditLog[] findAllByContentUID(final String contentUUID, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileAuditLogs(columnMap.get("contentUUID") + "='" + contentUUID + "'", transaction);
	}
	
	public static UserProfileAuditLog[] findAllByUserUIDAndType(final String userUID, final String type, final int limit, final DBTransaction transaction) throws FinderException, Exception {
		String query = columnMap.get("userUID") + "='" + userUID + "'";
		query += " AND ";
		query += columnMap.get("type") + "='" + type + "'";
		query += " ORDER BY " + columnMap.get("creationDate") + " DESC";
		if (limit > 0) {
			query += " FETCH FIRST " + limit + " ROWS ONLY";
		}
		System.out.println("query=" + query);
		return findAllUserProfileAuditLogs(query, transaction);
	}
	
	public static UserProfileAuditLog findByUserUIDAndContentUUID(final String userUID, final String contentUUID, final DBTransaction transaction) throws FinderException, Exception {
		String query = columnMap.get("userUID") + "='" + userUID + "'";
		query += " AND ";
		query += columnMap.get("contentUUID") + "='" + contentUUID + "'";
		return (UserProfileAuditLog) findSingle(query, CLASS_NAME, transaction);
	}
	
	public static UserProfileAuditLog findByUserUIDAndContentUUIDAndType(final String userUID, final String contentUUID, final String type, final DBTransaction transaction) throws FinderException, Exception {
		String query = columnMap.get("userUID") + "='" + userUID + "'";
		query += " AND ";
		query += columnMap.get("contentUUID") + "='" + contentUUID + "'";
		query += " AND ";
		query += columnMap.get("type") + "='" + type + "'";
		return (UserProfileAuditLog) findSingle(query, CLASS_NAME, transaction);
	}
	
	public static void removeAllByUserUID(String userUID, DBTransaction transaction) throws FinderException, Exception {
		UserProfileAuditLog userProfileMyFavorites = new UserProfileAuditLog();
		String cond = columnMap.get("userUID") + "='" + userUID + "'";
		userProfileMyFavorites.removeConditional(cond, transaction);			
	}
	
	public static void removeByUserUIDAndContentUUID(String userUID, String contentUUID, DBTransaction transaction) throws FinderException, Exception {
		UserProfileAuditLog userProfileMyFavorites = new UserProfileAuditLog();
		String cond = columnMap.get("userUID") + "='" + userUID + "' AND " + columnMap.get("contentUUID") + "='" + contentUUID + "'";
		userProfileMyFavorites.removeConditional(cond, transaction);			
	}

	public static UserProfileAuditLog[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileAuditLogs("1=1", transaction);
	}

	public static UserProfileAuditLog[] findAllUserProfileAuditLogs(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final UserProfileAuditLog[] userProfileAuditLogs = new UserProfileAuditLog[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				userProfileAuditLogs[i] = (UserProfileAuditLog) tmp[i];
			}
			return userProfileAuditLogs;
		} 
		return null;
	}
	
}
