package com.ibs.myspace.portlet.management;

import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.dbo.UserProfileXCRole;

public class UserProfileXCRoleManagement {
	
	public UserProfileXCRole[] loadAllXCRolesByUserProfileIdAndUserUID(String userProfileId, String userUID) {
		try {
			return UserProfileXCRole.findAllByUserProfileIdAndUserUID(userProfileId, userUID, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
}
