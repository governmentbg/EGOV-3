package com.ibs.myspace.communicator;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.bean.esb.ESBUserProfileSubscriberBean;
import com.ibs.myspace.portlet.bean.esb.ESBUserProfileSubscriberChannelBean;
import com.ibs.myspace.portlet.bean.esb.ESBUserProfileSubscriptionBean;

public class ESBUtils {
	
	public List<ESBUserProfileSubscriptionBean> getSubscriptionPath(Map<String, ESBUserProfileSubscriptionBean> subscriptionsMap, String parentId) {		 
		List<ESBUserProfileSubscriptionBean> path = new ArrayList<>();
		if (parentId == null || parentId.equalsIgnoreCase("0")) {
			return path;
		}
		ESBUserProfileSubscriptionBean subscription = subscriptionsMap.get(parentId);
		if (subscription != null && subscription.getParentId() != 0) {
			path.add(subscription);
			subscription = subscriptionsMap.get(String.valueOf(subscription.getParentId()));
			if (subscription != null && subscription.getParentId() != 0) {
				while (subscription != null && subscription.getParentId() != 0) {
					path.add(subscription);
					subscription = subscriptionsMap.get(String.valueOf(subscription.getParentId()));
				}
			}
		}
		return path;
	}
	
	public String getSubscriptionPathString(List<ESBUserProfileSubscriptionBean> path) {
		if (path == null || path.isEmpty()) return "";
		String html = "";
		for (int i = path.size() - 1; i >= 0 ; i--) {
			if (i < path.size() - 1) {
				html += " > ";
			}
			html += path.get(i).getDescription();
		}
		return html;
	}
	
	public String printJsonSubscriptions(List<ESBUserProfileSubscriptionBean> subscriptions, ESBUserProfileSubscriberBean rootBean, String json) {
		if (subscriptions != null && !subscriptions.isEmpty()) {	
			List<ESBUserProfileSubscriptionBean> children = null;
			for (int i = 0; i < subscriptions.size(); i++) {
				System.out.println("NAME = " + subscriptions.get(i).getDescription() + ",status=" + subscriptions.get(i).getStatus());
				if (MySpaceConstants.ESB_SUB_STATUS_SUBSCRIBED.equalsIgnoreCase(subscriptions.get(i).getStatus())) {
					continue;
				}
				if (i > 0) {
					json += ",";
				}
				json += "{";
				json += "id:" + subscriptions.get(i).getId() + ",";
				json += "parentId:" + subscriptions.get(i).getParentId() + ",";
//				json += "status:" + JSONObject.valueToString(subscriptions.get(i).getStatus()) + ",";
				json += "text:" + JSONObject.valueToString(subscriptions.get(i).getDescription());				 
												
				children = rootBean.getSubscriptionsParentMap().get(String.valueOf(subscriptions.get(i).getId()));
				if (children != null && !children.isEmpty()) {
					json += ",children:[";
					json = printJsonSubscriptions(children, rootBean, json);
					json += "]";
				}
				
				json += "}";
			}
		}
		return json;
	}
	
	private List<ESBUserProfileSubscriptionBean> recursiveLoadAvailableSubscriptions(List<ESBUserProfileSubscriptionBean> subscriptions, List<ESBUserProfileSubscriptionBean> availableSubscriptions, ESBUserProfileSubscriberBean rootBean) {
		if (subscriptions != null && !subscriptions.isEmpty()) {	
			List<ESBUserProfileSubscriptionBean> children = null;
			for (int i = 0; i < subscriptions.size(); i++) {				
				if (MySpaceConstants.ESB_SUB_STATUS_SUBSCRIBED.equalsIgnoreCase(subscriptions.get(i).getStatus())) {
					continue;
				}
				availableSubscriptions.add(subscriptions.get(i));
				children = rootBean.getSubscriptionsParentMap().get(String.valueOf(subscriptions.get(i).getId()));
				if (children != null && !children.isEmpty()) {
					availableSubscriptions = recursiveLoadAvailableSubscriptions(children, availableSubscriptions, rootBean);					
				}
			}
		}
		return availableSubscriptions;
	}
	
	public List<ESBUserProfileSubscriptionBean> removeSubscribedEvents(ESBUserProfileSubscriberBean rootBean) {
		if (rootBean == null) return null;
		List<ESBUserProfileSubscriptionBean> subscriptions = rootBean.getSubscriptions();
		List<ESBUserProfileSubscriptionBean> availableSubscriptions = new ArrayList<ESBUserProfileSubscriptionBean>();
		List<ESBUserProfileSubscriptionBean> topSubscriptions = new ArrayList<ESBUserProfileSubscriptionBean>();
		for (int i = 0; i < subscriptions.size(); i++) {
			if (subscriptions.get(i).getParentId() == rootBean.getRootSubscription().getId()) {
				topSubscriptions.add(subscriptions.get(i));
			}
		}
		if (!topSubscriptions.isEmpty()) {
			availableSubscriptions = recursiveLoadAvailableSubscriptions(topSubscriptions, availableSubscriptions, rootBean);			
		}
		return availableSubscriptions;
	}
	
	public List<ESBUserProfileSubscriptionBean> getTopSubscriptions(ESBUserProfileSubscriberBean rootBean, boolean notSubscribed) {
		if (rootBean == null) return null;
		List<ESBUserProfileSubscriptionBean> subscriptions = rootBean.getSubscriptions();
		List<ESBUserProfileSubscriptionBean> topSubscriptions = new ArrayList<ESBUserProfileSubscriptionBean>();
		for (int i = 0; i < subscriptions.size(); i++) {
			if (subscriptions.get(i).getParentId() == rootBean.getRootSubscription().getId()) {
				if (notSubscribed && MySpaceConstants.ESB_SUB_STATUS_SUBSCRIBED.equalsIgnoreCase(subscriptions.get(i).getStatus())) {
					continue;
				}
				topSubscriptions.add(subscriptions.get(i));
			}
		}
		return topSubscriptions;
	}
	
	/*
	 [
	  	{
		    "children": [
		      {
		        "children": [],
		        "id": 10,
		        "parentId": 9,
		        "text": "Проявен интерес на ФЛ",
		        "checked": 1
		      },
		      {
		        "children": [],
		        "id": 11,
		        "parentId": 9,
		        "text": "Промяна на данни на ФЛ",
		        "checked": 0
		      }
		    ],
		    "id": 9,
		    "parentId": 1,
		    "text": "REGIX",
		    "checked": 2
		}
	]
	*/
	// ["checked": 1] is the 'real' checked one.
	public List<ESBUserProfileSubscriptionBean> parseJSONEvents(ESBUserProfileSubscriberBean rootBean, String eventsJSON) {
		return parseJSONEventChildren(rootBean, new JSONArray(eventsJSON), new ArrayList<ESBUserProfileSubscriptionBean>());
	}
		
	private List<ESBUserProfileSubscriptionBean> parseJSONEventChildren(ESBUserProfileSubscriberBean rootBean, JSONArray children, List<ESBUserProfileSubscriptionBean> subscriptions) {
		JSONObject jo = new JSONObject();
		JSONArray jaChildren = new JSONArray();
		for (int i = 0; i < children.length(); i++) {
			jo = children.getJSONObject(i);
			if (jo.has("checked") && jo.getInt("checked") == 1) {
				subscriptions.add(rootBean.getSubscriptionsMap().get(jo.get("id").toString()));
				continue;
			}
			jaChildren = jo.has("children") && jo.getJSONArray("children").length() > 0 ? jo.getJSONArray("children") : null;
			if (jaChildren != null) {
				subscriptions = parseJSONEventChildren(rootBean, jaChildren, subscriptions);
			}
		}
		return subscriptions;
	}
	
	public List<ESBUserProfileSubscriptionBean> processSubscriptionsForChange(ESBUserProfileSubscriberBean rootBean, List<ESBUserProfileSubscriptionBean> subscriptions) {
		if (subscriptions == null) return null;
		List<ESBUserProfileSubscriptionBean> processed = new ArrayList<ESBUserProfileSubscriptionBean>();
		ESBUserProfileSubscriptionBean subscription = null;
		for (int i = 0; i < subscriptions.size(); i++) {
			subscription = subscriptions.get(i);
			// check down
			processed = processSubscriptionsForChangeChildrenRecursive(String.valueOf(subscription.getId()), rootBean, processed);
			// check up			
			processed = processSubscriptionsForChangeParentsRecursive(subscription, rootBean, processed);
		}
		return processed;
	}
	
	private List<ESBUserProfileSubscriptionBean> processSubscriptionsForChangeChildrenRecursive(String subscriptionId, ESBUserProfileSubscriberBean rootBean, List<ESBUserProfileSubscriptionBean> processed) {
		List<ESBUserProfileSubscriptionBean> children = rootBean.getSubscriptionsParentMap().get(subscriptionId);
		if (children != null && children.size() > 0) {
			for (int i = 0; i < children.size(); i++) {
				if (MySpaceConstants.ESB_SUB_STATUS_SUBSCRIBED.equalsIgnoreCase(children.get(i).getStatus())) {
					children.get(i).setStatus(MySpaceConstants.ESB_SUB_STATUS_REMOVE_SUBSCRIPTION);
					processed.add(children.get(i));
					continue;
				} 
				processed = processSubscriptionsForChangeChildrenRecursive(String.valueOf(children.get(i).getId()), rootBean, processed);
			}
		}
		return processed;
	}

	private List<ESBUserProfileSubscriptionBean> processSubscriptionsForChangeParentsRecursive(ESBUserProfileSubscriptionBean subscription, ESBUserProfileSubscriberBean rootBean, List<ESBUserProfileSubscriptionBean> processed) {
		List<ESBUserProfileSubscriptionBean> siblings = rootBean.getSubscriptionsParentMap().get(String.valueOf(subscription.getParentId()));
		if (siblings != null && siblings.size() > 0) {
			ESBUserProfileSubscriptionBean sibling = null;
			boolean allChecked = true;
			for (int i = 0; i < siblings.size(); i++) {
				sibling = siblings.get(i);
				if (subscription.getId() == sibling.getId()) continue;
				if (!MySpaceConstants.ESB_SUB_STATUS_SUBSCRIBED.equalsIgnoreCase(sibling.getStatus())) {
					allChecked = false;
					break;
				} 
			}
			if (allChecked && sibling.getParentId() != MySpaceConstants.ESB_SUB_ROOT_ID) {
				// Unselect all, and select the parent!
				for (int i = 0; i < siblings.size(); i++) {
					sibling = siblings.get(i);
					if (MySpaceConstants.ESB_SUB_STATUS_SUBSCRIBED.equalsIgnoreCase(sibling.getStatus())) {
						sibling.setStatus(MySpaceConstants.ESB_SUB_STATUS_REMOVE_SUBSCRIPTION);
						processed.add(sibling);
					} 
				}
				processed = processSubscriptionsForChangeParentsRecursive(rootBean.getSubscriptionsMap().get(String.valueOf(sibling.getParentId())), rootBean, processed);
			} else {
				subscription.setStatus(MySpaceConstants.ESB_SUB_STATUS_NEW_SUBSCRIPTION);
				processed.add(subscription);
			}
		}
		return processed;
	}
	
	public String prepareJSONForChangeSubscription(List<ESBUserProfileSubscriptionBean> subscriptions, String status, String profileType, String profileStructureType) {
		if (subscriptions == null || subscriptions.size() == 0) return null;
		JSONObject json = new JSONObject();
		JSONObject jo = new JSONObject();
		JSONArray ja = new JSONArray();
		jo.put("profile_type", profileType);
		jo.put("profile_subtype", profileStructureType != null ? profileStructureType : "1");
		json.put("subscriber", jo);
		jo = new JSONObject();
		jo.put("type", subscriptions.get(0).getChannels().get(0).getType());
		jo.put("destination", subscriptions.get(0).getChannels().get(0).getDestination());
		json.put("chanel", jo);
		for (int i = 0; i < subscriptions.size(); i++) {
			jo = new JSONObject();
			jo.put("description", subscriptions.get(i).getDescription());
			jo.put("parent_id", subscriptions.get(i).getParentId());
			jo.put("topic_id", subscriptions.get(i).getId());
			jo.put("topic_string", subscriptions.get(i).getTopicString());
			jo.put("status", subscriptions.size() == 1 ? status : subscriptions.get(i).getStatus());
			jo.put("filter", subscriptions.get(i).isFilter());
			ja.put(jo);
		}				
		json.put("subscriptions", ja);
		return json.toString(MySpaceConstants.JSON_PRETTY_PRINT_INDENT_FACTOR);
	}
	
	public static void main(String[] args) {
		ESBTokenManager tokenManager = new ESBTokenManager();
		ESBUserProfileSubscriberBean rootBean = tokenManager.getPredefinedSupsData();
	}
}
