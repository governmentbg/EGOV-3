package com.ibs.myspace.portlet.bean.esb;

import java.util.List;

public class ESBTicketsByPersonResponseBean {
	private int count = 0;
	private List<ESBTicketsByPersonBean> tickets = null;
	
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public List<ESBTicketsByPersonBean> getTickets() {
		return tickets;
	}
	public void setTickets(List<ESBTicketsByPersonBean> tickets) {
		this.tickets = tickets;
	} 	 
}
