package com.ibs.myspace.portlet.bean.esb;

import java.util.List;

public class ESBUserProfileSubscriptionBean {
	private long id = 0;	 
	private long parentId = 0;	 
	private String description = null;
	private String status = null;	
	private String topicString = null;
	private boolean filter = false;
	private List<ESBUserProfileSubscriberChannelBean> channels = null;
	private String selectedEventsJSON = null;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getParentId() {
		return parentId;
	}
	public void setParentId(long parentId) {
		this.parentId = parentId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTopicString() {
		return topicString;
	}
	public void setTopicString(String topicString) {
		this.topicString = topicString;
	}
	public boolean isFilter() {
		return filter;
	}
	public void setFilter(boolean filter) {
		this.filter = filter;
	}
	public List<ESBUserProfileSubscriberChannelBean> getChannels() {
		return channels;
	}
	public void setChannels(List<ESBUserProfileSubscriberChannelBean> channels) {
		this.channels = channels;
	}
	public String getSelectedEventsJSON() {
		return selectedEventsJSON;
	}
	public void setSelectedEventsJSON(String selectedEventsJSON) {
		this.selectedEventsJSON = selectedEventsJSON;
	}
	
}
