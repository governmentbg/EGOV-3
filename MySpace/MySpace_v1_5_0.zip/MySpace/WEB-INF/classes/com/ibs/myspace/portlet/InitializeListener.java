package com.ibs.myspace.portlet;

import java.net.InetAddress;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.ibs.myspace.portlet.db.Base;
import com.ibs.myspace.portlet.db.DBPool;
import com.ibs.myspace.portlet.db.DBResources;
import com.ibs.myspace.portlet.utils.Logger;

@WebListener
public class InitializeListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        ServletContext servletContext = sce.getServletContext();
        String realPath = servletContext.getRealPath("/");
        Base.REAL_PATH = realPath;
        Base.TEST_ENVIRONMENT = "TEST".equalsIgnoreCase(System.getProperty("environmentType"));
        Base.PRODUCTION_ENVIRONMENT = "PROD".equalsIgnoreCase(System.getProperty("environment"));
        Base.STAGING_ENVIRONMENT = "STAGING".equalsIgnoreCase(System.getProperty("environment")) && !Base.TEST_ENVIRONMENT;
        try {
        	Base.IS_NODE_1 = "node1".equalsIgnoreCase(InetAddress.getLocalHost().getHostName());
		} catch (Exception e) {
			e.printStackTrace();
		}
        System.out.println(MySpaceConstants._PRODUCT_NAME + " " + MySpaceConstants._PRODUCT_VERSION + " | Application is starting...");
        if (DBResources.init(realPath)) {
        	MySpaceETranslationRequestCleaner.init();
        	MySpaceGhostUsersCleaner.init();
        	MySpaceGeneralTermsReleaseDate.init();
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        Logger.log(Logger.DEBUG_LEVEL, "Stopping all threads...");        
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        MySpaceETranslationRequestCleaner.shutdown();
        try {
        	Thread.sleep(500);
        } catch (Exception e) {
        	e.printStackTrace();
        }
        MySpaceGhostUsersCleaner.shutdown();
        MySpaceGeneralTermsReleaseDate.shutdown();
        try {
        	Thread.sleep(1000);
        } catch (Exception e) {
        	e.printStackTrace();
        }
        Logger.log(Logger.DEBUG_LEVEL, "Shutdown datasource...");
        DBPool.shutdownDataSource();
        Logger.log(Logger.DEBUG_LEVEL, "Application is stopped!");
    }

}