package com.ibs.myspace.portlet.servlet;

import java.io.IOException;
import java.util.Base64;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibs.myspace.portlet.management.ETranslationRequestManagement;
import com.ibs.myspace.portlet.utils.Logger;

@WebServlet("/etranslation-receive-callback")
public class ETranslationReceiveCallback extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Logger.log(Logger.ERROR_LEVEL, "MySpace::ETranslationReceiveCallback -> doGet()");
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("MySpace::ETranslationReceiveCallback -> doPost(" + request.getParameter("request-id") + ") start...");
		request.setCharacterEncoding("utf8");
		response.setHeader("Cache-Control", "no-cache");
		response.setContentType("text/plain; charset=UTF-8");
		
		String idRequest = request.getParameter("request-id");
		String targetLanguage = request.getParameter("target-language");
		String translatedText = request.getParameter("translated-text");
		boolean isProduction = "PROD".equalsIgnoreCase(System.getProperty("environment"));
		System.out.println("MySpace::ETranslationReceiveCallback -> response received [" +  idRequest + "][encoded>" + translatedText + "][" + targetLanguage + "]");
		
		// Use lines below only for STAGE.
		if (!isProduction) {
			translatedText = translatedText.replaceAll(" ", "+"); // this fix base64 encoding bug.
			translatedText = new String(Base64.getDecoder().decode(translatedText), "UTF-8");
		}
		System.out.println("MySpace::ETranslationReceiveCallback -> response received [" +  idRequest + "][" + translatedText + "]");
		
		ETranslationRequestManagement management = new ETranslationRequestManagement();
		management.updateETranslationRequestText(idRequest, translatedText, targetLanguage, System.currentTimeMillis());		
	}
}
