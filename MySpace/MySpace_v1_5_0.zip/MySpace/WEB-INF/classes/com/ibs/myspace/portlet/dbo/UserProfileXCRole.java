package com.ibs.myspace.portlet.dbo;

import java.sql.Timestamp;
import java.util.Hashtable;

import com.ibs.myspace.portlet.db.DBTransaction;
import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.db.PersistentObject;
import com.ibs.myspace.portlet.db.QueryComposer;
import com.ibs.myspace.portlet.db.QuerySet;
import com.ibs.myspace.portlet.utils.MySpaceUtils;


public class UserProfileXCRole extends PersistentObject {

	private static String CLASS_NAME = UserProfileXCRole.class.getName();
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "USERPROFILEXCROLE";
        sequenceName = "SEQ_USERPROFILEXCROLE";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "USERPROFILEXCROLEID");        
        columnMap.put("userProfileId", "USERPROFILEID");
        columnMap.put("userUID", "USERUID");
        columnMap.put("horizontalSystemRoleId", "HORIZONTALSYSTEMROLEID");
        columnMap.put("dateCreated", "DATECREATED");

        querySet = QueryComposer.composeAll(table, sequenceName, columnMap);
    }
	
    public UserProfileXCRole() {
        super(querySet);
    }
        
    private String userProfileId = null;
    private String userUID = null;
    private String horizontalSystemRoleId = null;
    private String dateCreated = null;
	
	public String getUserProfileId() {
		return userProfileId;
	}

	public void setUserProfileId(String userProfileId) {
		this.userProfileId = userProfileId;
	}
	
	public String getUserUID() {
		return userUID;
	}

	public void setUserUID(String userUID) {
		this.userUID = userUID;
	}

	public String getHorizontalSystemRoleId() {
		return horizontalSystemRoleId;
	}

	public void setHorizontalSystemRoleId(String horizontalSystemRoleId) {
		this.horizontalSystemRoleId = horizontalSystemRoleId;
	}

	public Timestamp getDateCreated() {
		return (dateCreated != null) ? new Timestamp(Long.parseLong(dateCreated)) : null;
	}
	
	public void setDateCreated(String dateCreated) {  
		this.dateCreated = (dateCreated != null) ? String.valueOf(MySpaceUtils.date_TimestampToTimeMillis(dateCreated)) : null;
	}	
	
	public static UserProfileXCRole findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileXCRole) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}
	
	public static UserProfileXCRole findByUserProfileIdAndUserUIDAndHorizontalSystemRoleId(final String userProfileId, final String userUID, final String horizontalSystemRoleId, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileXCRole) findSingle(columnMap.get("userProfileId") + "='" + userProfileId + "' AND " + columnMap.get("userUID") + "='" + userUID + "' AND " + columnMap.get("horizontalSystemRoleId") + "='" + horizontalSystemRoleId + "'", CLASS_NAME, transaction);
	} 
	
	public static UserProfileXCRole[] findAllByUserProfileId(final String userProfileId, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileXCRoles(columnMap.get("userProfileId") + "='" + userProfileId + "'", transaction);
	}
	
	public static UserProfileXCRole[] findAllByUserProfileIdAndUserUID(final String userProfileId, final String userUID, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileXCRoles(columnMap.get("userProfileId") + "='" + userProfileId + "' AND " + columnMap.get("userUID") + "='" + userUID + "'", transaction);
	}
		
	public static UserProfileXCRole[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileXCRoles("1=1", transaction);
	}

	public static UserProfileXCRole[] findAllUserProfileXCRoles(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final UserProfileXCRole[] userProfileXCRoles = new UserProfileXCRole[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				userProfileXCRoles[i] = (UserProfileXCRole) tmp[i];
			}
			return userProfileXCRoles;
		} 
		return null;
	}
	
}
