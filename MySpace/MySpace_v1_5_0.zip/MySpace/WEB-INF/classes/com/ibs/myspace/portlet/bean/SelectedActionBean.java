package com.ibs.myspace.portlet.bean;

public class SelectedActionBean {
	private Long actionsId = null;
	private String description = null;
	private String code = null;
	
	public Long getActionsId() {
		return actionsId;
	}
	public void setActionsId(Long actionsId) {
		this.actionsId = actionsId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	
}
