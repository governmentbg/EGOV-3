package com.ibs.myspace.portlet;

import java.time.Instant;

import com.ibs.myspace.communicator.RegixCommunicator;
import com.ibs.myspace.portlet.bean.ValidPersonResponse;
import com.ibs.myspace.portlet.db.Base;
import com.ibs.myspace.portlet.db.QueryExecution;
import com.ibs.myspace.portlet.management.AuditLogManagement;
import com.ibs.myspace.portlet.utils.EncryptorAESGCM;
import com.ibs.myspace.portlet.utils.MySpaceUtils;

public class MySpaceGhostUsersCleaner {

	private static int sleepTime = 1 * 60 * 60 * 1000; // 1 hour	
	private static int hourToRun = 2;
	private static boolean enableMySpaceGhostUsersCleanerThread = false;
	private static boolean startMySpaceGhostUsersCleanerThread = true;
	public static boolean isRunning = false;
	public static boolean initialized = false;
	private static MySpaceGhostUsersCleanerThread mySpaceGhostUsersCleanerThread = null;

	public MySpaceGhostUsersCleaner() {}

	public static class MySpaceGhostUsersCleanerThread extends Thread {

		public void run() {			
//			if (!(Base.STAGING_ENVIRONMENT && Base.IS_NODE_1)) {
			// Stop for now!
			if (true) {
				return;
			}
			AuditLogManagement alManagement = new AuditLogManagement();
			RegixCommunicator regixCommunicator = new RegixCommunicator();
			EncryptorAESGCM aesCls = new EncryptorAESGCM();
			ValidPersonResponse validPersonResponse = null; 
			String egovIdentifier = null;			
			String[] userData = null;
			String remoteIP = "127.0.0.1";
			long startTime = Instant.now().getEpochSecond();
			String deactivationReason = "Дата на смърт: ";
			int results = 0;		
			boolean runThread = false;
			System.out.println("------ MySpaceGhostUsersCleanerThread start");
			//Logger.log(Logger.DEBUG_LEVEL, "------ MySpaceGhostUsersCleanerThread start");
			while (MySpaceGhostUsersCleaner.startMySpaceGhostUsersCleanerThread) {				
				if (MySpaceGhostUsersCleaner.enableMySpaceGhostUsersCleanerThread) {
					try {
						MySpaceGhostUsersCleaner.isRunning = true;		
						runThread = "1".equals(MySpaceUtils.getConfigValueFromFile(Base.CONFIG_FILE_LOCATION + MySpaceConstants.THREAD_CONFIG_FILE_NAME, MySpaceConstants.THREAD_EXECUTION_PARAMETER));
						if (runThread && hourToRun == MySpaceUtils.getCurrentHour()) { 											
							startTime = Instant.now().getEpochSecond();
							results = 0;					
							QueryExecution qe = new QueryExecution();	
							String[] usersData = qe.loadAllActiveUserDataForAliveCheck(null);
							if (usersData != null && usersData.length > 0) {
								System.out.println("------ MySpaceGhostUsersCleanerThread -> loaded users for processing [" + usersData.length + "]");
								for (int i = 0; i < usersData.length; i++) {
									userData = usersData[i].split("\\^\\^");
									if (userData != null && userData.length == 2) {
										egovIdentifier = aesCls.decryptEgovIdentifier(userData[1]);
										try {
											validPersonResponse = regixCommunicator.getValidPersonRequest(egovIdentifier);
											if (validPersonResponse != null && validPersonResponse.getDeathDate() != null && validPersonResponse.getDeathDate().trim().length() > 0) {
												System.out.println("------ MySpaceGhostUsersCleanerThread -> USER IS DEAD! ALL USER'S PROFILE(S) WILL BE DEACTIVATED! [EGN:" + egovIdentifier + " (" + validPersonResponse.getFirstName() + " " + validPersonResponse.getSurName() + " " + validPersonResponse.getFamilyName() + ")][DeathDate:" + validPersonResponse.getDeathDate() + "(" + validPersonResponse.getBirthDate() + ")]");
												int result = qe.deactivateAllProfiles(userData[0], deactivationReason + validPersonResponse.getDeathDate(), null);
												qe.removeAllUserRoleAssociations(userData[0], null);
												// Leave this for history restore info, if needed.
												//qe.removeAllUserInvitationAssociations(userData[0], null);
												if (result > 1) {
													// Register event in the log.
													alManagement.sendEvent(userData[0], MySpaceConstants.EVENT_LOG_PORTAL_DEACTIVATE_ALL_PROFILES, "Деактивиране на всички профили", null, remoteIP, false);								
												} else {
													// Register event in the log.
													alManagement.sendEvent(userData[0], MySpaceConstants.EVENT_LOG_PORTAL_DEACTIVATE_PROFILE, "Деактивиране на персонален профил", null, remoteIP, false);				
												}
												results++;
											}
										} catch (Exception e) {											
											e.printStackTrace();
										}
									}
								}
							}
														
							if (results > 0) {
								System.out.println("------ MySpaceGhostUsersCleanerThread deactivated [" + results + "]");							
							}																
							MySpaceGhostUsersCleaner.isRunning = false;
							
							double duration = Instant.now().getEpochSecond() - startTime;
							System.out.println("------ MySpaceGhostUsersCleanerThread completed for " + duration + " seconds.");
						}
					} catch (Exception e) {
						e.printStackTrace();
						MySpaceGhostUsersCleaner.isRunning = false;
					}
				}
				try {
					System.out.println("------ MySpaceGhostUsersCleanerThread will sleep for another 1 hour. [hour to run: " + hourToRun + "]");
					MySpaceGhostUsersCleaner.isRunning = false;
					sleep(MySpaceGhostUsersCleaner.sleepTime);
				} catch (InterruptedException e) {
				}
			}
			MySpaceGhostUsersCleaner.isRunning = false;
			System.out.println("------ MySpaceGhostUsersCleanerThread stop");
		}
	}

	public static synchronized void init() {
		enableMySpaceGhostUsersCleanerThread = true;
		mySpaceGhostUsersCleanerThread = new MySpaceGhostUsersCleanerThread();
		mySpaceGhostUsersCleanerThread.start();
	}

	public static void shutdown() {
		enableMySpaceGhostUsersCleanerThread = false;
		startMySpaceGhostUsersCleanerThread = false;
		mySpaceGhostUsersCleanerThread.interrupt();
		long startTime = Instant.now().getEpochSecond();
		while (isRunning) {
			System.out.println("------ Waiting MySpaceGhostUsersCleaner for stop signal...");
//			Logger.log(Logger.DEBUG_LEVEL, "------ Waiting MySpaceGhostUsersCleaner for stop signal...");
			// if we wait for more than 1 minute, it looks like it hangs, so break from here.
			if (Instant.now().getEpochSecond() - startTime > 60) {
				break;
			}
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			}
		}
		System.out.println("------ MySpaceGhostUsersCleaner HAS BEEN KILLED SUCCESSFULLY!");
//		Logger.log(Logger.DEBUG_LEVEL, "------ MySpaceGhostUsersCleaner HAS BEEN KILLED SUCCESSFULLY!");
	}
		
}
