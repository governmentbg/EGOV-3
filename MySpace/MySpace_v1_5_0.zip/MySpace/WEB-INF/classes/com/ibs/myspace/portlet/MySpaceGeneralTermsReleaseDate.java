package com.ibs.myspace.portlet;

import java.time.Instant;
import java.util.Date;

import com.ibm.workplace.wcm.api.Content;
import com.ibs.myspace.communicator.WCMCommunicator;
import com.ibs.myspace.portlet.utils.MySpaceUtils;

public class MySpaceGeneralTermsReleaseDate {

	private static int sleepTime = 24 * 60 * 60 * 1000; // 24 hours		
	private static boolean enableMySpaceGeneralTermsReleaseDateThread = false;
	private static boolean startMySpaceGeneralTermsReleaseDateThread = true;
	public static boolean isRunning = false;
	public static boolean initialized = false;
	private static MySpaceGeneralTermsReleaseDateThread mySpaceGhostUsersCleanerThread = null;
	public static Date releaseDate = null;

	public MySpaceGeneralTermsReleaseDate() {}

	public static class MySpaceGeneralTermsReleaseDateThread extends Thread {

		public void run() {
			WCMCommunicator wcmCommunicator = new WCMCommunicator();
			Content content = null;
			long startTime = Instant.now().getEpochSecond();
			System.out.println("------ MySpaceGeneralTermsReleaseDateThread start");
			//Logger.log(Logger.DEBUG_LEVEL, "------ MySpaceGeneralTermsReleaseDateThread start");
			while (MySpaceGeneralTermsReleaseDate.startMySpaceGeneralTermsReleaseDateThread) {				
				if (MySpaceGeneralTermsReleaseDate.enableMySpaceGeneralTermsReleaseDateThread) {
					try {
						MySpaceGeneralTermsReleaseDate.isRunning = true;		
						startTime = Instant.now().getEpochSecond();
						content = wcmCommunicator.getEGOVTermsAndConditionsContent();
						releaseDate = wcmCommunicator.getEGOVTermsAndConditionsContentReleaseDate(content);
										 			
						if (releaseDate != null) {
							System.out.println("------ MySpaceGeneralTermsReleaseDateThread releaseDate [" + MySpaceUtils.timeMillisToDD_MM_YYYY(releaseDate.getTime()) + "]");							
						}																
						MySpaceGeneralTermsReleaseDate.isRunning = false;
						
						double duration = Instant.now().getEpochSecond() - startTime;
						System.out.println("------ MySpaceGeneralTermsReleaseDateThread completed for " + duration + " seconds.");
					} catch (Exception e) {
						e.printStackTrace();
						MySpaceGeneralTermsReleaseDate.isRunning = false;
					}
				}
				try {
					System.out.println("------ MySpaceGeneralTermsReleaseDateThread will sleep for another: 24 hours.");
					MySpaceGeneralTermsReleaseDate.isRunning = false;
					sleep(MySpaceGeneralTermsReleaseDate.sleepTime);
				} catch (InterruptedException e) {
				}
			}
			MySpaceGeneralTermsReleaseDate.isRunning = false;
			System.out.println("------ MySpaceGeneralTermsReleaseDateThread stop");
		}
	}

	public static synchronized void init() {
		enableMySpaceGeneralTermsReleaseDateThread = true;
		mySpaceGhostUsersCleanerThread = new MySpaceGeneralTermsReleaseDateThread();
		mySpaceGhostUsersCleanerThread.start();
	}

	public static void shutdown() {
		enableMySpaceGeneralTermsReleaseDateThread = false;
		startMySpaceGeneralTermsReleaseDateThread = false;
		mySpaceGhostUsersCleanerThread.interrupt();
		long startTime = Instant.now().getEpochSecond();
		while (isRunning) {
			System.out.println("------ Waiting MySpaceGeneralTermsReleaseDate for stop signal...");
//			Logger.log(Logger.DEBUG_LEVEL, "------ Waiting MySpaceGeneralTermsReleaseDate for stop signal...");
			// if we wait for more than 1 minute, it looks like it hangs, so break from here.
			if (Instant.now().getEpochSecond() - startTime > 60) {
				break;
			}
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			}
		}
		System.out.println("------ MySpaceGeneralTermsReleaseDate HAS BEEN KILLED SUCCESSFULLY!");
//		Logger.log(Logger.DEBUG_LEVEL, "------ MySpaceGeneralTermsReleaseDate HAS BEEN KILLED SUCCESSFULLY!");
	}
		
}
