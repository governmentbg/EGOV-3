package com.ibs.myspace.portlet.bean;

public class ValidPersonResponse {
	private String firstName;
	private String surName;
	private String familyName;
	private String birthDate;
	private String deathDate;
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getSurName() {
		return surName;
	}

	public void setSurName(String surName) {
		this.surName = surName;
	}

	public String getFamilyName() {
		return familyName;
	}

	public void setFamilyName(String familyName) {
		this.familyName = familyName;
	}

	public String getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}

	public String getDeathDate() {
		return deathDate;
	}

	public void setDeathDate(String deathDate) {
		this.deathDate = deathDate;
	}

	@Override
	public String toString() {
		return "ValidPersonResponse [firstName=" + firstName + ", surName=" + surName + ", familyName="
				+ familyName + ", birthDate=" + birthDate + ", deathDate=" + deathDate + "]";
	}
	
}