package com.ibs.myspace.portlet.management;

import com.ibs.myspace.portlet.dbo.HorizontalSystemRole;


public class HorizontalSystemRoleManagement {
	
	public HorizontalSystemRole[] loadAll() {
		try {			
			return HorizontalSystemRole.findAllOrderBySystemOID(null);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
}
