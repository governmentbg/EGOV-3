package com.ibs.myspace.portlet.bean;

public class EPaymentDataTableBean {
	private int pendingResultsPerPage = 10;	 
	private int pendingStart = 1;	 
	private int pendingOrderColumn = 1;	 
	private String pendingOrder = null;	 
	private int restResultsPerPage = 10;	 
	private int restStart = 1;	 
	private int restOrderColumn = 1;	 
	private String restOrder = null;
	
	public int getPendingResultsPerPage() {
		return pendingResultsPerPage;
	}
	public void setPendingResultsPerPage(int pendingResultsPerPage) {
		this.pendingResultsPerPage = pendingResultsPerPage;
	}
	public int getPendingStart() {
		return pendingStart;
	}
	public void setPendingStart(int pendingStart) {
		this.pendingStart = pendingStart;
	}
	public int getPendingOrderColumn() {
		return pendingOrderColumn;
	}
	public void setPendingOrderColumn(int pendingOrderColumn) {
		this.pendingOrderColumn = pendingOrderColumn;
	}
	public String getPendingOrder() {
		return pendingOrder;
	}
	public void setPendingOrder(String pendingOrder) {
		this.pendingOrder = pendingOrder;
	}
	public int getRestResultsPerPage() {
		return restResultsPerPage;
	}
	public void setRestResultsPerPage(int restResultsPerPage) {
		this.restResultsPerPage = restResultsPerPage;
	}
	public int getRestStart() {
		return restStart;
	}
	public void setRestStart(int restStart) {
		this.restStart = restStart;
	}
	public int getRestOrderColumn() {
		return restOrderColumn;
	}
	public void setRestOrderColumn(int restOrderColumn) {
		this.restOrderColumn = restOrderColumn;
	}
	public String getRestOrder() {
		return restOrder;
	}
	public void setRestOrder(String restOrder) {
		this.restOrder = restOrder;
	}	 
	
	
}
