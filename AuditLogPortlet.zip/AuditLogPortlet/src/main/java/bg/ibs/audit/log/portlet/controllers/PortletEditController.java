package bg.ibs.audit.log.portlet.controllers;

import java.io.IOException;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.portlet.ActionResponse;
import javax.portlet.PortletException;
import javax.portlet.PortletMode;
import javax.portlet.PortletPreferences;
import javax.portlet.WindowState;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.portlet.bind.annotation.ActionMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;

import bg.ibs.audit.log.portlet.AuditLogConstants;
import bg.ibs.audit.log.portlet.beans.AuditLogSessionBean;

@Controller
@RequestMapping("edit_defaults")
public class PortletEditController {
	
	private static final Logger logger = LoggerFactory.getLogger(PortletEditController.class);
	
	@Resource(name = "sessionScopedBean")
	AuditLogSessionBean sessionBean;
	
	@Resource(name = "messageSource")
	private MessageSource messageSource;
	
	@PostConstruct
	public void init() {
	}
	
	@RenderMapping
    public String render(Model model, PortletPreferences prefs){
		logMessage("render()", prefs);

        model.addAttribute("attribute", prefs.getValue("prefVal", "default"));

        return "editDefaults";
    }

    @ActionMapping(value = "editDefaults")
    public void action(
    	@RequestParam(value = "esbEventLogAddress", required = false) String esbEventLogAddress,
    	@RequestParam("resultsPerPage") int resultsPerPage,
    	@RequestParam("language") String language,    	
    	@RequestParam("debug") String debug,
    	PortletPreferences prefs,  
    	ActionResponse response) throws PortletException, IOException {
    	
    	logMessage("action()", prefs);
    	
    	try {
    		prefs.setValue(AuditLogConstants.SETTING_PARAMETER_ESB_EVENT_LOGGER_ADDRESS, esbEventLogAddress);
    		prefs.setValue(AuditLogConstants.SETTING_PARAMETER_RESULTS_PER_PAGE, resultsPerPage + ""); 
    		prefs.setValue(AuditLogConstants.SETTING_PARAMETER_LANGUAGE, language);    		
	    	prefs.setValue(AuditLogConstants.SETTING_PARAMETER_DEBUG, debug);
	    	prefs.store();
	    	response.setPortletMode(PortletMode.VIEW);
	    	response.setWindowState(WindowState.NORMAL);
		} catch( Exception e ) { 
			//sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
		}
    }
	
	private void logMessage(String message, PortletPreferences prefs) { 
		boolean isDebug = "1".equalsIgnoreCase(prefs.getValue(AuditLogConstants.SETTING_PARAMETER_DEBUG, ""));
		if (isDebug) {
			logger.info(message);
		}
	}
}
