package bg.ibs.audit.log.portlet.beans;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.SessionScope;

import bg.ibs.audit.log.portlet.AuditLogConstants;

@SessionScope
@Component
public class AuditLogSessionBean {
	private String filterUid;
	private String filterCommonName;
	private String filterEmail;
	private String filterPersonalIdentifier;
	private String filterActivity;
	private String filterActivityDetails;
	private String filterFromDate;
	private String filterToDate;
	private List<AuditLogBean> auditLogs;
	private boolean filterInitialised;
	private int resultsPerPage = AuditLogConstants.RESULTS_PER_PAGE;
	private int start = 0;
	private int orderColumn = AuditLogConstants.COLUMN_DATE;
	private String order = AuditLogConstants.ORDER_DESC;	
	
	public String getFilterUid() {
		return filterUid;
	}
	public void setFilterUid(String filterUid) {
		this.filterUid = filterUid;
	}
	public String getFilterCommonName() {
		return filterCommonName;
	}
	public void setFilterCommonName(String filterCommonName) {
		this.filterCommonName = filterCommonName;
	}
	public String getFilterEmail() {
		return filterEmail;
	}
	public void setFilterEmail(String filterEmail) {
		this.filterEmail = filterEmail;
	}
	public String getFilterPersonalIdentifier() {
		return filterPersonalIdentifier;
	}
	public void setFilterPersonalIdentifier(String filterPersonalIdentifier) {
		this.filterPersonalIdentifier = filterPersonalIdentifier;
	}
	public String getFilterActivity() {
		return filterActivity;
	}
	public void setFilterActivity(String filterActivity) {
		this.filterActivity = filterActivity;
	}
	public String getFilterActivityDetails() {
		return filterActivityDetails;
	}
	public void setFilterActivityDetails(String filterActivityDetails) {
		this.filterActivityDetails = filterActivityDetails;
	}
	public String getFilterFromDate() {
		return filterFromDate;
	}
	public void setFilterFromDate(String filterFromDate) {
		this.filterFromDate = filterFromDate;
	}
	public String getFilterToDate() {
		return filterToDate;
	}
	public void setFilterToDate(String filterToDate) {
		this.filterToDate = filterToDate;
	}
	public List<AuditLogBean> getAuditLogs() {
		return auditLogs;
	}
	public void setAuditLogs(List<AuditLogBean> auditLogs) {
		this.auditLogs = auditLogs;
	}
	public boolean isFilterInitialised() {
		return filterInitialised;
	}
	public void setFilterInitialised(boolean filterInitialised) {
		this.filterInitialised = filterInitialised;
	}
	public int getResultsPerPage() {
		return resultsPerPage;
	}
	public void setResultsPerPage(int resultsPerPage) {
		this.resultsPerPage = resultsPerPage;
	}
	public int getStart() {
		return start;
	}
	public void setStart(int start) {
		this.start = start;
	}
	public int getOrderColumn() {
		return orderColumn;
	}
	public void setOrderColumn(int orderColumn) {
		this.orderColumn = orderColumn;
	}
	public String getOrder() {
		return order;
	}
	public void setOrder(String order) {
		this.order = order;
	}
	
}
