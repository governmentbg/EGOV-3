package bg.ibs.audit.log.portlet.communicator;

import java.security.PrivilegedExceptionAction;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ibm.portal.um.PumaEnvironment;
import com.ibm.portal.um.PumaHome;
import com.ibm.portal.um.PumaLocator;
import com.ibm.portal.um.PumaProfile;
import com.ibm.portal.um.User;

import bg.ibs.audit.log.portlet.AuditLogConstants;
import bg.ibs.audit.log.portlet.utils.AuditLogLogger;

@Component
public class PumaCommunicator {
	@Autowired
	AuditLogLogger logger;

	public User getUserByPersonalIdentifier(final PumaHome pumaHome, final String userAttribute) {
		logger.message("getUserByPersonalIdentifier(" + userAttribute + ")");
		User user = null;
		List<User> users = getUsersByAttribute(pumaHome, userAttribute, AuditLogConstants.LDAP_ATTRIBUTE_EGOV_IDENTIFIER);
		//List<User> users = getUsersByAttribute(pumaHome, userAttribute, AuditLogConstants.LDAP_ATTRIBUTE_EMPLOYEE_NUMBER);
		if (users != null && users.size() > 0) {
			logger.message("getUserByPersonalIdentifier(" + userAttribute + ") -> users.size() = " + users.size());
			if (users.size() > 1) {
				//logger.message("getUserByPersonalIdentifier() -> " + "Warning: Using non-unique attribute for User. Attribute Name=" + AuditLogConstants.LDAP_ATTRIBUTE_EGOV_IDENTIFIER + " Value =" + userAttribute);
				logger.message("getUserByPersonalIdentifier() -> " + "Warning: Using non-unique attribute for User. Attribute Name=" + AuditLogConstants.LDAP_ATTRIBUTE_EMPLOYEE_NUMBER + " Value =" + userAttribute);
			} else {
				user = (User) users.get(0);
			}
		} else {
			logger.message("getUserByPersonalIdentifier(" + userAttribute + ") -> No User was found!");
		}
		
		return user;
	}
	
	public User getUserByEmail(final PumaHome pumaHome, final String userAttribute) {
		logger.message("getUserByEmail(" + userAttribute + ")");
		User user = null;
		List<User> users = getUsersByAttribute(pumaHome, userAttribute, AuditLogConstants.LDAP_ATTRIBUTE_PORTAL_EMAIL);
		if (users != null && users.size() > 0) {
			logger.message("getUserByEmail(" + userAttribute + ") -> users.size() = " + users.size());
			if (users.size() > 1) {
				logger.message("getUserByEmail() -> " + "Warning: Using non-unique attribute for User. Attribute Name=" + AuditLogConstants.LDAP_ATTRIBUTE_PORTAL_EMAIL + " Value =" + userAttribute);
			} else {
				user = (User) users.get(0);
			}
		} else {
			logger.message("getUserByEmail(" + userAttribute + ") -> No User was found!");
		}
		
		return user;
	}
	
	@SuppressWarnings("rawtypes")
	public String getUserUIDByPersonalIdentifier(final PumaHome pumaHome, final String userAttribute) {
		logger.message("getUserByPersonalIdentifier(" + userAttribute + ")");
		User user = null;
		List<User> users = getUsersByAttribute(pumaHome, userAttribute, AuditLogConstants.LDAP_ATTRIBUTE_EGOV_IDENTIFIER);
		//List<User> users = getUsersByAttribute(pumaHome, userAttribute, AuditLogConstants.LDAP_ATTRIBUTE_EMPLOYEE_NUMBER);
		if (users != null && users.size() > 0) {
			logger.message("getUserByPersonalIdentifier(" + userAttribute + ") -> users.size() = " + users.size());
			if (users.size() > 1) {
				logger.message("getUserByPersonalIdentifier() -> " + "Warning: Using non-unique attribute for User. Attribute Name=" + AuditLogConstants.LDAP_ATTRIBUTE_EGOV_IDENTIFIER + " Value =" + userAttribute);
				//logger.message("getUserByPersonalIdentifier() -> " + "Warning: Using non-unique attribute for User. Attribute Name=" + AuditLogConstants.LDAP_ATTRIBUTE_EMPLOYEE_NUMBER + " Value =" + userAttribute);
			} else {
				user = (User) users.get(0);
				java.util.Map<String, Object> userInfo = getUserAttributesInfo(user, pumaHome, pumaHome.getProfile());
				if (userInfo != null) {
					Object attribute = userInfo.get(AuditLogConstants.LDAP_ATTRIBUTE_UID);
					if (attribute != null) {
						String currentUserUID = "";
						if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
							for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
								if (i > 0) {
									currentUserUID += " ";
								}
								currentUserUID += (String)((ArrayList)attribute).get(i);
							}
						} else if (attribute instanceof String) {
							currentUserUID = (String)attribute;
						}		
						return currentUserUID;
					}
				}
			}
		} else {
			logger.message("getUserByPersonalIdentifier(" + userAttribute + ") -> No User was found!");
		}
		
		return null;
	}
	
	@SuppressWarnings("rawtypes")
	public String getUserUIDsByCommonName(final PumaHome pumaHome, final String userAttribute) {
		logger.message("getUserUIDsByCommonName(" + userAttribute + ")");
		User user = null;
		List<User> users = getUsersByAttribute(pumaHome, "*" + userAttribute + "*", AuditLogConstants.LDAP_ATTRIBUTE_COMMON_NAME);
		if (users != null && users.size() > 0) {
			logger.message("getUserUIDsByCommonName(" + userAttribute + ") -> users.size() = " + users.size());
			if (users.size() > 0) {
				java.util.Map<String, Object> userInfo = null;
				Object attribute = null;
				String currentUserUID = "";
				String userIds = "";
				for(int i = 0; i < users.size(); i++) {
					user = (User) users.get(i);
					userInfo = getUserAttributesInfo(user, pumaHome, pumaHome.getProfile());
					if (userInfo != null) {
						attribute = userInfo.get(AuditLogConstants.LDAP_ATTRIBUTE_UID);
						if (attribute != null) {
							currentUserUID = "";
							if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
								for (int j = 0; j < ((ArrayList)attribute).size(); j++) {
									if (j > 0) {
										currentUserUID += " ";
									}
									currentUserUID += (String)((ArrayList)attribute).get(j);
								}
							} else if (attribute instanceof String) {
								currentUserUID = (String)attribute;
							}
							if (userIds.trim().length() > 0) {
								userIds += ",";
							}
							userIds += currentUserUID;
						}
					}
				}
				return userIds;
			} 
		} else {
			logger.message("getUserUIDsByCommonName(" + userAttribute + ") -> No User was found!");
		}
		return null;
	}
	
	@SuppressWarnings("rawtypes")
	public String getUserUIDsByAttribute(final PumaHome pumaHome, final String atttibuteValue, final String attributeName) {
		logger.message("getUserUIDsByAttribute(" + atttibuteValue + "," + attributeName + ")");
		User user = null;
		List<User> users = getUsersByAttribute(pumaHome, atttibuteValue, attributeName);
		if (users != null && users.size() > 0) {
			logger.message("getUserUIDsByAttribute(" + atttibuteValue + ") -> users.size() = " + users.size());
			if (users.size() > 0) {
				java.util.Map<String, Object> userInfo = null;
				Object attribute = null;
				String currentUserUID = "";
				String userIds = "";
				for(int i = 0; i < users.size(); i++) {
					user = (User) users.get(i);
					userInfo = getUserAttributesInfo(user, pumaHome, pumaHome.getProfile());
					if (userInfo != null) {
						attribute = userInfo.get(AuditLogConstants.LDAP_ATTRIBUTE_UID);
						if (attribute != null) {
							currentUserUID = "";
							if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
								for (int j = 0; j < ((ArrayList)attribute).size(); j++) {
									if (j > 0) {
										currentUserUID += " ";
									}
									currentUserUID += (String)((ArrayList)attribute).get(j);
								}
							} else if (attribute instanceof String) {
								currentUserUID = (String)attribute;
							}
							if (userIds.trim().length() > 0) {
								userIds += ",";
							}
							userIds += currentUserUID;
						}
					}
				}
				return userIds;
			} 
		} else {
			logger.message("getUserUIDsByAttribute(" + atttibuteValue + ") -> No User was found!");
		}
		
		return null;
	}
	
	@SuppressWarnings("rawtypes")
	public List<String> getCNAndEmailByUserUID(final PumaHome pumaHome, final String userAttribute) {
		logger.message("getCNAndEmailByUserUID(" + userAttribute + ")");
		User user = null;
		List<User> users = getUsersByAttribute(pumaHome, userAttribute, AuditLogConstants.LDAP_ATTRIBUTE_UID);
		if (users != null && users.size() > 0) {
			logger.message("getCNAndEmailByUserUID(" + userAttribute + ") -> users.size() = " + users.size());
			if (users.size() > 1) {
				logger.message("getCNAndEmailByUserUID() -> " + "Warning: Using non-unique attribute for User. Attribute Name=" + AuditLogConstants.LDAP_ATTRIBUTE_UID + " Value =" + userAttribute);
			} else {
				user = (User) users.get(0);
				java.util.Map<String, Object> userInfo = getUserAttributesInfo(user, pumaHome, pumaHome.getProfile());
				if (userInfo != null) {
					Object attribute = userInfo.get(AuditLogConstants.LDAP_ATTRIBUTE_COMMON_NAME);
					String currentUserCN = "";
					String currentUserEmail = "";
					if (attribute != null) {
						if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
							for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
								if (i > 0) {
									currentUserCN += " ";
								}
								currentUserCN += (String)((ArrayList)attribute).get(i);
							}
						} else if (attribute instanceof String) {
							currentUserCN = (String)attribute;
						}		
					}
					attribute = userInfo.get(AuditLogConstants.LDAP_ATTRIBUTE_PORTAL_EMAIL);
					if (attribute != null) {
						if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
							for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
								if (i > 0) {
									currentUserEmail += " ";
								}
								currentUserEmail += (String)((ArrayList)attribute).get(i);
							}
						} else if (attribute instanceof String) {
							currentUserEmail = (String)attribute;
						}		
					}
					List<String> attributes = new ArrayList<>();
					attributes.add(currentUserCN);
					attributes.add(currentUserEmail);
					return attributes;
				}
			}
		} else {
			logger.message("getCNAndEmailByUserUID(" + userAttribute + ") -> No User was found!");
		}
		return null;
	}

	
	@SuppressWarnings("rawtypes")
	public String getSpecificAttributeByUserUID(final PumaHome pumaHome, final String uId, final String attributeName) {
		logger.message("getAttributeByUserUID(" + uId + "," + attributeName + ")");
		User user = null;
		List<User> users = getUsersByAttribute(pumaHome, uId, AuditLogConstants.LDAP_ATTRIBUTE_UID);
		if (users != null && users.size() > 0) {
			logger.message("getAttributeByUserUID(" + uId + "," + attributeName + ") -> users.size() = " + users.size());
			if (users.size() > 1) {
				logger.message("getAttributeByUserUID() -> " + "Warning: Using non-unique attribute for User. Attribute Name=" + AuditLogConstants.LDAP_ATTRIBUTE_UID + " Value =" + uId);
			} else {
				user = (User) users.get(0);
				java.util.Map<String, Object> userInfo = getUserAttributesInfo(user, pumaHome, pumaHome.getProfile());
				if (userInfo != null) {
					Object attribute = userInfo.get(attributeName);
					if (attribute != null) {
						String currentUserAttribute = "";
						if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
							for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
								if (i > 0) {
									currentUserAttribute += " ";
								}
								currentUserAttribute += (String)((ArrayList)attribute).get(i);
							}
						} else if (attribute instanceof String) {
							currentUserAttribute = (String)attribute;
						}		
						return currentUserAttribute;
					}
				}
			}
		} else {
			logger.message("getAttributeByUserUID(" + uId + "," + attributeName + ") -> No User was found!");
		}
		return null;
	}
	

	@SuppressWarnings("rawtypes")
	public String getPersonalIdentifierByUserUID(final PumaHome pumaHome, final String userAttribute) {
		logger.message("getPersonalIdentifierByUserUID(" + userAttribute + ")");
		User user = null;
		List<User> users = getUsersByAttribute(pumaHome, userAttribute, AuditLogConstants.LDAP_ATTRIBUTE_UID);
		if (users != null && users.size() > 0) {
			logger.message("getPersonalIdentifierByUserUID(" + userAttribute + ") -> users.size() = " + users.size());
			if (users.size() > 1) {
				logger.message("getPersonalIdentifierByUserUID() -> " + "Warning: Using non-unique attribute for User. Attribute Name=" + AuditLogConstants.LDAP_ATTRIBUTE_UID + " Value =" + userAttribute);
			} else {
				user = (User) users.get(0);
				java.util.Map<String, Object> userInfo = getUserAttributesInfo(user, pumaHome, pumaHome.getProfile());
				if (userInfo != null) {
					Object attribute = userInfo.get(AuditLogConstants.LDAP_ATTRIBUTE_EGOV_IDENTIFIER);
					//Object attribute = userInfo.get(AuditLogConstants.LDAP_ATTRIBUTE_EMPLOYEE_NUMBER);
					if (attribute != null) {
						String currentUserUID = "";
						if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
							for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
								if (i > 0) {
									currentUserUID += " ";
								}
								currentUserUID += (String)((ArrayList)attribute).get(i);
							}
						} else if (attribute instanceof String) {
							currentUserUID = (String)attribute;
						}		
						return currentUserUID;
					}
				}
			}
		} else {
			logger.message("getPersonalIdentifierByUserUID(" + userAttribute + ") -> No User was found!");
		}
		
		return null;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<User> getUsersByAttribute(final PumaHome pumaHome, final String userAttributeValue, final String searchAttribute) {
		logger.message("getUsersByAttribute(" + userAttributeValue + "," + searchAttribute + ")");
		List<User> users = null;
		try {
			final PumaEnvironment env = pumaHome.getEnvironment();
			final PumaLocator locatorService = pumaHome.getLocator();
			users = (List<User>) env.runUnrestricted(new PrivilegedExceptionAction() {
				public Object run() throws Exception {
					return locatorService.findUsersByAttribute(searchAttribute, userAttributeValue);
				}
			});
		} catch (Exception e) {
			logger.error("getUsersByAttribute(" + userAttributeValue + "," + searchAttribute + ") -> Exception: " + e.getMessage());
			e.printStackTrace();
		}		
		return users;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public java.util.Map<String, Object> getUserAttributesInfo(final User user, final PumaHome pumaHome, final PumaProfile pumaProfile) {
		logger.message("getUserAttributesInfo(com.ibm.portal.um.User)");
		final java.util.List<String> attributesNamesList;
		try {
			final PumaEnvironment env = pumaHome.getEnvironment();
			// We need only uId and Personal Identifier data, which is stored in LDAP_ATTRIBUTE_EMPLOYEE_NUMBER field.
			//attributesNamesList = pumaProfile.getDefinedUserAttributeNames();
			attributesNamesList = new ArrayList<>();
			attributesNamesList.add(AuditLogConstants.LDAP_ATTRIBUTE_UID);
			attributesNamesList.add(AuditLogConstants.LDAP_ATTRIBUTE_EGOV_IDENTIFIER);
//			attributesNamesList.add(AuditLogConstants.LDAP_ATTRIBUTE_EMPLOYEE_NUMBER);
			attributesNamesList.add(AuditLogConstants.LDAP_ATTRIBUTE_COMMON_NAME);
			attributesNamesList.add(AuditLogConstants.LDAP_ATTRIBUTE_PORTAL_EMAIL);
//			To use this implementation you need to defined Anonymous User access to Virtual Resource USER_GROUPS!
//			java.util.Map<String, Object> userInfo = (java.util.Map<String, Object>) getPumaProfile().getAttributes((com.ibm.portal.um.Principal) user, attributesNamesList);
			java.util.Map<String, Object> userInfo = (java.util.Map<String, Object>) env.runUnrestricted(new PrivilegedExceptionAction() {
				public Object run() throws Exception {
					return pumaProfile.getAttributes((com.ibm.portal.um.Principal) user, attributesNamesList);
				}
			});
			return userInfo;
		} catch (Exception e) {
			logger.error("getUserAttribute(com.ibm.portal.um.User) -> Exception: " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
}
