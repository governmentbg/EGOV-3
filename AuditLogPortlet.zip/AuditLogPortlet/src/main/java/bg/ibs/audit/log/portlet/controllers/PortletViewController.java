package bg.ibs.audit.log.portlet.controllers;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequest;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.portlet.ModelAndView;
import org.springframework.web.portlet.bind.annotation.ActionMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;
import org.springframework.web.portlet.bind.annotation.ResourceMapping;

import com.egov.wcm.cache.EgovService;
import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.portal.um.PumaHome;

import bg.ibs.audit.log.portlet.AuditLogConstants;
import bg.ibs.audit.log.portlet.beans.AuditLogBean;
import bg.ibs.audit.log.portlet.beans.AuditLogSessionBean;
import bg.ibs.audit.log.portlet.communicator.AuditLogCommunicator;
import bg.ibs.audit.log.portlet.communicator.PumaCommunicator;
import bg.ibs.audit.log.portlet.utils.AuditLogLogger;
import bg.ibs.audit.log.portlet.utils.EncryptorAESGCM;

@Controller
@RequestMapping("view")
public class PortletViewController {
	
	@Resource(name = "sessionScopedBean")
	AuditLogSessionBean sessionBean;
	
	@Resource(name = "messageSource")
	private MessageSource messageSource;
	
	@Autowired
	AuditLogLogger logger;
	@Autowired
	PumaCommunicator pumaCommunicator;
	@Autowired
	AuditLogCommunicator auditLogCommunicator;
	
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	
	private static PumaHome pumaHome = null;
	public static String esbEventLogAddress = AuditLogConstants.ESB_LOGGING_URL;
	public static String language = AuditLogConstants.LANGUAGE_BG;
	public static boolean isDebug = false;	
	
	
	@PostConstruct
	public void init() {
		InitialContext initialcontext;
		try {
			initialcontext = new InitialContext();
			pumaHome = (PumaHome) initialcontext.lookup("portal:service/usermanagement/Puma");
		} catch (NamingException namingexception) {
			namingexception.printStackTrace();
		}
	}
	
	@RenderMapping
	public ModelAndView defaultView(RenderRequest renderRequest, RenderResponse renderResponse) {
		loadPreferences(renderRequest);
		if (!sessionBean.isFilterInitialised()) {
			// Initialise filter values. 
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd.MM.yyyy"); 
			LocalDateTime now = LocalDateTime.now();
			sessionBean.setFilterFromDate(dtf.format(now));
			sessionBean.setFilterToDate(dtf.format(now));
			sessionBean.setFilterInitialised(true);
			sessionBean.setFilterActivity(null);
		}
		logger.message("in defaultView() ");
		ModelAndView mv = new ModelAndView("index");
		mv.addObject("filterUid", sessionBean.getFilterUid());
		mv.addObject("filterPersonalIdentifier", sessionBean.getFilterPersonalIdentifier());
		mv.addObject("filterCommonName", sessionBean.getFilterCommonName());
		mv.addObject("filterEmail", sessionBean.getFilterEmail());
		mv.addObject("filterActivity", sessionBean.getFilterActivity());
		mv.addObject("filterActivityDetails", sessionBean.getFilterActivityDetails());
		mv.addObject("filterFromDate", sessionBean.getFilterFromDate());
		mv.addObject("filterToDate", sessionBean.getFilterToDate());		
		mv.addObject("active", "0");		
		mv.addObject("tabAuditLog", AuditLogConstants.TAB_AUDIT_LOG);			
		mv.addObject("resultsPerPage", sessionBean.getResultsPerPage());
		mv.addObject("start", sessionBean.getStart());
		mv.addObject("orderColumn", sessionBean.getOrderColumn());
		mv.addObject("order", sessionBean.getOrder().toLowerCase());
		mv.addObject("language", language);		
		System.out.println("defaultView() -> resultsPerPage=" + sessionBean.getResultsPerPage());
		System.out.println("defaultView() -> order=" + sessionBean.getOrder().toLowerCase());
		System.out.println("defaultView() -> start=" + sessionBean.getStart());
		return mv;
	}		
	
	@ActionMapping(value = "searchFilter")
	public void searchFilter(
			ActionRequest actionRequest, ActionResponse actionResponse,
			@RequestParam(value = "uid", required = false) String uid,
			@RequestParam(value = "personalIdentifier", required = false) String personalIdentifier,
			@RequestParam(value = "commonName", required = false) String commonName,
			@RequestParam(value = "email", required = false) String email,
			@RequestParam(value = "activity", required = false) String activity,
			@RequestParam(value = "activityDetails", required = false) String activityDetails,
			@RequestParam(value = "fromDate", required = false) String fromDate,
			@RequestParam(value = "toDate", required = false) String toDate) 
	{
		loadPreferences(actionRequest);
		logger.message("searchFilter");
		logger.message("uid=" + (uid != null ? uid : ""));
		logger.message("personalIdentifier=" + (personalIdentifier != null ? personalIdentifier : ""));
		logger.message("activity=" + (activity != null ? activity : ""));
		if (sessionBean != null) {
			sessionBean.setFilterUid(uid != null && uid.trim().length() > 0 ? uid.trim() : null);
			sessionBean.setFilterPersonalIdentifier(personalIdentifier != null && personalIdentifier.trim().length() > 0 ? personalIdentifier.trim() : null);
			sessionBean.setFilterCommonName(commonName != null && commonName.trim().length() > 0 ? commonName.trim() : null);
			sessionBean.setFilterEmail(email != null && email.trim().length() > 0 ? email.trim() : null);
			sessionBean.setFilterActivity(activity);
			sessionBean.setFilterActivityDetails(activityDetails != null && activityDetails.trim().length() > 0 ? activityDetails : null);
			sessionBean.setFilterFromDate(fromDate != null && fromDate.trim().length() > 0 ? fromDate : null);
			sessionBean.setFilterToDate(toDate != null && toDate.trim().length() > 0 ? toDate : null);
			sessionBean.setStart(0);
		}
		// Pass parameters to default view.
		//actionResponse.setRenderParameters(actionRequest.getParameterMap());
		// Returns control to default view.
	}
	
	@ResourceMapping(value = "resourceAuditLog")
	public void resourceAuditLog(
			ResourceRequest resourceRequest, ResourceResponse resourceResponse,
			@RequestParam("draw") Integer draw,
			@RequestParam("start") Integer start,
			@RequestParam("length") Integer length,
			@RequestParam("order[0][column]") Integer orderColumn,
			@RequestParam("order[0][dir]") String order)
	{
		loadPreferences(resourceRequest);		
		logger.message("resourceAuditLog");
		resourceResponse.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		JSONArray ja = new JSONArray();
		
//		Enumeration<String> parameterNames = resourceRequest.getParameterNames();
//        while (parameterNames.hasMoreElements()) {
//            String paramName = parameterNames.nextElement();
//            System.out.print(paramName);            
//            String[] paramValues = resourceRequest.getParameterValues(paramName);
//            for (int i = 0; i < paramValues.length; i++) {
//                String paramValue = paramValues[i];
//                if (i > 0) {
//                	System.out.print(",");
//                }
//                System.out.print("=" + paramValue);
//            }
//            System.out.println("");
//        }
		int totalResults = 0;
		if (sessionBean != null) {
			sessionBean.setResultsPerPage(length);
			sessionBean.setStart(start);
			sessionBean.setOrderColumn(orderColumn);
			sessionBean.setOrder(order);
			
			String filterUid = sessionBean.getFilterUid();
			String filterPersonalIdentifier = sessionBean.getFilterPersonalIdentifier();
			String filterCommonName = sessionBean.getFilterCommonName();
			String filterEmail = sessionBean.getFilterEmail();
			String filterActivity = sessionBean.getFilterActivity();
			String filterActivityDetails = sessionBean.getFilterActivityDetails();
			String filterFromDate = sessionBean.getFilterFromDate();
			String filterToDate = sessionBean.getFilterToDate();
			boolean noData = false;
			if (filterPersonalIdentifier != null && filterPersonalIdentifier.trim().length() > 0) {
				EncryptorAESGCM aesCls = new EncryptorAESGCM();
				String encryptedFilterPersonalIdentifier = aesCls.encryptEgovIdentifier(filterPersonalIdentifier);
				String userUID = pumaCommunicator.getUserUIDsByAttribute(pumaHome, encryptedFilterPersonalIdentifier, AuditLogConstants.LDAP_ATTRIBUTE_EMPLOYEE_NUMBER);
				//String userUID = pumaCommunicator.getUserUIDsByAttribute(pumaHome, filterPersonalIdentifier, AuditLogConstants.LDAP_ATTRIBUTE_EMPLOYEE_NUMBER);
				if (userUID != null) {
					filterUid = userUID;
				} else {
					noData = true;
				}	
			} else if (filterEmail != null && filterEmail.trim().length() > 0) {
				String userUID = pumaCommunicator.getUserUIDsByAttribute(pumaHome, filterEmail, AuditLogConstants.LDAP_ATTRIBUTE_PORTAL_EMAIL);
				if (userUID != null) {
					filterUid = userUID;
				} else {
					noData = true;
				}
			} else if (filterCommonName != null && filterCommonName.trim().length() > 0) {
				String userUID = pumaCommunicator.getUserUIDsByCommonName(pumaHome, filterCommonName);
				if (userUID != null) {
					filterUid = userUID;
				} else {
					noData = true;
				}
			}
			logger.message("resourceAuditLog() -> length=" + length);
			logger.message("resourceAuditLog() -> start=" + start);
			logger.message("resourceAuditLog() -> orderColumn=" + orderColumn);
			logger.message("resourceAuditLog() -> order=" + order);
			logger.message("resourceAuditLog() -> filterUid=" + filterUid);
			logger.message("resourceAuditLog() -> filterPersonalIdentifier=" + filterPersonalIdentifier);
			logger.message("resourceAuditLog() -> filterCommonName=" + filterCommonName);
			logger.message("resourceAuditLog() -> filterEmail=" + filterEmail);
			logger.message("resourceAuditLog() -> filterActivity=" + filterActivity);
			logger.message("resourceAuditLog() -> filterActivityDetails=" + filterActivityDetails);
			logger.message("resourceAuditLog() -> filterFromDate=" + filterFromDate);
			logger.message("resourceAuditLog() -> filterToDate=" + filterToDate);

			String resultsJSON = !noData ? auditLogCommunicator.loadAllAuditLogs(filterUid, filterActivity, filterActivityDetails, filterFromDate, filterToDate, esbEventLogAddress, start, length, orderColumn, order) : null;
			List<AuditLogBean> results = (resultsJSON != null) ? auditLogCommunicator.getAuditLogBeansFromResponse(resultsJSON) : null;			
			if (results != null && results.size() > 0) {
				logger.message("resourceAuditLog() -> results.size()=" + results.size());
				// Load userAttributes.
				Map<String, List<String>> userAttributesHm = new HashMap<String, List<String>>();
				List<String> attributes = null;
				String userUID = null;
				for (int i = 0; i < results.size(); i++) {
					userUID = results.get(i).getUserId();
					if (userAttributesHm.get(userUID) == null) {
						attributes = pumaCommunicator.getCNAndEmailByUserUID(pumaHome, userUID);
						userAttributesHm.put(userUID, attributes);
					}
				}
				JSONArray tmpJA = null; 
				String description = null;
//				for (int i = start; i < results.size(); i++) {
				for (int i = 0; i < results.size(); i++) {
					attributes = userAttributesHm.get(results.get(i).getUserId());
					//if (start + length == i) {break;}
					description = results.get(i).getActivityDescription() != null ? results.get(i).getActivityDescription() : "";
					if (AuditLogConstants.EVENT_LOG_PORTAL_LAST_VISITED_SERVICE.equalsIgnoreCase(results.get(i).getActivityName())
							|| AuditLogConstants.EVENT_LOG_PORTAL_ADD_FAVOURITE_SERVICE.equalsIgnoreCase(results.get(i).getActivityName())
							|| AuditLogConstants.EVENT_LOG_PORTAL_REMOVE_FAVOURITE_SERVICE.equalsIgnoreCase(results.get(i).getActivityName())) {
						// "description" will contains contentUUID.
						if (EgovWCMCache.getServiceById() != null) {
							EgovService service = EgovWCMCache.getServiceById().get(description);
							if (service != null) {
								description = service.getTitle();
							}
						}
					}
					tmpJA = new JSONArray();
					tmpJA.put(results.get(i).getUserId());
//					tmpJA.put(personalIdentifiersHm.get(results.get(i).getUserId()));
					tmpJA.put(attributes != null && attributes.size() > 0 ? attributes.get(0) : "");
					tmpJA.put(attributes != null && attributes.size() > 1 ? attributes.get(1) : "");
					tmpJA.put(getActivityName(results.get(i).getActivityName(), resourceRequest));
					tmpJA.put(description);
					tmpJA.put(results.get(i).getDateCreated());
					tmpJA.put(results.get(i).getIpAddress());					
					ja.put(tmpJA);						
				}				
			} else {
				logger.message("resourceAuditLog() -> requests.length=0");
			}
			//totalResults = results != null ? results.size() : 0;
			totalResults = (resultsJSON != null) ? auditLogCommunicator.getRecordsTotalFromRepsonse(resultsJSON) : 0;			
		} 
		json.put("draw", draw);	
		json.put("recordsTotal", totalResults);	
		json.put("recordsFiltered", totalResults);	
		json.put("data", ja);	
		try {
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			resourceResponse.setContentType("application/json; charset=UTF-8");
			resourceResponse.getWriter().print(jsonPrettyPrintString);	    
			resourceResponse.getWriter().flush();
			resourceResponse.getWriter().close();	
		} catch (IOException e) {			
			e.printStackTrace();
		}	 
		
		System.out.println("resourceAuditLog() -> resultsPerPage=" + sessionBean.getResultsPerPage());
		System.out.println("resourceAuditLog() -> start=" + sessionBean.getStart());
		System.out.println("resourceAuditLog() -> order=" + sessionBean.getOrder().toLowerCase());
	}
	
	@ResourceMapping(value = "resource-one")
	public void resourceOne(ResourceRequest resourceRequest, ResourceResponse response) {
		loadPreferences(resourceRequest);
		logger.message("Resource one");
	}
	
	private void loadPreferences(PortletRequest request) {
		PortletPreferences prefs = request.getPreferences();		
		PortletViewController.esbEventLogAddress = prefs.getValue(AuditLogConstants.SETTING_PARAMETER_ESB_EVENT_LOGGER_ADDRESS, AuditLogConstants.ESB_LOGGING_URL);
		if (!sessionBean.isFilterInitialised()) {
			try {
				sessionBean.setResultsPerPage(Integer.parseInt(prefs.getValue(AuditLogConstants.SETTING_PARAMETER_RESULTS_PER_PAGE, AuditLogConstants.RESULTS_PER_PAGE + "")));			
			} catch (Exception e) {
				e.printStackTrace();
			}		
		}
		PortletViewController.language = prefs.getValue(AuditLogConstants.SETTING_PARAMETER_LANGUAGE, AuditLogConstants.LANGUAGE_BG);
		PortletViewController.isDebug = "1".equalsIgnoreCase(prefs.getValue(AuditLogConstants.SETTING_PARAMETER_DEBUG, ""));		
	}
	
	private String getActivityName(String activity, PortletRequest portletRequest) {
		if (AuditLogConstants.EVENT_LOG_PORTAL_ACTIVATE_PROFILE.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.activate.profile", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_LOGIN_OPERATION.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.login", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_DEACTIVATE_PROFILE.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.deactivate.profile", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_DEACTIVATE_ALL_PROFILES.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.deactivate.all.profiles", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_ADD_USER_TO_PROFILE.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.add.user.to.profile", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_ADD_FAVOURITE_SERVICE.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.add.favourite.service", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_REQUEST_PROFILE.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.request.profile", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_LOGOUT_OPERATION.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.logout", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_PROFILE_PERSONALIZATION.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.profile.personalization", null, getLocale(portletRequest));			
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_LAST_VISITED_SERVICE.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.last.visited.service", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_REMOVE_USER_FROM_PROFILE.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.remove.user.from.profile", null, getLocale(portletRequest));			
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_REMOVE_FAVOURITE_SERVICE.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.remove.favourite.service", null, getLocale(portletRequest));			
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_EDIT_USER_OF_PROFILE.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.edit.user.of.profile", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_EDIT_PROFILE.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.edit.profile", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_MODERATOR_EDIT_PROFILE.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.edit.profile.moderator", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_MODERATOR_EDIT_PROFILE_ACCESS.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.moderator.edit.profile.access", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_MODERATOR_CREATE_LE_PROFILE_REIK.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.moderator.create.reik.profile", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_APPROVE_PROFILE_REQUEST.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.approve.profile.request", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_CANCEL_PROFILE_REQUEST.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.cancel.profile.request", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_SWITCH_PROFILE.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.switch.profile", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_ADD_REGISTER_GROUP.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.add.register.group", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_UPDATE_REGISTER_GROUP.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.update.register.group", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_DEACTIVATE_REGISTER_GROUP.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.deactivate.register.group", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_ACTIVATE_REGISTER_GROUP.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.activate.register.group", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_ADD_REGISTER_GROUP_PARAMETER.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.add.register.group.parameter", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_UPDATE_REGISTER_GROUP_PARAMETER.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.update.register.group.parameter", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_DEACTIVATE_REGISTER_GROUP_PARAMETER.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.deactivate.register.group.parameter", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_ACTIVATE_REGISTER_GROUP_PARAMETER.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.activate.register.group.parameter", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_MARK_REQUIRED_REGISTER_GROUP_PARAMETER.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.mark.required.register.group.parameter", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_UNMARK_REQUIRED_REGISTER_GROUP_PARAMETER.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.mark.not.required.register.group.parameter", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_MARK_CONSENT_REGISTER_GROUP_PARAMETER.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.mark.conset.register.group.parameter", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_UNMARK_CONSENT_REGISTER_GROUP_PARAMETER.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.mark.not.conset.register.group.parameter", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_EDIT_PROFILE_PARAMETERS.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.edit.profile.parameters", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_ADD_AUTHORIZATION_SYSTEM.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.add.authorization.system", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_UPDATE_AUTHORIZATION_SYSTEM.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.update.authorization.system", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_ADD_AUTHORIZATION_ACTION.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.add.authorization.action", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_UPDATE_AUTHORIZATION_ACTION.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.update.authorization.action", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_MODERATOR_CANCEL_AUTHORIZATION.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.moderator.cancel.authorization", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_ADD_AUTHORIZATION.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.add.authorization", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_CANCEL_AUTHORIZATION.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.cancel.authorization", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_CONFIRM_PROFILE.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.confirm.profile", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_INVITE_USER_TO_PROFILE.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.invite.user.to.profile", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_REINVITE_USER_TO_PROFILE.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.reinvite.user.to.profile", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_REMOVE_INVITATION_TO_PROFILE.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.remove.user.invitation.to.profile", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_ADD_PROFILE_IDENTIFIER.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.add.profile.identifier", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_REMOVE_PROFILE_IDENTIFIER.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.remove.profile.identifier", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_SET_DEFAULT_PROFILE.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.set.default.profile", null, getLocale(portletRequest));
		} else if (AuditLogConstants.EVENT_LOG_PORTAL_REGIX_UIC_CLOSED.equalsIgnoreCase(activity)) {
			return messageSource.getMessage("event.log.regix.uic.closed", null, getLocale(portletRequest));
		}
		return activity;
	}
	
	private Locale getLocale(PortletRequest request) {
		PortletPreferences prefs = request.getPreferences();
		return new Locale(prefs.getValue(AuditLogConstants.SETTING_PARAMETER_LANGUAGE, AuditLogConstants.LANGUAGE_BG));
	}
	
}
