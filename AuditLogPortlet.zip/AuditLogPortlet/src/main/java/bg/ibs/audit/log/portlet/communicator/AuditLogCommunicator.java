package bg.ibs.audit.log.portlet.communicator;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.cert.X509Certificate;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import bg.ibs.audit.log.portlet.AuditLogConstants;
import bg.ibs.audit.log.portlet.beans.AuditLogBean;
import bg.ibs.audit.log.portlet.utils.AuditLogLogger;

@Component
public class AuditLogCommunicator {
	@Autowired
	AuditLogLogger logger;
	
	private static DateTimeFormatter customFormatter = DateTimeFormatter.ofPattern("dd.MM.yyyy");
	
	public String loadAllAuditLogs(String userUID, String activityName, String activityDetails, String fromDate, String toDate, String esbEventLogAddress, int start, int length, int orderColumn, String order) {
		logger.message("loadAllAuditLogs(" + userUID + "," + activityName + "," + activityDetails + "," + fromDate + "," + toDate + "," + esbEventLogAddress + "," + start + "," + length + "," + orderColumn + "," + order + ")");
		StringBuilder strBuf = new StringBuilder();

        HttpsURLConnection conn = null;
        BufferedReader reader = null;
        
        try {
			// Create a trust manager that does not validate certificate chains.
	        TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
	            public java.security.cert.X509Certificate[] getAcceptedIssuers() {return null;}
	            public void checkClientTrusted(X509Certificate[] certs, String authType) {}
	            public void checkServerTrusted(X509Certificate[] certs, String authType) {}
	        }
	        };
	
	        logger.message("AuditLogCommunicator -> loadAllAuditLogs() trustAllCerts - done.");
	        // Install the all-trusting trust manager.
	        SSLContext sc = SSLContext.getInstance("SSL");
	        sc.init(null, trustAllCerts, new java.security.SecureRandom());
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
	        
	        logger.message("AuditLogCommunicator -> loadAllAuditLogs() SSLContext init - done.");
	
	        // Create all-trusting host name verifier.
	        HostnameVerifier allHostsValid = new HostnameVerifier() {
	            public boolean verify(String hostname, SSLSession session) {
	                return true;
	            }
	        };
	
	        // Install the all-trusting host verifier.
	        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	        
	        logger.message("AuditLogCommunicator -> loadAllAuditLogs() allHostsValid - done.");
	        logger.message("AuditLogCommunicator -> loadAllAuditLogs() url:" + esbEventLogAddress + "/retrieveEvent");
	       
	        URL url = new URL(esbEventLogAddress + "/retrieveEvent" + ((activityDetails != null && activityDetails.trim().length() > 0) ? "?activityDetails=" + URLEncoder.encode(activityDetails, StandardCharsets.UTF_8.toString()) : ""));
	        logger.message("AuditLogCommunicator -> loadAllAuditLogs() FINAL url:" + esbEventLogAddress + "/retrieveEvent" + ((activityDetails != null && activityDetails.trim().length() > 0) ? "?activityDetails=" + URLEncoder.encode(activityDetails, StandardCharsets.UTF_8.toString()) : ""));
	        conn = (HttpsURLConnection) url.openConnection();
	        conn.setConnectTimeout(5000); //set timeout to 5 seconds
	        conn.setReadTimeout(5000); //set timeout to 5 seconds
	        
	        conn.setRequestMethod("GET");
	        conn.setRequestProperty("Content-Type", "application/json; utf-8");
	        conn.setRequestProperty("Accept", "application/json");
	        if (fromDate != null && fromDate.trim().length() > 0) {
	        	try {	        		
	        		LocalDate ld = LocalDate.parse(fromDate, customFormatter);
	        		conn.setRequestProperty("fromDate", ld.toString());
	        	} catch (Exception e) {
					e.printStackTrace();
				}	        	
	        }
	        if (toDate != null && toDate.trim().length() > 0) {
	        	try {	        		
	        		LocalDate ld = LocalDate.parse(toDate, customFormatter);
	        		conn.setRequestProperty("toDate", ld.toString());
	        	} catch (Exception e) {
					e.printStackTrace();
				}	        	
	        }
	        if (activityName != null && activityName.trim().length() > 0) {
	        	conn.setRequestProperty("activity", activityName);
	        }        
//	        if (activityDetails != null && activityDetails.trim().length() > 0) {
//	        	conn.setRequestProperty("activityDetails", activityDetails);
//	        }        	        
	        if (AuditLogConstants.COLUMN_DATE == orderColumn) {
	        	conn.setRequestProperty("orderField", "CREATION_DATE");
	        } else if (AuditLogConstants.COLUMN_UID == orderColumn) {
	        	conn.setRequestProperty("orderField", "USER_ID");
	        } else if (AuditLogConstants.COLUMN_ACTIVITY_DETAILS == orderColumn) {
	        	conn.setRequestProperty("orderField", "ACTIVITY_DETAILS");
	        }
	        if (order == null || order.trim().length() == 0) {
	        	order = "DESC";
	        }
	        conn.setRequestProperty("order", order.toUpperCase());	
	        conn.setRequestProperty("start", start + "");
	        conn.setRequestProperty("limit", length + "");
	        if (userUID != null) {
	        	conn.setRequestProperty("userId", userUID);
	        }
	        logger.message("AuditLogCommunicator -> loadAllAuditLogs() before setDoOutput - done.");
	        conn.setDoOutput(true);
	        
	        java.util.Map<String, List<String>> properties = conn.getRequestProperties();
	        java.util.Set<String> hdrKeys = properties.keySet();
	        logger.message("------------------------------");
	        for (String k : hdrKeys) {
	            logger.message("Key: " + k + "  Value: " + properties.get(k));
	        }
	        logger.message("------------------------------");
	
	        if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
	        	if (conn.getResponseCode() == HttpURLConnection.HTTP_NOT_FOUND) {
	        		return null;
	        	}
	            throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode());
	        }
	
	        logger.message("AuditLogCommunicator -> loadAllAuditLogs() after setDoOutput, going to read response.");
	        
	        reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
	        String output = null;
	        while ((output = reader.readLine()) != null) {
	            strBuf.append(output);
	        }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
        
        String result = strBuf.toString();
        System.out.println("result=" + result);
        if (result != null && result.trim().length() > 0) {
	        return result;
        }
        logger.message("AuditLogCommunicator -> loadAllAuditLogs() done.");
        return null;
	}
	
	public List<AuditLogBean> getAuditLogBeansFromResponse(String response) {
		if (response != null && response.trim().length() > 0) {
	        JSONObject jsonObject = new JSONObject(response);
	        JSONObject jo = new JSONObject(response);
	        JSONArray ja = jsonObject.getJSONArray("events");
	        if (ja != null && ja.length() > 0) {
	        	logger.message("AuditLogCommunicator -> getAuditLogBeansFromResponse(): total:" + ja.length());
	        	List<AuditLogBean> auditLogBeans = new ArrayList<AuditLogBean>();
	        	AuditLogBean auditLogBean = null;
	        	for (int i = 0; i < ja.length(); i++) {
	        		jo = ja.getJSONObject(i);
	        		logger.message("AuditLogCommunicator -> loadAllAuditLogs():userId=" + jo.get("userId").toString());
	        		logger.message("AuditLogCommunicator -> loadAllAuditLogs():activity=" + jo.get("activity").toString());
	        		logger.message("AuditLogCommunicator -> loadAllAuditLogs():activityDetails=" + jo.get("activityDetails").toString());
	        		logger.message("AuditLogCommunicator -> loadAllAuditLogs():page=" + jo.get("page").toString());
	        		logger.message("AuditLogCommunicator -> loadAllAuditLogs():ipaddress=" + jo.get("ipAddress").toString());
	        		logger.message("AuditLogCommunicator -> loadAllAuditLogs():dateCreated=" + jo.get("dateCreated").toString());
	        		auditLogBean = new AuditLogBean();
	        		auditLogBean.setUserId(jo.get("userId").toString());
	        		auditLogBean.setActivityName(jo.get("activity").toString());
	        		auditLogBean.setActivityDescription(jo.get("activityDetails").toString());
	        		auditLogBean.setPage(!"null".equals(jo.get("page").toString()) ? jo.get("page").toString() : "");
	        		auditLogBean.setIpAddress(jo.get("ipAddress") != null && !"null".equals(jo.get("ipAddress").toString()) ? jo.get("ipAddress").toString() : null);
	        		auditLogBean.setDateCreated(jo.get("dateCreated").toString());
	        		auditLogBeans.add(auditLogBean);
				}
	        	return auditLogBeans;		            	
	        }
		}
		return null;
	}
	
	public int getRecordsTotalFromRepsonse (String response) {
		if (response != null && response.trim().length() > 0) {
	        return Integer.parseInt(new JSONObject(response).get("recordsTotal").toString());
		}
		return 0;
	}
	
}
