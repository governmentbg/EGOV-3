package bg.ibs.audit.log.portlet;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.web.context.annotation.SessionScope;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.view.InternalResourceView;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import bg.ibs.audit.log.portlet.beans.AuditLogSessionBean;

@Configuration 
@ComponentScan(basePackages = {"bg.ibs.audit.log.portlet"})
public class AppConfig  {
		 
	@Bean(name = "messageSource")
	public ReloadableResourceBundleMessageSource getMessageSource() {
      ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
      messageSource.setBasename("classpath:/bg/ibs/audit/log/portlet/nl/AuditLogPortletResource");
      messageSource.setFallbackToSystemLocale(false);
      //messageSource.setDefaultEncoding("UTF-8");
      messageSource.setUseCodeAsDefaultMessage(true);
      return messageSource;
	}
	
	@Bean(name = "viewResolver")
	public ViewResolver getViewResolver() {
	 InternalResourceViewResolver resolver = new InternalResourceViewResolver();
	 resolver.setViewClass(InternalResourceView.class);
	 resolver.setPrefix("/WEB-INF/jsp/");
	 resolver.setSuffix(".jsp");
	 resolver.setOrder(1);
//	 resolver.setViewClass(org.springframework.web.servlet.view.JstlView.class);
	 resolver.setContentType("text/html; charset=UTF-8");
	 resolver.setCache(true);
	 return resolver;
	}
	
	@Bean
    @SessionScope
    public AuditLogSessionBean sessionScopedBean() {
		System.out.println("ScopesConfig=sessionScopedBean");
        return new AuditLogSessionBean();
    }
}
