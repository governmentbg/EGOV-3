package com.ibm.pollviewer;

import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import com.ibm.poll.management.PollManagement;

public class PollViewerContainerManager {
	public static void process(RenderRequest request, RenderResponse response, PollViewerPortletSessionBean sessionBean) {
		PollManagement pollManagement = new PollManagement();
		sessionBean.clear();
		if (PollViewerPortlet.currentPollId != null && PollViewerPortlet.currentPollId.trim().length() > 0) {
			if (pollManagement.loadActivePollByIdWithAllRelative(PollViewerPortlet.currentPollId) == 1) {
				sessionBean.setPoll(pollManagement.getCurrentPoll());
			}
		} else {
			if (sessionBean.getPollId() != null) {
				if (pollManagement.loadActivePollByIdWithAllRelative(sessionBean.getPollId()) == 1) {
					sessionBean.setPoll(pollManagement.getCurrentPoll());					
					return;
				} else {
					sessionBean.setPollId(null);
					sessionBean.setPoll(null);
				}
			}
			if (pollManagement.loadAllActivePolls(PollViewerPortlet.language, PollViewerPortlet.vp) > 0) { 
				sessionBean.setPolls(pollManagement.getPolls());
				// IF ONLY ONE POLL IS FOUND AND THE VIEW IS NOT EXPLICITLY SET TO "LIST" => LOAD IT DIRECTLY /SKIP LIST/
				if (sessionBean.getPolls() != null && sessionBean.getPolls().length == 1 && !PollViewerPortlet.VIEW_LIST.equals(PollViewerPortlet.view)) { 
					if (pollManagement.loadActivePollByIdWithAllRelative(sessionBean.getPolls()[0].getId()) == 1) {
						sessionBean.setPoll(pollManagement.getCurrentPoll());
						sessionBean.setPollId(null);
					} 
					sessionBean.setPolls(null);
				}
			}
		}
	}
}
