package com.ibm.pollviewer;

import com.ibm.poll.bean.Message;
import com.ibm.poll.dbo.Poll;

public class PollViewerPortletSessionBean {
	private String currentPage = PollViewerPortlet.INDEX_JSP;
	private String pollId = null;
	private Poll poll = null;
	private Poll[] polls = null;
	private Message message = null;

	public String getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}
	
	public String getPollId() {
		return pollId;
	}
	
	public void setPollId(String pollId) {
		this.pollId = pollId;
	}
	
	public Poll getPoll() {
		return poll;
	}
	
	public void setPoll(Poll poll) {
		this.poll = poll;
	}
	
	public Poll[] getPolls() {
		return polls;
	}
	
	public void setPolls(Poll[] polls) {
		this.polls = polls;
	}

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}
	
	public void clear() {
		this.message = null;
		this.poll = null;
		this.polls = null;
	}
}
