package com.ibm.pollviewer;

import java.util.ResourceBundle;

import javax.portlet.ActionRequest;

import com.ibm.poll.management.PollManagement;

public class PollViewerActionManager {

	public boolean process(PollViewerPortletSessionBean sessionBean, ActionRequest request, ResourceBundle bundle) {
		PollManagement pollManagement = new PollManagement();
		if (pollManagement.loadActivePollByIdWithAllRelative(sessionBean.getPoll().getId()) == 1) { // LOAD CURRENT POLL DATA...
			if (!sessionBean.getCurrentPage().equals(PollViewerPortlet.RESULT_JSP)) {//this is just reload event, do not create result again
				pollManagement.createPollQuestionResult(pollManagement.getCurrentPoll(), request, PollViewerPortlet.currentUserDN);	
			}
			sessionBean.setMessage(null);
			sessionBean.setCurrentPage(PollViewerPortlet.RESULT_JSP);
			pollManagement = null;
			return true;
		} 
		return false;
	}
}
