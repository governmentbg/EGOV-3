package com.ibm.pollviewer;

import java.io.IOException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.GenericPortlet;
import javax.portlet.PortletException;
import javax.portlet.PortletMode;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequest;
import javax.portlet.PortletRequestDispatcher;
import javax.portlet.PortletSession;
import javax.portlet.ReadOnlyException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ValidatorException;
import javax.portlet.WindowState;

import com.ibm.poll.bean.Message;
import com.ibm.poll.db.DBPool;
import com.ibm.poll.db.DBResources;
import com.ibm.poll.utils.PollUtils;
import com.ibm.portal.um.PumaHome;
import com.ibm.portal.um.PumaProfile;
import com.ibm.portal.um.exceptions.PumaException;

public class PollViewerPortlet extends GenericPortlet {
  
	public static final String JSP_FOLDER    = "/_PollViewer/jsp/";    // JSP folder name
      
	public static final String INDEX_JSP     = "index";         // JSP file name to be rendered on the view mode
	public static final String RESULT_JSP    = "result";         // JSP file name to be rendered on the view mode
	public static final String CONFIG_JSP    = "PollViewerPortletConfig";       // JSP file name to be rendered on the configure mode
	public static final String EDIT_DEFAULTS_JSP    = "PollViewerPortletEditDefaults";       // JSP file name to be rendered on the configure mode
	   
	public static final String SESSION_BEAN  = "PollViewerPortletSessionBean";  // Bean name for the portlet session
	public static final String FORM_SUBMIT   = "PollViewerPortletFormSubmit";   // Action name for submit form
	public static final String FORM_TEXT     = "PollViewerPortletFormText";     // Parameter name for the text input
     
	public static final String CONFIG_SUBMIT = "PollViewerPortletConfigSubmit"; // Action name for submit form
	public static final String CONFIG_CANCEL = "PollViewerPortletConfigCancel"; // Action name for submit form
	public static final String EDIT_DEFAULTS_SUBMIT = "PollViewerPortletEditDefaultsSubmit"; // Action name for submit form
	public static final String EDIT_DEFAULTS_CANCEL = "PollViewerPortletEditDefaultsCancel"; // Action name for submit form
 
    public static final String ERROR_MESSAGE = "PollViewerPortletErrorMessage"; // Parameter name for the validation error message
	public static final String ERROR_KEYS    = "PollViewerPortletErrorKeys";    // Parameter name for the validation failed keys

	private static final PortletMode CUSTOM_CONFIG_MODE = new PortletMode("config");
	private static final PortletMode CUSTOM_EDIT_DEFAULTS_MODE = new PortletMode("edit_defaults");
	
	public static final String ACTION_CHANGE_MODE = "changeMode";
	public static final String ACTION_CHANGE_PAGE = "changePage";
	public static final String ACTION_SUBMIT = "submit";
	
	public static final String PARAMETER_ACTION = "action";
	public static final String PARAMETER_ID = "id";
	
	public static final String THEME_NAME_IBM = "ibm";
	public static final String THEME_NAME_AGENCY = "agency";
	public static final String THEME_NAME_TEMPLATE = "template";
	public static final String THEME_NAME_NRA = "nra";
	
	public static final String VIEW_LIST = "1";
	public static final String HIDE_DESC_IN_SINGLE_MODE = "1";
	public static final String OVERWRITE_PORTAL_BREADCRUMB = "1";
	
	
	public static final String SETTING_PARAMETER_POLL_ID = "wps.poll.id";
	public static final String SETTING_PARAMETER_WIDTH = "wps.poll.width";
	public static final String SETTING_PARAMETER_HEIGHT = "wps.poll.height";
	public static final String SETTING_PARAMETER_LANGUAGE = "wps.poll.language";
	public static final String SETTING_PARAMETER_VP = "wps.poll.vp";
	public static final String SETTING_PARAMETER_VIEW = "wps.poll.view";
	public static final String SETTING_PARAMETER_THEME = "wps.poll.theme";
	public static final String SETTING_PARAMETER_HIDE_DESC_IN_SINGLE_MODE = "wps.poll.hide.desc.in.sigle.mode";
	public static final String SETTING_PARAMETER_OVERWRITE_PORTAL_BREADCRUMB = "wps.poll.overwrite.portal.breadcrumb";
	
	public static boolean preferencesLoaded = false;
	private static PumaHome pumaHome = null;
	public static boolean userLoggedIn = false;
	public static com.ibm.portal.um.User currentUser = null;
	public static String currentUserDN = null;
	public static String currentPollId = null; 
	public static String width = null; 
	public static String height = null; 
	public static String language = "bg";
	public static String vp = null;
	public static String view = null;
	public static String theme = "ibm";	
	public static String hideDescInSingleMode = null;	
	public static String overwritePortalBreadCrumb = null;

	public void init() throws PortletException{
		super.init(); 
		InitialContext initialcontext;
		try {
			initialcontext = new InitialContext();
			try {
				initialcontext.lookup("portletservice/com.ibm.portal.state.service.PortletStateManagerService");
			} catch (Exception exception) {
				System.out.println(exception.getMessage());
				exception.printStackTrace();
			}
		} catch (NamingException e) {
			System.out.println(e.getMessage());
		}
		try {
			initialcontext = new InitialContext();
			pumaHome = (PumaHome) initialcontext.lookup("portal:service/usermanagement/Puma");
		} catch (NamingException namingexception) {
			namingexception.printStackTrace();
		}
		String realPath = getPortletContext().getRealPath("/");
		if (DBResources.loadProps(realPath)) {
			System.out.print("------ APPLICATION STARTED NORMALLY: [ OK ]");
		}
	}

	public void doView(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		// Set the MIME type for the render response
		response.setContentType(request.getResponseContentType());

		// Check if portlet session exists
		PollViewerPortletSessionBean sessionBean = getSessionBean(request);
		if( sessionBean==null ) {
			response.getWriter().println("<b>NO PORTLET SESSION YET</b>");
			return;
		}
		// Invoke the JSP to render
		PortletRequestDispatcher rd = null;
		PollViewerContainerManager.process(request, response, sessionBean); 
		rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, sessionBean.getCurrentPage()));
		rd.include(request,response);
	}

	protected void doDispatch(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		if (!WindowState.MINIMIZED.equals(request.getWindowState())){
			PollUtils.loadPreferences(request);
			userLoggedIn = false; 
			if (getPumaHome() != null) {
				com.ibm.portal.um.PumaProfile pumaProfile = getPumaHome().getProfile();
				if (pumaProfile != null) {
					try {
						com.ibm.portal.um.User user = pumaProfile.getCurrentUser();
						if (user != null) {
							userLoggedIn = true;
							currentUser = user;
							currentUserDN = pumaProfile.getIdentifier(user);
						}
					} catch (PumaException e) {
						System.out.println(e.getMessage());
						e.printStackTrace();
					}
				}
			}
			PortletMode mode = request.getPortletMode();			
			if (CUSTOM_CONFIG_MODE.equals(mode)) {
				doCustomConfigure(request, response);
				return;
			}
			else if (CUSTOM_EDIT_DEFAULTS_MODE.equals(mode)) {
				doCustomEditDefaults(request, response);
				return;
			}
		}
		super.doDispatch(request, response);
	}
 
	public void processAction(ActionRequest request, ActionResponse response) throws PortletException, java.io.IOException {
		PollViewerPortletSessionBean sessionBean = getSessionBean(request);		
		sessionBean.setMessage(null);
		String action = request.getParameter(PARAMETER_ACTION);
		if (ACTION_CHANGE_MODE.equals(action)) {
			String id = request.getParameter(PARAMETER_ID);
			sessionBean.setPollId(id);
			System.out.println("change mode, id: " + id);
		} else if (ACTION_CHANGE_PAGE.equals(action)) {
			String id = request.getParameter(PARAMETER_ID);
			System.out.println("change page, id: " + id);
			sessionBean.setPollId(null);
			sessionBean.setCurrentPage(id);
		} else if (ACTION_SUBMIT.equals(action)) {
			PollViewerActionManager pollViewerActionManager = new PollViewerActionManager();
			pollViewerActionManager.process(sessionBean, request, getPortletConfig().getResourceBundle(request.getLocale()));
		} else if (request.getParameter(CONFIG_SUBMIT) != null) {
			String pollId = request.getParameter(SETTING_PARAMETER_POLL_ID);
			String width = request.getParameter(SETTING_PARAMETER_WIDTH);
			String height = request.getParameter(SETTING_PARAMETER_HEIGHT);
			PortletPreferences prefs = request.getPreferences();			
			try {
				prefs.setValue(SETTING_PARAMETER_POLL_ID, pollId);
				prefs.setValue(SETTING_PARAMETER_WIDTH, width);
				prefs.setValue(SETTING_PARAMETER_HEIGHT, height);
				prefs.store();
				sessionBean.setMessage(new Message(PollViewerConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(request.getLocale()).getString("settings.were.saved")));
				response.setPortletMode(PortletMode.VIEW);
				response.setWindowState(WindowState.NORMAL);
			} catch( ReadOnlyException roe ) {
				sessionBean.setMessage(new Message(PollViewerConstants.MESSAGE_TYPE_ERROR, roe.getMessage()));
			} catch( ValidatorException ve ) { 
				sessionBean.setMessage(new Message(PollViewerConstants.MESSAGE_TYPE_ERROR, ve.getMessage()));
			}
		} else if (request.getParameter(CONFIG_CANCEL) != null) {			
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);
		} else if( request.getParameter(EDIT_DEFAULTS_SUBMIT) != null ) {
			String pollId = request.getParameter(SETTING_PARAMETER_POLL_ID);
			String width = request.getParameter(SETTING_PARAMETER_WIDTH);
			String height = request.getParameter(SETTING_PARAMETER_HEIGHT);
			String language = request.getParameter(SETTING_PARAMETER_LANGUAGE);
			String vp = request.getParameter(SETTING_PARAMETER_VP);
			String view = request.getParameter(SETTING_PARAMETER_VIEW);
			String theme = request.getParameter(SETTING_PARAMETER_THEME);
			String hideDescInSingleMode = request.getParameter(SETTING_PARAMETER_HIDE_DESC_IN_SINGLE_MODE);
			String overwritePortalBreadcrumb = request.getParameter(SETTING_PARAMETER_OVERWRITE_PORTAL_BREADCRUMB);
			PortletPreferences prefs = request.getPreferences();			
			try {
				prefs.setValue(SETTING_PARAMETER_POLL_ID, pollId);
				prefs.setValue(SETTING_PARAMETER_WIDTH, width);
				prefs.setValue(SETTING_PARAMETER_HEIGHT, height);
				prefs.setValue(SETTING_PARAMETER_LANGUAGE, language);
				prefs.setValue(SETTING_PARAMETER_VP, vp);
				prefs.setValue(SETTING_PARAMETER_VIEW, view);
				prefs.setValue(SETTING_PARAMETER_THEME, theme);
				prefs.setValue(SETTING_PARAMETER_HIDE_DESC_IN_SINGLE_MODE, hideDescInSingleMode);
				prefs.setValue(SETTING_PARAMETER_OVERWRITE_PORTAL_BREADCRUMB, overwritePortalBreadcrumb);
				prefs.store();
				sessionBean.setMessage(new Message(PollViewerConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(request.getLocale()).getString("settings.were.saved")));
				response.setPortletMode(PortletMode.VIEW);
				response.setWindowState(WindowState.NORMAL);
			} catch( ReadOnlyException roe ) {
				sessionBean.setMessage(new Message(PollViewerConstants.MESSAGE_TYPE_ERROR, roe.getMessage()));
			} catch( ValidatorException ve ) { 
				sessionBean.setMessage(new Message(PollViewerConstants.MESSAGE_TYPE_ERROR, ve.getMessage()));
			}
		} else if (request.getParameter(EDIT_DEFAULTS_CANCEL) != null) {			
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);
		}
	}

	protected void doCustomConfigure(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		// Set the MIME type for the render response
		response.setContentType(request.getResponseContentType());
		// Invoke the JSP to render
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, CONFIG_JSP));
		rd.include(request,response);
	}
	
	protected void doCustomEditDefaults(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		// Set the MIME type for the render response
		response.setContentType(request.getResponseContentType());
		// Invoke the JSP to render
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, EDIT_DEFAULTS_JSP));
		rd.include(request,response);
	}
	
	public void destroy() {
		System.out.println("STOPPING THREADS STARTED");
		DBPool.shutdownDataSource();
		System.out.println("STOPPING THREADS FINISHED");
	}
	
	private static PollViewerPortletSessionBean getSessionBean(PortletRequest request) {
		PortletSession session = request.getPortletSession();
		if( session == null ) {
			return null;
		}
		PollViewerPortletSessionBean sessionBean = (PollViewerPortletSessionBean)session.getAttribute(SESSION_BEAN);
		if( sessionBean == null ) {
			sessionBean = new PollViewerPortletSessionBean();
			session.setAttribute(SESSION_BEAN,sessionBean);
		}
		return sessionBean;
	}

	private static String getJspFilePath(RenderRequest request, String jspFile) {
		String markup = request.getProperty("wps.markup");
		if( markup == null )
			markup = getMarkup(request.getResponseContentType());
		return JSP_FOLDER + markup + "/" + jspFile + "." + getJspExtension(markup);
	}

	private static String getMarkup(String contentType) {
		if( "text/vnd.wap.wml".equals(contentType) )
			return "wml";
        else
            return "html";
	}

	private static String getJspExtension(String markupName) {
		return "jsp";
	}

	public static PumaHome getPumaHome() {
		return pumaHome;
	}

	public static PumaProfile getPumaProfile() {
		return pumaHome.getProfile();
	}
}
