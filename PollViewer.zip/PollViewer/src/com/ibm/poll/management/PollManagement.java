package com.ibm.poll.management;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.portlet.ActionRequest;

import com.ibm.poll.bean.PollResult;
import com.ibm.poll.db.DBResources;
import com.ibm.poll.db.DBTransaction;
import com.ibm.poll.db.FinderException;
import com.ibm.poll.db.QueryExecution;
import com.ibm.poll.dbo.Poll;
import com.ibm.poll.dbo.PollQuestion;
import com.ibm.poll.dbo.PollQuestionLabel;
import com.ibm.poll.dbo.PollQuestionOption;
import com.ibm.poll.dbo.PollQuestionResult;
import com.ibm.poll.dbo.PollStep;
import com.ibm.poll.utils.PollUtils;
import com.ibm.pollviewer.PollViewerConstants;

public class PollManagement {

	private Poll[] polls = null;
	private int pollCounter = 0;
	private Poll currentPoll = null;

	public Poll[] getPolls() {
		return polls;
	}

	public void setPolls(Poll[] polls) {
		this.polls = polls;
	}

	public int getPollCounter() {
		return pollCounter;
	}

	public void setPollCounter(int pollCounter) {
		this.pollCounter = pollCounter;
	}

	public Poll getCurrentPoll() {
		if (currentPoll == null)
			currentPoll = new Poll();
		return currentPoll;
	}

	public void setCurrentPoll(Poll currentPoll) {
		this.currentPoll = currentPoll;
	}

	public boolean selectNextPoll() {
		if (polls != null) {
			if (pollCounter < polls.length) {
				setCurrentPoll(polls[pollCounter++]);
				return true;
			}
		}
		return false;
	}

	public int loadPollById(String id, DBTransaction transaction) {
		try {
			Poll tmpPoll = Poll.findById(id, transaction);
			if (tmpPoll != null) {
				setCurrentPoll(tmpPoll);
				return 1;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			System.out.println("PollManagement : loadPollById : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

	public int loadActivePollByIdWithAllRelative(String pollId) {
		DBTransaction transaction = null;
		int result = -1;
		try {
			transaction = new DBTransaction();
			if (PollViewerConstants._DB_ORACLE.equalsIgnoreCase(DBResources._DB)) {
				QueryExecution.setSessionTimestampFormat(transaction);
			}
			Poll poll = Poll.findByIdActivePoll(pollId, transaction);
			if (poll != null) {
				PollStep[] pollSteps = null;
				try {
					pollSteps = PollStep.findAllStepsByPollId(pollId, transaction);
				} catch (FinderException e) {
				}
				if (pollSteps != null && pollSteps.length > 0) {
					StringBuffer pollStepsIds = new StringBuffer();
					for (int i = 0; i < pollSteps.length; i++) {
						if (pollStepsIds.toString().length() > 0) {
							pollStepsIds.append(",");
						}
						pollStepsIds.append(pollSteps[i].getId());
					}
					PollQuestion[] pollQuestions = null;
					try {
						pollQuestions = PollQuestion.findAllQuestionsByStepIds(pollStepsIds.toString(), transaction);
					} catch (FinderException e) {
					}
					if (pollQuestions != null && pollQuestions.length > 0) {
						StringBuffer pollQuestionsIds = new StringBuffer();
						for (int i = 0; i < pollQuestions.length; i++) {
							if (pollQuestionsIds.toString().length() > 0) {
								pollQuestionsIds.append(",");
							}
							pollQuestionsIds.append(pollQuestions[i].getId());
						}
						PollQuestionOption[] pollQuestionOptions = null;
						try {
							pollQuestionOptions = PollQuestionOption.findAllOptionsByQuestionIds(pollQuestionsIds.toString(), transaction);
						} catch (FinderException e) {
						}
						PollQuestionLabel[] pollQuestionLabels = null;
						try {
							pollQuestionLabels = PollQuestionLabel.findAllLabelsByQuestionIds(pollQuestionsIds.toString(), transaction);
						} catch (FinderException e) {
						}
						// SORT ALL OPTIONS PER QUESTION
						HashMap<String, ArrayList<PollQuestionOption>> pollQuestionOptionsHm = new HashMap<String, ArrayList<PollQuestionOption>>();
						ArrayList<PollQuestionOption> tmpPollQuestionOptionArr = null;
						if (pollQuestionOptions != null && pollQuestionOptions.length > 0) {
							tmpPollQuestionOptionArr = new ArrayList<PollQuestionOption>();
							for (int i = 0; i < pollQuestionOptions.length; i++) {
								tmpPollQuestionOptionArr = pollQuestionOptionsHm.get(pollQuestionOptions[i].getPollQuestionId());
								if (tmpPollQuestionOptionArr == null) {
									tmpPollQuestionOptionArr = new ArrayList<PollQuestionOption>();
								}
								tmpPollQuestionOptionArr.add(pollQuestionOptions[i]);
								pollQuestionOptionsHm.put(pollQuestionOptions[i].getPollQuestionId(), tmpPollQuestionOptionArr);
							}
						}
						// SORT ALL LABELS PER QUESTION
						HashMap<String, ArrayList<PollQuestionLabel>> pollQuestionLabelsHm = new HashMap<String, ArrayList<PollQuestionLabel>>();
						ArrayList<PollQuestionLabel> tmpPollQuestionLabelArr = null;
						if (pollQuestionLabels != null && pollQuestionLabels.length > 0) {
							tmpPollQuestionLabelArr = new ArrayList<PollQuestionLabel>();
							for (int i = 0; i < pollQuestionLabels.length; i++) {
								tmpPollQuestionLabelArr = pollQuestionLabelsHm.get(pollQuestionLabels[i].getPollQuestionId());
								if (tmpPollQuestionLabelArr == null) {
									tmpPollQuestionLabelArr = new ArrayList<PollQuestionLabel>();
								}
								tmpPollQuestionLabelArr.add(pollQuestionLabels[i]);
								pollQuestionLabelsHm.put(pollQuestionLabels[i].getPollQuestionId(), tmpPollQuestionLabelArr);
							}
						}
						// SORT ALL QUESTION PER STEP
						HashMap<String, ArrayList<PollQuestion>> pollQuestionsHm = new HashMap<String, ArrayList<PollQuestion>>();
						ArrayList<PollQuestion> tmpPollQuestionArr = new ArrayList<PollQuestion>();
						for (int i = 0; i < pollQuestions.length; i++) {
							tmpPollQuestionArr = pollQuestionsHm.get(pollQuestions[i].getPollStepId());
							if (tmpPollQuestionArr == null) {
								tmpPollQuestionArr = new ArrayList<PollQuestion>();
							}
							tmpPollQuestionArr.add(pollQuestions[i]);
							pollQuestionsHm.put(pollQuestions[i].getPollStepId(), tmpPollQuestionArr);
						}
						// POPULATE EACH STEP WITH RELATIVE DATA IF NO QUESTION FOUND IN STEP -> SKIP IT...
						ArrayList<PollStep> filteredPollSteps = new ArrayList<PollStep>();
						PollStep tmpStep = null;
						PollQuestion tmpPollQuestion = null;
						for (int i = 0; i < pollSteps.length; i++) {
							tmpStep = pollSteps[i];
							tmpPollQuestionArr = pollQuestionsHm.get(tmpStep.getId());
							if (tmpPollQuestionArr != null && tmpPollQuestionArr.size() > 0) {
								for (int j = 0; j < tmpPollQuestionArr.size(); j++) {
									tmpPollQuestion = tmpPollQuestionArr.get(j);
									tmpPollQuestionOptionArr = pollQuestionOptionsHm.get(tmpPollQuestion.getId());
									if (tmpPollQuestionOptionArr != null) {
										tmpPollQuestion.setPollQuestionOptions((PollQuestionOption[]) tmpPollQuestionOptionArr.toArray(new PollQuestionOption[tmpPollQuestionOptionArr.size()]));
									}
									tmpPollQuestionLabelArr = pollQuestionLabelsHm.get(tmpPollQuestion.getId());
									if (tmpPollQuestionLabelArr != null) {
										tmpPollQuestion.setPollQuestionLabels((PollQuestionLabel[]) tmpPollQuestionLabelArr.toArray(new PollQuestionLabel[tmpPollQuestionLabelArr.size()]));
									}
								}
								tmpStep.setPollQuestions((PollQuestion[]) tmpPollQuestionArr.toArray(new PollQuestion[tmpPollQuestionArr.size()]));
								filteredPollSteps.add(tmpStep);
							}
						}
						poll.setPollSteps((PollStep[]) filteredPollSteps.toArray(new PollStep[filteredPollSteps.size()]));
						setCurrentPoll(poll);
						result = 1;
						tmpPollQuestion = null;
						tmpPollQuestionArr = null;
						tmpPollQuestionLabelArr = null;
						tmpPollQuestionOptionArr = null;
						pollQuestionsHm = null;
						pollQuestionOptionsHm = null;
						pollQuestionLabelsHm = null;
					}
				}
			}
			transaction.commit();
		} catch (Exception e) {
			System.out.println("PollManagement : loadActivePollByIdWithAllRelative : " + e.getMessage());
			e.printStackTrace();
			if (transaction != null) {
				try {
					transaction.commit();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			result = -1;
		}
		return result;
	}

	public int loadAllPolls() {
		try {
			pollCounter = 0;
			polls = null;
			polls = Poll.findAll(null);
			if (polls != null) {
				pollCounter = 0;
				return polls.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("PollManagement : loadAllPolls : " + e.getMessage());
		}
		return -1;
	}

	public int loadAllActivePolls(String language, String vp) {
		DBTransaction transaction = null;
		int result = -1;
		try {
			transaction = new DBTransaction();
			pollCounter = 0;
			polls = null;
			if (PollViewerConstants._DB_ORACLE.equalsIgnoreCase(DBResources._DB)) {
				QueryExecution.setSessionTimestampFormat(transaction);
			}
			polls = Poll.findAllActivePolls(transaction, language, vp); 
			if (polls != null && polls.length > 0) {
				PollStep[] pollSteps = null;
				StringBuffer tmpIds = new StringBuffer();
				for (int i = 0; i < polls.length; i++) {
					if (tmpIds.toString().length() > 0) {
						tmpIds.append(",");
					}
					tmpIds.append(polls[i].getId());
				}
				try {
					pollSteps = PollStep.findAllStepsByPollIds(tmpIds.toString(), transaction);
				} catch (FinderException e) {
				}
				if (pollSteps != null && pollSteps.length > 0) {
					HashMap<String, ArrayList<PollStep>> pollStepsHm = new HashMap<String, ArrayList<PollStep>>();
					ArrayList<PollStep> pollStepsArrayList = null;
					pollStepsArrayList = new ArrayList<PollStep>();
					tmpIds = new StringBuffer();
					for (int i = 0; i < pollSteps.length; i++) {
						if (tmpIds.toString().length() > 0) {
							tmpIds.append(",");
						}
						tmpIds.append(pollSteps[i].getId());
					}
					PollQuestion[] pollQuestions = null;
					try {
						pollQuestions = PollQuestion.findAllQuestionsByStepIds(tmpIds.toString(), transaction);
					} catch (FinderException e) {
					}
					if (pollQuestions != null && pollQuestions.length > 0) {
						ArrayList<String> stepIds = new ArrayList<String>();
						for (int i = 0; i < pollQuestions.length; i++) {
							if (!stepIds.contains(pollQuestions[i].getPollStepId())) { // PUT ALL STEPIDS THAT HAVE QUESTIONS...
								stepIds.add(pollQuestions[i].getPollStepId());
							}
						}
						// FILTER STEPS...
						for (int i = 0; i < pollSteps.length; i++) {
							if (stepIds.contains(pollSteps[i].getId())) {
								pollStepsArrayList.add(pollSteps[i]);
							}
						}
						pollSteps = (PollStep[]) pollStepsArrayList.toArray(new PollStep[pollStepsArrayList.size()]);
						pollStepsArrayList = new ArrayList<PollStep>();
						// ORDER STEPS FOR EACH POLL
						for (int i = 0; i < pollSteps.length; i++) {
							pollStepsArrayList = pollStepsHm.get(pollSteps[i].getPollId());
							if (pollStepsArrayList == null) {
								pollStepsArrayList = new ArrayList<PollStep>();
							}
							pollStepsArrayList.add(pollSteps[i]);
							pollStepsHm.put(pollSteps[i].getPollId(), pollStepsArrayList);
						}
						ArrayList<Poll> pollArrayList = new ArrayList<Poll>();
						for (int i = 0; i < polls.length; i++) {
							pollStepsArrayList = pollStepsHm.get(polls[i].getId());
							if (pollStepsArrayList != null) { // HAS STEP(S)
								pollArrayList.add(polls[i]);
							}
						}
						polls = (Poll[]) pollArrayList.toArray(new Poll[pollArrayList.size()]);
						pollCounter = 0;
						result = polls.length;
					} else {
						polls = null;
					}
				} else {
					polls = null;
				}
			}
			transaction.commit();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("PollManagement : loadAllActivePolls : " + e.getMessage());
			if (transaction != null) {
				try {
					transaction.commit();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			result = -1;
		}
		return result;
	}

	public PollResult getAllPollQuestionResultsByPollId(String pollId) {	
		PollResult pollResult = new PollResult();
		HashMap<String, String> results = new HashMap<String, String>();
		HashMap<String, ArrayList<String>> comments = new HashMap<String, ArrayList<String>>();		
		try {
			PollQuestionResult[] pollQuestionResults = null;
			try {
				pollQuestionResults = PollQuestionResult.findAllQuestionResultsByPollId(pollId, null);
			} catch (FinderException e) {
			}	
			if (pollQuestionResults != null && pollQuestionResults.length > 0) {								
				String count = null;
				ArrayList<String> tmp = null;
				for (int i = 0; i < pollQuestionResults.length; i++) {
					count = results.get(pollQuestionResults[i].getPollQuestionOptionId() + "_" + pollQuestionResults[i].getPollQuestionLabelId());
					if (count == null) {
						count = "0";
					}
					try {
						count = String.valueOf(Integer.parseInt(count) + 1);
 					} catch (NumberFormatException e) {
						e.printStackTrace();
					}
					results.put(pollQuestionResults[i].getPollQuestionOptionId() + "_" + pollQuestionResults[i].getPollQuestionLabelId(), count);
					if (pollQuestionResults[i].getQuestionComment() != null && pollQuestionResults[i].getQuestionComment().trim().length() > 0) {
						tmp = comments.get(pollQuestionResults[i].getPollQuestionId());
						if (tmp == null) {
							tmp = new ArrayList<String>();
						}
						tmp.add(pollQuestionResults[i].getQuestionComment());
						comments.put(pollQuestionResults[i].getPollQuestionId(), tmp);
					}
				}				
			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("PollManagement : getAllPollQuestionResultsByPollId : " + e.getMessage());
		}
		pollResult.setResults(results);
		pollResult.setComments(comments);		
		return pollResult;
	}

	public int createPollQuestionResult(Poll poll, ActionRequest request, String userDN) {
		DBTransaction transaction = null;
		long currentTime = System.currentTimeMillis();
		try {
			transaction = new DBTransaction();			
			PollQuestionResult pollQuestionResult = null;
			PollQuestion[] pollQuestions = null;
			PollQuestion pollQuestion = null;
			String[] parameterValues = null;
			String questionComment = null;
			com.ibm.poll.dbo.PollResult pollResult = new com.ibm.poll.dbo.PollResult();
			pollResult.setPollId(poll.getId());
			pollResult.setUserDN(userDN);
			pollResult.setCreationDate(PollUtils.timeMillisToTimestamp(currentTime));
			pollResult.create(transaction);
			for (int i = 0; i < poll.getPollSteps().length; i++) {
				pollQuestions = poll.getPollSteps()[i].getPollQuestions();
				if (pollQuestions != null) {
					for (int j = 0; j < pollQuestions.length; j++) {
						pollQuestion = pollQuestions[j];
						if (PollViewerConstants.QUESTION_TYPE_SIMPLE_ONE.equals(pollQuestion.getType()) || PollViewerConstants.QUESTION_TYPE_SIMPLE_MULTIPLE.equals(pollQuestion.getType())) {
							parameterValues = request.getParameterValues("option_" + pollQuestion.getId());
							questionComment = request.getParameter("comment_" + pollQuestion.getId());
							if (parameterValues != null && parameterValues.length > 0) {
								for (int k = 0; k < parameterValues.length; k++) {
									if (parameterValues[k] == null || parameterValues[k].trim().length() == 0)
										continue;
									pollQuestionResult = new PollQuestionResult();
									pollQuestionResult.setPollResultId(pollResult.getId());
									pollQuestionResult.setPollId(poll.getId());
									pollQuestionResult.setPollStepId(poll.getPollSteps()[i].getId());
									pollQuestionResult.setPollQuestionId(pollQuestion.getId());
									pollQuestionResult.setPollQuestionOptionId(parameterValues[k]);
									if (questionComment != null && questionComment.trim().length() > 0) {
										pollQuestionResult.setQuestionComment(questionComment.trim());
									}
									pollQuestionResult.create(transaction);
								}
							}
						} if (PollViewerConstants.QUESTION_TYPE_OPEN.equals(pollQuestion.getType())) {
							parameterValues = request.getParameterValues("openquestion_" + pollQuestion.getId());
							if (parameterValues != null && parameterValues.length > 0) {
								//System.out.println("question type open, len: " + parameterValues.length);
								for (int k = 0; k < parameterValues.length; k++) {
									if (parameterValues[k] == null || parameterValues[k].trim().length() == 0)
										continue;
									//System.out.println("parameterValues[k]: " + parameterValues[k]);
									pollQuestionResult = new PollQuestionResult();
									pollQuestionResult.setPollResultId(pollResult.getId());
									pollQuestionResult.setPollId(poll.getId());
									pollQuestionResult.setPollStepId(poll.getPollSteps()[i].getId());
									pollQuestionResult.setPollQuestionId(pollQuestion.getId());
									pollQuestionResult.setQuestionComment(parameterValues[k].trim());
									pollQuestionResult.create(transaction);
								}
							}
						} else {
							for (int z = 0; z < pollQuestion.getPollQuestionOptions().length; z++) {
								parameterValues = request.getParameterValues("option_" + pollQuestion.getId() + "_" + pollQuestion.getPollQuestionOptions()[z].getId());
								questionComment = request.getParameter("comment_" + pollQuestion.getId());
								if (parameterValues != null && parameterValues.length > 0) {
									for (int k = 0; k < parameterValues.length; k++) {
										if (parameterValues[k] == null || parameterValues[k].trim().length() == 0)
											continue;
										pollQuestionResult = new PollQuestionResult();
										pollQuestionResult.setPollResultId(pollResult.getId());
										pollQuestionResult.setPollId(poll.getId());
										pollQuestionResult.setPollStepId(poll.getPollSteps()[i].getId());
										pollQuestionResult.setPollQuestionId(pollQuestion.getId());
										pollQuestionResult.setPollQuestionOptionId(pollQuestion.getPollQuestionOptions()[z].getId());
										pollQuestionResult.setPollQuestionLabelId(parameterValues[k]);
										if (questionComment != null && questionComment.trim().length() > 0) {
											pollQuestionResult.setQuestionComment(questionComment.trim());
										}
										pollQuestionResult.create(transaction);
									}
								}
							}
						}
					}
				}
			}
			transaction.commit();
			return 1;
		} catch (Exception e) {
			System.out.println("PollManagement : createPollQuestionResult : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("PollManagement : createPollQuestionResult : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
		}
		return -1;
	}

}
