package com.ibm.poll.db;

public class FinderException extends Exception {

	private static final long serialVersionUID = 3767698392027350664L;
    public FinderException(final String msg) {
        super(msg);
    }

    public FinderException() {

    }
}
