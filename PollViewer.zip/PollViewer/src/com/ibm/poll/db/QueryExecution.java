package com.ibm.poll.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.ibm.pollviewer.PollViewerConstants;

public class QueryExecution {

	private static Connection getConnection() throws SQLException {

		Connection con = DBPool.getConnection();
		if (con == null) {
			throw new SQLException("Connection is NULL");
		}
		return con;

	}

	public static void setSessionTimestampFormat(final DBTransaction transaction) throws FinderException, Exception {
		Connection connection = null;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				Statement statement = connection.createStatement();
				statement.executeUpdate("alter session set NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH24:MI:SSXFF'");
				statement.close();
			} else {
				throw new Exception("Connection or query set is not initialized.");
			}
		} catch (final SQLException e) {
			throw new Exception(e.getMessage());
		} 
	}
	
	public static int getMaxSequenceByPollId(String pollId, DBTransaction transaction) throws FinderException, Exception {
		Connection con = null;
		try {
			if (transaction != null) {
				con = transaction.getConnection();
			} else {
				con = getConnection();
			}
			if (con != null) {
				Statement stmt = con.createStatement();
				String s1 = "SELECT MAX(SEQUENCE)" + " FROM " + PollViewerConstants._SCHEMANAME + "POLLSTEP" + " WHERE POLLID = " + pollId;

				ResultSet rs = stmt.executeQuery(s1);
				if (rs != null && rs.next()) {
					int maxSequence = rs.getInt(1);
					rs.close();
					stmt.close();
					return maxSequence;
				} else {
					throw new FinderException("Unable to find object.");
				}
			} else
				throw new Exception("Connection or query set is not initialized.");
		} catch (SQLException e) {
			throw new Exception(e.getMessage());
		} 
	}
	
	public static int getMaxQuestionSequenceByStepId(String stepId, DBTransaction transaction) throws FinderException, Exception {
		Connection con = null;
		try {
			if (transaction != null) {
				con = transaction.getConnection();
			} else {
				con = getConnection();
			}
			if (con != null) {
				Statement stmt = con.createStatement();
				String s1 = "SELECT MAX(SEQUENCE)" + " FROM " + PollViewerConstants._SCHEMANAME + "POLLQUESTION" + " WHERE POLLSTEPID = " + stepId;

				ResultSet rs = stmt.executeQuery(s1);
				if (rs != null && rs.next()) {
					int maxSequence = rs.getInt(1);
					rs.close();
					stmt.close();
					return maxSequence;
				} else {
					throw new FinderException("Unable to find object.");
				}
			} else
				throw new Exception("Connection or query set is not initialized.");
		} catch (SQLException e) {
			throw new Exception(e.getMessage());
		} 
	}
	
	public static int getMaxLabelSequenceByQuestionId(String questionId, DBTransaction transaction) throws FinderException, Exception {
		Connection con = null;
		try {
			if (transaction != null) {
				con = transaction.getConnection();
			} else {
				con = getConnection();
			}
			if (con != null) {
				Statement stmt = con.createStatement();
				String s1 = "SELECT MAX(SEQUENCE)" + " FROM " + PollViewerConstants._SCHEMANAME + "POLLQUESTIONLABEL" + " WHERE QUESTIONID = " + questionId;
				ResultSet rs = stmt.executeQuery(s1);
				if (rs != null && rs.next()) {
					int maxSequence = rs.getInt(1);
					rs.close();
					stmt.close();
					return maxSequence;
				} else {
					throw new FinderException("Unable to find object.");
				}
			} else
				throw new Exception("Connection or query set is not initialized.");
		} catch (SQLException e) {
			throw new Exception(e.getMessage());
		} 
	}

	public static int decrementPollStepSequence(String pollId, String sequence, DBTransaction transaction) throws FinderException, Exception {
		Connection con = null;
		try {
			if (transaction != null) {
				con = transaction.getConnection();
			} else {
				con = getConnection();
			}
			if (con != null) {
				String query = "UPDATE " + PollViewerConstants._SCHEMANAME + "POLLSTEP SET SEQUENCE = SEQUENCE - 1 WHERE POLLID = " + pollId + " AND SEQUENCE > " + sequence;
				System.out.println("QueryExecution: query => " + query);
				Statement stmt = con.createStatement();
				int result = stmt.executeUpdate(query);
				System.out.println("QueryExecution: UPDATE RESULT = " + result);
				stmt.close();
				return result;
			} else
				throw new Exception("Connection or query set is not initialized.");
		} catch (SQLException e) {
			throw new Exception(e.getMessage());
		} 
	}
}
