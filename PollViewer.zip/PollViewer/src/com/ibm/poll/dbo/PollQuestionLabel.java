package com.ibm.poll.dbo;

import java.util.Hashtable;

import com.ibm.poll.db.DBTransaction;
import com.ibm.poll.db.FinderException;
import com.ibm.poll.db.PersistentObject;
import com.ibm.poll.db.QueryComposer;
import com.ibm.poll.db.QuerySet;
import com.ibm.pollviewer.PollViewerConstants;

public class PollQuestionLabel extends PersistentObject {

	private static String CLASS_NAME = PollQuestionLabel.class.getName();
	protected static String schema = PollViewerConstants._SCHEMANAME;
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "POLLQUESTIONLABEL";
        sequenceName = "SEQ_POLLQUESTIONLABELID";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "POLLQUESTIONLABELID");
        columnMap.put("pollQuestionId", "POLLQUESTIONID");
        columnMap.put("labelText", "LABELTEXT");
        querySet = QueryComposer.composeAll(schema, table, sequenceName, columnMap);
    }
	
    public PollQuestionLabel() {
        super(querySet);
    }
    
    private String pollQuestionId = null;
	private String labelText = null;
	
	public String getPollQuestionId() {
		return pollQuestionId;
	}

	public void setPollQuestionId(String pollQuestionId) {
		this.pollQuestionId = pollQuestionId;
	}

	public String getLabelText() {
		return labelText;
	}

	public void setLabelText(String labelText) {
		this.labelText = labelText;
	}

	public static PollQuestionLabel findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
        return (PollQuestionLabel) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
    }
	
	public static PollQuestionLabel[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllLabels("1=1", transaction);
	}

	public static PollQuestionLabel[] findAllLabelsByQuestionId(String questionId, final DBTransaction transaction) throws FinderException, Exception {
		String cond = columnMap.get("pollQuestionId") + " = " + questionId + " ORDER BY " + columnMap.get("id");
		return findAllLabels(cond, transaction);
	}

	public static PollQuestionLabel[] findAllLabelsByQuestionIds(String questionIds, final DBTransaction transaction) throws FinderException, Exception {
		String cond = columnMap.get("pollQuestionId") + " IN (" + questionIds + ") ORDER BY " + columnMap.get("id");
		return findAllLabels(cond, transaction);
	}

	public static PollQuestionLabel[] findAllLabels(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final PollQuestionLabel[] pollQuestionLabels = new PollQuestionLabel[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				pollQuestionLabels[i] = (PollQuestionLabel) tmp[i];
			}
			return pollQuestionLabels;
		}
		return null;
	}

}
