package com.ibm.poll.dbo;

import java.util.Hashtable;

import com.ibm.poll.db.DBTransaction;
import com.ibm.poll.db.FinderException;
import com.ibm.poll.db.PersistentObject;
import com.ibm.poll.db.QueryComposer;
import com.ibm.poll.db.QuerySet;
import com.ibm.pollviewer.PollViewerConstants;

public class PollQuestion extends PersistentObject {

	private static String CLASS_NAME = PollQuestion.class.getName();
	protected static String schema = PollViewerConstants._SCHEMANAME;
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "POLLQUESTION";
        sequenceName = "SEQ_POLLQUESTIONID";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "POLLQUESTIONID");
        columnMap.put("pollStepId", "POLLSTEPID");
        columnMap.put("type", "TYPE");
        columnMap.put("sequence", "SEQUENCE");
        columnMap.put("title", "TITLE");
        columnMap.put("isCompulsory", "ISCOMPULSORY");
        columnMap.put("commentLabel", "COMMENTLABEL");
        querySet = QueryComposer.composeAll(schema, table, sequenceName, columnMap);
    }
	
    public PollQuestion() {
        super(querySet);
    }
    
    private String pollStepId = null;
    private String type = null;
    private String title = null;
	private String description = null;	
	private String sequence = null;	
	private String isCompulsory = null;
	private String commentLabel = null;
	private PollQuestionOption[] pollQuestionOptions = null; // FOR BUSINESS PURPOSE ONLY
	private PollQuestionLabel[] pollQuestionLabels = null; // FOR BUSINESS PURPOSE ONLY
	
	public String getPollStepId() {
		return pollStepId;
	}

	public void setPollStepId(String pollStepId) {
		this.pollStepId = pollStepId;
	}
	
	public String getType() {
		return type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getSequence() {
		return sequence;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}
	
	public String getIsCompulsory() {
		return isCompulsory;
	}

	public void setIsCompulsory(String isCompulsory) {
		this.isCompulsory = isCompulsory;
	}
	
	public String getCommentLabel() {
		return commentLabel;
	}

	public void setCommentLabel(String commentLabel) {
		this.commentLabel = commentLabel;
	}

	public PollQuestionOption[] getPollQuestionOptions() {
		return pollQuestionOptions;
	}

	public void setPollQuestionOptions(PollQuestionOption[] pollQuestionOptions) {
		this.pollQuestionOptions = pollQuestionOptions;
	}

	public PollQuestionLabel[] getPollQuestionLabels() {
		return pollQuestionLabels;
	}

	public void setPollQuestionLabels(PollQuestionLabel[] pollQuestionLabels) {
		this.pollQuestionLabels = pollQuestionLabels;
	}

	public static PollQuestion findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
        return (PollQuestion) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
    }
		
	public static PollQuestion[] findAllQuestionsByStepId(final String pollStepId, final DBTransaction transaction) throws FinderException, Exception {
		return findQuestions(columnMap.get("pollStepId") + "=" + pollStepId + " ORDER BY " + columnMap.get("sequence"), transaction);
	}

	public static PollQuestion[] findAllQuestionsByStepIds(final String pollStepIds, final DBTransaction transaction) throws FinderException, Exception {
		return findQuestions(columnMap.get("pollStepId") + " IN (" + pollStepIds + ") ORDER BY " + columnMap.get("sequence"), transaction);
	}
	
	public static PollQuestion findBySequenceAndStepId(final String sequence, final String pollStepId, final DBTransaction transaction) throws FinderException, Exception {
        return (PollQuestion) findSingle(columnMap.get("sequence") + "=" + sequence + " AND " +columnMap.get("pollStepId") + "=" + pollStepId, CLASS_NAME, transaction);
    }

	public static PollQuestion[] findQuestions(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final PollQuestion[] pollQuestions = new PollQuestion[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				pollQuestions[i] = (PollQuestion) tmp[i];
			}
			return pollQuestions;
		}
		return null;
	}

	public static PollQuestion[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple("1=1", CLASS_NAME, transaction);
		if (tmp != null) {
			final PollQuestion[] pollQuestions = new PollQuestion[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				pollQuestions[i] = (PollQuestion) tmp[i];
			}
			return pollQuestions;
		}
		return null;
	}

}
