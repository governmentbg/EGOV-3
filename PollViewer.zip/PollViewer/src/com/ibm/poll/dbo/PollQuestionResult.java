package com.ibm.poll.dbo;

import java.sql.Timestamp;
import java.util.Hashtable;

import com.ibm.poll.db.DBTransaction;
import com.ibm.poll.db.FinderException;
import com.ibm.poll.db.PersistentObject;
import com.ibm.poll.db.QueryComposer;
import com.ibm.poll.db.QuerySet;
import com.ibm.poll.utils.PollUtils;
import com.ibm.pollviewer.PollViewerConstants;

public class PollQuestionResult extends PersistentObject {

	private static String CLASS_NAME = PollQuestionResult.class.getName();
	protected static String schema = PollViewerConstants._SCHEMANAME;
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "POLLQUESTIONRESULT";
        sequenceName = "SEQ_POLLQUESTIONRESULTID";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "POLLQUESTIONRESULTID");
        columnMap.put("pollResultId", "POLLRESULTID");
        columnMap.put("pollId", "POLLID");
        columnMap.put("pollStepId", "POLLSTEPID");
        columnMap.put("pollQuestionId", "POLLQUESTIONID");
        columnMap.put("pollQuestionOptionId", "POLLQUESTIONOPTIONID");
        columnMap.put("pollQuestionLabelId", "POLLQUESTIONLABELID");
        columnMap.put("questionComment", "QUESTIONCOMMENT");
        querySet = QueryComposer.composeAll(schema, table, sequenceName, columnMap);
    }
	
    public PollQuestionResult() {
        super(querySet);
    }
    
    private String pollResultId = null;
    private String pollId = null;
    private String pollStepId = null;
    private String pollQuestionId = null;
    private String pollQuestionOptionId = null;
    private String pollQuestionLabelId = null;
    private String questionComment = null;

	public String getPollResultId() {
		return pollResultId;
	}

	public void setPollResultId(String pollResultId) {
		this.pollResultId = pollResultId;
	}

	public String getPollId() {
		return pollId;
	}

	public void setPollId(String pollId) {
		this.pollId = pollId;
	}
	
	public String getPollStepId() {
		return pollStepId;
	}

	public void setPollStepId(String pollStepId) {
		this.pollStepId = pollStepId;
	}

	public String getPollQuestionId() {
		return pollQuestionId;
	}

	public void setPollQuestionId(String pollQuestionId) {
		this.pollQuestionId = pollQuestionId;
	}

	public String getPollQuestionOptionId() {
		return pollQuestionOptionId;
	}

	public void setPollQuestionOptionId(String pollQuestionOptionId) {
		this.pollQuestionOptionId = pollQuestionOptionId;
	}

	public String getPollQuestionLabelId() {
		return pollQuestionLabelId;
	}

	public void setPollQuestionLabelId(String pollQuestionLabelId) {
		this.pollQuestionLabelId = pollQuestionLabelId;
	}

	public String getQuestionComment() {
		return questionComment;
	}

	public void setQuestionComment(String questionComment) {
		this.questionComment = questionComment;
	}

	public static PollQuestionResult findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
        return (PollQuestionResult) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
    }
		
	public static PollQuestionResult[] findAllQuestionResultsByPollId(final String pollId, final DBTransaction transaction) throws FinderException, Exception {
		return findQuestionResults(columnMap.get("pollId") + "=" + pollId + " ORDER BY " + columnMap.get("id"), transaction);
	}

	public static PollQuestionResult[] findAllQuestionResultsByStepId(final String pollStepId, final DBTransaction transaction) throws FinderException, Exception {
		return findQuestionResults(columnMap.get("pollStepId") + "=" + pollStepId + " ORDER BY " + columnMap.get("pollId"), transaction);
	}

	public static PollQuestionResult[] findQuestionResults(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final PollQuestionResult[] pollQuestionResults = new PollQuestionResult[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				pollQuestionResults[i] = (PollQuestionResult) tmp[i];
			}
			return pollQuestionResults;
		}
		return null;
	}

	public static PollQuestionResult[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple("1=1", CLASS_NAME, transaction);
		if (tmp != null) {
			final PollQuestionResult[] pollQuestionResults = new PollQuestionResult[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				pollQuestionResults[i] = (PollQuestionResult) tmp[i];
			}
			return pollQuestionResults;
		}
		return null;
	}

}
