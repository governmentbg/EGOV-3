package com.ibm.poll.dbo;

import java.util.Hashtable;

import com.ibm.poll.db.DBTransaction;
import com.ibm.poll.db.FinderException;
import com.ibm.poll.db.PersistentObject;
import com.ibm.poll.db.QueryComposer;
import com.ibm.poll.db.QuerySet;
import com.ibm.pollviewer.PollViewerConstants;

public class PollStep extends PersistentObject {

	private static String CLASS_NAME = PollStep.class.getName();
	protected static String schema = PollViewerConstants._SCHEMANAME;
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "POLLSTEP";
        sequenceName = "SEQ_POLLSTEPID";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "POLLSTEPID");
        columnMap.put("pollId", "POLLID");
        columnMap.put("title", "TITLE");
        columnMap.put("description", "DESCRIPTION");
        columnMap.put("sequence", "SEQUENCE");
        columnMap.put("showTitle", "SHOWTITLE");
        querySet = QueryComposer.composeAll(schema, table, sequenceName, columnMap);
    }
	
    public PollStep() {
        super(querySet);
    }
    
    private String title = null;
	private String description = null;
	private String pollId = null;
	private String sequence = null;
	private String showTitle = null;
	private PollQuestion[] pollQuestions = null; // FOR BUSINESS PURPOSE ONLY

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPollId() {
		return pollId;
	}

	public void setPollId(String pollId) {
		this.pollId = pollId;
	}

	public String getSequence() {
		return sequence;
	}

	public void setSequence(String sequence) {
		this.sequence = sequence;
	}
	
	public String getShowTitle() {
		return showTitle;
	}

	public void setShowTitle(String showTitle) {
		this.showTitle = showTitle;
	}
 
	public PollQuestion[] getPollQuestions() {
		return pollQuestions;
	}

	public void setPollQuestions(PollQuestion[] pollQuestions) {
		this.pollQuestions = pollQuestions;
	}

	public static PollStep findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
        return (PollStep) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
    }
	
	public static PollStep findBySequenceAndPollId(final String sequence, final String pollId, final DBTransaction transaction) throws FinderException, Exception {
        return (PollStep) findSingle(columnMap.get("sequence") + "=" + sequence + " AND " +columnMap.get("pollId") + "=" + pollId, CLASS_NAME, transaction);
    }
	
	public static PollStep[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllSteps("1=1", transaction);
	}

	public static PollStep[] findAllStepsByPollId(String pollId, final DBTransaction transaction) throws FinderException, Exception {
		String cond = columnMap.get("pollId") + " = " + pollId + " ORDER BY " + columnMap.get("sequence") + " ASC";
		return findAllSteps(cond, transaction);
	}

	public static PollStep[] findAllStepsByPollIds(String pollIds, final DBTransaction transaction) throws FinderException, Exception {
		String cond = columnMap.get("pollId") + " IN (" + pollIds + ") ORDER BY " + columnMap.get("sequence") + " ASC";
		return findAllSteps(cond, transaction);
	}
	
	public static PollStep[] findAllSteps(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final PollStep[] steps = new PollStep[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				steps[i] = (PollStep) tmp[i];
			} // for
			return steps;
		} // tmp
		return null;
	}

}
