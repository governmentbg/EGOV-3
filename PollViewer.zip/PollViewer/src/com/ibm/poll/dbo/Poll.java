package com.ibm.poll.dbo;

import java.sql.Timestamp;
import java.util.Hashtable;

import com.ibm.poll.db.DBTransaction;
import com.ibm.poll.db.FinderException;
import com.ibm.poll.db.PersistentObject;
import com.ibm.poll.db.QueryComposer;
import com.ibm.poll.db.QuerySet;
import com.ibm.poll.utils.PollUtils;
import com.ibm.pollviewer.PollViewerConstants;

public class Poll extends PersistentObject {

	private static String CLASS_NAME = Poll.class.getName();
	protected static String schema = PollViewerConstants._SCHEMANAME;
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "POLL";
        sequenceName = "SEQ_POLLID";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "POLLID");
        columnMap.put("title", "TITLE");
        columnMap.put("appendix", "APPENDIX");
        columnMap.put("description", "DESCRIPTION");
        columnMap.put("userDN", "USERDN");        
        columnMap.put("startDate", "STARTDATE");
        columnMap.put("endDate", "ENDDATE");
        columnMap.put("status", "STATUS");
        columnMap.put("creationDate", "CREATIONDATE");
        columnMap.put("introMsg", "INTROMSG");
        columnMap.put("completionMessage", "COMPLETIONMESSAGE");
        columnMap.put("showTitle", "SHOWTITLE");
        columnMap.put("showResult", "SHOWRESULT");
        columnMap.put("language", "POLLLANGUAGE");
        columnMap.put("vp", "VP");
        querySet = QueryComposer.composeAll(schema, table, sequenceName, columnMap);
    }
	
    public Poll() {
        super(querySet);
    }
    
    private String title = null;
    private String appendix = null;
	private String description = null;
	private String userDN;	
	private String startDate = null;
	private String endDate = null;
	private String status;
	private String creationDate = null;
	private String introMsg = null;
	private String completionMessage = null;
	private String showTitle = null;
	private String showDescription = null;
	private String showResult = null;
	private String language = null;
	private String vp = null;
	private PollStep[] pollSteps = null; // FOR BUSINESS PURPOSE ONLY
	
	public String getTitle() {
		return title;
	}
	
	public void setTitle(String title) {
		this.title = title;
	}
	
	public String getAppendix() {
		return appendix;
	}
	
	public void setAppendix(String appendix) {
		this.appendix = appendix;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getUserDN() {
		return userDN;
	}
	
	public void setUserDN(String userDN) {
		this.userDN = userDN;
	}
	
	public Timestamp getStartDate() {
		return (startDate != null) ? new Timestamp(Long.parseLong(startDate)) : null;
	}
	
	public void setStartDate(String startDate) {
		this.startDate = (startDate != null) ? String.valueOf(PollUtils.date_TimestampToTimeMillis(startDate)) : null;
	}
	
	public Timestamp getEndDate() {
		return (endDate != null) ? new Timestamp(Long.parseLong(endDate)) : null;
	}
	
	public void setEndDate(String endDate) {
		this.endDate = (endDate != null) ? String.valueOf(PollUtils.date_TimestampToTimeMillis(endDate)) : null;
	}
	
	public String getStatus() {
		return status;
	}
	
	public void setStatus(String status) {
		this.status = status;
	}
	
	public Timestamp getCreationDate() {
		return (creationDate != null) ? new Timestamp(Long.parseLong(creationDate)) : null;
	}
	
	public void setCreationDate(String creationDate) {
		this.creationDate = (creationDate != null) ? String.valueOf(PollUtils.date_TimestampToTimeMillis(creationDate)) : null;
	}
	
	public String getIntroMsg() {
		return introMsg;
	}
	
	public void setIntroMsg(String introMsg) {
		this.introMsg = introMsg;
	}
	
	public String getCompletionMessage() {
		return completionMessage;
	}

	public void setCompletionMessage(String completionMessage) {
		this.completionMessage = completionMessage;
	}

	public String getShowTitle() {
		return showTitle;
	}

	public void setShowTitle(String showTitle) {
		this.showTitle = showTitle;
	}
	
	
	public String getShowResult() {
		return showResult;
	}

	public void setShowResult(String showResult) {
		this.showResult = showResult;
	}
	
	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getVp() {
		return vp;
	}

	public void setVp(String vp) {
		this.vp = vp;
	}

	public PollStep[] getPollSteps() {
		return pollSteps;
	}

	public void setPollSteps(PollStep[] pollSteps) {
		this.pollSteps = pollSteps;
	}

	public static Poll findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
        return (Poll) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
    }

	public static Poll findByIdAndStatus(final String id, final String status, final DBTransaction transaction) throws FinderException, Exception {
		return (Poll) findSingle(columnMap.get("id") + "=" + id + columnMap.get("status") + "='" + status + "'", CLASS_NAME, transaction);
	}

	public static Poll findByIdActivePoll(final String id, final DBTransaction transaction) throws FinderException, Exception {
		String currentTime = PollUtils.timeMillisToTimestamp(System.currentTimeMillis());
		StringBuffer cond = new StringBuffer();
		cond.append(columnMap.get("id") + "=" + id);
		cond.append(" AND " + columnMap.get("status") + "='" + PollViewerConstants.POLL_STATUS_ACTIVE + "'");
		cond.append(" AND " + columnMap.get("startDate") + "<='" + currentTime + "' ");
		cond.append(" AND " + columnMap.get("endDate") + ">'" + currentTime + "' ");
		return (Poll) findSingle(cond.toString(), CLASS_NAME, transaction);
	}
	
	public static Poll[] findAllActivePolls(final DBTransaction transaction, final String language, final String vp) throws FinderException, Exception {
		String currentTime = PollUtils.timeMillisToTimestamp(System.currentTimeMillis());
		StringBuffer cond = new StringBuffer();
		cond.append(columnMap.get("status") + "='" + PollViewerConstants.POLL_STATUS_ACTIVE + "'");
		cond.append(" AND " + columnMap.get("language") + "='" + language + "' ");
		cond.append(" AND " + columnMap.get("startDate") + "<='" + currentTime + "' ");
		cond.append(" AND " + columnMap.get("endDate") + ">'" + currentTime + "' ");
		if (vp != null && vp.trim().length() > 0) {
			cond.append(" AND " + columnMap.get("vp") + "='" + vp + "' ");
		}
		cond.append(" ORDER BY " + columnMap.get("title"));
		return findPolls(cond.toString(), transaction);
	}
	
	public static Poll[] findPolls(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final Poll[] polls = new Poll[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				polls[i] = (Poll) tmp[i];
			}
			return polls;
		}
		return null;
	}
	
	public static Poll[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple("1=1", CLASS_NAME, transaction);
		if (tmp != null) {
			final Poll[] polls = new Poll[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				polls[i] = (Poll) tmp[i];
			}
			return polls;
		} 
		return null;
	}
	
}
