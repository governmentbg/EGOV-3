package com.ibm.poll.bean;

import java.util.ArrayList;
import java.util.HashMap;

public class PollResult {
	HashMap<String, String> results = null;
	HashMap<String, ArrayList<String>> comments = null;

	public HashMap<String, String> getResults() {
		return results;
	}

	public void setResults(HashMap<String, String> results) {
		this.results = results;
	}

	public HashMap<String, ArrayList<String>> getComments() {
		return comments;
	}

	public void setComments(HashMap<String, ArrayList<String>> comments) {
		this.comments = comments;
	}

}
