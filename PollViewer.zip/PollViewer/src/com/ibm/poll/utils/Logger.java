package com.ibm.poll.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.ibm.poll.db.Base;
import com.ibm.pollviewer.PollViewerConstants;

public class Logger extends Base {

    public final static int ERROR_LEVEL = 0;
    public final static int WARNING_LEVEL = 1;
    public final static int DEBUG_LEVEL = 2;

    private final static SimpleDateFormat formatter = new SimpleDateFormat("[yyyy-MM-dd HH:mm:ss] ");

    public synchronized static void log(String logMessage) {
        System.err.println(logMessage);
    }

    public synchronized static void log(int logLevel, String logMessage) {

        String message = PollViewerConstants._PRODUCT_NAME + PollViewerConstants._PRODUCT_VERSION + " | ";

        if (logLevel <= _LOGLEVEL && _LOGON) {
            if (_SHOWTIMESTAMP) {
                message += formatter.format(new Date(System.currentTimeMillis())) + logMessage;
                System.err.println(message);
            } else {
                message += logMessage;
                System.err.println(message);
            }
        }

        if (logLevel == ERROR_LEVEL) {
//        	 mailError(message);
        }
    }
}
