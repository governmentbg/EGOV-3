package com.ibm.customsearch.servlet;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.ContentComponent;
import com.ibm.workplace.wcm.api.DateComponent;
import com.ibm.workplace.wcm.api.Document;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentLibrary;
import com.ibm.workplace.wcm.api.FileComponent;
import com.ibm.workplace.wcm.api.Identity;
import com.ibm.workplace.wcm.api.ImageComponent;
import com.ibm.workplace.wcm.api.LinkComponent;
import com.ibm.workplace.wcm.api.NumericComponent;
import com.ibm.workplace.wcm.api.OptionSelectionComponent;
import com.ibm.workplace.wcm.api.OptionType;
import com.ibm.workplace.wcm.api.Repository;
import com.ibm.workplace.wcm.api.RichTextComponent;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.SiteArea;
import com.ibm.workplace.wcm.api.TextComponent;
import com.ibm.workplace.wcm.api.VirtualPortalScopedAction;
import com.ibm.workplace.wcm.api.WCM_API;
import com.ibm.workplace.wcm.api.Workspace;
import com.ibm.workplace.wcm.api.exceptions.AuthorizationException;
import com.ibm.workplace.wcm.api.exceptions.ComponentNotFoundException;
import com.ibm.workplace.wcm.api.exceptions.DocumentIdCreationException;
import com.ibm.workplace.wcm.api.exceptions.DocumentRetrievalException;
import com.ibm.workplace.wcm.api.exceptions.OperationFailedException;
import com.ibm.workplace.wcm.api.exceptions.QueryServiceException;
import com.ibm.workplace.wcm.api.exceptions.WCMException;
import com.ibm.workplace.wcm.api.query.Conjunction;
import com.ibm.workplace.wcm.api.query.Disjunction;
import com.ibm.workplace.wcm.api.query.ProfileSelectors;
import com.ibm.workplace.wcm.api.query.Query;
import com.ibm.workplace.wcm.api.query.QueryDepth;
import com.ibm.workplace.wcm.api.query.ResultIterator;
import com.ibm.workplace.wcm.api.query.Selectors;
import com.ibm.workplace.wcm.api.query.SortDirection;
import com.ibm.workplace.wcm.api.query.Sorts;
import com.ibm.workplace.wcm.api.query.WorkflowSelectors;

public class VPScopedContentSearch implements VirtualPortalScopedAction {
	
	private ArrayList<Content> contents = null;
	@SuppressWarnings("rawtypes")
	private HashMap<DocumentId, String> parentSiteAreas = null;
	@SuppressWarnings("rawtypes")
	private HashMap<DocumentId, String> parentSiteAreaNames = null;
	@SuppressWarnings("rawtypes")
	private HashMap<DocumentId, String> paths = null;
	@SuppressWarnings("rawtypes")
	private HashMap <DocumentId, HashMap> allElements = null;
	private int total = 0;
	private HashMap <String, String> element = null;
	private ArrayList<Object> returnedValues = null;
	private String libraryName = null;
	private String contentRoot = "site";
	private String[] siteAreaIds = null;	
	private String authoringTemplateIds;
	private String[] categories;
	private String[] keywords;
	private String orderBy = Workspace.SORT_KEY_TITLE;
	private String orderBy2 = Workspace.SORT_KEY_TITLE;
	private String orderBy3 = Workspace.SORT_KEY_TITLE;
	private boolean sortOrder = true;
	private boolean includeAncestors = false;
	private boolean includeDescendants = false;
	private boolean matchAllCategories = false;
	private boolean includeDescendentCategories = false;
	private int draftStatus = Workspace.WORKFLOWSTATUS_PUBLISHED;
	private boolean isDebug = false;
	private String returnElements = "";
	private SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.ENGLISH);
	private String dateStringFrom = "";
	private String dateStringTo = "";
	private boolean useQuery = false;
//	private JSONObject parsedJson = null;
	private static Repository repository = null;
	public static Workspace workspace = null;	
	
	public ArrayList<Object> getReturnedValue() {
		returnedValues = new ArrayList<Object>();
		returnedValues.add(contents);
		returnedValues.add(parentSiteAreas);
		returnedValues.add(parentSiteAreaNames);
		returnedValues.add(paths);
		returnedValues.add(allElements);
		returnedValues.add(total);
		return returnedValues;
	}	

	// public constructor
	public VPScopedContentSearch(String libraryName, String contentRoot, String[] siteAreaIds, String authoringTemplateIds, String[] categories, 
			String[] keywords, boolean matchAllCategories, boolean includeDescendentCategories, boolean includeAncestors, boolean includeDescendants, 
			String orderBy, String orderBy2, String orderBy3, boolean sortOrder, int draftStatus, boolean isDebug, String elements, 
			SimpleDateFormat dateFormat, String dateStringFrom, String dateStringTo, boolean useQuery) {
		this.libraryName = libraryName;
		this.contentRoot = contentRoot;
		this.siteAreaIds = siteAreaIds;
		this.authoringTemplateIds = authoringTemplateIds;
		this.categories = categories;
		this.matchAllCategories = matchAllCategories;
		this.includeDescendentCategories = includeDescendentCategories;
		this.keywords = keywords;
		this.orderBy = orderBy;
		this.orderBy2 = orderBy2;
		this.orderBy3 = orderBy3;
		this.sortOrder = sortOrder;
		this.includeAncestors = includeAncestors;
		this.includeDescendants = includeDescendants;
		this.draftStatus = draftStatus;
		this.isDebug = isDebug;
		this.returnElements = elements;
		this.dateFormat = dateFormat;
		this.dateStringFrom = dateStringFrom;
		this.dateStringTo = dateStringTo;
		this.useQuery = useQuery;
//		this.parsedJson = parsedJson;
	}

	// overwritten method
	@SuppressWarnings({ "rawtypes" })
	@Override
	public void run() throws WCMException {

		repository = WCM_API.getRepository();
		workspace = repository.getSystemWorkspace();
		workspace.login();
		DocumentLibrary docLib = workspace.getDocumentLibrary(this.libraryName);
		workspace.setCurrentDocumentLibrary(docLib);
		DocumentId doc = null;
		Content content = null;
		String label = null;
		String parentName = null;
		String parentSAName = null;
		DocumentId parentDoc = null;
		DocumentId tempDoc = null;
		DocumentId[] authTempIds = null;
		String path = "";
		if (this.isDebug) { System.out.println("inside VPSCOPED ACTION");	}

		DocumentIdIterator<Content> docIterator = null;
		this.contents = new ArrayList<Content>();	
		DocumentId [] siteAreaDocIdArray = null;
		DocumentId [] categoryIdsArray = null;
		
		
		try {
			//fill category		
			if (this.categories != null && this.categories.length > 0) {
				if (this.isDebug) { System.out.println("has categories [" + this.categories.length + "]"); }
				categoryIdsArray =  new DocumentId[categories.length];
				DocumentId categoryId = null;
				for (int i = 0; i < categories.length; i++) {
					//fill each saID into new doc id, then add to array
					if (this.isDebug) { System.out.println("category id : " + categories[i]); }
					try {
						categoryId = workspace.createDocumentId(categories[i]);
						if (this.isDebug) { System.out.println("category name: " + categoryId.getName()); }
						categoryIdsArray[i] = categoryId;
					} catch (Exception e) {						
						System.out.println("ERR_MESSAGE: " + e.getMessage());
						e. printStackTrace();
					}
					
				}
			}
			if (this.authoringTemplateIds != null && this.authoringTemplateIds.trim().length() > 0) {	
				if (isDebug) {
					System.out.println("has atID(s) = " + this.authoringTemplateIds);
				}
				String[] tempATIds = authoringTemplateIds.split(","); 
				authTempIds = new DocumentId[tempATIds.length];
				for (int i = 0; i < tempATIds.length; i++) {
					authTempIds[i] = workspace.createDocumentId(tempATIds[i]);									
				}								
			}			
			//fill SA
			if (this.siteAreaIds != null && this.siteAreaIds.length > 0) {		
				if (this.isDebug) { System.out.println("has siteAreaIds [" + this.siteAreaIds.length + "]"); }
				DocumentId docId = null;
				siteAreaDocIdArray = new DocumentId[siteAreaIds.length];
				for ( int i = 0; i < siteAreaIds.length; i++) {
					//fill each saID into new doc id, then add to array
					if (this.isDebug) { System.out.println("sitearea id : " + siteAreaIds[i]); }
					try {
						docId = workspace.createDocumentId(siteAreaIds[i]);
						if (this.isDebug) { System.out.println("sitearea name " + docId.getName()); }
						siteAreaDocIdArray[i] = docId;
					} catch (Exception e) {						
						System.out.println("ERR_MESSAGE: " + e.getMessage());
						e. printStackTrace();
					}
				}
			}
			if (this.isDebug) { 
				if (authTempIds != null) {
					for (int i = 0; i < authTempIds.length; i++) {
						System.out.println("AuthTempId = " + authTempIds[i].getName());
					}
				} else {
					System.out.println("AuthTempId = NULL");
				}
				System.out.println("draftStatus = " + this.draftStatus);
			}
			
			//System.out.println("Workspace.WORKFLOWSTATUS_PUBLISHED " + Workspace.WORKFLOWSTATUS_PUBLISHED);
			parentSiteAreas = new HashMap<>();
			parentSiteAreaNames = new HashMap<>();
			paths = new HashMap<>();
			allElements = new HashMap<>();			
			
			//use new query search, which is much faster
			if (this.useQuery) {
				if(this.isDebug) System.out.println("QUERY SEARCH!");
				Query query = workspace.getQueryService().createQuery();
				//if (this.isDebug) { System.out.println("siteAreaIds length:" + siteAreaIds.length);}
				ResultIterator rIter = createQueryAndReturnResult (query, docLib, authTempIds, siteAreaIds, categoryIdsArray, this.orderBy, this.sortOrder);
				getPropertiesFromQueryResults(rIter, doc,parentDoc,parentName,parentSAName,tempDoc,label,path);
			} else {
				DocumentId authTempId = null;
				if (authTempIds != null && authTempIds.length > 0) {
					authTempId = authTempIds[0];
				}
				docIterator = workspace.contentSearch(
						authTempId, 
						//siteAreaDocId != null ? new DocumentId[] { siteAreaDocId } : null, //need array of doc ids
						siteAreaDocIdArray,
						categoryIdsArray,
						this.keywords,
						this.matchAllCategories, 
						false,
						this.includeDescendentCategories,
						this.includeAncestors, 
						this.includeDescendants, this.orderBy, this.orderBy2, this.orderBy3, this.sortOrder, this.draftStatus);
				//prepare return values in vp context, as those are not accessible to outside scope
				getPropertiesFromMenuResults(docIterator, content, doc, parentDoc, parentName, parentSAName, tempDoc, label, path);
			}
			
			
		} catch (Exception e) {	
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		//}
		workspace.logout();
		repository.endWorkspace();
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private String getContentElement(Content content, String componentName, SimpleDateFormat dateFormat) throws ComponentNotFoundException, DocumentRetrievalException, AuthorizationException {
		//if (isDebug) { System.out.println("entering getcontent element " + componentName); }
		ContentComponent contentComponent = null;
		if (content.hasComponent(componentName)) {
			contentComponent = content.getComponentByReference(componentName);
			if (contentComponent instanceof RichTextComponent) {
				//System.out.println("richtextcomponent");				
				return ((RichTextComponent)contentComponent).getRichText().toString();
			} else if (contentComponent instanceof ShortTextComponent) {
				return ((ShortTextComponent)contentComponent).getText();				
			} else if (contentComponent instanceof TextComponent) {
				return ((TextComponent)contentComponent).getText();
			} else if (contentComponent instanceof NumericComponent) {
				return ((NumericComponent)contentComponent).getNumber().toString();
			} else if (contentComponent instanceof ImageComponent) {
				return ((ImageComponent)contentComponent).getResourceURL();
			} else if (contentComponent instanceof LinkComponent) {		
				return ((LinkComponent)contentComponent).getURL() + "&linktext&" + ((LinkComponent)contentComponent).getLinkText();				
			} else if (contentComponent instanceof FileComponent) {
				if (isDebug) {System.out.println("FileComponent");}
				FileComponent component = (FileComponent) contentComponent;
				if (component.getResourceURL() != null) {
					return component.getResourceURL();
				} else {
					return "";
				}							
			}		
			else if (contentComponent instanceof DateComponent) {
				//if(isDebug) { System.out.println("datecomponent"); }
				DateComponent component = (DateComponent) contentComponent;
				if (component.getDate() != null) {				
					return component.getDate().getTime() + "";
				}else {
					if (this.isDebug) {System.out.println("dateComponent empty");}
					return "";
				}
			}//need to filter contents by optionselection here, can't access them outside vp scope 
			else if (contentComponent instanceof OptionSelectionComponent) {
				//if (isDebug) { System.out.println("optionselectioncomponent"); }										
				OptionSelectionComponent component = (OptionSelectionComponent)contentComponent;
				DocumentId [] selections = null;
				String [] stringSelections = null;				
				try {
					if (component.getOptionType() == OptionType.USE_TAXONOMY) {
						if (isDebug) { System.out.println("OPTION TYPE USE TAXONOMY");}
						selections = component.getCategorySelections();
					} else if (component.getOptionType() == OptionType.USER_DEFINED) {
						if (isDebug) { System.out.println("OPTION TYPE USER DEFINED");}
						stringSelections = component.getSelections();
						if (isDebug) { 
							if (stringSelections == null) {
								System.out.println("stringSelections are null " + stringSelections);
							}
						}
					}
				} catch (OperationFailedException e) { //if the option type is OptionType.USER_DEFINED ??? We usually define it this way
					System.out.println("OperationFailedException:" + e.getMessage());
					e.printStackTrace();							
				}	
				
				if (selections != null) {
					if (this.isDebug) { System.out.println("SELECTION LEN: " + selections.length); }
					String result = "";				
//					DocumentId selected = null;
					Document doc = null;
					//Category cat = null;
					for (int i = 0; i < selections.length; i++) {
						System.out.println(" option 0: " + selections[0]);
//						selected = selections[i];				
						doc = workspace.getById(selections[i]);
						if (selections.length > 1) {
							result = doc.getTitle() + ",";					
						} else {
							result = doc.getTitle();					
						}
						if (this.isDebug) { System.out.println("selections " + result); }			
					}
					return result;	
					
				} if (stringSelections != null) {
					if (this.isDebug) { System.out.println("STRING SELECTION LEN: " + stringSelections.length + " option 0: " + stringSelections[0]); }
					String result = "";	
					String selected = "";
					for (int i = 0; i < stringSelections.length; i++) {
						selected = stringSelections[i];				
						if (stringSelections.length > 1) {
							result = selected + ",";					
						} else {
							result = selected;					
						}
						if (this.isDebug) { System.out.println("stringSelections " + result); }			
					}
					return result;
				}
			}
		} else {
			if (this.isDebug) { System.out.println("No such component (vpscoped) " + componentName); }
		}
		
		 			
		return "";	
	}
	
	 public static Date addDays(Date date, int days, boolean isDebug) {
		if (isDebug) { System.out.println("add days " + date.toString() + " offset: " + days);}
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DATE, days); //minus number would decrement the days
        if (isDebug) { System.out.println("add days cal " + cal.getTime());}
        return cal.getTime();
    }
	 
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private ResultIterator createQueryAndReturnResult (Query query, DocumentLibrary docLib, DocumentId[] authTempIds, String [] siteAreaIds, DocumentId[] categoryIds,
			String sortByPublishDate, boolean ascending) throws QueryServiceException, DocumentIdCreationException {
		
		Conjunction and = new Conjunction();
		and.add(Selectors.libraryEquals(docLib));
		and.add(Selectors.typeIn(Content.class));
		
		if (dateStringFrom != null && dateStringFrom.trim().length() > 0) {
			if (isDebug) System.out.println("filter by date from");
			Date dateFrom = null;
			try {
				dateFrom = dateFormat.parse(dateStringFrom);
				if (isDebug) { System.out.println("date from after parse: " + dateFrom);}
				//fix includeboundary not working, subtract one day manually
				dateFrom = addDays(dateFrom, -1, isDebug);
				if (isDebug) System.out.println("query updated date:" + dateFrom.toString());
			} catch (ParseException e) {
				e.printStackTrace();
			}
			if (dateFrom != null) {
				//includeboundary, the 2nd parameter is NOT working. It is always false anyway
				and.add(WorkflowSelectors.publishAfter(dateFrom, false));
			}
		}
		//filter date to
		if (dateStringTo != null && dateStringTo.trim().length() > 0) { 
			if (isDebug) System.out.println("filter by date to");
			Date dateTo = null;
			try {
				dateTo = dateFormat.parse(dateStringTo);
				if (isDebug) { System.out.println("date to after parse: " + dateTo);}
				// Add one day manually (fix includeboundary not working)
				dateTo = addDays(dateTo, 1, isDebug);
				if (isDebug) System.out.println("query updated date:" + dateTo.toString());
			} catch (ParseException e) {
				e.printStackTrace();
			}
			if (dateTo != null) {
				//includeboundary, the 2nd parameter is NOT working. It is always false anyway
				and.add(WorkflowSelectors.publishBefore(dateTo, false));
			}
		}
		//sort
		if ("publishDate".equalsIgnoreCase(sortByPublishDate)) {
			SortDirection sortDirection = ascending ? SortDirection.ASCENDING: SortDirection.DESCENDING;
			Sorts.byPublishDate(sortDirection);
			query.addSort(Sorts.byPublishDate(sortDirection));
		}
			
		
		//filter AT
		if (authTempIds != null && authTempIds.length > 0) {
			if (isDebug) {
				for (int i = 0; i < authTempIds.length; i++) {
					System.out.println("filter by AT: " + authTempIds[i].getId());
				}
			}			
			and.add(Selectors.authoringTemplateIn(authTempIds));
			//query.addSelector(Selectors.authoringTemplateEquals(authTempId));
		}
		//filter SA
		if (siteAreaIds != null && siteAreaIds.length > 0) {
			if (isDebug) System.out.println("has siteArea:");
			DocumentId siteAreaDocId = null;
			for (int i = 0; i < siteAreaIds.length; i++) {
				if (isDebug) System.out.println("siteAreaIds[i]:" + siteAreaIds[i]);
				siteAreaDocId = workspace.createDocumentId(siteAreaIds[i]);
				query.addParentId(siteAreaDocId, QueryDepth.CHILDREN);
			}
			
		}	
		//filter by categories.
		if (categoryIds != null && categoryIds.length > 0) {
			if (this.matchAllCategories) {
				List<Identity> categoriesList = new ArrayList<Identity>(Arrays.asList(categoryIds));
				and.add(ProfileSelectors.categoriesContains(categoriesList));
			} else {
				Disjunction or = new Disjunction();
				for (int i = 0; i < categoryIds.length; i++) {
					or.add(ProfileSelectors.categoriesContains(categoryIds[i]));	
				}
				and.add(or);
			}
		}
		query.addSelector(and);
		//generate result
		query.returnObjects();
		ResultIterator resultIterator = workspace.getQueryService().execute(query);
		return resultIterator;
	}
	
	@SuppressWarnings({"rawtypes", "unchecked"})
	private void getPropertiesFromMenuResults(DocumentIdIterator docIterator, Content content, DocumentId doc, DocumentId parentDoc,
			String parentName, String parentSAName,DocumentId tempDoc,String label,String path) throws DocumentRetrievalException, AuthorizationException {
		while (docIterator.hasNext()) {				
			doc = docIterator.next(); // returns <T extends Document >
			content = (Content) workspace.getById(doc, true);
			if (returnElements != null) {
				String contentElement = "";
				String [] returnElementsArray = returnElements.split(",");
				element = new HashMap<>();
				for (int i = 0; i < returnElementsArray.length; i++) {						
					try {
						//if (isDebug) { System.out.println("returnElements: " + returnElementsArray[i]); }
						contentElement = getContentElement(content, returnElementsArray[i], this.dateFormat);
						//if (isDebug) { System.out.println("contentElement: " + contentElement);}
					} catch (DocumentRetrievalException e) {
						System.out.println("DocumentRetrievalException:" + e.getMessage());
					} catch (ComponentNotFoundException e) {
						System.out.println("ComponentNotFoundException:" + e.getMessage());
					}
					//insert single element
					element.put(returnElementsArray[i], contentElement);
					contentElement = "";
				}
				if (isDebug) { System.out.println("VP id key: " + content.getId()); }
				//insert all elements in single result
				allElements.put(content.getId(), element);				
			}
			
			// FORCE Portal to load Workflow data (this includes the publish date if content has workflow)
			if (content.isWorkflowed()) {
				try {if (content.isPublished()) {content.getPublishedDate();}} catch (Exception e) {}
			}
			// FORCE Portal to load creation date
			try {content.getCreationDate();} catch (Exception e) {}
			
			if (this.isDebug) { System.out.println("pDate vp: " + content.getCreationDate().toString()); }			
			contents.add(content);	
			parentDoc = content.getParentId();
			label = ((SiteArea) workspace.getById(parentDoc, true)).getTitle();
			parentSiteAreas.put(content.getId(), label);	
							
			parentName = ((SiteArea) workspace.getById(parentDoc, true)).getName();
			parentSiteAreaNames.put(content.getId(), parentName);	
			tempDoc = content.getParentId();
			SiteArea tempSA = (SiteArea) workspace.getById(tempDoc, true);
			
			//IMPORTANT ! prerequisite -> customsearch returns name of sitearea as contentroot, the portal
			// rootpage has to be the exact same name
			while (!tempSA.getName().equals(this.contentRoot)) { //usually "site"
				path = parentName + "/" + path;
				tempDoc = tempSA.getParentId();
				
				if (this.isDebug) { 
					//System.out.println("path " + path + ", tempDoc: " + tempDoc);
					//System.out.println("tempSA: " + tempSA.getName());
				}
				tempSA = (SiteArea) workspace.getById(tempDoc, true);
				parentName = ((SiteArea) workspace.getById(tempDoc, true)).getName();
				if (parentName.equals(this.contentRoot)) {
					break;
				}					
			}
			paths.put(content.getId(), path);
			path = "";				
		}
	}

	
	@SuppressWarnings({"rawtypes", "unchecked"})
	private void getPropertiesFromQueryResults(ResultIterator docIterator, DocumentId doc, DocumentId parentDoc,
			String parentName, String parentSAName,DocumentId tempDoc,String label,String path)
					throws DocumentRetrievalException, AuthorizationException {
		Content content = null;
		while (docIterator.hasNext()) {				
			content = (Content)docIterator.next(); // returns <T extends Document >
			
			if (returnElements != null) {
				String contentElement = "";
				String [] returnElementsArray = returnElements.split(",");
				element = new HashMap<>();
				for (int i = 0; i < returnElementsArray.length; i++) {						
					try {
						//if (isDebug) { System.out.println("returnElements: " + returnElementsArray[i]); }
						contentElement = getContentElement(content, returnElementsArray[i], this.dateFormat);						
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					//insert single element
					element.put(returnElementsArray[i], contentElement);
					contentElement = "";
				}
				//if (isDebug) { System.out.println("VP id key: " + content.getId()); }
				//insert all elements in single result
				allElements.put(content.getId(), element);				
			}
			
			// FORCE Portal to load Workflow data (this includes the publish date if content has workflow)
			if (content.isWorkflowed()) {
				try {if (content.isPublished()) {content.getPublishedDate();}} catch (Exception e) {}
			}				
			// FORCE Portal to load creation date
			try {content.getCreationDate();} catch (Exception e) {}
			
			if (this.isDebug) { System.out.println("pDate vp: " + content.getCreationDate().toString()); }			
			contents.add(content);	
			parentDoc = content.getParentId();
			label = ((SiteArea) workspace.getById(parentDoc, true)).getTitle();
			parentSiteAreas.put(content.getId(), label);	
							
			parentName = ((SiteArea) workspace.getById(parentDoc, true)).getName();
			parentSiteAreaNames.put(content.getId(), parentName);	
			tempDoc = content.getParentId();
			SiteArea tempSA = (SiteArea) workspace.getById(tempDoc, true);
			
			//IMPORTANT ! prerequisite -> customsearch returns name of sitearea as contentroot, the portal
			// rootpage has to be the exact same name
			while (!tempSA.getName().equals(this.contentRoot)) { //usually "site"
				path = parentName + "/" + path;
				tempDoc = tempSA.getParentId();
				
				if (this.isDebug) { 
					System.out.println("path " + path + ", tempDoc: " + tempDoc);
					System.out.println("tempSA: " + tempSA.getName());
				}
				tempSA = (SiteArea) workspace.getById(tempDoc, true);
				parentName = ((SiteArea) workspace.getById(tempDoc, true)).getName();
				if (parentName.equals(this.contentRoot)) {
					break;
				}					
			}
			paths.put(content.getId(), path);
			path = "";				
		}
	}
	
}
		
