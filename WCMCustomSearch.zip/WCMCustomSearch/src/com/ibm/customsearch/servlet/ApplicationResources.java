package com.ibm.customsearch.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class ApplicationResources {

	private static final String PROPERTIES_FILE_NAME = "Resources.wcmcustomsearch.properties";
	private static Properties defaultProps = null;
	private static String _PRODUCTION_PROPERTY = "";
	// private static boolean _PRODUCTION_FLAG = false;
	private static String _CONTEXTVP_PROPERTY = "";
	// private static boolean _CONTEXT_VP_FLAG = false;
	private static boolean isDebug = true;

	public ApplicationResources() {
	}

	private static void getProperties(String fileName) {
		defaultProps = new Properties();
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(fileName);
			defaultProps.load(fis);

		} catch (Exception e) {
			System.out.print("ApplicationProperties: Error loading properties file " + fileName + " !");
			e.printStackTrace();
		}
	}

	public static boolean loadProps(String realpath) {
		boolean result = false;
		File file = null;
		String configPath = realpath + File.separator + "WEB-INF" + File.separator + "config" + File.separator + PROPERTIES_FILE_NAME;
		if (isDebug) {
			System.err.println("Configuration path is " + configPath);
		}
		file = new File(configPath);
		if (file.exists()) {
			if (isDebug) {
				System.out.print("Loading Properties from file : " + file.getAbsolutePath() + "... ");
			}
			getProperties(configPath);
			System.out.print("OK");
			if (defaultProps != null) {
				_PRODUCTION_PROPERTY = ((defaultProps.getProperty("PRODUCTION") != null) ? defaultProps.getProperty("PRODUCTION").trim() : null);
				_CONTEXTVP_PROPERTY = ((defaultProps.getProperty("CONTEXTVP") != null) ? defaultProps.getProperty("CONTEXTVP").trim() : null);

			}
			result = true;
		}
		return result;
	}

	public static String get_PRODUCTION_PROPERTY() {
		return _PRODUCTION_PROPERTY;
	}

	public static String get_CONTEXTVP_PROPERTY() {
		return _CONTEXTVP_PROPERTY;
	}

}
