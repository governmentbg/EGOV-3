package com.ibm.customsearch.servlet;

import java.io.File;
import java.io.FileOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import javax.activation.MimetypesFileTypeMap;

import com.ibm.workplace.wcm.api.AuthoringTemplate;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.ContentComponent;
import com.ibm.workplace.wcm.api.DateComponent;
import com.ibm.workplace.wcm.api.Document;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentLibrary;
import com.ibm.workplace.wcm.api.FileComponent;
import com.ibm.workplace.wcm.api.HTMLComponent;
import com.ibm.workplace.wcm.api.Identity;
import com.ibm.workplace.wcm.api.ImageComponent;
import com.ibm.workplace.wcm.api.Library;
import com.ibm.workplace.wcm.api.LibraryComponent;
import com.ibm.workplace.wcm.api.LibraryHTMLComponent;
import com.ibm.workplace.wcm.api.LibraryMenuComponent;
import com.ibm.workplace.wcm.api.LinkComponent;
import com.ibm.workplace.wcm.api.NumericComponent;
import com.ibm.workplace.wcm.api.OptionSelectionComponent;
import com.ibm.workplace.wcm.api.OptionType;
import com.ibm.workplace.wcm.api.PresentationTemplate;
import com.ibm.workplace.wcm.api.Repository;
import com.ibm.workplace.wcm.api.RichTextComponent;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.SiteArea;
import com.ibm.workplace.wcm.api.TextComponent;
import com.ibm.workplace.wcm.api.VirtualPortalScopedAction;
import com.ibm.workplace.wcm.api.WCM_API;
import com.ibm.workplace.wcm.api.Workspace;
import com.ibm.workplace.wcm.api.exceptions.AuthorizationException;
import com.ibm.workplace.wcm.api.exceptions.ComponentNotFoundException;
import com.ibm.workplace.wcm.api.exceptions.DocumentIdCreationException;
import com.ibm.workplace.wcm.api.exceptions.DocumentRetrievalException;
import com.ibm.workplace.wcm.api.exceptions.OperationFailedException;
import com.ibm.workplace.wcm.api.exceptions.PropertyRetrievalException;
import com.ibm.workplace.wcm.api.exceptions.QueryServiceException;
import com.ibm.workplace.wcm.api.exceptions.WCMException;
import com.ibm.workplace.wcm.api.query.Association;
import com.ibm.workplace.wcm.api.query.Conjunction;
import com.ibm.workplace.wcm.api.query.Disjunction;
import com.ibm.workplace.wcm.api.query.Operator;
import com.ibm.workplace.wcm.api.query.PageIterator;
import com.ibm.workplace.wcm.api.query.ProfileSelectors;
import com.ibm.workplace.wcm.api.query.Query;
import com.ibm.workplace.wcm.api.query.QueryDepth;
import com.ibm.workplace.wcm.api.query.QueryStructureException;
import com.ibm.workplace.wcm.api.query.ResultIterator;
import com.ibm.workplace.wcm.api.query.Selectors;
import com.ibm.workplace.wcm.api.query.SortDirection;
import com.ibm.workplace.wcm.api.query.Sorts;
import com.ibm.workplace.wcm.api.query.WorkflowSelectors;

public class VPScopedPaginationQuerySearch implements VirtualPortalScopedAction {

	private ArrayList<Content> contents = null;
	@SuppressWarnings("rawtypes")
	private HashMap<DocumentId, String> parentSiteAreas = null;
	@SuppressWarnings("rawtypes")
	private HashMap<DocumentId, String> parentSiteAreaNames = null;
	@SuppressWarnings("rawtypes")
	private HashMap<DocumentId, String> paths = null;
	@SuppressWarnings("rawtypes")
	private HashMap<DocumentId, HashMap> allElements = null;
	//each content -> catData/fileData -> list elements -> map elementName -> map -> id-id, title-title etc
	@SuppressWarnings("rawtypes")
	private HashMap<DocumentId, HashMap <String, HashMap<String, HashMap<String, String>>>> optionElementMetaMap = null;
	private HashMap<DocumentId, HashMap <String, HashMap<String, String>>> fileElementMetaMap = null;
	private HashMap <String, HashMap<String, HashMap<String, String>>> tempOptionSelectionMap = null;
	private HashMap <String, HashMap<String, String>> tempCategorySelectionMap = null;
	private HashMap <String, HashMap<String, String>> tempFileElementMap = null;
	private HashMap<DocumentId, ArrayList<String>> categoryIdsForContent = null;
	
	private int total = 0;
	private HashMap<String, String> element = null;
	private ArrayList<Object> returnedValues = null;
	private String libraryName = null;
	private String contentRoot = "site";
	private String[] siteAreaIds = null;
	private String authoringTemplateId;
	private HashMap <String, Object> propertiesFilterMap;
	private String[] categories;
	private String orderBy = Workspace.SORT_KEY_TITLE;
	private boolean sortOrder = true;
	private int draftStatus = Workspace.WORKFLOWSTATUS_PUBLISHED;
	private boolean isDebug = false;
	private String methodDebugged = "";
	private String returnElements = "";
	private SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.ENGLISH);
	private String dateStringFrom = "";
	private String dateStringTo = "";
	private int resultsPerPage = 10;
	private int currentPage = 1;
	private String searchTerm = null;
	private String id = null;
	private String name = null;
	private String [] categoryIdsArray = null;
	private String [] keywordsArray = null;
	private String creator = null;
	private static Repository repository = null;
	public static Workspace workspace = null;
	private Util util = new Util();

	public ArrayList<Object> getReturnedValue() {
		returnedValues = new ArrayList<Object>();
		returnedValues.add(contents);
		returnedValues.add(parentSiteAreas);
		returnedValues.add(parentSiteAreaNames);
		returnedValues.add(paths);
		returnedValues.add(allElements);
		returnedValues.add(total);
		returnedValues.add(optionElementMetaMap);
		returnedValues.add(fileElementMetaMap);
		returnedValues.add(categoryIdsForContent);
		return returnedValues;
	}

	// public constructor
	public VPScopedPaginationQuerySearch(String libraryName, HashMap<String, Object> propertiesFilterMap, 
			String contentRoot, boolean isDebug, String methodDebugged, String elements,
			SimpleDateFormat dateFormat,  int resultsPerPage, int currentPage) {
		this.libraryName = libraryName;
		this.contentRoot = contentRoot;
		this.propertiesFilterMap = propertiesFilterMap;
		this.isDebug = isDebug;
		this.methodDebugged = methodDebugged;
		this.returnElements = elements;
		this.dateFormat = dateFormat;
		this.resultsPerPage = resultsPerPage;
		this.currentPage = currentPage;
	}

	@SuppressWarnings({ "rawtypes" })
	@Override
	public void run() throws WCMException {

		repository = WCM_API.getRepository();
		workspace = repository.getSystemWorkspace();
		workspace.login();
		DocumentLibrary docLib = workspace.getDocumentLibrary(libraryName);
		workspace.setCurrentDocumentLibrary(docLib);
		util.setDebug(isDebug);
		util.setMethodDebugged(methodDebugged);
		util.logger("inside VPSCOPED QUERY ACTION");

		contents = new ArrayList<Content>();
		DocumentId[] atIdDocArray = null;
		DocumentId[] categoryIdsArray = null;
		
		try {
			// System.out.println("Workspace.WORKFLOWSTATUS_PUBLISHED " + Workspace.WORKFLOWSTATUS_PUBLISHED);
			parentSiteAreas = new HashMap<>();
			parentSiteAreaNames = new HashMap<>();
			paths = new HashMap<>();
			allElements = new HashMap<>();
			optionElementMetaMap = new HashMap<>();
			fileElementMetaMap = new HashMap<>();
			categoryIdsForContent = new HashMap<DocumentId, ArrayList<String>>();
			//build queries for other types of components - at, pt, component etc
			String type = (String)propertiesFilterMap.get("type"); 
			if (type != null && type.length() > 0) {
				ResultIterator resultIter = null;
				//general comp -> when we can't know if what we search is is menu, html comp, authoring tool etc
				if (type.equals("COMP")) {
					Query query = workspace.getQueryService().createQuery(LibraryComponent.class);
					resultIter = getUtilResults(query, docLib, propertiesFilterMap, type);
				} else if (type.equals("MENU")) { 
					Query query = workspace.getQueryService().createQuery(LibraryMenuComponent.class);
					resultIter = getUtilResults(query, docLib, propertiesFilterMap, type);
				} else if (type.equals("HTML")) { 
					Query query = workspace.getQueryService().createQuery(LibraryHTMLComponent.class);
					resultIter = getUtilResults(query, docLib, propertiesFilterMap, type);
				} else if (type.equals("AT")) { 
					Query query = workspace.getQueryService().createQuery(AuthoringTemplate.class);
					resultIter = getUtilResults(query, docLib, propertiesFilterMap, type);
				} else if (type.equals("PT")) { 
					Query query = workspace.getQueryService().createQuery(PresentationTemplate.class);
					resultIter = getUtilResults(query, docLib, propertiesFilterMap, type);
				} 
				
				processUtilResults(resultIter, type, propertiesFilterMap);
			} else {
				// use new query search, which is much faster
				Query query = workspace.getQueryService().createQuery();
				PageIterator pIter = getResults(query, docLib, propertiesFilterMap);
				processQueryResults(pIter);
			}
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		workspace.logout();
		repository.endWorkspace();
	}
	
	//when processing the result we can actually search using searchTerm in html 
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void processUtilResults(ResultIterator resultIterator, String type, HashMap <String, Object> propertiesFilterMap)
			throws DocumentRetrievalException, AuthorizationException, QueryStructureException {
		ResultIterator docIterator = null;
		searchTerm = (String)propertiesFilterMap.get("searchTerm");
		
		if (type.equals("AT")) {
			while (resultIterator.hasNext()) { 
				AuthoringTemplate at = (AuthoringTemplate) resultIterator.next();
				util.logger("AT name", at.getName());
				util.logger("AT title", at.getTitle());
			}
		} else if (type.equals("PT")) {
			while (resultIterator.hasNext()) { 
				PresentationTemplate pt = (PresentationTemplate) resultIterator.next();
				util.logger("PT name", pt.getName());
				String searchTerm = (String)propertiesFilterMap.get("searchTerm");
				//util.logger("html", pt.getHTML());
				if (pt != null && pt.getHTML() != null && searchTerm != null && searchTerm.length() > 0) { 
					if (pt.getHTML().indexOf(searchTerm) != -1) {
						util.logger("has " + searchTerm + " in PT " + pt.getName());
					} 
				}
			}
		} else if (type.equals("HTML")) {
			while (resultIterator.hasNext()) { 
				LibraryHTMLComponent htmlComponent = (LibraryHTMLComponent) resultIterator.next();
				util.logger("HTML name", htmlComponent.getName());
				//util.logger("html", htmlComponent.getHTML());
				if (htmlComponent != null && htmlComponent.getHTML() != null && searchTerm != null && searchTerm.length() > 0) {
					if (htmlComponent.getHTML().indexOf(searchTerm) != -1) {
						util.logger("has " + searchTerm + " in html " + htmlComponent.getName());
					} 
				}
				
			}
		} else if (type.equals("MENU")) {
			while (resultIterator.hasNext()) { 
				LibraryMenuComponent menuComponent = (LibraryMenuComponent) resultIterator.next();
				util.logger("MENU name", menuComponent.getName());
				//util.logger("html", menuComponent.);
			}
		} else if (type.equals("COMP")) { //default for comp
			while (resultIterator.hasNext()) { 
				LibraryComponent component = (LibraryComponent) resultIterator.next();
				util.logger("COMP name",  component.getName());
				util.logger("class",  component.getClass());
			}
		}
		
	}

	//this method does simple generic search based on common properties of each type of component:
	//id, title, name
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private ResultIterator getUtilResults(Query query, DocumentLibrary docLib, 
			HashMap <String, Object> propertiesFilterMap, String type) throws QueryServiceException, DocumentIdCreationException { 
		query.addSelector(Selectors.libraryEquals(docLib));
		
		if (type.equals("AT")) {
			//filter at on id
			String [] atIdArray = (String [])propertiesFilterMap.get("atIdArray");
			DocumentId authTempDocId = null;
			if (atIdArray != null && atIdArray.length == 1) {
				authTempDocId = workspace.createDocumentId(atIdArray[0]);
				query.addSelector(Selectors.authoringTemplateEquals(authTempDocId));
			} else if (atIdArray != null && atIdArray.length > 1) {
				DocumentId [] authTempDocIdArray = new DocumentId[atIdArray.length];
				for (int i = 0; i < atIdArray.length; i++) {
					authTempDocIdArray[i] = workspace.createDocumentId(atIdArray[i]);
				}
				query.addSelector(Selectors.authoringTemplateIn(authTempDocIdArray));
			}			
		}
		
		//exact match -> capitalize bug the same as title 
		name = (String)propertiesFilterMap.get("name");
		if (name != null && name.length() > 0) {
			Disjunction or = new Disjunction();
			or.add(Selectors.nameLike("%" + name + "%"));
			or.add(Selectors.nameLike("%" + name.toLowerCase() + "%"));
			or.add(Selectors.nameLike("%" + name.toUpperCase() + "%"));
			query.addSelector(or);
			//query.addSelector(Selectors.nameLike("%" + name + "%"));
		}
		
		// test new filter id -= for PT, AT , COMP
		String [] idArray = (String [])propertiesFilterMap.get("idArray");
		boolean matchAllIds = (Boolean)propertiesFilterMap.get("matchAllIds");
		if (idArray != null && idArray.length > 0) {
			DocumentId[] idDocArray = new DocumentId[idArray.length];
			DocumentId idDoc = null;
			for (int i = 0; i < idArray.length; i++) {
				idDoc = workspace.createDocumentId(idArray[i]);
				idDocArray[i] = idDoc;
				if (!matchAllIds) { 
					query.addSelector(Selectors.idIn(idDoc));
				}
			}
			List<Identity> categoriesList = new ArrayList<Identity>(Arrays.asList(idDocArray));
			if (matchAllIds) {
				//this is the equivalent of match all cat
				query.addSelector(Selectors.idIn(categoriesList));
			} 
			//simple match by one id
			//query.addSelector(Selectors.idEquals(workspace.createDocumentId(id)));
		}
				
		// filter title, AT, PT or COMP
		String searchTerm = (String)propertiesFilterMap.get("searchTerm");
		if (searchTerm != null && searchTerm.trim().length() > 0) {
			// Stupid IBM function does not support case insensitive!
			util.logger("query searchTerm title", searchTerm);
			Disjunction or = new Disjunction();
			or.add(Selectors.titleLike("%" + searchTerm + "%"));
			or.add(Selectors.titleLike("%" + searchTerm.toLowerCase() + "%"));
			or.add(Selectors.titleLike("%" + searchTerm.toUpperCase() + "%"));
			if (searchTerm.trim().length() > 1) {
				if (!Character.isUpperCase(searchTerm.charAt(0))) {
					or.add(Selectors
							.titleLike("%" + searchTerm.substring(0, 1).toUpperCase() + searchTerm.substring(1) + "%"));
				}
				or.add(Selectors.titleLike("%" + capitalizeString(searchTerm.trim()) + "%"));
			}
			query.addSelector(or);
		}
					
		query.returnObjects();//what does this do ? 
		ResultIterator resultIterator = null;
		resultIterator = workspace.getQueryService().execute(query);
		return resultIterator;
	}

	
	//works with content - each added selector is added filter; By default they are AND-ed 
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private PageIterator getResults(Query query, DocumentLibrary docLib, 
			HashMap <String, Object> propertiesFilterMap) throws QueryServiceException, DocumentIdCreationException {
		
		//by default and all types of filters. If certain filter needs to be OR-ed, send new param specifically
		Conjunction and = new Conjunction();
		and.add(Selectors.libraryEquals(docLib));
		and.add(Selectors.typeIn(Content.class));
		
		// filter AT
		String [] atIdArray = (String [])propertiesFilterMap.get("atIdArray");
		DocumentId authTempDocId = null;
		if (atIdArray != null && atIdArray.length == 1) {
			authTempDocId = workspace.createDocumentId(atIdArray[0]);
			and.add(Selectors.authoringTemplateEquals(authTempDocId));
		} else if (atIdArray != null && atIdArray.length > 1) {
			DocumentId [] authTempDocIdArray = new DocumentId[atIdArray.length];
			for (int i = 0; i < atIdArray.length; i++) {
				authTempDocIdArray[i] = workspace.createDocumentId(atIdArray[i]);
			}
			and.add(Selectors.authoringTemplateIn(authTempDocIdArray));
		}
			
		//filter date from
		Date dateFrom = null;
		String dateStringFrom = (String)propertiesFilterMap.get("dateFrom");
		if (dateStringFrom != null && dateStringFrom.trim().length() > 0) {
			//util.logger("filter by date from");
			try {
				dateFrom = dateFormat.parse(dateStringFrom);
				util.logger("date from after parse: " + dateFrom);
				util.logger("query updated date:" + dateFrom.toString());
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		
		// filter date to
		Date dateTo = null;
		String dateStringTo = (String)propertiesFilterMap.get("dateTo");
		if (dateStringTo != null && dateStringTo.trim().length() > 0) {
			//util.logger("filter by date to");
			try {
				dateTo = dateFormat.parse(dateStringTo);
				util.logger("date to after parse: " + dateTo);
				// Add one day manually (fix includeBoundary not working)
				dateTo = addDays(dateTo, 1, isDebug);
				util.logger("query updated date:" + dateTo.toString());
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		
		//go through all filter properties and use dateFrom and dateTo
		//later we can implement searching by multiple types of date at the same time TODO
		String [] propertiesArray = (String [])propertiesFilterMap.get("propertiesArray");
		if (propertiesArray != null && propertiesArray.length > 0) {
			
			for (int i = 0; i < propertiesArray.length; i++) {
				util.logger("propertiesArray[i]", propertiesArray[i]);
				if (dateFrom != null) {
					util.logger("dateFrom", dateFrom);
					if (propertiesArray[i].equals("publishDate") && dateFrom != null) {
						// includeboundary, the 2nd parameter is NOT working. It is always false anyway
						and.add(WorkflowSelectors.publishAfter(dateFrom, false));
					} else if (propertiesArray[i].equals("generalDateOne") && dateFrom != null) { 
						and.add(WorkflowSelectors.generalDateOneAfter(dateFrom, false));
					} else if (propertiesArray[i].equals("generalDateTwo") && dateFrom != null) { 
						and.add(WorkflowSelectors.generalDateTwoAfter(dateFrom, false));
					}
					
				} if (dateTo != null) {
					if (propertiesArray[i].equals("publishDate") && dateTo != null) {
						// includeboundary, the 2nd parameter is NOT working. It is always false anyway
						and.add(WorkflowSelectors.publishBefore(dateTo, false));
					} else if (propertiesArray[i].equals("generalDateOne") && dateTo != null) { 
						and.add(WorkflowSelectors.generalDateOneBefore(dateTo, false));
					} else if (propertiesArray[i].equals("generalDateTwo")) { 
						and.add(WorkflowSelectors.generalDateTwoBefore(dateTo, false));
					} 
				}
				 
			}
		}
		else { //default if no filterByProperties param send, but dateFrom is sent (as it is now with most portals)
			if (dateFrom != null) and.add(WorkflowSelectors.publishAfter(dateFrom, false));
			if (dateTo != null) and.add(WorkflowSelectors.publishBefore(dateTo, false));
		}
		
		
		//creator DN match
		String creator = (String)propertiesFilterMap.get("creator");
		if (creator != null && creator.length() > 0) {
			and.add(Selectors.creatorEquals(creator));
		}
		
		//TODO what if content is not workflowed ? 
		
		// filter title
		String searchTerm = (String)propertiesFilterMap.get("searchTerm");
		if (searchTerm != null && searchTerm.trim().length() > 0) {
			// Stupid IBM function does not support case insensitive!
			util.logger("query searchTerm", searchTerm);
			Disjunction or = new Disjunction();
			or.add(Selectors.titleLike("%" + searchTerm + "%"));
			or.add(Selectors.titleLike("%" + searchTerm.toLowerCase() + "%"));
			or.add(Selectors.titleLike("%" + searchTerm.toUpperCase() + "%"));
			if (searchTerm.trim().length() > 1) {
				if (!Character.isUpperCase(searchTerm.charAt(0))) {
					or.add(Selectors
							.titleLike("%" + searchTerm.substring(0, 1).toUpperCase() + searchTerm.substring(1) + "%"));
				}
				or.add(Selectors.titleLike("%" + capitalizeString(searchTerm.trim()) + "%"));
			}
			and.add(or);
		}
		
		//sort direction
		sortOrder = (Boolean)propertiesFilterMap.get("sortOrder");
		SortDirection sortDirection = sortOrder ? SortDirection.ASCENDING : SortDirection.DESCENDING;
		
		// sort
		orderBy = (String)propertiesFilterMap.get("orderBy");
		if ("publishDate".equalsIgnoreCase(orderBy)) {
			query.addSort(Sorts.byPublishDate(sortDirection));
		} else if ("creationDate".equalsIgnoreCase(orderBy)) {
			query.addSort(Sorts.byDateCreated(sortDirection));
		} else if ("lastModifiedDate".equalsIgnoreCase(orderBy)) {
			query.addSort(Sorts.byDateModified(sortDirection)); //? is this the same ?
		} else if ("generalDateOne".equalsIgnoreCase(orderBy)) {
			query.addSort(Sorts.byGeneralDateOne(sortDirection));
		} else if ("generalDateTwo".equalsIgnoreCase(orderBy)) {
			query.addSort(Sorts.byGeneralDateTwo(sortDirection));
		} else if ("title".equalsIgnoreCase(orderBy)) {
			query.addSort(Sorts.byTitle(sortDirection));
		} else if ("position".equalsIgnoreCase(orderBy)) {
			query.addSort(Sorts.byPosition(sortDirection));
		} else if ("name".equalsIgnoreCase(orderBy)) {
			query.addSort(Sorts.byName(sortDirection));
		} 

		
		String [] siteAreaIdsArray = (String [])propertiesFilterMap.get("siteAreaIdsArray");
		boolean includeDescendants = (Boolean)propertiesFilterMap.get("includeDescendants");
		if (siteAreaIdsArray != null && siteAreaIdsArray.length > 0) {
			DocumentId siteAreaDocId = null;
			for (int i = 0; i < siteAreaIdsArray.length; i++) {
				util.logger("siteAreaIdsArray[i]", siteAreaIdsArray[i]);
				siteAreaDocId = workspace.createDocumentId(siteAreaIdsArray[i]);
				//desc searches further siteareas 
				if (includeDescendants) {
					util.logger("includeDescendants");
					query.addParentId(siteAreaDocId, QueryDepth.DESCENDANTS);
				} else {
					query.addParentId(siteAreaDocId, QueryDepth.CHILDREN);
				}
			}
		}
		
		// test new filter id
		String [] idArray = (String [])propertiesFilterMap.get("idArray");
		boolean matchAllIds = (Boolean)propertiesFilterMap.get("matchAllIds");
		if (idArray != null && idArray.length > 0) {
			DocumentId[] idDocArray = new DocumentId[idArray.length];
			DocumentId idDoc = null;
			for (int i = 0; i < idArray.length; i++) {
				idDoc = workspace.createDocumentId(idArray[i]);
				idDocArray[i] = idDoc;
				if (!matchAllIds) { 
					util.logger("idDoc " + idDoc.getID());
					and.add(Selectors.idIn(idDoc));
				}
			}
			List<Identity> categoriesList = new ArrayList<Identity>(Arrays.asList(idDocArray));
			if (matchAllIds) {
				//this is the equivalent of match all cat
				and.add(Selectors.idIn(categoriesList));
			} else {
				
			}
			//simple match by one id
			//query.addSelector(Selectors.idEquals(workspace.createDocumentId(id)));
		}
		
		//property -> system name
		name = (String)propertiesFilterMap.get("name");
		if (name != null && name.length() > 0) {
			and.add(Selectors.nameLike("%" + name + "%"));
		}
		
		//all keywords filter - TODO disjunction
		boolean matchAllKeys = (Boolean)propertiesFilterMap.get("matchAllKeys");
		String [] keywordsArray = (String [])propertiesFilterMap.get("keywordsArray");
		if (keywordsArray != null && keywordsArray.length > 0) {
//			DocumentId[] keywordDocIdsArray = new DocumentId[keywordsArray.length];
//			DocumentId keywordDocId = null;
//			for (int i = 0; i < keywordsArray.length; i++) {
//				keywordDocId = workspace.createDocumentId(keywordsArray[i]);
//				keywordDocIdsArray[i] = keywordDocId;
//			}
			List<String> keywordsList = new ArrayList<String>(Arrays.asList(keywordsArray));
			//matches any content which has any of those keys
			if (matchAllKeys) {
				and.add(ProfileSelectors.keywordsContain(keywordsList));
			} else {
				and.add(ProfileSelectors.keywordIn(keywordsList));
			}			
		}
	
		//all categories filter -> does always match by all unless disjunction
		boolean matchAllCategories = (Boolean)propertiesFilterMap.get("matchAllCategories");
		String [] categoryIdsArray = (String [])propertiesFilterMap.get("categoryIdsArray");
		if (categoryIdsArray != null && categoryIdsArray.length > 0) {
			DocumentId[] categoryDocIdsArray = new DocumentId[categoryIdsArray.length];
			DocumentId categoryId = null;
			Disjunction or = new Disjunction();
			Conjunction catAnd = new Conjunction();
			for (int i = 0; i < categoryIdsArray.length; i++) {
				categoryId = workspace.createDocumentId(categoryIdsArray[i]);
				categoryDocIdsArray[i] = categoryId;
				util.logger("categoryId name",categoryId.getName());
				util.logger("categoryId ",categoryId.getID());
				//!!! Doesn't work for more than one category 27.10.2020 -> needs explicit OR
				if (!matchAllCategories) {
					util.logger("match any cat");
					or.add(ProfileSelectors.categoriesContains(categoryId));					
				}
			}
			and.add(or);
			//!!! Doesn't work for more than one category w/o OR Disjunction!! 27.10.2020
			List<Identity> categoriesList = new ArrayList<Identity>(Arrays.asList(categoryDocIdsArray));
			if (matchAllCategories) {
				//this is the equivalent of match all cat
				Conjunction andCatFilter = new Conjunction();
				andCatFilter.add(ProfileSelectors.categoriesContains(categoriesList));
				and.add(andCatFilter);
			} 
		}
		
		//OR-ed categories
		String [] orCategoryIdsArray = (String [])propertiesFilterMap.get("orCategoryIdsArray");
		if (orCategoryIdsArray != null && orCategoryIdsArray.length > 0) {
			DocumentId[] categoryDocIdsArray = new DocumentId[orCategoryIdsArray.length];
			DocumentId categoryId = null;
			Disjunction or = new Disjunction();
			for (int i = 0; i < orCategoryIdsArray.length; i++) {
				categoryId = workspace.createDocumentId(orCategoryIdsArray[i]);
				categoryDocIdsArray[i] = categoryId;
				util.logger("OR categoryId name",categoryId.getName());
				util.logger("OR categoryId ",categoryId.getID());
				or.add(ProfileSelectors.categoriesContains(categoryId));
			}
			and.add(or);
		}
		
		//workflow statuses, if none supplied, the default should be published only
		int draftStatus = (Integer)propertiesFilterMap.get("draftStatus");
		util.logger("draftStatus", draftStatus);
		if (draftStatus == Workspace.WORKFLOWSTATUS_DRAFT) {
			and.add(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.DRAFT));
		} else if (draftStatus == Workspace.WORKFLOWSTATUS_PUBLISHED) {
			and.add(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
		} else if (draftStatus == Workspace.WORKFLOWSTATUS_EXPIRED) {
			and.add(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.EXPIRED));
		} else if (draftStatus == 0) {//default
			and.add(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
		}
		
		query.addSelector(and);
		// generate result
		query.returnObjects();
		
		PageIterator pageIterator = null;
		pageIterator = workspace.getQueryService().execute(query, resultsPerPage, currentPage);
		return pageIterator;
	}
	
	

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void processQueryResults(PageIterator pageIterator)
			throws DocumentRetrievalException, AuthorizationException, QueryStructureException {
		util.logger("IN processQueryResults---------");
		util.logger("page size --------->", pageIterator.getPageSize());
		util.logger("currentPage --------->", currentPage);
		util.logger("searchTerm --------->", searchTerm);
		
		Content content = null;
		ResultIterator docIterator = null;
		DocumentId tempDoc = null;
		DocumentId parentDoc = null;
		String label = "";
		String path = "";
		int page = 0;
		DocumentId [] combinedCategories = null; 
		ArrayList <String> tmpCategoriesList = new ArrayList<String>();
		
		while (pageIterator.hasNext()) {
			docIterator = (ResultIterator) pageIterator.next(); // returns <T extends Document >
			util.logger("pageIterator ---------> NEXT");
			page++;
			String parentName = "";
			
			while (docIterator.hasNext()) {
				total++;
				if (currentPage == 1 && page != currentPage) {
					docIterator.next();
					continue;
				}
				content = (Content) docIterator.next(); // returns <T extends Document >
				
				util.logger("COUNT CONTENT, then get elements ---------> ", total);
				if (returnElements != null) {
					tempFileElementMap = new HashMap();
					tempOptionSelectionMap = new HashMap();
					tmpCategoriesList = new ArrayList<String>();
					String contentElement = "";
					String[] returnElementsArray = returnElements.split(",");
					element = new HashMap<>();
					
					for (int i = 0; i < returnElementsArray.length; i++) {
						try {
							tempCategorySelectionMap = new HashMap();
							contentElement = getContentElement(content, returnElementsArray[i], this.dateFormat);
						} catch (Exception e) {
							System.out.println(e.getMessage());
						}
						// insert single element
						element.put(returnElementsArray[i], contentElement);
						contentElement = "";
					}
					allElements.put(content.getId(), element);
					if (tempOptionSelectionMap.size() > 0) {
						optionElementMetaMap.put(content.getId(), tempOptionSelectionMap);
					}
					if (tempFileElementMap.size() > 0) {
						fileElementMetaMap.put(content.getId(), tempFileElementMap);
					}
					combinedCategories = content.getCombinedCategoryIds();
					for (int j = 0; j < combinedCategories.length; j++) {
						util.logger("combined cat", combinedCategories[j].getId());
						tmpCategoriesList.add(combinedCategories[j].getId());
					}
					categoryIdsForContent.put(content.getId(), tmpCategoriesList);
					//util.logger("VP for " + content.getTitle() + " tempOptionSelectionMap size", tempOptionSelectionMap.size());
					//util.logger("VP for " + content.getTitle() + " tempCategorySelectionMap size", tempCategorySelectionMap.size());
					//util.logger("VP for " + content.getTitle() + " fileElementMetaMap size", fileElementMetaMap.size());
				}

				// FORCE Portal to load Workflow data (this includes the publish date if content
				// has workflow)
				if (content.isWorkflowed()) {
					try {
						if (content.isPublished()) {
							content.getPublishedDate();
						}
					} catch (Exception e) {
					}
				}
				// FORCE Portal to load creation date
				try {
					content.getCreationDate();
				} catch (Exception e) {
				}

				util.logger("pDate vp: ", content.getCreationDate().toString());
				contents.add(content);
				parentDoc = content.getParentId();
				label = ((SiteArea) workspace.getById(parentDoc, true)).getTitle();
				parentSiteAreas.put(content.getId(), label);

				parentName = ((SiteArea) workspace.getById(parentDoc, true)).getName();
				parentSiteAreaNames.put(content.getId(), parentName);
				tempDoc = content.getParentId();
				SiteArea tempSA = (SiteArea) workspace.getById(tempDoc, true);

				// IMPORTANT ! prerequisite -> customsearch returns name of sitearea as
				// contentroot, the portal
				// rootpage has to be the exact same name
				while (!tempSA.getName().equals(this.contentRoot)) { // usually "site"
					path = parentName + "/" + path;
					tempDoc = tempSA.getParentId();
					util.logger("path ", path + ", tempDoc: " + tempDoc);
					util.logger("tempSA ", tempSA.getName());
					tempSA = (SiteArea) workspace.getById(tempDoc, true);
					parentName = ((SiteArea) workspace.getById(tempDoc, true)).getName();
					if (parentName.equals(this.contentRoot)) {
						break;
					}
				}
				paths.put(content.getId(), path);
				path = "";
							
				
			}
			if (currentPage != 1) {
				break;
			}
		}
		util.logger("TOTAL ---------> ", total);
	}
	
	public String [] processStringToStrArray(String values) {
		if (values != null && values.length() > 0) {
			return values.split(",");
		} return null;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private String getContentElement(Content content, String componentName, SimpleDateFormat dateFormat)
			throws ComponentNotFoundException, DocumentRetrievalException, AuthorizationException, PropertyRetrievalException {
		// if (isDebug) { System.out.println("entering getcontent element " +
		// componentName); }
		ContentComponent contentComponent = null;
		if (content.hasComponent(componentName)) {
			contentComponent = content.getComponentByReference(componentName);
			if (contentComponent instanceof RichTextComponent) {
				// System.out.println("richtextcomponent");
				return ((RichTextComponent) contentComponent).getRichText().toString();
			} else if (contentComponent instanceof ShortTextComponent) {
				return ((ShortTextComponent) contentComponent).getText();
			} else if (contentComponent instanceof TextComponent) {
				return ((TextComponent) contentComponent).getText();
			} else if (contentComponent instanceof NumericComponent) {
				return ((NumericComponent) contentComponent).getNumber().toString();
			} else if (contentComponent instanceof ImageComponent) {
				return ((ImageComponent) contentComponent).getResourceURL();
			} else if (contentComponent instanceof LinkComponent) {
				return ((LinkComponent) contentComponent).getURL() + "&linktext&"
						+ ((LinkComponent) contentComponent).getLinkText();
			} else if (contentComponent instanceof FileComponent) {
				util.logger("FileComponent");
				FileComponent component = (FileComponent) contentComponent;
				if (component.getResourceURL() != null) {
										
					//add meta cat data
					HashMap <String, String> fileFieldsMap = new HashMap();
					try {
						fileFieldsMap.put("size", component.getSize() + "");
					} catch (PropertyRetrievalException e) {
						e.printStackTrace();
					}
					
					//util.logger("component.getMimeType()", component.getMimeType());
					//util.logger("component.getFileName()", component.getFileName());
					//can't handle .rar for example
					if (component.getMimeType().indexOf("unknown") != -1) {
						fileFieldsMap.put("mimetype", component.getFileName());
					} else {
						fileFieldsMap.put("mimetype", component.getMimeType());
					}
					
					tempFileElementMap.put(component.getName(), fileFieldsMap);					
					return component.getResourceURL();
				} else {
					return "";
				}
			} else if (contentComponent instanceof DateComponent) {
				// if(isDebug) { System.out.println("datecomponent"); }
				DateComponent component = (DateComponent) contentComponent;
				if (component.getDate() != null) {
					return component.getDate().getTime() + "";
				} else {
					util.logger("dateComponent empty");
					return "";
				}
			} // need to filter contents by optionselection here, can't access them outside vp
				// scope
			else if (contentComponent instanceof OptionSelectionComponent) {
				// util.logger("optionselectioncomponent");
				
				OptionSelectionComponent component = (OptionSelectionComponent) contentComponent;
				DocumentId[] selections = null;
				String[] stringSelections = null;
				try {
					if (component.getOptionType() == OptionType.USE_TAXONOMY) {
						util.logger("OPTION TYPE USE TAXONOMY");
						selections = component.getCategorySelections();
						
					} else if (component.getOptionType() == OptionType.USER_DEFINED) {
						util.logger("OPTION TYPE USER DEFINED");
						stringSelections = component.getSelections();
						if (isDebug) {
							if (stringSelections == null) {
								util.logger("stringSelections are null ", stringSelections);
							}
						}
					}
				} catch (OperationFailedException e) { // if the option type is OptionType.USER_DEFINED ??? We usually
														// define it this wayp ;w mwiud;
					System.out.println("OperationFailedException:" + e.getMessage());
					e.printStackTrace();
				}

				if (selections != null) {
					util.logger("SELECTION LEN: ", selections.length);
					String result = "";
					Document doc = null;
					
					//add meta cat data for chosen categories for THIS element
					HashMap <String, String> categoryFieldsMap = null;
					for (int i = 0; i < selections.length; i++) {
						util.logger(" option i: ", selections[i]);
						doc = workspace.getById(selections[i]);
						util.logger("id ", doc.getId().getID() + " , name: " + doc.getName() + ", component.getName() " + component.getName());
						categoryFieldsMap = new HashMap();
						categoryFieldsMap.put("id", doc.getId().getID());
						categoryFieldsMap.put("name", doc.getName());
						categoryFieldsMap.put("title", doc.getTitle());
						tempCategorySelectionMap.put(doc.getName(), categoryFieldsMap);						
						
						if (selections.length > 1 && i != (selections.length -1)) {
							result += doc.getTitle() + ",";
						} else {
							result += doc.getTitle();
						}
						util.logger("selections result", result);
					}
					//populate all chosen cat meta data for this element 
					if (selections.length > 0) {
						tempOptionSelectionMap.put(component.getName(), tempCategorySelectionMap);
					}
					return result;

				}
				if (stringSelections != null) {
					util.logger("STRING SELECTION LEN: ", stringSelections.length + " option 0: "
								+ stringSelections[0]);
					String result = "";
					String selected = "";
					for (int i = 0; i < stringSelections.length; i++) {
						selected = stringSelections[i];
						if (stringSelections.length > 1 && i != (stringSelections.length -1)) {
							result += selected + ",";
						} else {
							result += selected;
						}
						util.logger("stringSelections ", result);
					}
					return result;
				}
			}
		} else {
			util.logger("No such component (vpscoped) ", componentName);
		}
		return "";
	}

	private Date addDays(Date date, int days, boolean isDebug) {
		if (isDebug) {
			System.out.println("add days " + date.toString() + " offset: " + days);
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DATE, days); // minus number would decrement the days
		util.logger("add days cal ", cal.getTime());
		return cal.getTime();
	}

	private String capitalizeString(String string) {
		char[] chars = string.toLowerCase().toCharArray();
		boolean found = false;
		for (int i = 0; i < chars.length; i++) {
			if (!found && Character.isLetter(chars[i])) {
				chars[i] = Character.toUpperCase(chars[i]);
				found = true;
			} else if (Character.isWhitespace(chars[i]) || chars[i] == '.' || chars[i] == '\'') { // You can add other
																									// chars here
				found = false;
			}
		}
		return String.valueOf(chars);
	}

}
