package com.ibm.customsearch.servlet;

public class Util {
	private boolean isDebug = false;
	private String methodDebugged = "";
	
	public void setDebug(boolean isDebug) {
		this.isDebug = isDebug;
	}
	public void setMethodDebugged(String methodDebugged) {
		this.methodDebugged = methodDebugged;
	}
	
	public Util() {
	}
	
	public void logger(Object... message) {
		if (isDebug){
			if (message != null && message.length > 1 && message[1] != null) {
				log(message[0], message[1]);
			} else {
				log(message[0]);
			}
			if (methodDebugged != null && methodDebugged.length() > 0) {
				StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
				String stacktrace = stackTraceElements[2].toString().substring(0, stackTraceElements[2].toString().indexOf("("));
				if (stacktrace.substring(stacktrace.lastIndexOf(".") + 1).equals(methodDebugged)) {
					if (message.length > 1 && message[1] != null) {
						log(message[0], message[1]);
		    		} else {
		    			log(message[0]);
		    		}
				}
			}
		}
	}
	
	private void log(Object... message) {
    	if (message != null && message.length > 1 && message[1] != null) {
    		if (message[0].equals("") && message[1].equals("")) {
    			System.out.println();
    		} else {
    			System.out.println(message[0] + ": " + message[1]);
    		}
    	} else {
    		System.out.println(message[0]);
    	}
    }
	
}
