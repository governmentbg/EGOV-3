package com.ibm.customsearch.servlet;

import java.io.IOException;
import java.net.URLDecoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.ContentComponent;
import com.ibm.workplace.wcm.api.DateComponent;
import com.ibm.workplace.wcm.api.Document;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.FileComponent;
import com.ibm.workplace.wcm.api.ImageComponent;
import com.ibm.workplace.wcm.api.LinkComponent;
import com.ibm.workplace.wcm.api.NumericComponent;
import com.ibm.workplace.wcm.api.OptionSelectionComponent;
import com.ibm.workplace.wcm.api.Repository;
import com.ibm.workplace.wcm.api.RichTextComponent;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.TextComponent;
import com.ibm.workplace.wcm.api.VirtualPortalContext;
import com.ibm.workplace.wcm.api.WCM_API;
import com.ibm.workplace.wcm.api.Workspace;
import com.ibm.workplace.wcm.api.exceptions.ComponentNotFoundException;
import com.ibm.workplace.wcm.api.exceptions.PropertyRetrievalException;

/**
 * Servlet implementation class WCMCustomSearch
 */
@WebServlet("/customsearch")
public class WCMCustomSearch extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.ENGLISH);
	private static Repository repository = null;
	private static Workspace workspace = null;
	private String contentRoot = "site";
	private int resultsPerPage = 10;
	private int currentPage = 1;
	private String orderBy = Workspace.SORT_KEY_TITLE;
	private String orderBy2 = Workspace.SORT_KEY_TITLE;
	private String orderBy3 = Workspace.SORT_KEY_TITLE;
	private boolean sortOrder = true;// true asc, false desc
	private boolean includeAncestors = false;
	private boolean includeDescendants = false;
	private boolean matchAllCategories = false;
	private boolean includeDescendentCategories = false;
	private boolean isDebug = false;
	private long start = 0;
	private Util util = new Util();
	private String methodDebugged = "";

	public static final java.lang.String SORT_KEY_CREATION_DATE = "creationDate";
	public static final java.lang.String SORT_KEY_PUBLISH_DATE = "publishDate";
	public static final java.lang.String SORT_KEY_EXPIRY_DATE = "expiryDate";
	public static final java.lang.String SORT_KEY_GENERAL_DATE_ONE = "generalDateOne";
	public static final java.lang.String SORT_KEY_GENERAL_DATE_TWO = "generalDateTwo";
	public static final java.lang.String SORT_KEY_LASTMODIFIED_DATE = "lastModifiedDate";
	public static final java.lang.String SORT_KEY_NAME = "name";
	public static final java.lang.String SORT_KEY_TITLE = "title";
	public static final java.lang.String SORT_KEY_DESCRIPTION = "description";
	public static final java.lang.String SORT_KEY_NONE = "";
	
	public boolean PRODUCTION_FLAG = false;
	public boolean VPCONTEXT_FLAG = true;

	// private static final String contentSummaryField = "institutionDescription";// egov institution field
	
	public void init() throws ServletException {
		super.init();
		//ServletContext servletContext = getServletContext();
        //String realPath = servletContext.getRealPath("/");
        //System.out.println("server info: " + servletContext.getServerInfo());
		if (repository != null) {
			return;
		}
		repository = WCM_API.getRepository();
		try {
			workspace = repository.getSystemWorkspace();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public WCMCustomSearch() {		
		super();
	}

	public void destroy() {
		super.destroy();
		if (workspace != null) {
			try {
				workspace.logout();
				repository.endWorkspace();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setHeader("Cache-Control", "no-cache");
		response.setContentType("application/json; charset=UTF-8");
		request.setCharacterEncoding("utf8");
		
		init();
		
		start = System.currentTimeMillis();
		isDebug = request.getParameter("debug") != null;
		methodDebugged = request.getParameter("methodDebugged");
		util.setDebug(isDebug);
		util.setMethodDebugged(methodDebugged);
		util.logger("WCMCustomSearch customsearch -> doGET(request, response)");
				
		//params		
		String contextParam = request.getParameter("context");
		String libraryNameParam = request.getParameter("libName");
		String contentRootParam = request.getParameter("contentRoot");
		String rootPageParam = request.getParameter("rootPage");
		String sortByElementParam = request.getParameter("sortByElement");
		String dateFormatParam = request.getParameter("dateFormat");
		String siteAreaIds = request.getParameter("saId");
		String authoringTemplateId = request.getParameter("atId");
		String categoryIds = request.getParameter("catId");
		String matchAllCatParam = request.getParameter("matchAllCat");
		String includeDescendentCategoriesParam = request.getParameter("includeDescCat");
		String returnElements = request.getParameter("returnElements");
		String returnProperties = request.getParameter("returnProperties");
		boolean searchByKeywords = request.getParameter("searchByKeywords") != null;
		String filterByElements = request.getParameter("filterByElements");
		String filterByProperties = request.getParameter("filterByProperties");
		String lastModifiedDate = request.getParameter("lastModifiedDate");
		boolean userCache = request.getParameter("cache") != null;		
		String currentUrl = request.getParameter("currentUrl");		
		// boolean isBGLocale = request.getParameter("localeBg") != null;
		boolean isDateCapital = request.getParameter("capitalDate") != null;
		String includeAncestorsParam = request.getParameter("ancestors");
		String includeDescendantsParam = request.getParameter("descendants");
		String orderByParam = request.getParameter("orderBy");
		String orderByParam2 = request.getParameter("orderBy2");
		String orderByParam3 = request.getParameter("orderBy3");
		String sortOrderParam = request.getParameter("sortOrder");
		String searchTerm = request.getParameter("searchTerm");
		String searchFilters = request.getParameter("searchFilterObject");
		String dateFrom = request.getParameter("from");
		String dateTo = request.getParameter("before");
		String rootPage = "";
		String libraryName = "";
		String context = null;
		String sortByElement = "";
		boolean isDraft = request.getParameter("draftStatus") != null;// 1 draft, 2 published
		boolean showOnlyElementsWithKey = request.getParameter("showOnlyElementsWithKey") != null;
		boolean customSortReverse = request.getParameter("customSortReverse") != null;
		boolean useQuery = request.getParameter("useQuery") != null;
		if (request.getParameter("rPP") != null) {
			try {
				resultsPerPage = Integer.parseInt(request.getParameter("rPP"));
			} catch (Exception e) {
			}
		}
		if (request.getParameter("currentPage") != null) {
			try {
				this.currentPage = Integer.parseInt(request.getParameter("currentPage"));
			} catch (Exception e) {
			}
		}
		
		this.PRODUCTION_FLAG = "PROD".equalsIgnoreCase(System.getProperty("environment"));
		if (this.PRODUCTION_FLAG) {
			util.logger("PROD ENV");
		} else if ("STAGING".equalsIgnoreCase(System.getProperty("environment"))) {
			util.logger("STAGING ENV request url", request.getRequestURL());			
		}
		util.logger("searchTerm", request.getParameter("searchTerm"));
		
		JSONObject parsedJson = null;
		
		if (searchFilters != null && searchFilters.length() > 0) {
			String decodedFilters = URLDecoder.decode(searchFilters, "UTF-8");
			util.logger("decodedFilters", decodedFilters);
			parsedJson = JSONObject.parse(decodedFilters);		
		}
				
		int draftStatus = Workspace.WORKFLOWSTATUS_PUBLISHED;
		// System.out.println("DOGET draftStatus " + draftStatus);
		if (isDraft) {
			util.logger("draft status");
			draftStatus = Workspace.WORKFLOWSTATUS_DRAFT;
		}

		ArrayList<Content> contents = null;
		HashMap<DocumentId, String> parentSiteAreas = null;
		HashMap<DocumentId, String> parentSiteAreaNames = null;
		HashMap<DocumentId, String> paths = null;
		HashMap<DocumentId, HashMap> allElements = null;
		int total = 0;
		//HashMap<String, String> element = null;
		util.logger("rElem", returnElements);
		util.logger("siteAreaIds", siteAreaIds);
		util.logger("context", contextParam);
		util.logger("from", dateFrom);
		util.logger("before", dateTo);			
		// if (siteAreaId != null && siteAreaId.trim().length() > 0) {
		if (contentRootParam != null && contentRootParam.length() > 0) {
			this.contentRoot = contentRootParam;
		}
		if (orderByParam != null) {
			this.orderBy = orderByParam;
		}
		if (orderByParam2 != null) {
			this.orderBy2 = orderByParam2;
		}
		if (orderByParam3 != null) {
			this.orderBy3 = orderByParam3;
		}
		if (sortOrderParam != null && sortOrderParam.length() > 0) {
			this.sortOrder = new Boolean(sortOrderParam);
		}
		if (includeAncestorsParam != null && includeAncestorsParam.length() > 0) {
			this.includeAncestors = new Boolean(includeAncestorsParam);
		}
		if (includeDescendantsParam != null && includeDescendantsParam.length() > 0) {
			this.includeDescendants = new Boolean(includeDescendantsParam);
		}
		if (matchAllCatParam != null && matchAllCatParam.length() > 0) {
			this.matchAllCategories = new Boolean(matchAllCatParam);
		}
		if (includeDescendentCategoriesParam != null && includeDescendentCategoriesParam.length() > 0) {
			this.includeDescendentCategories = new Boolean(includeDescendentCategoriesParam);
		}
		if (rootPageParam != null && rootPageParam.length() > 0) {
			rootPage = rootPageParam;
		} else {
			rootPage = libraryNameParam;
		}
		if (libraryNameParam != null && libraryNameParam.length() > 0) {
			libraryName = libraryNameParam;
		}
		if (contextParam != null && contextParam.length() > 0) {
			context = contextParam;
		}
		if (sortByElementParam != null && sortByElementParam.length() > 0) {
			if (isDebug) {System.out.println("will use custom sort");}
			sortByElement = sortByElementParam;
		}
		// parse multiple site areas
		String[] siteAreaIdsArray = null;
		if (siteAreaIds != null && siteAreaIds.length() > 0) {
			siteAreaIdsArray = siteAreaIds.split(",");
		}
		// parse multiple category Ids
		String[] categoryIdsArray = null;
		if (categoryIds != null && categoryIds.length() > 0) {
			categoryIdsArray = categoryIds.split(",");
		}
		////////////////////////////////////// VP ///////////////////////////////////////////////
		if (context != null) {
			util.logger("VP CONTEXT", contextParam);
			// Create the required VirtualPortalContext using the repositorysetd
			VirtualPortalContext vctx;
			try {
				vctx = repository.generateVPContextFromContextPath(context);
				// Create VP Scoped Action object
				util.logger("before entering vp scoped search");
				if (request.getParameter("demo") != null) {
					VPScopedQuerySearch vpA = new VPScopedQuerySearch(libraryName, contentRoot, siteAreaIdsArray, authoringTemplateId, 
							categoryIdsArray, this.orderBy, this.sortOrder, draftStatus, 
							isDebug, returnElements, dateFormat, dateFrom, dateTo, resultsPerPage, currentPage, searchTerm);
					util.logger("after init");
					repository.executeInVP(vctx, vpA);
					util.logger("after execute");
					contents = (ArrayList) ((ArrayList) vpA.getReturnedValue()).get(0);
					parentSiteAreas = (HashMap) ((ArrayList) vpA.getReturnedValue()).get(1);
					parentSiteAreaNames = (HashMap) ((ArrayList) vpA.getReturnedValue()).get(2);
					paths = (HashMap) ((ArrayList) vpA.getReturnedValue()).get(3);
					allElements = (HashMap) ((ArrayList) vpA.getReturnedValue()).get(4);
					total = (int)((ArrayList) vpA.getReturnedValue()).get(5);
				} else {
					VPScopedContentSearch vpA = new VPScopedContentSearch(libraryName, this.contentRoot, siteAreaIdsArray, authoringTemplateId, 
							categoryIdsArray, (searchByKeywords && searchTerm != null ? new String[] { searchTerm } : null), 
							this.matchAllCategories, this.includeDescendentCategories, this.includeAncestors, 
							this.includeDescendants, this.orderBy, this.orderBy2, this.orderBy3, this.sortOrder, draftStatus, 
							isDebug, returnElements, dateFormat, dateFrom, dateTo, useQuery);
					util.logger("after init");
					repository.executeInVP(vctx, vpA);
					util.logger("after execute");
					contents = (ArrayList) ((ArrayList) vpA.getReturnedValue()).get(0);
					parentSiteAreas = (HashMap) ((ArrayList) vpA.getReturnedValue()).get(1);
					parentSiteAreaNames = (HashMap) ((ArrayList) vpA.getReturnedValue()).get(2);
					paths = (HashMap) ((ArrayList) vpA.getReturnedValue()).get(3);
					allElements = (HashMap) ((ArrayList) vpA.getReturnedValue()).get(4);
				}

			} catch (Exception e) {
				e.printStackTrace();
			}
		} ///////////////////////////////// BASE ////////////////////////////////////////////
		else {
			DocumentId doc = null;
			Content content = null;
			util.logger("AT", authoringTemplateId);
			DocumentIdIterator<Content> docIterator = null;
			contents = new ArrayList<Content>();

			try {
				// fill category
				DocumentId[] categoryDocIdsArray = null;
				if (categoryIdsArray != null && categoryIdsArray.length > 0) {
					categoryDocIdsArray = new DocumentId[categoryIdsArray.length];
					DocumentId categoryId = null;
					for (int i = 0; i < categoryIdsArray.length; i++) {
						// fill each saID into new doc id, then add to array
						categoryId = workspace.createDocumentId(categoryIdsArray[i]);
						util.logger("category name", categoryId.getName());
						categoryDocIdsArray[i] = categoryId;
					}
				}

				DocumentId AuthTempId = workspace.createDocumentId(authoringTemplateId);

				// site area
				DocumentId docId = null;
				DocumentId[] siteAreaDocIdArray = new DocumentId[siteAreaIdsArray.length];
				for (int i = 0; i < siteAreaIdsArray.length; i++) {
					// fill each saID into new doc id, then add to array
					docId = workspace.createDocumentId(siteAreaIdsArray[i]);
					util.logger("sitearea id", docId.getName());
					siteAreaDocIdArray[i] = docId;
				}
				docIterator = workspace.contentSearch(AuthTempId, siteAreaDocIdArray, categoryDocIdsArray, (searchByKeywords && searchTerm != null ? new String[] { searchTerm }
						: null), this.matchAllCategories, false, this.includeDescendentCategories, this.includeAncestors, this.includeDescendants, this.orderBy, this.orderBy2,
						this.orderBy3, this.sortOrder, draftStatus);

				while (docIterator.hasNext()) {
					doc = docIterator.next(); // returns <T extends Document >
					content = (Content) workspace.getById(doc, true);					
					contents.add(content);
				}				
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (contents != null && contents.size() >= 0) { // process response			
			if (dateFormatParam != null) {
				try {
					// SimpleDateFormat dateFormat2 = new SimpleDateFormat("dd MMMM yyyy", LocaleUtils.toLocale("bg_BG"));
					// System.out.println("testdateformat");
					// System.out.println("df2: " + dateFormat2.format(new Date()));

					this.dateFormat = new SimpleDateFormat(dateFormatParam, Locale.ENGLISH);
				} catch (Exception e) {
				}
			}
			
			// custom sort if such parameter passed from UI
			util.logger("sortByElement", sortByElement);
			if (!sortByElement.equals("")) {
				try {
					contents = customSortContents(sortByElement, contents, showOnlyElementsWithKey, isDebug, this.dateFormat, customSortReverse);
				} catch (ComponentNotFoundException e) {
					e.printStackTrace();
				}
			}
			
			try {
				if (request.getParameter("demo") != null) {
					this.returnResultNew(request, response, libraryName, contents, searchTerm, dateFrom, dateTo, currentUrl, 
							filterByElements, filterByProperties, searchByKeywords, returnProperties, returnElements, parentSiteAreas, 
							parentSiteAreaNames, paths, userCache, isDraft, isDateCapital, context, allElements, 
							this.dateFormat, rootPage, parsedJson, lastModifiedDate, total);
					if (isDebug) {
						System.out.println("-------------------------");
						System.out.println("timeElapsed=" + ((float)((System.currentTimeMillis() - start)) / 1000) + " seconds");
						System.out.println("-------------------------");
					}
					return;
				}
				this.returnResult(request, response, libraryName, contents, searchTerm, dateFrom, dateTo, currentUrl, 
						filterByElements, filterByProperties, searchByKeywords, returnProperties, returnElements, parentSiteAreas, 
						parentSiteAreaNames, paths, userCache, isDraft, isDateCapital, context, allElements, 
						this.dateFormat, rootPage, parsedJson, lastModifiedDate);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void returnResult(HttpServletRequest request, HttpServletResponse response, String libraryName, 
			ArrayList<Content> contents, String searchTerm, String dateFrom, String dateTo, String currentUrl, 
			String filterByElements, String filterByProperties, boolean searchByKeywords, String returnProperties, String returnElements,
			HashMap<DocumentId, String> parentSiteAreas, HashMap<DocumentId, String> parentSiteAreaNames, 
			HashMap<DocumentId, String> paths, boolean userCache, boolean isDraft, boolean isDateCapital, 
			String context, HashMap<DocumentId, HashMap> allElements, SimpleDateFormat dateFormat, String rootPage, 
			JSONObject parsedJson, String lastModifiedDate) throws Exception {

		int jsonCounter = 0;
		JSONObject tmpJsonObj = null;
		JSONObject jsonContent = null;
		JSONObject json = new JSONObject();
		JSONArray jsonArr = new JSONArray();

		String id = "";
		DocumentId docId = null;
		String title = "";
		String contentUrl = "";
		String originUrl = currentUrl;
		String label = "";
		String author = "";
		String description = "";
		Date tmpDate = null;
		String formattedDate = "";
		String[] properties = null;
		String[] elements = null;
		// String summary = null;
		String componentName = "";
		// String remoteActionEntry = "";
		if (isDebug) {
			System.out.println("originUrl " + originUrl);
		}

		ArrayList<Content> filteredContents = this.searchSiteArea(contents, searchTerm, dateFrom, dateTo, 
				filterByElements, filterByProperties, searchByKeywords, dateFormat, parsedJson, lastModifiedDate, isDraft);

		// json objects

		int resultSize = filteredContents.size();
		Double d = new Double(resultSize);
		Integer numPages = WCMCustomSearch.getNumberOfPages(d, this.resultsPerPage);

		json.put("numberOfAllResults", new String(((Integer) contents.size()).toString())); // egov municipalities
		json.put("numberOfPages", new String(numPages.toString()));
		json.put("numberOfResults", new String(((Integer) filteredContents.size()).toString()));
		if (isDebug) {
			System.out.println("SIZE of result: " + filteredContents.size());
		}
		jsonArr.add(jsonCounter++, json);

//		String[] arr = null;
		String contentName = "";
		DocumentId parentId = null;
		String parentSiteAreaName = "";
		Content currentContent = null;

		for (int i = (currentPage - 1) * this.resultsPerPage; i < (this.resultsPerPage * this.currentPage) && i < filteredContents.size(); i++) {
			
			// properties always sent to client			
			currentContent = (Content)filteredContents.get(i); 
			docId = currentContent.getId();
			id = docId.getID();
			title = currentContent.getTitle();
			// procedures 1 level deeper
//			arr = originUrl.split("/");
			contentName = currentContent.getName();
			parentId = currentContent.getParentId();
			parentSiteAreaName = parentId.getName();
			if (isDebug) {
				System.out.println("parentSA: " + parentSiteAreaName);
				System.out.println("origin URL " + contentUrl);
			}
				
			//contents are accessed differently on a vp contextual portal, which are often used in development
			if (VPCONTEXT_FLAG) {
				if (isDebug) { System.out.println("VP CONTEXTUAL PORTAL!!!");}
				if (isDebug) { System.out.println("prod flag: " + this.PRODUCTION_FLAG);}
				// dev url longer
				if (this.PRODUCTION_FLAG) {
					contentUrl = originUrl.substring(0, originUrl.indexOf("portal/") + 7) +  rootPage + "/";
				} else {
					contentUrl = originUrl.substring(0, originUrl.indexOf("portal/") + 7) + context + "/" + rootPage + "/";
				}
				
			} 
			else {
				contentUrl = originUrl.substring(0, originUrl.indexOf("portal/") + 7) +  rootPage + "/";
			}
			if (isDebug) {System.out.println("paths: " + paths.get(filteredContents.get(i).getId()));}
			contentUrl += paths.get(filteredContents.get(i).getId()) + contentName;
			contentUrl.replaceAll(" ", "%20");
			if (isDebug) {
				System.out.println("new URL : " + contentUrl);
			}
			
			
			// System.out.println("title " + title);
			tmpJsonObj = new JSONObject();
			jsonContent = new JSONObject();

			// id
			tmpJsonObj = new JSONObject();
			tmpJsonObj.put("id", id);
			jsonContent.put("content", tmpJsonObj);
			// title
			tmpJsonObj = new JSONObject();
			tmpJsonObj.put("title", title);
			jsonContent.put("contentTitle", tmpJsonObj);
			// url
			// System.out.println("contentName: " + contentName);
			tmpJsonObj = new JSONObject();
			tmpJsonObj.put("url", contentUrl);
			jsonContent.put("contentUrl", tmpJsonObj);

			tmpJsonObj = new JSONObject();
			tmpJsonObj.put("name", ((Content) contents.get(i)).getId().getName());
			jsonContent.put("contentName", tmpJsonObj);

			// properties on demand
			if (returnProperties != null) {
				properties = returnProperties.split(",");
				for (int j = 0; j < properties.length; j++) {
					tmpDate = null;
					if (properties[j].equals("author")) {
						author = currentContent.getCreator();
						if (isDebug) {
							System.out.println("creator " + author);
						}
						// author
						tmpJsonObj = new JSONObject();
						tmpJsonObj.put("author", author);
						jsonContent.put("contentAuthor", tmpJsonObj);

					} else if (properties[j].equals("publishDate")) {						
						try {							
							tmpDate = currentContent.getEffectiveDate();
						} catch (PropertyRetrievalException e) {
							System.out.println("get Effective date exception... trying to get the publish date instead...err:" 
									+ e.getMessage());
							try {
								if (currentContent.isPublished()) {
									tmpDate = currentContent.getPublishedDate();
								}
							} catch (Exception e2) {
								System.out.println("Error getting publish date... err:" + e2.getMessage());
							}
						}																	
						if (tmpDate == null) {
							tmpDate = currentContent.getCreationDate();
						}						
						
						formattedDate = dateFormat.format(tmpDate);
						//?
						if (isDateCapital) {
							formattedDate = formattedDate.toUpperCase();
						}
						if (isDebug) {
							System.out.println("publish date " + formattedDate);
						}
						// publishDate
						tmpJsonObj = new JSONObject();
						tmpJsonObj.put("publishDate", formattedDate);
						jsonContent.put("contentDate", tmpJsonObj);
					} else if (properties[j].equals("lastModifiedDate")) {						
						try {
							tmpDate = currentContent.getModifiedDate();
						} catch (Exception e) {
							System.out.println("getModifiedDate date exception");		
						}
						if (tmpDate == null) {
							tmpDate = currentContent.getCreationDate();
						}
						if (isDebug) {
							System.out.println(tmpDate.toString());
						}
						formattedDate = dateFormat.format(tmpDate);
						if (isDateCapital) {
							formattedDate = formattedDate.toUpperCase();
						}
						if (isDebug) {
							System.out.println("last modified date " + formattedDate);
						}
						// publishDate
						tmpJsonObj = new JSONObject();
						tmpJsonObj.put("lastModifiedDate", formattedDate);
						jsonContent.put("contentLastModifiedDate", tmpJsonObj);
					} else if (properties[j].equals("parentSA")) {
						// label
						label = parentSiteAreas.get(filteredContents.get(i).getId());
						tmpJsonObj = new JSONObject();
						tmpJsonObj.put("label", label);
						jsonContent.put("contentLabel", tmpJsonObj);
					} else if (properties[j].equals("parentSAName")) {
						// label
						//parentSiteAreaName = parentSiteAreaNames.get(filteredContents.get(i).getId());
						tmpJsonObj = new JSONObject();
						tmpJsonObj.put("parentSAName", parentSiteAreaName);
						jsonContent.put("contentParentSAName", tmpJsonObj);
					} else if (properties[j].equals("description")) {
						description = currentContent.getDescription();
						tmpJsonObj = new JSONObject();
						tmpJsonObj.put("description", description);
						jsonContent.put("contentDescription", tmpJsonObj);
					}
				}
			}

			// elements on demand - only for base portal
			if (returnElements != null) {
				elements = returnElements.split(",");
				String newElement = "";
				HashMap <String, String> element = new HashMap <>();
				element = allElements.get(docId);
				if (isDebug) { System.out.println("docId " + docId); }
				for (int j = 0; j < elements.length; j++) {
					if (context == null) {
						componentName = this.getContentElement((Content) filteredContents.get(i), elements[j], dateFormat);
					} else {
						//get elements from result of vp c. search
						//if (this.isDebug) {System.out.println("comp: " ); }
						componentName = element.get(elements[j]);
					}
					//if (this.isDebug) { System.out.println("componentName " + componentName); }
					tmpJsonObj = new JSONObject();
					if (elements[j].contains("-")) {
						newElement = elements[j].replaceAll("-", "");
						tmpJsonObj.put(newElement, componentName);
						jsonContent.put("content" + newElement, tmpJsonObj);
					} else if (elements[j].contains(" ")) { //fix for Cveti's AT names
						newElement = elements[j].replaceAll(" ", "");
						tmpJsonObj.put(newElement, componentName);
						jsonContent.put("content" + newElement, tmpJsonObj);
					}else {
						tmpJsonObj.put(elements[j], componentName);
						jsonContent.put("content" + elements[j], tmpJsonObj);
					}
				}
			}
			// result ready to be added
			jsonArr.add(jsonCounter++, jsonContent);
		}

		if (currentPage == 1 && userCache == true) {//
			jsonArr.add(getAllTitlesAndUrls(contents, originUrl));
		}

		// System.out.println("response: " + jsonArr);	
		response.getWriter().write(jsonArr.toString());
		response.getWriter().flush();
		response.getWriter().close();
		
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void returnResultNew(HttpServletRequest request, HttpServletResponse response, String libraryName, 
			ArrayList<Content> contents, String searchTerm, String dateFrom, String dateTo, String currentUrl, 
			String filterByElements, String filterByProperties, boolean searchByKeywords, String returnProperties, String returnElements,
			HashMap<DocumentId, String> parentSiteAreas, HashMap<DocumentId, String> parentSiteAreaNames, 
			HashMap<DocumentId, String> paths, boolean userCache, boolean isDraft, boolean isDateCapital, 
			String context, HashMap<DocumentId, HashMap> allElements, SimpleDateFormat dateFormat, String rootPage, 
			JSONObject parsedJson, String lastModifiedDate, int total) throws Exception {

		int jsonCounter = 0;
		JSONObject tmpJsonObj = null;
		JSONObject jsonContent = null;
		JSONObject json = new JSONObject();
		JSONArray jsonArr = new JSONArray();

		String id = "";
		DocumentId docId = null;
		String title = "";
		String contentUrl = "";
		String originUrl = currentUrl;
		String label = "";
		String author = "";
		String description = "";
		Date tmpDate = null;
		String formattedDate = "";
		String[] properties = null;
		String[] elements = null;
		// String summary = null;
		String componentName = "";
		// String remoteActionEntry = "";
		if (isDebug) {
			System.out.println("originUrl " + originUrl);
		}

		// TODO why?
		//ArrayList<Content> filteredContents = this.searchSiteArea(contents, searchTerm, dateFrom, dateTo, filterByElements, filterByProperties, searchByKeywords, dateFormat, parsedJson, lastModifiedDate, isDraft);

		// json objects

		Double d = new Double(total);
		Integer numPages = WCMCustomSearch.getNumberOfPages(d, resultsPerPage);

		
		json.put("numberOfPages", new String(numPages.toString()));
		json.put("numberOfResults", new String(((Integer) contents.size()).toString())); // egov municipalities
		json.put("numberOfAllResults", new String(((Integer) total).toString())); // egov municipalities
		json.put("timeInSeconds", new String(((Float) ((float)(System.currentTimeMillis() - start) / 1000)).toString()));
		if (isDebug) {
			System.out.println("SIZE of result: " + contents.size());
		}
		jsonArr.add(jsonCounter++, json);

//		String[] arr = null;
		String contentName = "";
		DocumentId parentId = null;
		String parentSiteAreaName = "";
		Content currentContent = null;

		for (int i = 0; i < contents.size(); i++) {
			
			// properties always sent to client			
			currentContent = (Content)contents.get(i); 
			docId = currentContent.getId();
			id = docId.getID();
			title = currentContent.getTitle();
			// procedures 1 level deeper
//			arr = originUrl.split("/");
			contentName = currentContent.getName();
			parentId = currentContent.getParentId();
			parentSiteAreaName = parentId.getName();
			if (isDebug) {
				System.out.println("parentSA: " + parentSiteAreaName);
				System.out.println("origin URL " + contentUrl);
			}
				
			//contents are accessed differently on a vp contextual portal, which are often used in development
			if (VPCONTEXT_FLAG) {
				if (isDebug) { System.out.println("VP CONTEXTUAL PORTAL!!!");}
				if (isDebug) { System.out.println("prod flag: " + this.PRODUCTION_FLAG);}
				// dev url longer
				if (this.PRODUCTION_FLAG) {
					contentUrl = originUrl.substring(0, originUrl.indexOf("portal/") + 7) +  rootPage + "/";
				} else {
					contentUrl = originUrl.substring(0, originUrl.indexOf("portal/") + 7) + context + "/" + rootPage + "/";
				}
				
			} 
			else {
				contentUrl = originUrl.substring(0, originUrl.indexOf("portal/") + 7) +  rootPage + "/";
			}
			if (isDebug) {System.out.println("paths: " + paths.get(contents.get(i).getId()));}
			contentUrl += paths.get(contents.get(i).getId()) + contentName;
			contentUrl.replaceAll(" ", "%20");
			if (isDebug) {
				System.out.println("new URL : " + contentUrl);
			}
			
			
			// System.out.println("title " + title);
			tmpJsonObj = new JSONObject();
			jsonContent = new JSONObject();

			// id
			tmpJsonObj = new JSONObject();
			tmpJsonObj.put("id", id);
			jsonContent.put("content", tmpJsonObj);
			// title
			tmpJsonObj = new JSONObject();
			tmpJsonObj.put("title", title);
			jsonContent.put("contentTitle", tmpJsonObj);
			// url
			// System.out.println("contentName: " + contentName);
			tmpJsonObj = new JSONObject();
			tmpJsonObj.put("url", contentUrl);
			jsonContent.put("contentUrl", tmpJsonObj);

			tmpJsonObj = new JSONObject();
			tmpJsonObj.put("name", ((Content) contents.get(i)).getId().getName());
			jsonContent.put("contentName", tmpJsonObj);

			// properties on demand
			if (returnProperties != null) {
				properties = returnProperties.split(",");
				for (int j = 0; j < properties.length; j++) {
					tmpDate = null;
					if (properties[j].equals("author")) {
						author = currentContent.getCreator();
						if (isDebug) {
							System.out.println("creator " + author);
						}
						// author
						tmpJsonObj = new JSONObject();
						tmpJsonObj.put("author", author);
						jsonContent.put("contentAuthor", tmpJsonObj);

					} else if (properties[j].equals("publishDate")) {						
						try {							
							tmpDate = currentContent.getEffectiveDate();
						} catch (PropertyRetrievalException e) {
							System.out.println("get Effective date exception... trying to get the publish date instead...err:" 
									+ e.getMessage());
							try {
								if (currentContent.isPublished()) {
									tmpDate = currentContent.getPublishedDate();
								}
							} catch (Exception e2) {
								System.out.println("Error getting publish date... err:" + e2.getMessage());
							}
						}																	
						if (tmpDate == null) {
							tmpDate = currentContent.getCreationDate();
						}						
						
						formattedDate = dateFormat.format(tmpDate);
						//?
						if (isDateCapital) {
							formattedDate = formattedDate.toUpperCase();
						}
						if (isDebug) {
							System.out.println("publish date " + formattedDate);
						}
						// publishDate
						tmpJsonObj = new JSONObject();
						tmpJsonObj.put("publishDate", formattedDate);
						jsonContent.put("contentDate", tmpJsonObj);
					} else if (properties[j].equals("lastModifiedDate")) {						
						try {
							tmpDate = currentContent.getModifiedDate();
						} catch (Exception e) {
							System.out.println("getModifiedDate date exception");		
						}
						if (tmpDate == null) {
							tmpDate = currentContent.getCreationDate();
						}
						if (isDebug) {
							System.out.println(tmpDate.toString());
						}
						formattedDate = dateFormat.format(tmpDate);
						if (isDateCapital) {
							formattedDate = formattedDate.toUpperCase();
						}
						if (isDebug) {
							System.out.println("last modified date " + formattedDate);
						}
						// publishDate
						tmpJsonObj = new JSONObject();
						tmpJsonObj.put("lastModifiedDate", formattedDate);
						jsonContent.put("contentLastModifiedDate", tmpJsonObj);
					} else if (properties[j].equals("parentSA")) {
						// label
						label = parentSiteAreas.get(contents.get(i).getId());
						tmpJsonObj = new JSONObject();
						tmpJsonObj.put("label", label);
						jsonContent.put("contentLabel", tmpJsonObj);
					} else if (properties[j].equals("parentSAName")) {
						// label
						//parentSiteAreaName = parentSiteAreaNames.get(filteredContents.get(i).getId());
						tmpJsonObj = new JSONObject();
						tmpJsonObj.put("parentSAName", parentSiteAreaName);
						jsonContent.put("contentParentSAName", tmpJsonObj);
					} else if (properties[j].equals("description")) {
						description = currentContent.getDescription();
						tmpJsonObj = new JSONObject();
						tmpJsonObj.put("description", description);
						jsonContent.put("contentDescription", tmpJsonObj);
					}
				}
			}

			// elements on demand - only for base portal
			if (returnElements != null) {
				elements = returnElements.split(",");
				String newElement = "";
				HashMap <String, String> element = new HashMap <>();
				element = allElements.get(docId);
				if (isDebug) { System.out.println("docId " + docId); }
				for (int j = 0; j < elements.length; j++) {
					if (context == null) {
						componentName = this.getContentElement((Content) contents.get(i), elements[j], dateFormat);
					} else {
						//get elements from result of vp c. search
						//if (this.isDebug) {System.out.println("comp: " ); }
						componentName = element.get(elements[j]);
					}
					//if (this.isDebug) { System.out.println("componentName " + componentName); }
					tmpJsonObj = new JSONObject();
					if (elements[j].contains("-")) {
						newElement = elements[j].replaceAll("-", "");
						tmpJsonObj.put(newElement, componentName);
						jsonContent.put("content" + newElement, tmpJsonObj);
					} else if (elements[j].contains(" ")) { //fix for Cveti's AT names
						newElement = elements[j].replaceAll(" ", "");
						tmpJsonObj.put(newElement, componentName);
						jsonContent.put("content" + newElement, tmpJsonObj);
					}else {
						tmpJsonObj.put(elements[j], componentName);
						jsonContent.put("content" + elements[j], tmpJsonObj);
					}
				}
			}
			// result ready to be added
			jsonArr.add(jsonCounter++, jsonContent);
		}

		if (currentPage == 1 && userCache == true) {//
			jsonArr.add(getAllTitlesAndUrls(contents, originUrl));
		}
		
		// System.out.println("response: " + jsonArr);		
		response.getWriter().write(jsonArr.toString());
		response.getWriter().flush();
		response.getWriter().close();
		
	}
	
	//we use both searchTerm and multiple filters
	public ArrayList<Content> searchSiteArea(ArrayList<Content> contents, String searchTerm, String dateFrom, String dateTo, 
			String filterByElements, String filterByProperties, boolean searchByKeywords, SimpleDateFormat dateFormat, 
			JSONObject parsedJson, String lastModifiedDateFilter, boolean isDraft)
			throws Exception {
		if (isDebug) {
			System.out.println("searchterm " + searchTerm + "; filterByelements: " + filterByElements + 
					";filterByProperties " + filterByProperties);
		}
		if (isDebug) {
			if (parsedJson != null) { System.out.println("parsed json:" + parsedJson); }
		}
		if ((searchTerm == null || searchTerm.length() < 3) && (dateFrom == null || dateFrom.equals("")) && 
				(dateTo == null || dateTo.equals("")) && (parsedJson == null || parsedJson.isEmpty()) && 
				(lastModifiedDateFilter == null || lastModifiedDateFilter.equals(""))) { // return all results when
			if (isDebug) {
				System.out.println("return ALL results");
			}
			return contents;
		}
		
		searchTerm = searchTerm.toLowerCase();
		Content content = null;
		String title = "";
		ArrayList<Content> filteredSearchResults = new ArrayList<Content>();
		String elementValueToFilter = "";
//		String propertyToFilter = "";
		String splitValueFromDate [] = null;
		Calendar calendarDateFromFilter = null;
		Calendar calendarDateFromContent = null;
		String jsonStringValue = "";
		String filterValue = "";
		Date lastModifiedDate = null;
		Date contentDate = null;
		Date dateFromDate = null;
		Date dateToDate = null;
		String[] elements = null;
		String[] properties = null;
		String docId = "";
		boolean keywordsMatch = false;
		boolean elementMatch = false;
		boolean propertyMatched = false;
		boolean titleMatched = false;
		
		boolean elementsFilterEnforced = false;
		boolean propertiesFilterEnforced = false;
		boolean searchTermFilterEnforced = false; //used for titleMatch and keywordsMatch specific element
//		boolean hasFilterMatchingBothTitleAndElement = false;
		
		//important! to enforce strict element filtering, front end should send multiple values
		//if not, then the other filters could be enough
		//-> TODO! add multipleFilter enforcing later
		if (parsedJson != null && !parsedJson.isEmpty()) {
			
		}
		if (filterByElements != null && !filterByElements.equals("")) {
			elements = filterByElements.split(",");
			elementsFilterEnforced = true;
		}
		//results have been queried by publish date already (if using query of course)
		if (filterByProperties != null && !filterByProperties.equals("") && lastModifiedDateFilter != null && lastModifiedDateFilter.length() > 0) {
			properties = filterByProperties.split(",");
			propertiesFilterEnforced = true;
		}
		if (searchTerm.length() > 2) { // search term exists
			searchTermFilterEnforced = true;
		}
		if (isDebug) { System.out.println("contents.size() " + contents.size());}
		for (int i = 0; i < contents.size(); i++) {
			
			keywordsMatch = false;
			elementMatch = false;
			titleMatched = false;
			propertyMatched = false;
			
			content = (Content) contents.get(i);
			docId = content.getId().toString();
			if (isDebug) { System.out.println("docId: " + docId + ", isDraft: " + isDraft);}
			if (docId.endsWith("/DRAFT") && !isDraft) {
				continue;
				
			} else if (docId.endsWith("/PUBLISHED") && isDraft) { 
				continue;
			} 
			title = content.getTitle().trim().toLowerCase();
			contentDate = content.getCreationDate();
			lastModifiedDate = content.getModifiedDate();
			
			//if publishDate between from && to -> keep going, otherwise quit this iteration
			try {
				contentDate = content.getEffectiveDate();
			} catch (Exception e) {
				if (isDebug) { System.out.println("getEffectiveDate exception: " + e.getMessage()); }
			}
			
			if (isDebug) {
				System.out.println("contentDate=" + contentDate.toString());
			}
			
			//TODO RESEARCH WHY WE DUPLICATE VALIDATION?
			//validation by publish date was not done in menu API
			if (dateFrom != null && dateFrom.trim().length() > 0) {
				dateFromDate = dateFormat.parse(dateFrom);
				if (isDebug) {
					System.out.println("dateFrom " + dateFromDate.toString());
				}
				if (contentDate.compareTo(dateFromDate) < 0) {
					System.out.println("SKIPPING");
					continue;					
				}
			}
			if (dateTo != null && dateTo.trim().length() > 0) {
				dateToDate = dateFormat.parse(dateTo);
				if (isDebug) {
					System.out.println("dateTo " + dateToDate.toString());
				}
				dateToDate = VPScopedContentSearch.addDays(contentDate, 1, isDebug);
				if (contentDate.compareTo(dateToDate) > 0) {
					System.out.println("SKIPPING");
					continue;
				}
			}
				
			if (searchByKeywords) {
				if (searchTermFilterEnforced) {
					for (int j = 0; j < content.getKeywords().length; j++) {					
						if (content.getKeywords()[j].toLowerCase().equals(searchTerm)) {
							keywordsMatch = true;
							//old implementation
							//break;
						}				
						//for now, won't implement searching in keywords using those multiple filters
						//if (parsedJson.containsValue(content.getKeywords()[j].toLowerCase())) {
						//	keywordsMatch = true;
						//	break;
						//}											
					}
				}
			}
			
			//check for searchTerm in property title
			if (searchTermFilterEnforced) {
				if (title.indexOf(searchTerm) != -1) {
					if (isDebug) { System.out.println("title case: " + searchTerm); }
					titleMatched = true;

				}
			}
			
			//
			if (elements != null) {
				elementValueToFilter = "";
				for (int j = 0; j < elements.length; j++) {
					elementValueToFilter = this.getContentElement(content, elements[j], dateFormat);
					//if (isDebug) { System.out.println("elementValueToFilter: " + elementValueToFilter + ",element: " + elements[j] + 
					//		", value:" + parsedJson.get(elements[j]) + "; equals: " + elements[j].equalsIgnoreCase(searchTerm)); }
					if (isDebug) { System.out.println("elements[j]: " + elements[j]); }
					//element name was camelcased, but searchTerm is lowercased ! 
					//if (isDebug) { System.out.println("searchTerm toString: "+ searchTerm.toString());}
					//if (isDebug) { System.out.println("elements[j] toString: "+ elements[j].toString());}
					
					//very specific case -> if certain element is not mandatory, and title is used instead, then
					//the filter's name is added to searchTerm value , and check in title should be made
					//either element or title match is ENOUGH! 
					
					/*if (elements[j].equalsIgnoreCase(searchTerm)) {
						filterValue = (String)parsedJson.get(elements[j]);
						if (isDebug) { System.out.println("specific case, title is :" + title + ", elements[j] is: " + elements[j] + ", filter is:" + filterValue); } 
						filterValue = filterValue.toLowerCase();
						if (title.indexOf(filterValue) != -1 || elementValueToFilter.indexOf(filterValue) != -1) { 
							if (isDebug) { System.out.println("match element field with title "); }
							searchTermFilterEnforced = false;
							elementMatch = true;
						} else { 
							elementMatch = false;
							break; 
						}
					} */
					if (elementValueToFilter != null && elementValueToFilter.trim().length() > 0) {
						elementValueToFilter = elementValueToFilter.toLowerCase();						
						
						//if using just single searchTerm, search elements the old way
						if (elementValueToFilter.indexOf(searchTerm) != -1) {
							if (isDebug) { System.out.println("element match"); }
							//filteredSearchResults.add(content);
							elementMatch = true;
							//old implementation
							//break;
						}
						
						/*if (parsedJson == null) {
							
						} else {
							//if (isDebug) {System.out.println("elem: " + elements[j]);}
							jsonStringValue = (String) parsedJson.get(elements[j]);
							//check if keys have been added to filter							
							if (jsonStringValue != null) {
								if (isDebug) { System.out.println("jsonStringValue " + jsonStringValue); }
								if (isDebug) { System.out.println("elementToFilter " + elementValueToFilter); }
								if (elementValueToFilter.indexOf(jsonStringValue) != -1 || elementValueToFilter.equals(jsonStringValue)) {
									if (isDebug) { System.out.println("json element match"); }
									elementMatch = true;
								} else { //AND operator -> search for contents 
									elementMatch = false;
									break;
								}
							}							
						}*/					
					}
				}
			}
			
			
			//this will be used for exact property matching (lastModifiedDate for now)
			if (properties != null) {								
				for (int j = 0; j < properties.length; j++) { 
					//jsonStringValue = (String) parsedJson.get(properties[j]);
					if (properties[j].equals("lastModifiedDate")) {
						//jsonStringValue = (String)parsedJson.get("lastModifiedDate");
						if (lastModifiedDateFilter != null && lastModifiedDateFilter.length() > 0) {
							if (isDebug) {System.out.println("lastModifiedDateFilter :" + lastModifiedDateFilter);}
							if (isDebug) { System.out.println("content lastmodified: " + content.getModifiedDate().toString());}
							splitValueFromDate = lastModifiedDateFilter.split("\\.");
//							Date dateFromFilter = dateFormat.parse(lastModifiedDateFilter);
//							Date lastModifiedFromContent = content.getModifiedDate();
														
							//Date lastModifiedFromContent = dateFormat.parse(content.getModifiedDate().toString());
							calendarDateFromFilter = Calendar.getInstance();
							calendarDateFromFilter.set(Integer.parseInt(splitValueFromDate[2]), 
									Integer.parseInt(splitValueFromDate[1]) - 1, Integer.parseInt(splitValueFromDate[0]));
							calendarDateFromFilter.set(Calendar.HOUR_OF_DAY, 0);
							calendarDateFromFilter.set(Calendar.MINUTE, 0);
							calendarDateFromFilter.set(Calendar.SECOND, 0);
							calendarDateFromFilter.set(Calendar.MILLISECOND, 0);
							calendarDateFromContent = Calendar.getInstance();
							calendarDateFromContent.setTime(content.getModifiedDate());
							calendarDateFromContent.set(Calendar.HOUR_OF_DAY, 0);
							calendarDateFromContent.set(Calendar.MINUTE, 0);
							calendarDateFromContent.set(Calendar.SECOND, 0);
							calendarDateFromContent.set(Calendar.MILLISECOND, 0);
							
							Date dateFromFilter = calendarDateFromFilter.getTime();
							Date dateFromContent = calendarDateFromContent.getTime();
							
							if (isDebug) {
								System.out.println("date from filter: " + dateFromFilter);
								System.out.println("date from content: " + dateFromContent);
							}
														
							if (dateFromFilter.compareTo(dateFromContent) == 0) {
								if (isDebug) { System.out.println("lastModifiedDate MATCH !"); }
								propertyMatched = true;
							}
						}						
					}					
				}			
			}
			
			if (isDebug) {System.out.println("elementsFilterEnforced: " + elementsFilterEnforced);}
			if (isDebug) {System.out.println("elementMatch: " + elementMatch);}
			if (isDebug) {System.out.println("searchTermFilterEnforced: " + searchTermFilterEnforced);}
			if (isDebug) {System.out.println("titleMatched: " + titleMatched);}
			if (isDebug) {System.out.println("keywordsMatch: " + keywordsMatch);}
			if (isDebug) {System.out.println("elementMatch: " + elementMatch);}
			if (isDebug) {System.out.println("propertiesFilterEnforced: " + propertiesFilterEnforced);}
			if (isDebug) {System.out.println("propertyMatched: " + propertyMatched);}
			
			
			/*if (elementsFilterEnforced) {
				if (!elementMatch) {
					continue;
				}
			}//when single searchTerm is supplied, compare it to all 3 
			*/
			if (searchTermFilterEnforced) { 
				if(!titleMatched && !keywordsMatch && !elementMatch) {
					continue;
				}
			} if (propertiesFilterEnforced) {
				if(!propertyMatched) {
					continue;
				}
			}
			if (isDebug) {System.out.println("no filters have been set");}
			filteredSearchResults.add(content);					
		}
		return filteredSearchResults;
	}

	public static JSONArray getAllTitlesAndUrls(ArrayList<Content> contents, String originUrl) {
		JSONObject jsonAutocompleteTitle = null;
		JSONObject jsonAutocompleteUrl = null;
		JSONObject jsonAutocomplete = null;
		JSONArray jsonAutocompleteArr = new JSONArray();

		// put all urls and titles for autocomplete in json
		for (int i = 0; i < contents.size(); i++) {
			jsonAutocompleteTitle = new JSONObject();
			jsonAutocompleteTitle.put("title", ((Content) contents.get(i)).getTitle());
			jsonAutocompleteUrl = new JSONObject();
			jsonAutocompleteUrl.put("url", originUrl + ((Content) contents.get(i)).getName());
			jsonAutocomplete = new JSONObject();
			jsonAutocomplete.put("autocompleteTitle", jsonAutocompleteTitle);
			jsonAutocomplete.put("autocompleteUrl", jsonAutocompleteUrl);
			jsonAutocompleteArr.add(i, jsonAutocomplete);
		}
		return jsonAutocompleteArr;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private String getContentElement(Content content, String componentName, SimpleDateFormat dateFormat) throws Exception {
		//if (isDebug) { System.out.println("entering getcontent element " + componentName); }
		ContentComponent contentComponent = null;
		if (content.hasComponent(componentName)) {
			contentComponent = content.getComponentByReference(componentName);
		} else {
			if (isDebug) { System.out.println("No such component " + componentName); }
		}
		if (contentComponent == null) return "";
		if (contentComponent instanceof RichTextComponent) {
			//System.out.println("richtextcomponent");
			RichTextComponent component = (RichTextComponent) contentComponent;
			return component.getRichText().toString();
		} else if (contentComponent instanceof ShortTextComponent) {
			//System.out.println("shorttextcomponent");
			ShortTextComponent component = (ShortTextComponent) contentComponent;
			//System.out.println("short: " + component.getName());
			//System.out.println("short2: " + component.getText());
			return component.getText();
		} else if (contentComponent instanceof TextComponent) {
			//System.out.println("textcomponent");
			TextComponent component = (TextComponent) contentComponent;
			return component.getText();
		} else if (contentComponent instanceof NumericComponent) {
			//System.out.println("numericcomponent");
			NumericComponent component = (NumericComponent) contentComponent;
			return component.getNumber().toString();
		} else if (contentComponent instanceof ImageComponent) {
			//System.out.println("imagecomponent");
			ImageComponent component = (ImageComponent) contentComponent;
			return component.getResourceURL();
		} else if (contentComponent instanceof FileComponent) {
			//System.out.println("filecomponent");
			FileComponent component = (FileComponent) contentComponent;
			return component.getResourceURL();
		} else if (contentComponent instanceof LinkComponent) {
			LinkComponent component = (LinkComponent) contentComponent;
			return component.getLinkText();
		} else if (contentComponent instanceof DateComponent) {
			//System.out.println("imagecomponent");
			DateComponent component = (DateComponent) contentComponent;
			if (component.getDate() != null) {			
				DateFormat inputFormat = new SimpleDateFormat("EEE MMM dd hh:hh:ss zzzz yyyy");
				Date date = inputFormat.parse(component.getDate().toString());				
				String dateString = dateFormat.format(date);
				if (isDebug) {System.out.println("dateComponent formated: " + dateString );}
				return dateString;
			}else {
				if (isDebug) {System.out.println("dateComponent empty");}
				return "";
			}
			
		} else if (contentComponent instanceof OptionSelectionComponent) {
			if(isDebug) { System.out.println("optionselectioncomponent"); }		
			//cant get categories ouside of VP context in case of VP
						
			OptionSelectionComponent component = (OptionSelectionComponent) contentComponent;
			DocumentId [] selections = null;
			try {
				selections = component.getCategorySelections();
			} catch (Exception e) {
				System.out.println(e.getMessage());
				e.printStackTrace();							
			}
					
			if (selections != null) {
				if (isDebug) { System.out.println("SELECTION: " + selections.length); }
				
				String result = "";			
//				DocumentId selected = null;
				Document doc = null;
				//Category cat = null;
				for (int i = 0; i < selections.length; i++) {
//					selected = selections[i];				
					doc = workspace.getById(selections[i]);
					if (selections.length > 1) {
						result = doc.getTitle() + ",";					
					} else {
						result = doc.getTitle();					
					}
					if (isDebug) { System.out.println("selections " + result); }			
				}
				return result;	
			}							
		} 			
		return "";	
	}

	public static int getNumberOfPages(Double resultSize, int resultsPerPage) {
		if (resultSize <= resultsPerPage) {
			return 1;
		} else {
			Double d = new Double(Math.ceil(resultSize / resultsPerPage));
			return d.intValue();
		}
	}
	
	//custom sort, reordering the whole array and passing the key to be sorted by
	public static ArrayList<Content> customSortContents(String sortByElement, ArrayList<Content> contents, boolean showOnlyElementsWithKey, boolean isDebug,
			SimpleDateFormat dateFormat, boolean customSortReverse) throws ComponentNotFoundException {
		if (isDebug) { System.out.println("inside customsort "); }
		HashMap<Long, ArrayList<Content>> contentsHm = new HashMap<>();		 
		ArrayList<Content> tmpContents = new ArrayList<Content>();				
		ContentComponent contentComponent = null;
		Content tmpContent = null;		
		ArrayList<Content> singleElement = new ArrayList<Content>();
		ArrayList<Content> zeroKeyElements = new ArrayList<Content>();
		Long sortKey = 0l;
		Long tempSortKey = 0l;		
		ArrayList <Long> sortKeys = new ArrayList<Long>();
		
		for (int i = 0; i < contents.size(); i++) {
			//if (isDebug) { System.out.println("contents size: " + contents.size()); }
			//get element and store type of sort key
			tmpContent = contents.get(i);			
			if (tmpContent.hasComponent(sortByElement)) {
				contentComponent = contents.get(i).getComponentByReference(sortByElement);
			}
			//represent all types of keys as strings
			if (contentComponent instanceof DateComponent) {		
				DateComponent component = (DateComponent) contentComponent;					
				if (component.getDate() != null) {					
					sortKey = component.getDate().getTime();
					System.out.println("sortKey date " + i + "-th iteration " + sortKey);
					if (!sortKeys.contains(sortKey) && sortKey != 0l) {
						if(isDebug) {System.out.println("list doesnt contain sortkey");}
						sortKeys.add(sortKey);
					}					
				}			
				
			} else if (contentComponent instanceof NumericComponent) {
				NumericComponent component = (NumericComponent) contentComponent;				
				if (!component.toString().equals("")) {
					sortKey = component.getNumber().longValue();
					if (!sortKeys.contains(sortKey) && sortKey != 0l) {						
						sortKeys.add(sortKey);
					}
				}
				
			} else {
				if (isDebug) { System.out.println("custom sort text ?: ");}
				//sortKey = ""; no real world scenarios requiring sort by random text element ?
				sortKeys.add(sortKey);
			}
			
			if (customSortReverse) {
				Collections.sort(sortKeys, Collections.reverseOrder());
			} else {
				Collections.sort(sortKeys);
			}			
			
			//generate hashmap of all keys and content pairs
			
			if (isDebug) { System.out.println("sortKey: " + sortKey); }
			if (sortKey != null && sortKey != 0) { 
				if(isDebug) {System.out.println("content pair " + sortKey + ", " + tempSortKey);}
				
				if (tempSortKey.compareTo(sortKey) == 0) { //add another entry for the same key
					singleElement.add(tmpContent);
					if(isDebug) { System.out.println("addd"); }
				} else {
					if(isDebug) { System.out.println("addd new"); }
					singleElement = new ArrayList<Content>();//create new list for the next key, then add entry
					singleElement.add(tmpContent);
				}
				tempSortKey = sortKey;
				contentsHm.put(sortKey, singleElement);
			}			
			//reset sortKey
			//sortKey = 0l;
			//save the contents with no sortkey in separate list, so that they can be added to result if showElementsWith key is false
			if (sortKey == 0 && !showOnlyElementsWithKey) {
				if (isDebug) { System.out.println("sortkey zero");}
				zeroKeyElements.add(tmpContent);
			}
		}
		
		//iterate over sortKeys to populate an  arraylist for each sortKey		
		
		if (isDebug) {System.out.println("contentsHm: " + contentsHm.size());}
		
		//if no keys are set, just iterate result set
		if (sortKeys.size() == 0) {
			return contents;
		} else {
			//clear all order provided by menu sort and do custom sort, iterate over sorted key set
			contents = new ArrayList<>();
			for (int i = 0; i < sortKeys.size(); i++) {
				if (isDebug) { System.out.println("iterate sorted keyset: " + sortKeys.get(i)); }
				tmpContents = contentsHm.get(sortKeys.get(i));
				if(isDebug) {  System.out.println("tmpContents size on each key: " + tmpContents.size());}
				if (tmpContents != null && tmpContents.size() > 0) {
					for (int j = 0; j < tmpContents.size(); j++) {	
						if(isDebug) { System.out.println("inner loop'"); }
						/*if (showOnlyElementsWithKey) {
							if (isDebug) { System.out.println("showOnlyElementsWithKey"); }
							if(sortKeys.get(i) == 0l) { //add results with zero key ?
								if (isDebug) { System.out.println("sort key not set"); }
								//contents.add(tmpContents.get(j));
							} else {
								contents.add(tmpContents.get(j));	
							}
						} else {
							contents.add(tmpContents.get(j));	
						} */
						contents.add(tmpContents.get(j));	
					}
				}			
			}
			if (!showOnlyElementsWithKey) {
				for (int i = 0; i < zeroKeyElements.size(); i++) {
					if (isDebug) {System.out.println("element with no key: " + zeroKeyElements.get(i).getTitle());}
					contents.add(zeroKeyElements.get(i));
				}
			}
		}
		return contents;
	}
	
	public static String getTypeOfElement(ArrayList<Content> contents, String sortByElement, boolean isDebug) throws ComponentNotFoundException {
		//get element and store type of sort key
		Content tmpContent = null;
		ContentComponent contentComponent = null;
		for (int i = 0; i < contents.size(); i++) { 			
			tmpContent = contents.get(i);			 
			contentComponent = null;
			if (tmpContent.hasComponent(sortByElement)) {
				contentComponent = contents.get(i).getComponentByReference(sortByElement);
			}
			if (contentComponent == null) continue;
			//only date and numeric components will be represented as long, else string
			if (contentComponent instanceof DateComponent) {		
				DateComponent component = (DateComponent) contentComponent;				
				if (!component.toString().equals("")) {
					return "long";
				}				
				
			} else if (contentComponent instanceof NumericComponent) {
				NumericComponent component = (NumericComponent) contentComponent;
				if (isDebug) { System.out.println("custom sort number: " + component.toString());}
				if (!component.toString().equals("")) {					
					return "long";
				}
				
			} else {				
				return "string";
			}
		}
		return "";
	}
	
	

}
