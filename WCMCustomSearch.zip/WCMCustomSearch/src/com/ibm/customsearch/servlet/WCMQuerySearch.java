package com.ibm.customsearch.servlet;

import java.io.IOException;
import java.net.URLDecoder;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.ContentComponent;
import com.ibm.workplace.wcm.api.DateComponent;
import com.ibm.workplace.wcm.api.Document;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.FileComponent;
import com.ibm.workplace.wcm.api.ImageComponent;
import com.ibm.workplace.wcm.api.LinkComponent;
import com.ibm.workplace.wcm.api.NumericComponent;
import com.ibm.workplace.wcm.api.OptionSelectionComponent;
import com.ibm.workplace.wcm.api.Repository;
import com.ibm.workplace.wcm.api.RichTextComponent;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.TextComponent;
import com.ibm.workplace.wcm.api.VirtualPortalContext;
import com.ibm.workplace.wcm.api.WCM_API;
import com.ibm.workplace.wcm.api.Workspace;
import com.ibm.workplace.wcm.api.exceptions.ComponentNotFoundException;
import com.ibm.workplace.wcm.api.exceptions.PropertyRetrievalException;

/**
 * Servlet implementation class WCMCustomSearch
 */
@WebServlet("/query")
public class WCMQuerySearch extends HttpServlet {

	private static final long serialVersionUID = 1L;
	private SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.ENGLISH);
	private static Repository repository = null;
	private static Workspace workspace = null;
	private String contentRoot = "site";
	private int resultsPerPage = 10;
	private int currentPage = 1;
	private String orderBy = Workspace.SORT_KEY_TITLE;
	private boolean sortOrder = true;// true asc, false desc
	private boolean includeAncestors = false;
	private boolean includeDescendants = false;
	private boolean matchAllCategories = false;
	private boolean matchAllKeys = false;
	private boolean matchAllIds = false;
	private boolean includeDescendentCategories = false;
	private HashMap<String, Object> propertiesFilterMap = null;
	private boolean isDebug = false;
	private String methodDebugged = "";
	private Util util = new Util();
	private long start = 0;
	

	public static final java.lang.String SORT_KEY_CREATION_DATE = "creationDate";
	public static final java.lang.String SORT_KEY_PUBLISH_DATE = "publishDate";
	public static final java.lang.String SORT_KEY_EXPIRY_DATE = "expiryDate";
	public static final java.lang.String SORT_KEY_GENERAL_DATE_ONE = "generalDateOne";
	public static final java.lang.String SORT_KEY_GENERAL_DATE_TWO = "generalDateTwo";
	public static final java.lang.String SORT_KEY_LASTMODIFIED_DATE = "lastModifiedDate";
	public static final java.lang.String SORT_KEY_NAME = "name";
	public static final java.lang.String SORT_KEY_TITLE = "title";
	public static final java.lang.String SORT_KEY_DESCRIPTION = "description";
	public static final java.lang.String SORT_KEY_NONE = "";
	
	public boolean PRODUCTION_FLAG = false;
	public boolean VPCONTEXT_FLAG = true;

	public void init() throws ServletException {
		super.init();
		//ServletContext servletContext = getServletContext();
        //String realPath = servletContext.getRealPath("/");
        //System.out.println("server info: " + servletContext.getServerInfo());
		if (repository != null) {
			return;
		}
		repository = WCM_API.getRepository();
		try {
			workspace = repository.getSystemWorkspace();			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public WCMQuerySearch() {		
		super();
	}

	public void destroy() {
		super.destroy();
		if (workspace != null) {
			try {
				workspace.logout();
				repository.endWorkspace();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setHeader("Cache-Control", "no-cache");
		response.setContentType("application/json; charset=UTF-8");
		request.setCharacterEncoding("utf8");
		
		init();
		
		start = System.currentTimeMillis();
		
		ArrayList<Content> contents = null;
		HashMap<DocumentId, String> parentSiteAreas = null;
		HashMap<DocumentId, String> parentSiteAreaNames = null;
		HashMap<DocumentId, String> paths = null;
		HashMap<DocumentId, HashMap> allElements = null;
		//content docid:element name map -> element name:chosenCat map-> chosenCat:map -> id, title, name
		HashMap<DocumentId, HashMap <String, HashMap<String, HashMap<String, String>>>> optionElementMetaMap = null;
		HashMap<DocumentId, HashMap <String, HashMap<String, String>>> fileElementMetaMap = null;
		HashMap<DocumentId, ArrayList<String>> combinedCatIdsForContent = null;
		
		isDebug = request.getParameter("debug") != null;
		methodDebugged = request.getParameter("methodDebugged");
		util.setDebug(isDebug);
		util.setMethodDebugged(methodDebugged);
		util.logger("WCMCustomSearch query -> doGET(request, response)");		
				
		//params
		//to expand logic - we add each new property as separate request param in front end
		//here, we accumulate them in a hashMap
		String contextParam = request.getParameter("context");
		String libraryNameParam = request.getParameter("libName");
		String contentRootParam = request.getParameter("contentRoot");
		String rootPageParam = request.getParameter("rootPage");
		String dateFormatParam = request.getParameter("dateFormat");
		String siteAreaIds = request.getParameter("saId");
		String authoringTemplateId = request.getParameter("atId");
		String categoryIds = request.getParameter("catId");
		String orCategoryIds = request.getParameter("ORcatId");
		String secondaryFilterParam = request.getParameter("secondaryFilterProp");
		String secondaryFrom = request.getParameter("secondaryFrom");
		String secondaryTo = request.getParameter("secondaryTo");
		String keywordIds = request.getParameter("keyId");
		String matchAllCatParam = request.getParameter("matchAllCat");
		String matchAllKeysParam = request.getParameter("matchAllKeys");
		String matchAllIdsParam = request.getParameter("matchAllIds");
		String includeDescendentCategoriesParam = request.getParameter("includeDescCat");
		String returnElements = request.getParameter("returnElements");
		String returnProperties = request.getParameter("returnProperties");
		boolean userCache = request.getParameter("cache") != null;		
		String currentUrl = request.getParameter("currentUrl");
		String filterByProperties = request.getParameter("filterByProperties");
		String lastModifiedDate = request.getParameter("lastModifiedDate");
		String optionMetaParam = request.getParameter("optionMeta");
		String fileMetaParam = request.getParameter("fileMeta");
		String sortByElementParam = request.getParameter("sortByElement");
		boolean getOptionMeta = false;
		boolean getFileMeta = false;
		
		// boolean isBGLocale = request.getParameter("localeBg") != null;
		boolean isDateCapital = request.getParameter("capitalDate") != null;
		String includeAncestorsParam = request.getParameter("ancestors");
		String includeDescendantsParam = request.getParameter("descendants");
		String orderByParam = request.getParameter("orderBy");
		String sortOrderParam = request.getParameter("sortOrder");
		String searchTerm = request.getParameter("searchTerm");
		String dateFrom = request.getParameter("from");
		String dateTo = request.getParameter("before");
		
		//new properties added
		String idParam = request.getParameter("id");
		String nameParam = request.getParameter("name");
		String creatorParam = request.getParameter("creator");
		String type = request.getParameter("type");
		
		String rootPage = "";
		String libraryName = "";
		String context = null;
		String secondaryFilter = null;
		String sortByElement = "";
		String draftStatus = request.getParameter("draftStatus");// 1 draft, 2 published, 4 exp
		boolean showOnlyElementsWithKey = request.getParameter("showOnlyElementsWithKey") != null;
		propertiesFilterMap = new HashMap<String, Object>();
		
		if (request.getParameter("rPP") != null) {
			try {
				resultsPerPage = Integer.parseInt(request.getParameter("rPP"));
			} catch (Exception e) {
			}
		}
		if (request.getParameter("currentPage") != null) {
			try {
				this.currentPage = Integer.parseInt(request.getParameter("currentPage"));
			} catch (Exception e) {
			}
		}
			
		this.PRODUCTION_FLAG = "PROD".equalsIgnoreCase(System.getProperty("environment"));
		if (this.PRODUCTION_FLAG) {
			util.logger("PROD ENV");
		} else if ("STAGING".equalsIgnoreCase(System.getProperty("environment"))) {
			util.logger("STAGING ENV request url",request.getRequestURL());			
		}
		util.logger("searchTerm", request.getParameter("searchTerm"));
		int draftStatusInt = 2;//by default, if not supplied - draft status published
//		util.logger("draft:" + Workspace.WORKFLOWSTATUS_DRAFT, "pub:" + 
//		Workspace.WORKFLOWSTATUS_PUBLISHED + ", exp: " + Workspace.WORKFLOWSTATUS_EXPIRED);
		if (draftStatus != null && draftStatus.length() > 0) {
			draftStatusInt = Integer.parseInt(draftStatus); 
			if (draftStatusInt == Workspace.WORKFLOWSTATUS_PUBLISHED) {
				util.logger("published status");
			} else if (draftStatusInt == Workspace.WORKFLOWSTATUS_DRAFT) { 
				util.logger("draft status");
			} else if (draftStatusInt == Workspace.WORKFLOWSTATUS_EXPIRED) { 
				util.logger("expired status");
			}
		}

		int total = 0;
		util.logger("rElem: ",returnElements);
		util.logger("siteAreaIds ", siteAreaIds);
		util.logger("context ", contextParam);
		util.logger("from ",dateFrom);
		util.logger("before ", dateTo);			
		if (contentRootParam != null && contentRootParam.length() > 0) {
			this.contentRoot = contentRootParam;
		}
		if (orderByParam != null) {
			this.orderBy = orderByParam;
		}
		if (sortOrderParam != null && sortOrderParam.length() > 0) {
			this.sortOrder = new Boolean(sortOrderParam);
		}
		if (includeAncestorsParam != null && includeAncestorsParam.length() > 0) {
			this.includeAncestors = new Boolean(includeAncestorsParam);
		}
		if (includeDescendantsParam != null && includeDescendantsParam.length() > 0) {
			this.includeDescendants = new Boolean(includeDescendantsParam);
		}
		if (matchAllCatParam != null && matchAllCatParam.length() > 0) {
			this.matchAllCategories = new Boolean(matchAllCatParam);
		}
		if (matchAllKeysParam != null && matchAllKeysParam.length() > 0) {
			this.matchAllKeys= new Boolean(matchAllKeysParam);
		}
		if (matchAllIdsParam != null && matchAllIdsParam.length() > 0) {
			this.matchAllIds= new Boolean(matchAllIdsParam);
		}
		if (includeDescendentCategoriesParam != null && includeDescendentCategoriesParam.length() > 0) {
			this.includeDescendentCategories = new Boolean(includeDescendentCategoriesParam);
		}
		if (rootPageParam != null && rootPageParam.length() > 0) {
			rootPage = rootPageParam;
		} else {
			rootPage = libraryNameParam;
		}
		
		if (libraryNameParam != null && libraryNameParam.length() > 0) {
			libraryName = libraryNameParam;
		}
		if (contextParam != null && contextParam.length() > 0) {
			context = contextParam;
		}
		if (sortByElementParam != null && sortByElementParam.length() > 0) {
			if (isDebug) {System.out.println("use custom sort");}
			sortByElement = sortByElementParam;
		}
		
		// parse multiple site areas
		String[] siteAreaIdsArray = null;
		if (siteAreaIds != null && siteAreaIds.length() > 0) {
			siteAreaIdsArray = siteAreaIds.split(",");
		}
		// parse multiple category Ids
		String[] categoryIdsArray = null;
		if (categoryIds != null && categoryIds.length() > 0) {
			categoryIdsArray = categoryIds.split(",");
		}
		// parse multiple category Ids
		String[] orCategoryIdsArray = null;
		if (orCategoryIds != null && orCategoryIds.length() > 0) {
			orCategoryIdsArray = orCategoryIds.split(",");
		}
		String [] keywordsArray = null;
		if (keywordIds != null && keywordIds.length() > 0) {
			keywordsArray = keywordIds.split(",");
		}
		//parse all props
		String[] propertiesArray = null;
		if (filterByProperties != null && filterByProperties.length() > 0) {
			propertiesArray = filterByProperties.split(",");
		}
		//parse all AT
		String[] atIdArray = null;
		if (authoringTemplateId != null && authoringTemplateId.length() > 0) {
			atIdArray = authoringTemplateId.split(",");
		}
		//parse all AT
		String[] idArray = null;
		if (idParam != null && idParam.length() > 0) {
			idArray = idParam.split(",");
		}
		if (optionMetaParam != null && optionMetaParam.length() > 0) {
			getOptionMeta = true;
		}
		if (fileMetaParam != null && fileMetaParam.length() > 0) {
			getFileMeta = true;
		}
		
		propertiesFilterMap.put("searchTerm", searchTerm);
		propertiesFilterMap.put("draftStatus", draftStatusInt);
		propertiesFilterMap.put("orderBy", this.orderBy);
		propertiesFilterMap.put("sortOrder", this.sortOrder);
		propertiesFilterMap.put("includeAncestors", this.includeAncestors);
		propertiesFilterMap.put("includeDescendants", this.includeDescendants);
		propertiesFilterMap.put("matchAllCategories", this.matchAllCategories);
		propertiesFilterMap.put("matchAllKeys", this.matchAllKeys);
		propertiesFilterMap.put("matchAllIds", this.matchAllIds);
		propertiesFilterMap.put("includeDescendentCategories", this.includeDescendentCategories);
		propertiesFilterMap.put("rootPage", rootPage);
		propertiesFilterMap.put("context", context);
		propertiesFilterMap.put("idArray", idArray);
		propertiesFilterMap.put("name", nameParam);
		propertiesFilterMap.put("creator", creatorParam);
		propertiesFilterMap.put("siteAreaIdsArray", siteAreaIdsArray);
		propertiesFilterMap.put("categoryIdsArray", categoryIdsArray);
		propertiesFilterMap.put("orCategoryIdsArray", orCategoryIdsArray);
		propertiesFilterMap.put("keywordsArray", keywordsArray);
		propertiesFilterMap.put("propertiesArray", propertiesArray);
		propertiesFilterMap.put("atIdArray", atIdArray);
		propertiesFilterMap.put("dateFrom", dateFrom);
		propertiesFilterMap.put("dateTo", dateTo);
		propertiesFilterMap.put("type", type);
		
		////////////////////////////////////// VP ///////////////////////////////////////////////
		if (context != null) {
			util.logger("VP CONTEXT", contextParam);
			// Create the required VirtualPortalContext using the repositorysetd
			VirtualPortalContext vctx;
			try {
				vctx = repository.generateVPContextFromContextPath(context);
				// Create VP Scoped Action object
				util.logger("before entering vp scoped search");
				VPScopedPaginationQuerySearch vpA = new VPScopedPaginationQuerySearch(libraryName,
						propertiesFilterMap, contentRoot, isDebug, methodDebugged, returnElements, 
						dateFormat, resultsPerPage, currentPage);
				repository.executeInVP(vctx, vpA);
				util.logger("after execute");
				contents = (ArrayList) ((ArrayList) vpA.getReturnedValue()).get(0);
				parentSiteAreas = (HashMap) ((ArrayList) vpA.getReturnedValue()).get(1);
				parentSiteAreaNames = (HashMap) ((ArrayList) vpA.getReturnedValue()).get(2);
				paths = (HashMap) ((ArrayList) vpA.getReturnedValue()).get(3);
				allElements = (HashMap) ((ArrayList) vpA.getReturnedValue()).get(4);
				total = (int)((ArrayList) vpA.getReturnedValue()).get(5);
				optionElementMetaMap = (HashMap) ((ArrayList) vpA.getReturnedValue()).get(6);
				fileElementMetaMap = (HashMap) ((ArrayList) vpA.getReturnedValue()).get(7);
				combinedCatIdsForContent = (HashMap) ((ArrayList) vpA.getReturnedValue()).get(8);

			} catch (Exception e) {
				e.printStackTrace();
			}
		} ///////////////////////////////// BASE ////////////////////////////////////////////
		else {
			//do query search for base portal
			//menuSearchForBase(siteAreaIdsArray, categoryIdsArray, draftStatus, 
			//		authoringTemplateId, searchByKeywords, searchTerm);
		}
		
		// process response
		if (contents != null && contents.size() >= 0) { 	
			if (dateFormatParam != null) {
				try {
					// SimpleDateFormat dateFormat2 = new SimpleDateFormat("dd MMMM yyyy", LocaleUtils.toLocale("bg_BG"));
					// System.out.println("testdateformat");
					// System.out.println("df2: " + dateFormat2.format(new Date()));

					this.dateFormat = new SimpleDateFormat(dateFormatParam, Locale.ENGLISH);
				} catch (Exception e) {
				}
			}
			
			// custom sort if such parameter passed from UI
			util.logger("sortByElement", sortByElement);
			if (!sortByElement.equals("")) {
				try {
					contents = customSortContents(sortByElement, contents, showOnlyElementsWithKey, isDebug, this.dateFormat, false);
				} catch (ComponentNotFoundException e) {
					e.printStackTrace();
				}
			}
			
			//do additional filtration based on secondary criteria (ex: GDO)
			if (secondaryFilterParam != null && secondaryFilterParam.length() > 0) {
				secondaryFilter = secondaryFilterParam;				
			} 
			if (secondaryFilter != null) {
				contents = secondaryFiltration(contents, secondaryFilter, secondaryFrom, secondaryTo, orCategoryIdsArray, combinedCatIdsForContent);
			}
			
			try {
				this.returnQueryResult(request, response, libraryName, contents, 
						searchTerm, currentUrl, returnProperties, 
						returnElements, parentSiteAreas, parentSiteAreaNames, paths, userCache, draftStatusInt, 
						isDateCapital, context, allElements, optionElementMetaMap, fileElementMetaMap, this.dateFormat, 
						rootPage, lastModifiedDate, total, getOptionMeta, getFileMeta);
				util.logger("-------------------------");
				util.logger("timeElapsed=", ((float)((System.currentTimeMillis() - start)) / 1000) + " seconds");
				util.logger("-------------------------");
				return;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private ArrayList<Content> secondaryFiltration(ArrayList<Content> contents, String secondaryFilterCriteria, String from, String to, 
			String [] orCategoryIdsArray, HashMap<DocumentId, ArrayList<String>> combinedCatIdsForContent) {
		ArrayList<Content> filteredContents = new ArrayList<Content>();
		util.logger("secondaryFilterCriteria",secondaryFilterCriteria);
		Date dateFrom = null;
		Date dateTo = null;
		if (secondaryFilterCriteria.equals("generalDateOne")) {
			util.logger("secondaryFiltration generalDateOne");
			
			for (int i = 0; i < contents.size(); i++) {
				//if 2ndary from and to not supplied, add result by default to original query result
				if ((from == null || from.length() == 0) && (to == null || to.length() == 0)) {
					util.logger("no date ssupplied");
					filteredContents.add(contents.get(i));
					continue;
				}
				try {
					if (from != null && from.length() > 0) {
						dateFrom = dateFormat.parse(from);
						util.logger("dateFrom", dateFrom.getTime());
						util.logger("content time", contents.get(i).getGeneralDateOne().getTime());
						if (contents.get(i).getGeneralDateOne().getTime() < dateFrom.getTime()) {
							continue;
						} 
					} else {
						continue;
					}
					if (to != null && to.length() > 0) { 
						dateTo = dateFormat.parse(to);
						util.logger("dateTo", dateTo.getTime());
						util.logger("content time", contents.get(i).getGeneralDateOne().getTime());
						if (contents.get(i).getGeneralDateOne().getTime() > dateTo.getTime()) {
							continue;
						} 
					} else {
						continue;
					}
					filteredContents.add(contents.get(i));
					
				} catch (ParseException e) {
					e.printStackTrace();
				} catch (PropertyRetrievalException e) {
					e.printStackTrace();
				}
			}
		}
		//specific case for NRA -> compare dates only. Send number of date as param, not entire date
		//use the two month categories if current Month And date from > / if nextMonth And date < from 
		else if (secondaryFilterCriteria.equals("GDODateNumber")) {
			util.logger("secondaryFiltration GDODateNumber size of primary filtration", contents.size());
			Calendar cal = Calendar.getInstance();
			int dateFromParam = 0;
			int dateContent = 0;
			String currentMonthCat = "";
			String nextMonthCat = "";
			Content tmpContent = null;
			Date gdoTmpDate = null;
			DocumentId [] combinedCategories = null; 
			HashMap <DocumentId, String> tmpCombinedCatMap = null;
			ArrayList<String> tmpCatList = null;
			String tmpCat = "";
			
			for (int i = 0; i < contents.size(); i++) { 
				//if from and to not set, do not do any filtering. If orCatId not set, don't filter anything as well
				tmpContent = contents.get(i);
				boolean hasCurrentMonth = false;
				boolean hasNextMonth = false;
				util.logger("secondaryFiltration title", tmpContent.getTitle());
				if ((from == null || from.length() == 0) && (orCategoryIdsArray == null || orCategoryIdsArray.length == 0)) { 
					filteredContents.add(tmpContent);
					continue;
				}
				if (orCategoryIdsArray.length >= 2) {
					currentMonthCat = orCategoryIdsArray[0];
					nextMonthCat = orCategoryIdsArray[1];
				}
				//if date number is inside supplied from and to, add result
				try {
					if (from != null && from.length() > 0) {					
						dateFromParam = Integer.parseInt(from);
						gdoTmpDate = tmpContent.getGeneralDateOne();
						//if date not set, include in result
						util.logger("gdoTmpDate", gdoTmpDate);
						if (gdoTmpDate != null) {
							cal.setTime(gdoTmpDate);
						} 
						
						dateContent = cal.get(Calendar.DAY_OF_MONTH);
						util.logger("dateFromParam", dateFromParam + "");
						util.logger("dateContent", dateContent + "");
						
						//if in current month date must be after from, if next month, date must be before from
						tmpCatList = combinedCatIdsForContent.get(tmpContent.getId());
						for (int j = 0; j < tmpCatList.size(); j++) {
							tmpCat = tmpCatList.get(j);
							util.logger("categoriesMap tmpCat", tmpCat);
							if (currentMonthCat.equals(tmpCat)) {
								util.logger("hasCurrentMonth");
								hasCurrentMonth = true;
							} if(nextMonthCat.equals(tmpCat)) {
								util.logger("hasNextMonth");
								hasNextMonth = true;
							}
						}
						//if content has both current and next month
						if (hasCurrentMonth && !hasNextMonth &&  dateContent < dateFromParam) {
							continue;//dont put in result
						} if (hasNextMonth && !hasCurrentMonth && dateContent > dateFromParam) {
							continue;
						}
					} else {
						continue;
					}
					util.logger("add ", tmpContent.getTitle());
					filteredContents.add(tmpContent);
					
				} catch (PropertyRetrievalException e) {
					util.logger("gdoretrievalException");
					e.printStackTrace();
					filteredContents.add(tmpContent);
				}
			}
		}
		util.logger("secondaryFiltration len of filtered res", filteredContents.size());
		return filteredContents;
	}
	
	/**
	 * @param request
	 * @param response
	 * @param libraryName
	 * @param contents
	 * @param searchTerm
	 * @param currentUrl
	 * @param returnProperties
	 * @param returnElements
	 * @param parentSiteAreas
	 * @param parentSiteAreaNames
	 * @param paths
	 * @param userCache
	 * @param draftStatusInt
	 * @param isDateCapital
	 * @param context
	 * @param allElements
	 * @param optionElementMetaMap
	 * @param fileElementMetaMap
	 * @param dateFormat
	 * @param rootPage
	 * @param lastModifiedDate
	 * @param total
	 * @param getOptionMeta
	 * @param getFileMeta
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void returnQueryResult(HttpServletRequest request, HttpServletResponse response, String libraryName, 
			ArrayList<Content> contents, String searchTerm, String currentUrl, String returnProperties, String returnElements,
			HashMap<DocumentId, String> parentSiteAreas, HashMap<DocumentId, String> parentSiteAreaNames, 
			HashMap<DocumentId, String> paths, boolean userCache, int draftStatusInt, boolean isDateCapital, 
			String context, HashMap<DocumentId, HashMap> allElements, HashMap<DocumentId,
			HashMap<String, HashMap<String, HashMap<String, String>>>> optionElementMetaMap,
			HashMap<DocumentId, HashMap<String,HashMap<String,String>>> fileElementMetaMap, SimpleDateFormat dateFormat, String rootPage, 
			String lastModifiedDate, int total, boolean getOptionMeta, boolean getFileMeta) throws Exception {

		int jsonCounter = 0;
		JSONObject tmpJsonObj = null;
		JSONObject jsonContent = null;
		JSONObject tmpJsonCatObj = null;
		JSONObject json = new JSONObject();
		JSONArray jsonArr = new JSONArray();
		JSONArray jsonCategoryArr = new JSONArray();

		String id = "";
		DocumentId docId = null;
		String title = "";
		String contentUrl = "";
		String originUrl = currentUrl;
		String label = "";
		String author = "";
		String description = "";
		Date tmpDate = null;
		String formattedDate = "";
		String[] properties = null;
		String[] elements = null;
		String component = "";
		util.logger("originUrl", originUrl);

		// json objects
		Double d = new Double(total);
		Integer numPages = WCMQuerySearch.getNumberOfPages(d, resultsPerPage);
		
		json.put("numberOfPages", new String(numPages.toString()));
		json.put("numberOfResults", new String(((Integer) contents.size()).toString())); // egov municipalities
		json.put("numberOfAllResults", new String(((Integer) total).toString())); // egov municipalities
		json.put("timeInSeconds", new String(((Float) ((float)(System.currentTimeMillis() - start) / 1000)).toString()));
		util.logger("SIZE of result", contents.size());
		jsonArr.add(jsonCounter++, json);

		String contentName = "";
		DocumentId parentId = null;
		String parentSiteAreaName = "";
		String categoryNameKey = "";
		Content currentContent = null;
		HashMap <String, HashMap<String, HashMap<String, String>>> optionElementMeta = new HashMap <>();
		HashMap <String, HashMap<String, String>> categoryMetaMap = new HashMap <>();
		HashMap<String, String> tmpOptionMetaFieldsMap = new HashMap<>();
		HashMap <String, HashMap<String, String>> fileElementMeta = new HashMap <>();
		HashMap<String, String> tmpFileMetaFieldsMap = new HashMap<>();
		

		for (int i = 0; i < contents.size(); i++) {
			// properties always sent to client			
			currentContent = (Content)contents.get(i); 
			docId = currentContent.getId();
			id = docId.getID();
			title = currentContent.getTitle();
			contentName = currentContent.getName();
			parentId = currentContent.getParentId();
			parentSiteAreaName = parentId.getName();
			util.logger("parentSA", parentSiteAreaName);
			util.logger("origin URL", contentUrl);
				
			//contents are accessed differently on a vp contextual portal, which are often used in development
			if (VPCONTEXT_FLAG) {
				util.logger("VP CONTEXTUAL PORTAL!!!");
				util.logger("prod flag: " + this.PRODUCTION_FLAG);
				// dev url longer
				if (this.PRODUCTION_FLAG) {
					contentUrl = originUrl.substring(0, originUrl.indexOf("portal/") + 7) +  rootPage + "/";
				} else {
					contentUrl = originUrl.substring(0, originUrl.indexOf("portal/") + 7) + context + "/" + rootPage + "/";
				}
			} 
			else {
				contentUrl = originUrl.substring(0, originUrl.indexOf("portal/") + 7) +  rootPage + "/";
			}
			util.logger("paths", paths.get(contents.get(i).getId()));
			contentUrl += paths.get(contents.get(i).getId()) + contentName;
			contentUrl.replaceAll(" ", "%20");
			util.logger("new URL", contentUrl);
			
			tmpJsonObj = new JSONObject();
			jsonContent = new JSONObject();

			// id
			tmpJsonObj = new JSONObject();
			tmpJsonObj.put("id", id);
			jsonContent.put("content", tmpJsonObj);
			// title
			tmpJsonObj = new JSONObject();
			tmpJsonObj.put("title", title);
			jsonContent.put("contentTitle", tmpJsonObj);
			// url
			// System.out.println("contentName: " + contentName);
			tmpJsonObj = new JSONObject();
			tmpJsonObj.put("url", contentUrl);
			jsonContent.put("contentUrl", tmpJsonObj);

			tmpJsonObj = new JSONObject();
			tmpJsonObj.put("name", ((Content) contents.get(i)).getId().getName());
			jsonContent.put("contentName", tmpJsonObj);

			// properties on demand
			if (returnProperties != null) {
				properties = returnProperties.split(",");
				for (int j = 0; j < properties.length; j++) {
					tmpDate = null;
					if (properties[j].equals("author")) {
						author = currentContent.getCreator();
						util.logger("creator ", author);
						// author
						tmpJsonObj = new JSONObject();
						tmpJsonObj.put("author", author);
						jsonContent.put("contentAuthor", tmpJsonObj);

					} else if (properties[j].equals("publishDate")) {						
						try {							
							tmpDate = currentContent.getEffectiveDate();
						} catch (PropertyRetrievalException e) {
							System.out.println("get Effective date exception... trying to get the publish date instead...err:" 
									+ e.getMessage());
							try {
								if (currentContent.isPublished()) {
									tmpDate = currentContent.getPublishedDate();
								}
							} catch (Exception e2) {
								System.out.println("Error getting publish date... err:" + e2.getMessage());
							}
						}																	
						if (tmpDate == null) {
							tmpDate = currentContent.getCreationDate();
						}						
						
						formattedDate = dateFormat.format(tmpDate);
						//?
						if (isDateCapital) {
							formattedDate = formattedDate.toUpperCase();
						}
						util.logger("publish date ", formattedDate);
						// publishDate
						tmpJsonObj = new JSONObject();
						tmpJsonObj.put("publishDate", formattedDate);
						jsonContent.put("contentDate", tmpJsonObj);
					} else if (properties[j].equals("lastModifiedDate")) {						
						try {
							tmpDate = currentContent.getModifiedDate();
						} catch (Exception e) {
							System.out.println("getModifiedDate date exception");		
						}
						if (tmpDate == null) {
							tmpDate = currentContent.getCreationDate();
						}
						util.logger(tmpDate.toString());
						formattedDate = dateFormat.format(tmpDate);
						if (isDateCapital) {
							formattedDate = formattedDate.toUpperCase();
						}
						util.logger("last modified date " + formattedDate);
						// publishDate
						tmpJsonObj = new JSONObject();
						tmpJsonObj.put("lastModifiedDate", formattedDate);
						jsonContent.put("contentLastModifiedDate", tmpJsonObj);
					} else if (properties[j].equals("parentSA")) {
						// label
						label = parentSiteAreas.get(contents.get(i).getId());
						tmpJsonObj = new JSONObject();
						tmpJsonObj.put("label", label);
						jsonContent.put("contentLabel", tmpJsonObj);
					} else if (properties[j].equals("parentSAName")) {
						// label
						//parentSiteAreaName = parentSiteAreaNames.get(filteredContents.get(i).getId());
						tmpJsonObj = new JSONObject();
						tmpJsonObj.put("parentSAName", parentSiteAreaName);
						jsonContent.put("contentParentSAName", tmpJsonObj);
					} else if (properties[j].equals("description")) {
						description = currentContent.getDescription();
						tmpJsonObj = new JSONObject();
						tmpJsonObj.put("description", description);
						jsonContent.put("contentDescription", tmpJsonObj);
					} else if (properties[j].equals("generalDateOne")) {
						util.logger("return GDOne");
						try { 
							tmpDate = currentContent.getGeneralDateOne();
							util.logger("getGeneralDateOne", tmpDate);
						} catch (Exception e) {
							util.logger("exception getting generaldateone");
						}
						if (tmpDate != null) {
							formattedDate = dateFormat.format(tmpDate);
							if (isDateCapital) {
								formattedDate = formattedDate.toUpperCase();
							}
							tmpJsonObj = new JSONObject();
							tmpJsonObj.put("generalDateOne", formattedDate);
							jsonContent.put("contentGeneralDateOne", tmpJsonObj);
						}
					} else if (properties[j].equals("generalDateTwo")) {
						try { 
							tmpDate = currentContent.getGeneralDateTwo();
						} catch (Exception e) {}
						if (tmpDate != null) {
							formattedDate = dateFormat.format(tmpDate);
							if (isDateCapital) {
								formattedDate = formattedDate.toUpperCase();
							}
							tmpJsonObj = new JSONObject();
							tmpJsonObj.put("generalDateTwo", formattedDate);
							jsonContent.put("contentGeneralDateTwo", tmpJsonObj);
						}
					}
				}
			}

			// fill elements
			if (returnElements != null) {
				elements = returnElements.split(",");
				String newElement = "";
				HashMap <String, String> element = new HashMap <>();
				
				element = allElements.get(docId);
				util.logger("docId ",docId);
				
				//getOption meta data for content
				if (getOptionMeta && optionElementMetaMap != null && optionElementMetaMap.size() > 0) {
					optionElementMeta = optionElementMetaMap.get(docId);
					if (optionElementMeta != null) {
						util.logger("optionElementMeta size of elements", optionElementMeta.size());
					}
				}
				
				//getFile meta data for file elements if any
				if (getFileMeta && fileElementMetaMap != null && fileElementMetaMap.size() > 0) {
					fileElementMeta = fileElementMetaMap.get(docId);					
				}
				
				for (int j = 0; j < elements.length; j++) {
					if (context == null) {
						component = this.getContentElement((Content) contents.get(i), elements[j], dateFormat);
					} else {
						//get elements from result of vp c. search
						component = element.get(elements[j]);
						//component contains mao with key name of element and value another map
						if (optionElementMeta != null && optionElementMeta.get(elements[j]) != null) {							
							util.logger("populate meta data in json for option elem", elements[j]);
							//returns map with category info for this element
							categoryMetaMap = optionElementMeta.get(elements[j]);
							int categoryCounter = 0;
							jsonCategoryArr = new JSONArray();
							for(Map.Entry<String, HashMap<String, String>> optionSelectionMetaMap : 
								categoryMetaMap.entrySet()) {
								tmpOptionMetaFieldsMap = optionSelectionMetaMap.getValue();
								//util.logger("test id", tmpOptionMetaFieldsMap.get("id"));
								//util.logger("test title", tmpOptionMetaFieldsMap.get("title"));
								//util.logger("test name", tmpOptionMetaFieldsMap.get("name"));
								tmpJsonObj = new JSONObject();
								if (elements[j].contains("-")) {
									newElement = elements[j].replaceAll("-", "");
									tmpJsonObj.put(newElement + "_id", tmpOptionMetaFieldsMap.get("id"));
									tmpJsonObj.put(newElement + "_name", tmpOptionMetaFieldsMap.get("name"));
									tmpJsonObj.put(newElement + "_title", tmpOptionMetaFieldsMap.get("title"));
									jsonCategoryArr.add(categoryCounter++, tmpJsonObj);
								} else if (elements[j].contains(" ")) {
									newElement = elements[j].replaceAll(" ", "");
									tmpJsonObj.put(newElement + "_id", tmpOptionMetaFieldsMap.get("id"));
									tmpJsonObj.put(newElement + "_name", tmpOptionMetaFieldsMap.get("name"));
									tmpJsonObj.put(newElement + "_title", tmpOptionMetaFieldsMap.get("title"));
									jsonCategoryArr.add(categoryCounter++, tmpJsonObj);
								} else {
									newElement = elements[j];
									tmpJsonObj.put(elements[j] + "_id", tmpOptionMetaFieldsMap.get("id"));
									tmpJsonObj.put(elements[j] + "_name", tmpOptionMetaFieldsMap.get("name"));
									tmpJsonObj.put(elements[j] + "_title", tmpOptionMetaFieldsMap.get("title"));
									jsonCategoryArr.add(categoryCounter++, tmpJsonObj);
								}
							}
							jsonContent.put("content" + newElement + "_option", jsonCategoryArr);
							
						}
						if (fileElementMeta != null && fileElementMeta.get(elements[j]) != null) {
							//util.logger("populate meta data in json for file elem", elements[j]);
							
							tmpJsonObj = new JSONObject();
							tmpFileMetaFieldsMap = fileElementMeta.get(elements[j]);
							if (elements[j].contains("-")) {
								newElement = elements[j].replaceAll("-", "");
								tmpJsonObj.put(newElement + "_size", tmpFileMetaFieldsMap.get("size"));
								tmpJsonObj.put(newElement + "_mimetype", tmpFileMetaFieldsMap.get("mimetype"));
								jsonContent.put("content" + newElement + "_file", tmpJsonObj);
								
							} else if (elements[j].contains(" ")) {
								newElement = elements[j].replaceAll(" ", "");
								tmpJsonObj.put(newElement + "_size", tmpFileMetaFieldsMap.get("size"));
								tmpJsonObj.put(newElement + "_name", tmpFileMetaFieldsMap.get("mimetype"));
								jsonContent.put("content" + newElement + "_file", tmpJsonObj);
								
							} else {
								tmpJsonObj.put(elements[j] + "_size", tmpFileMetaFieldsMap.get("size"));
								tmpJsonObj.put(elements[j] + "_name", tmpFileMetaFieldsMap.get("mimetype"));
								jsonContent.put("content" + elements[j] + "_file", tmpJsonObj);
							}
						}
						
					}
					tmpJsonObj = new JSONObject();
					if (elements[j].contains("-")) {
						newElement = elements[j].replaceAll("-", "");
						tmpJsonObj.put(newElement, component);
						jsonContent.put("content" + newElement, tmpJsonObj);
					} else if (elements[j].contains(" ")) { //fix for Cveti's AT names
						newElement = elements[j].replaceAll(" ", "");
						tmpJsonObj.put(newElement, component);
						jsonContent.put("content" + newElement, tmpJsonObj);
					} else {
						tmpJsonObj.put(elements[j], component);
						jsonContent.put("content" + elements[j], tmpJsonObj);
					}
				}
			}
			
			
			// result ready to be added
			jsonArr.add(jsonCounter++, jsonContent);
		}

		if (currentPage == 1 && userCache == true) {//
			jsonArr.add(getAllTitlesAndUrls(contents, originUrl));
		}
		
		// util.logger("response: ", jsonArr);		
		response.getWriter().write(jsonArr.toString());
		response.getWriter().flush();
		response.getWriter().close();
		
	}
	
	public static JSONArray getAllTitlesAndUrls(ArrayList<Content> contents, String originUrl) {
		JSONObject jsonAutocompleteTitle = null;
		JSONObject jsonAutocompleteUrl = null;
		JSONObject jsonAutocomplete = null;
		JSONArray jsonAutocompleteArr = new JSONArray();

		// put all urls and titles for autocomplete in json
		for (int i = 0; i < contents.size(); i++) {
			jsonAutocompleteTitle = new JSONObject();
			jsonAutocompleteTitle.put("title", ((Content) contents.get(i)).getTitle());
			jsonAutocompleteUrl = new JSONObject();
			jsonAutocompleteUrl.put("url", originUrl + ((Content) contents.get(i)).getName());
			jsonAutocomplete = new JSONObject();
			jsonAutocomplete.put("autocompleteTitle", jsonAutocompleteTitle);
			jsonAutocomplete.put("autocompleteUrl", jsonAutocompleteUrl);
			jsonAutocompleteArr.add(i, jsonAutocomplete);
		}
		return jsonAutocompleteArr;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private String getContentElement(Content content, String componentName, SimpleDateFormat dateFormat) throws Exception {
		ContentComponent contentComponent = null;
		if (content.hasComponent(componentName)) {
			contentComponent = content.getComponentByReference(componentName);
		} else {
			util.logger("No such component", componentName);
		}
		if (contentComponent == null) return "";
		if (contentComponent instanceof RichTextComponent) {
			//System.out.println("richtextcomponent");
			RichTextComponent component = (RichTextComponent) contentComponent;
			return component.getRichText().toString();
		} else if (contentComponent instanceof ShortTextComponent) {
			//System.out.println("shorttextcomponent");
			ShortTextComponent component = (ShortTextComponent) contentComponent;
			//System.out.println("short: " + component.getName());
			//System.out.println("short2: " + component.getText());
			return component.getText();
		} else if (contentComponent instanceof TextComponent) {
			//System.out.println("textcomponent");
			TextComponent component = (TextComponent) contentComponent;
			return component.getText();
		} else if (contentComponent instanceof NumericComponent) {
			//System.out.println("numericcomponent");
			NumericComponent component = (NumericComponent) contentComponent;
			return component.getNumber().toString();
		} else if (contentComponent instanceof ImageComponent) {
			//System.out.println("imagecomponent");
			ImageComponent component = (ImageComponent) contentComponent;
			return component.getResourceURL();
		} else if (contentComponent instanceof FileComponent) {
			//System.out.println("filecomponent");
			FileComponent component = (FileComponent) contentComponent;
			return component.getResourceURL();
		} else if (contentComponent instanceof LinkComponent) {
			LinkComponent component = (LinkComponent) contentComponent;
			return component.getLinkText();
		} else if (contentComponent instanceof DateComponent) {
			//System.out.println("imagecomponent");
			DateComponent component = (DateComponent) contentComponent;
			if (component.getDate() != null) {			
				DateFormat inputFormat = new SimpleDateFormat("EEE MMM dd hh:hh:ss zzzz yyyy");
				Date date = inputFormat.parse(component.getDate().toString());				
				String dateString = dateFormat.format(date);
				util.logger("dateComponent formated: ", dateString );
				return dateString;
			} else {
				util.logger("dateComponent empty");
				return "";
			}
			
		} else if (contentComponent instanceof OptionSelectionComponent) {
			util.logger("optionselectioncomponent");		
			//cant get categories ouside of VP context in case of VP
						
			OptionSelectionComponent component = (OptionSelectionComponent) contentComponent;
			DocumentId [] selections = null;
			try {
				selections = component.getCategorySelections();
			} catch (Exception e) {
				System.out.println(e.getMessage());
				e.printStackTrace();							
			}
					
			if (selections != null) {
				util.logger("SELECTION", selections.length);
				String result = "";			
				Document doc = null;
				for (int i = 0; i < selections.length; i++) {
					doc = workspace.getById(selections[i]);
					if (selections.length > 1) {
						result = doc.getTitle() + ",";					
					} else {
						result = doc.getTitle();					
					}
					util.logger("selections", result);			
				}
				return result;	
			}							
		} 			
		return "";	
	}

	public static int getNumberOfPages(Double resultSize, int resultsPerPage) {
		if (resultSize <= resultsPerPage) {
			return 1;
		} else {
			Double d = new Double(Math.ceil(resultSize / resultsPerPage));
			return d.intValue();
		}
	}
	
	//custom sort, reordering the whole array and passing the key to be sorted by
	public static ArrayList<Content> customSortContents(String sortByElement, ArrayList<Content> contents, boolean showOnlyElementsWithKey, boolean isDebug,
			SimpleDateFormat dateFormat, boolean customSortReverse) throws ComponentNotFoundException {
		if (isDebug) { System.out.println("inside customsort "); }
		HashMap<Long, ArrayList<Content>> contentsHm = new HashMap<>();		 
		ArrayList<Content> tmpContents = new ArrayList<Content>();				
		ContentComponent contentComponent = null;
		Content tmpContent = null;		
		ArrayList<Content> singleElement = new ArrayList<Content>();
		ArrayList<Content> zeroKeyElements = new ArrayList<Content>();
		Long sortKey = 0l;
		Long tempSortKey = 0l;		
		ArrayList <Long> sortKeys = new ArrayList<Long>();
		
		for (int i = 0; i < contents.size(); i++) {
			//if (isDebug) { System.out.println("contents size: " + contents.size()); }
			//get element and store type of sort key
			tmpContent = contents.get(i);			
			if (tmpContent.hasComponent(sortByElement)) {
				contentComponent = contents.get(i).getComponentByReference(sortByElement);
			}
			//represent all types of keys as strings
			if (contentComponent instanceof DateComponent) {		
				DateComponent component = (DateComponent) contentComponent;					
				if (component.getDate() != null) {					
					sortKey = component.getDate().getTime();
					System.out.println("sortKey date " + i + "-th iteration " + sortKey);
					if (!sortKeys.contains(sortKey) && sortKey != 0l) {
						if(isDebug) {System.out.println("list doesnt contain sortkey");}
						sortKeys.add(sortKey);
					}					
				}			
				
			} else if (contentComponent instanceof NumericComponent) {
				NumericComponent component = (NumericComponent) contentComponent;				
				if (!component.toString().equals("")) {
					sortKey = component.getNumber().longValue();
					if (!sortKeys.contains(sortKey) && sortKey != 0l) {						
						sortKeys.add(sortKey);
					}
				}
				
			} else {
				if (isDebug) { System.out.println("custom sort text ?: ");}
				//sortKey = ""; no real world scenarios requiring sort by random text element ?
				sortKeys.add(sortKey);
			}
			
			if (customSortReverse) {
				Collections.sort(sortKeys, Collections.reverseOrder());
			} else {
				Collections.sort(sortKeys);
			}			
			
			//generate hashmap of all keys and content pairs
			
			if (isDebug) { System.out.println("sortKey: " + sortKey); }
			if (sortKey != null && sortKey != 0) { 
				if(isDebug) {System.out.println("content pair " + sortKey + ", " + tempSortKey);}
				
				if (tempSortKey.compareTo(sortKey) == 0) { //add another entry for the same key
					singleElement.add(tmpContent);
					if(isDebug) { System.out.println("addd"); }
				} else {
					if(isDebug) { System.out.println("addd new"); }
					singleElement = new ArrayList<Content>();//create new list for the next key, then add entry
					singleElement.add(tmpContent);
				}
				tempSortKey = sortKey;
				contentsHm.put(sortKey, singleElement);
			}			
			//reset sortKey
			//sortKey = 0l;
			//save the contents with no sortkey in separate list, so that they can be added to result if showElementsWith key is false
			if (sortKey == 0 && !showOnlyElementsWithKey) {
				if (isDebug) { System.out.println("sortkey zero");}
				zeroKeyElements.add(tmpContent);
			}
		}
		
		//iterate over sortKeys to populate an  arraylist for each sortKey		
		
		if (isDebug) {System.out.println("contentsHm: " + contentsHm.size());}
		
		//if no keys are set, just iterate result set
		if (sortKeys.size() == 0) {
			return contents;
		} else {
			//clear all order provided by menu sort and do custom sort, iterate over sorted key set
			contents = new ArrayList<>();
			for (int i = 0; i < sortKeys.size(); i++) {
				if (isDebug) { System.out.println("iterate sorted keyset: " + sortKeys.get(i)); }
				tmpContents = contentsHm.get(sortKeys.get(i));
				if(isDebug) {  System.out.println("tmpContents size on each key: " + tmpContents.size());}
				if (tmpContents != null && tmpContents.size() > 0) {
					for (int j = 0; j < tmpContents.size(); j++) {	
						if(isDebug) { System.out.println("inner loop'"); }
						/*if (showOnlyElementsWithKey) {
							if (isDebug) { System.out.println("showOnlyElementsWithKey"); }
							if(sortKeys.get(i) == 0l) { //add results with zero key ?
								if (isDebug) { System.out.println("sort key not set"); }
								//contents.add(tmpContents.get(j));
							} else {
								contents.add(tmpContents.get(j));	
							}
						} else {
							contents.add(tmpContents.get(j));	
						} */
						contents.add(tmpContents.get(j));	
					}
				}			
			}
			if (!showOnlyElementsWithKey) {
				for (int i = 0; i < zeroKeyElements.size(); i++) {
					if (isDebug) {System.out.println("element with no key: " + zeroKeyElements.get(i).getTitle());}
					contents.add(zeroKeyElements.get(i));
				}
			}
		}
		return contents;
	}
	
	public String getTypeOfElement(ArrayList<Content> contents, String sortByElement, boolean isDebug) throws ComponentNotFoundException {
		//get element and store type of sort key
		Content tmpContent = null;
		ContentComponent contentComponent = null;
		for (int i = 0; i < contents.size(); i++) { 			
			tmpContent = contents.get(i);			 
			contentComponent = null;
			if (tmpContent.hasComponent(sortByElement)) {
				contentComponent = contents.get(i).getComponentByReference(sortByElement);
			}
			if (contentComponent == null) continue;
			//only date and numeric components will be represented as long, else string
			if (contentComponent instanceof DateComponent) {		
				DateComponent component = (DateComponent) contentComponent;				
				if (!component.toString().equals("")) {
					return "long";
				}				
				
			} else if (contentComponent instanceof NumericComponent) {
				NumericComponent component = (NumericComponent) contentComponent;
				util.logger("custom sort number: " + component.toString());
				if (!component.toString().equals("")) {					
					return "long";
				}
				
			} else {				
				return "string";
			}
		}
		return "";
	}
	

}
