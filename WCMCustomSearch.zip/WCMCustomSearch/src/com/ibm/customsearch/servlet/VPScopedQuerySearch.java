package com.ibm.customsearch.servlet;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;

import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.ContentComponent;
import com.ibm.workplace.wcm.api.DateComponent;
import com.ibm.workplace.wcm.api.Document;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentLibrary;
import com.ibm.workplace.wcm.api.FileComponent;
import com.ibm.workplace.wcm.api.ImageComponent;
import com.ibm.workplace.wcm.api.LinkComponent;
import com.ibm.workplace.wcm.api.NumericComponent;
import com.ibm.workplace.wcm.api.OptionSelectionComponent;
import com.ibm.workplace.wcm.api.OptionType;
import com.ibm.workplace.wcm.api.Repository;
import com.ibm.workplace.wcm.api.RichTextComponent;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.SiteArea;
import com.ibm.workplace.wcm.api.TextComponent;
import com.ibm.workplace.wcm.api.VirtualPortalScopedAction;
import com.ibm.workplace.wcm.api.WCM_API;
import com.ibm.workplace.wcm.api.Workspace;
import com.ibm.workplace.wcm.api.exceptions.AuthorizationException;
import com.ibm.workplace.wcm.api.exceptions.ComponentNotFoundException;
import com.ibm.workplace.wcm.api.exceptions.DocumentIdCreationException;
import com.ibm.workplace.wcm.api.exceptions.DocumentRetrievalException;
import com.ibm.workplace.wcm.api.exceptions.OperationFailedException;
import com.ibm.workplace.wcm.api.exceptions.QueryServiceException;
import com.ibm.workplace.wcm.api.exceptions.WCMException;
import com.ibm.workplace.wcm.api.query.Disjunction;
import com.ibm.workplace.wcm.api.query.PageIterator;
import com.ibm.workplace.wcm.api.query.Query;
import com.ibm.workplace.wcm.api.query.QueryDepth;
import com.ibm.workplace.wcm.api.query.QueryStructureException;
import com.ibm.workplace.wcm.api.query.ResultIterator;
import com.ibm.workplace.wcm.api.query.Selectors;
import com.ibm.workplace.wcm.api.query.SortDirection;
import com.ibm.workplace.wcm.api.query.Sorts;
import com.ibm.workplace.wcm.api.query.WorkflowSelectors;

public class VPScopedQuerySearch implements VirtualPortalScopedAction {

	private ArrayList<Content> contents = null;
	@SuppressWarnings("rawtypes")
	private HashMap<DocumentId, String> parentSiteAreas = null;
	@SuppressWarnings("rawtypes")
	private HashMap<DocumentId, String> parentSiteAreaNames = null;
	@SuppressWarnings("rawtypes")
	private HashMap<DocumentId, String> paths = null;
	@SuppressWarnings("rawtypes")
	private HashMap<DocumentId, HashMap> allElements = null;
	private int total = 0;
	private HashMap<String, String> element = null;
	private ArrayList<Object> returnedValues = null;
	private String libraryName = null;
	private String contentRoot = "site";
	private String[] siteAreaIds = null;
	private String authoringTemplateIds;
	private String[] categories;
	private String orderBy = Workspace.SORT_KEY_TITLE;
	private boolean sortOrder = true;
	private int draftStatus = Workspace.WORKFLOWSTATUS_PUBLISHED;
	private boolean isDebug = false;
	private String returnElements = "";
	private SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.ENGLISH);
	private String dateStringFrom = "";
	private String dateStringTo = "";
	private int resultsPerPage = 10;
	private int currentPage = 1;
	private String searchTerm = null;
	private static Repository repository = null;
	public static Workspace workspace = null;

	public ArrayList<Object> getReturnedValue() {
		returnedValues = new ArrayList<Object>();
		returnedValues.add(contents);
		returnedValues.add(parentSiteAreas);
		returnedValues.add(parentSiteAreaNames);
		returnedValues.add(paths);
		returnedValues.add(allElements);
		returnedValues.add(total);
		return returnedValues;
	}

	// public constructor
	public VPScopedQuerySearch(String libraryName, String contentRoot, String[] siteAreaIds, String authoringTemplateIds,
			String[] categories, String orderBy, boolean sortOrder, int draftStatus, boolean isDebug, String elements,
			SimpleDateFormat dateFormat, String dateStringFrom, String dateStringTo, int resultsPerPage,
			int currentPage, String searchTerm) {
		this.libraryName = libraryName;
		this.contentRoot = contentRoot;
		this.siteAreaIds = siteAreaIds;
		this.authoringTemplateIds = authoringTemplateIds;
		this.categories = categories;
		this.orderBy = orderBy;
		this.sortOrder = sortOrder;
		this.draftStatus = draftStatus;
		this.isDebug = isDebug;
		this.returnElements = elements;
		this.dateFormat = dateFormat;
		this.dateStringFrom = dateStringFrom;
		this.dateStringTo = dateStringTo;
		this.resultsPerPage = resultsPerPage;
		this.currentPage = currentPage;
		this.searchTerm = searchTerm;
	}

	@SuppressWarnings({ "rawtypes" })
	@Override
	public void run() throws WCMException {

		repository = WCM_API.getRepository();
		workspace = repository.getSystemWorkspace();
		workspace.login();
		DocumentLibrary docLib = workspace.getDocumentLibrary(libraryName);
		workspace.setCurrentDocumentLibrary(docLib);
		DocumentId doc = null;
		String label = null;
		String parentName = null;
		String parentSAName = null;
		DocumentId parentDoc = null;
		DocumentId tempDoc = null;
		DocumentId[] authTempIds = null;
		String path = "";
		if (isDebug) {
			System.out.println("inside VPSCOPED ACTION");
		}

		contents = new ArrayList<Content>();
		DocumentId[] siteAreaDocIdArray = null;
		DocumentId[] categoryIdsArray = null;

		try {
			// fill category
			if (categories != null && categories.length > 0) {
				if (isDebug) {
					System.out.println("has categories [" + categories.length + "]");
				}
				categoryIdsArray = new DocumentId[categories.length];
				DocumentId categoryId = null;
				for (int i = 0; i < categories.length; i++) {
					// fill each saID into new doc id, then add to array
					if (isDebug) {
						System.out.println("category id : " + categories[i]);
					}
					try {
						categoryId = workspace.createDocumentId(categories[i]);
						if (isDebug) {
							System.out.println("category name: " + categoryId.getName());
						}
						categoryIdsArray[i] = categoryId;
					} catch (Exception e) {
						System.out.println("ERR_MESSAGE: " + e.getMessage());
						e.printStackTrace();
					}

				}
			}
			if (authoringTemplateIds != null && authoringTemplateIds.trim().length() > 0) {
				if (isDebug) {
					System.out.println("has atID(s) = " + authoringTemplateIds);
				}
				String[] tempATIds = authoringTemplateIds.split(","); 
				authTempIds = new DocumentId[tempATIds.length];
				for (int i = 0; i < tempATIds.length; i++) {
					authTempIds[i] = workspace.createDocumentId(tempATIds[i]);									
				}				
			}
			// fill SA
			if (siteAreaIds != null && siteAreaIds.length > 0) {
				if (isDebug) {
					System.out.println("has siteAreaIds [" + siteAreaIds.length + "]");
				}
				DocumentId docId = null;
				siteAreaDocIdArray = new DocumentId[siteAreaIds.length];
				for (int i = 0; i < siteAreaIds.length; i++) {
					// fill each saID into new doc id, then add to array
					if (isDebug) {
						System.out.println("sitearea id : " + siteAreaIds[i]);
					}
					try {
						docId = workspace.createDocumentId(siteAreaIds[i]);
						if (isDebug) {
							System.out.println("sitearea name " + docId.getName());
						}
						siteAreaDocIdArray[i] = docId;
					} catch (Exception e) {
						System.out.println("ERR_MESSAGE: " + e.getMessage());
						e.printStackTrace();
					}
				}
			}
			if (isDebug) {
				if (authTempIds != null) {
					for (int i = 0; i < authTempIds.length; i++) {
						System.out.println("AuthTempId = " + authTempIds[i].getName());
					}
				} else {
					System.out.println("AuthTempId = NULL");
				}
				System.out.println("draftStatus = " + draftStatus);
			}

			// System.out.println("Workspace.WORKFLOWSTATUS_PUBLISHED " +
			// Workspace.WORKFLOWSTATUS_PUBLISHED);
			parentSiteAreas = new HashMap<>();
			parentSiteAreaNames = new HashMap<>();
			paths = new HashMap<>();
			allElements = new HashMap<>();

			// use new query search, which is much faster
			if (isDebug)
				System.out.println("QUERY SEARCH!");
			Query query = workspace.getQueryService().createQuery();
			// if (isDebug) { System.out.println("siteAreaIds length:" +
			// siteAreaIds.length);}
			PageIterator pIter = getResults(query, docLib, authTempIds);
			processQueryResults(pIter, doc, parentDoc, parentName, parentSAName, tempDoc, label, path);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		workspace.logout();
		repository.endWorkspace();
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private PageIterator getResults(Query query, DocumentLibrary docLib, DocumentId[] authTempIds)
			throws QueryServiceException, DocumentIdCreationException {
		query.addSelector(Selectors.libraryEquals(docLib));
		query.addSelector(Selectors.typeIn(Content.class));

		if (dateStringFrom != null && dateStringFrom.trim().length() > 0) {
			if (isDebug)
				System.out.println("filter by date from");
			Date dateFrom = null;
			try {
				dateFrom = dateFormat.parse(dateStringFrom);
				if (isDebug) {
					System.out.println("date from after parse: " + dateFrom);
				}
				if (isDebug)
					System.out.println("query updated date:" + dateFrom.toString());
			} catch (ParseException e) {
				e.printStackTrace();
			}
			if (dateFrom != null) {
				// includeboundary, the 2nd parameter is NOT working. It is always false anyway
				query.addSelector(WorkflowSelectors.publishAfter(dateFrom, false));
			}
		}
		// filter date to
		if (dateStringTo != null && dateStringTo.trim().length() > 0) {
			if (isDebug)
				System.out.println("filter by date to");
			Date dateTo = null;
			try {
				dateTo = dateFormat.parse(dateStringTo);
				if (isDebug) {
					System.out.println("date to after parse: " + dateTo);
				}
				// Add one day manually (fix includeboundary not working)
				dateTo = addDays(dateTo, 1, isDebug);
				if (isDebug)
					System.out.println("query updated date:" + dateTo.toString());
			} catch (ParseException e) {
				e.printStackTrace();
			}
			if (dateTo != null) {
				// includeboundary, the 2nd parameter is NOT working. It is always false anyway
				query.addSelector(WorkflowSelectors.publishBefore(dateTo, false));
			}
		}
		// filter title
		if (searchTerm != null && searchTerm.trim().length() > 0) {
			// Stupid IBM function does not support case insensitive!
			if (isDebug)
				System.out.println("query searchTerm:" + searchTerm);
			Disjunction or = new Disjunction();
			or.add(Selectors.titleLike("%" + searchTerm + "%"));
			or.add(Selectors.titleLike("%" + searchTerm.toLowerCase() + "%"));
			or.add(Selectors.titleLike("%" + searchTerm.toUpperCase() + "%"));
			if (searchTerm.trim().length() > 1) {
				if (!Character.isUpperCase(searchTerm.charAt(0))) {
					or.add(Selectors
							.titleLike("%" + searchTerm.substring(0, 1).toUpperCase() + searchTerm.substring(1) + "%"));
				}
				or.add(Selectors.titleLike("%" + capitalizeString(searchTerm.trim()) + "%"));
			}
			query.addSelector(or);
//			query.addSelector(Selectors.titleLike("%" + searchTerm + "%"));
		}
		// sort
		if ("publishDate".equalsIgnoreCase(orderBy)) {
			SortDirection sortDirection = sortOrder ? SortDirection.ASCENDING : SortDirection.DESCENDING;
			query.addSort(Sorts.byPublishDate(sortDirection));
		}

		// filter AT
		if (authTempIds != null && authTempIds.length > 0) {
			if (isDebug) {
				for (int i = 0; i < authTempIds.length; i++) {
					System.out.println("filter by AT: " + authTempIds[i].getId());
				}
			}
			//query.addSelector(Selectors.authoringTemplateEquals(authTempId));
			query.addSelector(Selectors.authoringTemplateIn(authTempIds));
		}
		// filter SA
		if (siteAreaIds != null && siteAreaIds.length > 0) {
			if (isDebug)
				System.out.println("has siteArea:");
			DocumentId siteAreaDocId = null;
			for (int i = 0; i < siteAreaIds.length; i++) {
				if (isDebug)
					System.out.println("siteAreaIds[i]:" + siteAreaIds[i]);
				siteAreaDocId = workspace.createDocumentId(siteAreaIds[i]);
				query.addParentId(siteAreaDocId, QueryDepth.CHILDREN);
			}

		}

		// generate result
		query.returnObjects();//what does this do ? 
		PageIterator pageIterator = null;
		pageIterator = workspace.getQueryService().execute(query, resultsPerPage, currentPage);
		return pageIterator;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void processQueryResults(PageIterator pageIterator, DocumentId doc, DocumentId parentDoc, String parentName,
			String parentSAName, DocumentId tempDoc, String label, String path)
			throws DocumentRetrievalException, AuthorizationException, QueryStructureException {
		if (this.isDebug) {
			System.out.println("IN processQueryResults---------");
			System.out.println("page size --------->" + pageIterator.getPageSize());
			System.out.println("currentPage --------->" + currentPage);
			System.out.println("searchTerm --------->" + searchTerm);
		}
		Content content = null;
		ResultIterator docIterator = null;
		int page = 0;
		while (pageIterator.hasNext()) {
			docIterator = (ResultIterator) pageIterator.next(); // returns <T extends Document >
			if (this.isDebug) {
				System.out.println("pageIterator ---------> NEXT");
			}
			page++;
			while (docIterator.hasNext()) {
				total++;
				if (currentPage == 1 && page != currentPage) {
					docIterator.next();
					continue;
				}
				content = (Content) docIterator.next(); // returns <T extends Document >
				if (this.isDebug) {
					System.out.println("COUNT CONTENT ---------> " + total);
				}
				if (returnElements != null) {
					String contentElement = "";
					String[] returnElementsArray = returnElements.split(",");
					element = new HashMap<>();
					for (int i = 0; i < returnElementsArray.length; i++) {
						try {
							// if (isDebug) { System.out.println("returnElements: " +
							// returnElementsArray[i]); }
							contentElement = getContentElement(content, returnElementsArray[i], this.dateFormat);
						} catch (Exception e) {
							System.out.println(e.getMessage());
						}
						// insert single element
						element.put(returnElementsArray[i], contentElement);
						contentElement = "";
					}
					// if (isDebug) { System.out.println("VP id key: " + content.getId()); }
					// insert all elements in single result
					allElements.put(content.getId(), element);
				}

				// FORCE Portal to load Workflow data (this includes the publish date if content
				// has workflow)
				if (content.isWorkflowed()) {
					try {
						if (content.isPublished()) {
							content.getPublishedDate();
						}
					} catch (Exception e) {
					}
				}
				// FORCE Portal to load creation date
				try {
					content.getCreationDate();
				} catch (Exception e) {
				}

				if (this.isDebug) {
					System.out.println("pDate vp: " + content.getCreationDate().toString());
				}
				contents.add(content);
				parentDoc = content.getParentId();
				label = ((SiteArea) workspace.getById(parentDoc, true)).getTitle();
				parentSiteAreas.put(content.getId(), label);

				parentName = ((SiteArea) workspace.getById(parentDoc, true)).getName();
				parentSiteAreaNames.put(content.getId(), parentName);
				tempDoc = content.getParentId();
				SiteArea tempSA = (SiteArea) workspace.getById(tempDoc, true);

				// IMPORTANT ! prerequisite -> customsearch returns name of sitearea as
				// contentroot, the portal
				// rootpage has to be the exact same name
				while (!tempSA.getName().equals(this.contentRoot)) { // usually "site"
					path = parentName + "/" + path;
					tempDoc = tempSA.getParentId();

					if (this.isDebug) {
						System.out.println("path " + path + ", tempDoc: " + tempDoc);
						System.out.println("tempSA: " + tempSA.getName());
					}
					tempSA = (SiteArea) workspace.getById(tempDoc, true);
					parentName = ((SiteArea) workspace.getById(tempDoc, true)).getName();
					if (parentName.equals(this.contentRoot)) {
						break;
					}
				}
				paths.put(content.getId(), path);
				path = "";
			}
			if (currentPage != 1) {
				break;
			}
		}
		if (this.isDebug) {
			System.out.println("TOTAL ---------> " + total);
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private String getContentElement(Content content, String componentName, SimpleDateFormat dateFormat)
			throws ComponentNotFoundException, DocumentRetrievalException, AuthorizationException {
		// if (isDebug) { System.out.println("entering getcontent element " +
		// componentName); }
		ContentComponent contentComponent = null;
		if (content.hasComponent(componentName)) {
			contentComponent = content.getComponentByReference(componentName);
			if (contentComponent instanceof RichTextComponent) {
				// System.out.println("richtextcomponent");
				return ((RichTextComponent) contentComponent).getRichText().toString();
			} else if (contentComponent instanceof ShortTextComponent) {
				return ((ShortTextComponent) contentComponent).getText();
			} else if (contentComponent instanceof TextComponent) {
				return ((TextComponent) contentComponent).getText();
			} else if (contentComponent instanceof NumericComponent) {
				return ((NumericComponent) contentComponent).getNumber().toString();
			} else if (contentComponent instanceof ImageComponent) {
				return ((ImageComponent) contentComponent).getResourceURL();
			} else if (contentComponent instanceof LinkComponent) {
				return ((LinkComponent) contentComponent).getURL() + "&linktext&"
						+ ((LinkComponent) contentComponent).getLinkText();
			} else if (contentComponent instanceof FileComponent) {
				if (isDebug) {
					System.out.println("FileComponent");
				}
				FileComponent component = (FileComponent) contentComponent;
				if (component.getResourceURL() != null) {
					return component.getResourceURL();
				} else {
					return "";
				}
			} else if (contentComponent instanceof DateComponent) {
				// if(isDebug) { System.out.println("datecomponent"); }
				DateComponent component = (DateComponent) contentComponent;
				if (component.getDate() != null) {
					return component.getDate().getTime() + "";
				} else {
					if (isDebug) {
						System.out.println("dateComponent empty");
					}
					return "";
				}
			} // need to filter contents by optionselection here, can't access them outside vp
				// scope
			else if (contentComponent instanceof OptionSelectionComponent) {
				// if (isDebug) { System.out.println("optionselectioncomponent"); }
				OptionSelectionComponent component = (OptionSelectionComponent) contentComponent;
				DocumentId[] selections = null;
				String[] stringSelections = null;
				try {
					if (component.getOptionType() == OptionType.USE_TAXONOMY) {
						if (isDebug) {
							System.out.println("OPTION TYPE USE TAXONOMY");
						}
						selections = component.getCategorySelections();
					} else if (component.getOptionType() == OptionType.USER_DEFINED) {
						if (isDebug) {
							System.out.println("OPTION TYPE USER DEFINED");
						}
						stringSelections = component.getSelections();
						if (isDebug) {
							if (stringSelections == null) {
								System.out.println("stringSelections are null " + stringSelections);
							}
						}
					}
				} catch (OperationFailedException e) { // if the option type is OptionType.USER_DEFINED ??? We usually
														// define it this way
					System.out.println("OperationFailedException:" + e.getMessage());
					e.printStackTrace();
				}

				if (selections != null) {
					if (isDebug) {
						System.out.println("SELECTION LEN: " + selections.length);
					}
					String result = "";
//					DocumentId selected = null;
					Document doc = null;
					// Category cat = null;
					for (int i = 0; i < selections.length; i++) {
						System.out.println(" option 0: " + selections[0]);
//						selected = selections[i];				
						doc = workspace.getById(selections[i]);
						if (selections.length > 1) {
							result = doc.getTitle() + ",";
						} else {
							result = doc.getTitle();
						}
						if (isDebug) {
							System.out.println("selections " + result);
						}
					}
					return result;

				}
				if (stringSelections != null) {
					if (isDebug) {
						System.out.println("STRING SELECTION LEN: " + stringSelections.length + " option 0: "
								+ stringSelections[0]);
					}
					String result = "";
					String selected = "";
					for (int i = 0; i < stringSelections.length; i++) {
						selected = stringSelections[i];
						if (stringSelections.length > 1) {
							result = selected + ",";
						} else {
							result = selected;
						}
						if (isDebug) {
							System.out.println("stringSelections " + result);
						}
					}
					return result;
				}
			}
		} else {
			if (isDebug) {
				System.out.println("No such component (vpscoped) " + componentName);
			}
		}
		return "";
	}

	private Date addDays(Date date, int days, boolean isDebug) {
		if (isDebug) {
			System.out.println("add days " + date.toString() + " offset: " + days);
		}
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DATE, days); // minus number would decrement the days
		if (isDebug) {
			System.out.println("add days cal " + cal.getTime());
		}
		return cal.getTime();
	}

	private String capitalizeString(String string) {
		char[] chars = string.toLowerCase().toCharArray();
		boolean found = false;
		for (int i = 0; i < chars.length; i++) {
			if (!found && Character.isLetter(chars[i])) {
				chars[i] = Character.toUpperCase(chars[i]);
				found = true;
			} else if (Character.isWhitespace(chars[i]) || chars[i] == '.' || chars[i] == '\'') { // You can add other
																									// chars here
				found = false;
			}
		}
		return String.valueOf(chars);
	}

}
