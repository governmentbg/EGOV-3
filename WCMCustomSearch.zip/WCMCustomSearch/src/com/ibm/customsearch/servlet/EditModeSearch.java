package com.ibm.customsearch.servlet;

import java.io.IOException;
import java.util.HashMap;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentTypes;
import com.ibm.workplace.wcm.api.RenderingContext;
import com.ibm.workplace.wcm.api.Repository;
import com.ibm.workplace.wcm.api.WCM_API;
import com.ibm.workplace.wcm.api.Workspace;


@WebServlet("/getrenderingcontext")
public class EditModeSearch extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static Repository repository = null;
	private static Workspace workspace = null;
    

    public EditModeSearch() {
        super();
    }


	public void init(ServletConfig config) throws ServletException {
		super.init();
		if (repository != null)
			return;
		repository = WCM_API.getRepository();
		try {
			workspace = repository.getSystemWorkspace();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	@SuppressWarnings({ "rawtypes", "unchecked" })
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		init();
		System.out.println("doGET rc");
		request.setCharacterEncoding("utf8");
		String contentParam = request.getParameter("content");
		String context = request.getParameter("context");
//		String path = request.getParameter("path");
		System.out.println("content " + contentParam);
		String renderedContent = "";
		String contentName = request.getParameter("contentName");
		try {
			RenderingContext rc = workspace.createRenderingContext(request, response, new HashMap(), "http://172.23.103.75:10059/" + context, "connect");
			 // Set the path to the content to be rendered
			 rc.setRenderedContent("/VP Content/site/home/customer profile/procedures new/procedure new/000321/00334-2016-0001");
			 
			 DocumentIdIterator ids = workspace.findByName(DocumentTypes.Content, contentName);
		  	 if(ids.hasNext()){
		  		 System.out.println("Found Content");
		  		 Content content = (Content) workspace.getById(ids.next());
		  		 System.out.println("Found Content of name: " + content.getTitle());
		  		
		  	 }
			 /* DocumentId doc = null;
			 Content content = (Content) workspace.getById(doc, true);
			 ContentComponent contentComponent = content.getComponent("procedure-name"); */
			 // Get the rendered string
			 renderedContent = workspace.render(rc);			
			 
			
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		System.out.println("response: " + renderedContent);
		response.setHeader("Cache-Control", "no-cache");
		response.setContentType("application/json; charset=UTF-8");
		response.getWriter().write(renderedContent);
		response.getWriter().flush();
		response.getWriter().close();
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

}
