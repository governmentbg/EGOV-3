$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'simpleChartContainer',
                zoomType: 'xy'
            },
            title: {
                text: 'Bulgarian Household Internet Data'
            },
            subtitle: {
                text: 'Source: egov.bg'
            },
            xAxis: [{
                categories: ['20.11.2012', '20.12.2012', '20.02.2013', '20.03.2013', '20.04.2013', '20.05.2013', '20.06.2013']
            }],
            yAxis: [{ // Primary yAxis
            	labels: {
                    formatter: function() {
                        return this.value +' ';
                    },
                    style: {
                        color: 'red'
                    }
                },
                title: {
                    text: 'People',
                    style: {
                        color: 'red'
                    }
                }}],
            tooltip: {
                formatter: function() {
                    var unit = {
                    	'People': ''
                    }[this.series.name];
                    return ''+
                        //this.x +': '+ this.y +'people: ' + this.series.name;
                        this.y + ' - People (' + this.series.name + ')';
                }
            },
            legend: {
                layout: 'vertical',
                align: 'left',
                x: 120,
                verticalAlign: 'top',
                y: 60,
                floating: true,
                backgroundColor: '#FFFFFF'
            },
            series: [{
            	name: 'Birth Rate',
            	color: 'green',
                type: 'column',
                data: [20, 50, 24, 60, 80, 100, 60]
            	
            }, {
            	name: 'Death Rate',
            	color: 'yellow',
                type: 'column',
                data: [5, 10, 5, 10, 20, 35, 10]
            }, {
            	name: 'Homocide',
                type: 'column',
                color: 'blue',
                data: [10, 25, 12, 30, 40, 100, 30]
            }]
        });
    });
    
});