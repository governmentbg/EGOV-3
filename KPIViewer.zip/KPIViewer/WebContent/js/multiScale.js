$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'complexChartContainer',
                zoomType: 'xy'
            },
            title: {
                text: 'Earnings Spendings Savings and Taxes in MIA'
            },
            subtitle: {
                text: 'Source: egov.bg'
            },
            xAxis: [{
                categories: ['20.11.2012', '20.12.2012', '20.02.2013', '20.03.2013', '20.04.2013', '20.05.2013', '20.06.2013']
            }],
            yAxis: [{ // Primary yAxis
            	labels: {
                    formatter: function() {
                        return this.value +' ';
                    },
                    style: {
                        color: 'blue'
                    }
                },
                title: {
                    text: 'People',
                    style: {
                        color: 'blue'
                    },
                    
                }
            }, 
                { // Secondary yAxis
                	labels: {
                        formatter: function() {
                            return this.value +' BGN';
                        },
                        style: {
                            color: 'green'
                        }
                    },
                    title: {
                        text: 'Earnings per annum',
                        style: {
                            color: 'green'
                        },
                    },
                    opposite: true},
                    { // Tertiary yAxis
                    	labels: {
                            formatter: function() {
                                return this.value +' %';
                            },
                            style: {
                                color: 'red'
                            }
                        },
                        title: {
                            text: 'Tax rate (annual)',
                            style: {
                                color: 'red'
                            },
                        },
                        opposite: true
                        },
                ],
            tooltip: {
                formatter: function() {
                	var unit = {
                            'People': ' ',
                            'Earnings per annum': 'BGN',
                            'Tax rate (annual)': '%',
                            'Expenses (annual)': 'BGN',
                            'Savings (annual)': 'BGN'
                        }[this.series.name];
                        return ''+
                            this.x +': '+ this.y +' '+ unit;
                }
            },
            legend: {
                layout: 'vertical',
                align: 'left',
                x: 200,
                verticalAlign: 'top',
                y: 60,
                floating: true,
                backgroundColor: '#FFFFFF'
            },
            series: [{
            	name: 'People',
            	color: 'blue',
                type: 'column',
                data: [20, 50, 24, 60, 80, 100, 60]
            	
            }, {
            	name: 'Earnings per annum',
            	color: 'green',
                type: 'line',
                data: [10000, 15000, 10000, 20000, 20000, 15000, 30000]
            }, {
            	name: 'Tax rate (annual)',
                type: 'line',
                color: 'red',
                data: [12, 13, 10, 11, 17, 30, 40]
            }, {
            	name: 'Expenses (annual)',
                type: 'line',
                color: 'orange',
                yAxis: 2,
                data: [6000, 7000, 8000, 9000, 10000, 12000, 20000]
            }, {
            	name: 'Savings (annual)',
                type: 'line',
                color: 'grey',
                yAxis: 2,
                data: [4000, 3000, 2500, 2000, 1500, 1000, 0]
            }
            ]
        });
    });
    
});