package com.ibm.kpiviewer;

import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import com.ibm.kpi.bean.BreadCrumbNode;
import com.ibm.kpi.bean.Container;
import com.ibm.kpi.management.IndicatorManagement;
import com.ibm.kpi.management.SectorManagement;

public class KPIBreadCrumbManager {
	
	public static void buildBreadCrumb(RenderRequest request, RenderResponse response, ResourceBundle bundle, KPIPortletSessionBean sessionBean) {
		ArrayList<BreadCrumbNode> breadCrumb = new ArrayList<BreadCrumbNode>();	 			
		if (KPIViewerPortlet.SECTORS_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			breadCrumb.add(getNode(response, bundle.getString("breadcrumb.sectors"), KPIViewerPortlet.SECTORS_LIST_PAGE, null, null));
		} else if (KPIViewerPortlet.INDICATORS_LIST_PAGE.equals(sessionBean.getCurrentPage()) || KPIViewerPortlet.INDICATOR_VALUES_LIST_PAGE.equals(sessionBean.getCurrentPage()) || KPIViewerPortlet.INDICATOR_STATISTICS_PAGE.equals(sessionBean.getCurrentPage())) {
			Container container = sessionBean.getContainer().get(KPIViewerPortlet.INDICATORS_LIST_PAGE);
			String sectorId = null;
			if (container != null && container.getId() != null) { // LOAD SECTOR
				SectorManagement sectorManagement = new SectorManagement();
				if (sectorManagement.loadKPISectorById(container.getId(), null) == 1) {
					sectorId = container.getId();
					ArrayList<String> extraParametersNames = new ArrayList<String>();
					ArrayList<String> extraParametersValues = new ArrayList<String>();
					extraParametersNames.add(KPIViewerPortlet.PARAMETER_ID);
					extraParametersValues.add(container.getId());
					breadCrumb.add(getNode(response, sectorManagement.getCurrentKPISector().getSectorName(), KPIViewerPortlet.SECTORS_LIST_PAGE, extraParametersNames, extraParametersValues));
				}
			}	
			if (KPIViewerPortlet.INDICATOR_STATISTICS_PAGE.equals(sessionBean.getCurrentPage())) {
				if (sectorId != null && sectorId.trim().length() > 0) {
					ArrayList<String> extraParametersNames = new ArrayList<String>();
					ArrayList<String> extraParametersValues = new ArrayList<String>();
					extraParametersNames.add(KPIViewerPortlet.PARAMETER_ID);
					extraParametersValues.add(sectorId);
					breadCrumb.add(getNode(response, bundle.getString("breadcrumb.indicators"), KPIViewerPortlet.INDICATORS_LIST_PAGE, extraParametersNames, extraParametersValues));
				} else {
					breadCrumb.add(getNode(response, bundle.getString("breadcrumb.indicators"), KPIViewerPortlet.INDICATORS_LIST_PAGE, null, null));
				}
				breadCrumb.add(getNode(response, bundle.getString("breadcrumb.graphic"), KPIViewerPortlet.INDICATOR_STATISTICS_PAGE, null, null));
			} else if (KPIViewerPortlet.INDICATOR_VALUES_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
				container = sessionBean.getContainer().get(KPIViewerPortlet.INDICATOR_VALUES_LIST_PAGE);
				if (container != null && container.getId() != null) { // LOAD INDICATOR
					IndicatorManagement indicatorManagement = new IndicatorManagement();
					if (indicatorManagement.loadKPIIndicatorById(container.getId(), null) == 1) {
						if (sectorId != null && sectorId.trim().length() > 0) {
							ArrayList<String> extraParametersNames = new ArrayList<String>();
							ArrayList<String> extraParametersValues = new ArrayList<String>();
							extraParametersNames.add(KPIViewerPortlet.PARAMETER_ID);
							extraParametersValues.add(sectorId);
							breadCrumb.add(getNode(response, indicatorManagement.getCurrentKPIIndicator().getIndicatorName(), KPIViewerPortlet.INDICATORS_LIST_PAGE, extraParametersNames, extraParametersValues));
						} else {
							breadCrumb.add(getNode(response, indicatorManagement.getCurrentKPIIndicator().getIndicatorName(), KPIViewerPortlet.INDICATORS_LIST_PAGE, null, null));
						}
					} else {
						breadCrumb.add(getNode(response, bundle.getString("breadcrumb.indicators"), KPIViewerPortlet.INDICATORS_LIST_PAGE, null, null));
					}
				}					
				if (KPIConstants.MODE_INDICATOR_VALUES.equals(KPIViewerPortlet.mode) && (container == null || container.getId() == null)) {
					breadCrumb.add(getNode(response, bundle.getString("breadcrumb.indicators"), KPIViewerPortlet.INDICATORS_LIST_PAGE, null, null));
				}
				breadCrumb.add(getNode(response, bundle.getString("breadcrumb.indicator.values"), KPIViewerPortlet.INDICATOR_VALUES_LIST_PAGE, null, null));
			} else { 
				breadCrumb.add(getNode(response, bundle.getString("breadcrumb.indicators"), KPIViewerPortlet.INDICATORS_LIST_PAGE, null, null));
			}
		} 
		sessionBean.setBreadCrumb(breadCrumb);
	}

	private static BreadCrumbNode getNode(RenderResponse response, String nodeName, String nodePage, ArrayList<String> extraParametersNames, ArrayList<String> extraParametersValues) {
		BreadCrumbNode breadCrumbNode = new BreadCrumbNode();		
		breadCrumbNode.setName(nodeName);
		PortletURL breadCrumbActionUrl = response.createActionURL(); 
		breadCrumbActionUrl.setParameter(KPIViewerPortlet.PARAMETER_ACTION, KPIViewerPortlet.ACTION_NAVIGATE_TO_PAGE);
		breadCrumbActionUrl.setParameter(KPIViewerPortlet.PARAMETER_VALUE, nodePage);
		breadCrumbActionUrl.setParameter(KPIViewerPortlet.PARAMETER_SOURCE, KPIViewerPortlet.SOURCE_BREADCRUMB);
		if (extraParametersNames != null && extraParametersValues != null && extraParametersNames.size() == extraParametersValues.size()) {
			for (int i = 0; i < extraParametersNames.size(); i++) {
				breadCrumbActionUrl.setParameter(extraParametersNames.get(i), extraParametersValues.get(i));
			}
		}
		breadCrumbNode.setUrl(breadCrumbActionUrl.toString());
		return breadCrumbNode;
	}
	
}
