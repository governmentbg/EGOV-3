package com.ibm.kpiviewer;

import java.io.IOException;
import java.io.OutputStream;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.GenericPortlet;
import javax.portlet.PortletException;
import javax.portlet.PortletMode;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequest;
import javax.portlet.PortletRequestDispatcher;
import javax.portlet.PortletSession;
import javax.portlet.ReadOnlyException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.portlet.ValidatorException;
import javax.portlet.WindowState;

import com.ibm.kpi.bean.Container;
import com.ibm.kpi.bean.Message;
import com.ibm.kpi.db.DBPool;
import com.ibm.kpi.db.DBResources;
import com.ibm.kpi.management.AttachmentManagement;
import com.ibm.kpi.utils.KPIUtils;

public class KPIViewerPortlet extends GenericPortlet {
 
	public static final String JSP_FOLDER = "/_KPIViewer/jsp/"; // JSP folder name
  
	public static final String SECTORS_LIST_PAGE = "sectors";
	public static final String INDICATORS_LIST_PAGE = "indicators";
	public static final String INDICATOR_VALUES_LIST_PAGE = "indicatorValues";
	public static final String INDICATOR_VALUE_PREVIEW_PAGE = "indicatorValueForm";
	public static final String INDICATOR_STATISTICS_PAGE = "indicatorStatistics";
	public static final String CONFIG_JSP = "KPIViewerPortletConfig"; // JSP file name to be rendered on the configure mode
	public static final String EDIT_DEFAULTS_JSP = "KPIViewerPortletEditDefaults"; // JSP file name to be rendered on the configure mode
  
	public static final String PARAMETER_SOURCE = "source";
	public static final String PARAMETER_ACTION = "action";
	public static final String PARAMETER_VALUE = "value";
	public static final String PARAMETER_ID = "id";
	public static final String PARAMETER_OPERATION = "operation";
	
	public static final String ACTION_NAVIGATE_TO_PAGE = "changePage";
	public static final String ACTION_NAVIGATOR = "navigator";
	public static final String ACTION_CHANGE_SEARCH_CRITERIA = "searchCriteria";

	public static final String SOURCE_BREADCRUMB = "breadcrumb";

	public static final String NAVIGATOR_OPERATION_FIRST = "1";
	public static final String NAVIGATOR_OPERATION_PREVIOUS = "2";
	public static final String NAVIGATOR_OPERATION_NEXT = "3";
	public static final String NAVIGATOR_OPERATION_LAST = "4";
	public static final String NAVIGATOR_OPERATION_GOTO = "5";
	
	public static final String SESSION_BEAN = "KPIViewerPortletSessionBean"; // Bean name for the portlet session
	public static final String MESSAGE = "KPIViwerMessage";
	public static final String MESSAGE_TYPE = "KPIViwerMessageType";
	public static final String CONFIG_SUBMIT = "KPIViewerPortletConfigSubmit"; // Action name for submit form
	public static final String CONFIG_CANCEL = "KPIViewerPortletConfigCancel";
	public static final String EDIT_DEFAULTS_SUBMIT = "KPIViewerPortletEditDefaultsSubmit"; // Action name for submit form
	public static final String EDIT_DEFAULTS_CANCEL = "KPIViewerPortletEditDefaultsCancel";

	public static final String SETTING_PARAMETER_RESULTS_PER_PAGE = "wps.results.per.page";
	public static final String SETTING_PARAMETER_MODE = "wps.mode";

	public static int resultsPerPage = 10;
	public static String mode = KPIConstants.MODE_INDICATOR_VALUES;

	private static final PortletMode CUSTOM_CONFIG_MODE = new PortletMode("config");
	private static final PortletMode CUSTOM_EDIT_DEFAULTS_MODE = new PortletMode("edit_defaults");

	public void init() throws PortletException {
		super.init();
		String realPath = getPortletContext().getRealPath("/");
		if (DBResources.loadProps(realPath)) {
			System.out.print("------ APPLICATION STARTED NORMALLY: [ OK ]");
		}
	}

	public void doView(RenderRequest request, RenderResponse response) throws PortletException, IOException {	
		// Set the MIME type for the render response
		response.setContentType(request.getResponseContentType());

		// Check if portlet session exists
		KPIPortletSessionBean sessionBean = getSessionBean(request);
		if (sessionBean == null) {
			response.getWriter().println("<b>NO PORTLET SESSION YET</b>");
			return;
		}
		if (sessionBean.getCurrentPage() == null) {
			if (mode.equals(KPIConstants.MODE_INDICATOR_VALUES)) {
				sessionBean.setCurrentPage(INDICATOR_VALUES_LIST_PAGE);
			} else {
				sessionBean.setCurrentPage(SECTORS_LIST_PAGE);
			}
		}

		// Invoke the JSP to render
		KPIContainerManager.process(request, response, getPortletConfig().getResourceBundle(request.getLocale()), sessionBean);
		KPIBreadCrumbManager.buildBreadCrumb(request, response, getPortletConfig().getResourceBundle(request.getLocale()), sessionBean);
		KPINavigatorManager.buildNavigator(request, response, getPortletConfig().getResourceBundle(request.getLocale()), sessionBean);
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, sessionBean.getCurrentPage()));
		rd.include(request, response);
	}

	protected void doCustomConfigure(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		// Set the MIME type for the render response
		response.setContentType(request.getResponseContentType());
		// Invoke the JSP to render
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, CONFIG_JSP));
		rd.include(request, response);
	}

	protected void doCustomEditDefaults(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		// Set the MIME type for the render response
		response.setContentType(request.getResponseContentType());
		// Invoke the JSP to render
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, EDIT_DEFAULTS_JSP));
		rd.include(request, response);
	}

	protected void doDispatch(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		if (!WindowState.MINIMIZED.equals(request.getWindowState())) {
			KPIUtils.loadPreferences(request);
			PortletMode mode = request.getPortletMode();
			if (CUSTOM_CONFIG_MODE.equals(mode)) {
				doCustomConfigure(request, response);
				return;
			} else if (CUSTOM_EDIT_DEFAULTS_MODE.equals(mode)) {
				doCustomEditDefaults(request, response);
				return;
			}
		}
		super.doDispatch(request, response);
	}

	public void processAction(ActionRequest request, ActionResponse response) throws PortletException, java.io.IOException {
		String action = request.getParameter(PARAMETER_ACTION);
		String value = request.getParameter(PARAMETER_VALUE);
		String id = request.getParameter(PARAMETER_ID);
		KPIPortletSessionBean sessionBean = getSessionBean(request);
		sessionBean.setMessage(null);
		Container container = sessionBean.getContainer().get(sessionBean.getCurrentPage());
		if (container == null) {
			container = new Container();
		}
		KPIActionManager kpiActionManager = new KPIActionManager();

		System.out.println("currentPage = " + sessionBean.getCurrentPage());
		System.out.println("action = " + action);
		System.out.println("value = " + value);
		// SET PARAMETERS TO BE VISIBILE FOR doView()...
		response.setRenderParameters(request.getParameterMap());
		if (ACTION_NAVIGATE_TO_PAGE.equals(action)) {
			sessionBean.setCurrentPage(value);
			container = sessionBean.getContainer().get(value);
			if (container == null) {
				container = new Container();
			}
			if (id != null && id.trim().length() > 0) {
				container.setId(id.trim());
			} else {
				container.setId(null);
			}
			sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
		} else if (ACTION_NAVIGATOR.equals(action)) {
			kpiActionManager.processNavigator(sessionBean, request);
		} else if (ACTION_CHANGE_SEARCH_CRITERIA.equals(action)) {
			container.setFilterCriteria(request.getParameter("filterCriteria"));
			container.setFilterType(request.getParameter("filterType"));
			container.setFilterValue(request.getParameter("filterValue"));
			container.setFilterValue2(request.getParameter("filterValue2"));
			container.setNavigatorPage(1);
			container.setNavigatorTotalPages(1);			
			sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
		}
		
		if (request.getParameter(CONFIG_SUBMIT) != null) {
			String resultsPerPage = request.getParameter(SETTING_PARAMETER_RESULTS_PER_PAGE);
			String mode = request.getParameter(SETTING_PARAMETER_MODE);
			PortletPreferences prefs = request.getPreferences();
			try {
				prefs.setValue(SETTING_PARAMETER_RESULTS_PER_PAGE, resultsPerPage);
				prefs.setValue(SETTING_PARAMETER_MODE, mode);
				prefs.store();
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(request.getLocale()).getString("settings.were.saved")));
				response.setPortletMode(PortletMode.VIEW);
				response.setWindowState(WindowState.NORMAL);
				if (!KPIViewerPortlet.mode.equals(mode)) {
					PortletSession session = request.getPortletSession();
					if (session != null) {
						sessionBean = (KPIPortletSessionBean) session.getAttribute(SESSION_BEAN);
						sessionBean = new KPIPortletSessionBean();
						session.setAttribute(SESSION_BEAN, sessionBean);
					}
				} 
			} catch (ReadOnlyException roe) {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, roe.getMessage()));
			} catch (ValidatorException ve) {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, ve.getMessage()));
			}
		} else if (request.getParameter(CONFIG_CANCEL) != null) {
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);
		}
		if (request.getParameter(EDIT_DEFAULTS_SUBMIT) != null) {
			String resultsPerPage = request.getParameter(SETTING_PARAMETER_RESULTS_PER_PAGE);
			String mode = request.getParameter(SETTING_PARAMETER_MODE);
			PortletPreferences prefs = request.getPreferences();
			try { 
				prefs.setValue(SETTING_PARAMETER_RESULTS_PER_PAGE, resultsPerPage);
				prefs.setValue(SETTING_PARAMETER_MODE, mode);
				prefs.store();
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(request.getLocale()).getString("settings.were.saved")));
				response.setPortletMode(PortletMode.VIEW);
				response.setWindowState(WindowState.NORMAL);
				if (!KPIViewerPortlet.mode.equals(mode)) {
					PortletSession session = request.getPortletSession();
					if (session != null) {
						sessionBean = (KPIPortletSessionBean) session.getAttribute(SESSION_BEAN);
						sessionBean = new KPIPortletSessionBean();
						session.setAttribute(SESSION_BEAN, sessionBean);
					}
				}
			} catch (ReadOnlyException roe) {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, roe.getMessage()));
			} catch (ValidatorException ve) {
				sessionBean.setMessage(new Message(KPIConstants.MESSAGE_TYPE_ERROR, ve.getMessage()));
			}
		} else if (request.getParameter(EDIT_DEFAULTS_CANCEL) != null) {
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);
		}
	} 

	public void serveResource(ResourceRequest request, ResourceResponse response) throws PortletException, IOException {
		String attachmentId = request.getParameter(PARAMETER_ID);
		AttachmentManagement attachmentManagement = new AttachmentManagement();
		OutputStream outputStream = response.getPortletOutputStream();

		if (attachmentManagement.loadKPIAttachmentById(attachmentId, null) == 1) {
			response.setContentType(attachmentManagement.getCurrentKPIAttachment().getContentType());
			response.setProperty("Content-disposition", "attachment; filename=\"" + attachmentManagement.getCurrentKPIAttachment().getFileName() + "\"");
			outputStream.write(attachmentManagement.getCurrentKPIAttachment().getAttachment(), 0, attachmentManagement.getCurrentKPIAttachment().getAttachment().length);
		} else {
			outputStream.write("<i>Unable to find the specified file</i>".getBytes());
		}
		outputStream.flush(); 
		outputStream.close();
	}

	public void destroy() {
		System.out.println("STOPPING THREADS STARTED");
		DBPool.shutdownDataSource();
		System.out.println("STOPPING THREADS FINISHED");
	}

	private static KPIPortletSessionBean getSessionBean(PortletRequest request) {
		PortletSession session = request.getPortletSession();
		if (session == null) {
			return null;
		}
		KPIPortletSessionBean sessionBean = (KPIPortletSessionBean) session.getAttribute(SESSION_BEAN);
		if (sessionBean == null) {
			sessionBean = new KPIPortletSessionBean();
			session.setAttribute(SESSION_BEAN, sessionBean);
		}
		return sessionBean;
	}

	/**
	 * Returns JSP file path.
	 * 
	 * @param request
	 *            Render request
	 * @param jspFile
	 *            JSP file name
	 * @return JSP file path
	 */
	private static String getJspFilePath(RenderRequest request, String jspFile) {
		String markup = request.getProperty("wps.markup");
		if (markup == null)
			markup = getMarkup(request.getResponseContentType());
		return JSP_FOLDER + markup + "/" + jspFile + "." + getJspExtension(markup);
	}

	/**
	 * Convert MIME type to markup name.
	 * 
	 * @param contentType
	 *            MIME type
	 * @return Markup name
	 */
	private static String getMarkup(String contentType) {
		if ("text/vnd.wap.wml".equals(contentType))
			return "wml";
		else
			return "html";
	}

	/**
	 * Returns the file extension for the JSP file
	 * 
	 * @param markupName
	 *            Markup name
	 * @return JSP extension
	 */
	private static String getJspExtension(String markupName) {
		return "jsp";
	}

}
