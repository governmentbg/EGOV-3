package com.ibm.kpiviewer;

import java.util.ArrayList;
import java.util.ResourceBundle;

import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import com.ibm.kpi.bean.Container;

public class KPINavigatorManager {
	
	public static void buildNavigator(RenderRequest request, RenderResponse response, ResourceBundle bundle, KPIPortletSessionBean sessionBean) {
		sessionBean.setNavigatorTop(getNavigator(request, response, bundle, sessionBean));
		sessionBean.setNavigatorBottom(getNavigator(request, response, bundle, sessionBean));
	}

	public static String getNavigator(RenderRequest request, RenderResponse response, ResourceBundle bundle, KPIPortletSessionBean sessionBean) {
		Container container = sessionBean.getContainer().get(sessionBean.getCurrentPage());
		StringBuffer navigator = new StringBuffer(); 
		if (container != null) {
			java.util.UUID uuId = java.util.UUID.randomUUID();
			String imagePath = request.getContextPath() + "/images/";
			int navigatorPage = container.getNavigatorPage();
			int totalPages = container.getNavigatorTotalPages();			
			if (navigatorPage > 1) {
				navigator.append("<td valign=\"middle\" nowrap=\"nowrap\"><a role=\"button\" class=\"lnk1\" onclick=\"" + response.getNamespace() + "navigate(" + KPIViewerPortlet.NAVIGATOR_OPERATION_FIRST + "); return false;\" href=\"#\"><img border=\"0\" align=\"absmiddle\" title=\"" + bundle.getString("navigator.first.page") + "\" alt=\"" + bundle.getString("navigator.first.page") + "\" src=\"" + imagePath + "Buttons_First.gif\"></a></td>");
				navigator.append("<td>&nbsp;&nbsp;</td>");
				navigator.append("<td valign=\"middle\" nowrap=\"nowrap\"><a role=\"button\" class=\"lnk1\" onclick=\"" + response.getNamespace() + "navigate(" + KPIViewerPortlet.NAVIGATOR_OPERATION_PREVIOUS + "); return false;\" href=\"#\"><img border=\"0\" align=\"absmiddle\" title=\"" + bundle.getString("navigator.previous.page") + "\" alt=\"" + bundle.getString("navigator.previous.page") + "\" src=\"" + imagePath + "Buttons_Left.gif\"></a></td>");
				navigator.append("<td>&nbsp;&nbsp;</td>");
			}			
			navigator.append("<td valign=\"middle\" nowrap=\"nowrap\" style=\"padding-top:1px;\">" + bundle.getString("navigator.page") + " " + navigatorPage + " " + bundle.getString("navigator.of") + " " + totalPages + " " + "</td>");
			if (navigatorPage < totalPages) {
				navigator.append("<td>&nbsp;&nbsp;</td>");
				navigator.append("<td valign=\"middle\" nowrap=\"nowrap\"><a role=\"button\" class=\"lnk1\" onclick=\"" + response.getNamespace() + "navigate(" + KPIViewerPortlet.NAVIGATOR_OPERATION_NEXT + "); return false;\" href=\"#\"><img border=\"0\" align=\"absmiddle\" title=\"" + bundle.getString("navigator.next.page") + "\" alt=\"" + bundle.getString("navigator.next.page") + "\" src=\"" + imagePath + "Buttons_Right.gif\"></a></td>");
				navigator.append("<td>&nbsp;&nbsp;</td>");
				navigator.append("<td valign=\"middle\" nowrap=\"nowrap\"><a role=\"button\" class=\"lnk1\" onclick=\"" + response.getNamespace() + "navigate(" + KPIViewerPortlet.NAVIGATOR_OPERATION_LAST + "); return false;\" href=\"#\"><img border=\"0\" align=\"absmiddle\" title=\"" + bundle.getString("navigator.last.page") + "\" alt=\"" + bundle.getString("navigator.last.page") + "\" src=\"" + imagePath + "Buttons_Last.gif\"></a></td>");
			}
			if (totalPages > 1) {
				navigator.append("<td>&nbsp;&nbsp;</td>");
				navigator.append("<td valign=\"middle\" nowrap=\"nowrap\"><label for=\"" + response.getNamespace() + "jumptopage\">" + bundle.getString("navigator.jump.to.page") + ":</label><span dir=\"LTR\"><img src=\"/wps/defaultTheme80/themes/html/psw/wcl/images/o.gif\"><input type=\"text\" dir=\"LTR\" class=\"wpsEditField\" onkeypress=\"if (event && event.which == 13) { " + response.getNamespace() + "validateGoToPage('" + response.getNamespace() + String.valueOf(uuId) + "'); return false; }\" id=\"" + response.getNamespace() + String.valueOf(uuId) + "\" size=\"2\" value=\"" + navigatorPage + "\"></span></td>");
				navigator.append("<td>&nbsp;&nbsp;</td>");
				navigator.append("<td valign=\"middle\" nowrap=\"nowrap\"><span dir=\"LTR\"><img src=\"/wps/defaultTheme80/themes/html/psw/wcl/images/o.gif\"><input type=\"image\" border=\"0\" dir=\"LTR\" onclick=\"" + response.getNamespace() + "validateGoToPage('" + response.getNamespace() + String.valueOf(uuId) + "'); return false;\" class=\"wpsPagingTableHeaderIcon\" title=\"" + bundle.getString("navigator.go") + "\" alt=\"" + bundle.getString("navigator.go") + "\" src=\"" + imagePath + "Buttons_Go.gif\"></span></td>");
			}
		} else {
			navigator.append("<td valign=\"middle\" nowrap=\"nowrap\" style=\"padding-top:1px;\">" + bundle.getString("navigator.page") + " 1 " + bundle.getString("navigator.of") + " 1 " + "</td>");
		}
		return "<table cellpadding=\"0\" cellspacing=\"0\" border=\"0\"><tr>" + navigator.toString() + "</tr></table>";
	}
		
	public static ArrayList<Object> filterResults(Object[] objects, int resultsPerPage, int navigatorPage) {		
		int k = 0;
		if (navigatorPage != 1) {
			k = (navigatorPage * resultsPerPage) - resultsPerPage; 
		}
		int total = (resultsPerPage > 0) ? k + resultsPerPage : objects.length;
		ArrayList<Object> filteredObjects = new ArrayList<Object>();
		for (int i = k; i < total; i++) {
			if (objects.length > i) {
				filteredObjects.add(objects[i]);
			} else {
				break;
			}
		}
		return filteredObjects;
	}
}
