package com.ibm.kpiviewer;

import javax.portlet.ActionRequest;

import com.ibm.kpi.bean.Container;

public class KPIActionManager {
	public void processNavigator(KPIPortletSessionBean sessionBean, ActionRequest request) {
		Container container = sessionBean.getContainer().get(sessionBean.getCurrentPage());
		if (container != null) {
			String operation = request.getParameter(KPIViewerPortlet.PARAMETER_OPERATION);
			String value = request.getParameter(KPIViewerPortlet.PARAMETER_VALUE);
			int navigatorPage = container.getNavigatorPage();
			int navigatorTotalPages = container.getNavigatorTotalPages();
			if (operation != null && operation.trim().length() > 0) {
				if (KPIViewerPortlet.NAVIGATOR_OPERATION_FIRST.equals(operation)) {
					container.setNavigatorPage(1);
				} else if (KPIViewerPortlet.NAVIGATOR_OPERATION_PREVIOUS.equals(operation)) {
					if (navigatorPage > 1) {
						container.setNavigatorPage(navigatorPage - 1);
					}
				} else if (KPIViewerPortlet.NAVIGATOR_OPERATION_NEXT.equals(operation)) {
					if (navigatorPage < navigatorTotalPages) {
						container.setNavigatorPage(navigatorPage + 1);
					}
				} else if (KPIViewerPortlet.NAVIGATOR_OPERATION_LAST.equals(operation)) {
					container.setNavigatorPage(navigatorTotalPages);
				} else if (KPIViewerPortlet.NAVIGATOR_OPERATION_GOTO.equals(operation) && value != null && value.trim().length() > 0) {
					try {
						if (Integer.parseInt(value) > navigatorTotalPages) {
							container.setNavigatorPage(navigatorTotalPages);
						} else if (Integer.parseInt(value) < 1) {
							container.setNavigatorPage(1);
						} else {
							container.setNavigatorPage(Integer.parseInt(value));
						}
					} catch (NumberFormatException e) {
						e.printStackTrace();
					}
				}
				System.out.println("navPage = " + container.getNavigatorPage());
				sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
			}
		}
	}
}