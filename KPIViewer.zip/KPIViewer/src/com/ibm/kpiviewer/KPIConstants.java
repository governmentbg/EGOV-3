package com.ibm.kpiviewer;


public class KPIConstants {
	public static String _SCHEMANAME = "EGOV.";
	public static final String MESSAGE_TYPE_INFORMATION = "I";
	public static final String MESSAGE_TYPE_WARNING = "W";
	public static final String MESSAGE_TYPE_ERROR = "E";
	
	public static String _PRODUCT_NAME = "kpiviewer";
	public static String _PRODUCT_VERSION = "1.0";
	public static String _OFFICIALMAILSENDER = null;
	
	public static final String MODE_INDICATOR_VALUES = "1";
	public static final String MODE_SECTORS = "2";
}
