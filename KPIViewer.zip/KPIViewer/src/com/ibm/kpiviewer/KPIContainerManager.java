package com.ibm.kpiviewer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.ResourceBundle;

import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;

import com.ibm.kpi.bean.Container;
import com.ibm.kpi.dbo.KPIIndicator;
import com.ibm.kpi.dbo.KPIIndicatorValue;
import com.ibm.kpi.dbo.KPISector;
import com.ibm.kpi.management.IndicatorManagement;
import com.ibm.kpi.management.IndicatorValueManagement;
import com.ibm.kpi.management.SectorManagement;
import com.ibm.kpi.utils.KPIUtils;

public class KPIContainerManager {

	public static void process(RenderRequest request, RenderResponse response, ResourceBundle bundle, KPIPortletSessionBean sessionBean) {
		Container container = sessionBean.getContainer().get(sessionBean.getCurrentPage());
		if (container == null) {
			container = new Container();
		}
		if (KPIViewerPortlet.SECTORS_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			processSectorListPage(container, sessionBean);
		} else if (KPIViewerPortlet.INDICATORS_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			processIndicatorListPage(container, sessionBean);
		} else if (KPIViewerPortlet.INDICATOR_STATISTICS_PAGE.equals(sessionBean.getCurrentPage())) {
			processIndicatorGraphicPage(request, container, sessionBean);
		} else if (KPIViewerPortlet.INDICATOR_VALUES_LIST_PAGE.equals(sessionBean.getCurrentPage())) {
			processIndicatorValueListPage(container, request, sessionBean);
		} else if (KPIViewerPortlet.INDICATOR_VALUE_PREVIEW_PAGE.equals(sessionBean.getCurrentPage())) {
			processIndicatorValuePreviewPage(container, sessionBean);
		}
	}

	private static void processSectorListPage(Container container, KPIPortletSessionBean sessionBean) {
		int navigatorPage = container.getNavigatorPage();
		int totalPages = container.getNavigatorTotalPages();
		container.clearObject();
		SectorManagement sectorManagement = new SectorManagement();
		if (sectorManagement.loadAllKPISectorsByFilter(container.getFilterType(), container.getFilterValue(), container.getFilterValue2()) > 0) {
			KPISector[] kpiSectors = sectorManagement.getKPISectors();
			navigatorPage = KPIUtils.getCurrentPageNumber(kpiSectors.length, navigatorPage, KPIViewerPortlet.resultsPerPage);
			totalPages = KPIUtils.getTotalPages(kpiSectors.length, KPIViewerPortlet.resultsPerPage);
			ArrayList<Object> filteredKPISectors = KPINavigatorManager.filterResults(kpiSectors, KPIViewerPortlet.resultsPerPage, navigatorPage);
			container.setResults((KPISector[]) filteredKPISectors.toArray(new KPISector[filteredKPISectors.size()]));
		} else {
			navigatorPage = 1;
			totalPages = 1;
		}
		container.setNavigatorPage(navigatorPage);
		container.setNavigatorTotalPages(totalPages);
		sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
	}

	private static void processIndicatorListPage(Container container, KPIPortletSessionBean sessionBean) {
		int navigatorPage = container.getNavigatorPage();
		int totalPages = container.getNavigatorTotalPages();
		container.clearObject();
		SectorManagement sectorManagement = new SectorManagement();
		if (sectorManagement.loadKPISectorById(container.getId(), null) == 1) {
			container.setObject(sectorManagement.getCurrentKPISector());
		}
		IndicatorManagement indicatorManagement = new IndicatorManagement();
		if (indicatorManagement.loadAllKPIIndicatorsByFilter(container.getId(), container.getFilterType(), container.getFilterValue(), container.getFilterValue2()) > 0) {
			KPIIndicator[] kpiIndicators = indicatorManagement.getKPIIndicators();
			navigatorPage = KPIUtils.getCurrentPageNumber(kpiIndicators.length, navigatorPage, KPIViewerPortlet.resultsPerPage);
			totalPages = KPIUtils.getTotalPages(kpiIndicators.length, KPIViewerPortlet.resultsPerPage);
			ArrayList<Object> filteredKPIIndicators = KPINavigatorManager.filterResults(kpiIndicators, KPIViewerPortlet.resultsPerPage, navigatorPage);
			container.setResults((KPIIndicator[]) filteredKPIIndicators.toArray(new KPIIndicator[filteredKPIIndicators.size()]));
		} else {
			navigatorPage = 1;
			totalPages = 1;
		}
		container.setNavigatorPage(navigatorPage);
		container.setNavigatorTotalPages(totalPages);
		sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
	}

	private static void processIndicatorGraphicPage(RenderRequest request, Container container, KPIPortletSessionBean sessionBean) {
		container.clearObject();
		String[] indicatorIds = request.getParameterValues("indicatorId");
		if (indicatorIds != null && indicatorIds.length > 0) {
			StringBuffer indIds = new StringBuffer();
			for (int i = 0; i < indicatorIds.length; i++) {
				if (indIds.toString().length() > 0) {
					indIds.append(",");
				}
				indIds.append(indicatorIds[i]);
			}
			IndicatorManagement indicatorManagement = new IndicatorManagement();
			if (indicatorManagement.loadAllKPIIndicatorsByIds(indIds.toString(), null) > 0) {
				IndicatorValueManagement indicatorValueManagement = new IndicatorValueManagement();
				if (indicatorValueManagement.loadAllKPIIndicatorValuesByIndicatorIds(indIds.toString(), null) > 0) {
					HashMap<String, ArrayList<KPIIndicatorValue>> tmpHm = new HashMap<String, ArrayList<KPIIndicatorValue>>();
					ArrayList<KPIIndicatorValue> tmpArr = null;
					ArrayList<String> targetDatesArr = new ArrayList<String>();
					String currentTargetDate = null;
					for (int i = 0; i < indicatorValueManagement.getKPIIndicatorValues().length; i++) {
						tmpArr = tmpHm.get(indicatorValueManagement.getKPIIndicatorValues()[i].getKpiIndicatorId());
						if (tmpArr == null) {
							tmpArr = new ArrayList<KPIIndicatorValue>();
						}
						tmpArr.add(indicatorValueManagement.getKPIIndicatorValues()[i]);
						tmpHm.put(indicatorValueManagement.getKPIIndicatorValues()[i].getKpiIndicatorId(), tmpArr);
						currentTargetDate = KPIUtils.timeMillisToYYYY_MM_DD(indicatorValueManagement.getKPIIndicatorValues()[i].getTargetDate().getTime());
						if (!targetDatesArr.contains(currentTargetDate)) {
							targetDatesArr.add(currentTargetDate);
						}
					}
					for (int i = 0; i < indicatorManagement.getKPIIndicators().length; i++) {
						tmpArr = tmpHm.get(indicatorManagement.getKPIIndicators()[i].getId());
						if (tmpArr != null && tmpArr.size() > 0) {
							indicatorManagement.getKPIIndicators()[i].setIndicatorValues((KPIIndicatorValue[]) tmpArr.toArray(new KPIIndicatorValue[tmpArr.size()]));
						}
					}
					ArrayList<KPIIndicator> tmpIndicators = new ArrayList<KPIIndicator>();
					for (int i = 0; i < indicatorManagement.getKPIIndicators().length; i++) {
						if (indicatorManagement.getKPIIndicators()[i].getIndicatorValues() != null && indicatorManagement.getKPIIndicators()[i].getIndicatorValues().length > 0) {
							tmpIndicators.add(indicatorManagement.getKPIIndicators()[i]);
						}
					}
					indicatorManagement.setKPIIndicators((KPIIndicator[]) tmpIndicators.toArray(new KPIIndicator[tmpIndicators.size()]));
					container.setResults(prepareForGraphic(indicatorManagement.getKPIIndicators(), targetDatesArr));
					ArrayList<Object> data = new ArrayList<Object>();
					data.add(targetDatesArr);
					container.setData(data);
				}
			}
		}
		sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
	}

	private static void processIndicatorValueListPage(Container container, RenderRequest renderRequest, KPIPortletSessionBean sessionBean) {
		int navigatorPage = container.getNavigatorPage();
		int totalPages = container.getNavigatorTotalPages();
		container.clearObject();
		if (container.getId() != null) {
			IndicatorManagement indicatorManagement = new IndicatorManagement();
			if (indicatorManagement.loadKPIIndicatorById(container.getId(), null) == 1) {
				container.setObject(indicatorManagement.getCurrentKPIIndicator());
			}
		}
		IndicatorValueManagement indicatorValueManagement = new IndicatorValueManagement();
		if (KPIConstants.MODE_SECTORS.equals(KPIViewerPortlet.mode)) {
			if (indicatorValueManagement.loadAllKPIIndicatorValuesByFilterSectors(container.getId(), container.getFilterType(), container.getFilterValue(), container.getFilterValue2()) > 0) {
				KPIIndicatorValue[] kpiIndicatorValues = indicatorValueManagement.getKPIIndicatorValues();
				navigatorPage = KPIUtils.getCurrentPageNumber(kpiIndicatorValues.length, navigatorPage, KPIViewerPortlet.resultsPerPage);
				totalPages = KPIUtils.getTotalPages(kpiIndicatorValues.length, KPIViewerPortlet.resultsPerPage);
				ArrayList<Object> filteredKPIIndicatorValues = KPINavigatorManager.filterResults(kpiIndicatorValues, KPIViewerPortlet.resultsPerPage, navigatorPage);
				container.setResults((KPIIndicatorValue[]) filteredKPIIndicatorValues.toArray(new KPIIndicatorValue[filteredKPIIndicatorValues.size()]));
			} else {
				navigatorPage = 1;
				totalPages = 1;
			}
		} else {
			if (indicatorValueManagement.loadAllKPIIndicatorValuesByFilterIndicators(container.getId(), container.getFilterType(), container.getFilterValue(), container.getFilterValue2()) > 0) {
				KPIIndicatorValue[] kpiIndicatorValues = indicatorValueManagement.getKPIIndicatorValues();
				navigatorPage = KPIUtils.getCurrentPageNumber(kpiIndicatorValues.length, navigatorPage, KPIViewerPortlet.resultsPerPage);
				totalPages = KPIUtils.getTotalPages(kpiIndicatorValues.length, KPIViewerPortlet.resultsPerPage);
				ArrayList<Object> filteredKPIIndicatorValues = KPINavigatorManager.filterResults(kpiIndicatorValues, KPIViewerPortlet.resultsPerPage, navigatorPage);
				container.setResults((KPIIndicatorValue[]) filteredKPIIndicatorValues.toArray(new KPIIndicatorValue[filteredKPIIndicatorValues.size()]));
			} else {
				navigatorPage = 1;
				totalPages = 1;
			}
		}
		container.setNavigatorPage(navigatorPage);
		container.setNavigatorTotalPages(totalPages);
		sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
	}

	private static void processIndicatorValuePreviewPage(Container container, KPIPortletSessionBean sessionBean) {
		int navigatorPage = container.getNavigatorPage();
		int totalPages = container.getNavigatorTotalPages();
		container.clearObject();
		IndicatorValueManagement indicatorValueManagement = new IndicatorValueManagement();
		if (indicatorValueManagement.loadKPIIndicatorValueWithAttachmentsById(container.getId(), null) == 1) {
			container.setObject(indicatorValueManagement.getCurrentKPIIndicatorValue());
		} else {
			navigatorPage = 1;
			totalPages = 1;
		}
		container.setNavigatorPage(navigatorPage);
		container.setNavigatorTotalPages(totalPages);
		sessionBean.getContainer().put(sessionBean.getCurrentPage(), container);
	}

	private static KPIIndicator[] prepareForGraphic(KPIIndicator[] indicators, ArrayList<String> targetDatesArr) {
		if (indicators != null && targetDatesArr != null && targetDatesArr.size() > 0) {
			KPIIndicator indicator = null;
			KPIIndicatorValue indicatorValue = null;
			KPIIndicatorValue tmpIndicatorValue = null;
			KPIIndicatorValue[] indicatorValues = null;
			HashMap<String, ArrayList<Object>> tmpHm = null;
			ArrayList<Object> tmpArr = null;
			ArrayList<KPIIndicatorValue> indicatorValuesArr = null;
			int index = 0;
			for (int i = 0; i < indicators.length; i++) {
				indicator = indicators[i];
				indicatorValues = indicator.getIndicatorValues();
				if (indicatorValues != null && indicatorValues.length > 0) {
					tmpHm = new HashMap<String, ArrayList<Object>>();
					for (int j = 0; j < indicatorValues.length; j++) {
						tmpArr = new ArrayList<Object>();
						tmpArr.add(j);
						tmpArr.add(indicatorValues[j]);
						tmpHm.put(KPIUtils.timeMillisToYYYY_MM_DD(indicatorValues[j].getTargetDate().getTime()), tmpArr);
					}
					indicatorValuesArr = new ArrayList<KPIIndicatorValue>();
					index = 0;
					for (int j = 0; j < targetDatesArr.size(); j++) {
						indicatorValue = null;
						if (tmpHm.get(targetDatesArr.get(j)) != null) { // DATE MATCH...
							tmpArr = tmpHm.get(targetDatesArr.get(j));
							indicatorValue = (KPIIndicatorValue) tmpArr.get(1);
							indicatorValuesArr.add(indicatorValue);
							index = (Integer) tmpArr.get(0);
						} else { // DATE NOT MATCH...
							if (KPIUtils.date_yyyy_MM_dd_ToTimeMillis(targetDatesArr.get(j), true) < indicatorValues[0].getTargetDate().getTime()) {
								indicatorValue = indicatorValues[index];
							} else {
								indicatorValue = (indicatorValuesArr.size() > 0) ? indicatorValuesArr.get(indicatorValuesArr.size() - 1) : indicatorValues[0];
							}
							tmpIndicatorValue = new KPIIndicatorValue();
							tmpIndicatorValue.setId(indicatorValue.getId());
							tmpIndicatorValue.setKpiIndicatorId(indicatorValue.getKpiIndicatorId());
							tmpIndicatorValue.setValue(indicatorValue.getValue());
							tmpIndicatorValue.setComments(indicatorValue.getComments());
							tmpIndicatorValue.setTargetDate(KPIUtils.timeMillisToTimestamp(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(targetDatesArr.get(j), true)));
							tmpIndicatorValue.setUserDN(indicatorValue.getUserDN());
							tmpIndicatorValue.setCreationDate(KPIUtils.timeMillisToTimestamp(indicatorValue.getCreationDate().getTime()));
							indicatorValuesArr.add(tmpIndicatorValue);
						}
					}
					indicators[i].setIndicatorValues((KPIIndicatorValue[]) indicatorValuesArr.toArray(new KPIIndicatorValue[indicatorValuesArr.size()]));
				}
			}
		}
		return indicators;
	}
}
