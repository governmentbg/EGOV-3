package com.ibm.kpi.management;

import java.sql.SQLException;

import com.ibm.kpi.db.DBTransaction;
import com.ibm.kpi.db.FinderException;
import com.ibm.kpi.db.QueryExecution;
import com.ibm.kpi.dbo.KPIIndicator;
import com.ibm.kpi.dbo.KPIIndicatorHit;
import com.ibm.kpi.dbo.KPISectorIndicator;
import com.ibm.kpi.utils.KPIUtils;

public class IndicatorManagement {

	private KPIIndicator[] indicators = null;
	private int indicatorCounter = 0;
	private KPIIndicator current = null;

	public int getKPIIndicatorCounter() {
		return indicatorCounter;
	}

	public void setKPIIndicatorCounter(int indicatorCounter) {
		this.indicatorCounter = indicatorCounter;
	}

	public void setCurrentKPIIndicator(KPIIndicator object) {
		current = object;
	}

	public KPIIndicator getCurrentKPIIndicator() {
		if (current == null)
			current = new KPIIndicator();
		return current;
	}

	public boolean selectNextKPIIndicator() {
		if (indicators != null) {
			if (indicatorCounter < indicators.length) {
				setCurrentKPIIndicator(indicators[indicatorCounter++]);
				return true;
			}
		}
		return false;
	}

	public int loadKPIIndicatorById(String kpiIndicatorId, DBTransaction transaction) {
		try {
			KPIIndicator tmpKPIIndicator = KPIIndicator.findById(kpiIndicatorId, transaction);
			if (tmpKPIIndicator != null) {
				setCurrentKPIIndicator(tmpKPIIndicator);
				return 1;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			System.out.println("KPIIndicatorManagement : loadKPIIndicatorById : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

	public int loadKPIIndicatorWithSectorsById(String kpiIndicatorId, DBTransaction transaction) {
		try {
			KPIIndicator tmpKPIIndicator = KPIIndicator.findById(kpiIndicatorId, transaction);
			if (tmpKPIIndicator != null) {
				KPISectorIndicator[] kpiSectorIndicators = null;
				try {
					kpiSectorIndicators = KPISectorIndicator.findAllByIndicatorIds(kpiIndicatorId, transaction);
				} catch (FinderException e) {
				}
				if (kpiSectorIndicators != null) {
					tmpKPIIndicator.setSectorIndicators(kpiSectorIndicators);
					setCurrentKPIIndicator(tmpKPIIndicator);
					return 1;
				}
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			System.out.println("KPIIndicatorManagement : loadKPIIndicatorWithSectorsById : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

	public int loadAllKPIIndicators() {
		try {
			indicatorCounter = 0;
			indicators = null;
			indicators = KPIIndicator.findAll(null);
			if (indicators != null) {
				indicatorCounter = 0;
				return indicators.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("KPIIndicatorManagement : loadAllKPIIndicators : " + e.getMessage());
		}
		return -1;
	}

	public int loadAllKPIIndicatorsByIds(String ids, DBTransaction transaction) {
		try {
			indicatorCounter = 0;
			indicators = null;
			indicators = KPIIndicator.findAllByIds(ids, transaction);
			if (indicators != null) {
				indicatorCounter = 0;
				return indicators.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("KPIIndicatorManagement : loadAllKPIIndicatorsByIds : " + e.getMessage());
		}
		return -1;
	}

	public int loadAllKPIIndicatorsByFilter(String sectorId, String filterType, String filterValue, String filterValue2) {
		DBTransaction transaction = null;
		try {
			transaction = new DBTransaction();
			indicatorCounter = 0;
			indicators = null;
			if ("4".equals(filterType)) {
				if (filterValue != null && filterValue.trim().length() > 0) {
					filterValue = KPIUtils.timeMillisToTimestamp(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(filterValue.trim(), true));
				}
				if (filterValue2 != null && filterValue2.trim().length() > 0) {
					filterValue2 = KPIUtils.timeMillisToTimestamp(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(filterValue2.trim(), false));
				}
				QueryExecution.setSessionTimestampFormat(transaction);
			}
			StringBuffer indicatorIds = null;
			if (sectorId != null && sectorId.trim().length() > 0) {
				indicatorIds = new StringBuffer();
				KPISectorIndicator[] kpiSectorIndicators = null;
				try {
					kpiSectorIndicators = KPISectorIndicator.findAllBySectorId(sectorId, transaction);
				} catch (FinderException e) {
				}
				if (kpiSectorIndicators != null && kpiSectorIndicators.length > 0) {
					for (int i = 0; i < kpiSectorIndicators.length; i++) {
						if (indicatorIds.toString().length() > 0) {
							indicatorIds.append(",");
						}
						indicatorIds.append(kpiSectorIndicators[i].getKpiIndicatorId());
					}
				} else {
					indicatorIds.append("0"); // SET ID TO NON EXISTING WHEN THERE IS NO INDICATORS FOUND FOR CURRENT SECTOR
				}
			}
			indicators = KPIIndicator.findAllByFilter((indicatorIds != null) ? indicatorIds.toString() : null, filterType, filterValue, filterValue2, transaction);
			transaction.commit();
			if (indicators != null) {
				indicatorCounter = 0;
				return indicators.length;
			}
		} catch (FinderException e) {
			if (transaction != null) {
				try {
					transaction.commit();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			return 0;
		} catch (Exception e) {
			if (transaction != null) {
				try {
					transaction.commit();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			e.printStackTrace();
			System.out.println("KPIIndicatorManagement : loadAllKPIIndicators : " + e.getMessage());
		}
		return -1;
	}

	public void addIndicatorsHit(KPIIndicator[] indicators, String ip) {
		if (indicators == null || indicators.length == 0) {
			return;
		}
		KPIIndicatorHit kpiIndicatorHit = null;
		DBTransaction transaction = null;
		long currentTime = System.currentTimeMillis();
		try {
			transaction = new DBTransaction();
			for (int i = 0; i < indicators.length; i++) {
				kpiIndicatorHit = new KPIIndicatorHit();
				kpiIndicatorHit.setKpiIndicatorId(indicators[i].getId());
				kpiIndicatorHit.setIp(ip);
				kpiIndicatorHit.setCreationDate(KPIUtils.timeMillisToTimestamp(currentTime));
				kpiIndicatorHit.create(transaction);
			}
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				try {
					transaction.commit();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			e.printStackTrace();
			System.out.println("IndicatorManagement : addIndicatorsHit : " + e.getMessage());
		}
	}

	public KPIIndicator[] getKPIIndicators() {
		return indicators;
	}

	public void setKPIIndicators(KPIIndicator[] indicators) {
		this.indicators = indicators;
	}

}
