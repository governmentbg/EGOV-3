package com.ibm.kpi.management;

import java.sql.SQLException;

import com.ibm.kpi.db.DBTransaction;
import com.ibm.kpi.db.FinderException;
import com.ibm.kpi.db.QueryExecution;
import com.ibm.kpi.dbo.KPISector;
import com.ibm.kpi.utils.KPIUtils;

public class SectorManagement {
	
	private KPISector[] sectors = null;
	private int sectorCounter = 0;
	private KPISector current = null;

	public int getKPISectorCounter() {
		return sectorCounter;
	}

	public void setKPISectorCounter(int sectorCounter) {
		this.sectorCounter = sectorCounter;
	}

	public void setCurrentKPISector(KPISector object) {
		current = object;
	}

	public KPISector getCurrentKPISector() {
		if (current == null)
			current = new KPISector();
		return current;
	}

	public boolean selectNextKPISector() {
		if (sectors != null) {
			if (sectorCounter < sectors.length) {
				setCurrentKPISector(sectors[sectorCounter++]);
				return true;
			}
		}
		return false;
	}

	public int loadKPISectorById(String kpiSectorId, DBTransaction transaction) {
		try {
			KPISector tmpKPISector = KPISector.findById(kpiSectorId, transaction);
			if (tmpKPISector != null) {
				setCurrentKPISector(tmpKPISector);
				return 1;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			System.out.println("KPISectorManagement : loadKPISectorById : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

	public int loadAllKPISectors() {
		try {
			sectorCounter = 0;
			sectors = null;
			sectors = KPISector.findAll(null);
			if (sectors != null) {
				sectorCounter = 0;
				return sectors.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("KPISectorManagement : loadAllKPISectors : " + e.getMessage());
		}
		return -1;
	}

	public int loadAllKPISectorsByFilter(String filterType, String filterValue, String filterValue2) {
		DBTransaction transaction = null;
		try {
			transaction = new DBTransaction();
			sectorCounter = 0;
			sectors = null;
			if ("2".equals(filterType)) {
				if (filterValue != null && filterValue.trim().length() > 0) {
					filterValue = KPIUtils.timeMillisToTimestamp(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(filterValue.trim(), true));
				}
				if (filterValue2 != null && filterValue2.trim().length() > 0) {
					filterValue2 = KPIUtils.timeMillisToTimestamp(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(filterValue2.trim(), false));
				}
				QueryExecution.setSessionTimestampFormat(transaction);
			}
			sectors = KPISector.findAllByFilter(filterType, filterValue, filterValue2, transaction);
			transaction.commit();
			if (sectors != null) {
				sectorCounter = 0;
				return sectors.length;
			}
		} catch (FinderException e) {
			if (transaction != null) {
				try {
					transaction.commit();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			return 0;
		} catch (Exception e) {
			if (transaction != null) {
				try {
					transaction.commit();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			e.printStackTrace();
			System.out.println("KPISectorManagement : loadAllKPISectors : " + e.getMessage());
		}
		return -1;
	}

	public KPISector[] getKPISectors() {
		return sectors;
	}

	public void setKPISectors(KPISector[] sectors) {
		this.sectors = sectors;
	}

}
