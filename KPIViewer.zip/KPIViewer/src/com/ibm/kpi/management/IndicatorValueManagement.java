package com.ibm.kpi.management;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import com.ibm.kpi.db.DBTransaction;
import com.ibm.kpi.db.FinderException;
import com.ibm.kpi.db.QueryExecution;
import com.ibm.kpi.dbo.KPIAttachment;
import com.ibm.kpi.dbo.KPIIndicator;
import com.ibm.kpi.dbo.KPIIndicatorHit;
import com.ibm.kpi.dbo.KPIIndicatorValue;
import com.ibm.kpi.utils.KPIUtils;

public class IndicatorValueManagement {

	private KPIIndicatorValue[] indicatorValues = null;
	private int indicatorValueCounter = 0;
	private KPIIndicatorValue current = null;

	public int getKPIIndicatorValueCounter() {
		return indicatorValueCounter;
	}

	public void setKPIIndicatorValueCounter(int indicatorValueCounter) {
		this.indicatorValueCounter = indicatorValueCounter;
	}

	public void setCurrentKPIIndicatorValue(KPIIndicatorValue object) {
		current = object;
	}

	public KPIIndicatorValue getCurrentKPIIndicatorValue() {
		if (current == null)
			current = new KPIIndicatorValue();
		return current;
	}

	public boolean selectNextKPIIndicatorValue() {
		if (indicatorValues != null) {
			if (indicatorValueCounter < indicatorValues.length) {
				setCurrentKPIIndicatorValue(indicatorValues[indicatorValueCounter++]);
				return true;
			}
		}
		return false;
	}

	public int loadKPIIndicatorValueById(String kpiIndicatorValueId, DBTransaction transaction) {
		try {
			KPIIndicatorValue tmpKPIIndicatorValue = KPIIndicatorValue.findById(kpiIndicatorValueId, transaction);
			if (tmpKPIIndicatorValue != null) {
				setCurrentKPIIndicatorValue(tmpKPIIndicatorValue);
				return 1;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			System.out.println("KPIIndicatorValueManagement : loadKPIIndicatorValueById : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

	public int loadKPIIndicatorValueWithAttachmentsById(String kpiIndicatorValueId, DBTransaction transaction) {
		try {
			KPIIndicatorValue tmpKPIIndicatorValue = KPIIndicatorValue.findById(kpiIndicatorValueId, transaction);
			if (tmpKPIIndicatorValue != null) {
				KPIAttachment[] kpiAttachments = null;
				try {
					kpiAttachments = QueryExecution.findAllKPIAttachmentsByIndicatorValueId(kpiIndicatorValueId, transaction);
				} catch (FinderException e) {
				}
				if (kpiAttachments != null) {
					tmpKPIIndicatorValue.setAttachments(kpiAttachments);
					setCurrentKPIIndicatorValue(tmpKPIIndicatorValue);
					return 1;
				}
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			System.out.println("KPIIndicatorValueManagement : loadKPIIndicatorValueWithAttachmentsById : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

	public int loadAllKPIIndicatorValues() {
		try {
			indicatorValueCounter = 0;
			indicatorValues = null;
			indicatorValues = KPIIndicatorValue.findAll(null);
			if (indicatorValues != null) {
				indicatorValueCounter = 0;
				return indicatorValues.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("KPIIndicatorValueManagement : loadAllKPIIndicatorValues : " + e.getMessage());
		}
		return -1;
	}

	public int loadAllKPIIndicatorValuesByIndicatorIds(String indicatorIds, DBTransaction transaction) {
		try {
			indicatorValueCounter = 0;
			indicatorValues = null;
			indicatorValues = KPIIndicatorValue.findAllByIndicatorIds(indicatorIds, transaction);
			if (indicatorValues != null) {
				indicatorValueCounter = 0;
				return indicatorValues.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("KPIIndicatorValueManagement : loadAllKPIIndicatorValuesByIndicatorIds : " + e.getMessage());
		}
		return -1;
	}

	public int loadAllKPIIndicatorValuesByFilterSectors(String indicatorId, String filterType, String filterValue, String filterValue2) {
		DBTransaction transaction = null;
		try {
			transaction = new DBTransaction();
			indicatorValueCounter = 0;
			indicatorValues = null;
			if ("2".equals(filterType)) {
				if (filterValue != null && filterValue.trim().length() > 0) {
					filterValue = KPIUtils.timeMillisToTimestamp(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(filterValue.trim(), true));
				}
				if (filterValue2 != null && filterValue2.trim().length() > 0) {
					filterValue2 = KPIUtils.timeMillisToTimestamp(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(filterValue2.trim(), false));
				}
				QueryExecution.setSessionTimestampFormat(transaction);
			}
			indicatorValues = KPIIndicatorValue.findAllByFilter(indicatorId, filterType, filterValue, filterValue2, transaction);
			transaction.commit();
			if (indicatorValues != null) {
				indicatorValueCounter = 0;
				return indicatorValues.length;
			}
		} catch (FinderException e) {
			if (transaction != null) {
				try {
					transaction.commit();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			return 0;
		} catch (Exception e) {
			if (transaction != null) {
				try {
					transaction.commit();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			e.printStackTrace();
			System.out.println("KPIIndicatorValueManagement : loadAllKPIIndicatorValues : " + e.getMessage());
		}
		return -1;
	}

	public int loadAllKPIIndicatorValuesByFilterIndicators(String indicatorId, String filterType, String filterValue, String filterValue2) {
		DBTransaction transaction = null;
		try {
			transaction = new DBTransaction();
			indicatorValueCounter = 0;
			indicatorValues = null;
			if ("2".equals(filterType)) {
				if (filterValue != null && filterValue.trim().length() > 0) {
					filterValue = KPIUtils.timeMillisToTimestamp(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(filterValue.trim(), true));
				}
				if (filterValue2 != null && filterValue2.trim().length() > 0) {
					filterValue2 = KPIUtils.timeMillisToTimestamp(KPIUtils.date_yyyy_MM_dd_ToTimeMillis(filterValue2.trim(), false));
				}
				QueryExecution.setSessionTimestampFormat(transaction);
			}
			indicatorValues = KPIIndicatorValue.findAllByFilterIndicatorsFilter(indicatorId, filterType, filterValue, filterValue2, transaction);
			if (indicatorValues != null && indicatorValues.length > 0) {
				KPIIndicator[] kpiIndicators = null;
				HashMap<String, String> tmp = new HashMap<String, String>();
				String indicatorName = null;
				if ("3".equals(filterType) && filterValue != null && filterValue.trim().length() > 0) { // INDICATOR NAME
					try {
						if (filterValue != null && filterValue.trim().length() > 0) {
							kpiIndicators = KPIIndicator.findAllByName(filterValue.trim(), transaction);
						}
					} catch (FinderException e) {
					}
					if (kpiIndicators != null && kpiIndicators.length > 0) {
						tmp = new HashMap<String, String>();
						for (int i = 0; i < kpiIndicators.length; i++) {
							tmp.put(kpiIndicators[i].getId(), kpiIndicators[i].getIndicatorName());
						}
						ArrayList<KPIIndicatorValue> tmpArr = new ArrayList<KPIIndicatorValue>();
						for (int i = 0; i < indicatorValues.length; i++) {
							indicatorName = tmp.get(indicatorValues[i].getKpiIndicatorId());
							if (indicatorName != null) {
								indicatorValues[i].setIndicatorName(indicatorName);
								tmpArr.add(indicatorValues[i]);
							}
						}
						indicatorValues = (tmpArr.size() > 0) ? (KPIIndicatorValue[])tmpArr.toArray(new KPIIndicatorValue[tmpArr.size()]) : null;
					}
				} else {
					StringBuffer indicatorIds = new StringBuffer();
					for (int i = 0; i < indicatorValues.length; i++) {
						if (tmp.get(indicatorValues[i].getKpiIndicatorId()) == null) {
							tmp.put(indicatorValues[i].getKpiIndicatorId(), "1");
							if (indicatorIds.toString().length() > 0) {
								indicatorIds.append(",");
							}
							indicatorIds.append(indicatorValues[i].getKpiIndicatorId());
						}
					}
					try {
						kpiIndicators = KPIIndicator.findAllByIds(indicatorIds.toString(), transaction);
					} catch (FinderException e) {
					}
					if (kpiIndicators != null && kpiIndicators.length > 0) {
						tmp = new HashMap<String, String>();
						for (int i = 0; i < kpiIndicators.length; i++) {
							tmp.put(kpiIndicators[i].getId(), kpiIndicators[i].getIndicatorName());
						}
					}					
					for (int i = 0; i < indicatorValues.length; i++) {
						indicatorName = tmp.get(indicatorValues[i].getKpiIndicatorId());
						if (indicatorName != null) {
							indicatorValues[i].setIndicatorName(indicatorName);
						}
					}
				}
			}
			transaction.commit();
			if (indicatorValues != null) {
				indicatorValueCounter = 0;
				return indicatorValues.length;
			}
		} catch (FinderException e) {
			if (transaction != null) {
				try {
					transaction.commit();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			return 0;
		} catch (Exception e) {
			if (transaction != null) {
				try {
					transaction.commit();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			e.printStackTrace();
			System.out.println("KPIIndicatorValueManagement : loadAllKPIIndicatorValuesByFilterIndicators : " + e.getMessage());
		}
		return -1;
	}

	public void addIndicatorsHit(KPIIndicatorValue[] indicatorValues, String ip) {
		if (indicatorValues == null || indicatorValues.length == 0) {
			return;
		}
		KPIIndicatorHit kpiIndicatorHit = null;
		DBTransaction transaction = null;
		long currentTime = System.currentTimeMillis();
		try {
			HashMap<String, String> tmp = new HashMap<String, String>();
			transaction = new DBTransaction();
			for (int i = 0; i < indicatorValues.length; i++) {
				if (tmp.get(indicatorValues[i].getKpiIndicatorId()) == null) {
					kpiIndicatorHit = new KPIIndicatorHit();
					kpiIndicatorHit.setKpiIndicatorId(indicatorValues[i].getKpiIndicatorId());
					kpiIndicatorHit.setIp(ip);
					kpiIndicatorHit.setCreationDate(KPIUtils.timeMillisToTimestamp(currentTime));
					kpiIndicatorHit.create(transaction);
					tmp.put(indicatorValues[i].getKpiIndicatorId(), "1");
				}
			}
			transaction.commit();
		} catch (Exception e) {
			if (transaction != null) {
				try {
					transaction.commit();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
			e.printStackTrace();
			System.out.println("IndicatorValueManagement : addIndicatorsHit : " + e.getMessage());
		}
	}

	public KPIIndicatorValue[] getKPIIndicatorValues() {
		return indicatorValues;
	}

	public void setKPIIndicatorValues(KPIIndicatorValue[] indicatorValues) {
		this.indicatorValues = indicatorValues;
	}

}
