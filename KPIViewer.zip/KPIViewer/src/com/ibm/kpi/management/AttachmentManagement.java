package com.ibm.kpi.management;

import com.ibm.kpi.db.DBTransaction;
import com.ibm.kpi.db.FinderException;
import com.ibm.kpi.dbo.KPIAttachment;

public class AttachmentManagement {
	
	private KPIAttachment[] attachments = null;
	private int attachmentCounter = 0;
	private KPIAttachment current = null;

	public int getKPIAttachmentCounter() {
		return attachmentCounter;
	}

	public void setKPIAttachmentCounter(int attachmentCounter) {
		this.attachmentCounter = attachmentCounter;
	}

	public void setCurrentKPIAttachment(KPIAttachment object) {
		current = object;
	}

	public KPIAttachment getCurrentKPIAttachment() {
		if (current == null)
			current = new KPIAttachment();
		return current;
	}

	public boolean selectNextKPIAttachment() {
		if (attachments != null) {
			if (attachmentCounter < attachments.length) {
				setCurrentKPIAttachment(attachments[attachmentCounter++]);
				return true;
			}
		}
		return false;
	}

	public int loadKPIAttachmentById(String kpiAttachmentId, DBTransaction transaction) {
		try {
			KPIAttachment tmpKPIAttachment = KPIAttachment.findById(kpiAttachmentId, transaction);
			if (tmpKPIAttachment != null) {
				setCurrentKPIAttachment(tmpKPIAttachment);
				return 1;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			System.out.println("KPIAttachmentManagement : loadKPIAttachmentById : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

	public int loadAllKPIAttachments() {
		try {
			attachmentCounter = 0;
			attachments = null;
			attachments = KPIAttachment.findAll(null);
			if (attachments != null) {
				attachmentCounter = 0;
				return attachments.length;
			}
		} catch (FinderException e) {
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("KPIAttachmentManagement : loadAllKPIAttachments : " + e.getMessage());
		}
		return -1;
	}

	public KPIAttachment[] getKPIAttachments() {
		return attachments;
	}

	public void setKPIAttachments(KPIAttachment[] attachments) {
		this.attachments = attachments;
	}

}
