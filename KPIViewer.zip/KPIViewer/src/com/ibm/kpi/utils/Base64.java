package com.ibm.kpi.utils;

public class Base64 {
	
		// private property
		public static String _keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";

		// public method for encoding
		public static String encode(String input) {
			String output = "";
			int chr2 = 0;
			int chr3 = 0;
			int enc2 = 0;
			int enc3 = 0;
			int enc4 = 0;
			int chr1, enc1;
			int i = 0;

			input = _utf8_encode(input);
			while (i < input.toCharArray().length) {
				chr1 = 0;
				chr2 = 0;
				chr3 = 0;
				enc1 = 0;
				enc2 = 0;
				enc3 = 0;
				enc4 = 0;
				
				chr1 = input.charAt(i++);
				try {
					chr2 = input.charAt(i++);
				} catch (Exception e) {
					chr2 = -1;
				}
				try {
					chr3 = input.charAt(i++);
				} catch (Exception e) {
					chr3 = -1;
				}				
				enc1 = chr1 >> 2;	
				if (chr2 == -1)
					enc2 = ((chr1 & 3) << 4);
				else 
					enc2 = ((chr1 & 3) << 4) | (chr2 >> 4);
				if (chr3 == -1)
					enc3 = ((chr2 & 15) << 2);
				else  {
					enc3 = ((chr2 & 15) << 2) | (chr3 >> 6);		
					enc4 = chr3 & 63;
				}	
				if (chr2 == -1) {
					enc3 = enc4 = 64;
				} else if (chr3 == -1) {
					enc4 = 64;
				}
				output = output + _keyStr.charAt(enc1);
					output+= _keyStr.charAt(enc2);
					output += _keyStr.charAt(enc3);
				output +=_keyStr.charAt(enc4);

			}
			return output;
		}

		// public method for decoding
		public static String decode (String input) {
			String output = "";
			int chr1, chr2, chr3;
			int enc1, enc2, enc3, enc4;
			int i = 0;

			input = input.replaceAll("/[^A-Za-z0-9\\+\\/\\=]/g", "");

			while (i < input.toCharArray().length) {

				enc1 = _keyStr.indexOf(input.charAt(i++));
				enc2 = _keyStr.indexOf(input.charAt(i++));
				enc3 = _keyStr.indexOf(input.charAt(i++));
				enc4 = _keyStr.indexOf(input.charAt(i++));

				chr1 = (enc1 << 2) | (enc2 >> 4);
				chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
				chr3 = ((enc3 & 3) << 6) | enc4;

				output = output + new Character((char)(chr1)).toString();

				if (enc3 != 64) {
					output = output + new Character((char)(chr2)).toString();
				}
				if (enc4 != 64) {
					output = output + new Character((char)(chr3)).toString();
				}

			}

			output = _utf8_decode(output);

			return output;

		}

		// private method for UTF-8 encoding
		public static String _utf8_encode(String string) {
			string = string.replaceAll("/\r\n/g","\n");
			String utftext = "";

			for (int n = 0; n < string.toCharArray().length; n++) {

				int c = string.charAt(n);
				if (c < 128) {				
					utftext += new Character((char)c).toString();
				}
				else if((c > 127) && (c < 2048)) {					
					utftext += new Character((char)((c >> 6) | 192)).toString();
					utftext += new Character((char)((c & 63) | 128)).toString();
				}
				else {
					utftext += new Character((char)((c >> 12) | 224)).toString();
					utftext += new Character((char)(((c >> 6) & 63) | 128)).toString();
					utftext += new Character((char)((c & 63) | 128)).toString();
				}

			}	 			
			return utftext;
		}

		// private method for UTF-8 decoding
		public static String _utf8_decode (String utftext) {
			String string = "";
			int i = 0;
			int c = 0;
			int c2 = 0;
			int c3 = 0;

			while ( i < utftext.toCharArray().length ) {

				c = utftext.charAt(i);

				if (c < 128) {
					string += new Character((char)(c)).toString();
					i++;
				}
				else if((c > 191) && (c < 224)) {
					c2 = utftext.charAt(i+1);
					string += new Character((char)(((c & 31) << 6) | (c2 & 63))).toString();
					i += 2;
				}
				else {
					c2 = utftext.charAt(i+1);
					c3 = utftext.charAt(i+2);
					string += new Character((char)(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63))).toString();
					i += 3;
				}

			}

			return string;
		}
		public static void main(String[] args) {
			String word = "Дамян Славов";
			String encode = Base64.encode(word);
			System.out.println(encode);
			System.out.println(Base64.decode(encode));
		}
}

