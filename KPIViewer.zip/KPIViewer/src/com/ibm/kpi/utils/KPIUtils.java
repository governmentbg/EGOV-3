package com.ibm.kpi.utils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.StringTokenizer;

import javax.portlet.PortletPreferences;
import javax.portlet.RenderRequest;
import javax.servlet.http.HttpServletRequest;

import com.ibm.kpiviewer.KPIConstants;
import com.ibm.kpiviewer.KPIViewerPortlet;

public class KPIUtils {

	private static SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH);
	private static SimpleDateFormat dateTimeFormatYYYY_MM_dd = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);

	public static long date_yyyy_MM_dd_ToTimeMillis(final String date, final boolean beginDay) {
		try {
			final StringTokenizer st = new StringTokenizer(date, "-");
			if (st.countTokens() != 3) {
				return 0;
			}
			final int year = Integer.parseInt(st.nextToken());
			final int month = Integer.parseInt(st.nextToken());
			final int day = Integer.parseInt(st.nextToken());
			final Calendar cal = Calendar.getInstance();
			cal.set(Calendar.DAY_OF_MONTH, day);
			cal.set(Calendar.MONTH, month - 1);
			cal.set(Calendar.YEAR, year);

			if (beginDay) {
				cal.set(Calendar.HOUR_OF_DAY, 0);
				cal.set(Calendar.MINUTE, 0);
				cal.set(Calendar.SECOND, 0);
				cal.set(Calendar.MILLISECOND, 0);
			} else {
				cal.set(Calendar.HOUR_OF_DAY, 23);
				cal.set(Calendar.MINUTE, 59);
				cal.set(Calendar.SECOND, 59);
				cal.set(Calendar.MILLISECOND, 999);
			}
			return cal.getTime().getTime();
		} catch (final NumberFormatException e) {
			e.printStackTrace();
		}
		return 0;
	}

	public static long date_TimestampToTimeMillis(final String s) {
		if (s != null) {
			try {
				return dateTimeFormat.parse(s).getTime();
			} catch (final Exception e) {
			}
		}
		return 0;
	}

	public static String timeMillisToTimestamp(final String millis) {
		try {
			final long l = Long.parseLong(millis);
			return dateTimeFormat.format(new Date(l));
		} catch (final Exception e) {
			System.out.println("KPIUtils : timeMillisToTimestamp : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static String timeMillisToTimestamp(final long millis) {
		try {

			return dateTimeFormat.format(new Date(millis));
		} catch (final Exception e) {
			System.out.println("KPIUtils : timeMillisToTimestamp : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static String timeMillisToYYYY_MM_DD_HH_MM_SS(final String timeMillis) {
		try {
			final Date date = new Date(Long.parseLong(timeMillis));
			return dateTimeFormat.format(date);
		} catch (Exception e) {
			System.out.println("KPIUtils : timeMillisToYYYY_MM_DD_HH_MM_SS : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static String timeMillisToYYYY_MM_DD_HH_MM_SS(final long timeMillis) {
		try {
			final Date date = new Date(timeMillis);
			return dateTimeFormat.format(date);
		} catch (Exception e) {
			System.out.println("KPIUtils : timeMillisToYYYY_MM_DD_HH_MM_SS : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static String timeMillisToYYYY_MM_DD(final long timeMillis) {
		try {
			final Date date = new Date(timeMillis);
			return dateTimeFormatYYYY_MM_dd.format(date);
		} catch (Exception e) {
			System.out.println("KPIUtils : timeMillisToYYYY_MM_DD : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static void loadPreferences(RenderRequest request) {
		PortletPreferences portletPreferences = request.getPreferences();
		if (portletPreferences != null) {
			String mode = portletPreferences.getValue(KPIViewerPortlet.SETTING_PARAMETER_MODE, KPIConstants.MODE_INDICATOR_VALUES);
			String resultsPerPage = portletPreferences.getValue(KPIViewerPortlet.SETTING_PARAMETER_RESULTS_PER_PAGE, null);
			if (resultsPerPage != null && resultsPerPage.trim().length() > 0) {
				try {
					KPIViewerPortlet.resultsPerPage = Integer.parseInt(resultsPerPage.trim());
				} catch (NumberFormatException e) {
					e.printStackTrace();
				}
			} else {
				KPIViewerPortlet.resultsPerPage = -1;
			}
			if (KPIConstants.MODE_SECTORS.equals(mode)) {
				KPIViewerPortlet.mode = mode;
			} else {
				KPIViewerPortlet.mode = KPIConstants.MODE_INDICATOR_VALUES;
			}
		}
	}

	public static int getCurrentPageNumber(int total, int currentPage, int resultsPerPage) {
		if (total > 0 && resultsPerPage > 0) {
			int totalPages = getTotalPages(total, resultsPerPage);
			if (totalPages < currentPage) {
				currentPage = totalPages;
			}
			return currentPage;
		}
		return 1;
	}

	public static int getTotalPages(int total, int resultsPerPage) {
		if (total > 0 && resultsPerPage > 0) {
			try {
				return (int) Math.ceil((double) total / (double) resultsPerPage);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return 1;
	}

	public static String getClientIpAddr(HttpServletRequest request) {
		String ip = request.getHeader("X-Forwarded-For");
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_CLIENT_IP");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("HTTP_X_FORWARDED_FOR");
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
		}
		return ip;
	}
}
