package com.ibm.kpi.bean;

public class BreadCrumbNode {
	String name = null;
	String url = null;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
}
