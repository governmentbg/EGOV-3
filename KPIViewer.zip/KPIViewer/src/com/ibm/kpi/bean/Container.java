package com.ibm.kpi.bean;

public class Container {
	String filterCriteria = null;
	String filterType = null;
	String filterValue = null;
	String filterValue2 = null;
	int navigatorPage = 1;
	int navigatorTotalPages = 1;
	String id = null;
	Object object = null;
	Object[] results = null;
	Object data = null;
	
	public String getFilterCriteria() {
		return filterCriteria;
	}
	
	public void setFilterCriteria(String filterCriteria) {
		this.filterCriteria = filterCriteria;
	}
	
	public String getFilterType() {
		return filterType;
	}
	
	public void setFilterType(String filterType) {
		this.filterType = filterType;
	}
	
	public String getFilterValue() {
		return filterValue;
	}

	public void setFilterValue(String filterValue) {
		this.filterValue = filterValue;
	}

	public String getFilterValue2() {
		return filterValue2;
	}

	public void setFilterValue2(String filterValue2) {
		this.filterValue2 = filterValue2;
	}

	public int getNavigatorPage() {
		return navigatorPage;
	}

	public void setNavigatorPage(int navigatorPage) {
		this.navigatorPage = navigatorPage;
	}

	public int getNavigatorTotalPages() {
		return navigatorTotalPages;
	}

	public void setNavigatorTotalPages(int navigatorTotalPages) {
		this.navigatorTotalPages = navigatorTotalPages;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Object getObject() {
		return object;
	}

	public void setObject(Object object) {
		this.object = object;
	}

	public Object[] getResults() {
		return results;
	}
	
	public void setResults(Object[] results) {
		this.results = results;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public void clearObject() {
		this.results = null;
		this.object = null;
		this.data = null;
	}	
}