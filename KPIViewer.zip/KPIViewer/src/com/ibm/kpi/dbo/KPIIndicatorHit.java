package com.ibm.kpi.dbo;

import java.util.Hashtable;

import com.ibm.kpi.db.DBTransaction;
import com.ibm.kpi.db.FinderException;
import com.ibm.kpi.db.PersistentObject;
import com.ibm.kpi.db.QueryComposer;
import com.ibm.kpi.db.QuerySet;
import com.ibm.kpi.utils.KPIUtils;
import com.ibm.kpiviewer.KPIConstants;

public class KPIIndicatorHit extends PersistentObject {
	private static String CLASS_NAME = KPIIndicatorHit.class.getName();
	protected static String schema = KPIConstants._SCHEMANAME;
	protected static String table;
	protected static Hashtable<String, String> columnMap;
	protected static String[] keyArray;
	protected static String sequenceName;
	public static QuerySet querySet;
	static {
		table = "KPIINDICATORHIT";
		sequenceName = "SEQ_KPIINDICATORHITID";
		columnMap = new Hashtable<String, String>();
		columnMap.put("id", "KPIINDICATORHITID");
		columnMap.put("kpiIndicatorId", "KPIINDICATORID");
		columnMap.put("ip", "IP");
		columnMap.put("creationDate", "CREATIONDATE");
		querySet = QueryComposer.composeAll(schema, table, sequenceName, columnMap);
	}

	public KPIIndicatorHit() {
		super(querySet);
	}

	private String kpiIndicatorId = null;
	private String ip = null;
	private String creationDate = null;

	public String getKpiIndicatorId() {
		return kpiIndicatorId;
	}

	public void setKpiIndicatorId(String kpiIndicatorId) {
		this.kpiIndicatorId = kpiIndicatorId;
	}

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public java.sql.Timestamp getCreationDate() {
		return (creationDate != null) ? new java.sql.Timestamp(Long.parseLong(creationDate)) : null;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = (creationDate != null) ? String.valueOf(KPIUtils.date_TimestampToTimeMillis(creationDate)) : null;
	}

	public static KPIIndicatorHit findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (KPIIndicatorHit) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}

	public static KPIIndicatorHit[] findAllByIndicatorId(final String kpiIndicatorId, final DBTransaction transaction) throws FinderException, Exception {
		return findKPIIndicatorHits(columnMap.get("kpiIndicatorId") + " = " + kpiIndicatorId, transaction);
	}

	public static KPIIndicatorHit[] findAllByIds(final String ids, final DBTransaction transaction) throws FinderException, Exception {
		return findKPIIndicatorHits(columnMap.get("id") + " IN (" + ids + ") ", transaction);
	}

	public static KPIIndicatorHit[] findAllByFilter(String indicatorId, String filterValue, String filterValue2, final DBTransaction transaction) throws FinderException, Exception {
		StringBuffer cond = new StringBuffer();
		cond.append(" 1=1 ");
		if (indicatorId != null && indicatorId.trim().length() > 0) {
			cond.append(" AND " + columnMap.get("kpiIndicatorId") + " =" + indicatorId);
		}
		if (filterValue != null && filterValue.trim().length() > 0) {
			cond.append(" AND " + columnMap.get("creationDate") + ">='" + filterValue.trim() + "' ");
		}
		if (filterValue2 != null && filterValue2.trim().length() > 0) {
			cond.append(" AND " + columnMap.get("creationDate") + "<='" + filterValue2.trim() + "' ");
		}
		cond.append(" ORDER BY " + columnMap.get("creationDate") + " ASC");
		return findKPIIndicatorHits(cond.toString(), transaction);
	}

	public static KPIIndicatorHit[] findKPIIndicatorHits(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final KPIIndicatorHit[] kpiIndicatorHits = new KPIIndicatorHit[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				kpiIndicatorHits[i] = (KPIIndicatorHit) tmp[i];
			}
			return kpiIndicatorHits;
		}
		return null;
	}

	public static KPIIndicatorHit[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple("1=1", CLASS_NAME, transaction);
		if (tmp != null) {
			final KPIIndicatorHit[] kpiIndicatorHits = new KPIIndicatorHit[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				kpiIndicatorHits[i] = (KPIIndicatorHit) tmp[i];
			}
			return kpiIndicatorHits;
		}
		return null;
	}

}
