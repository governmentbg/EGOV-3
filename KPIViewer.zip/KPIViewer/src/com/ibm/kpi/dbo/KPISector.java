package com.ibm.kpi.dbo;

import java.util.Hashtable;

import com.ibm.kpi.db.DBTransaction;
import com.ibm.kpi.db.FinderException;
import com.ibm.kpi.db.PersistentObject;
import com.ibm.kpi.db.QueryComposer;
import com.ibm.kpi.db.QuerySet;
import com.ibm.kpi.utils.KPIUtils;
import com.ibm.kpiviewer.KPIConstants;


public class KPISector extends PersistentObject {
	private static String CLASS_NAME = KPISector.class.getName();
    protected static String schema = KPIConstants._SCHEMANAME;
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
    static {
        table = "KPISECTOR";
        sequenceName = "SEQ_KPISECTORID";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "KPISECTORID");
        columnMap.put("sectorName", "SECTORNAME");
        columnMap.put("sectorDescription", "SECTORDESCRIPTION");
        columnMap.put("creationDate", "CREATIONDATE");
        querySet = QueryComposer.composeAll(schema, table, sequenceName, columnMap);
    }
	
    public KPISector() {
        super(querySet);
    }
    
	private String sectorName = null;
	private String sectorDescription = null;
	private String creationDate = null;
	
	public String getSectorName() {
		return sectorName;
	}
	
	public void setSectorName(String sectorName) {
		this.sectorName = sectorName;
	}
	
	public String getSectorDescription() {
		return sectorDescription;
	}

	public void setSectorDescription(String sectorDescription) {
		this.sectorDescription = sectorDescription;
	}

	public java.sql.Timestamp getCreationDate() {
		return (creationDate != null) ? new java.sql.Timestamp(Long.parseLong(creationDate)) : null;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = (creationDate != null) ? String.valueOf(KPIUtils.date_TimestampToTimeMillis(creationDate)) : null;
	}

	public static KPISector findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
        return (KPISector) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
    }

	public static KPISector[] findAllByIds(final String ids, final DBTransaction transaction) throws FinderException, Exception {
		return findKPISectors(columnMap.get("id") + " IN (" + ids + ")", transaction);
	}
	
	public static KPISector[] findAllByFilter(String filterType, String filterValue, String filterValue2, final DBTransaction transaction) throws FinderException, Exception {
		StringBuffer cond = new StringBuffer();
		cond.append(" 1=1 ");
		if ("1".equals(filterType)) { //NAME
			if (filterValue != null && filterValue.trim().length() > 0) {
				cond.append(" AND LOWER(" + columnMap.get("sectorName") + ") LIKE '" + filterValue.trim().toLowerCase() + "%' ");
			}
		} else if ("2".equals(filterType)) { //CREATION DATE
			if (filterValue != null && filterValue.trim().length() > 0) {
				cond.append(" AND " + columnMap.get("creationDate") + ">='" + filterValue.trim() + "' ");
			}
			if (filterValue2 != null && filterValue2.trim().length() > 0) {
				cond.append(" AND " + columnMap.get("creationDate") + "<='" + filterValue2.trim() + "' ");
			}			
		}
		cond.append( " ORDER BY " + columnMap.get("sectorName") + " ASC");
		return findKPISectors(cond.toString(), transaction);
	}
	
	public static KPISector[] findKPISectors(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final KPISector[] kpiSectors = new KPISector[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				kpiSectors[i] = (KPISector) tmp[i];
			}
			return kpiSectors;
		}
		return null;
	}
	
	public static KPISector[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple("1=1", CLASS_NAME, transaction);
		if (tmp != null) {
			final KPISector[] kpiSectors = new KPISector[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				kpiSectors[i] = (KPISector) tmp[i];
			} 
			return kpiSectors;
		} 
		return null;
	}
	
}
