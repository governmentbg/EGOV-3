package com.ibm.kpi.dbo;

import java.util.Hashtable;

import com.ibm.kpi.db.DBTransaction;
import com.ibm.kpi.db.FinderException;
import com.ibm.kpi.db.PersistentObject;
import com.ibm.kpi.db.QueryComposer;
import com.ibm.kpi.db.QuerySet;
import com.ibm.kpi.utils.KPIUtils;
import com.ibm.kpiviewer.KPIConstants;

public class KPIIndicator extends PersistentObject {
	private static String CLASS_NAME = KPIIndicator.class.getName();
	protected static String schema = KPIConstants._SCHEMANAME;
	protected static String table;
	protected static Hashtable<String, String> columnMap;
	protected static String[] keyArray;
	protected static String sequenceName;
	public static QuerySet querySet;
	static {
		table = "KPIINDICATOR";
		sequenceName = "SEQ_KPIINDICATORID";
		columnMap = new Hashtable<String, String>();
		columnMap.put("id", "KPIINDICATORID");
		columnMap.put("indicatorName", "INDICATORNAME");
		columnMap.put("kpiOrganizationId", "KPIORGANIZATIONID");
		columnMap.put("responsibleUserId", "RESPONSIBLEUSERID");
		columnMap.put("period", "PERIOD");
		columnMap.put("description", "DESCRIPTION");
		columnMap.put("inputMethod", "INPUTMETHOD");
		columnMap.put("targetValue", "TARGETVALUE");
		columnMap.put("targetType", "TARGETTYPE");
		columnMap.put("adminUserDN", "ADMINUSERDN");
		columnMap.put("creationDate", "CREATIONDATE");
		querySet = QueryComposer.composeAll(schema, table, sequenceName, columnMap);
	}

	public KPIIndicator() {
		super(querySet);
	}

	private String indicatorName = null;
	private String kpiOrganizationId = null;
	private String responsibleUserId = null;
	private String period = null;
	private String description = null;
	private String inputMethod = null;
	private String targetValue = null;
	private String targetType = null;
	private String adminUserDN = null;
	private String creationDate = null;
	private KPISectorIndicator[] sectorIndicators = null; // ONLY FOR BUSINESS PURPOSE...
	private KPIIndicatorValue[] indicatorValues = null; // ONLY FOR BUSINESS PURPOSE...

	public String getIndicatorName() {
		return indicatorName;
	}

	public void setIndicatorName(String indicatorName) {
		this.indicatorName = indicatorName;
	}

	public String getKpiOrganizationId() {
		return kpiOrganizationId;
	}

	public void setKpiOrganizationId(String kpiOrganizationId) {
		this.kpiOrganizationId = kpiOrganizationId;
	}

	public String getResponsibleUserId() {
		return responsibleUserId;
	}

	public void setResponsibleUserId(String responsibleUserId) {
		this.responsibleUserId = responsibleUserId;
	}

	public String getPeriod() {
		return period;
	}

	public void setPeriod(String period) {
		this.period = period;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getInputMethod() {
		return inputMethod;
	}

	public void setInputMethod(String inputMethod) {
		this.inputMethod = inputMethod;
	}

	public String getTargetValue() {
		return targetValue;
	}

	public void setTargetValue(String targetValue) {
		this.targetValue = targetValue;
	}

	public String getTargetType() {
		return targetType;
	}

	public void setTargetType(String targetType) {
		this.targetType = targetType;
	}

	public String getAdminUserDN() {
		return adminUserDN;
	}

	public void setAdminUserDN(String adminUserDN) {
		this.adminUserDN = adminUserDN;
	}

	public java.sql.Timestamp getCreationDate() {
		return (creationDate != null) ? new java.sql.Timestamp(Long.parseLong(creationDate)) : null;
	}

	public void setCreationDate(String creationDate) {
		this.creationDate = (creationDate != null) ? String.valueOf(KPIUtils.date_TimestampToTimeMillis(creationDate)) : null;
	}

	public KPISectorIndicator[] getSectorIndicators() {
		return sectorIndicators;
	}

	public void setSectorIndicators(KPISectorIndicator[] sectorIndicators) {
		this.sectorIndicators = sectorIndicators;
	}

	public KPIIndicatorValue[] getIndicatorValues() {
		return indicatorValues;
	}

	public void setIndicatorValues(KPIIndicatorValue[] indicatorValues) {
		this.indicatorValues = indicatorValues;
	}

	public static KPIIndicator findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (KPIIndicator) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}

	public static KPIIndicator[] findAllByOrganizationId(final String organizationId, final DBTransaction transaction) throws FinderException, Exception {
		return findKPIIndicators(columnMap.get("kpiOrganizationId") + " = " + organizationId, transaction);
	}

	public static KPIIndicator[] findAllByIds(final String ids, final DBTransaction transaction) throws FinderException, Exception {
		return findKPIIndicators(columnMap.get("id") + " IN (" + ids + ") ", transaction);
	}

	public static KPIIndicator[] findAllByName(final String name, final DBTransaction transaction) throws FinderException, Exception {
		return findKPIIndicators("LOWER(" + columnMap.get("indicatorName") + ") LIKE '" + name.trim().toLowerCase() + "%' ", transaction);
	}

	public static KPIIndicator[] findAllByFilter(String indicatorIds, String filterType, String filterValue, String filterValue2, final DBTransaction transaction) throws FinderException, Exception {
		StringBuffer cond = new StringBuffer();
		cond.append(" 1=1 ");
		if (indicatorIds != null && indicatorIds.trim().length() > 0) {
			cond.append(" AND " + columnMap.get("id") + " IN (" + indicatorIds.trim() + ") ");
		}
		if ("1".equals(filterType)) { // NAME
			if (filterValue != null && filterValue.trim().length() > 0) {
				cond.append(" AND LOWER(" + columnMap.get("indicatorName") + ") LIKE '" + filterValue.trim().toLowerCase() + "%' ");
			}
		} else if ("4".equals(filterType)) { // CREATION DATE
			if (filterValue != null && filterValue.trim().length() > 0) {
				cond.append(" AND " + columnMap.get("creationDate") + ">='" + filterValue.trim() + "' ");
			}
			if (filterValue2 != null && filterValue2.trim().length() > 0) {
				cond.append(" AND " + columnMap.get("creationDate") + "<='" + filterValue2.trim() + "' ");
			}
		}
		cond.append(" ORDER BY " + columnMap.get("indicatorName") + " ASC");
		return findKPIIndicators(cond.toString(), transaction);
	}

	public static KPIIndicator[] findKPIIndicators(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final KPIIndicator[] kpiIndicators = new KPIIndicator[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				kpiIndicators[i] = (KPIIndicator) tmp[i];
			}
			return kpiIndicators;
		}
		return null;
	}

	public static KPIIndicator[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple("1=1", CLASS_NAME, transaction);
		if (tmp != null) {
			final KPIIndicator[] kpiIndicators = new KPIIndicator[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				kpiIndicators[i] = (KPIIndicator) tmp[i];
			}
			return kpiIndicators;
		}
		return null;
	}

}
