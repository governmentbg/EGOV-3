package com.ibm.kpi.dbo;

import java.util.Hashtable;

import com.ibm.kpi.db.DBTransaction;
import com.ibm.kpi.db.FinderException;
import com.ibm.kpi.db.PersistentObject;
import com.ibm.kpi.db.QueryComposer;
import com.ibm.kpi.db.QuerySet;
import com.ibm.kpiviewer.KPIConstants;

public class KPIOrganizationUser extends PersistentObject {
	private static String CLASS_NAME = KPIOrganizationUser.class.getName();
	protected static String schema = KPIConstants._SCHEMANAME;
	protected static String table;
	protected static Hashtable<String, String> columnMap;
	protected static String[] keyArray;
	protected static String sequenceName;
	public static QuerySet querySet;
	static {
		table = "KPIORGANIZATIONUSER";
		sequenceName = "SEQ_KPIORGANIZATIONUSERID";
		columnMap = new Hashtable<String, String>();
		columnMap.put("id", "KPIORGANIZATIONUSERID");
		columnMap.put("kpiOrganizationId", "KPIORGANIZATIONID");
		columnMap.put("userDN", "USERDN");
		columnMap.put("userType", "USERTYPE");
		querySet = QueryComposer.composeAll(schema, table, sequenceName, columnMap);
	}

	public KPIOrganizationUser() {
		super(querySet);
	}

	private String kpiOrganizationId = null;
	private String userDN = null;
	private String userType = null;

	public String getKpiOrganizationId() {
		return kpiOrganizationId;
	}

	public void setKpiOrganizationId(String kpiOrganizationId) {
		this.kpiOrganizationId = kpiOrganizationId;
	}

	public String getUserDN() {
		return userDN;
	}

	public void setUserDN(String userDN) {
		this.userDN = userDN;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public static KPIOrganizationUser findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (KPIOrganizationUser) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}

	public static KPIOrganizationUser findByUserDN(final String userDN, final DBTransaction transaction) throws FinderException, Exception {
		return (KPIOrganizationUser) findSingle(columnMap.get("userDN") + "='" + userDN + "'", CLASS_NAME, transaction);
	}

	public static KPIOrganizationUser[] findAllByUserDNs(final String userDNs, final DBTransaction transaction) throws FinderException, Exception {
		return  findKPIOrganizationUsers(columnMap.get("userDN") + " IN (" + userDNs + ")", transaction);
	}

	public static KPIOrganizationUser[] findAllByUserUIDOrCN(final String userDN, final DBTransaction transaction) throws FinderException, Exception {
		StringBuffer cond = new StringBuffer();
		cond.append(" LOWER(" + columnMap.get("userDN") + ") LIKE 'uid=" + userDN.trim().toLowerCase() + "%' ");
		cond.append(" OR LOWER(" + columnMap.get("userDN") + ") LIKE 'cn=" + userDN.trim().toLowerCase() + "%' ");
		cond.append( " ORDER BY " + columnMap.get("kpiOrganizationId"));
		return findKPIOrganizationUsers(cond.toString(), transaction);
	}

	public static KPIOrganizationUser[] findAllByOrganizationId(final String organizationId, final DBTransaction transaction) throws FinderException, Exception {		
		return  findKPIOrganizationUsers(columnMap.get("kpiOrganizationId") + " = " + organizationId, transaction);
	}
	
	public static KPIOrganizationUser[] findAllByFilter(String organizationId, String filterType, String filterValue, final DBTransaction transaction) throws FinderException, Exception {
		StringBuffer cond = new StringBuffer();
		cond.append(columnMap.get("kpiOrganizationId") + "=" + organizationId);
		if ("1".equals(filterType)) { //UID
			if (filterValue != null && filterValue.trim().length() > 0) {
				cond.append(" AND LOWER(" + columnMap.get("userDN") + ") LIKE 'uid=" + filterValue.trim().toLowerCase() + "%' ");
			}
		} else if ("2".equals(filterType)) { //CN
			if (filterValue != null && filterValue.trim().length() > 0) {
				cond.append(" AND LOWER(" + columnMap.get("userDN") + ") LIKE 'cn=" + filterValue.trim().toLowerCase() + "%' ");
			}
		}
		cond.append( " ORDER BY " + columnMap.get("kpiOrganizationId"));
		return findKPIOrganizationUsers(cond.toString(), transaction);
	}
	
	public static KPIOrganizationUser[] findKPIOrganizationUsers(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final KPIOrganizationUser[] organizationUsers = new KPIOrganizationUser[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				organizationUsers[i] = (KPIOrganizationUser) tmp[i];
			}
			return organizationUsers;
		}
		return null;
	}
	
	public static KPIOrganizationUser[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple("1=1", CLASS_NAME, transaction);
		if (tmp != null) {
			final KPIOrganizationUser[] kpiOrganizationUsers = new KPIOrganizationUser[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				kpiOrganizationUsers[i] = (KPIOrganizationUser) tmp[i];
			} 
			return kpiOrganizationUsers;
		} 
		return null;
	}
}
