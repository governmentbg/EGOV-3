package com.ibm.kpi.dbo;

import java.util.Hashtable;

import com.ibm.kpi.db.DBTransaction;
import com.ibm.kpi.db.FinderException;
import com.ibm.kpi.db.PersistentObject;
import com.ibm.kpi.db.QueryComposer;
import com.ibm.kpi.db.QuerySet;
import com.ibm.kpiviewer.KPIConstants;


public class KPIOrganization extends PersistentObject {
	private static String CLASS_NAME = KPIOrganization.class.getName();
    protected static String schema = KPIConstants._SCHEMANAME;
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
    static {
        table = "KPIORGANIZATION";
        sequenceName = "SEQ_KPIORGANIZATIONID";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "KPIORGANIZATIONID");
        columnMap.put("organizationName", "ORGANIZATIONNAME");
        columnMap.put("organizationDescription", "ORGANIZATIONDESCRIPTION");
        querySet = QueryComposer.composeAll(schema, table, sequenceName, columnMap);
    }
	
    public KPIOrganization() {
        super(querySet);
    }
    
	private String organizationName = null;
	private String organizationDescription = null;
	
	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public String getOrganizationDescription() {
		return organizationDescription;
	}

	public void setOrganizationDescription(String organizationDescription) {
		this.organizationDescription = organizationDescription;
	}

	public static KPIOrganization findById(final String organizationId, final DBTransaction transaction) throws FinderException, Exception {
        return (KPIOrganization) findSingle(columnMap.get("id") + "=" + organizationId, CLASS_NAME, transaction);
    }

	public static KPIOrganization[] findAllByName(final String organizationName, final DBTransaction transaction) throws FinderException, Exception {
		return findKPIOrganizations(columnMap.get("organizationName") + " LIKE '" + organizationName + "%'", transaction);
	}
	
	public static KPIOrganization[] findAllByFilter(String filterType, String filterValue, final DBTransaction transaction) throws FinderException, Exception {
		StringBuffer cond = new StringBuffer();
		cond.append(" 1=1 ");
		if ("1".equals(filterType)) { //NAME
			if (filterValue != null && filterValue.trim().length() > 0) {
				cond.append(" AND LOWER(" + columnMap.get("organizationName") + ") LIKE '" + filterValue.trim().toLowerCase() + "%' ");
			}
		} else if ("2".equals(filterType)) { //DESCRIPTION
			if (filterValue != null && filterValue.trim().length() > 0) {
				cond.append(" AND LOWER(" + columnMap.get("organizationDescription") + ") LIKE '" + filterValue.trim().toLowerCase() + "%' ");
			}
		}
		cond.append( " ORDER BY " + columnMap.get("organizationName") + " ASC");
		return findKPIOrganizations(cond.toString(), transaction);
	}
	
	public static KPIOrganization[] findKPIOrganizations(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final KPIOrganization[] KPIOrganizations = new KPIOrganization[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				KPIOrganizations[i] = (KPIOrganization) tmp[i];
			}
			return KPIOrganizations;
		}
		return null;
	}
	
	public static KPIOrganization[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple("1=1", CLASS_NAME, transaction);
		if (tmp != null) {
			final KPIOrganization[] kpiOrganizations = new KPIOrganization[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				kpiOrganizations[i] = (KPIOrganization) tmp[i];
			} // for
			return kpiOrganizations;
		} // tmp
		return null;
	}
	
}
