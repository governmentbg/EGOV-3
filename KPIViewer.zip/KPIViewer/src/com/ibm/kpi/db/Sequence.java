package com.ibm.kpi.db;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import com.ibm.kpiviewer.KPIConstants;

public class Sequence {

	public synchronized static String getNextVal(String sequenceName, Connection connection) throws SQLException {
		String sequenceValue;
		sequenceValue = "-1";
		Statement st = connection.createStatement();
		String query = "select " + KPIConstants._SCHEMANAME + sequenceName + ".nextval from dual";
		ResultSet rs = st.executeQuery(query);
		if (rs != null) {
			if (rs.next()) {
				sequenceValue = rs.getString(1);
			}
		} // rs
		rs.close();
		st.close();
		return sequenceValue;
	} // getNextVal
} 