package com.ibm.kpi.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBconnection {
	
	static {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException cnfe) {
			System.out.println("Error while loading the driver!!!");
			cnfe.printStackTrace();
		}
	}
	
	public static Connection getConnection() {
		String url		 = "jdbc:oracle:thin:@//192.168.20.223:1521/wpsdb";
		String username  = "egov";
		String password  = "WS8devts4";
		try {
			Connection con = DriverManager.getConnection(url, username, password);
			con.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);
			return con;
		} catch (SQLException sqle) {
			System.out.println("Error while connecting to the database!!!");
			sqle.printStackTrace();			
		}
		return null;
	}
}
