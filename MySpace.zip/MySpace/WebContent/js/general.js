mySpaceSearchResults.prototype = {};
mySpaceSearchResults.prototype.constructor = mySpaceSearchResults;
mySpaceSearchResults.superclass = null;
function mySpaceSearchResults(id, name, link, title, summary, authoringTemplate, lastModifiedTime) {
    this.id = id;
    this.name = name;
    this.link = link;
    this.title = title;
    this.summary = summary;
    this.authoringTemplate = authoringTemplate;
    this.lastModifiedTime = lastModifiedTime;
    
};
function mySpaceSearchServices() {
    var searchText = document.getElementById(MY_SPACE_SEARCH_SERVICES_REQUEST_BUTTON).value;
    if (searchText.trim() == '') {
       alert(MY_SPACE_EMPTY_SEARCH_STRING);
       return false;
    }
    MY_SPACE_START_INDEX = 0;
    MY_SPACE_TOTAL_RESULTS = 0;
    MY_SPACE_SEARCH_TEXT = searchText.trim();
    mySpaceSearchServicesCall(MY_SPACE_START_INDEX);
    return true;
};
function mySpaceCheckEnterPressed(e) {    
    var code = (e.keyCode ? e.keyCode : e.which);
    if (code != 13) return;
    return mySpaceSearchServices();         
};
function mySpaceGoToPage(number) {
	MY_SPACE_CURRENT_PAGE = number;
	mySpaceSearchServicesCall(number-1);
};
		 
function mySpaceSearchServicesCall(startIndex) {		
    var searchText = decodeURIComponent(MY_SPACE_SEARCH_TEXT);
    var searchURL = MY_SPACE_FEED_PREFIX +"?queryLang=en&locale="+MY_SPACE_LOCALE+"&resultLang="+MY_SPACE_RESULT_LANG+"&start="+(startIndex*MY_SPACE_RESULTS_PER_PAGE) + "&results=" + MY_SPACE_RESULTS_PER_PAGE +"&scope="+ MY_SPACE_SCOPE_ID +"&query="+ encodeURIComponent(searchText);
    // Add order. (not needed here as we want the default order by relevance!)
    // searchURL += '&sortKey=title&sortOrder=asc';
    // Add filter by AT.
    searchURL += '&constraint={"type":"field","id":"authoringtemplate","values":["ServiceProvidedBySupplier","UnifiedService"]}';
    var categoryTitle = encodeURIComponent('"Активен"');
    searchURL += '&constraint={"type":"field","id":"category","values":[' + categoryTitle + ']}';
	searchURL += '&rand=' + Math.random(); 
    console.log("searchURL:" + searchURL);
    mySpaceSearchResultsArray = [];
    mySpaceHT = new HashTable();
    document.getElementById(MY_SPACE_SEARCH_SERVICES_REQUEST_BUTTON).value = MY_SPACE_SEARCH_TEXT;
    document.getElementById(MY_SPACE_SEARCH_SERVICES_RESULT_CONTAINER).style.display = 'none';
    document.getElementById(MY_SPACE_SEARCH_SERVICES_LOADER_DIV).style.display = '';
    var wsgXMLHttpRequestObject = new PortalXMLHttpRequestObject();
  	var xmlHttpRequestObject = wsgXMLHttpRequestObject.getXMLHttpRequestObject();
  	if (xmlHttpRequestObject) {
    	xmlHttpRequestObject.open('GET', searchURL);
      	xmlHttpRequestObject.onreadystatechange = function() {
          if (xmlHttpRequestObject.readyState == 4 && xmlHttpRequestObject.status == 200) {
            var xmlDoc = xmlHttpRequestObject.responseXML;
            var node = xmlDoc.childNodes[0];
            if (node == null) {
                console.debug("ATOM XML has issues?");
                return;
            }
            var docIds = new Array();
            var id;
            var name;
            var title;
            var link;
            var contentType;
            var summary;
            var authoringTemplate;
            var lastModifiedTime;
            for (var i = 0; i < node.childNodes.length;i++){
                var current = node.childNodes[i];
                if (current.nodeName == "opensearch:totalResults") {
                	MY_SPACE_TOTAL_RESULTS = current.childNodes[0].data;
                } else if (current.nodeName == "atom:entry") {
                    id = "";
                    name = "";
                    title = "";
                    link = "";
                    contentType = "";
                    summary = "";
                    authoringTemplate = "";
                    lastModifiedTime = "";
                    for (var j = 0; j < current.childNodes.length;j++){
                        var currentChild=current.childNodes[j];
                        if (currentChild.nodeName == "atom:id") {
                            id = currentChild.childNodes[0].data;
                        } else if (currentChild.nodeName == "atom:title") {
                            title = currentChild.childNodes[0].data;
                        } else if (currentChild.nodeName == "wplc:field" ){
                            if (currentChild.id== "display_uri" || currentChild.attributes[0].value=="display_uri"){
                                link = currentChild.childNodes[0].data;
                            }
                            if (currentChild.id == "contentsourcetype" || currentChild.attributes[0].value == "contentsourcetype") {
                                contentType = currentChild.childNodes[0].data;
                            }
                            if (currentChild.id == "summary"  || currentChild.attributes[0].value == "summary") {
                                summary = currentChild.childNodes[0].data;
                            }
                            if (currentChild.id == "authoringtemplate"  || currentChild.attributes[0].value == "authoringtemplate") {
                                authoringTemplate = currentChild.childNodes[0].data;
                            }
                            if (currentChild.id == "name"  || currentChild.attributes[0].value == "name") {
                                name = currentChild.childNodes[0].data;
                            }
                            if (currentChild.id== "update_date"  || currentChild.attributes[0].value=="update_date") {
                                var tmpDate = new Date(parseInt(currentChild.childNodes[0].data, 10));
                                lastModifiedTime = ((tmpDate.getDate() < 10) ? "0" : "") + tmpDate.getDate() + "." + ((tmpDate.getMonth()+1 < 10) ? "0" : "") + (tmpDate.getMonth()+1) + "." + tmpDate.getFullYear();
                            }
                         }
                    }
                    if (contentType == "WCM"){                          
                        var newLink = link.replace('//','');
                        var pos = newLink.indexOf('/');
                        if (pos != -1) {
                            newLink = newLink.substring(pos + 1);
                            if (newLink.indexOf('?') != 0) {
                                newLink = '/' + newLink;
                            }
                        }
                        link = newLink;                          
                    }
                    mySpaceSearchResultsArray[mySpaceSearchResultsArray.length] = new mySpaceSearchResults(id, name, link, title, summary, authoringTemplate, lastModifiedTime);
	                //if (id != null && MY_SPACE_AT_SERVICE_PROVIDED_BY_SUPPLIER == authoringTemplate) {
	                  docIds[docIds.length] = id;                        
	                //}						                 
                 }
              }
          	  if (docIds.length == 0) {
              	  console.log("mySpaceShowResults");
              	  mySpaceShowResults();
              } else {
                  console.log("loadExtraData: " + docIds.length);
                  mySpaceLoadExtraData(docIds);
			  }
		} else if (xmlHttpRequestObject.readyState != 0) {
      	} else {
        	document.getElementById(MY_SPACE_SEARCH_SERVICES_RESULT_CONTAINER).innerHTML = "Error loading feed";
            console.debug("failed xhrGet for URL: ", error, ioArgs);
            document.getElementById(MY_SPACE_SEARCH_SERVICES_LOADER_DIV).style.display = 'none';
      	}         
    };
    xmlHttpRequestObject.send(null);  
  }
};		 
function mySpaceDashBoardServicesCall(uids) {		
    var searchText = decodeURIComponent('uid');
    var searchURL = MY_SPACE_FEED_PREFIX +"?queryLang=en&locale="+MY_SPACE_LOCALE+"&resultLang="+MY_SPACE_RESULT_LANG+"&start="+ MY_SPACE_START_INDEX + "&results=" + MY_SPACE_RESULTS_PER_PAGE + "&scope="+ MY_SPACE_SCOPE_ID +"&query="+ encodeURIComponent(searchText);
    // Add order. 
    searchURL += '&sortKey=title&sortOrder=asc';
    // Add filter by docid.
    searchURL += '&constraint={"type":"field","id":"docid","values":[' + uids + ']}';
	searchURL += '&rand=' + Math.random();
    console.log("searchURL:" + searchURL);
    mySpaceSearchResultsArray = [];
    mySpaceHT = new HashTable();
    document.getElementById(MY_SPACE_SEARCH_SERVICES_RESULT_CONTAINER).style.display = 'none';
    document.getElementById(MY_SPACE_SEARCH_SERVICES_LOADER_DIV).style.display = '';
    var wsgXMLHttpRequestObject = new PortalXMLHttpRequestObject();
    var xmlHttpRequestObject = wsgXMLHttpRequestObject.getXMLHttpRequestObject();
	if (xmlHttpRequestObject) {
		xmlHttpRequestObject.open('GET', searchURL);
      	xmlHttpRequestObject.onreadystatechange = function() {
			if (xmlHttpRequestObject.readyState == 4 && xmlHttpRequestObject.status == 200) {
				var xmlDoc = xmlHttpRequestObject.responseXML;
	            var node = xmlDoc.childNodes[0];
	            if (node == null) {
	                console.debug("ATOM XML has issues?");
	                return;
	            }
	            var docIds = new Array();
	            var id;
	            var name;
	            var title;
	            var link;
	            var contentType;
	            var summary;
	            var authoringTemplate;
	            var lastModifiedTime;
	            for (var i = 0; i < node.childNodes.length;i++){
	                var current = node.childNodes[i];
	                if (current.nodeName == "opensearch:totalResults") {
	                  	MY_SPACE_TOTAL_RESULTS = current.childNodes[0].data;
	                } else if (current.nodeName == "atom:entry") {
	                    id = "";
	                    name = "";
	                    title = "";
	                    link = "";
	                    contentType = "";
	                    summary = "";
	                    authoringTemplate = "";
	                    lastModifiedTime = "";
	                    for (var j = 0; j < current.childNodes.length;j++){
	                        var currentChild=current.childNodes[j];
	                        if (currentChild.nodeName == "atom:id") {
	                            id = currentChild.childNodes[0].data;
	                        } else if (currentChild.nodeName == "atom:title") {
	                            title = currentChild.childNodes[0].data;
	                        } else if (currentChild.nodeName == "wplc:field" ){
	                            if (currentChild.id== "display_uri" || currentChild.attributes[0].value=="display_uri"){
	                                link = currentChild.childNodes[0].data;
	                            }
	                            if (currentChild.id == "contentsourcetype" || currentChild.attributes[0].value == "contentsourcetype") {
	                                contentType = currentChild.childNodes[0].data;
	                            }
	                            if (currentChild.id == "summary"  || currentChild.attributes[0].value == "summary") {
	                                summary = currentChild.childNodes[0].data;
	                            }
	                            if (currentChild.id == "authoringtemplate"  || currentChild.attributes[0].value == "authoringtemplate") {
	                                authoringTemplate = currentChild.childNodes[0].data;
	                            }
	                            if (currentChild.id == "name"  || currentChild.attributes[0].value == "name") {
	                                name = currentChild.childNodes[0].data;
	                            }
	                            if (currentChild.id== "update_date"  || currentChild.attributes[0].value=="update_date") {
	                                var tmpDate = new Date(parseInt(currentChild.childNodes[0].data, 10));
	                                lastModifiedTime = ((tmpDate.getDate() < 10) ? "0" : "") + tmpDate.getDate() + "." + ((tmpDate.getMonth()+1 < 10) ? "0" : "") + (tmpDate.getMonth()+1) + "." + tmpDate.getFullYear();
	                            }
	                         }
	                    }
	                    if (contentType == "WCM"){                          
	                        var newLink = link.replace('//','');
	                        var pos = newLink.indexOf('/');
	                        if (pos != -1) {
	                            newLink = newLink.substring(pos + 1);
	                            if (newLink.indexOf('?') != 0) {
	                                newLink = '/' + newLink;
	                            }
	                        }
	                        link = newLink;                          
	                    }
	 					mySpaceSearchResultsArray[mySpaceSearchResultsArray.length] = new mySpaceSearchResults(id, name, link, title, summary, authoringTemplate, lastModifiedTime);
	                    //if (id != null && MY_SPACE_AT_SERVICE_PROVIDED_BY_SUPPLIER == authoringTemplate) {
	                        docIds[docIds.length] = id;                        
	                    //}
						}
	              }
	              if (docIds.length == 0) {
	              	  console.log("mySpaceShowResults");
	              	  mySpaceShowResults();
	              } else {
	                  console.log("loadExtraData: " + docIds.length);
	                  mySpaceLoadExtraData(docIds);
				  }
			} else if (xmlHttpRequestObject.readyState != 0) {
			} else {
		        document.getElementById(MY_SPACE_SEARCH_SERVICES_RESULT_CONTAINER).innerHTML = "Error loading feed";
	            console.debug("failed xhrGet for URL: ", error, ioArgs);
	            document.getElementById(MY_SPACE_SEARCH_SERVICES_LOADER_DIV).style.display = 'none';
		    }		         
    	};
		xmlHttpRequestObject.send(null);
	}             
};


function mySpaceLoadExtraData(docIds) {
    if (docIds == null || docIds.length == 0) {
        mySpaceShowResults();
        return;
    }
    var dataStr = '';
    for (var i = 0; i < docIds.length; i++) {
        if (i > 0) {
            dataStr += ',';
        }
        dataStr += docIds[i];
    }
    var searchURL = document.location.href.substr(0, document.location.href.indexOf('/wps/'));
    searchURL += '/egov-search-ext/get-data?data=' + dataStr + '&rand=' + Math.random();
    var wsgXMLHttpRequestObject = new PortalXMLHttpRequestObject();
    var xmlHttpRequestObject = wsgXMLHttpRequestObject.getXMLHttpRequestObject();
    if (xmlHttpRequestObject) {
		xmlHttpRequestObject.open('GET', searchURL);
      	xmlHttpRequestObject.onreadystatechange = function() {
			if (xmlHttpRequestObject.readyState == 4 && xmlHttpRequestObject.status == 200) {
          		var xmlDoc = xmlHttpRequestObject.responseXML;
          		var node = xmlDoc.childNodes[0];
		        if (node == null) {
		            console.debug("ATOM XML has issues?");
		            mySpaceShowResults();
		            return;
		        }
		        var docId;
		        var id;
		        var name;
		        var title;
          		for (var i = 0; i < node.childNodes.length;i++){
              		var current = node.childNodes[i];
		            if (current.nodeName == "supplier") {
		                docId = "";
		                id = "";
		                name = "";
		                title = "";
		                for (var j = 0; j < current.childNodes.length;j++){
		                    var currentChild = current.childNodes[j];
		                    if (currentChild.nodeName == "docId") {
		                        docId = currentChild.childNodes[0].data;
		                    } else if (currentChild.nodeName == "id") {
		                        id = currentChild.childNodes[0].data;
		                    } else if (currentChild.nodeName == "name") {
		                        name = currentChild.childNodes[0].data;
		                    } else if (currentChild.nodeName == "title") {
		                        title = currentChild.childNodes[0].data;
		                    }
		                }
		                if (docId != null) {
		                    mySpaceHT.put(docId, title);
		                }
		             }
            	}
            	mySpaceShowResults();
	        } else if (xmlHttpRequestObject.readyState != 0) {
	        } else {          
	          console.debug("failed xhrGet for URL: ", error, ioArgs);
	         mySpaceShowResults();
	        }          
		};
	    xmlHttpRequestObject.send(null);  
	}
};

function mySpaceShowResults() {
	document.getElementById(MY_SPACE_SEARCH_SERVICES_LOADER_DIV).style.display='none';
	document.getElementById(MY_SPACE_SEARCH_SERVICES_RESULT_CONTAINER).style.display='none';	
    mySpaceRenderResults();
    console.log("MY_SPACE_REGISTER_CALLBACK_FUNCTION=" + MY_SPACE_REGISTER_CALLBACK_FUNCTION);
    if (MY_SPACE_REGISTER_CALLBACK_FUNCTION != null) {
    	eval(MY_SPACE_REGISTER_CALLBACK_FUNCTION);
    }
};

function mySpaceRenderResults() {
    document.getElementById(MY_SPACE_SEARCH_SERVICES_RESULT_CONTAINER).innerHTML = '';
    var output = '';
    if (mySpaceSearchResultsArray != null && mySpaceSearchResultsArray.length > 0) {
        for (var i = 0; i < mySpaceSearchResultsArray.length; i++) {
            output += mySpaceDisplayRow(mySpaceSearchResultsArray[i]);
        }
    }
    document.getElementById(MY_SPACE_SEARCH_SERVICES_RESULT_CONTAINER).style.display = '';
    if (document.getElementById(MY_SPACE_SEARCH_SERVICES_RESULT_NUMBER_DIV) != null) {
	    document.getElementById(MY_SPACE_SEARCH_SERVICES_RESULT_NUMBER_DIV).innerHTML = '<span class="portal-search-result-number-bold"> '
	        + MY_SPACE_TOTAL_RESULTS + '</span> ' + ((MY_SPACE_TOTAL_RESULTS == 1) ? MY_SPACE_COUNT_ONE_LABEL
	        : MY_SPACE_COUNT_MULTIPLE_LABEL) +
	        ' ' + MY_SPACE_NUMBER_RESULTS_FROM_SEARCH_LABEL + ' <span class="portal-search-result-number-bold">'
	        + MY_SPACE_SEARCH_TEXT + '</span>.';
    }
    document.getElementById(MY_SPACE_SEARCH_SERVICES_RESULT_CONTAINER).innerHTML = output;
    mySpaceDisplayPagination();
}

function mySpaceDisplayRow(searchResult) {  
	var supplier = mySpaceHT.get(searchResult.id);
    if (supplier != null) {
        searchResult.supplier = supplier;
    }
    var founded = false;
    var output = '<div class="portal-search-result-row pt-20">';
	    output += '<div class="' + MY_SPACE_SEARCH_ROW_CLASS + '">';
		    output += '<div><a class="portal-search-result-link" href="' + MY_SPACE_URL_PREFIX + _portalRemoveUrlWCMPrefix(searchResult.link) +'">' + searchResult.title + '</a></div>';
		    if (searchResult.supplier != undefined && MY_SPACE_SEARCH_SHOW_SUPPLIER) {
		        output += '<div id="mySpaceSupplier_' + searchResult.id +'" class="portal-search-result-supplier">' + MY_SPACE_SUPPLIER_LABEL + ': ' + searchResult.supplier + '</div>';
		    }
		    
		    if (searchResult.summary != undefined && MY_SPACE_SEARCH_SHOW_SUMMARY) {
		        output += '<div class="portal-search-result-summary">' + searchResult.summary + '</div>';
		    }
		    
		    if (searchResult.name != undefined && MY_SPACE_SEARCH_SHOW_SERVICE_NUMBER) {
		        output += '<div class="portal-search-service-number">' + MY_SPACE_SERVICE_NUMBER_LABEL + ': ' + searchResult.name + '</div>';
		    }
		    
		    if (searchResult.lastModifiedTime != undefined && MY_SPACE_SEARCH_SHOW_LAST_MODIFIED_TIME) {
		    	output += '<div class="portal-search-last-modified">' + MY_SPACE_LAST_UPDATED_LABEL + ': ' + searchResult.lastModifiedTime + '</div>';
		    }
	    output +='</div>';	    
	    if (MY_SPACE_REVERSE_ID_ARR != null && MY_SPACE_REVERSE_ID_ARR.length > 0) {	    	
	    	for (var i = 0; i < MY_SPACE_REVERSE_ID_ARR.length; i++) {
				if (MY_SPACE_REVERSE_ID_ARR[i] == searchResult.id) {
					founded = true;
					if (MY_SPACE_SEARCH_ROW_BUTTON_REVERSE) {
						output +='<div class="' + MY_SPACE_SEARCH_ROW_BUTTON_REVERSE_CLASS_DIV + '"><div class="' + MY_SPACE_SEARCH_ROW_BUTTON_REVERSE_CLASS + '" onclick="' + MY_SPACE_SEARCH_ROW_BUTTON_REVERSE_ON_CLICK_FUNCTION + '(this, \'' + searchResult.id + '\');">' + MY_SPACE_SEARCH_ROW_BUTTON_REVERSE_LABEL + '</div></div>';
					}
					break;
				}
			}
	    } 
    	if (!founded && MY_SPACE_SEARCH_ROW_BUTTON_SHOW) {
    		output +='<div class="' + MY_SPACE_SEARCH_ROW_BUTTON_CLASS_DIV + '"><div class="' + MY_SPACE_SEARCH_ROW_BUTTON_CLASS + '" onclick="' + (MY_SPACE_SEARCH_ROW_BUTTON_ON_CLICK_FUNCTION ? (MY_SPACE_SEARCH_ROW_BUTTON_ON_CLICK_FUNCTION_IS_ALERT ? MY_SPACE_SEARCH_ROW_BUTTON_ON_CLICK_FUNCTION : MY_SPACE_SEARCH_ROW_BUTTON_ON_CLICK_FUNCTION + '(this, \'' + searchResult.id + '\');') : '') + '">' + MY_SPACE_SEARCH_ROW_BUTTON_LABEL + '</div></div>';
    	}
	    
    output +='</div>';
    return output;
};

function mySpaceDisplayPagination() {
	if (document.getElementById(MY_SPACE_SEARCH_SERVICES_PAGINATION_DIV) == undefined) return;
    document.getElementById(MY_SPACE_SEARCH_SERVICES_PAGINATION_DIV).innerHTML = "";//prevent multiplication
    if (MY_SPACE_TOTAL_RESULTS == 0) {
        document.getElementById(MY_SPACE_SEARCH_SERVICES_PAGINATION_DIV).style.display='none';
        return;
    }
    document.getElementById(MY_SPACE_SEARCH_SERVICES_PAGINATION_DIV).style.display='';
    var pages = 0;
    if (MY_SPACE_TOTAL_RESULTS <= MY_SPACE_RESULTS_PER_PAGE && MY_SPACE_TOTAL_RESULTS > 0) {
        pages = 1;
    } else {
        pages = Math.ceil(MY_SPACE_TOTAL_RESULTS/MY_SPACE_RESULTS_PER_PAGE);
    }
    var str = '<div class="wpthemeNavigator">';
        str += '<div class="wpthemeNavigatorWrapper">';
            str += '<ul class="wpthemeNavigatorItems">';
            if (pages > 1) {
                str += '<li class="wpthemeNavigatorItemsPrevious"><span class="link" ' + ((MY_SPACE_CURRENT_PAGE > 1) ? 'onclick="mySpaceGoToPage(' + (MY_SPACE_CURRENT_PAGE - 1) + ')"' : '') + '>&lt;</span></li>';
            }
            if (pages > 5) {
                if (MY_SPACE_CURRENT_PAGE == 1) {
                    str += '<li class="wpthemeNavigatorItemSelected"><span class="link" onclick="mySpaceGoToPage('+ MY_SPACE_CURRENT_PAGE +')">' + MY_SPACE_CURRENT_PAGE + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceGoToPage('+ (MY_SPACE_CURRENT_PAGE + 1) +')">' + (MY_SPACE_CURRENT_PAGE + 1) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceGoToPage('+ (MY_SPACE_CURRENT_PAGE + 2) +')">' + (MY_SPACE_CURRENT_PAGE + 2) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceGoToPage('+ (MY_SPACE_CURRENT_PAGE + 3) +')">' + (MY_SPACE_CURRENT_PAGE + 3) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceGoToPage('+ (MY_SPACE_CURRENT_PAGE + 4) +')">' + (MY_SPACE_CURRENT_PAGE + 4) + '</span></li>';
                } else if (MY_SPACE_CURRENT_PAGE == 2) {
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceGoToPage('+ (MY_SPACE_CURRENT_PAGE - 1) +')">' + (MY_SPACE_CURRENT_PAGE - 1) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItemSelected"><span class="link" onclick="mySpaceGoToPage('+ MY_SPACE_CURRENT_PAGE +')">' + MY_SPACE_CURRENT_PAGE + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceGoToPage('+ (MY_SPACE_CURRENT_PAGE + 1) +')">' + (MY_SPACE_CURRENT_PAGE + 1) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceGoToPage('+ (MY_SPACE_CURRENT_PAGE + 2) +')">' + (MY_SPACE_CURRENT_PAGE + 2) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceGoToPage('+ (MY_SPACE_CURRENT_PAGE + 3) +')">' + (MY_SPACE_CURRENT_PAGE + 3) + '</span></li>';
                } else if (MY_SPACE_CURRENT_PAGE == pages) {
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceGoToPage('+ (MY_SPACE_CURRENT_PAGE - 4) +')">' + (MY_SPACE_CURRENT_PAGE - 4) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceGoToPage('+ (MY_SPACE_CURRENT_PAGE - 3) +')">' + (MY_SPACE_CURRENT_PAGE - 3) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceGoToPage('+ (MY_SPACE_CURRENT_PAGE - 2) +')">' + (MY_SPACE_CURRENT_PAGE - 2) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceGoToPage('+ (MY_SPACE_CURRENT_PAGE - 1) +')">' + (MY_SPACE_CURRENT_PAGE - 1) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItemSelected"><span class="link" onclick="mySpaceGoToPage('+ MY_SPACE_CURRENT_PAGE +')">' + MY_SPACE_CURRENT_PAGE + '</span></li>';
                } else if (MY_SPACE_CURRENT_PAGE + 1 == pages) {
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceGoToPage('+ (MY_SPACE_CURRENT_PAGE - 3) +')">' + (MY_SPACE_CURRENT_PAGE - 3) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceGoToPage('+ (MY_SPACE_CURRENT_PAGE - 2) +')">' + (MY_SPACE_CURRENT_PAGE - 2) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceGoToPage('+ (MY_SPACE_CURRENT_PAGE - 1) +')">' + (MY_SPACE_CURRENT_PAGE - 1) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItemSelected"><span class="link" onclick="mySpaceGoToPage('+ MY_SPACE_CURRENT_PAGE +')">' + MY_SPACE_CURRENT_PAGE + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceGoToPage('+ (MY_SPACE_CURRENT_PAGE + 1) +')">' + (MY_SPACE_CURRENT_PAGE + 1) + '</span></li>';
                } else {
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceGoToPage('+ (MY_SPACE_CURRENT_PAGE - 2) +')">' + (MY_SPACE_CURRENT_PAGE - 2) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceGoToPage('+ (MY_SPACE_CURRENT_PAGE - 1) +')">' + (MY_SPACE_CURRENT_PAGE - 1) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItemSelected"><span class="link" onclick="mySpaceGoToPage('+ MY_SPACE_CURRENT_PAGE +')">' + MY_SPACE_CURRENT_PAGE + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceGoToPage('+ (MY_SPACE_CURRENT_PAGE + 1) +')">' + (MY_SPACE_CURRENT_PAGE + 1) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceGoToPage('+ (MY_SPACE_CURRENT_PAGE + 2) +')">' + (MY_SPACE_CURRENT_PAGE + 2) + '</span></li>';
                }
            } else {
                for(var i = 1; i <= pages; i++){
                    if (pages == 1) {
                        //str += '<li class="wpthemeNavigatorItemSelected">' + i + '</li>'; //no pagination needed with single page
                        break;
                    }
                    if (MY_SPACE_CURRENT_PAGE == i) {
                        str += '<li class="wpthemeNavigatorItemSelected"><span class="link" onclick="mySpaceGoToPage('+ i +')">' + i + '</span></li>';
                    } else {
                        str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceGoToPage('+ i +')">' + i + '</span></li>';
                    }
                }
            }
            if (pages > 1) {
                str += '<li class="wpthemeNavigatorItemsNext"><span class="link" ' + ((MY_SPACE_CURRENT_PAGE < pages) ? 'onclick="mySpaceGoToPage(' + (MY_SPACE_CURRENT_PAGE + 1) + ')"' : '') + '>&gt;</span></li>';
            }
            str += '</ul>';
        str += '</div>';
    str += '</div>';
    str += '<div style="height: 40px;"></div>';
    document.getElementById(MY_SPACE_SEARCH_SERVICES_PAGINATION_DIV).innerHTML = str;
};

function mySpaceAuditLogServicesCall() {
	if (MY_SPACE_UUID_STR_ARR == null || MY_SPACE_UUID_STR_ARR.trim().length == 0) {
		mySpaceRenderAuditLogResults();
		return false;
	}
    var searchText = decodeURIComponent('uid');
    var searchURL = MY_SPACE_FEED_PREFIX +"?queryLang=en&locale="+MY_SPACE_LOCALE+"&resultLang="+MY_SPACE_RESULT_LANG+"&start=0&results=1000&scope="+ MY_SPACE_SCOPE_ID +"&query="+ encodeURIComponent(searchText);
    // Add order. (not needed here as we want the default order by relevance!)
    searchURL += '&sortKey=title&sortOrder=asc';
    // Add filter by docid.
    searchURL += '&constraint={"type":"field","id":"docid","values":[' + MY_SPACE_UUID_STR_ARR + ']}';
	searchURL += '&rand=' + Math.random();
    console.log("searchURL:" + searchURL);
   
    var tmpHT = new HashTable();
    document.getElementById(PORTLET_NAMESPACE + 'auditLogResultContainer').style.display = 'none';
	var wsgXMLHttpRequestObject = new PortalXMLHttpRequestObject();
  	var xmlHttpRequestObject = wsgXMLHttpRequestObject.getXMLHttpRequestObject();
  	if (xmlHttpRequestObject) {
    	xmlHttpRequestObject.open('GET', searchURL);
      	xmlHttpRequestObject.onreadystatechange = function() {
			if (xmlHttpRequestObject.readyState == 4 && xmlHttpRequestObject.status == 200) {
            	var xmlDoc = xmlHttpRequestObject.responseXML;
            	var node = xmlDoc.childNodes[0];
            	if (node == null) {
                	console.debug("ATOM XML has issues?");
                	return;
            	}   
 				var id;
            	var title;
				var link; 
				var dataArr;
				for (var i = 0; i < node.childNodes.length;i++) {
	                var current = node.childNodes[i];
	                if (current.nodeName == "atom:entry") {
	                    id = "";
	                    title = "";
	                    for (var j = 0; j < current.childNodes.length;j++){
	                        var currentChild=current.childNodes[j];
	                        //console.log("currentChild.nodeName " + currentChild.nodeName);
	                        if (currentChild.nodeName == "atom:id") {
	                            id = currentChild.childNodes[0].data;
	                        } else if (currentChild.nodeName == "atom:title") {
	                            title = currentChild.childNodes[0].data;
	                        } else if (currentChild.nodeName == "wplc:field" ){
	                            if (currentChild.id== "display_uri" || currentChild.attributes[0].value=="display_uri"){
	                                link = currentChild.childNodes[0].data;
	                            }                           
	                         }
	                    }
						if (link != null) {
							//need to use a relative URL
		                    var newLink = link.replace('//','');
		                    var pos = newLink.indexOf('/');
		                    if (pos != -1) {
		                        newLink = newLink.substring(pos + 1);
		                        if (newLink.indexOf('?') != 0) {
		                            newLink = '/' + newLink;
		                        }
		                    }
		                    link = newLink;
						}
						dataArr = new Array();
						dataArr[0] = title;
						dataArr[1] = link;
	                    //console.log(" tmpHT.put(id, title); =" +id + ", title=" + title);
	                    tmpHT.put(id, dataArr);                    
	                 }
	            }
	            console.log(" tmpHT: populated");
	            for (var i = 0; i < _mySpaceAuditLogs.length; i++) {
	            	//console.log("_mySpaceAuditLogs[" + i + "] = " + _mySpaceAuditLogs[i][1]);
	            	var tmpData = null;
	            	if (EVENT_LOG_PORTAL_LAST_VISITED_SERVICE == _mySpaceAuditLogs[i][1]
							|| EVENT_LOG_PORTAL_ADD_FAVOURITE_SERVICE == _mySpaceAuditLogs[i][1]
							|| EVENT_LOG_PORTAL_REMOVE_FAVOURITE_SERVICE == _mySpaceAuditLogs[i][1]) {
	            		//console.log("_mySpaceAuditLogs[" + i + "] is EVENT_LOG_PORTAL_LAST_VISITED_SERVICE");
	            		tmpData = tmpHT.get(_mySpaceAuditLogs[i][2]);
	            		//console.log("tmpHT.get(" + _mySpaceAuditLogs[i][2] + ")");
	            		if (tmpData != null && tmpData.length > 1) {
	            			//console.log("_mySpaceAuditLogs[" + i + "] has value!");
							if (tmpData[1] != null) {
	            				_mySpaceAuditLogs[i][3] = '<a href="' + MY_SPACE_URL_PREFIX + _portalRemoveUrlWCMPrefix(tmpData[1]) + '">' + tmpData[0].replace(/'/g,'&#39;') + '</a>';
							} else {
								_mySpaceAuditLogs[i][3] = tmpData[0].replace(/'/g,'&#39;');
							}
	            		} else {
	            			_mySpaceAuditLogs[i][3] = '';
	            		}
	            		_mySpaceAuditLogs[i][2] = 'Преглед на услуга';
						if (EVENT_LOG_PORTAL_ADD_FAVOURITE_SERVICE == _mySpaceAuditLogs[i][1]) {
							_mySpaceAuditLogs[i][2] = 'Добавяне на услуга към "предпочитани"';
						} else if (EVENT_LOG_PORTAL_REMOVE_FAVOURITE_SERVICE == _mySpaceAuditLogs[i][1]) {
							_mySpaceAuditLogs[i][2] = 'Премахване на услуга от "предпочитани"';
						} 
	            	}				
				}            
	            document.getElementById(PORTLET_NAMESPACE + 'auditLogResultContainer').style.display = 'table';
	            console.log(" call mySpaceRenderAuditLogResults()");
	            mySpaceRenderAuditLogResults();
			} else if (xmlHttpRequestObject.readyState != 0) {
	        } else {
	        	console.debug("failed xhrGet for URL: ", error, ioArgs);  
	       }
          
    	};
    	xmlHttpRequestObject.send(null);  
  	}
};		

function mySpaceRenderAuditLogResults() {
    document.getElementById(PORTLET_NAMESPACE + 'auditLogResultContainer').innerHTML = '';
    var output = '';
    if (_mySpaceAuditLogs != null && _mySpaceAuditLogs.length > 0) {
    	for(var i = ((MY_SPACE_CURRENT_PAGE - 1) * MY_SPACE_RESULTS_PER_PAGE), j = 0; i < _mySpaceAuditLogs.length; i++, j++) {
            if (j == MY_SPACE_RESULTS_PER_PAGE) {break;}              
            output += mySpaceDisplayAuditLogRow(_mySpaceAuditLogs[i], j % 2 == 1);
        }
    }   
    document.getElementById(PORTLET_NAMESPACE + 'auditLogResultContainer').innerHTML = document.getElementById(PORTLET_NAMESPACE + 'auditLogResultTableHeaderDump').innerHTML;
    document.getElementById(PORTLET_NAMESPACE + 'auditLogResultContainer').innerHTML += output;
    mySpaceDisplayAuditLogPagination();
};

function mySpaceDisplayAuditLogRow(auditLog, colored) {   
	var output = '<div class="table-row' + (colored ? '-colored' : '') + '">';
	output += '<div class="row c-15"><p>' + auditLog[0] + '</p></div>';
	output += '<div class="row c-34"><p>' + auditLog[2] + '</p></div>';
	output += '<div class="row c-34"><p>' + auditLog[3] + '</p></div>';
	output += '<div class="row c-15"><p>' + auditLog[4] + '</p></div>';
	output += '</div>';
    return output;
};

function mySpaceDisplayAuditLogPagination() {
    document.getElementById(PORTLET_NAMESPACE + 'auditLogPaginationDiv').innerHTML = "";//prevent multiplication
    if (MY_SPACE_TOTAL_RESULTS <= MY_SPACE_RESULTS_PER_PAGE) {
        document.getElementById(PORTLET_NAMESPACE + 'auditLogPaginationDiv').style.display='none';
        return;
    }
    document.getElementById(PORTLET_NAMESPACE + 'auditLogPaginationDiv').style.display='';
    var pages = 0;
    if (MY_SPACE_TOTAL_RESULTS <= MY_SPACE_RESULTS_PER_PAGE && MY_SPACE_TOTAL_RESULTS > 0) {
        pages = 1;
    } else {
        pages = Math.ceil(MY_SPACE_TOTAL_RESULTS/MY_SPACE_RESULTS_PER_PAGE);
    }
    var str = '<div class="wpthemeNavigator">';
        str += '<div class="wpthemeNavigatorWrapper">';
            str += '<ul class="wpthemeNavigatorItems">';
            if (pages > 1) {
                str += '<li class="wpthemeNavigatorItemsPrevious"><span class="link" ' + ((MY_SPACE_CURRENT_PAGE > 1) ? 'onclick="mySpaceAuditLogGoToPage(' + (MY_SPACE_CURRENT_PAGE - 1) + ')"' : '') + '>&lt;</span></li>';
            }
            if (pages > 5) {
                if (MY_SPACE_CURRENT_PAGE == 1) {
                    str += '<li class="wpthemeNavigatorItemSelected"><span class="link" onclick="mySpaceAuditLogGoToPage('+ MY_SPACE_CURRENT_PAGE +')">' + MY_SPACE_CURRENT_PAGE + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceAuditLogGoToPage('+ (MY_SPACE_CURRENT_PAGE + 1) +')">' + (MY_SPACE_CURRENT_PAGE + 1) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceAuditLogGoToPage('+ (MY_SPACE_CURRENT_PAGE + 2) +')">' + (MY_SPACE_CURRENT_PAGE + 2) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceAuditLogGoToPage('+ (MY_SPACE_CURRENT_PAGE + 3) +')">' + (MY_SPACE_CURRENT_PAGE + 3) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceAuditLogGoToPage('+ (MY_SPACE_CURRENT_PAGE + 4) +')">' + (MY_SPACE_CURRENT_PAGE + 4) + '</span></li>';
                } else if (MY_SPACE_CURRENT_PAGE == 2) {
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceAuditLogGoToPage('+ (MY_SPACE_CURRENT_PAGE - 1) +')">' + (MY_SPACE_CURRENT_PAGE - 1) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItemSelected"><span class="link" onclick="mySpaceAuditLogGoToPage('+ MY_SPACE_CURRENT_PAGE +')">' + MY_SPACE_CURRENT_PAGE + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceAuditLogGoToPage('+ (MY_SPACE_CURRENT_PAGE + 1) +')">' + (MY_SPACE_CURRENT_PAGE + 1) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceAuditLogGoToPage('+ (MY_SPACE_CURRENT_PAGE + 2) +')">' + (MY_SPACE_CURRENT_PAGE + 2) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceAuditLogGoToPage('+ (MY_SPACE_CURRENT_PAGE + 3) +')">' + (MY_SPACE_CURRENT_PAGE + 3) + '</span></li>';
                } else if (MY_SPACE_CURRENT_PAGE == pages) {
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceAuditLogGoToPage('+ (MY_SPACE_CURRENT_PAGE - 4) +')">' + (MY_SPACE_CURRENT_PAGE - 4) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceAuditLogGoToPage('+ (MY_SPACE_CURRENT_PAGE - 3) +')">' + (MY_SPACE_CURRENT_PAGE - 3) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceAuditLogGoToPage('+ (MY_SPACE_CURRENT_PAGE - 2) +')">' + (MY_SPACE_CURRENT_PAGE - 2) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceAuditLogGoToPage('+ (MY_SPACE_CURRENT_PAGE - 1) +')">' + (MY_SPACE_CURRENT_PAGE - 1) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItemSelected"><span class="link" onclick="mySpaceAuditLogGoToPage('+ MY_SPACE_CURRENT_PAGE +')">' + MY_SPACE_CURRENT_PAGE + '</span></li>';
                } else if (MY_SPACE_CURRENT_PAGE + 1 == pages) {
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceAuditLogGoToPage('+ (MY_SPACE_CURRENT_PAGE - 3) +')">' + (MY_SPACE_CURRENT_PAGE - 3) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceAuditLogGoToPage('+ (MY_SPACE_CURRENT_PAGE - 2) +')">' + (MY_SPACE_CURRENT_PAGE - 2) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceAuditLogGoToPage('+ (MY_SPACE_CURRENT_PAGE - 1) +')">' + (MY_SPACE_CURRENT_PAGE - 1) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItemSelected"><span class="link" onclick="mySpaceAuditLogGoToPage('+ MY_SPACE_CURRENT_PAGE +')">' + MY_SPACE_CURRENT_PAGE + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceAuditLogGoToPage('+ (MY_SPACE_CURRENT_PAGE + 1) +')">' + (MY_SPACE_CURRENT_PAGE + 1) + '</span></li>';
                } else {
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceAuditLogGoToPage('+ (MY_SPACE_CURRENT_PAGE - 2) +')">' + (MY_SPACE_CURRENT_PAGE - 2) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceAuditLogGoToPage('+ (MY_SPACE_CURRENT_PAGE - 1) +')">' + (MY_SPACE_CURRENT_PAGE - 1) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItemSelected"><span class="link" onclick="mySpaceAuditLogGoToPage('+ MY_SPACE_CURRENT_PAGE +')">' + MY_SPACE_CURRENT_PAGE + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceAuditLogGoToPage('+ (MY_SPACE_CURRENT_PAGE + 1) +')">' + (MY_SPACE_CURRENT_PAGE + 1) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceAuditLogGoToPage('+ (MY_SPACE_CURRENT_PAGE + 2) +')">' + (MY_SPACE_CURRENT_PAGE + 2) + '</span></li>';
                }
            } else {
                for(var i = 1; i <= pages; i++){
                    if (pages == 1) {
                        //str += '<li class="wpthemeNavigatorItemSelected">' + i + '</li>'; //no pagination needed with single page
                        break;
                    }
                    if (MY_SPACE_CURRENT_PAGE == i) {
                        str += '<li class="wpthemeNavigatorItemSelected"><span class="link" onclick="mySpaceAuditLogGoToPage('+ i +')">' + i + '</span></li>';
                    } else {
                        str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceAuditLogGoToPage('+ i +')">' + i + '</span></li>';
                    }
                }
            }
            if (pages > 1) {
                str += '<li class="wpthemeNavigatorItemsNext"><span class="link" ' + ((MY_SPACE_CURRENT_PAGE < pages) ? 'onclick="mySpaceAuditLogGoToPage(' + (MY_SPACE_CURRENT_PAGE + 1) + ')"' : '') + '>&gt;</span></li>';
            }
            str += '</ul>';
        str += '</div>';
    str += '</div>';
    str += '<div style="height: 40px;"></div>';
    document.getElementById(PORTLET_NAMESPACE + 'auditLogPaginationDiv').innerHTML = str;
};

function mySpaceAuditLogGoToPage(number) {
	MY_SPACE_CURRENT_PAGE = number;
	mySpaceRenderAuditLogResults();
};

function mySpaceLoadServicesClassification(resourceURL, categoryId, categoryTitle, showMessage) {
	if (showMessage == null || !showMessage) {removeMessageBox();}
	mySpaceClearCatalogServicesSearchText();
	mySpaceHideCatalogServicesHideResultContainer();
	document.getElementById(MY_SPACE_SEARCH_SERVICES_LOADER_DIV).style.display = '';
	var container = document.getElementById(PORTLET_NAMESPACE + 'catalogServicesClassificationDIV');
	container.innerHTML = '';
	var url = resourceURL;
	url = url.substring(0, url.length - 1);
	// add action parameter -> Evalue!all=action!add==/
	url += 'Eaction!getServicesClassification' + (categoryId != null ? '=pageUniqueName!' + categoryId : '') + '==/'; 
	console.log("url=" + url);
	var wsgXMLHttpRequestObject = new PortalXMLHttpRequestObject();
  	var xmlHttpRequestObject = wsgXMLHttpRequestObject.getXMLHttpRequestObject();
  	if (xmlHttpRequestObject) {
		xmlHttpRequestObject.overrideMimeType("application/json");
    	xmlHttpRequestObject.open('GET', url);
      	xmlHttpRequestObject.onreadystatechange = function() {
        	if (xmlHttpRequestObject.readyState == 4 && xmlHttpRequestObject.status == 200) {
				jsonData = JSON.parse(xmlHttpRequestObject.responseText);
            	if (jsonData == null) {
        			console.debug("XML has issues?");
        			return;
	        	}
	        	document.getElementById(MY_SPACE_SEARCH_SERVICES_LOADER_DIV).style.display = 'none';	
        		if (jsonData.data != undefined && jsonData.data.length > 0) {
					var html = '';
	        		for (var i = 0; i < jsonData.data.length; i++) {
						if (categoryId != null) {
							html+='<p><a href="javascript:void(0)" onclick="mySpaceSearchServicesInServicesClassification(\'' + resourceURL + '\',\'' + jsonData.data[i][0] + '\', \'' + jsonData.data[i][1] + '\'); return false;">' + jsonData.data[i][1] + '</a></p>';
						} else {
							html+='<p><a href="javascript:void(0)" onclick="mySpaceLoadServicesClassification(\'' + resourceURL + '\',\'' + jsonData.data[i][0] + '\', \'' + jsonData.data[i][1] + '\'); return false;">' + jsonData.data[i][1] + '</a></p>';
						}
					}
					container.innerHTML = html;
					container.style.display = '';
					_CATALOG_SERVICE_PAGE_UNIQUE_NAME = categoryId;
					_CATALOG_SERVICE_PAGE_TITLE = categoryTitle;
					_CATALOG_SERVICE_SUB_PAGE_UNIQUE_NAME = '';
					_CATALOG_SERVICE_SUB_PAGE_TITLE = '';				
					mySpaceBuildCatalogServicesBreadcrumb(resourceURL);
					mySpaceUpdateCatalogServicesSearchPlaceholder();
	        	}     
            } else if (xmlHttpRequestObject.readyState != 0) {
		    } else {
		       	console.debug("failed xhrGet for URL: ", error, ioArgs);
            	alert(error);
		    }
 		};
    	xmlHttpRequestObject.send(null);  
	}
};

function mySpaceSearchServicesInServicesClassification(resourceURL, categoryId, categoryTitle, showMessage) {
	if (showMessage == null || !showMessage) {removeMessageBox();}
	document.getElementById(MY_SPACE_SEARCH_SERVICES_LOADER_DIV).style.display = '';	
	var servicesContainer = document.getElementById(MY_SPACE_SEARCH_SERVICES_RESULT_CONTAINER);
	var catalogContainer = document.getElementById(PORTLET_NAMESPACE + 'catalogServicesClassificationDIV');
	var searchField = document.getElementById(PORTLET_NAMESPACE + 'catalogServicesSearchField').value;	
	if (categoryId == null) {
		categoryId = _CATALOG_SERVICE_SUB_PAGE_UNIQUE_NAME;
		categoryTitle = _CATALOG_SERVICE_SUB_PAGE_TITLE;
	}
	// Search button was clicked without category and search term, so show catalog again.
	if ((categoryId == null || categoryId == '') && searchField.trim().length == 0) {
		mySpaceCatalogServiceShowClassification();
		return;
	}	
	catalogContainer.style.display = 'none';
	var query = (categoryId != null ? '=subPageUniqueName!' + categoryId : '');
	if (searchField.trim().length > 0) {
		query += '=searchString!' + searchField.trim();
	}
	_MY_FAVORITE_SERVICES_UUIDS = new Array();
	_CATALOG_SERVICES = new Array();
	MY_SPACE_CURRENT_PAGE = 1;
	MY_SPACE_TOTAL_RESULTS = 0;
	servicesContainer.innerHTML = '';
	var url = resourceURL;
	url = url.substring(0, url.length - 1);
	// add action parameter -> Evalue!all=action!add==/
	url += 'Eaction!getServicesForCatalog' + query + '==/'; 
	console.log("url=" + url);
	var wsgXMLHttpRequestObject = new PortalXMLHttpRequestObject();
  	var xmlHttpRequestObject = wsgXMLHttpRequestObject.getXMLHttpRequestObject();
  	if (xmlHttpRequestObject) {
		xmlHttpRequestObject.overrideMimeType("application/json");
    	xmlHttpRequestObject.open('GET', url);
      	xmlHttpRequestObject.onreadystatechange = function() {
        	if (xmlHttpRequestObject.readyState == 4 && xmlHttpRequestObject.status == 200) {
				jsonData = JSON.parse(xmlHttpRequestObject.responseText);
            	if (jsonData == null) {
        			console.debug("XML has issues?");
        			return;
	        	}
	        	document.getElementById(MY_SPACE_SEARCH_SERVICES_LOADER_DIV).style.display = 'none';
				var html = '';	
	        	if (jsonData.data != undefined) {				
					if (jsonData.data.favoritesServicesUUIDs != undefined && jsonData.data.favoritesServicesUUIDs.trim().length > 0) {
						_MY_FAVORITE_SERVICES_UUIDS = jsonData.data.favoritesServicesUUIDs.split(',');
					}
					if (jsonData.data.servicesUUIDs != undefined && jsonData.data.servicesUUIDs.length > 0) {
						console.log(jsonData.data.servicesUUIDs);
						_CATALOG_SERVICES = jsonData.data.servicesUUIDs;
						MY_SPACE_TOTAL_RESULTS = _CATALOG_SERVICES.length;
						html = mySpaceCatalogServiceRenderResults(resourceURL);
					} else {
						html = '<p>Няма намерени резултати.</p>';	
					}				        						
	        	} else {
					html = '<p>Няма намерени резултати.</p>';
				}   
				servicesContainer.innerHTML = html;    
				servicesContainer.style.display = '';       
				_CATALOG_SERVICE_SUB_PAGE_UNIQUE_NAME = categoryId;
				_CATALOG_SERVICE_SUB_PAGE_TITLE = categoryTitle;
				mySpaceBuildCatalogServicesBreadcrumb(resourceURL);
				mySpaceUpdateCatalogServicesSearchPlaceholder();     
            } else if (xmlHttpRequestObject.readyState != 0) {
		    } else {
		       	console.debug("failed xhrGet for URL: ", error, ioArgs);
            	alert(error);
		    }
 		};
    	xmlHttpRequestObject.send(null);  
	}
};	
	
function mySpaceCatalogServiceRenderResults(resourceURL) {
	var searchField = document.getElementById(PORTLET_NAMESPACE + 'catalogServicesSearchField').value;
    var html = ''; 	
    if (_CATALOG_SERVICES != null && _CATALOG_SERVICES.length > 0) {
		for(var i = ((MY_SPACE_CURRENT_PAGE - 1) * MY_SPACE_RESULTS_PER_PAGE), j = 0; i < _CATALOG_SERVICES.length; i++, j++) {
            if (j == MY_SPACE_RESULTS_PER_PAGE) {break;}        
            html += mySpaceCatalogServiceDisplayRow(_CATALOG_SERVICES[i], resourceURL);
		}        
    }
	if (searchField.trim().length > 0) {
		var totalResults = _CATALOG_SERVICES.length;
	    if (document.getElementById(MY_SPACE_SEARCH_SERVICES_RESULT_NUMBER_DIV) != null) {
		    document.getElementById(MY_SPACE_SEARCH_SERVICES_RESULT_NUMBER_DIV).innerHTML = '<span class="portal-search-result-number-bold"> '
		        + totalResults + '</span> ' + ((totalResults == 1) ? MY_SPACE_COUNT_ONE_LABEL
		        : MY_SPACE_COUNT_MULTIPLE_LABEL) +
		        ' ' + MY_SPACE_NUMBER_RESULTS_FROM_SEARCH_LABEL + ' <span class="portal-search-result-number-bold">'
		        + searchField.trim() + '</span>.';
	    }
	}
    mySpaceCatalogServiceDisplayPagination(resourceURL);
	return html;
}

function mySpaceCatalogServiceDisplayRow(searchResult, resourceURL) {  
    var founded = _MY_FAVORITE_SERVICES_UUIDS.indexOf(searchResult[0]) != -1;
	if (searchResult[4].startsWith("/")) {
		searchResult[4] = searchResult[4].substr(1);
	}
    var output = '<div class="portal-search-result-row pt-20">';
	    output += '<div class="' + MY_SPACE_SEARCH_ROW_CLASS + '">';
		    output += '<div><a class="portal-search-result-link" href="' + MY_SPACE_URL_CONTEXT + searchResult[4] +'">' + searchResult[1] + '</a></div>';
		    if (searchResult[3].trim().length > 0) {
		    	output += '<div id="mySpaceSupplier_' + searchResult[0] +'" class="portal-search-result-supplier">' + MY_SPACE_SUPPLIER_LABEL + ': ' + searchResult[3] + '</div>';
		    }
		    output += '<div class="portal-search-service-number">' + MY_SPACE_SERVICE_NUMBER_LABEL + ': ' + searchResult[2] + '</div>';
		    output += '<div class="portal-search-last-modified">' + MY_SPACE_LAST_UPDATED_LABEL + ': ' + searchResult[5] + '</div>';
	    output +='</div>';	    	    
    	if (!founded) {
    		output +='<div class="' + MY_SPACE_SEARCH_ROW_BUTTON_CLASS_DIV + '"><div class="' + MY_SPACE_SEARCH_ROW_BUTTON_CLASS + '" onclick="' + (MY_SPACE_SEARCH_ROW_BUTTON_ON_CLICK_FUNCTION ? (MY_SPACE_SEARCH_ROW_BUTTON_ON_CLICK_FUNCTION_IS_ALERT ? MY_SPACE_SEARCH_ROW_BUTTON_ON_CLICK_FUNCTION : MY_SPACE_SEARCH_ROW_BUTTON_ON_CLICK_FUNCTION + '(this, \'' + searchResult[0] + '\', \'' + resourceURL + '\');') : '') + '">' + MY_SPACE_SEARCH_ROW_BUTTON_LABEL + '</div></div>';
    	}
	    
    output +='</div><div class="my-space-catalog-service-divider"></div>';
    return output;
};

function mySpaceCatalogServiceDisplayPagination(resourceURL) {
	if (document.getElementById(MY_SPACE_SEARCH_SERVICES_PAGINATION_DIV) == undefined) return;
    document.getElementById(MY_SPACE_SEARCH_SERVICES_PAGINATION_DIV).innerHTML = "";//prevent multiplication
    if (MY_SPACE_TOTAL_RESULTS == 0) {
        document.getElementById(MY_SPACE_SEARCH_SERVICES_PAGINATION_DIV).style.display='none';
        return;
    }
    document.getElementById(MY_SPACE_SEARCH_SERVICES_PAGINATION_DIV).style.display='';
    var pages = 0;
    if (MY_SPACE_TOTAL_RESULTS <= MY_SPACE_RESULTS_PER_PAGE && MY_SPACE_TOTAL_RESULTS > 0) {
        pages = 1;
    } else {
        pages = Math.ceil(MY_SPACE_TOTAL_RESULTS/MY_SPACE_RESULTS_PER_PAGE);
    }
    var str = '<div class="wpthemeNavigator">';
        str += '<div class="wpthemeNavigatorWrapper">';
            str += '<ul class="wpthemeNavigatorItems">';
            if (pages > 1) {
                str += '<li class="wpthemeNavigatorItemsPrevious"><span class="' + (MY_SPACE_CURRENT_PAGE > 1 ? 'link' : 'link-inactive') + '" ' + ((MY_SPACE_CURRENT_PAGE > 1) ? 'onclick="mySpaceCatalogServiceGoToPage(' + (MY_SPACE_CURRENT_PAGE - 1) + ',\'' + resourceURL + '\')"' : '') + '>&lt;</span></li>';
            }
            if (pages > 5) {
                if (MY_SPACE_CURRENT_PAGE == 1) {
                    str += '<li class="wpthemeNavigatorItemSelected"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ MY_SPACE_CURRENT_PAGE +',\'' + resourceURL + '\')">' + MY_SPACE_CURRENT_PAGE + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ (MY_SPACE_CURRENT_PAGE + 1) +',\'' + resourceURL + '\')">' + (MY_SPACE_CURRENT_PAGE + 1) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ (MY_SPACE_CURRENT_PAGE + 2) +',\'' + resourceURL + '\')">' + (MY_SPACE_CURRENT_PAGE + 2) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ (MY_SPACE_CURRENT_PAGE + 3) +',\'' + resourceURL + '\')">' + (MY_SPACE_CURRENT_PAGE + 3) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ (MY_SPACE_CURRENT_PAGE + 4) +',\'' + resourceURL + '\')">' + (MY_SPACE_CURRENT_PAGE + 4) + '</span></li>';
                } else if (MY_SPACE_CURRENT_PAGE == 2) {
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ (MY_SPACE_CURRENT_PAGE - 1) +',\'' + resourceURL + '\')">' + (MY_SPACE_CURRENT_PAGE - 1) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItemSelected"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ MY_SPACE_CURRENT_PAGE +',\'' + resourceURL + '\')">' + MY_SPACE_CURRENT_PAGE + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ (MY_SPACE_CURRENT_PAGE + 1) +',\'' + resourceURL + '\')">' + (MY_SPACE_CURRENT_PAGE + 1) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ (MY_SPACE_CURRENT_PAGE + 2) +',\'' + resourceURL + '\')">' + (MY_SPACE_CURRENT_PAGE + 2) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ (MY_SPACE_CURRENT_PAGE + 3) +',\'' + resourceURL + '\')">' + (MY_SPACE_CURRENT_PAGE + 3) + '</span></li>';
                } else if (MY_SPACE_CURRENT_PAGE == pages) {
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ (MY_SPACE_CURRENT_PAGE - 4) +',\'' + resourceURL + '\')">' + (MY_SPACE_CURRENT_PAGE - 4) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ (MY_SPACE_CURRENT_PAGE - 3) +',\'' + resourceURL + '\')">' + (MY_SPACE_CURRENT_PAGE - 3) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ (MY_SPACE_CURRENT_PAGE - 2) +',\'' + resourceURL + '\')">' + (MY_SPACE_CURRENT_PAGE - 2) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ (MY_SPACE_CURRENT_PAGE - 1) +',\'' + resourceURL + '\')">' + (MY_SPACE_CURRENT_PAGE - 1) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItemSelected"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ MY_SPACE_CURRENT_PAGE +',\'' + resourceURL + '\')">' + MY_SPACE_CURRENT_PAGE + '</span></li>';
                } else if (MY_SPACE_CURRENT_PAGE + 1 == pages) {
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ (MY_SPACE_CURRENT_PAGE - 3) +',\'' + resourceURL + '\')">' + (MY_SPACE_CURRENT_PAGE - 3) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ (MY_SPACE_CURRENT_PAGE - 2) +',\'' + resourceURL + '\')">' + (MY_SPACE_CURRENT_PAGE - 2) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ (MY_SPACE_CURRENT_PAGE - 1) +',\'' + resourceURL + '\')">' + (MY_SPACE_CURRENT_PAGE - 1) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItemSelected"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ MY_SPACE_CURRENT_PAGE +',\'' + resourceURL + '\')">' + MY_SPACE_CURRENT_PAGE + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ (MY_SPACE_CURRENT_PAGE + 1) +',\'' + resourceURL + '\')">' + (MY_SPACE_CURRENT_PAGE + 1) + '</span></li>';
                } else {
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ (MY_SPACE_CURRENT_PAGE - 2) +',\'' + resourceURL + '\')">' + (MY_SPACE_CURRENT_PAGE - 2) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ (MY_SPACE_CURRENT_PAGE - 1) +',\'' + resourceURL + '\')">' + (MY_SPACE_CURRENT_PAGE - 1) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItemSelected"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ MY_SPACE_CURRENT_PAGE +',\'' + resourceURL + '\')">' + MY_SPACE_CURRENT_PAGE + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ (MY_SPACE_CURRENT_PAGE + 1) +',\'' + resourceURL + '\')">' + (MY_SPACE_CURRENT_PAGE + 1) + '</span></li>';
                    str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ (MY_SPACE_CURRENT_PAGE + 2) +',\'' + resourceURL + '\')">' + (MY_SPACE_CURRENT_PAGE + 2) + '</span></li>';
                }
            } else {
                for(var i = 1; i <= pages; i++){
                    if (pages == 1) {
                        //str += '<li class="wpthemeNavigatorItemSelected">' + i + '</li>'; //no pagination needed with single page
                        break;
                    }
                    if (MY_SPACE_CURRENT_PAGE == i) {
                        str += '<li class="wpthemeNavigatorItemSelected"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ i +',\'' + resourceURL + '\')">' + i + '</span></li>';
                    } else {
                        str += '<li class="wpthemeNavigatorItem"><span class="link" onclick="mySpaceCatalogServiceGoToPage('+ i +',\'' + resourceURL + '\')">' + i + '</span></li>';
                    }
                }
            }
            if (pages > 1) {
                str += '<li class="wpthemeNavigatorItemsNext"><span class="' + (pages > MY_SPACE_CURRENT_PAGE ? 'link' : 'link-inactive') + '" ' + ((MY_SPACE_CURRENT_PAGE < pages) ? 'onclick="mySpaceCatalogServiceGoToPage(' + (MY_SPACE_CURRENT_PAGE + 1) + ',\'' + resourceURL + '\')"' : '') + '>&gt;</span></li>';
            }
            str += '</ul>';
        str += '</div>';
    str += '</div>';
    str += '<div style="height: 40px;"></div>';
    document.getElementById(MY_SPACE_SEARCH_SERVICES_PAGINATION_DIV).innerHTML = str;
};

function mySpaceCatalogServiceGoToPage(number, resourceURL) {
	var servicesContainer = document.getElementById(MY_SPACE_SEARCH_SERVICES_RESULT_CONTAINER);
	MY_SPACE_CURRENT_PAGE = number;
	servicesContainer.innerHTML = mySpaceCatalogServiceRenderResults(resourceURL);
};

function mySpaceCatalogServiceShowClassification() {
	var servicesContainer = document.getElementById(MY_SPACE_SEARCH_SERVICES_RESULT_CONTAINER);
	var catalogContainer = document.getElementById(PORTLET_NAMESPACE + 'catalogServicesClassificationDIV');
	document.getElementById(MY_SPACE_SEARCH_SERVICES_LOADER_DIV).style.display = 'none';
	document.getElementById(MY_SPACE_SEARCH_SERVICES_RESULT_NUMBER_DIV).innerHTML = '';
	catalogContainer.style.display = '';
	servicesContainer.style.display = 'none';
	document.getElementById(PORTLET_NAMESPACE + 'catalogServicesSearchField').value = '';
	if (document.getElementById(PORTLET_NAMESPACE + 'mySpaceServiceCatalogBreadCrumbActive') != null) {
		var tmpHtml = document.getElementById(PORTLET_NAMESPACE + 'mySpaceServiceCatalogBreadCrumbActive').innerHTML;
		var pos = tmpHtml.indexOf(' <a');
		if (pos != -1) {
			document.getElementById(PORTLET_NAMESPACE + 'mySpaceServiceCatalogBreadCrumbActive').innerHTML = tmpHtml.substr(0, pos);
		}
	}	
};

function mySpaceHideCatalogServicesHideResultContainer() {
	document.getElementById(MY_SPACE_SEARCH_SERVICES_RESULT_CONTAINER).innerHTML = '';
	document.getElementById(MY_SPACE_SEARCH_SERVICES_RESULT_NUMBER_DIV).innerHTML = '';
	document.getElementById(MY_SPACE_SEARCH_SERVICES_PAGINATION_DIV).innerHTML = '';
};

function mySpaceHideCatalogServicesHideClassification() {
	document.getElementById(PORTLET_NAMESPACE + 'catalogServicesClassificationDIV').innerHTML = '';		
};

function mySpaceClearCatalogServicesCategories() {
	_CATALOG_SERVICE_PAGE_UNIQUE_NAME = '';
 	_CATALOG_SERVICE_PAGE_TITLE = '';
 	_CATALOG_SERVICE_SUB_PAGE_UNIQUE_NAME= '';
 	_CATALOG_SERVICE_SUB_PAGE_TITLE= '';
};
function mySpaceClearCatalogServicesSearchText() {
	document.getElementById(PORTLET_NAMESPACE + 'catalogServicesSearchField').value = '';
};

function mySpaceBuildCatalogServicesBreadcrumb(resourceURL) {
	var breadcrumb = document.getElementById(PORTLET_NAMESPACE + 'catalogServicesBreadcrumbContainer');
	var searchText = document.getElementById(PORTLET_NAMESPACE + 'catalogServicesSearchField').value.trim();
	if (breadcrumb == null) return;
	var html = '';
	if (_CATALOG_SERVICE_PAGE_UNIQUE_NAME == null || _CATALOG_SERVICE_PAGE_UNIQUE_NAME.trim().length == 0) {
		html = '<div id="' + PORTLET_NAMESPACE + 'mySpaceServiceCatalogBreadCrumbActive">Всички';		
		if (searchText.length > 0 && (_CATALOG_SERVICE_SUB_PAGE_UNIQUE_NAME == null || _CATALOG_SERVICE_SUB_PAGE_UNIQUE_NAME.trim().length == 0)) {
			html += ' <a href="javascript:void(0);" onclick="mySpaceLoadServicesClassification(\'' + resourceURL + '\');">(Обратно към каталога на услуги)</a>';
		}
		html += '</div>';	
	} else {
		html = '<div><a href="javascript:void(0);" onclick="mySpaceClearCatalogServicesCategories();mySpaceLoadServicesClassification(\'' + resourceURL + '\', null, null);">Всички</a></div>';
		html += '<div>&nbsp;/&nbsp;</div>';
		if (_CATALOG_SERVICE_SUB_PAGE_UNIQUE_NAME == null || _CATALOG_SERVICE_SUB_PAGE_UNIQUE_NAME.trim().length == 0) {
			html += '<div id="' + PORTLET_NAMESPACE + 'mySpaceServiceCatalogBreadCrumbActive">' + _CATALOG_SERVICE_PAGE_TITLE;
			if (searchText.length > 0) {
				html += ' <a href="javascript:void(0);" onclick="mySpaceLoadServicesClassification(\'' + resourceURL + '\',\'' + _CATALOG_SERVICE_PAGE_UNIQUE_NAME + '\',\'' + _CATALOG_SERVICE_PAGE_TITLE + '\');">(Обратно към каталога на услуги)</a>';
			}	
			html += '</div>';		
		} else {
			html += '<div><a href="javascript:void(0);" onclick="mySpaceLoadServicesClassification(\'' + resourceURL + '\', _CATALOG_SERVICE_PAGE_UNIQUE_NAME, _CATALOG_SERVICE_PAGE_TITLE);">' + _CATALOG_SERVICE_PAGE_TITLE + '</a></div>';
			html += '<div>&nbsp;/&nbsp;</div>';
			html += '<div>' + _CATALOG_SERVICE_SUB_PAGE_TITLE  + '</div>';
		}
	}	
	breadcrumb.innerHTML = html;	
};

function mySpaceUpdateCatalogServicesSearchPlaceholder () {
	var search = document.getElementById(PORTLET_NAMESPACE + 'catalogServicesSearchField');
	if (search == null) return;
	var html = '';
	if (_CATALOG_SERVICE_PAGE_UNIQUE_NAME == null || _CATALOG_SERVICE_PAGE_UNIQUE_NAME.trim().length == 0) {
		html = 'Търсене на услуги ...';		
	} else {
		html = 'Търсене на услуги в ';
		if (_CATALOG_SERVICE_SUB_PAGE_UNIQUE_NAME == null || _CATALOG_SERVICE_SUB_PAGE_UNIQUE_NAME.trim().length == 0) {
			html += _CATALOG_SERVICE_PAGE_TITLE;
		} else {
			html += _CATALOG_SERVICE_SUB_PAGE_TITLE;
		}		
	}
	_SEARCH_PLACEHOLDER_TEXT = html;
	search.placeholder = _SEARCH_PLACEHOLDER_TEXT;	
		
};

function mySpaceCatalogServicesAddServiceToMyFavorites(obj, uuid, resourceURL) {
	if (uuid == null || uuid.length == 0) {    	
        return;
    }    
	removeMessageBox();
	obj.className = 'spinner-my-space-service-catalog';
	obj.innerHTML = MY_SPACE_ADDING_TEXT;
    var searchURL = document.location.href.substr(0, document.location.href.indexOf('/wps/'));
    searchURL += '/wps/PA_MySpace/my-favorite-services?op=add&uuid=' + uuid;
	searchURL += '&rand=' + Math.random();
	var wsgXMLHttpRequestObject = new PortalXMLHttpRequestObject();
  	var xmlHttpRequestObject = wsgXMLHttpRequestObject.getXMLHttpRequestObject();
  	if (xmlHttpRequestObject) {
		xmlHttpRequestObject.overrideMimeType("application/json");
    	xmlHttpRequestObject.open('GET', searchURL);
      	xmlHttpRequestObject.onreadystatechange = function() {
        	if (xmlHttpRequestObject.readyState == 4 && xmlHttpRequestObject.status == 200) {
				jsonData = JSON.parse(xmlHttpRequestObject.responseText);
            	if (jsonData == null) {
        			console.debug("XML has issues?");
        			return;
	        	}
	        	if (jsonData.data != undefined && jsonData.data.result == 1) {
	        		showMessageBoxSuccess('Услугата беше добавена.'); 
					var searchText = document.getElementById(PORTLET_NAMESPACE + 'catalogServicesSearchField').value.trim();
	        		if (searchText.length > 0 || (_CATALOG_SERVICE_SUB_PAGE_UNIQUE_NAME != null && _CATALOG_SERVICE_SUB_PAGE_UNIQUE_NAME.trim().length > 0)) {
						mySpaceSearchServicesInServicesClassification(resourceURL, null, null, true);
					} else {
						mySpaceLoadServicesClassification(resourceURL, (_CATALOG_SERVICE_PAGE_UNIQUE_NAME != null && _CATALOG_SERVICE_PAGE_UNIQUE_NAME.trim().length > 0 ? _CATALOG_SERVICE_PAGE_UNIQUE_NAME : null), (_CATALOG_SERVICE_PAGE_TITLE != null && _CATALOG_SERVICE_PAGE_TITLE.trim().length > 0 ? _CATALOG_SERVICE_PAGE_TITLE : null), true);
					}
	        	} else {
	        		if (jsonData.data != undefined && jsonData.data.message != undefined) {
	        			showMessageBoxError(jsonData.data.message);
	        		}
	        	}          
            } else if (xmlHttpRequestObject.readyState != 0) {
		    } else {
		       	console.debug("failed xhrGet for URL: ", error, ioArgs);
            	alert(error);
		    }
 		};
    	xmlHttpRequestObject.send(null);  
	}
};

function addServiceToMyFavorites(obj, uuid) {
	if (uuid == null || uuid.length == 0) {    	
        return;
    }    
	removeMessageBox();
	obj.className = 'spinner-xs pl-25';
	obj.innerHTML = MY_SPACE_ADDING_TEXT;
    var searchURL = document.location.href.substr(0, document.location.href.indexOf('/wps/'));
    searchURL += '/wps/PA_MySpace/my-favorite-services?op=add&uuid=' + uuid;
	searchURL += '&rand=' + Math.random();
	var wsgXMLHttpRequestObject = new PortalXMLHttpRequestObject();
  	var xmlHttpRequestObject = wsgXMLHttpRequestObject.getXMLHttpRequestObject();
  	if (xmlHttpRequestObject) {
		xmlHttpRequestObject.overrideMimeType("application/json");
    	xmlHttpRequestObject.open('GET', searchURL);
      	xmlHttpRequestObject.onreadystatechange = function() {
        	if (xmlHttpRequestObject.readyState == 4 && xmlHttpRequestObject.status == 200) {
				jsonData = JSON.parse(xmlHttpRequestObject.responseText);
            	if (jsonData == null) {
        			console.debug("XML has issues?");
        			return;
	        	}
	        	if (jsonData.data != undefined && jsonData.data.result == 1) {
	        		showMessageBoxSuccess('Услугата беше добавена.'); 
	        		MY_SPACE_REVERSE_ID_ARR[MY_SPACE_REVERSE_ID_ARR.length] = uuid;
	        		mySpaceSearchServicesCall(MY_SPACE_CURRENT_PAGE - 1);
	        	} else {
	        		if (jsonData.data != undefined && jsonData.data.message != undefined) {
	        			showMessageBoxError(jsonData.data.message);
	        		}
	        	}    
            } else if (xmlHttpRequestObject.readyState != 0) {
		    } else {
		       	console.debug("failed xhrGet for URL: ", error, ioArgs);
            	alert(error);
		    }
 		};
    	xmlHttpRequestObject.send(null);  
	}
};

function removeServiceFromFavorites(obj, uuid) {
	if (uuid == null || uuid.length == 0) {    	
        return;
    }    
	removeMessageBox();
	obj.className = 'spinner-xs pl-25';
	obj.innerHTML = MY_SPACE_REMOVING_TEXT;
    var searchURL = document.location.href.substr(0, document.location.href.indexOf('/wps/'));
    searchURL += '/wps/PA_MySpace/my-favorite-services?op=remove&uuid=' + uuid;
	searchURL += '&rand=' + Math.random();
	var wsgXMLHttpRequestObject = new PortalXMLHttpRequestObject();
  	var xmlHttpRequestObject = wsgXMLHttpRequestObject.getXMLHttpRequestObject();
  	if (xmlHttpRequestObject) {
		xmlHttpRequestObject.overrideMimeType("application/json"); 
    	xmlHttpRequestObject.open('GET', searchURL);
      	xmlHttpRequestObject.onreadystatechange = function() {
        	if (xmlHttpRequestObject.readyState == 4 && xmlHttpRequestObject.status == 200) {
				jsonData = JSON.parse(xmlHttpRequestObject.responseText);
				if (jsonData == null) {
	        		console.debug("XML has issues?");
	        		return;
	        	}
	        	if (jsonData.data != undefined && jsonData.data.result == 1) {
	        		showMessageBoxSuccess('Услугата беше премахната.');
	        		if (document.getElementById('myFavoriteServicesTotal') != null) {
	        			var total = parseInt(document.getElementById('myFavoriteServicesTotal').innerHTML, 10);
	        			document.getElementById('myFavoriteServicesTotal').innerHTML = total - 1;
	        		}
	        		var ind = MY_SPACE_UUID_STR_ARR.indexOf('"' + uuid + '",');
	        		if (ind != -1) {
	        			MY_SPACE_UUID_STR_ARR = MY_SPACE_UUID_STR_ARR.replace('"' + uuid + '",', '');
	        		} else {
	        			ind = MY_SPACE_UUID_STR_ARR.indexOf(',"' + uuid + '"');
	        			if (ind != -1) {
	        				MY_SPACE_UUID_STR_ARR = MY_SPACE_UUID_STR_ARR.replace(',"' + uuid + '"', '');
	        			} else {
	        				ind = MY_SPACE_UUID_STR_ARR.indexOf('"' + uuid + '"');
	        				if (ind != -1) {
	        					MY_SPACE_UUID_STR_ARR = MY_SPACE_UUID_STR_ARR.replace('"' + uuid + '"', '');
	        					if (MY_SPACE_UUID_STR_ARR.trim().length == 0) {
	        						if (document.getElementById(MY_SPACE_SEARCH_SERVICES_RESULT_CONTAINER) != null) {
	        							document.getElementById(MY_SPACE_SEARCH_SERVICES_RESULT_CONTAINER).innerHTML = '<p class="pt-20">' + MY_SPACE_NO_SERVICES_ADDED_TEXT + '</p>';
	        						}
	        						return;
	        					}
	        				}
	        			}
	        		}
	        		mySpaceDashBoardServicesCall(MY_SPACE_UUID_STR_ARR);        		
	        	} else {
	        		if (jsonData.data != undefined && jsonData.data.message != undefined) {
	        			showMessageBoxError(jsonData.data.message);
	        		}        		
	        	}  
			} else if (xmlHttpRequestObject.readyState != 0) {
		    } else {
		       	console.debug("failed xhrGet for URL: ", error, ioArgs);
            	alert(error);
		    }
 		};
    	xmlHttpRequestObject.send(null);  
	}
};

function loadLE(resourceURL) {
	if (document.getElementById(PORTLET_NAMESPACE + 'eik') != null && document.getElementById(PORTLET_NAMESPACE + 'eik').value.trim().length > 0) {
		document.getElementById(PORTLET_NAMESPACE + 'LELoaderDiv').style.display = 'block';
		document.getElementById(PORTLET_NAMESPACE + 'eik').className = 'form-input-my-space-50';
		document.getElementById(PORTLET_NAMESPACE + 'eikDIV').style.display = 'none';				
		document.getElementById(PORTLET_NAMESPACE + 'btnNext').style.display = 'none';	
		document.getElementById(PORTLET_NAMESPACE + 'my-space-le-request-message-block').innerHTML = '';
		document.getElementById(PORTLET_NAMESPACE + 'my-space-le-request-message-block').className = '';
		MY_SPACE_MESSAGE_BLOCK_DIV = PORTLET_NAMESPACE + 'my-space-le-request-message-block';
		var url = resourceURL;
   		url = url.substring(0, url.length - 1);
   		// add action parameter -> Evalue!all=action!add==/
   		url += 'Eaction!getLegalEntityData=value!' + document.getElementById(PORTLET_NAMESPACE + 'eik').value.trim() + '==/';
		var wsgXMLHttpRequestObject = new PortalXMLHttpRequestObject();
	  	var xmlHttpRequestObject = wsgXMLHttpRequestObject.getXMLHttpRequestObject();
	  	if (xmlHttpRequestObject) {
			xmlHttpRequestObject.overrideMimeType("application/json");
	    	xmlHttpRequestObject.open('GET', url);
	      	xmlHttpRequestObject.onreadystatechange = function() {
	        	if (xmlHttpRequestObject.readyState == 4 && xmlHttpRequestObject.status == 200) {
					jsonData = JSON.parse(xmlHttpRequestObject.responseText);
	            	if (jsonData == null) {
	        			console.debug("XML has issues?");
	        			return;
		        	}
		        	document.getElementById(PORTLET_NAMESPACE + 'LELoaderDiv').style.display = 'none';	
		        	if (jsonData.data != undefined && jsonData.data.result == 1) {
		        		if (jsonData.data.type == 2) {	        			
		        			showAddLEForm(jsonData.data);
		        		} else if (jsonData.data.type == 3) {
							showAddSSForm(jsonData.data);	        			
						} else if (jsonData.data.type == 4) {
							//showAddLE2Form(jsonData.data);
		        		} 
		        	} else {
		        		document.getElementById(PORTLET_NAMESPACE + 'eikDIV').style.display = '';				
		        		document.getElementById(PORTLET_NAMESPACE + 'btnNext').style.display = '';	        		
		        		if (jsonData.data != undefined && jsonData.data.message != undefined) {
		        			showGenericMessageBoxError(jsonData.data.message);
		        			document.getElementById(PORTLET_NAMESPACE + 'eik').className = 'form-input-my-space-50-error';	        			
		        		}
		        	}      
	            } else if (xmlHttpRequestObject.readyState != 0) {
			    } else {
			       	console.debug("failed xhrGet for URL: ", error, ioArgs);
	            	alert(error);
			    }
	 		};
	    	xmlHttpRequestObject.send(null);  
		}
	}
};

function resetSSForm() {
	document.getElementById(PORTLET_NAMESPACE + 'title').style.display = 'none';
	document.getElementById(PORTLET_NAMESPACE + 'SSFormDiv').style.display = 'none';
	document.getElementById(PORTLET_NAMESPACE + 'btnCancel').style.display = 'inline-block';		
	document.getElementById(PORTLET_NAMESPACE + 'btnNext').style.display = 'inline-block';		
	document.getElementById(PORTLET_NAMESPACE + 'eikDIV').style.display = 'block';		
};
function showAddSSForm(data) {
	document.getElementById(PORTLET_NAMESPACE + 'title').style.display = 'block';		
	document.getElementById(PORTLET_NAMESPACE + 'formSSEik').innerHTML = data.eik;
	document.getElementById(PORTLET_NAMESPACE + 'formSSName').innerHTML = data.nameAndLegalForm;	
	document.getElementById(PORTLET_NAMESPACE + 'btnCancel').style.display = 'none';
	document.getElementById(PORTLET_NAMESPACE + 'SSFormDiv').style.display = 'block';
	document.getElementById(PORTLET_NAMESPACE + 'formSSEIK').value = data.eik;
	document.getElementById(PORTLET_NAMESPACE + 'formSSNameAndLegalForm').value = data.nameAndLegalForm;
};
function validateAddSSForm() {
	return true;		
};
function resetLEForm() {
	document.getElementById(PORTLET_NAMESPACE + 'title').style.display = 'none';
	document.getElementById(PORTLET_NAMESPACE + 'LEFormDiv').style.display = 'none';
	document.getElementById(PORTLET_NAMESPACE + 'btnCancel').style.display = 'inline-block';		
	document.getElementById(PORTLET_NAMESPACE + 'btnNext').style.display = 'inline-block';		
	document.getElementById(PORTLET_NAMESPACE + 'eikDIV').style.display = 'block';
	if (document.getElementById(PORTLET_NAMESPACE + 'profileStructureType') != null) {
		document.getElementById(PORTLET_NAMESPACE + 'profileStructureType').value = '';
		document.getElementById(PORTLET_NAMESPACE + 'profileStructureTypeOther').value = '';
		document.getElementById(PORTLET_NAMESPACE + 'profileStructureTypeOtherDIV').style.display = 'none';
	}	
};
function showAddLEForm(data) {
	document.getElementById(PORTLET_NAMESPACE + 'title').style.display = 'block';		
	document.getElementById(PORTLET_NAMESPACE + 'formLEEIKLabel').innerHTML = data.eik;
	document.getElementById(PORTLET_NAMESPACE + 'formLENameLabel').innerHTML = data.nameAndLegalForm;	
	document.getElementById(PORTLET_NAMESPACE + 'btnCancel').style.display = 'none';
	document.getElementById(PORTLET_NAMESPACE + 'LEFormDiv').style.display = 'block';
	document.getElementById(PORTLET_NAMESPACE + 'formLEEIK').value = data.eik;
	document.getElementById(PORTLET_NAMESPACE + 'formLENameAndLegalForm').value = data.nameAndLegalForm;
};
function validateAddLEForm() {
	return true;		
};
function validateSyncEDeliveryProfilesForm() {
	return true;	
};
function loadUser(resourceURL) {
	if (document.getElementById(PORTLET_NAMESPACE + 'personalIdentifier') != null && document.getElementById(PORTLET_NAMESPACE + 'personalIdentifier').value.trim().length > 0) {
		document.getElementById(PORTLET_NAMESPACE + 'AddUserLoaderDiv').style.display = 'block';				
		document.getElementById(PORTLET_NAMESPACE + 'personalIdentifierDIV').style.display = 'none';				
		document.getElementById(PORTLET_NAMESPACE + 'btnNext').style.display = 'none';	
		MY_SPACE_MESSAGE_BLOCK_DIV = PORTLET_NAMESPACE + 'my-space-add-user-message-block';
		var url = resourceURL;
   		url = url.substring(0, url.length - 1);
   		// add action parameter -> Evalue!all=action!add==/
   		url += 'Eaction!getUserData=value!' + document.getElementById(PORTLET_NAMESPACE + 'personalIdentifier').value.trim() + '==/';
		var wsgXMLHttpRequestObject = new PortalXMLHttpRequestObject();
	  	var xmlHttpRequestObject = wsgXMLHttpRequestObject.getXMLHttpRequestObject();
	  	if (xmlHttpRequestObject) {
			xmlHttpRequestObject.overrideMimeType("application/json");
	    	xmlHttpRequestObject.open('GET', url);
	      	xmlHttpRequestObject.onreadystatechange = function() {
	        	if (xmlHttpRequestObject.readyState == 4 && xmlHttpRequestObject.status == 200) {
					jsonData = JSON.parse(xmlHttpRequestObject.responseText);
	            	if (jsonData == null) {
	        			console.debug("XML has issues?");
	        			return;
		        	}
		        	document.getElementById(PORTLET_NAMESPACE + 'AddUserLoaderDiv').style.display = 'none';	
	        		if (jsonData.data != undefined && jsonData.data.result == 1) {
		        		// render response.
		        		showAddUserForm(jsonData.data);
		        	} else {
		        		if (jsonData.data != undefined && jsonData.data.message != undefined) {
		        			showGenericMessageBoxError(jsonData.data.message);
		        			document.getElementById(PORTLET_NAMESPACE + 'personalIdentifierDIV').style.display = '';				
		        			document.getElementById(PORTLET_NAMESPACE + 'btnNext').style.display = '';	
		        		}
		        	}      
	            } else if (xmlHttpRequestObject.readyState != 0) {
			    } else {
			       	console.debug("failed xhrGet for URL: ", error, ioArgs);
	            	alert(error);
			    }
	 		};
	    	xmlHttpRequestObject.send(null);  
		}
	}
}; 
function resetAddUserForm() {	
	document.getElementById(PORTLET_NAMESPACE + 'addUserFormDiv').style.display = 'none';
	document.getElementById(PORTLET_NAMESPACE + 'btnCancel').style.display = 'inline-block';		
	document.getElementById(PORTLET_NAMESPACE + 'btnNext').style.display = 'inline-block';		
	document.getElementById(PORTLET_NAMESPACE + 'personalIdentifierDIV').style.display = 'block';	
	document.getElementById(PORTLET_NAMESPACE + 'formEmailDiv').style.display = 'none';
};
function showAddUserForm(data) {	
	document.getElementById(PORTLET_NAMESPACE + 'formUserNames').innerHTML = data.userNames;
	document.getElementById(PORTLET_NAMESPACE + 'formPersonalIdentifier').innerHTML = data.personalIdentifier;	
	if (data.email != null && data.email.trim().length > 0) {
		document.getElementById(PORTLET_NAMESPACE + 'formEmail').innerHTML = data.email;
		document.getElementById(PORTLET_NAMESPACE + 'formEmailDiv').style.display = '';
	}
	document.getElementById(PORTLET_NAMESPACE + 'btnCancel').style.display = 'none';
	document.getElementById(PORTLET_NAMESPACE + 'addUserFormDiv').style.display = 'block';
	document.getElementById(PORTLET_NAMESPACE + 'formUniqueIdentifier').value = data.personalIdentifier;	
};
function validateAddUserForm() {
	if (!document.getElementById(PORTLET_NAMESPACE + 'editor').checked && !document.getElementById(PORTLET_NAMESPACE + 'services').checked && !document.getElementById(PORTLET_NAMESPACE + 'admin').checked) {
		alert('Моля изберете роля на потребителя!');
		return false;
	}
	return true;		
};
function validateEditUserForm() {
	if (!document.getElementById(PORTLET_NAMESPACE + 'editor').checked && !document.getElementById(PORTLET_NAMESPACE + 'services').checked && !document.getElementById(PORTLET_NAMESPACE + 'admin').checked) {
		alert('Моля изберете роля на потребителя!');
		return false;
	}
	return true;		
};
function validateDeactivateProfileForm() {
	if (document.getElementById(PORTLET_NAMESPACE +'deactivationReason').value.trim().length <= 2) {
		alert('Моля въведете "причина".');
		return false;
	}
	return true;
}
function mySpaceTranslate() {
	if (MY_SPACE_AJAX_RUNNIG) return false;
	var sourceLanguage = document.getElementById(PORTLET_NAMESPACE + 'sourceLanguage').value;
	var targetLanguage = document.getElementById(PORTLET_NAMESPACE + 'targetLanguage').value;
	var textToTranslate = document.getElementById(PORTLET_NAMESPACE + 'originalText').value;
	if (sourceLanguage == targetLanguage) {
		alert('Моля изберете "Целеви език" различен от "Език на оригиналния текст"!');
		return false;
	}
	if (textToTranslate.trim().length > 2048) {
		alert('Моля въведете текст до 2048 символа.');
		return false;
	}
	document.getElementById(PORTLET_NAMESPACE + 'spinnerButton').style.display = 'inline-block';
	//var url = '/wps/PA_MySpace/etranslation?op=1&sl=' + sourceLanguage + '&tl=' + targetLanguage + '&ttt=' + textToTranslate;
	var url = '/wps/PA_MySpace/etranslation';
	MY_SPACE_AJAX_RUNNIG = true;
	var wsgXMLHttpRequestObject = new PortalXMLHttpRequestObject();
	var xmlHttpRequestObject = wsgXMLHttpRequestObject.getXMLHttpRequestObject();
	if (xmlHttpRequestObject) {		
		var params = 'op=1&textToTranslate=' + textToTranslate + '&sourceLanguage=' + sourceLanguage + '&targetLanguage=' + targetLanguage;
		xmlHttpRequestObject.open('POST', url, true);
		
		//Send the proper header information along with the request
		xmlHttpRequestObject.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
		
		xmlHttpRequestObject.onreadystatechange = function() {//Call a function when the state changes.
		    if(xmlHttpRequestObject.readyState == 4 && xmlHttpRequestObject.status == 200) {
				var response = xmlHttpRequestObject.responseText;
				try {
					if (!isNaN(response) && parseInt(response, 10) > 0) {
						MY_SPACE_TRANSLATE_REFRESH_TRY = 15;
    	    			mySpaceTranslateRefresh(response);
					}	
				} catch(e) {}		      
		    } else if (xmlHttpRequestObject.readyState != 0) {
		    } else {
		       	console.debug("failed xhrGet for URL: ", error, ioArgs);
            	MY_SPACE_AJAX_RUNNIG = false;
		    }
		}
		xmlHttpRequestObject.send(params);
	}
};
function mySpaceTranslateRefresh(idRequest) {
	var url = '/wps/PA_MySpace/etranslation';
	var last = MY_SPACE_TRANSLATE_REFRESH_TRY == 1 ? 1 : 0;
	var wsgXMLHttpRequestObject = new PortalXMLHttpRequestObject();
	var xmlHttpRequestObject = wsgXMLHttpRequestObject.getXMLHttpRequestObject();
	if (xmlHttpRequestObject) {		
		var params = 'op=2&idRequest=' + idRequest + '&last=' + last;
		xmlHttpRequestObject.open('POST', url, true);
		
		//Send the proper header information along with the request
		xmlHttpRequestObject.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
		
		xmlHttpRequestObject.onreadystatechange = function() {//Call a function when the state changes.
		    if(xmlHttpRequestObject.readyState == 4 && xmlHttpRequestObject.status == 200) {
				var data = xmlHttpRequestObject.responseText;
				 MY_SPACE_TRANSLATE_REFRESH_TRY--;
	             if(data != null && data.trim().length > 0) {      
	        	 	document.getElementById(PORTLET_NAMESPACE + 'translatedText').value=data;     
	        	   	document.getElementById(PORTLET_NAMESPACE + 'spinnerButton').style.display = 'none';
	        	   	MY_SPACE_AJAX_RUNNIG = false;
	             } else if (MY_SPACE_TRANSLATE_REFRESH_TRY == 0) {
	        	   	document.getElementById(PORTLET_NAMESPACE + 'translatedText').value='Няма получен отговор от eTranslation услугата.';
	        	   	document.getElementById(PORTLET_NAMESPACE + 'spinnerButton').style.display = 'none';
	        	   	MY_SPACE_AJAX_RUNNIG = false;
	           	} else {
	               setTimeout('mySpaceTranslateRefresh(' + idRequest + ')', 1000);
	           	}   		      
		    } else if (xmlHttpRequestObject.readyState != 0) {
		    } else {
		       	console.debug("failed xhrGet for URL: ", error, ioArgs);
            	MY_SPACE_AJAX_RUNNIG = false;
		    }
		}
		xmlHttpRequestObject.send(params);
	}
};
	
function syncEDeliveryProfile(resourceURL, identifier) {
	if (document.getElementById(PORTLET_NAMESPACE + identifier + 'DIV')) {
		var _iHTML = document.getElementById(PORTLET_NAMESPACE + identifier + 'DIV').innerHTML; 
		document.getElementById(PORTLET_NAMESPACE + identifier + 'DIV').innerHTML = '<div class="spinner-button-my-space"></div>';
		MY_SPACE_MESSAGE_BLOCK_DIV = PORTLET_NAMESPACE + 'my-space-sync-edelivery-profile-message-block';
		var url = resourceURL;
   		url = url.substring(0, url.length - 1);
   		// add action parameter -> Evalue!all=action!add==/
   		url += 'Eaction!syncEDeliveryProfile=value!' + identifier + '==/'; 
		var wsgXMLHttpRequestObject = new PortalXMLHttpRequestObject();
	  	var xmlHttpRequestObject = wsgXMLHttpRequestObject.getXMLHttpRequestObject();
	  	if (xmlHttpRequestObject) {
			xmlHttpRequestObject.overrideMimeType("application/json");
	    	xmlHttpRequestObject.open('GET', url);
	      	xmlHttpRequestObject.onreadystatechange = function() {
	        	if (xmlHttpRequestObject.readyState == 4 && xmlHttpRequestObject.status == 200) {
					jsonData = JSON.parse(xmlHttpRequestObject.responseText);
	            	if (jsonData == null) {
	        			console.debug("XML has issues?");
	        			return;
		        	}
		        	if (jsonData.data != undefined && jsonData.data.result == 1) {	        		
	        		document.getElementById(PORTLET_NAMESPACE + identifier + 'DIV').innerHTML = '<p style="font-style: italic;">' + jsonData.data.type + '</p>';
	        		if (jsonData.data.type == 'Присъединен') {
	        			showGenericMessageBoxSuccess('Профилът беше присъединен успешно.');
	        		} else {
	        			showGenericMessageBoxSuccess('Заявка за одобрение на профил беше изпратена успешно.');
	        		}
	        		var list = document.getElementsByClassName('form-div-list-my-space-sync-edelivery-profile-button');
	        		if (list != null && list.length > 0) {
	        			var i;
	        			var j;
	        			var found = false;
	        			for (i = 0; i < list.length; i++) {
	        				var c = list[i].childNodes;	        					        				
	        				for (j = 0; j < c.length; j++) {
	        					if ("INPUT" == c[j].nodeName.toUpperCase()) {
	        						found = true;
	        						break;	
	        					}
	        				}
	        				if (found) {
	        					break;
	        				}
						}
	        			if (!found) {
	        				document.getElementById(PORTLET_NAMESPACE + 'syncAllButton').style.display = 'none';
	        			}
	        		}
	        	} else {
	        		document.getElementById(PORTLET_NAMESPACE + identifier + 'DIV').innerHTML = _iHTML;				
	        		if (jsonData.data != undefined && jsonData.data.message != undefined) {
	        			showGenericMessageBoxError(jsonData.data.message);	        				        			
	        		}
	        	}   
	            } else if (xmlHttpRequestObject.readyState != 0) {
			    } else {
			       	console.debug("failed xhrGet for URL: ", error, ioArgs);
	            	alert(error);
			    }
	 		};
	    	xmlHttpRequestObject.send(null);  
		}
	}
};

function mySpaceProfilePersonalizationAddPages(all) {		
	var select = document.getElementById(PORTLET_NAMESPACE + 'selectedPages');
	var pagesList = document.getElementById(PORTLET_NAMESPACE + 'allPages');
	if (select != null && pagesList != null) {			
		for (var i = 0; i < pagesList.options.length; i++) {					
			if (all || (pagesList.options[i].selected && pagesList.options[i].value != '')) {				
				var option = document.createElement("option");
				option.text = pagesList.options[i].text;
				option.value = pagesList.options[i].value;
				select.options.add(option);				
			}
		}
		for (i = pagesList.options.length-1; i >= 0; i--) {	
			if (pagesList.options[i].selected || all) {				        
				pagesList.remove(i);					
			}
		}
	}
	mySpaceProfilePersonalizationToggleButtons();
};
function mySpaceProfilePersonalizationRemovePages(all) {
	var select = document.getElementById(PORTLET_NAMESPACE + 'selectedPages');
	var pagesList = document.getElementById(PORTLET_NAMESPACE + 'allPages');
	if (select != null && select.options != null && select.options.length > 0) {
		for (i = select.options.length-1; i >= 0; i--) {	
			if (select.options[i].selected || all) {	
				var option = document.createElement("option");
				option.text = select.options[i].text;
				option.value = select.options[i].value;
				pagesList.options.add(option);	
				
				select.remove(i);					
			}
		}
	}
	mySpaceProfilePersonalizationToggleButtons();
};
function mySpaceProfilePersonalizationMoveUpPages() {
	var select = document.getElementById(PORTLET_NAMESPACE + 'selectedPages');
	if (select != null && select.options != null && select.options.length > 0) {
		if (select.options[0].selected) {
			return;
		}
		for (var i = 0; i < select.options.length; i++) {		
			if (select.options[i].selected) {	
				if (i == 0) continue;
				var text = select.options[i].text;
				var value = select.options[i].value;
				select.options[i].text = select.options[i-1].text;
				select.options[i].value = select.options[i-1].value;
				select.options[i-1].text = text;
				select.options[i-1].value = value;
				select.options[i-1].selected = true;
				select.options[i].selected = false;					
			}
		}
	}	
};
function mySpaceProfilePersonalizationMoveDownPages() {
	var select = document.getElementById(PORTLET_NAMESPACE + 'selectedPages');
	if (select != null && select.options != null && select.options.length > 0) {
		if (select.options[select.options.length-1].selected) {
			return;
		}		
		for (i = select.options.length-1; i >= 0; i--) {	
			if (select.options[i].selected) {	
				if (i+1 == select.options.length) continue;
				var text = select.options[i].text;
				var value = select.options[i].value;
				select.options[i].text = select.options[i+1].text;
				select.options[i].value = select.options[i+1].value;
				select.options[i+1].text = text;
				select.options[i+1].value = value;
				select.options[i+1].selected = true;
				select.options[i].selected = false;					
			}
		}
	}		
};
function mySpaceProfilePersonalizationToggleButtons() {
	console.log("mySpaceProfilePersonalizationToggleButtons");	
	var allPages = document.getElementById(PORTLET_NAMESPACE + 'allPages');
	var selectedPages = document.getElementById(PORTLET_NAMESPACE + 'selectedPages');
	if (allPages != null && allPages.options != null && allPages.options.length > 0) {
		var hasSelected = false;
		for (var i = 0; i < allPages.options.length; i++) {		
			if (allPages.options[i].selected) {
				hasSelected = true;
				break;
			}
		}
		if (hasSelected) {
			document.getElementById(PORTLET_NAMESPACE + 'addButton').style.opacity='1';
			document.getElementById(PORTLET_NAMESPACE + 'addButtonImg').style.cursor='pointer';
		} else {
			document.getElementById(PORTLET_NAMESPACE + 'addButton').style.opacity='0.5';
			document.getElementById(PORTLET_NAMESPACE + 'addButtonImg').style.cursor='default';
		}
		document.getElementById(PORTLET_NAMESPACE + 'addAllButton').style.opacity='1';
		document.getElementById(PORTLET_NAMESPACE + 'addAllButtonImg').style.cursor='pointer';
	} else {
		document.getElementById(PORTLET_NAMESPACE + 'addAllButton').style.opacity='0.5';
		document.getElementById(PORTLET_NAMESPACE + 'addAllButtonImg').style.cursor='default';
		document.getElementById(PORTLET_NAMESPACE + 'addButton').style.opacity='0.5';
		document.getElementById(PORTLET_NAMESPACE + 'addButtonImg').style.cursor='default';		
	}
	if (selectedPages != null && selectedPages.options != null && selectedPages.options.length > 0) {
		var hasSelected = false;
		var showUp = true;
		var showDown = true;
		for (var i = 0; i < selectedPages.options.length; i++) {		
			if (selectedPages.options[i].selected) {
				hasSelected = true;
				if (i == 0) {
					showUp = false;
				} else if (i + 1 == selectedPages.options.length) {
					showDown = false;
				}
			}
		}
		if (hasSelected) {
			document.getElementById(PORTLET_NAMESPACE + 'removeButton').style.opacity='1';
			document.getElementById(PORTLET_NAMESPACE + 'removeButtonImg').style.cursor='pointer';
			if (showUp) {
				document.getElementById(PORTLET_NAMESPACE + 'moveUpButton').style.opacity='1';
				document.getElementById(PORTLET_NAMESPACE + 'moveUpButtonImg').style.cursor='pointer';
			} else {
				document.getElementById(PORTLET_NAMESPACE + 'moveUpButton').style.opacity='0.5';
				document.getElementById(PORTLET_NAMESPACE + 'moveUpButtonImg').style.cursor='default';
			}
			if (showDown) {
				document.getElementById(PORTLET_NAMESPACE + 'moveDownButton').style.opacity='1';
				document.getElementById(PORTLET_NAMESPACE + 'moveDownButtonImg').style.cursor='pointer';
			} else {
				document.getElementById(PORTLET_NAMESPACE + 'moveDownButton').style.opacity='0.5';
				document.getElementById(PORTLET_NAMESPACE + 'moveDownButtonImg').style.cursor='default';
			}
		} else {
			document.getElementById(PORTLET_NAMESPACE + 'removeButton').style.opacity='0.5';
			document.getElementById(PORTLET_NAMESPACE + 'removeButtonImg').style.cursor='default';
			document.getElementById(PORTLET_NAMESPACE + 'moveUpButton').style.opacity='0.5';
			document.getElementById(PORTLET_NAMESPACE + 'moveUpButtonImg').style.cursor='default';
			document.getElementById(PORTLET_NAMESPACE + 'moveDownButton').style.opacity='0.5';
			document.getElementById(PORTLET_NAMESPACE + 'moveDownButtonImg').style.cursor='default';
		}
		document.getElementById(PORTLET_NAMESPACE + 'removeAllButton').style.opacity='1';
		document.getElementById(PORTLET_NAMESPACE + 'removeAllButtonImg').style.cursor='pointer';
	} else {
		document.getElementById(PORTLET_NAMESPACE + 'removeButton').style.opacity='0.5';
		document.getElementById(PORTLET_NAMESPACE + 'removeButtonImg').style.cursor='default';
		document.getElementById(PORTLET_NAMESPACE + 'removeAllButton').style.opacity='0.5';
		document.getElementById(PORTLET_NAMESPACE + 'removeAllButtonImg').style.cursor='default';
		document.getElementById(PORTLET_NAMESPACE + 'moveUpButton').style.opacity='0.5';
		document.getElementById(PORTLET_NAMESPACE + 'moveUpButtonImg').style.cursor='default';
		document.getElementById(PORTLET_NAMESPACE + 'moveDownButton').style.opacity='0.5';
		document.getElementById(PORTLET_NAMESPACE + 'moveDownButtonImg').style.cursor='default';
	}
};
function mySpaceValidateNewAuthorizationSearch() {
	if (document.getElementById(PORTLET_NAMESPACE + 'authorizedNames') != null && document.getElementById(PORTLET_NAMESPACE + 'authorizedNames').value.trim().length > 0
		&& document.getElementById(PORTLET_NAMESPACE + 'authorizedIdentifier') != null && document.getElementById(PORTLET_NAMESPACE + 'authorizedIdentifier').value.trim().length > 0) {
		return true;	
	}
	var message = "";
	if (document.getElementById(PORTLET_NAMESPACE + 'authorizedNames') == null || document.getElementById(PORTLET_NAMESPACE + 'authorizedNames').value.trim().length == 0) {
		message = 'Моля въведете "' + (document.getElementById(PORTLET_NAMESPACE + 'authorizedType1').checked ? 'Имена': 'Наименование') + '".';
		document.getElementById(PORTLET_NAMESPACE + 'authorizedNames').className = 'form-input-my-space-50-error';
		document.getElementById(PORTLET_NAMESPACE + 'authorizedNames').focus();
	}
	if (document.getElementById(PORTLET_NAMESPACE + 'authorizedIdentifier') == null || document.getElementById(PORTLET_NAMESPACE + 'authorizedIdentifier').value.trim().length == 0) {
		if (message.length > 0) {
			message += "<br/>";
		} else {
			document.getElementById(PORTLET_NAMESPACE + 'authorizedIdentifier').focus();
		}
		message += 'Моля въведете "' + (document.getElementById(PORTLET_NAMESPACE + 'authorizedType1').checked ? 'ЕГН/ЛНЧ': 'ЕИК') + '".';
		document.getElementById(PORTLET_NAMESPACE + 'authorizedIdentifier').className = 'form-input-my-space-50-error';
	} 
	showGenericMessageBoxError(message);
	return false;
};
function mySpaceLoadAuthorizedUserData(resourceURL, callBackFnc) {
	if (document.getElementById(PORTLET_NAMESPACE + 'authorizedNames') != null && document.getElementById(PORTLET_NAMESPACE + 'authorizedNames').value.trim().length > 0
		&& document.getElementById(PORTLET_NAMESPACE + 'authorizedIdentifier') != null && document.getElementById(PORTLET_NAMESPACE + 'authorizedIdentifier').value.trim().length > 0) {
		
		document.getElementById(PORTLET_NAMESPACE + 'searchAuthorizedUserLoaderDiv').style.display = 'block';
		document.getElementById(PORTLET_NAMESPACE + 'authorizedNames').className = 'form-input-my-space-50';
		document.getElementById(PORTLET_NAMESPACE + 'authorizedIdentifier').className = 'form-input-my-space-50';
		document.getElementById(PORTLET_NAMESPACE + 'searchFieldsDIV').style.display = 'none';				
		document.getElementById(PORTLET_NAMESPACE + 'btnNext').style.display = 'none';	
		document.getElementById(PORTLET_NAMESPACE + 'btnCancel').style.display = 'none';	
		document.getElementById(PORTLET_NAMESPACE + 'my-space-add-authorization-message-block').innerHTML = '';
		document.getElementById(PORTLET_NAMESPACE + 'my-space-add-authorization-message-block').className = '';
		var type = document.getElementById(PORTLET_NAMESPACE + 'authorizedType1').checked ? document.getElementById(PORTLET_NAMESPACE + 'authorizedType1').value : document.getElementById(PORTLET_NAMESPACE + 'authorizedType2').value;
		MY_SPACE_MESSAGE_BLOCK_DIV = PORTLET_NAMESPACE + 'my-space-add-authorization-message-block';
		var url = resourceURL;
   		url = url.substring(0, url.length - 1);
   		url += 'Eaction!getAuthorizedUserData=authorizedType!' + type + '=authorizedNames!' + encodeURIComponent(document.getElementById(PORTLET_NAMESPACE + 'authorizedNames').value.trim()) + '=authorizedIdentifier!' + encodeURIComponent(document.getElementById(PORTLET_NAMESPACE + 'authorizedIdentifier').value.trim()) + '==/';
		var wsgXMLHttpRequestObject = new PortalXMLHttpRequestObject();
	  	var xmlHttpRequestObject = wsgXMLHttpRequestObject.getXMLHttpRequestObject();
	  	if (xmlHttpRequestObject) {
			xmlHttpRequestObject.overrideMimeType("application/json");
	    	xmlHttpRequestObject.open('GET', url);
	      	xmlHttpRequestObject.onreadystatechange = function() {
	        	if (xmlHttpRequestObject.readyState == 4 && xmlHttpRequestObject.status == 200) {
					jsonData = JSON.parse(xmlHttpRequestObject.responseText);
	            	if (jsonData == null) {
	        			console.debug("XML has issues?");
	        			return;
		        	}
		        	document.getElementById(PORTLET_NAMESPACE + 'searchAuthorizedUserLoaderDiv').style.display = 'none';	
		        	if (jsonData.data != undefined && jsonData.data.result == 1) {
						MY_SPACE_AUTHORIZATION_SYSTEMS = jsonData.data.systems;					
		        		mySpaceShowAddAuthorizationForm(jsonData.data);	
						if (callBackFnc != null) {
							eval(callBackFnc);					
						}			
		        	} else {
		        		document.getElementById(PORTLET_NAMESPACE + 'searchFieldsDIV').style.display = '';				
		        		document.getElementById(PORTLET_NAMESPACE + 'btnNext').style.display = '';	
						document.getElementById(PORTLET_NAMESPACE + 'btnCancel').style.display = '';        		
		        		if (jsonData.data != undefined && jsonData.data.message != undefined) {
		        			showGenericMessageBoxError(jsonData.data.message);
		        			document.getElementById(PORTLET_NAMESPACE + 'authorizedNames').className = 'form-input-my-space-50-error';	        			
		        			document.getElementById(PORTLET_NAMESPACE + 'authorizedIdentifier').className = 'form-input-my-space-50-error';	        			
		        		}
		        	}   
	            } else if (xmlHttpRequestObject.readyState != 0) {
			    } else {
			       	console.debug("failed xhrGet for URL: ", error, ioArgs);
	            	alert(error);
			    }
	 		};
	    	xmlHttpRequestObject.send(null);  
		}
	}
};	
 
function mySpaceShowAddAuthorizationForm(data) {
	mySpaceAddAuthorizationFormClearSystems();
	document.getElementById(PORTLET_NAMESPACE + 'sectionRight').style.display = 'none';
	document.getElementById(PORTLET_NAMESPACE + 'sectionLeft').className = '';
	document.getElementById(PORTLET_NAMESPACE + 'addAuthorizationFormDiv').style.display = '';
	document.getElementById(PORTLET_NAMESPACE + 'formAuthorizedNames').innerHTML = data.name;	
	document.getElementById(PORTLET_NAMESPACE + 'formAuthorizedIdentifier').value = data.identifier;	
	document.getElementById(PORTLET_NAMESPACE + 'formAuthorizedIdentifierText').innerHTML = data.identifier;
	var select = document.getElementById(PORTLET_NAMESPACE + 'formAllSystems');
	if (select != null && MY_SPACE_AUTHORIZATION_SYSTEMS != null && MY_SPACE_AUTHORIZATION_SYSTEMS.length > 0) {
		var option = null;
		for(var i = 0; i < MY_SPACE_AUTHORIZATION_SYSTEMS.length; i++) {
			option = document.createElement("option");
			option.text = MY_SPACE_AUTHORIZATION_SYSTEMS[i].title;
			option.value = MY_SPACE_AUTHORIZATION_SYSTEMS[i].id;
			select.options.add(option);	
		}
	}
	eval(PORTLET_NAMESPACE + 'showFormActionsPerSystem();');
};
function mySpaceAddAuthorizationFormClearSystems() {
	var select = document.getElementById(PORTLET_NAMESPACE + 'formAllSystems');
	if (select != null) {
		for (i = select.options.length-1; i >= 0; i--) {
			select.remove(i);	
		}
		var option = document.createElement("option");
		option.text = "--- Изберете ---";
		option.value = "";
		select.options.add(option);
	}	
};
function removeMessageBox() {
	if (document.getElementById(MY_SPACE_MESSAGE_BLOCK_DIV) != null) {
		document.getElementById(MY_SPACE_MESSAGE_BLOCK_DIV).className = '';
		document.getElementById(MY_SPACE_MESSAGE_BLOCK_DIV).innerHTML = '';
	}
};
function showMessageBoxSuccess(message) {
	if (document.getElementById(MY_SPACE_MESSAGE_BLOCK_DIV) != null) {
		document.getElementById(MY_SPACE_MESSAGE_BLOCK_DIV).className = 'message-block-success';
		document.getElementById(MY_SPACE_MESSAGE_BLOCK_DIV).innerHTML = message;		
	}
};
function showMessageBoxError(message) {
	if (document.getElementById(MY_SPACE_MESSAGE_BLOCK_DIV) != null) {
		document.getElementById(MY_SPACE_MESSAGE_BLOCK_DIV).className = 'message-block-error';
		document.getElementById(MY_SPACE_MESSAGE_BLOCK_DIV).innerHTML = message;		
	}
};
function showMessageBoxErrorMultiple(message) {
	if (document.getElementById(MY_SPACE_MESSAGE_BLOCK_DIV) != null) {
		document.getElementById(MY_SPACE_MESSAGE_BLOCK_DIV).className = 'message-block-error-multiple';
		document.getElementById(MY_SPACE_MESSAGE_BLOCK_DIV).innerHTML = message;		
	}
};
function showGenericMessageBoxError(message) {
	if (document.getElementById(MY_SPACE_MESSAGE_BLOCK_DIV) != null) {
		document.getElementById(MY_SPACE_MESSAGE_BLOCK_DIV).className = 'generic-message-block-error-multiple';
		document.getElementById(MY_SPACE_MESSAGE_BLOCK_DIV).innerHTML = message;		
	}
};
function showGenericMessageBoxSuccess(message) {
	if (document.getElementById(MY_SPACE_MESSAGE_BLOCK_DIV) != null) {
		document.getElementById(MY_SPACE_MESSAGE_BLOCK_DIV).className = 'generic-message-block-success-multiple';
		document.getElementById(MY_SPACE_MESSAGE_BLOCK_DIV).innerHTML = message;		
	}
};