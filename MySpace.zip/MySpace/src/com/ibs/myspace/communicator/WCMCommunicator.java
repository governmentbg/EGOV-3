package com.ibs.myspace.communicator;

import java.util.List;


import com.egov.wcm.cache.EgovProfileStructureType;
import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.Category;

public class WCMCommunicator {
	
	public Category getProfileTypeCategoryByName(String profileType) {
		if (profileType != null) {
			List<Category> categories = EgovWCMCache.getCategoriesProfileTypes();
			if (categories != null && categories.size() > 0) {
				for (int i = 0; i < categories.size(); i++) {
					if (profileType.equalsIgnoreCase(categories.get(i).getName())) {
						return categories.get(i);
					}
				}				
			}
		}
		return null;
	}
	public String getProfileTypeName(String profileType) {
		if (profileType != null) {
			List<Category> categories = EgovWCMCache.getCategoriesProfileTypes();
			if (categories != null && categories.size() > 0) {
				for (int i = 0; i < categories.size(); i++) {
					if (profileType.equalsIgnoreCase(categories.get(i).getName())) {
						return categories.get(i).getTitle();
					}
				}				
			}
		}
		return "";
	}
	
	public String getProfileStructureTypeName(String profileStructureType) {
		if (profileStructureType != null) {
			List<EgovProfileStructureType> profileStructureTypes = EgovWCMCache.getProfileStructureTypes();
			if (profileStructureTypes != null && profileStructureTypes.size() > 0) {
				for (int i = 0; i < profileStructureTypes.size(); i++) {
					if (profileStructureType.equalsIgnoreCase(profileStructureTypes.get(i).getName())) {
						return profileStructureTypes.get(i).getTitle();
					}
				}				
			}
		}
		return "";
	}
}
