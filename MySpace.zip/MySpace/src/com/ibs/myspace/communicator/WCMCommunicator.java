package com.ibs.myspace.communicator;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.egov.wcm.cache.EgovProfileStructureType;
import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.Category;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentTypes;
import com.ibm.workplace.wcm.api.Taxonomy;
import com.ibm.workplace.wcm.api.Workspace;
import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.utils.Logger;
import com.ibs.myspace.portlet.utils.MySpaceWCMUtils;

public class WCMCommunicator {
	
	public Category getProfileTypeCategoryByName(String profileType) {
		if (profileType != null) {
			List<Category> categories = EgovWCMCache.getCategoriesProfileTypes();
			if (categories != null && categories.size() > 0) {
				for (int i = 0; i < categories.size(); i++) {
					if (profileType.equalsIgnoreCase(categories.get(i).getName())) {
						return categories.get(i);
					}
				}				
			}
		}
		return null;
	}
	
	public String getProfileTypeName(String profileType) {
		if (profileType != null) {
			List<Category> categories = EgovWCMCache.getCategoriesProfileTypes();
			if (categories != null && categories.size() > 0) {
				for (int i = 0; i < categories.size(); i++) {
					if (profileType.equalsIgnoreCase(categories.get(i).getName())) {
						return categories.get(i).getTitle();
					}
				}				
			}
		}
		return "";
	}
	
	public String getProfileStructureTypeName(String profileStructureType) {
		if (profileStructureType != null) {
			List<EgovProfileStructureType> profileStructureTypes = EgovWCMCache.getProfileStructureTypes();
			if (profileStructureTypes != null && profileStructureTypes.size() > 0) {
				for (int i = 0; i < profileStructureTypes.size(); i++) {
					if (profileStructureType.equalsIgnoreCase(profileStructureTypes.get(i).getName())) {
						return profileStructureTypes.get(i).getTitle();
					}
				}				
			}
		}
		return "";
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List<Category> getInternalAdministrativeServicesCategories() {
		try {
			DocumentIdIterator taxonomyIterator = EgovWCMCache.getWorkspace().findByName(DocumentTypes.Taxonomy, EgovWCMCache.TAXONOMY_INTERNAL_ADMIN_SERVICES);
			if (taxonomyIterator.hasNext()) {
				Taxonomy taxonomy = (Taxonomy)EgovWCMCache.getWorkspace().getById(taxonomyIterator.next(), true);
				if (taxonomy != null) {
					DocumentIdIterator dIt = taxonomy.getChildren();
					if (dIt != null) {
						List<Category> categories = new ArrayList<Category>();
						while (dIt.hasNext()) {
							categories.add((Category) EgovWCMCache.getWorkspace().getById(dIt.next(), true));
						}
						return categories;
					}					
				} 
			} else {
				Logger.log(Logger.DEBUG_LEVEL, "getInternalAdministrativeServicesCategories() no taxonomy found with name: " + EgovWCMCache.TAXONOMY_INTERNAL_ADMIN_SERVICES);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}		
		return null;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Content getEGOVRegistrationPageContent() {
		try {
			DocumentIdIterator contentIterator = EgovWCMCache.getWorkspace().findByName(DocumentTypes.Content, MySpaceConstants.EGOV_REGISTRATION_PAGE_CONTENT_NAME, Workspace.WORKFLOWSTATUS_PUBLISHED);
			if (contentIterator.hasNext()) {
				return (Content)EgovWCMCache.getWorkspace().getById(contentIterator.next(), true);				 
			} else {
				Logger.log(Logger.DEBUG_LEVEL, "getEGOVRegistrationPageContent() no content found with name: " + MySpaceConstants.EGOV_REGISTRATION_PAGE_CONTENT_NAME);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}		
		return null;
	}
	
	public String getEGOVRegistrationPageContentLeftColumn(Content content) {
		MySpaceWCMUtils utils = new MySpaceWCMUtils(); 
		return utils.getTextField(content, MySpaceConstants.EGOV_REGISTRATION_PAGE_CONTENT_ELEMENT_LEFT_COLUMN_NAME);
	}
	
	public String getEGOVRegistrationPageContentRightColumn(Content content) {
		MySpaceWCMUtils utils = new MySpaceWCMUtils(); 
		return utils.getTextField(content, MySpaceConstants.EGOV_REGISTRATION_PAGE_CONTENT_ELEMENT_RIGHT_COLUMN_NAME);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Content getEGOVTermsAndConditionsContent() {
		try {
			DocumentIdIterator contentIterator = EgovWCMCache.getWorkspace().findByName(DocumentTypes.Content, MySpaceConstants.EGOV_TERMS_AND_CONDITIONS_CONTENT_NAME, Workspace.WORKFLOWSTATUS_PUBLISHED);
			if (contentIterator.hasNext()) {
				return (Content)EgovWCMCache.getWorkspace().getById(contentIterator.next(), true);				 
			} else {
				Logger.log(Logger.DEBUG_LEVEL, "getEGOVTermsAndConditionsContent() no content found with name: " + MySpaceConstants.EGOV_TERMS_AND_CONDITIONS_CONTENT_NAME);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}		
		return null;
	}
	
	public String getEGOVTermsAndConditionsContentBody(Content content) {
		MySpaceWCMUtils utils = new MySpaceWCMUtils(); 
		return utils.getTextField(content, MySpaceConstants.EGOV_TERMS_AND_CONDITIONS_CONTENT_ELEMENT_BODY_NAME);
	}
	
	public Date getEGOVTermsAndConditionsContentReleaseDate(Content content) {
		MySpaceWCMUtils utils = new MySpaceWCMUtils(); 
		return utils.getDateField(content, MySpaceConstants.EGOV_TERMS_AND_CONDITIONS_CONTENT_ELEMENT_RELEASE_DATE_NAME);
	}
}
