package com.ibs.myspace.communicator;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.cert.X509Certificate;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.json.JSONArray;
import org.json.JSONObject;

import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.bean.ESBEDeliveryBean;
import com.ibs.myspace.portlet.bean.ESBEDeliveryResponseBean;
import com.ibs.myspace.portlet.bean.ESBEPaymentBean;
import com.ibs.myspace.portlet.bean.ESBEPaymentDataBean;
import com.ibs.myspace.portlet.bean.ESBEPaymentProviderInfoBean;
import com.ibs.myspace.portlet.bean.ESBEPaymentResponseBean;
import com.ibs.myspace.portlet.bean.ESBMDTBean;
import com.ibs.myspace.portlet.bean.ESBMDTResponseBean;
import com.ibs.myspace.portlet.bean.ESBTokenBean;
import com.ibs.myspace.portlet.db.Base;
import com.ibs.myspace.portlet.utils.Logger;

public class ESBTokenManager {
	
//	private static TrustManager[] trustAllCerts = null;
//	private static KeyManager[] keyManagers = null;
//	private static HostnameVerifier allHostsValid = null;
//	private static boolean initialized = false;
	private static final String KEY_STORE_TYPE = "pkcs12";
	private static final String KEY_STORE_FILE_NAME = Base.TEST_ENVIRONMENT ? MySpaceConstants.ESB_TEST_CLIENT_CERT_NAME : MySpaceConstants.ESB_CLIENT_CERT_NAME;
	private static final String KEY_STORE_PASSWORD = Base.TEST_ENVIRONMENT ? MySpaceConstants.ESB_TEST_CLIENT_CERT_PASS : MySpaceConstants.ESB_CLIENT_CERT_PASS;
	
	public ESBTokenManager() {
		//init();
	}	
	
//	private void init() {		
//		if (!initialized) {
//			Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : init() -> initializing...");
//			// Create a trust manager that does not validate certificate chains.
//			trustAllCerts = new TrustManager[] {new X509TrustManager() {
//	            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
//	                return null;
//	            }
//	            public void checkClientTrusted(X509Certificate[] certs, String authType) {
//	            }
//	            public void checkServerTrusted(X509Certificate[] certs, String authType) {
//	            }
//	        }
//	        };
//			// Create all-trusting host name verifier.
//			allHostsValid = new HostnameVerifier() {
//	          public boolean verify(String hostname, SSLSession session) {
//	              return true;
//	          }
//			};
//			//String keyStoreFileName = Base.TEST_ENVIRONMENT ? MySpaceConstants.ESB_TEST_CLIENT_CERT_NAME : MySpaceConstants.ESB_CLIENT_CERT_NAME;
//			//String keyStorePassword = Base.TEST_ENVIRONMENT ? MySpaceConstants.ESB_TEST_CLIENT_CERT_PASS : MySpaceConstants.ESB_CLIENT_CERT_PASS;			 			
//	        try {
//	        	KeyStore keyStore = KeyStore.getInstance(KEY_STORE_TYPE);
//				keyStore.load(new FileInputStream(new File(Base.CONFIG_FILE_LOCATION + KEY_STORE_FILE_NAME)), KEY_STORE_PASSWORD.toCharArray());
//		        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
//		        kmf.init(keyStore, KEY_STORE_PASSWORD.toCharArray());
//		        keyManagers = kmf.getKeyManagers();
//			} catch (Exception e) {
//				System.out.println(e.getMessage());
//				e.printStackTrace();
//			}
//		}
//		initialized = true;
//	}
	
	public ESBTokenBean getToken(List<ESBTokenBean>tokens, String scope, String personalIdentifier) {		
		Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getToken(" + scope + ")");
		if (tokens == null) {
			tokens = new ArrayList<ESBTokenBean>();
		}
		ESBTokenBean token = null;
		if (tokens.size() > 0) {
			boolean tokenIsExpired = false;
			for (int i = 0; i < tokens.size(); i++) {
				token = tokens.get(i);
				if (token.getScope().equalsIgnoreCase(scope)) {
					// Check if it is expired.
					Instant instant = Instant.now();
			    	long currentTimeInSeconds = instant.getEpochSecond();
			    	// Decrease 5 mins, because of the server out of sync variations.
			    	currentTimeInSeconds -= 600;
			    	if (token.getConsentedOn() + token.getExpiresIn() < currentTimeInSeconds) {
			    		tokenIsExpired = true;
			    		break;
			    	}
			    	Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : found valid token for " + scope);
					return token;
				}
			}
			if (tokenIsExpired) {
				Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : remove expired token for " + scope);
				tokens.remove(token);
			}
		}	
		try {
			token = callForToken(scope, personalIdentifier);
			if (token != null) {
				tokens.add(token);
			}
			return token;	
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public ESBTokenBean callForToken(String scope, String personalIdentifier) throws Exception {	
		Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : callForToken (" + scope + ")");
		TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                return null;
            }
            public void checkClientTrusted(X509Certificate[] certs, String authType) {
            }
            public void checkServerTrusted(X509Certificate[] certs, String authType) {
            }
        }
        };
        SSLContext sc = SSLContext.getInstance("SSL");
        KeyManager[] keyManagers = null;
        try {
        	KeyStore keyStore = KeyStore.getInstance(KEY_STORE_TYPE);
			keyStore.load(new FileInputStream(new File(Base.CONFIG_FILE_LOCATION + KEY_STORE_FILE_NAME)), KEY_STORE_PASSWORD.toCharArray());
	        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
	        kmf.init(keyStore, KEY_STORE_PASSWORD.toCharArray());
	        keyManagers = kmf.getKeyManagers();
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
        sc.init(keyManagers, trustAllCerts, new java.security.SecureRandom());
        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        // Create all-trusting host name verifier
        HostnameVerifier allHostsValid = new HostnameVerifier() {
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        };
        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);        
        HttpsURLConnection conn = null;
        BufferedReader reader = null;                
        StringBuilder strBuf = new StringBuilder();
        String clientId = Base.TEST_ENVIRONMENT ? MySpaceConstants.ESB_TEST_TOKEN_CLIENT_ID : MySpaceConstants.ESB_TOKEN_CLIENT_ID; 
        try {
        	String urlParameters  = "grant_type=" + MySpaceConstants.ESB_TOKEN_GRANT_TYPE + "&client_id=" + clientId + "&scope=" + scope;
        	byte[] postData       = urlParameters.getBytes( StandardCharsets.UTF_8 );
        	int    postDataLength = postData.length;
            URL url = new URL(Base.TEST_ENVIRONMENT ? MySpaceConstants.ESB_TEST_TOKEN_URL : MySpaceConstants.ESB_TOKEN_URL);
            conn = (HttpsURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("charset", "utf-8");
            conn.setRequestProperty("Content-Length", Integer.toString(postDataLength));
            conn.setRequestProperty("OID", MySpaceConstants.PORTAL_OID);
            conn.setRequestProperty("representedPersonID", personalIdentifier);
            conn.setConnectTimeout(12000); //set timeout to 12 seconds
	        conn.setReadTimeout(12000); //set timeout to 12 seconds
            conn.setUseCaches(false);
            conn.setDoOutput(true);
            
            try( DataOutputStream wr = new DataOutputStream( conn.getOutputStream())) {
            	wr.write( postData );
            }

            if (conn.getResponseCode() != 200) {
            	Logger.log(Logger.ERROR_LEVEL, "MySpaceESBTokenManager : callForToken url->" + (Base.TEST_ENVIRONMENT ? MySpaceConstants.ESB_TEST_TOKEN_URL : MySpaceConstants.ESB_TOKEN_URL));
            	Logger.log(Logger.ERROR_LEVEL, "MySpaceESBTokenManager : callForToken urlParameters->" + urlParameters);
            	Logger.log(Logger.ERROR_LEVEL, "MySpaceESBTokenManager : callForToken OID->" + MySpaceConstants.PORTAL_OID);
            	Logger.log(Logger.ERROR_LEVEL, "MySpaceESBTokenManager : callForToken representedPersonID->" + personalIdentifier);
                throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode());
            }

            reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
            String output = null;
            while ((output = reader.readLine()) != null) {
                strBuf.append(output);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                conn.disconnect();
            }
        }

        String result = strBuf.toString();
        Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : callForToken result: " + result);
        if (result != null && result.trim().length() > 0) {        	
            JSONObject jo = new JSONObject(result);            
            if (jo != null) {
            	ESBTokenBean token = new ESBTokenBean();
            	token.setTokenType(jo.get("token_type").toString());
            	token.setAccessToken(jo.get("access_token").toString());
            	token.setExpiresIn(jo.getInt("expires_in"));
            	token.setConsentedOn(jo.getInt("consented_on"));
            	token.setScope(jo.get("scope").toString());
            	token.setGrantType(jo.get("grant_type").toString());
            	return token;            	
            }
        }
        return null;
	}
	
	@Deprecated
	public String getORN(ESBTokenBean token, String personalIdentifier) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getORN(token,personalIdentifier)");
		//ESBTokenBean token = getToken(MySpaceConstants.ESB_TOKEN_SCOPE_ORN, personalIdentifier);		
		if (token != null) {
			StringBuilder strBuf = new StringBuilder();
			TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
	            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
	                return null;
	            }
	            public void checkClientTrusted(X509Certificate[] certs, String authType) {
	            }
	            public void checkServerTrusted(X509Certificate[] certs, String authType) {
	            }
	        }
	        };
			SSLContext sc = SSLContext.getInstance("SSL");
			KeyManager[] keyManagers = null;
	        try {
	        	KeyStore keyStore = KeyStore.getInstance(KEY_STORE_TYPE);
				keyStore.load(new FileInputStream(new File(Base.CONFIG_FILE_LOCATION + KEY_STORE_FILE_NAME)), KEY_STORE_PASSWORD.toCharArray());
		        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
		        kmf.init(keyStore, KEY_STORE_PASSWORD.toCharArray());
		        keyManagers = kmf.getKeyManagers();
			} catch (Exception e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
	        sc.init(keyManagers, trustAllCerts, new java.security.SecureRandom());
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
	        // Create all-trusting host name verifier
	        HostnameVerifier allHostsValid = new HostnameVerifier() {
	            public boolean verify(String hostname, SSLSession session) {
	                return true;
	            }
	        };
	        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);    
	        HttpsURLConnection conn = null;
	        BufferedReader reader = null;	                
	        try {
	        	String typeService = URLEncoder.encode("Овластяване", StandardCharsets.UTF_8.toString());
	        	String ornURL = Base.TEST_ENVIRONMENT ? MySpaceConstants.ESB_TEST_ORN_URL : MySpaceConstants.ESB_ORN_URL;
	            URL url = new URL(ornURL + "?uri_service=" + MySpaceConstants.ESB_ORN_URI_SERVICE + "&bulstat=" + MySpaceConstants.ESB_ORN_BULSTAT + "&type_service=" + typeService);
	            conn = (HttpsURLConnection) url.openConnection();
	            conn.setRequestMethod("GET");
	            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
	            conn.setRequestProperty("Accept", "application/json");
	            conn.setRequestProperty( "charset", "utf-8");
	            conn.setConnectTimeout(12000); //set timeout to 12 seconds
		        conn.setReadTimeout(12000); //set timeout to 12 seconds
	            conn.setUseCaches( false );
	            conn.setDoOutput(true);
	            conn.setRequestProperty("Authorization","Bearer " + token.getAccessToken());
	            
	            if (conn.getResponseCode() != 200) {
	            	// Invalid token.
	            	if (401 == conn.getResponseCode()) {
	            		Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getORN() response 401 found, trying to get new token...");
	            		// Try to get new one.
	            		token = this.callForToken(MySpaceConstants.ESB_TOKEN_SCOPE_ORN, personalIdentifier);
	            		if (token != null) {	            			
	            			if (conn != null) {
	         	                conn.disconnect();
	         	                url = new URL(ornURL + "?uri_service=" + MySpaceConstants.ESB_ORN_URI_SERVICE + "&bulstat=" + MySpaceConstants.ESB_ORN_BULSTAT + "&type_service=" + typeService);
	         	                conn = (HttpsURLConnection) url.openConnection();
	         		            conn.setRequestMethod("GET");
	         		            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
	         		            conn.setRequestProperty("Accept", "application/json");
	         		            conn.setRequestProperty( "charset", "utf-8");
	         		            conn.setConnectTimeout(12000); //set timeout to 12 seconds
	         			        conn.setReadTimeout(12000); //set timeout to 12 seconds
	         		            conn.setUseCaches( false );
	         		            conn.setDoOutput(true);
	         		            conn.setRequestProperty("Authorization","Bearer " + token.getAccessToken());
	         		            if (conn.getResponseCode() != 200) {
	         		            	throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode());
	         		            }
	         	            }
	            		}
	            	} else {	            			            	
	            		throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode());
	            	}
	            }

	            reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
	            String output = null;
	            while ((output = reader.readLine()) != null) {
	                strBuf.append(output);
	            }
	        } catch (IOException e) {
	            e.printStackTrace();
	        } finally {
	            if (reader != null) {
	                try {
	                    reader.close();
	                } catch (IOException e) {
	                    e.printStackTrace();
	                }
	            }
	            if (conn != null) {
	                conn.disconnect();
	            }
	        }
	        String result = strBuf.toString();
	        if (result != null) {
	        	Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getORN() -> result: " + result);
	        	JSONObject jo = new JSONObject(result);  
	        	return jo.get("orn").toString();
	        }
		}		
		return null;
	}
	
	public ESBEDeliveryResponseBean getEDelivery(ESBTokenBean token, String personalIdentifier, String direction, String profileID, int pageNumber, int pageSize) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getEDelivery(token, " + personalIdentifier + ", " + direction + "," + profileID + "," + pageNumber + ", " + pageSize + ")");
		//ESBTokenBean token = getToken(tokens, MySpaceConstants.ESB_TOKEN_SCOPE_E_DELIVERY, personalIdentifier);				
		if (token != null) {
			StringBuilder strBuf = new StringBuilder();
			TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
	            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
	                return null;
	            }
	            public void checkClientTrusted(X509Certificate[] certs, String authType) {
	            }
	            public void checkServerTrusted(X509Certificate[] certs, String authType) {
	            }
	        }
	        };
			SSLContext sc = SSLContext.getInstance("SSL");
			KeyManager[] keyManagers = null;
	        try {
	        	KeyStore keyStore = KeyStore.getInstance(KEY_STORE_TYPE);
				keyStore.load(new FileInputStream(new File(Base.CONFIG_FILE_LOCATION + KEY_STORE_FILE_NAME)), KEY_STORE_PASSWORD.toCharArray());
		        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
		        kmf.init(keyStore, KEY_STORE_PASSWORD.toCharArray());
		        keyManagers = kmf.getKeyManagers();
			} catch (Exception e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
	        sc.init(keyManagers, trustAllCerts, new java.security.SecureRandom());
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
	     // Create all-trusting host name verifier
	        HostnameVerifier allHostsValid = new HostnameVerifier() {
	            public boolean verify(String hostname, SSLSession session) {
	                return true;
	            }
	        };
	        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);    
	        HttpsURLConnection conn = null;
	        BufferedReader reader = null;	 
	        String eDeliveryURL = Base.TEST_ENVIRONMENT ? MySpaceConstants.ESB_TEST_E_DELIVERY_URL : MySpaceConstants.ESB_E_DELIVERY_URL;
        	eDeliveryURL += "?direction=" + direction + (profileID != null ? "&profileID=" + profileID : "") + "&pageNumber=" + pageNumber + "&pageSize=" + pageSize;
        	System.out.println("eDeliveryURL=" + eDeliveryURL);
	        try {	        	
	            URL url = new URL(eDeliveryURL);
	            conn = (HttpsURLConnection) url.openConnection();
	            conn.setRequestMethod("GET");
	            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
	            conn.setRequestProperty("Accept", "application/json");
	            conn.setRequestProperty( "charset", "utf-8");
	            conn.setConnectTimeout(12000); //set timeout to 12 seconds
		        conn.setReadTimeout(12000); //set timeout to 12 seconds
	            conn.setUseCaches( false );
	            conn.setDoOutput(true);
	            conn.setRequestProperty("Authorization","Bearer " + token.getAccessToken());	            
	            if (conn.getResponseCode() != 200) {		            	
	            	if (401 == conn.getResponseCode()) {
	            		String authHeader = conn.getHeaderField("WWW-Authenticate");	            		
	            		if (authHeader != null && authHeader.indexOf("invalid_token") != -1) {	        
		            		Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getEDelivery() response 401 found, trying to get new token...");
		            		// Try to get new one.
		            		token = this.callForToken(MySpaceConstants.ESB_TOKEN_SCOPE_E_DELIVERY, personalIdentifier);
		            		if (token != null) {	            				            			
		            			if (conn != null) {
		         	                conn.disconnect();
		         	                url = new URL(eDeliveryURL);
		         	                conn = (HttpsURLConnection) url.openConnection();
		         		            conn.setRequestMethod("GET");
		         		            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		         		            conn.setRequestProperty("Accept", "application/json");
		         		            conn.setRequestProperty( "charset", "utf-8");
		         		            conn.setConnectTimeout(12000); //set timeout to 12 seconds
		         			        conn.setReadTimeout(12000); //set timeout to 12 seconds
		         		            conn.setUseCaches( false );
		         		            conn.setDoOutput(true);
		         		            conn.setRequestProperty("Authorization","Bearer " + token.getAccessToken());
		         		            if (conn.getResponseCode() != 200 && conn.getResponseCode() != 401) {
		         		            	throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode());
		         		            }
		         	            }
		            		}
	    		        } else {
	    		        	// Looks like there is no such user in eDelivery system.
		            		Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getEDelivery() response 401 found, no data for current user in eDelivery, exiting...");
		            		if (conn != null) {
		    	                conn.disconnect();
		    	            }
		            		return null;
	    		        }
	            	} else {	            			            	
	            		throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode());
	            	}
	            }

	            reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
	            String output = null;
	            while ((output = reader.readLine()) != null) {
	                strBuf.append(output);
	            }
	        } catch (IOException e) {	
	        	if (401 == conn.getResponseCode()) {
	        		String authHeader = conn.getHeaderField("WWW-Authenticate");	            		
            		if (authHeader != null && authHeader.indexOf("invalid_token") != -1) {	
            			Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getEDelivery() response 401 found, trying to get new token...");
            			// Try to get new one.
	            		token = this.callForToken(MySpaceConstants.ESB_TOKEN_SCOPE_E_DELIVERY, personalIdentifier);
	            		if (token != null) {	            				            			
	            			if (conn != null) {
	         	                conn.disconnect();
	         	                URL url = new URL(eDeliveryURL);
	         	                conn = (HttpsURLConnection) url.openConnection();
	         		            conn.setRequestMethod("GET");
	         		            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
	         		            conn.setRequestProperty("Accept", "application/json");
	         		            conn.setRequestProperty( "charset", "utf-8");
	         		            conn.setConnectTimeout(12000); //set timeout to 12 seconds
	         			        conn.setReadTimeout(12000); //set timeout to 12 seconds
	         		            conn.setUseCaches( false );
	         		            conn.setDoOutput(true);
	         		            conn.setRequestProperty("Authorization","Bearer " + token.getAccessToken());
	         		            if (conn.getResponseCode() != 200 && conn.getResponseCode() != 401) {
	         		            	throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode());
	         		            }
	         	            }
	            		}
	            		try {
			        		reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
				            String output = null;
				            while ((output = reader.readLine()) != null) {
				                strBuf.append(output);
				            }
						} catch (Exception e2) {
							e2.printStackTrace();
						} finally {
				            if (reader != null) {
				                try {
				                    reader.close();
				                } catch (IOException e3) {
				                    e3.printStackTrace();
				                }
				            }
				            if (conn != null) {
				                conn.disconnect();
				            }
				        }
            		} else {
            			// Looks like there is no such user in eDelivery system.
	            		Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getEDelivery() response 401 found, no data for current user in eDelivery, exiting...");
	            		if (conn != null) {
	    	                conn.disconnect();
	    	            }
	            		return null;
            		}
	        		
	        	} else {	        			        		
	        		throw e;
	        	}
	        } finally {
	            if (reader != null) {
	                try {
	                    reader.close();
	                } catch (IOException e) {
	                    e.printStackTrace();
	                }
	            }
	            if (conn != null) {
	                conn.disconnect();
	            }
	        }
	        String result = strBuf.toString();
	        if (result != null && result.trim().length() > 0) {	        	
	        	Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getEDelivery() -> result: " + result);
	        	JSONObject jo = new JSONObject(result); 
	        	ESBEDeliveryResponseBean response = new ESBEDeliveryResponseBean();
	        	if (jo.has("messages")) {
	    			JSONArray ja = jo.getJSONArray("messages");
	    			if (ja.length() > 0) {
	    				JSONObject jMessage = null;
	    				List<ESBEDeliveryBean> eDeliveries = new ArrayList<ESBEDeliveryBean>();
	    				ESBEDeliveryBean message = null;
	    				for (int i = 0; i < ja.length(); i++) {					
	    					jMessage = ja.getJSONObject(i);					
	    					message = new ESBEDeliveryBean();
	    					message.setMessageId(jMessage.getLong("messageId"));
	    					message.setSubject(jMessage.getString("subject"));
	    					if (jMessage.has("dateSent")) {
	    						message.setDateSent(jMessage.getString("dateSent"));
	    					}
	    					if (jMessage.has("dateReceived")) {
	    						message.setDateReceived(jMessage.getString("dateReceived"));						
	    					}
	    					if (jMessage.has("senderProfileName")) {
	    						message.setSenderProfileName(jMessage.getString("senderProfileName"));
	    					}
	    					if (jMessage.has("senderLoginName")) {
	    						message.setSenderLoginName(jMessage.getString("senderLoginName"));
	    					}
	    					if (jMessage.has("recipientProfileName")) {
	    						message.setRecipientProfileName(jMessage.getString("recipientProfileName"));
	    					}
	    					if (jMessage.has("recipientLoginName")) {
	    						message.setRecipientLoginName(jMessage.getString("recipientLoginName"));
	    					}
	    					if (jMessage.has("recipients")) {
	    						message.setRecipients(jMessage.getString("recipients"));
	    					}
	    					if (jMessage.has("url")) {
	    						message.setUrl(jMessage.getString("url"));
	    					}	    					
	    					eDeliveries.add(message);
	    				}
	    				response.setMessages(eDeliveries);
	    			}
	    		}
	        	if (jo.has("messageType")) {
	        		response.setMessageType(jo.getString("messageType"));
	        	}
	        	if (jo.has("count")) {
	        		response.setCount(jo.getInt("count"));
	        	}
	        	return response;
	        }
		}		
		return null;
	}
	
	public ESBEPaymentResponseBean getEPayment(ESBTokenBean token, String personalIdentifier, String status, String profileID, int pageNumber, int pageSize) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getEPayment(token, " + personalIdentifier + ", [" + status + "]," + profileID + "," + pageNumber + ", " + pageSize + ")");
		if (token != null) {
			StringBuilder strBuf = new StringBuilder();
			TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
	            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
	                return null;
	            }
	            public void checkClientTrusted(X509Certificate[] certs, String authType) {
	            }
	            public void checkServerTrusted(X509Certificate[] certs, String authType) {
	            }
	        }
	        };
			SSLContext sc = SSLContext.getInstance("SSL");
			KeyManager[] keyManagers = null;
	        try {
	        	KeyStore keyStore = KeyStore.getInstance(KEY_STORE_TYPE);
				keyStore.load(new FileInputStream(new File(Base.CONFIG_FILE_LOCATION + KEY_STORE_FILE_NAME)), KEY_STORE_PASSWORD.toCharArray());
		        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
		        kmf.init(keyStore, KEY_STORE_PASSWORD.toCharArray());
		        keyManagers = kmf.getKeyManagers();
			} catch (Exception e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
	        sc.init(keyManagers, trustAllCerts, new java.security.SecureRandom());
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
	        // Create all-trusting host name verifier
	        HostnameVerifier allHostsValid = new HostnameVerifier() {
	            public boolean verify(String hostname, SSLSession session) {
	                return true;
	            }
	        };
	        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);    
	        HttpsURLConnection conn = null;
	        BufferedReader reader = null;	 
	        String ePaymentURL = Base.TEST_ENVIRONMENT ? MySpaceConstants.ESB_TEST_E_PAYMENT_URL : MySpaceConstants.ESB_E_PAYMENT_URL;
	        ePaymentURL += "?paymentTypeList=" + status + (profileID != null ? "&profileID=" + profileID : "") + "&pageNumber=" + pageNumber + "&pageSize=" + pageSize;
        	System.out.println("ePaymentURL=" + ePaymentURL);
	        try {	        	
	            URL url = new URL(ePaymentURL);
	            conn = (HttpsURLConnection) url.openConnection();
	            conn.setRequestMethod("GET");
	            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
	            conn.setRequestProperty("Accept", "application/json");
	            conn.setRequestProperty( "charset", "utf-8");
	            conn.setConnectTimeout(12000); //set timeout to 12 seconds
		        conn.setReadTimeout(12000); //set timeout to 12 seconds
	            conn.setUseCaches( false );
	            conn.setDoOutput(true);
	            conn.setRequestProperty("Authorization","Bearer " + token.getAccessToken());	            
	            if (conn.getResponseCode() != 200) {		            	
	            	if (401 == conn.getResponseCode()) {
	            		String authHeader = conn.getHeaderField("WWW-Authenticate");	            		
	            		if (authHeader != null && authHeader.indexOf("invalid_token") != -1) {	        
		            		Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getEPayment() response 401 found, trying to get new token...");
		            		// Try to get new one.
		            		token = this.callForToken(MySpaceConstants.ESB_TOKEN_SCOPE_E_PAYMENT, personalIdentifier);
		            		if (token != null) {	            				            			
		            			if (conn != null) {
		         	                conn.disconnect();
		         	                url = new URL(ePaymentURL);
		         	                conn = (HttpsURLConnection) url.openConnection();
		         		            conn.setRequestMethod("GET");
		         		            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		         		            conn.setRequestProperty("Accept", "application/json");
		         		            conn.setRequestProperty( "charset", "utf-8");
		         		            conn.setConnectTimeout(12000); //set timeout to 12 seconds
		         			        conn.setReadTimeout(12000); //set timeout to 12 seconds
		         		            conn.setUseCaches( false );
		         		            conn.setDoOutput(true);
		         		            conn.setRequestProperty("Authorization","Bearer " + token.getAccessToken());
		         		            if (conn.getResponseCode() != 200 && conn.getResponseCode() != 401) {
		         		            	throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode());
		         		            }
		         	            }
		            		}
	    		        } else {
	    		        	// Looks like there is no such user in eDelivery system.
		            		Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getEPayment() response 401 found, no data for current user in eDelivery, exiting...");
		            		if (conn != null) {
		    	                conn.disconnect();
		    	            }
		            		return null;
	    		        }
	            	} else {	            			            	
	            		throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode() + ", msg:" + conn.getResponseMessage());
	            	}
	            }

	            reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
	            String output = null;
	            while ((output = reader.readLine()) != null) {
	                strBuf.append(output);
	            }
	        } catch (IOException e) {	
	        	if (401 == conn.getResponseCode()) {
	        		String authHeader = conn.getHeaderField("WWW-Authenticate");	            		
            		if (authHeader != null && authHeader.indexOf("invalid_token") != -1) {	
            			Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getEPayment() response 401 found, trying to get new token...");
            			// Try to get new one.
	            		token = this.callForToken(MySpaceConstants.ESB_TOKEN_SCOPE_E_PAYMENT, personalIdentifier);
	            		if (token != null) {	            				            			
	            			if (conn != null) {
	         	                conn.disconnect();
	         	                URL url = new URL(ePaymentURL);
	         	                conn = (HttpsURLConnection) url.openConnection();
	         		            conn.setRequestMethod("GET");
	         		            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
	         		            conn.setRequestProperty("Accept", "application/json");
	         		            conn.setRequestProperty( "charset", "utf-8");
	         		            conn.setConnectTimeout(12000); //set timeout to 12 seconds
	         			        conn.setReadTimeout(12000); //set timeout to 12 seconds
	         		            conn.setUseCaches( false );
	         		            conn.setDoOutput(true);
	         		            conn.setRequestProperty("Authorization","Bearer " + token.getAccessToken());
	         		            if (conn.getResponseCode() != 200 && conn.getResponseCode() != 401) {
	         		            	throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode());
	         		            }
	         	            }
	            		}
	            		try {
			        		reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
				            String output = null;
				            while ((output = reader.readLine()) != null) {
				                strBuf.append(output);
				            }
						} catch (Exception e2) {
							e2.printStackTrace();
						} finally {
				            if (reader != null) {
				                try {
				                    reader.close();
				                } catch (IOException e3) {
				                    e3.printStackTrace();
				                }
				            }
				            if (conn != null) {
				                conn.disconnect();
				            }
				        }
            		} else {
            			// Looks like there is no such user in eDelivery system.
	            		Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getEPayment() response 401 found, no data for current user in eDelivery, exiting...");
	            		if (conn != null) {
	    	                conn.disconnect();
	    	            }
	            		return null;
            		}
	        		
	        	} else {	        			        		
	        		throw e;
	        	}
	        } finally {
	            if (reader != null) {
	                try {
	                    reader.close();
	                } catch (IOException e) {
	                    e.printStackTrace();
	                }
	            }
	            if (conn != null) {
	                conn.disconnect();
	            }
	        }
	        String result = strBuf.toString();
	        if (result != null && result.trim().length() > 0) {	        	
	        	Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getEPayment() -> result: " + result);
	        	JSONObject jo = new JSONObject(result); 
	        	ESBEPaymentResponseBean response = new ESBEPaymentResponseBean();
	        	if (jo.has("payments")) {
	    			JSONArray ja = jo.getJSONArray("payments");
	    			if (ja.length() > 0) {
	    				JSONObject jPayment = null;
	    				JSONObject jPaymentData = null;	
	    				JSONObject jPaymentProviderInfo = null;	
	    				List<ESBEPaymentBean> ePayments = new ArrayList<ESBEPaymentBean>();
	    				ESBEPaymentBean payment = null;
	    				ESBEPaymentDataBean paymentData = null;
	    				ESBEPaymentProviderInfoBean bankAccount = null;
	    				for (int i = 0; i < ja.length(); i++) {					
	    					jPayment = ja.getJSONObject(i);
	    					
	    					if (jPayment.has("paymentData") && jPayment.has("providerInfo")) {
	    						
	    						jPaymentData = jPayment.getJSONObject("paymentData");
	    						jPaymentProviderInfo = jPayment.getJSONObject("providerInfo");
	    						
		    					payment = new ESBEPaymentBean();
		    					paymentData = new ESBEPaymentDataBean();
		    					bankAccount = new ESBEPaymentProviderInfoBean();
		    							    					
		    					paymentData.setPaymentId(jPaymentData.getLong("paymentId"));
		    					paymentData.setAmount(jPaymentData.getString("amount"));
		    					paymentData.setCurrency(jPaymentData.getString("currency"));
		    					paymentData.setStatus(jPaymentData.getString("status"));
		    					if (jPaymentData.has("referenceType") && !jPaymentData.isNull("referenceType")) {
		    						paymentData.setReferenceType(jPaymentData.getString("referenceType"));
		    					}
		    					if (jPaymentData.has("referenceNumber") && !jPaymentData.isNull("referenceNumber")) {
		    						paymentData.setReferenceNumber(jPaymentData.getString("referenceNumber"));
		    					}
		    					if (jPaymentData.has("referenceDate") && !jPaymentData.isNull("referenceDate")) {
		    						paymentData.setReferenceDate(jPaymentData.getString("referenceDate"));
		    					}
		    					if (jPaymentData.has("expirationDate")) {
		    						paymentData.setExpirationDate(jPaymentData.getString("expirationDate"));
		    					}
		    					if (jPaymentData.has("createDate")) {
		    						paymentData.setCreateDate(jPaymentData.getString("createDate"));
		    					}
		    					if (jPaymentData.has("additionalInformation") && !jPaymentData.isNull("additionalInformation")) {
		    						paymentData.setAdditionalInformation(jPaymentData.getString("additionalInformation"));
		    					}
		    					if (jPaymentData.has("reason") && !jPaymentData.isNull("reason")) {
		    						paymentData.setReason(jPaymentData.getString("reason"));
		    					}
		    					
		    					if (jPaymentProviderInfo.has("name") && !jPaymentData.isNull("name")) {
		    						bankAccount.setName(jPaymentProviderInfo.getString("name"));
		    					}
		    					if (jPaymentProviderInfo.has("bank") && !jPaymentData.isNull("bank")) {
		    						bankAccount.setBank(jPaymentProviderInfo.getString("bank"));
		    					}
		    					if (jPaymentProviderInfo.has("bic") && !jPaymentData.isNull("bic")) {
		    						bankAccount.setBic(jPaymentProviderInfo.getString("bic"));
		    					}
		    					if (jPaymentProviderInfo.has("iban") && !jPaymentData.isNull("iban")) {
		    						bankAccount.setIban(jPaymentProviderInfo.getString("iban"));
		    					}
		    					payment.setPaymentData(paymentData); 
		    					payment.setBankAccount(bankAccount);
		    					if (jPayment.has("eserviceAisName")) {
		    						payment.setEserviceAisName(jPayment.getString("eserviceAisName"));
		    					}
		    					ePayments.add(payment);
	    					}
	    				}
	    				response.setPayments(ePayments);
	    			}
	    		}
	        	if (jo.has("count")) {
	        		response.setCount(jo.getInt("count"));
	        	}
	        	return response;
	        }
		}		
		return null;
	}
	
	public ESBMDTResponseBean getMDT(ESBTokenBean token, String personalIdentifier) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getMDT(token, " + personalIdentifier + ")");
		if (token != null) {
			StringBuilder strBuf = new StringBuilder();
			TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
	            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
	                return null;
	            }
	            public void checkClientTrusted(X509Certificate[] certs, String authType) {
	            }
	            public void checkServerTrusted(X509Certificate[] certs, String authType) {
	            }
	        }
	        };
			SSLContext sc = SSLContext.getInstance("SSL");
			KeyManager[] keyManagers = null;
	        try {
	        	KeyStore keyStore = KeyStore.getInstance(KEY_STORE_TYPE);
				keyStore.load(new FileInputStream(new File(Base.CONFIG_FILE_LOCATION + KEY_STORE_FILE_NAME)), KEY_STORE_PASSWORD.toCharArray());
		        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
		        kmf.init(keyStore, KEY_STORE_PASSWORD.toCharArray());
		        keyManagers = kmf.getKeyManagers();
			} catch (Exception e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
	        sc.init(keyManagers, trustAllCerts, new java.security.SecureRandom());
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
	        // Create all-trusting host name verifier
	        HostnameVerifier allHostsValid = new HostnameVerifier() {
	            public boolean verify(String hostname, SSLSession session) {
	                return true;
	            }
	        };
	        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);    
	        HttpsURLConnection conn = null;
	        BufferedReader reader = null;	 
	        String mdtURL = Base.TEST_ENVIRONMENT ? MySpaceConstants.ESB_TEST_MDT_URL : MySpaceConstants.ESB_MDT_URL;
	        if (Base.TEST_ENVIRONMENT && "8203233820".equals(personalIdentifier)) {
	        	mdtURL += "?limit=35";
	        }
        	System.out.println("mdtURL=" + mdtURL);
	        try {	        	
	            URL url = new URL(mdtURL);
	            conn = (HttpsURLConnection) url.openConnection();
	            conn.setRequestMethod("GET");
	            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
	            conn.setRequestProperty("Accept", "application/json");
	            conn.setRequestProperty( "charset", "utf-8");
	            conn.setConnectTimeout(300000); //set timeout to 5 mins
		        conn.setReadTimeout(300000); //set timeout to 5 mins
	            conn.setUseCaches( false );
	            conn.setDoOutput(true);
	            conn.setRequestProperty("Authorization","Bearer " + token.getAccessToken());	            
	            if (conn.getResponseCode() != 200) {		            	
	            	if (401 == conn.getResponseCode()) {
	            		String authHeader = conn.getHeaderField("WWW-Authenticate");	            		
	            		if (authHeader != null && authHeader.indexOf("invalid_token") != -1) {	        
		            		Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getMDT() response 401 found, trying to get new token...");
		            		// Try to get new one.
		            		token = this.callForToken(MySpaceConstants.ESB_TOKEN_SCOPE_MDT, personalIdentifier);
		            		if (token != null) {	            				            			
		            			if (conn != null) {
		         	                conn.disconnect();
		         	                url = new URL(mdtURL);
		         	                conn = (HttpsURLConnection) url.openConnection();
		         		            conn.setRequestMethod("GET");
		         		            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
		         		            conn.setRequestProperty("Accept", "application/json");
		         		            conn.setRequestProperty( "charset", "utf-8");
		         		            conn.setConnectTimeout(300000); //set timeout to 5 mins
		         			        conn.setReadTimeout(300000); //set timeout to 5 mins
		         		            conn.setUseCaches( false );
		         		            conn.setDoOutput(true); 
		         		            conn.setRequestProperty("Authorization","Bearer " + token.getAccessToken());
		         		            if (conn.getResponseCode() != 200 && conn.getResponseCode() != 401) {
		         		            	throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode());
		         		            }
		         	            }
		            		}
	    		        } else {
	    		        	// Looks like there is no such user in eDelivery system.
		            		Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getMDT() response 401 found, no data for current user in eDelivery, exiting...");
		            		if (conn != null) {
		    	                conn.disconnect();
		    	            }
		            		return null;
	    		        }
	            	} else {	            			            	
	            		throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode() + ", msg:" + conn.getResponseMessage());
	            	}
	            }

	            reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
	            String output = null;
	            while ((output = reader.readLine()) != null) {
	                strBuf.append(output);
	            }
	        } catch (IOException e) {	
	        	if (401 == conn.getResponseCode()) {
	        		String authHeader = conn.getHeaderField("WWW-Authenticate");	            		
            		if (authHeader != null && authHeader.indexOf("invalid_token") != -1) {	
            			Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getMDT() response 401 found, trying to get new token...");
            			// Try to get new one.
	            		token = this.callForToken(MySpaceConstants.ESB_TOKEN_SCOPE_MDT, personalIdentifier);
	            		if (token != null) {	            				            			
	            			if (conn != null) {
	         	                conn.disconnect();
	         	                URL url = new URL(mdtURL);
	         	                conn = (HttpsURLConnection) url.openConnection();
	         		            conn.setRequestMethod("GET");
	         		            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
	         		            conn.setRequestProperty("Accept", "application/json");
	         		            conn.setRequestProperty( "charset", "utf-8");
	         		            conn.setConnectTimeout(300000); //set timeout to 5 mins
	         			        conn.setReadTimeout(300000); //set timeout to 5 mins
	         		            conn.setUseCaches( false );
	         		            conn.setDoOutput(true);
	         		            conn.setRequestProperty("Authorization","Bearer " + token.getAccessToken());
	         		            if (conn.getResponseCode() != 200 && conn.getResponseCode() != 401) {
	         		            	throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode());
	         		            }
	         	            }
	            		}
	            		try {
			        		reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
				            String output = null;
				            while ((output = reader.readLine()) != null) {
				                strBuf.append(output);
				            }
						} catch (Exception e2) {
							e2.printStackTrace();
						} finally {
				            if (reader != null) {
				                try {
				                    reader.close();
				                } catch (IOException e3) {
				                    e3.printStackTrace();
				                }
				            }
				            if (conn != null) {
				                conn.disconnect();
				            }
				        }
            		} else {
            			// Looks like there is no such user in eDelivery system.
	            		Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getMDT() response 401 found, no data for current user in eDelivery, exiting...");
	            		if (conn != null) {
	    	                conn.disconnect();
	    	            }
	            		return null;
            		}
	        		
	        	} else {	        			        		
	        		throw e;
	        	}
	        } finally {
	            if (reader != null) {
	                try {
	                    reader.close();
	                } catch (IOException e) {
	                    e.printStackTrace();
	                }
	            }
	            if (conn != null) {
	                conn.disconnect();
	            }
	        }
	        String result = strBuf.toString();
	        if (result != null && result.trim().length() > 0) {	        	
	        	Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : getMDT() -> result: " + result);
	        	JSONArray ja = new JSONArray(result); 
	        	ESBMDTResponseBean response = new ESBMDTResponseBean();
	    		if (ja.length() > 0) {
	    			JSONObject jMdt = null;
	    			JSONArray jResultArr = null;
    				JSONObject jResult = null;
    				List<ESBMDTBean> mdts = new ArrayList<ESBMDTBean>();
    				List<String> failed = new ArrayList<String>();
    				String municipalityStatus = null;
    				ESBMDTBean mdt = null;
    				for (int i = 0; i < ja.length(); i++) {					
    					jMdt = ja.getJSONObject(i);
    					
    					if (jMdt.has("municipality") && jMdt.has("municipalityStatus")) {
    						if (jMdt.has("result")) {
	    						jResultArr = jMdt.getJSONArray("result");
	    						if (jResultArr != null && jResultArr.length() > 0) {
	    							for (int j = 0; j < jResultArr.length(); j++) {
	    								mdt = new ESBMDTBean();
	    	    						mdt.setMunicipality(jMdt.getString("municipality"));
	    	    						mdt.setMunicipalityId(jMdt.get("municipalityId").toString());
	    	    						mdt.setMunicipalityStatus(jMdt.getString("municipalityStatus"));
	    								jResult = jResultArr.getJSONObject(j);
	    								if (jResult.has("reason") && !jResult.isNull("reason")) {
	    									mdt.setReason(jResult.getString("reason"));
	    								}
	    								if (jResult.has("partida") && !jResult.isNull("partida")) {
	    									mdt.setPartida(jResult.getString("partida"));
	    								}
	    								if (jResult.has("period") && !jResult.isNull("period")) {
	    									mdt.setPeriod(jResult.getString("period"));
	    								}
	    								if (jResult.has("installment") && !jResult.isNull("installment")) {
	    									mdt.setInstallment(String.valueOf(jResult.getInt("installment"))); 
	    								}
	    								if (jResult.has("amount") && !jResult.isNull("amount")) {
	    									mdt.setAmount(jResult.getString("amount"));
	    								}
	    								if (jResult.has("paymentStatus") && !jResult.isNull("paymentStatus")) {
	    									mdt.setPaymentStatus(jResult.getString("paymentStatus"));
	    								}
	    								if (MySpaceConstants.ESB_MDT_MUNICIPALITY_STATUS_OBLIGATIONS.equals(mdt.getMunicipalityStatus())) {
	    									mdts.add(mdt);
	    								} else if (!(MySpaceConstants.ESB_MDT_MUNICIPALITY_STATUS_MISSING_DEPT.equals(mdt.getMunicipalityStatus()) 
	    										|| MySpaceConstants.ESB_MDT_MUNICIPALITY_STATUS_MISSING_OBJECT.equals(mdt.getMunicipalityStatus()))) {
	    									failed.add(mdt.getMunicipality());
	    								}
	    							}
	    						}   
    						} else {
    							municipalityStatus = jMdt.getString("municipalityStatus");
    							if (!(MySpaceConstants.ESB_MDT_MUNICIPALITY_STATUS_MISSING_DEPT.equals(municipalityStatus) 
										|| MySpaceConstants.ESB_MDT_MUNICIPALITY_STATUS_MISSING_OBJECT.equals(municipalityStatus))) {
    								failed.add(jMdt.getString("municipality"));
    							}
    						}
    					}
    				}
    				response.setMdts(mdts);
    				response.setFailed(failed);
	    		}	        	
	        	return response;
	        }
		}		
		return null;
	}
	
	public ESBMDTResponseBean registerMDTObligations(ESBTokenBean token, String personalIdentifier, String municipalityIdList) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : registerMDTObligations(token, " + personalIdentifier + "," + municipalityIdList + ")");
		if (token != null) {
			StringBuilder strBuf = new StringBuilder();
			TrustManager[] trustAllCerts = new TrustManager[] {new X509TrustManager() {
	            public java.security.cert.X509Certificate[] getAcceptedIssuers() {
	                return null;
	            }
	            public void checkClientTrusted(X509Certificate[] certs, String authType) {
	            }
	            public void checkServerTrusted(X509Certificate[] certs, String authType) {
	            }
	        }
	        };
			SSLContext sc = SSLContext.getInstance("SSL");
			KeyManager[] keyManagers = null;
	        try {
	        	KeyStore keyStore = KeyStore.getInstance(KEY_STORE_TYPE);
				keyStore.load(new FileInputStream(new File(Base.CONFIG_FILE_LOCATION + KEY_STORE_FILE_NAME)), KEY_STORE_PASSWORD.toCharArray());
		        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
		        kmf.init(keyStore, KEY_STORE_PASSWORD.toCharArray());
		        keyManagers = kmf.getKeyManagers();
			} catch (Exception e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
	        sc.init(keyManagers, trustAllCerts, new java.security.SecureRandom());
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
	        // Create all-trusting host name verifier
	        HostnameVerifier allHostsValid = new HostnameVerifier() {
	            public boolean verify(String hostname, SSLSession session) {
	                return true;
	            }
	        };
	        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);    
	        HttpsURLConnection conn = null;
	        BufferedReader reader = null;	 
	        String mdtURL = Base.TEST_ENVIRONMENT ? MySpaceConstants.ESB_TEST_REGISTER_MDT_URL : MySpaceConstants.ESB_REGISTER_MDT_URL;
	        mdtURL += "?municipalityIdList=" + municipalityIdList;	    
	        Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : registerMDTObligations() -> mdtURL: " + mdtURL);
	        try {	        	
	            URL url = new URL(mdtURL);
	            conn = (HttpsURLConnection) url.openConnection();
	            conn.setRequestMethod("POST");
	            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
	            conn.setRequestProperty("Accept", "application/json");
	            conn.setRequestProperty( "charset", "utf-8");
	            conn.setConnectTimeout(120000); //set timeout to 2 mins
		        conn.setReadTimeout(120000); //set timeout to 2 mins
	            conn.setUseCaches( false );
	            conn.setDoOutput(true);
	            conn.setRequestProperty("Authorization","Bearer " + token.getAccessToken());	            
	            if (conn.getResponseCode() != 200) {		            	
	            	throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode() + ", msg:" + conn.getResponseMessage());
	            }
	            reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
	            String output = null;
	            while ((output = reader.readLine()) != null) {
	                strBuf.append(output);
	            }
	        } catch (IOException e) {	
	        	throw e;
	        } finally {
	            if (reader != null) {
	                try {
	                    reader.close();
	                } catch (IOException e) {
	                    e.printStackTrace();
	                }
	            }
	            if (conn != null) {
	                conn.disconnect();
	            }
	        }
	        String result = strBuf.toString();
	        if (result != null && result.trim().length() > 0) {	        	
	        	Logger.log(Logger.DEBUG_LEVEL, "MySpaceESBTokenManager : registerMDTObligations() -> result: " + result);
	        	JSONArray ja = new JSONArray(result); 
	        	ESBMDTResponseBean response = new ESBMDTResponseBean();
//	        	
//	        	For now we do not care about the reponse!
//	    		if (ja.length() > 0) {
//	    			JSONObject jMdt = null;
//	    			JSONArray jResultArr = null;
//    				JSONObject jResult = null;
//    				List<ESBMDTBean> mdts = new ArrayList<ESBMDTBean>();
//    				List<String> failed = new ArrayList<String>();
//    				String municipalityStatus = null;
//    				ESBMDTBean mdt = null;
//    				for (int i = 0; i < ja.length(); i++) {					
//    					jMdt = ja.getJSONObject(i);
//    					
//    					if (jMdt.has("municipality") && jMdt.has("municipalityStatus")) {
//    						if (jMdt.has("result")) {
//	    						jResultArr = jMdt.getJSONArray("result");
//	    						if (jResultArr != null && jResultArr.length() > 0) {
//	    							for (int j = 0; j < jResultArr.length(); j++) {
//	    								mdt = new ESBMDTBean();
//	    	    						mdt.setMunicipality(jMdt.getString("municipality"));
//	    	    						mdt.setMunicipalityId(jMdt.get("municipalityId").toString());
//	    	    						mdt.setMunicipalityStatus(jMdt.getString("municipalityStatus"));
//	    								jResult = jResultArr.getJSONObject(j);
//	    								if (jResult.has("reason") && !jResult.isNull("reason")) {
//	    									mdt.setReason(jResult.getString("reason"));
//	    								}
//	    								if (jResult.has("partida") && !jResult.isNull("partida")) {
//	    									mdt.setPartida(jResult.getString("partida"));
//	    								}
//	    								if (jResult.has("period") && !jResult.isNull("period")) {
//	    									mdt.setPeriod(jResult.getString("period"));
//	    								}
//	    								if (jResult.has("installment") && !jResult.isNull("installment")) {
//	    									mdt.setInstallment(String.valueOf(jResult.getInt("installment"))); 
//	    								}
//	    								if (jResult.has("amount") && !jResult.isNull("amount")) {
//	    									mdt.setAmount(jResult.getString("amount"));
//	    								}
//	    								if (jResult.has("paymentStatus") && !jResult.isNull("paymentStatus")) {
//	    									mdt.setPaymentStatus(jResult.getString("paymentStatus"));
//	    								}
//	    								if (MySpaceConstants.ESB_MDT_MUNICIPALITY_STATUS_OBLIGATIONS.equals(mdt.getMunicipalityStatus())) {
//	    									mdts.add(mdt);
//	    								} else if (!(MySpaceConstants.ESB_MDT_MUNICIPALITY_STATUS_MISSING_DEPT.equals(mdt.getMunicipalityStatus()) 
//	    										|| MySpaceConstants.ESB_MDT_MUNICIPALITY_STATUS_MISSING_OBJECT.equals(mdt.getMunicipalityStatus()))) {
//	    									failed.add(mdt.getMunicipality());
//	    								}
//	    							}
//	    						}   
//    						} else {
//    							municipalityStatus = jMdt.getString("municipalityStatus");
//    							if (!(MySpaceConstants.ESB_MDT_MUNICIPALITY_STATUS_MISSING_DEPT.equals(municipalityStatus) 
//										|| MySpaceConstants.ESB_MDT_MUNICIPALITY_STATUS_MISSING_OBJECT.equals(municipalityStatus))) {
//    								failed.add(jMdt.getString("municipality"));
//    							}
//    						}
//    					}
//    				}
//    				response.setMdts(mdts);
//    				response.setFailed(failed);
//	    		}	        	
	        	return response;
	        }
		}		
		return null;
	}

	
	public static void main(String[] args) {
		String orn = "{\n"
				+ "    \"orn\": \"BGES111AQG2\"\n"
				+ "}";
		
		
		String mdt = "[\n"
				+ "    {\n"
				+ "        \"municipality\": \"СТОЛИЧНА\",\n"
				+ "        \"municipalityStatus\": \"OBLIGATIONS\",\n"
				+ "        \"result\": [\n"
				+ "            {\n"
				+ "                \"reason\": \"глоби\",\n"
				+ "                \"partida\": \"725200058408\",\n"
				+ "                \"period\": \"2021\",\n"
				+ "                \"installment\": 0,\n"
				+ "                \"amount\": \"20.00\",\n"
				+ "                \"paymentStatus\": \"PENDING\"\n"
				+ "            }\n"
				+ "        ]\n"
				+ "    },{\n"
				+ "        \"municipality\": \"СТОЛИЧНА2\",\n"
				+ "        \"municipalityStatus\": \"OBLIGATIONS\",\n"
				+ "        \"result\": [\n"
				+ "            {\n"
				+ "                \"reason\": \"глоби2\",\n"
				+ "                \"partida\": \"725200058408\",\n"
				+ "                \"period\": \"2022\",\n"
				+ "                \"installment\": 1,\n"
				+ "                \"amount\": \"40.00\",\n"
				+ "                \"paymentStatus\": \"PENDING\"\n"
				+ "            }\n"
				+ "        ]\n"
				+ "    }]";
		
		JSONArray ja2 = new JSONArray(mdt);		
		if (ja2 != null && ja2.length() > 0) {
			System.out.println("ok");
			JSONObject jMdt = null;			
			JSONArray jaRes = null;
			JSONObject jRes = null;
			for (int i = 0; i < ja2.length(); i++) {					
				jMdt = ja2.getJSONObject(i);
				System.out.println(jMdt.getString("municipality"));
				System.out.println(jMdt.getString("municipalityStatus"));
				jaRes = jMdt.getJSONArray("result");
				if (jaRes != null && jaRes.length() > 0) {
					for (int j = 0; j < jaRes.length(); j++) {
						jRes = jaRes.getJSONObject(j);
						System.out.println(jRes.getString("amount"));
					}
				}
						
			}
			return;
		}
		
		
		JSONObject jo = new JSONObject(orn); 
		System.out.println(jo.get("orn").toString());
		
		String eDelivery = "{\n"
				+ "    \"messages\": [\n"
				+ "        {\n"
				+ "            \"messageId\": 5762,\n"
				+ "            \"subject\": \"Система за електронно връчване\",\n"
				+ "            \"dateSent\": \"2021-01-08T16:02:20.777+02:00\",\n"
				+ "            \"senderProfileName\": \"еПлащане\",\n"
				+ "            \"senderLoginName\": \"еПлащане\",\n"
				+ "            \"recipientProfileName\": \"Мирослав Христов Долапчиев\",\n"
				+ "            \"url\": \"https://edelivery-test-v2.egov.bg/Messages/Open/5762\"\n"
				+ "        },\n"
				+ "        {\n"
				+ "            \"messageId\": 1890,\n"
				+ "            \"subject\": \"Test Document\",\n"
				+ "            \"dateSent\": \"2020-05-19T17:58:27.533+03:00\",\n"
				+ "            \"senderProfileName\": \"ТЕСТОВИ ПРОФИЛ - Ай Би Ес - БЪЛГАРИЯ ЕООД\",\n"
				+ "            \"senderLoginName\": \"ТЕСТОВИ ПРОФИЛ - Ай Би Ес - БЪЛГАРИЯ ЕООД\",\n"
				+ "            \"recipientProfileName\": \"Мирослав Христов Долапчиев\",\n"
				+ "            \"url\": \"https://edelivery-test-v2.egov.bg/Messages/Open/1890\"\n"
				+ "        },\n"
				+ "        {\n"
				+ "            \"messageId\": 1889,\n"
				+ "            \"subject\": \"Test Document\",\n"
				+ "            \"dateSent\": \"2020-05-19T17:58:17.693+03:00\",\n"
				+ "            \"senderProfileName\": \"ТЕСТОВИ ПРОФИЛ - Ай Би Ес - БЪЛГАРИЯ ЕООД\",\n"
				+ "            \"senderLoginName\": \"ТЕСТОВИ ПРОФИЛ - Ай Би Ес - БЪЛГАРИЯ ЕООД\",\n"
				+ "            \"recipientProfileName\": \"Мирослав Христов Долапчиев\",\n"
				+ "            \"url\": \"https://edelivery-test-v2.egov.bg/Messages/Open/1889\"\n"
				+ "        },\n"
				+ "        {\n"
				+ "            \"messageId\": 1891,\n"
				+ "            \"subject\": \"Test Document\",\n"
				+ "            \"dateSent\": \"2020-05-19T17:58:48.903+03:00\",\n"
				+ "            \"dateReceived\": \"2020-05-19T17:58:56.763+03:00\",\n"
				+ "            \"senderProfileName\": \"ТЕСТОВИ ПРОФИЛ - Ай Би Ес - БЪЛГАРИЯ ЕООД\",\n"
				+ "            \"senderLoginName\": \"ТЕСТОВИ ПРОФИЛ - Ай Би Ес - БЪЛГАРИЯ ЕООД\",\n"
				+ "            \"recipientProfileName\": \"Мирослав Христов Долапчиев\",\n"
				+ "            \"recipientLoginName\": \"Мирослав Христов Долапчиев\",\n"
				+ "            \"url\": \"https://edelivery-test-v2.egov.bg/Messages/Open/1891\"\n"
				+ "        }\n"
				+ "    ],\n"
				+ "    \"messageType\": \"RECEIVED\",\n"
				+ "    \"count\": 5\n"
				+ "}";
		jo = new JSONObject(eDelivery);
		if (jo.has("messages")) {
			JSONArray ja = jo.getJSONArray("messages");
			if (ja.length() > 0) {
				JSONObject jMessage = null;
				List<ESBEDeliveryBean> eDeliveries = new ArrayList<ESBEDeliveryBean>();
				ESBEDeliveryBean message = null;
				for (int i = 0; i < ja.length(); i++) {					
					jMessage = ja.getJSONObject(i);					
					message = new ESBEDeliveryBean();
					message.setMessageId(jMessage.getLong("messageId"));
					message.setSubject(jMessage.getString("subject"));
					if (jMessage.has("dateSent")) {
						message.setDateSent(jMessage.getString("dateSent"));
					}
					if (jMessage.has("dateReceived")) {
						message.setDateReceived(jMessage.getString("dateReceived"));						
					}
					message.setSenderProfileName(jMessage.getString("senderProfileName"));
					message.setSenderLoginName(jMessage.getString("senderLoginName"));
					message.setRecipientProfileName(jMessage.getString("recipientProfileName"));
					if (jMessage.has("recipientLoginName")) {
						message.setRecipientLoginName(jMessage.getString("recipientLoginName"));
					}
					message.setUrl(jMessage.getString("url"));
					message.setMessageType(jMessage.getString("messageType"));
					eDeliveries.add(message);
				}
			}
		}		
	}
}
