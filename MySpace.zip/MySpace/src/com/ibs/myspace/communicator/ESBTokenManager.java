package com.ibs.myspace.communicator;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.cert.X509Certificate;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManager;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.json.JSONArray;
import org.json.JSONObject;

import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.bean.ESBEDeliveryBean;
import com.ibs.myspace.portlet.bean.ESBEDeliveryResponseBean;
import com.ibs.myspace.portlet.bean.ESBTokenBean;
import com.ibs.myspace.portlet.db.Base;
import com.ibs.myspace.portlet.utils.Logger;

public class ESBTokenManager {
	
	
}
