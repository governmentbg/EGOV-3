package com.ibs.myspace.communicator;

import java.util.Hashtable;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.DirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;
import javax.naming.ldap.InitialLdapContext;
import javax.naming.ldap.LdapContext;

import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.db.Base;
import com.ibs.myspace.portlet.utils.Logger;


public class LDAPCommunicator {
    Hashtable<String, String> env = new Hashtable<>();

    private SearchControls getSimpleSearchControls() {
        SearchControls searchControls = new SearchControls();
        searchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);
        searchControls.setTimeLimit(30000);
        //String[] attrIDs = {"objectGUID"};
        //searchControls.setReturningAttributes(attrIDs);
        return searchControls;
    }

    public String getInvitationId(String uid) {
    	Logger.log(Logger.DEBUG_LEVEL, "LDAPCommunicator:getInvitationId(" + uid + ") started...");
    	String invitationId = null;
    	Properties env = new Properties();

        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, Base.TEST_ENVIRONMENT ? MySpaceConstants.LDAP_TEST_ADDRESS : MySpaceConstants.LDAP_PROD_ADDRESS);
        env.put(Context.SECURITY_PRINCIPAL, "uid=wpbind,cn=users,o=egov");
        try {
        	env.put(Context.SECURITY_CREDENTIALS, "b1ndIbs");
		} catch (Exception e) {
			e.printStackTrace();
		}
        
        try {
            LdapContext ctx = new InitialLdapContext(env, null);
            ctx.setRequestControls(null);
            NamingEnumeration<?> namingEnum = ctx.search("o=egov", "(uid=" + uid + ")", this.getSimpleSearchControls());
            SearchResult result = null;
            Attributes attrs = null;
            while (namingEnum.hasMore ()) {
                result = (SearchResult) namingEnum.next ();    
                attrs = result.getAttributes (); 
                if (attrs.get(MySpaceConstants.LDAP_ATTRIBUTE_INVITATION_ID) != null) {
                	invitationId = (String)attrs.get(MySpaceConstants.LDAP_ATTRIBUTE_INVITATION_ID).get();
                }                
                break;
            } 
            namingEnum.close();
        } catch (Exception e) {
            e.printStackTrace();            
        }
        Logger.log(Logger.DEBUG_LEVEL, "LDAPCommunicator:getInvitationId() -> invitationId [" + invitationId + "]");        
        return invitationId;
	}
    
    public void removeInvitationId(String uid) {
    	Logger.log(Logger.DEBUG_LEVEL, "LDAPCommunicator:removeInvitationId(" + uid + ") started...");
    	Properties env = new Properties();

        env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
        env.put(Context.PROVIDER_URL, Base.TEST_ENVIRONMENT ? MySpaceConstants.LDAP_TEST_ADDRESS : MySpaceConstants.LDAP_PROD_ADDRESS);
        env.put(Context.SECURITY_PRINCIPAL, "uid=wpbind,cn=users,o=egov");
        try {
        	env.put(Context.SECURITY_CREDENTIALS, "b1ndIbs");
		} catch (Exception e) {
			e.printStackTrace();
		}
        
        try {
            LdapContext ctx = new InitialLdapContext(env, null);
            ctx.setRequestControls(null);
            NamingEnumeration<?> namingEnum = ctx.search("o=egov", "(uid=" + uid + ")", this.getSimpleSearchControls());
            SearchResult result = null;
            Attributes attrs = null;
            // Specify the changes to make
            ModificationItem[] mods = new ModificationItem[1];
            while (namingEnum.hasMore ()) {
                result = (SearchResult) namingEnum.next ();    
                attrs = result.getAttributes (); 
                if (attrs.get(MySpaceConstants.LDAP_ATTRIBUTE_INVITATION_ID) != null) {                	
                	mods[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute(MySpaceConstants.LDAP_ATTRIBUTE_INVITATION_ID, ""));
                	Logger.log(Logger.DEBUG_LEVEL, "LDAPCommunicator:removeInvitationId() -> founded, going to remove...");
                	// Perform the requested modifications on the named object
                	ctx.modifyAttributes("uid=" + attrs.get(MySpaceConstants.LDAP_ATTRIBUTE_UID).get().toString() + ",cn=users,o=egov", mods);
                }                
                break;
            } 
            namingEnum.close();
        } catch (Exception e) {
            e.printStackTrace();            
        }
        Logger.log(Logger.DEBUG_LEVEL, "LDAPCommunicator:removeInvitationId() -> end!");        
	}
    
    public static void main(String[] args) {
    	Base.TEST_ENVIRONMENT = true;
		LDAPCommunicator communicator = new LDAPCommunicator();		
		communicator.removeInvitationId("f6be55435b1ca589c915e6465d1b15da16");
	}
}