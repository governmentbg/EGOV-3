package com.ibs.myspace.communicator;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.cert.X509Certificate;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.json.JSONObject;

import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.MySpacePortlet;
import com.ibs.myspace.portlet.MySpacePortletSessionBean;
import com.ibs.myspace.portlet.bean.ESBEDeliveryResponseBean;
import com.ibs.myspace.portlet.bean.ESBEPaymentResponseBean;
import com.ibs.myspace.portlet.bean.ESBMDTResponseBean;
import com.ibs.myspace.portlet.bean.ESBTokenBean;
import com.ibs.myspace.portlet.bean.UserProfileBean;
import com.ibs.myspace.portlet.dbo.UserProfile;
import com.ibs.myspace.portlet.utils.EncryptorAESGCM;
import com.ibs.myspace.portlet.utils.Logger;
import com.ibs.myspace.portlet.utils.MySpaceUtils;

public class ESBCommunicator {
	@SuppressWarnings("unused")
	private MySpaceUtils utils = null;
	private ESBTokenManager tokenManager = null;
	
	public ESBCommunicator() {
		utils = new MySpaceUtils();
		tokenManager = new ESBTokenManager();
	}
	
	@Deprecated
	public ESBTokenBean getORNToken(MySpacePortletSessionBean sessionBean, String personalIdentifier) {
		return this.getToken(sessionBean, MySpaceConstants.ESB_TOKEN_SCOPE_ORN, personalIdentifier);
	}
	
	public ESBTokenBean getEDeliveryToken(MySpacePortletSessionBean sessionBean, String personalIdentifier) {
		return this.getToken(sessionBean, MySpaceConstants.ESB_TOKEN_SCOPE_E_DELIVERY, personalIdentifier);
	}
	
	public ESBTokenBean getEPaymentToken(MySpacePortletSessionBean sessionBean, String personalIdentifier) {
		return this.getToken(sessionBean, MySpaceConstants.ESB_TOKEN_SCOPE_E_PAYMENT, personalIdentifier);
	}
	
	public ESBTokenBean getMDTToken(MySpacePortletSessionBean sessionBean, String personalIdentifier) {
		return this.getToken(sessionBean, MySpaceConstants.ESB_TOKEN_SCOPE_MDT, personalIdentifier);
	}
	
	public ESBTokenBean getToken(MySpacePortletSessionBean sessionBean, String scope, String personalIdentifier) {
		List<ESBTokenBean> tokens = sessionBean.getESBTokens();
		Logger.log(Logger.DEBUG_LEVEL, "ESBCommunicator : getToken(" + scope + ")");
		if (tokens == null) {
			tokens = new ArrayList<ESBTokenBean>();
		}
		ESBTokenBean token = null;
		if (tokens.size() > 0) {
			boolean tokenIsExpired = false;
			for (int i = 0; i < tokens.size(); i++) {
				token = tokens.get(i);
				if (token.getScope().equalsIgnoreCase(scope)) {
					// Check if it is expired.
					Instant instant = Instant.now(); 
			    	long currentTimeInSeconds = instant.getEpochSecond();
			    	// Decrease 5 mins, because of the server out of sync variations.
			    	currentTimeInSeconds -= 600;
			    	if (token.getConsentedOn() + token.getExpiresIn() < currentTimeInSeconds) {
			    		tokenIsExpired = true;
			    		break;
			    	}
			    	Logger.log(Logger.DEBUG_LEVEL, "ESBCommunicator : found valid token for " + scope);
					return token;
				}
			}
			if (tokenIsExpired) {
				Logger.log(Logger.DEBUG_LEVEL, "ESBCommunicator : remove expired token for " + scope);
				tokens.remove(token);
			}
		}	
		try {
			token = this.tokenManager.callForToken(scope, personalIdentifier);
			if (token != null) {
				tokens.add(token);
			}
			return token;	
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	// This function calls the ESB to get the ORN.
	@Deprecated
	public String getORN(MySpacePortletSessionBean sessionBean, String personalIdentifier) throws Exception {
		ESBTokenBean token = this.getORNToken(sessionBean, personalIdentifier);
		return this.tokenManager.getORN(token, personalIdentifier);  
	}
	
	public ESBEPaymentResponseBean getEPayment(MySpacePortletSessionBean sessionBean, String personalIdentifier, String status, String profileID, int pageNumber, int pageSize) throws Exception {
		ESBTokenBean token = this.getEPaymentToken(sessionBean, personalIdentifier);
		if (token == null) {
			throw new Exception("Възникна комуникационна грешка");
		}
		return this.tokenManager.getEPayment(token, personalIdentifier, status, profileID, pageNumber, pageSize);
	}
	
	public ESBEDeliveryResponseBean getEDelivery(MySpacePortletSessionBean sessionBean, String personalIdentifier, String direction, String profileID, int pageNumber, int pageSize) throws Exception {
		ESBTokenBean token = this.getEDeliveryToken(sessionBean, personalIdentifier);
		if (token == null) {
			throw new Exception("Възникна комуникационна грешка");
		}
		return this.tokenManager.getEDelivery(token, personalIdentifier, direction, profileID, pageNumber, pageSize);
	}
	
	public ESBMDTResponseBean getMDT(MySpacePortletSessionBean sessionBean, String personalIdentifier) throws Exception {
		ESBTokenBean token = this.getMDTToken(sessionBean, personalIdentifier);
		if (token == null) {
			throw new Exception("Възникна комуникационна грешка");
		}
		return this.tokenManager.getMDT(token, personalIdentifier);
	}
	
	public ESBMDTResponseBean registerMDTObligations(MySpacePortletSessionBean sessionBean, String personalIdentifier, String municipalityIdList) throws Exception {
		ESBTokenBean token = this.getMDTToken(sessionBean, personalIdentifier);
		if (token == null) {
			throw new Exception("Възникна комуникационна грешка");
		}
		return this.tokenManager.registerMDTObligations(token, personalIdentifier, municipalityIdList);
	}
	
	public int getUnReadReceivedMessagesCounter(MySpacePortletSessionBean sessionBean) {
		ESBEDeliveryResponseBean responseReceived = null;
		EncryptorAESGCM aesCls = new EncryptorAESGCM();
		String profileID = null;
		UserProfile profile = sessionBean.getProfile();
		UserProfileBean userProfileBean = sessionBean.getUserProfile();
		if (!MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(profile.getProfileType())) {
			profileID = profile.getEik();
		}
		String personalIdentifier = userProfileBean.getCurrentUserIdentifier() != null ? aesCls.decryptEgovIdentifier(userProfileBean.getCurrentUserIdentifier()) : null;
		try {		
										
				responseReceived = this.getEDelivery(sessionBean, personalIdentifier, MySpaceConstants.ESB_E_DELIVERY_DIRECTION_RECEIVED, profileID, 1, 10);	
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		int unReadMessagesCount = 0;
		if (responseReceived != null && responseReceived.getMessages() != null 
				&& responseReceived.getMessages().size() > 0) {
			for (int i = 0; i < responseReceived.getMessages().size(); i++) {
				if (responseReceived.getMessages().get(i).getDateReceived() == null) {
					unReadMessagesCount++;
				}
			}
		}
		return unReadMessagesCount;
	}
	
	@SuppressWarnings("unused")
	private void invalidateToken(MySpacePortletSessionBean sessionBean, String scope) {
		Logger.log(Logger.DEBUG_LEVEL, "ESBCommunicator : invalidateToken(" + scope + ")");
		List<ESBTokenBean> tokens = sessionBean.getESBTokens();
		if (tokens.size() > 0) {
			ESBTokenBean token = null;
			boolean founded = false;
			for (int i = 0; i < tokens.size(); i++) {
				token = tokens.get(i);
				if (token.getScope().equalsIgnoreCase(scope)) {
					founded = true;
		    		break;
				}
			}
			if (founded) {
				Logger.log(Logger.DEBUG_LEVEL, "ESBCommunicator : invalidateToken(" + scope + "): Founded.");
				tokens.remove(token);
				Logger.log(Logger.DEBUG_LEVEL, "ESBCommunicator : invalidateToken(" + scope + "): tokens.size=" + tokens.size());
			}
		}	
	}
	
	// This function calls the ORN server.
	@Deprecated
	public String getORNDirect() {
		Logger.log(Logger.DEBUG_LEVEL, "ESBCommunicator -> getORN() start...");
		BufferedReader reader = null;
		HttpURLConnection conn = null;
		try {			
			StringBuilder strBuf = new StringBuilder();
			String typeService = URLEncoder.encode("Овластяване", StandardCharsets.UTF_8.toString()); 				
			String params = "?bulstat=_REPLACED_&type_service=" + typeService + "&uri_service=e-document";
			Logger.log(Logger.DEBUG_LEVEL, "ESBCommunicator -> getORN() url:" + MySpacePortlet.ornAddress + params);
			URL url = new URL(MySpacePortlet.ornAddress + params);
			conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setConnectTimeout(15000); //set timeout to 15 seconds
			conn.setReadTimeout(15000); //set timeout to 15 seconds			
			
			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode());
			}
			
			reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
			String output = null;
			while ((output = reader.readLine()) != null) {
				strBuf.append(output);
			}
			//"{\"return_code\":\"200\",\"description_code\":\"OK\",\"orn\":\"BGES1119MG2\"}";
			if (strBuf.toString().trim().length() > 0) {
				JSONObject jsonObject = new JSONObject(strBuf.toString().trim());
				if (jsonObject.has("return_code")) {
					if (200 == jsonObject.getInt("return_code")) {
						return jsonObject.getString("orn");				
					} else {
						Logger.log(Logger.ERROR_LEVEL, "ESBCommunicator -> getORN() return_code [" + jsonObject.getInt("return_code") + "]");
					}
				} else {
					Logger.log(Logger.ERROR_LEVEL, "ESBCommunicator -> getORN() no 'return_code' founded in the response.");
				}
			} else {
				Logger.log(Logger.ERROR_LEVEL, "ESBCommunicator -> getORN() no response.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				conn.disconnect();
			}
		}
		return null;
		// Custom generation of ORN.
		//long currentTime = new Date().getTime();
		//return currentTime + "" + utils.randomLong();
	}
	
	@Deprecated
	public void testOrnServiceDirect() {
		try {			
			URL url = new URL("_REPLACED_");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");
			conn.setConnectTimeout(15000); //set timeout to 15 seconds
			conn.setReadTimeout(15000); //set timeout to 15 seconds

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
				(conn.getInputStream())));

			String output;
			System.out.println("Output from Server .... \n");
			while ((output = br.readLine()) != null) {
				System.out.println(output);
			}
			conn.disconnect();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public String eDeliveryPersonHasRegistration(String personalIdentifier) {
		Logger.log(Logger.ERROR_LEVEL, "eDeliveryPersonHasRegistration(" + personalIdentifier + ")");
		StringBuilder strBuf = new StringBuilder();
		
		HttpsURLConnection conn = null;
		BufferedReader reader = null;
		
		try {
			
			// Create a trust manager that does not validate certificate chains
			TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {return null;}
				public void checkClientTrusted(X509Certificate[] certs, String authType) {}
				public void checkServerTrusted(X509Certificate[] certs, String authType) {}
			}
			};
			
			// Install the all-trusting trust manager
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
			
			// Create all-trusting host name verifier
			HostnameVerifier allHostsValid = new HostnameVerifier() {
				public boolean verify(String hostname, SSLSession session) {
					return true;
				}
			};
			// Install the all-trusting host verifier
			HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
			
			URL url = new URL(MySpacePortlet.esbEDeliveryAddress + "/checkPersonHasRegistration");
			conn = (HttpsURLConnection) url.openConnection();
			byte[] out = ("{\"personIdentificator\":\"" + personalIdentifier + "\"}").getBytes(StandardCharsets.UTF_8);
			int length = out.length;
			
			conn.setFixedLengthStreamingMode(length);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json; utf-8");
			conn.setRequestProperty("Accept", "application/json");
			conn.setConnectTimeout(15000); //set timeout to 15 seconds
			conn.setReadTimeout(15000); //set timeout to 15 seconds
			conn.setDoOutput(true);
			
			try(OutputStream os = conn.getOutputStream()) {
				os.write(out);
			}
			
			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("HTTP POST Request Failed with Error code : " + conn.getResponseCode());
			}
			
			reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
			String output = null;
			while ((output = reader.readLine()) != null) {
				strBuf.append(output);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				conn.disconnect();
			}
		}
		
		return strBuf.toString();
	}
	
	public String eDeliverySubjectHasRegistration(String personalIdentifier) {
		Logger.log(Logger.ERROR_LEVEL, "eDeliverySubjectHasRegistration(" + personalIdentifier + ")");
		StringBuilder strBuf = new StringBuilder();
		
		HttpsURLConnection conn = null;
	    BufferedReader reader = null;
						
        try {

        	// Create a trust manager that does not validate certificate chains
            TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {return null;}
                public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                public void checkServerTrusted(X509Certificate[] certs, String authType) {}
            }
            };

        	// Install the all-trusting trust manager
	        SSLContext sc = SSLContext.getInstance("SSL");
	        sc.init(null, trustAllCerts, new java.security.SecureRandom());
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

	        // Create all-trusting host name verifier
	        HostnameVerifier allHostsValid = new HostnameVerifier() {
	            public boolean verify(String hostname, SSLSession session) {
	                return true;
	            }
	        };
	        // Install the all-trusting host verifier
	        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
			
	        URL url = new URL(MySpacePortlet.esbEDeliveryAddress + "/check/subjectRegistration");
            conn = (HttpsURLConnection) url.openConnection();
            byte[] out = ("{\"personIdentificator\":\"" + personalIdentifier + "\"}").getBytes(StandardCharsets.UTF_8);
            int length = out.length;

            conn.setFixedLengthStreamingMode(length);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; utf-8");
            conn.setRequestProperty("Accept", "application/json");
            conn.setConnectTimeout(15000); //set timeout to 15 seconds
	        conn.setReadTimeout(15000); //set timeout to 15 seconds
            conn.setDoOutput(true);

            try(OutputStream os = conn.getOutputStream()) {
                os.write(out);
            }

            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("HTTP POST Request Failed with Error code : " + conn.getResponseCode());
            }
            
            reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
            String output = null;
            while ((output = reader.readLine()) != null) {
                strBuf.append(output);
            }
	        
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
        
        return strBuf.toString();
	}
	
	public String regixGetMaritalStatusSpouseChildren(String egn) {
		Logger.log(Logger.ERROR_LEVEL, "regixGetMaritalStatusSpouseChildren(" + egn + ")");
		StringBuilder strBuf = new StringBuilder();
		
		HttpsURLConnection conn = null;
		BufferedReader reader = null;
		
		try {
			
			// Create a trust manager that does not validate certificate chains
			TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
				public java.security.cert.X509Certificate[] getAcceptedIssuers() {return null;}
				public void checkClientTrusted(X509Certificate[] certs, String authType) {}
				public void checkServerTrusted(X509Certificate[] certs, String authType) {}
			}
			};
			
			// Install the all-trusting trust manager
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCerts, new java.security.SecureRandom());
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
			
			// Create all-trusting host name verifier
			HostnameVerifier allHostsValid = new HostnameVerifier() {
				public boolean verify(String hostname, SSLSession session) {
					return true;
				}
			};
			// Install the all-trusting host verifier
			HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
			
			URL url = new URL(MySpacePortlet.esbRegixAddress + "/maritalStatusSpouseChildren");
			conn = (HttpsURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Content-Type", "application/json; utf-8");
			conn.setRequestProperty("Accept", "application/json");
			conn.setRequestProperty("egn", egn);
			conn.setConnectTimeout(15000); //set timeout to 15 seconds
			conn.setReadTimeout(15000); //set timeout to 15 seconds
			conn.setDoOutput(true);
			
			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode());
			}
			
			reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
			String output = null;
			while ((output = reader.readLine()) != null) {
				strBuf.append(output);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				conn.disconnect();
			}
		}
		return strBuf.toString();
	}
	
	public String regixGetEIK(String eik) {
		Logger.log(Logger.ERROR_LEVEL, "regixGetEIK(" + eik + ")");
		StringBuilder strBuf = new StringBuilder();
		
		HttpsURLConnection conn = null;
	    BufferedReader reader = null;
						
        try {

        	// Create a trust manager that does not validate certificate chains
            TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
                public java.security.cert.X509Certificate[] getAcceptedIssuers() {return null;}
                public void checkClientTrusted(X509Certificate[] certs, String authType) {}
                public void checkServerTrusted(X509Certificate[] certs, String authType) {}
            }
            };

        	// Install the all-trusting trust manager
	        SSLContext sc = SSLContext.getInstance("SSL");
	        sc.init(null, trustAllCerts, new java.security.SecureRandom());
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

	        // Create all-trusting host name verifier
	        HostnameVerifier allHostsValid = new HostnameVerifier() {
	            public boolean verify(String hostname, SSLSession session) {
	                return true;
	            }
	        };
	        // Install the all-trusting host verifier
	        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
			
	        URL url = new URL(MySpacePortlet.esbRegixAddress + "/eik");
            conn = (HttpsURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Content-Type", "application/json; utf-8");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("eik", eik);
            conn.setConnectTimeout(15000); //set timeout to 15 seconds
	        conn.setReadTimeout(15000); //set timeout to 15 seconds
            conn.setDoOutput(true);

            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode());
            }
            
            reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
            String output = null;
            while ((output = reader.readLine()) != null) {
                strBuf.append(output);
            }
	        
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
        
        return strBuf.toString();
	}
	
}