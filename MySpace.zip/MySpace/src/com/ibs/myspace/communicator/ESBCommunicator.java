package com.ibs.myspace.communicator;


public class ESBCommunicator {
	
}