package com.ibs.myspace.communicator;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.UUID;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.json.JSONObject;
import org.json.XML;

import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.MySpacePortlet;
import com.ibs.myspace.portlet.bean.StateOfPlayResponse;
import com.ibs.myspace.portlet.bean.ValidPersonResponse;
import com.ibs.myspace.portlet.bean.ValidUICResponse;
import com.ibs.myspace.portlet.db.Base;
import com.ibs.myspace.portlet.utils.Logger;

public class RegixCommunicator {
	
	public static final String UIC_STATUS_TYPE_NEW = "Нова партида";
	public static final String UIC_STATUS_TYPE_RE_REGISTERED = "Пререгистрирана партида";
	public static final String UIC_STATUS_TYPE_NEW_CLOSED = "Нова закрита партида";
	public static final String UIC_STATUS_TYPE_RE_REGISTERED_CLOSED = "Пререгистрирана закрита партида";
	
	/*
	 * Търговски регистър:
	 * 		Справка за Валидност на ЕИК номер	
	 * https://info-regix.egov.bg/public/administrations/AV/registries/operations/TechnoLogica.RegiX.AVTRAdapter.APIService.ITRAPI/GetValidUICInfo
	 */
	public ValidUICResponse GetValidUICInfo(String uic) throws Exception {
		String contextPath = "";
		try {
			contextPath = new RegixCommunicator().getClass().getResource("/certs").toURI().getPath();
		} catch (Exception e) {
			e.printStackTrace();
		}
		boolean isProd = Base.PRODUCTION_ENVIRONMENT;
		String password = isProd ? MySpaceConstants.REGIX_PROD_PASSWORD : MySpaceConstants.REGIX_STAGING_PASSWORD;
		String fileName = isProd ? MySpaceConstants.REGIX_PROD_JKS_FILENAME : MySpaceConstants.REGIX_STAGING_JKS_FILENAME;
		String keyStoreLoc = contextPath + (!contextPath.endsWith("/") ? "/" : "") + fileName;
		String response = null;
		StringBuilder strBuf = new StringBuilder();
		HttpsURLConnection conn = null;
	    BufferedReader reader = null;
	    String message = null;
		try {
			SSLSocketFactory sslSocketFacotry = createSocketFactory(new FileInputStream(keyStoreLoc), password.toCharArray());
			URL url = new URL(MySpaceConstants.REGIX_PROD_URL);	        
        	conn = (HttpsURLConnection) url.openConnection();
        	conn.setSSLSocketFactory(sslSocketFacotry);        	
        	String requestBody = getValidUICRequestBody(uic);
        	byte[] out = requestBody.getBytes(StandardCharsets.UTF_8);
        	int length = out.length;
        	conn.setFixedLengthStreamingMode(length);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/soap+xml; charset=utf-8;action=\"http://tempuri.org/IRegiXEntryPoint/ExecuteSynchronous\"");
            conn.setRequestProperty("Accept", "application/soap+xml, multipart/related");
            conn.setRequestProperty("User-Agent", "JAX-WS RI 2.3.2");
            conn.setConnectTimeout(20000); //set timeout to 20 seconds
	        conn.setReadTimeout(20000); //set timeout to 20 seconds
            conn.setDoOutput(true);

            try(OutputStream os = conn.getOutputStream()) {
                os.write(out);
            }
            
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode());
            }

            reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
            String output = null;
            while ((output = reader.readLine()) != null) {
                strBuf.append(output);
            }
            response = strBuf.toString();
            Logger.log(Logger.DEBUG_LEVEL, "GetValidUICInfo response:" + response);
            return populateValidUICReponse(response);
        } catch (IOException e) {
        	message = e.getMessage();
            e.printStackTrace();                        
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
		throw new Exception(message);
	}
	
	private SSLSocketFactory createSocketFactory(InputStream keyStoreStream, char[] keyStorePassword) {
        try {
            KeyStore keyStore = KeyStore.getInstance("JKS");
            keyStore.load(keyStoreStream, keyStorePassword);
            
            KeyManagerFactory kmFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            kmFactory.init(keyStore, keyStorePassword);
            
            Enumeration<String> aliases = keyStore.aliases();
            List<X509Certificate> trustedIssuers = new ArrayList<>();
            while (aliases.hasMoreElements()) {
                trustedIssuers.add((X509Certificate) keyStore.getCertificate(aliases.nextElement()));
            }
            X509Certificate[] acceptedIssuers = trustedIssuers.toArray(new X509Certificate[0]);
            
            TrustManager[] trustManagers = new TrustManager[] {
              new X509TrustManager() {
                @Override
                public void checkClientTrusted(X509Certificate[] certs, String authType) throws CertificateException {
                }
                
                @Override
                public void checkServerTrusted(X509Certificate[] certs, String authType) throws CertificateException {
                }
    
                @Override
                public X509Certificate[] getAcceptedIssuers() {
                    return acceptedIssuers;
                }
              }      
            };
            
            SSLContext sc = SSLContext.getInstance("TLSv1.2");
            sc.init(kmFactory.getKeyManagers(), trustManagers, new java.security.SecureRandom());
            return sc.getSocketFactory();
        } catch (Exception ex) {
            throw new IllegalStateException(ex);
        }
    }
	
	private String getValidUICRequestBody (String uic) {
		String uuid = UUID.randomUUID().toString();
    	String xml = "";
    	xml += "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:tem=\"http://tempuri.org/\">\n"
    			+ "   <soap:Header>\n"
    			+ "     <To xmlns=\"http://www.w3.org/2005/08/addressing\">https://regix-service.egov.bg/regix/RegiXEntryPoint.svc</To>\n"
    			+ "     <Action xmlns=\"http://www.w3.org/2005/08/addressing\">http://tempuri.org/IRegiXEntryPoint/ExecuteSynchronous</Action>\n"
    			+ "     <ReplyTo xmlns=\"http://www.w3.org/2005/08/addressing\">\n"
    			+ "       <Address>http://www.w3.org/2005/08/addressing/anonymous</Address>\n"
    			+ "     </ReplyTo>\n"
    			+ "     <FaultTo xmlns=\"http://www.w3.org/2005/08/addressing\">\n"
    			+ "       <Address>http://www.w3.org/2005/08/addressing/anonymous</Address>\n"
    			+ "     </FaultTo>\n"
    			+ "     <MessageID xmlns=\"http://www.w3.org/2005/08/addressing\">uuid:" + uuid + "</MessageID>\n"
    			+ "   </soap:Header>\n"
    			+ "   <soap:Body>\n"
    			+ "      <tem:ExecuteSynchronous xmlns=\"http://tempuri.org/\" xmlns:ns2=\"http://egov.bg/RegiX/GRAO/NBD\" xmlns:ns3=\"http://egov.bg/RegiX/GRAO/NBD/PersonDataRequest\" xmlns:ns4=\"http://egov.bg/RegiX/GRAO/PNA/PermanentAddressRequest\" xmlns:ns5=\"http://egov.bg/RegiX/AV/TR\" xmlns:ns6=\"http://egov.bg/RegiX/AV/TR/ValidUICRequest\" xmlns:ns7=\"http://www.w3.org/2000/09/xmldsig#\">\n"
    			+ "         <tem:request>\n"
    			+ "            <tem:Operation>TechnoLogica.RegiX.AVTRAdapter.APIService.ITRAPI.GetValidUICInfo</tem:Operation>\n"
    			+ "            <tem:Argument>\n"
    			+ "               <ns6:ValidUICRequest>\n"
    			+ "                 <ns6:UIC>" + uic + "</ns6:UIC>                \n"
    			+ "               </ns6:ValidUICRequest>\n"
    			+ "            </tem:Argument>           \n"
    			+ "            <tem:CallContext/>                                  \n"
    			+ "            <tem:SignResult>false</tem:SignResult>\n"
    			+ "            <tem:ReturnAccessMatrix>false</tem:ReturnAccessMatrix>\n"
    			+ "         </tem:request>\n"
    			+ "      </tem:ExecuteSynchronous>\n"
    			+ "   </soap:Body>\n"
    			+ "</soap:Envelope>";
    	return xml;
    }
	
	private ValidUICResponse populateValidUICReponse(String response) {
		if (response == null || response.trim().length() == 0) return null;
		ValidUICResponse validUICResponse = new ValidUICResponse();
		int pos = response.indexOf("<ValidUICResponse");
		int pos2 = -1;
		if (pos != -1) {
			response = response.substring(pos);
			pos = response.indexOf("</ValidUICResponse>");
			if (pos != -1) {
				response = response.substring(0, pos + "</ValidUICResponse>".length());
				if ("<ValidUICResponse xmlns=\"http://egov.bg/RegiX/AV/TR/ValidUICResponse\"><LegalForm/></ValidUICResponse>".equalsIgnoreCase(response)) {
					return null;
				}
				// Status				
				//"Нова партида"
				//"Пререгистрирана партида"
				//"Нова закрита партида"
				//"Пререгистрирана закрита партида"
				pos = response.indexOf("<Status>");
				pos2 = response.indexOf("</Status>");
				if (pos != -1 && pos2 != -1) {
					validUICResponse.setStatus(response.substring(pos + "<Status>".length(), pos2));
				}
				// UIC
				pos = response.indexOf("<UIC>");
				pos2 = response.indexOf("</UIC>");
				if (pos != -1 && pos2 != -1) {
					validUICResponse.setUic(response.substring(pos + "<UIC>".length(), pos2));
				}
				// Company
				pos = response.indexOf("<Company>");
				pos2 = response.indexOf("</Company>");
				if (pos != -1 && pos2 != -1) {
					validUICResponse.setCompany(response.substring(pos + "<Company>".length(), pos2));
				}
				// LegalFormAbbr
				pos = response.indexOf("<LegalFormAbbr xmlns=\"http://egov.bg/RegiX/AV/TR\">");
				pos2 = response.indexOf("</LegalFormAbbr>");
				if (pos != -1 && pos2 != -1) {
					validUICResponse.setLegalFormAbbr(response.substring(pos + "<LegalFormAbbr xmlns=\"http://egov.bg/RegiX/AV/TR\">".length(), pos2));
				}
				// LegalFormName
				pos = response.indexOf("<LegalFormName xmlns=\"http://egov.bg/RegiX/AV/TR\">");
				pos2 = response.indexOf("</LegalFormName>");
				if (pos != -1 && pos2 != -1) {
					validUICResponse.setLegalFormName(response.substring(pos + "<LegalFormName xmlns=\"http://egov.bg/RegiX/AV/TR\">".length(), pos2));
				}
				// DataValidForDate
				pos = response.indexOf("<DataValidForDate>");
				pos2 = response.indexOf("</DataValidForDate>");
				if (pos != -1 && pos2 != -1) {
					validUICResponse.setDataValidForDate(response.substring(pos + "<DataValidForDate>".length(), pos2));
				}
			}
		}
		return validUICResponse;
	}
	
	
	
	/** Response
	 * 
<s:Envelope xmlns:s="http://www.w3.org/2003/05/soap-envelope" xmlns:a="http://www.w3.org/2005/08/addressing">
   <s:Header>
      <a:Action s:mustUnderstand="1">http://tempuri.org/IRegiXEntryPoint/ExecuteSynchronousResponse</a:Action>
      <ActivityId CorrelationId="4aa680b3-68fd-4dad-a154-6b5cfacffd3e" xmlns="http://schemas.microsoft.com/2004/09/ServiceModel/Diagnostics">00000000-0000-0000-0000-000000000000</ActivityId>
      <a:RelatesTo>uuid:fa03be85-73c4-436a-9d29-6d08fa38b2c0</a:RelatesTo>
   </s:Header>
   <s:Body xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
      <ExecuteSynchronousResponse xmlns="http://tempuri.org/">
         <ExecuteSynchronousResult>
            <IsReady>true</IsReady>
            <Data id="data">
               <Request id="request">
                  <ValidUICRequest xmlns="http://egov.bg/RegiX/AV/TR/ValidUICRequest">
                     <UIC>201593301</UIC>
                  </ValidUICRequest>
               </Request>
               <Response id="response">
                  <ValidUICResponse xmlns="http://egov.bg/RegiX/AV/TR/ValidUICResponse">
                     <Status>Нова партида</Status>
                     <UIC>201593301</UIC>
                     <Company>ТехноЛогика</Company>
                     <LegalForm>
                        <LegalFormAbbr xmlns="http://egov.bg/RegiX/AV/TR">ЕАД</LegalFormAbbr>
                        <LegalFormName xmlns="http://egov.bg/RegiX/AV/TR">Еднолично акционерно дружество</LegalFormName>
                     </LegalForm>
                     <DataValidForDate>2021-07-26T13:30:20.2171057+03:00</DataValidForDate>
                  </ValidUICResponse>
               </Response>
               <Matrix xsi:nil="true"/>
            </Data>
            <HasError>false</HasError>
            <Error xsi:nil="true"/>
         </ExecuteSynchronousResult>
      </ExecuteSynchronousResponse>
   </s:Body>
</s:Envelope>
	 */
	
	public void printValidUICResponse(ValidUICResponse validUICResponse) {
		if (validUICResponse != null) {
			Logger.log(Logger.DEBUG_LEVEL, validUICResponse.toString());
		}
	}
	
	/*
	 * Регистър БУЛСТАТ:
	 * 		Справка по код на БУЛСТАТ или по фирмено дело за актуално състояние на субект на БУЛСТАТ	
	 * https://info-regix.egov.bg/public/administrations/AV/registries/operations/TechnoLogica.RegiX.AVBulstat2Adapter.APIService.IAVBulstat2API/GetStateOfPlay
	 */
	public StateOfPlayResponse getStateOfPlay(String uic) throws Exception {
		String contextPath = "";
		try {
			contextPath = new RegixCommunicator().getClass().getResource("/certs").toURI().getPath();
		} catch (Exception e) {
			e.printStackTrace();
		}
		String password = MySpaceConstants.REGIX_V2_PASSWORD;
		String fileName = MySpaceConstants.REGIX_V2_JKS_FILENAME;
		String keyStoreLoc = contextPath + (!contextPath.endsWith("/") ? "/" : "") + fileName;
		String response = null;
		StringBuilder strBuf = new StringBuilder();
		HttpsURLConnection conn = null;
	    BufferedReader reader = null;
	    String message = "Regix communication error";
		try {
			SSLSocketFactory sslSocketFacotry = createSocketFactory(new FileInputStream(keyStoreLoc), password.toCharArray());
			URL url = new URL(MySpaceConstants.REGIX_V2_PROD_URL);	        
        	conn = (HttpsURLConnection) url.openConnection();
        	conn.setSSLSocketFactory(sslSocketFacotry);        	
        	String requestBody = GetStateOfPlayRequestBody(uic);
        	byte[] out = requestBody.getBytes(StandardCharsets.UTF_8);
        	int length = out.length;
        	conn.setFixedLengthStreamingMode(length);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "text/xml;charset=UTF-8");
            conn.setRequestProperty("Accept", "text/xml");
            conn.setRequestProperty("User-Agent", "JAX-WS RI 2.3.2");
            conn.setRequestProperty("SOAPAction", "http://egov.bg/RegiX/IRegiXEntryPointV2/Execute");
            conn.setConnectTimeout(20000); //set timeout to 20 seconds
	        conn.setReadTimeout(20000); //set timeout to 20 seconds
            conn.setDoOutput(true);

            try(OutputStream os = conn.getOutputStream()) {
                os.write(out);
            }
            
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode());
            }

            reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
            String output = null;
            while ((output = reader.readLine()) != null) {
                strBuf.append(output);
            }
            response = strBuf.toString();
            Logger.log(Logger.DEBUG_LEVEL, "getStateOfPlay response:" + response);
            return populateStateOfPlayReponse(response);
        } catch (IOException e) {
        	message = e.getMessage();
            e.printStackTrace();                
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
		throw new Exception(message);
	}
	
	private String GetStateOfPlayRequestBody (String uic) {
		String uuid = UUID.randomUUID().toString();
		String xml = "";
		xml += "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:reg=\"http://egov.bg/RegiX\" xmlns:sig=\"http://egov.bg/RegiX/SignedData\">   \n"
				+ "   <soapenv:Header>\n"
				+ "    <To xmlns=\"http://www.w3.org/2005/08/addressing\">https://service-regix.egov.bg/regix/RegiXEntryPoint2.svc</To>\n"
				+ "    <Action xmlns=\"http://www.w3.org/2005/08/addressing\">http://egov.bg/RegiX/IRegiXEntryPointV2/Execute</Action>\n"
				+ "    <ReplyTo xmlns=\"http://www.w3.org/2005/08/addressing\">\n"
				+ "        <Address>http://www.w3.org/2005/08/addressing/anonymous</Address>\n"
				+ "    </ReplyTo>    \n"
				+ "    <FaultTo xmlns=\"http://www.w3.org/2005/08/addressing\">\n"
				+ "        <Address>http://www.w3.org/2005/08/addressing/anonymous</Address>\n"
				+ "    </FaultTo>   \n"
				+ "    <MessageID xmlns=\"http://www.w3.org/2005/08/addressing\">uuid:" + uuid + "</MessageID>\n"
				+ "   </soapenv:Header>     \n"
				+ "   <soapenv:Body>\n"
				+ "      <reg:Execute>\n"
				+ "         <reg:request>\n"
				+ "            <sig:ServiceRequestData>\n"
				+ "               <sig:RequestProcessing></sig:RequestProcessing>\n"
				+ "               <sig:ResponseProcessing></sig:ResponseProcessing>\n"
				+ "               <sig:Operation>TechnoLogica.RegiX.AVBulstat2Adapter.APIService.IAVBulstat2API.GetStateOfPlay</sig:Operation>\n"
				+ "               <sig:Argument>\n"
				+ "                  <GetStateOfPlayRequest xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns=\"http://www.bulstat.bg/GetStateOfPlayRequest\">\n"
				+ "                        <UIC>" + uic + "</UIC>\n"
				+ "                  </GetStateOfPlayRequest>\n"
				+ "               </sig:Argument>\n"
				+ "               <SignResult>false</SignResult>\n"
				+ "               <ReturnAccessMatrix>false</ReturnAccessMatrix>\n"
				+ "            </sig:ServiceRequestData>\n"
				+ "         </reg:request>\n"
				+ "      </reg:Execute>\n"
				+ "   </soapenv:Body>\n"
				+ "</soapenv:Envelope>";
		return xml;
    }
	
	private StateOfPlayResponse populateStateOfPlayReponse(String response) {
		if (response == null || response.trim().length() == 0) return null;
		StateOfPlayResponse stateOfPlayResponse = new StateOfPlayResponse();
		int pos = response.indexOf("<StateOfPlay");
		int pos2 = -1;
		if (pos != -1) {
			response = response.substring(pos);
			pos = response.indexOf("</StateOfPlay>");
			if (pos != -1) {
				response = response.substring(0, pos + "</StateOfPlay>".length());
				// Extract 'Subject'
				pos = response.indexOf("<Subject>");
				pos2 = response.indexOf("</Subject>");
				if (pos != -1 && pos2 != -1) {
					response = response.substring(pos, pos2 + "</Subject>".length());
					JSONObject xmlJSONObj = XML.toJSONObject(response);
					JSONObject root = xmlJSONObj.getJSONObject("Subject");
					if (root.has("LegalEntitySubject")) {
						JSONObject jo = root.getJSONObject("LegalEntitySubject");					
						JSONObject jo2 = null;
						if (jo.has("CyrillicShortName")) {
							jo2 = jo.getJSONObject("CyrillicShortName");
							if (jo2.has("content")) {
								stateOfPlayResponse.setCyrillicShortName(jo2.getString("content"));
								System.out.println("CyrillicShortName=" + jo2.getString("content"));
							}						
						}
						if (jo.has("CyrillicFullName")) {
							jo2 = jo.getJSONObject("CyrillicFullName");
							if (jo2.has("content")) {
								stateOfPlayResponse.setCyrillicFullName(jo2.getString("content"));
								System.out.println("CyrillicFullName=" + jo2.getString("content"));
							}						
						}
						if (jo.has("LatinFullName")) {
							jo2 = jo.getJSONObject("LatinFullName");
							if (jo2.has("content")) {
								stateOfPlayResponse.setLatinFullName(jo2.getString("content"));
								System.out.println("LatinFullName=" + jo2.getString("content"));
							}						
						}
						if (root.has("UIC")) {
							jo = root.getJSONObject("UIC");
							if (jo.has("UIC")) {
								jo2 = jo.getJSONObject("UIC");
								if (jo2.has("content")) {
									stateOfPlayResponse.setUic(jo2.get("content").toString());
									System.out.println("UIC=" + jo2.get("content").toString());
								}
							}
						}
						//String jsonPrettyPrintString = xmlJSONObj.toString(PRETTY_PRINT_INDENT_FACTOR);
						//System.out.println(jsonPrettyPrintString);
					}
				}
			}
		} else {
			// UIC not found in Regix 
			return null;
		}
		return stateOfPlayResponse;
	}
	
	/** Response
	 <s:Envelope
	xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
	<s:Body
		xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
		xmlns:xsd="http://www.w3.org/2001/XMLSchema">
		<ExecuteResponse
			xmlns="http://egov.bg/RegiX">
			<ExecuteResult>
				<ServiceResultData
					xmlns="http://egov.bg/RegiX/SignedData">
					<IsReady>true</IsReady>
					<Data id="data">
						<Request id="request">
							<GetStateOfPlayRequest
								xmlns="http://www.bulstat.bg/GetStateOfPlayRequest">
								<UIC>1216049740027</UIC>
							</GetStateOfPlayRequest>
						</Request>
						<Response id="response">
							<StateOfPlay
								xmlns="http://www.bulstat.bg/StateOfPlay">
								<Subject>
									<EntryTime
										xmlns="http://www.bulstat.bg/Entry">2011-05-10T11:01:52
									</EntryTime>
									<UIC
										xmlns="http://www.bulstat.bg/Subject">
										<EntryTime
											xmlns="http://www.bulstat.bg/Entry">1999-01-01T01:00:00
										</EntryTime>
										<UIC
											xmlns="http://www.bulstat.bg/UIC">1216049740027
										</UIC>
										<UICType
											xmlns="http://www.bulstat.bg/UIC">
											<Code
												xmlns="http://www.bulstat.bg/NomenclatureEntry">1
											</Code>
										</UICType>
									</UIC>
									<SubjectType
										xmlns="http://www.bulstat.bg/Subject">
										<Code
											xmlns="http://www.bulstat.bg/NomenclatureEntry">896
										</Code>
									</SubjectType>
									<LegalEntitySubject
										xmlns="http://www.bulstat.bg/Subject">
										<EntryTime
											xmlns="http://www.bulstat.bg/Entry">2010-12-06T11:30:38
										</EntryTime>
										<Country
											xmlns="http://www.bulstat.bg/LegalEntity">
											<Code
												xmlns="http://www.bulstat.bg/NomenclatureEntry">100
											</Code>
										</Country>
										<LegalForm
											xmlns="http://www.bulstat.bg/LegalEntity">
											<Code
												xmlns="http://www.bulstat.bg/NomenclatureEntry">530
											</Code>
										</LegalForm>
										<LegalStatute
											xmlns="http://www.bulstat.bg/LegalEntity">
											<Code
												xmlns="http://www.bulstat.bg/NomenclatureEntry">436
											</Code>
										</LegalStatute>
										<SubjectGroup
											xmlns="http://www.bulstat.bg/LegalEntity">
											<Code
												xmlns="http://www.bulstat.bg/NomenclatureEntry">452
											</Code>
										</SubjectGroup>
										<CyrillicFullName
											xmlns="http://www.bulstat.bg/LegalEntity">ДИРЕКЦИЯ "БЮРО ПО ТРУДА" - АЙТОС
										</CyrillicFullName>
										<CyrillicShortName
											xmlns="http://www.bulstat.bg/LegalEntity">ДБТ - АЙТОС
										</CyrillicShortName>
										<LatinFullName
											xmlns="http://www.bulstat.bg/LegalEntity">DBT - AYTOS
										</LatinFullName>
										<SubordinateLevel
											xmlns="http://www.bulstat.bg/LegalEntity">
											<Code
												xmlns="http://www.bulstat.bg/NomenclatureEntry">617
											</Code>
										</SubordinateLevel>
									</LegalEntitySubject>
									<Communications
										xmlns="http://www.bulstat.bg/Subject">
										<EntryTime
											xmlns="http://www.bulstat.bg/Entry">2011-05-10T10:47:49
										</EntryTime>
										<Type
											xmlns="http://www.bulstat.bg/Communication">
											<Code
												xmlns="http://www.bulstat.bg/NomenclatureEntry">721
											</Code>
										</Type>
										<Value
											xmlns="http://www.bulstat.bg/Communication">0882/825284
										</Value>
									</Communications>
									<Addresses
										xmlns="http://www.bulstat.bg/Subject">
										<EntryTime
											xmlns="http://www.bulstat.bg/Entry">2003-06-30T11:58:33
										</EntryTime>
										<AddressType
											xmlns="http://www.bulstat.bg/Address">
											<Code
												xmlns="http://www.bulstat.bg/NomenclatureEntry">718
											</Code>
										</AddressType>
										<Country
											xmlns="http://www.bulstat.bg/Address">
											<Code
												xmlns="http://www.bulstat.bg/NomenclatureEntry">100
											</Code>
										</Country>
										<PostalCode
											xmlns="http://www.bulstat.bg/Address">8500
										</PostalCode>
										<Location
											xmlns="http://www.bulstat.bg/Address">
											<Code
												xmlns="http://www.bulstat.bg/NomenclatureEntry">00151
											</Code>
										</Location>
										<Street
											xmlns="http://www.bulstat.bg/Address">ул.ФИЛИП КУТЕВ
										</Street>
										<StreetNumber
											xmlns="http://www.bulstat.bg/Address">36
										</StreetNumber>
									</Addresses>
								</Subject>
								<Event>
									<EntryTime
										xmlns="http://www.bulstat.bg/Entry">2011-05-10T10:44:48
									</EntryTime>
								</Event>
								<MainActivity2003>
									<EntryTime
										xmlns="http://www.bulstat.bg/Entry">1999-01-01T01:00:00
									</EntryTime>
									<NKID2003
										xmlns="http://www.bulstat.bg/SubjectPropActivityKID2003">
										<Code
											xmlns="http://www.bulstat.bg/NomenclatureEntry">819
										</Code>
									</NKID2003>
								</MainActivity2003>
								<AccountingRecordForm>
									<EntryTime
										xmlns="http://www.bulstat.bg/Entry">1999-01-01T01:00:00
									</EntryTime>
									<Form
										xmlns="http://www.bulstat.bg/SubjectPropAccountingRecordForm">
										<Code
											xmlns="http://www.bulstat.bg/NomenclatureEntry">964
										</Code>
									</Form>
								</AccountingRecordForm>
								<OwnershipForms>
									<EntryTime
										xmlns="http://www.bulstat.bg/Entry">1999-01-01T01:00:00
									</EntryTime>
									<Form
										xmlns="http://www.bulstat.bg/SubjectPropOwnershipForm">
										<Code
											xmlns="http://www.bulstat.bg/NomenclatureEntry">576
										</Code>
									</Form>
									<Percent
										xmlns="http://www.bulstat.bg/SubjectPropOwnershipForm">100
									</Percent>
								</OwnershipForms>
								<FundingSources>
									<EntryTime
										xmlns="http://www.bulstat.bg/Entry">2006-02-23T13:01:45
									</EntryTime>
									<Source
										xmlns="http://www.bulstat.bg/SubjectPropFundingSource">
										<Code
											xmlns="http://www.bulstat.bg/NomenclatureEntry">589
										</Code>
									</Source>
									<Percent
										xmlns="http://www.bulstat.bg/SubjectPropFundingSource">100
									</Percent>
								</FundingSources>
								<State>
									<EntryTime
										xmlns="http://www.bulstat.bg/Entry">1999-01-01T01:00:00
									</EntryTime>
									<State
										xmlns="http://www.bulstat.bg/SubjectPropState">
										<Code
											xmlns="http://www.bulstat.bg/NomenclatureEntry">571
										</Code>
									</State>
								</State>
								<Managers>
									<EntryTime
										xmlns="http://www.bulstat.bg/Entry">2011-05-10T10:44:47
									</EntryTime>
									<RelatedSubject
										xmlns="http://www.bulstat.bg/SubjectRelManager">
										<EntryTime
											xmlns="http://www.bulstat.bg/Entry">2000-04-17T15:51:35
										</EntryTime>
										<SubjectType
											xmlns="http://www.bulstat.bg/Subject">
											<Code
												xmlns="http://www.bulstat.bg/NomenclatureEntry">897
											</Code>
										</SubjectType>
										<NaturalPersonSubject
											xmlns="http://www.bulstat.bg/Subject">
											<EntryTime
												xmlns="http://www.bulstat.bg/Entry">2000-05-01T00:00:00
											</EntryTime>
											<Country
												xmlns="http://www.bulstat.bg/NaturalPerson">
												<Code
													xmlns="http://www.bulstat.bg/NomenclatureEntry">100
												</Code>
											</Country>
											<EGN
												xmlns="http://www.bulstat.bg/NaturalPerson">6011120863
											</EGN>
											<CyrillicName
												xmlns="http://www.bulstat.bg/NaturalPerson">АНГЕЛ КОЛЕВ ГУГУЧКОВ
											</CyrillicName>
											<BirthDate
												xmlns="http://www.bulstat.bg/NaturalPerson">1960-11-12T00:00:00.000
											</BirthDate>
										</NaturalPersonSubject>
									</RelatedSubject>
									<Position
										xmlns="http://www.bulstat.bg/SubjectRelManager">
										<Code
											xmlns="http://www.bulstat.bg/NomenclatureEntry">640
										</Code>
									</Position>
								</Managers>
								<Belonging>
									<EntryTime
										xmlns="http://www.bulstat.bg/Entry">1999-01-01T01:00:00
									</EntryTime>
									<RelatedSubject
										xmlns="http://www.bulstat.bg/SubjectRelBelonging">
										<EntryTime
											xmlns="http://www.bulstat.bg/Entry">2015-02-06T15:10:29
										</EntryTime>
										<UIC
											xmlns="http://www.bulstat.bg/Subject">
											<EntryTime
												xmlns="http://www.bulstat.bg/Entry">1999-01-01T01:00:00
											</EntryTime>
											<UIC
												xmlns="http://www.bulstat.bg/UIC">121604974
											</UIC>
											<UICType
												xmlns="http://www.bulstat.bg/UIC">
												<Code
													xmlns="http://www.bulstat.bg/NomenclatureEntry">1
												</Code>
											</UICType>
										</UIC>
										<SubjectType
											xmlns="http://www.bulstat.bg/Subject">
											<Code
												xmlns="http://www.bulstat.bg/NomenclatureEntry">896
											</Code>
										</SubjectType>
										<LegalEntitySubject
											xmlns="http://www.bulstat.bg/Subject">
											<EntryTime
												xmlns="http://www.bulstat.bg/Entry">2004-01-07T11:27:15
											</EntryTime>
											<Country
												xmlns="http://www.bulstat.bg/LegalEntity">
												<Code
													xmlns="http://www.bulstat.bg/NomenclatureEntry">100
												</Code>
											</Country>
											<LegalForm
												xmlns="http://www.bulstat.bg/LegalEntity">
												<Code
													xmlns="http://www.bulstat.bg/NomenclatureEntry">1218
												</Code>
											</LegalForm>
											<LegalStatute
												xmlns="http://www.bulstat.bg/LegalEntity">
												<Code
													xmlns="http://www.bulstat.bg/NomenclatureEntry">435
												</Code>
											</LegalStatute>
											<SubjectGroup
												xmlns="http://www.bulstat.bg/LegalEntity">
												<Code
													xmlns="http://www.bulstat.bg/NomenclatureEntry">444
												</Code>
											</SubjectGroup>
											<CyrillicFullName
												xmlns="http://www.bulstat.bg/LegalEntity">АГЕНЦИЯ ПО ЗАЕТОСТТА
											</CyrillicFullName>
											<CyrillicShortName
												xmlns="http://www.bulstat.bg/LegalEntity">АГЕНЦИЯ ПО ЗАЕТОСТТА
											</CyrillicShortName>
											<LatinFullName
												xmlns="http://www.bulstat.bg/LegalEntity">AGENTZIYA PO ZAETOSTA
											</LatinFullName>
											<SubordinateLevel
												xmlns="http://www.bulstat.bg/LegalEntity">
												<Code
													xmlns="http://www.bulstat.bg/NomenclatureEntry">616
												</Code>
											</SubordinateLevel>
										</LegalEntitySubject>
									</RelatedSubject>
									<Type
										xmlns="http://www.bulstat.bg/SubjectRelBelonging">
										<Code
											xmlns="http://www.bulstat.bg/NomenclatureEntry">710
										</Code>
									</Type>
								</Belonging>
							</StateOfPlay>
						</Response>
						<Matrix xsi:nil="true"/>
					</Data>
					<HasError>false</HasError>
					<Error xsi:nil="true"/>
					<ServiceCallID>215598705</ServiceCallID>
				</ServiceResultData>
			</ExecuteResult>
		</ExecuteResponse>
	</s:Body>
</s:Envelope>
	 **/
	
	/*
	 * ГРАО:
	 * 		Справка за валидност на физическо лице	
	 * https://info-regix.egov.bg/public/administrations/-/registries/operations/TechnoLogica.RegiX.GraoNBDAdapter.APIService.INBDAPI/ValidPersonSearch
	 */
	public ValidPersonResponse getValidPersonRequest(String egn) throws Exception {
		String contextPath = "";
		try {
			contextPath = new RegixCommunicator().getClass().getResource("/certs").toURI().getPath();
		} catch (Exception e) {
			e.printStackTrace();
		}
		String password = MySpaceConstants.REGIX_V2_PASSWORD;
		String fileName = MySpaceConstants.REGIX_V2_JKS_FILENAME;
		String keyStoreLoc = contextPath + (!contextPath.endsWith("/") ? "/" : "") + fileName;
		String response = null;
		StringBuilder strBuf = new StringBuilder();
		HttpsURLConnection conn = null;
	    BufferedReader reader = null;
	    String message = "Regix communication error";
		try {
			SSLSocketFactory sslSocketFacotry = createSocketFactory(new FileInputStream(keyStoreLoc), password.toCharArray());
			URL url = new URL(MySpaceConstants.REGIX_V2_PROD_URL);	        
        	conn = (HttpsURLConnection) url.openConnection();
        	conn.setSSLSocketFactory(sslSocketFacotry);        	
        	String requestBody = GetValidPersonRequestBody(egn);
        	byte[] out = requestBody.getBytes(StandardCharsets.UTF_8);
        	int length = out.length;
        	conn.setFixedLengthStreamingMode(length);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "text/xml;charset=UTF-8");
            conn.setRequestProperty("Accept", "text/xml");
            conn.setRequestProperty("User-Agent", "JAX-WS RI 2.3.2");
            conn.setRequestProperty("SOAPAction", "http://egov.bg/RegiX/IRegiXEntryPointV2/Execute");
            conn.setConnectTimeout(20000); //set timeout to 20 seconds
	        conn.setReadTimeout(20000); //set timeout to 20 seconds
            conn.setDoOutput(true);

            try(OutputStream os = conn.getOutputStream()) {
                os.write(out);
            }
            
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode());
            }

            reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
            String output = null;
            while ((output = reader.readLine()) != null) {
                strBuf.append(output);
            }
            response = strBuf.toString();
            Logger.log(Logger.DEBUG_LEVEL, "getValidPersonRequest response:" + response);
            return populateValidPersonReponse(response);
        } catch (IOException e) {
        	message = e.getMessage();
            e.printStackTrace();                
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
		throw new Exception(message);
	}
	
	private String GetValidPersonRequestBody (String egn) {
		String uuid = UUID.randomUUID().toString();
		String xml = "";
		xml += "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:reg=\"http://egov.bg/RegiX\" xmlns:sig=\"http://egov.bg/RegiX/SignedData\">   \n"
				+ "   <soapenv:Header>\n"
				+ "    <To xmlns=\"http://www.w3.org/2005/08/addressing\">https://service-regix.egov.bg/regix/RegiXEntryPoint2.svc</To>\n"
				+ "    <Action xmlns=\"http://www.w3.org/2005/08/addressing\">http://egov.bg/RegiX/IRegiXEntryPointV2/Execute</Action>\n"
				+ "    <ReplyTo xmlns=\"http://www.w3.org/2005/08/addressing\">\n"
				+ "        <Address>http://www.w3.org/2005/08/addressing/anonymous</Address>\n"
				+ "    </ReplyTo>    \n"
				+ "    <FaultTo xmlns=\"http://www.w3.org/2005/08/addressing\">\n"
				+ "        <Address>http://www.w3.org/2005/08/addressing/anonymous</Address>\n"
				+ "    </FaultTo>   \n"
				+ "    <MessageID xmlns=\"http://www.w3.org/2005/08/addressing\">uuid:" + uuid + "</MessageID>\n"
				+ "   </soapenv:Header>     \n"
				+ "   <soapenv:Body>\n"
				+ "      <reg:Execute>\n"
				+ "         <reg:request>\n"
				+ "            <sig:ServiceRequestData>\n"
				+ "               <sig:RequestProcessing></sig:RequestProcessing>\n"
				+ "               <sig:ResponseProcessing></sig:ResponseProcessing>\n"
				+ "               <sig:Operation>TechnoLogica.RegiX.GraoNBDAdapter.APIService.INBDAPI.ValidPersonSearch</sig:Operation>\n"
				+ "               <sig:Argument>\n"
				+ "                  <ValidPersonRequest xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns=\"http://egov.bg/RegiX/GRAO/NBD/ValidPersonRequest\">\n"
				+ "                        <EGN>" + egn + "</EGN>\n"
				+ "                  </ValidPersonRequest>\n"
				+ "               </sig:Argument>\n"
				+ "               <SignResult>false</SignResult>\n"
				+ "               <ReturnAccessMatrix>false</ReturnAccessMatrix>\n"
				+ "            </sig:ServiceRequestData>\n"
				+ "         </reg:request>\n"
				+ "      </reg:Execute>\n"
				+ "   </soapenv:Body>\n"
				+ "</soapenv:Envelope>";
		return xml;
    }
	
	private ValidPersonResponse populateValidPersonReponse(String response) {
		if (response == null || response.trim().length() == 0) return null;
		ValidPersonResponse validPersonResponse = new ValidPersonResponse();
		int pos = response.indexOf("<ValidPersonResponse");
		if (pos != -1) {
			response = response.substring(pos);
			pos = response.indexOf("</ValidPersonResponse>");
			if (pos != -1) {
				response = response.substring(0, pos + "</ValidPersonResponse>".length());							
				JSONObject root = XML.toJSONObject(response);
				if (root.has("ValidPersonResponse")) {
					JSONObject jo = root.getJSONObject("ValidPersonResponse");					
					if (jo.has("FirstName")) {
						validPersonResponse.setFirstName(jo.getString("FirstName"));
						//System.out.println("FirstName=" + validPersonResponse.getFirstName());
					}
					if (jo.has("SurName")) {
						validPersonResponse.setSurName(jo.getString("SurName"));
						//System.out.println("SurName=" + validPersonResponse.getSurName());
					}
					if (jo.has("FamilyName")) {
						validPersonResponse.setFamilyName(jo.getString("FamilyName"));
						//System.out.println("FamilyName=" + validPersonResponse.getFamilyName());
					}
					if (jo.has("BirthDate")) {
						validPersonResponse.setBirthDate(jo.getString("BirthDate"));
						//System.out.println("BirthDate=" + validPersonResponse.getBirthDate());
					}
					if (jo.has("DeathDate")) {
						validPersonResponse.setDeathDate(jo.getString("DeathDate"));
						//System.out.println("DeathDate=" + validPersonResponse.getDeathDate());
					}					
				}
			}
		} else {
			// EGN not found in Regix 
			return null;
		}
		return validPersonResponse;
	}
	
	/** Response
	 <s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/">
    <s:Body xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
        <ExecuteResponse xmlns="http://egov.bg/RegiX">
            <ExecuteResult>
                <ServiceResultData xmlns="http://egov.bg/RegiX/SignedData">
                    <IsReady>true</IsReady>
                    <Data id="data">
                        <Request id="request">
                            <ValidPersonRequest xmlns="http://egov.bg/RegiX/GRAO/NBD/ValidPersonRequest">
                                <EGN>8506258485</EGN>
                            </ValidPersonRequest>
                        </Request>
                        <Response id="response">
                            <ValidPersonResponse xmlns="http://egov.bg/RegiX/GRAO/NBD/ValidPersonResponse">
                                <FirstName>АХМЕД</FirstName>
                                <SurName>ЮСУФ</SurName>
                                <FamilyName>АХМЕД</FamilyName>
                                <BirthDate>1985-06-25</BirthDate>
                            </ValidPersonResponse>
                        </Response>
                        <Matrix xsi:nil="true"/>
                    </Data>
                    <HasError>false</HasError>
                    <Error xsi:nil="true"/>
                    <ServiceCallID>225595109</ServiceCallID>
                </ServiceResultData>
            </ExecuteResult>
        </ExecuteResponse>
    </s:Body>
</s:Envelope>
	 **/
	
	public static void main(String[] args) {
		RegixCommunicator rc = new RegixCommunicator();
		MySpacePortlet.debug = true;
		try {
			//rc.printValidUICResponse(rc.GetValidUICInfo("117627631"));
			rc.getStateOfPlay("1216049740027");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
