package com.ibs.myspace.communicator;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import org.json.JSONObject;

import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.MySpacePortlet;
import com.ibs.myspace.portlet.db.Base;
import com.ibs.myspace.portlet.utils.Logger;
import com.ibs.myspace.portlet.utils.MySpaceUtils;

/*
 * This Communicator exists also in SignInEAvt & UserProfileManagerPortlet portlets & EgovRestProvider app.
 */

public class EJournalCommunicator {
	
		
	public String sendRNU(String rnu, int stageId, int statusId, long operationTime) {	
		Logger.log(Logger.DEBUG_LEVEL, "EJournalCommunicator::sendRNU(" + rnu + "," + stageId + "," + statusId + "," + operationTime + ")");
		if (!Base.TEST_ENVIRONMENT) {
			return "0";
		}
		String response = null;
		StringBuilder strBuf = new StringBuilder();	
		HttpURLConnection conn = null;
		BufferedReader reader = null;
		String eJournalAddress = null;
		String jsonBody = ""					
				+ "{"
				+ "    \"serviceRefNumber\": \"" + rnu + "\","
				+ "    \"systemOID\": \"" + MySpaceConstants.PORTAL_OID + "\","
				+ "    \"subjectId\": \"\","
				+ "    \"subjectIdType\": \"\","
				+ "    \"subjectIdName\": \"\","
				+ "    \"systemOIDowner\": \"" + MySpaceConstants.E_JOURNAL_SYSTEM_OID_OWNER + "\","
				+ "    \"idStage\": \"" + stageId + "\",   "
				+ "    \"idService\": \"" + MySpaceConstants.E_JOURNAL_ID_SERVICE_PARAM + "\",   "
				+ "    \"idStatus\": \"" + statusId + "\",   "
				+ "    \"infoRelatedService\": \"\",   "
				+ "    \"timeStatusChange\": \"" + MySpaceUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(operationTime) +  "\""
				+ "}";
		try {
			eJournalAddress = Base.PRODUCTION_ENVIRONMENT ? MySpacePortlet.eJournalAddressProd : MySpacePortlet.eJournalAddressTest; 
			URL url = new URL(eJournalAddress);
			conn = (HttpURLConnection) url.openConnection();
			
			byte[] postData = jsonBody.getBytes(StandardCharsets.UTF_8);
			int postDataLength = postData.length;
			
			conn.setFixedLengthStreamingMode(postDataLength);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("Accept", "application/json");
			conn.setRequestProperty("Content-Length", Integer.toString(postDataLength));
			conn.setConnectTimeout(2000); //set timeout to 2 seconds
			conn.setReadTimeout(2000); //set timeout to 2 seconds
			conn.setDoOutput(true);
			conn.setUseCaches( false );
			
			Logger.log(Logger.DEBUG_LEVEL, "calling [POST] " + eJournalAddress + " with jsonBody: " + jsonBody);
			try(OutputStream os = conn.getOutputStream()) {
				os.write(postData);
			}
			
			if (conn.getResponseCode() != 200) {
				Logger.log(Logger.ERROR_LEVEL, "ERROR calling [POST] " + eJournalAddress + " with jsonBody: " + jsonBody);
				throw new RuntimeException("HTTP POST Request Failed with Error code : " + conn.getResponseCode());
			}
			
			reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
			String output = null;
			while ((output = reader.readLine()) != null) {
				strBuf.append(output);
			}
			response = strBuf.toString();
            Logger.log(Logger.DEBUG_LEVEL, "EJournalCommunicator::sendRNU response:" + response);
            if (response != null && response.trim().length() > 0) {
            	 JSONObject jo = new JSONObject(response);            
                 if (jo != null && jo.has("id")) {
                	 return jo.get("id").toString();
                 }
            }
		} catch (SocketTimeoutException e) {
			Logger.log(Logger.ERROR_LEVEL, "ERROR calling [POST] " + eJournalAddress + " with jsonBody: " + jsonBody);
			e.printStackTrace();
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "ERROR calling [POST] " + eJournalAddress + " with jsonBody: " + jsonBody);
			e.printStackTrace();
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			if (conn != null) {
				conn.disconnect();
			}
		}
		return null;
	}
	
	public static void main(String[] args) {
		//EJournalCommunicator rc = new EJournalCommunicator();
		MySpacePortlet.debug = true;
		try {
			//rc.sendRNU("1216049740027");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
}
