package com.ibs.myspace.portlet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ibs.myspace.portlet.bean.Container;
import com.ibs.myspace.portlet.bean.EDeliveryProfileBean;
import com.ibs.myspace.portlet.bean.ESBTokenBean;
import com.ibs.myspace.portlet.bean.Message;
import com.ibs.myspace.portlet.bean.ProfileParametersContainer;
import com.ibs.myspace.portlet.bean.UserProfileBean;
import com.ibs.myspace.portlet.dbo.UserProfile;
import com.ibs.myspace.portlet.dbo.UserProfilePersonalParameters;
import com.ibs.myspace.portlet.dbo.UserProfileRequest;
import com.ibs.myspace.portlet.dbo.UserProfileRole;

public class MySpacePortletSessionBean {
	
	private String currentPage = MySpacePortlet.INDEX_PAGE;		
	private String redirectToPage = null;		
	private String currentSubPage = null;		
	private UserProfileBean userProfile = null;
	private String userProfileIdPersonal = null;
	private UserProfile profile = null;	
	private UserProfileRole roles = null;
	private UserProfile[] profiles = null;
	private UserProfile[] profilesParticipation = null;
	private UserProfileRequest[] requests = null;	
	private EDeliveryProfileBean[] eDeliveryProfileBeans = null;
	private UserProfilePersonalParameters personalParameters = null;
	private HashMap<String, Container> container = null;
	private boolean hasProfile = false;
	private boolean deactivation = false;
	private Message message = null;
	private List<Message> messages = null;
	private Map<String, String[]> parameterMap = null;
	private boolean initialized = false;
	private boolean eDeliveryProfilesLoaded = false;
	private String encryptedProfileId = null;
	private HashMap<String, ProfileParametersContainer> profileParametersContainer = null;
	private boolean hasNotPopulatedRequiredParameters = false;
	private boolean persistMessage = false;
	private int unReadReceivedMessagesCount = 0;
	private List<ESBTokenBean> esbTokens = null;
	
	public String getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(String currentPage) {
		this.currentPage = currentPage;
	}

	public String getRedirectToPage() {
		return redirectToPage;
	}

	public void setRedirectToPage(String redirectToPage) {
		this.redirectToPage = redirectToPage;
	}

	public String getCurrentSubPage() {
		return currentSubPage;
	}

	public void setCurrentSubPage(String currentSubPage) {
		this.currentSubPage = currentSubPage;
	}

	public UserProfileBean getUserProfile() {
		return userProfile;
	}

	public void setUserProfile(UserProfileBean userProfile) {
		this.userProfile = userProfile;
	}

	public String getUserProfileIdPersonal() {
		return userProfileIdPersonal;
	}

	public void setUserProfileIdPersonal(String userProfileIdPersonal) {
		this.userProfileIdPersonal = userProfileIdPersonal;
	}

	public UserProfile getProfile() {
		return profile;
	}
	
	public void setProfile(UserProfile profile) {
		this.profile = profile;
	}
	
	public UserProfileRole getProfileRoles() {
		return roles;
	}

	public void setProfileRoles(UserProfileRole roles) {
		this.roles = roles;
	}

	public UserProfile[] getProfiles() {
		return profiles;
	}
	
	public void setProfiles(UserProfile[] profiles) {
		this.profiles = profiles;
	}
	
	public UserProfile[] getProfilesParticipation() {
		return profilesParticipation;
	}

	public void setProfilesParticipation(UserProfile[] profilesParticipation) {
		this.profilesParticipation = profilesParticipation;
	}

	public UserProfileRequest[] getRequests() {
		return requests;
	}

	public void setRequests(UserProfileRequest[] requests) {
		this.requests = requests;
	}

	public EDeliveryProfileBean[] geteDeliveryProfileBeans() {
		return eDeliveryProfileBeans;
	}

	public void seteDeliveryProfileBeans(EDeliveryProfileBean[] eDeliveryProfileBeans) {
		this.eDeliveryProfileBeans = eDeliveryProfileBeans;
	}

	public UserProfilePersonalParameters getPersonalParameters() {
		return personalParameters;
	}

	public void setPersonalParameters(UserProfilePersonalParameters personalParameters) {
		this.personalParameters = personalParameters;
	}

	public HashMap<String, Container> getContainer() {
		return container != null ? container : new HashMap<String, Container>();
	}

	public void setContainer(HashMap<String, Container> container) {
		this.container = container;
	}

	public boolean isHasProfile() {
		return hasProfile;
	}

	public void setHasProfile(boolean hasProfile) {
		this.hasProfile = hasProfile;
	}
	
	public boolean isDeactivation() {
		return deactivation;
	}

	public void setDeactivation(boolean deactivation) {
		this.deactivation = deactivation;
	}

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}
	
	public List<Message> getMessages() {
		return messages != null ? messages : new ArrayList<Message>();
	}

	public void setMessages(List<Message> messages) {
		this.messages = messages;
	}

	public java.util.Map<String, String[]> getParameterMap() {
		return parameterMap;
	}

	public void setParameterMap(java.util.Map<String, String[]> parameterMap) {
		this.parameterMap = parameterMap;
	}

	public boolean isInitialized() {
		return initialized;
	}

	public void setInitialized(boolean initialized) {
		this.initialized = initialized;
	}

	public boolean iseDeliveryProfilesLoaded() {
		return eDeliveryProfilesLoaded;
	}

	public void seteDeliveryProfilesLoaded(boolean eDeliveryProfilesLoaded) {
		this.eDeliveryProfilesLoaded = eDeliveryProfilesLoaded;
	}

	public String getEncryptedProfileId() {
		return encryptedProfileId;
	}

	public void setEncryptedProfileId(String encryptedProfileId) {
		this.encryptedProfileId = encryptedProfileId;
	}

	public HashMap<String, ProfileParametersContainer> getProfileParametersContainer() {
		return profileParametersContainer != null ? profileParametersContainer : new HashMap<String, ProfileParametersContainer>();
	}

	public void setProfileParametersContainer(HashMap<String, ProfileParametersContainer> profileParametersContainer) {
		this.profileParametersContainer = profileParametersContainer;
	}

	public boolean isHasNotPopulatedRequiredParameters() {
		return hasNotPopulatedRequiredParameters;
	}

	public void setHasNotPopulatedRequiredParameters(boolean hasNotPopulatedRequiredParameters) {
		this.hasNotPopulatedRequiredParameters = hasNotPopulatedRequiredParameters;
	}

	public boolean isPersistMessage() {
		return persistMessage;
	}

	public void setPersistMessage(boolean persistMessage) {
		this.persistMessage = persistMessage;
	}

	public int getUnReadReceivedMessagesCount() {
		return unReadReceivedMessagesCount;
	}

	public void setUnReadReceivedMessagesCount(int unReadReceivedMessagesCount) {
		this.unReadReceivedMessagesCount = unReadReceivedMessagesCount;
	}

	public List<ESBTokenBean> getESBTokens() {
		return esbTokens;
	}

	public void setESBTokens(List<ESBTokenBean> esbTokens) {
		this.esbTokens = esbTokens;
	}
	
}
