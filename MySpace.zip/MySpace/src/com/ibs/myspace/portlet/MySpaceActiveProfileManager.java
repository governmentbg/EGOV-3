package com.ibs.myspace.portlet;

import java.security.PrivilegedExceptionAction;
import java.util.HashMap;
import java.util.Map;

import com.ibm.portal.um.PumaController;
import com.ibm.portal.um.PumaEnvironment;
import com.ibm.portal.um.User;
import com.ibs.myspace.portlet.bean.UserProfileBean;
import com.ibs.myspace.portlet.dbo.UserProfile;

public class MySpaceActiveProfileManager {
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void registerProfileInLdap(UserProfileBean userProfileBean, UserProfile profile) {
		if (profile == null || profile.getId() == null) {
			return;
		}
		try {
			final PumaEnvironment pumaEnvironment = MySpacePortlet.getPumaHome().getEnvironment();
			final PumaController controller = MySpacePortlet.getPumaController();
			final User user = userProfileBean.getCurrentUser();
			final String profileId = profile.getId();
			pumaEnvironment.runUnrestricted(new PrivilegedExceptionAction() {
				public Object run() {
					Map<String, String> userInputMap = new HashMap<String, String>();
					userInputMap.put(MySpaceConstants.LDAP_ATTRIBUTE_ROOM_NUMBER, profileId);
					try {
						controller.setAttributes(user, userInputMap);
					} catch (Exception e) {
						e.printStackTrace();
					}
					return null;
				}
			});
        } catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();                    
        }
	}
}
