package com.ibs.myspace.portlet.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.ibs.myspace.portlet.dbo.UserProfile;

public class UserProfileMapper {
	public UserProfile getUserProfile(ResultSet resultSet) throws SQLException {
		UserProfile userProfile = new UserProfile();
		userProfile.setId(resultSet.getString("USERPROFILEID"));
		userProfile.setUserUID(resultSet.getString("USERUID"));
		userProfile.setIdentifier(resultSet.getString("IDENTIFIER"));
		userProfile.setNames(resultSet.getString("NAMES"));
		userProfile.setStatus(resultSet.getString("STATUS"));
		userProfile.setDeactivationReason(resultSet.getString("DEACTIVATIONREASON"));
		userProfile.setEik(resultSet.getString("EIK"));
		userProfile.setNameAndLegalForm(resultSet.getString("NAMEANDLEGALFORM"));
		userProfile.setQualityOfPhysicalPerson(resultSet.getString("QUALITYOFPHYSICALPERSON"));
		userProfile.setMethodOfRepresentation(resultSet.getString("METHODOFREPRESENTATION"));
		userProfile.setProfileType(resultSet.getString("PROFILETYPE"));
		userProfile.setProfileStructureType(resultSet.getString("PROFILESTRUCTURETYPE"));
		userProfile.setDateCreated(resultSet.getString("DATECREATED"));
		userProfile.setDateModified(resultSet.getString("DATEMODIFIED"));
		userProfile.setGroupId(resultSet.getString("GROUPID"));
		userProfile.setSamlResponse(resultSet.getString("SAMLRESPONSE"));
		userProfile.setCustomSideNav(resultSet.getString("CUSTOMSIDENAV"));
		return userProfile;
	}
}
