package com.ibs.myspace.portlet.dbo;

import java.sql.Timestamp;
import java.util.Hashtable;

import com.ibs.myspace.portlet.db.DBTransaction;
import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.db.PersistentObject;
import com.ibs.myspace.portlet.db.QueryComposer;
import com.ibs.myspace.portlet.db.QuerySet;
import com.ibs.myspace.portlet.utils.MySpaceUtils;


public class ETranslationRequest extends PersistentObject {

	private static String CLASS_NAME = ETranslationRequest.class.getName();
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "ETRANSLATIONREQUEST";
        sequenceName = "SEQ_ETRANSLATIONREQUEST";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "ETRANSLATIONREQUESTID");
        columnMap.put("requestId", "REQUESTID");
        columnMap.put("translation", "TRANSLATION");
        columnMap.put("targetLanguage", "TARGETLANGUAGE");
        columnMap.put("creationDate", "CREATIONDATE");
        querySet = QueryComposer.composeAll(table, sequenceName, columnMap);
    }
	
    public ETranslationRequest() {
        super(querySet);
    }
    
    private String requestId = null;
    private String translation = null;
    private String targetLanguage = null;
	private String creationDate = null;

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getTranslation() {
		return translation;
	}

	public void setTranslation(String translation) {
		this.translation = translation;
	}

	public String getTargetLanguage() {
		return targetLanguage;
	}

	public void setTargetLanguage(String targetLanguage) {
		this.targetLanguage = targetLanguage;
	}

	public Timestamp getCreationDate() {
		return (creationDate != null) ? new Timestamp(Long.parseLong(creationDate)) : null;
	}
	
	public void setCreationDate(String creationDate) {  
		this.creationDate = (creationDate != null) ? String.valueOf(MySpaceUtils.date_TimestampToTimeMillis(creationDate)) : null;
	}	
	
	public static ETranslationRequest findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (ETranslationRequest) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}
	
	public static ETranslationRequest findByRequestId(final String requestId, final DBTransaction transaction) throws FinderException, Exception {
		return (ETranslationRequest) findSingle(columnMap.get("requestId") + "='" + requestId + "'", CLASS_NAME, transaction);
	}

	public static void removeByRequestId(String requestId, DBTransaction transaction) throws FinderException, Exception {
		ETranslationRequest requests = new ETranslationRequest();
		String cond = columnMap.get("requestId") + "='" + requestId + "'";
		requests.removeConditional(cond, transaction);			
	}

	public static ETranslationRequest[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllETranslationRequests("1=1", transaction);
	}

	public static ETranslationRequest[] findAllETranslationRequests(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final ETranslationRequest[] requests = new ETranslationRequest[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				requests[i] = (ETranslationRequest) tmp[i];
			}
			return requests;
		} 
		return null;
	}
	
}
