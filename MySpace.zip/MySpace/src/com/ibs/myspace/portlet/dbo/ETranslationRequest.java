package com.ibs.myspace.portlet.dbo;

import java.sql.Timestamp;
import java.util.Hashtable;

import com.ibs.myspace.portlet.db.DBTransaction;
import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.db.PersistentObject;
import com.ibs.myspace.portlet.db.QueryComposer;
import com.ibs.myspace.portlet.db.QuerySet;
import com.ibs.myspace.portlet.utils.MySpaceUtils;


public class ETranslationRequest extends PersistentObject {

	private static String CLASS_NAME = ETranslationRequest.class.getName();
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "ETRANSLATIONREQUEST";
        sequenceName = "SEQ_ETRANSLATIONREQUEST";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "ETRANSLATIONREQUESTID");
        columnMap.put("requestId", "REQUESTID");
        columnMap.put("translation", "TRANSLATION");
        columnMap.put("sourceLanguage", "SOURCELANGUAGE");
        columnMap.put("targetLanguage", "TARGETLANGUAGE");        
        columnMap.put("documentName", "DOCUMENTNAME");
        columnMap.put("documentContentType", "DOCUMENTCONTENTTYPE");
        columnMap.put("originalDocument", "ORIGINALDOCUMENT");
        columnMap.put("originalDocumentSize", "ORIGINALDOCUMENTSIZE");
        columnMap.put("translatedDocument", "TRANSLATEDDOCUMENT");
        columnMap.put("translatedDocumentSize", "TRANSLATEDDOCUMENTSIZE");        
        columnMap.put("errorCode", "ERRORCODE");
        columnMap.put("errorMessage", "ERRORMESSAGE");
        columnMap.put("userProfileId", "USERPROFILEID");
        columnMap.put("creationDate", "CREATIONDATE");
        columnMap.put("responseTime", "RESPONSETIME");
        querySet = QueryComposer.composeAll(table, sequenceName, columnMap);
    }
	
    public ETranslationRequest() {
        super(querySet);
    }
    
    private String requestId = null;
    private String translation = null;
    private String sourceLanguage = null;
    private String targetLanguage = null;
    private String documentName = null;
    private String documentContentType = null;
    private byte[] originalDocument = null;
    private String originalDocumentSize = null;
    private byte[] translatedDocument = null;
    private String translatedDocumentSize = null;
    private String errorCode = null;
    private String errorMessage = null;
    private String userProfileId = null;
    private String creationDate = null;
	private String responseTime = null;

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getTranslation() {
		return translation;
	}

	public void setTranslation(String translation) {
		this.translation = translation;
	}

	public String getSourceLanguage() {
		return sourceLanguage;
	}

	public void setSourceLanguage(String sourceLanguage) {
		this.sourceLanguage = sourceLanguage;
	}

	public String getTargetLanguage() {
		return targetLanguage;
	}

	public void setTargetLanguage(String targetLanguage) {
		this.targetLanguage = targetLanguage;
	}

	
	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDocumentContentType() {
		return documentContentType;
	}

	public void setDocumentContentType(String documentContentType) {
		this.documentContentType = documentContentType;
	}
	
	public byte[] getOriginalDocument() {
		return originalDocument;
	}

	public void setOriginalDocument(byte[] originalDocument) {
		this.originalDocument = originalDocument;
	}

	public String getOriginalDocumentSize() {
		return originalDocumentSize;
	}

	public void setOriginalDocumentSize(String originalDocumentSize) {
		this.originalDocumentSize = originalDocumentSize;
	}
	
	public byte[] getTranslatedDocument() {
		return translatedDocument;
	}

	public void setTranslatedDocument(byte[] translatedDocument) {
		this.translatedDocument = translatedDocument;
	}

	public String getTranslatedDocumentSize() {
		return translatedDocumentSize;
	}

	public void setTranslatedDocumentSize(String translatedDocumentSize) {
		this.translatedDocumentSize = translatedDocumentSize;
	}
	
	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
	public String getUserProfileId() {
		return userProfileId;
	}

	public void setUserProfileId(String userProfileId) {
		this.userProfileId = userProfileId;
	}

	public Timestamp getCreationDate() {
		return (creationDate != null) ? new Timestamp(Long.parseLong(creationDate)) : null;
	}
	
	public void setCreationDate(String creationDate) {  
		this.creationDate = (creationDate != null) ? String.valueOf(MySpaceUtils.date_TimestampToTimeMillis(creationDate)) : null;
	}	
	
	public Timestamp getResponseTime() {
		return (responseTime != null) ? new Timestamp(Long.parseLong(responseTime)) : null;
	}
	
	public void setResponseTime(String responseTime) {  
		this.responseTime = (responseTime != null) ? String.valueOf(MySpaceUtils.date_TimestampToTimeMillis(responseTime)) : null;
	}	
	
	public static ETranslationRequest findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (ETranslationRequest) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}
	
	public static ETranslationRequest findByRequestId(final String requestId, final DBTransaction transaction) throws FinderException, Exception {
		return (ETranslationRequest) findSingle(columnMap.get("requestId") + "='" + requestId + "'", CLASS_NAME, transaction);
	}

	public static void removeByRequestId(String requestId, DBTransaction transaction) throws FinderException, Exception {
		ETranslationRequest requests = new ETranslationRequest();
		String cond = columnMap.get("requestId") + "='" + requestId + "'";
		requests.removeConditional(cond, transaction);			
	}

	public static ETranslationRequest[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllETranslationRequests("1=1", transaction);
	}

	public static ETranslationRequest[] findAllETranslationRequests(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final ETranslationRequest[] requests = new ETranslationRequest[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				requests[i] = (ETranslationRequest) tmp[i];
			}
			return requests;
		} 
		return null;
	}
	
}
