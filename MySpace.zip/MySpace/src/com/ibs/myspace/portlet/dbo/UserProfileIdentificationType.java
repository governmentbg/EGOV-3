package com.ibs.myspace.portlet.dbo;

import java.util.Hashtable;

import com.ibs.myspace.portlet.db.DBTransaction;
import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.db.PersistentObject;
import com.ibs.myspace.portlet.db.QueryComposer;
import com.ibs.myspace.portlet.db.QuerySet;


public class UserProfileIdentificationType extends PersistentObject {

	private static String CLASS_NAME = UserProfileIdentificationType.class.getName();
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "USERPROFILEIDENTIFICATIONTYPE";
        sequenceName = "SEQ_USERPROFILEIDENTIFICATIONTYPE";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "USERPROFILEIDENTIFICATIONTYPEID");
        columnMap.put("userProfileId", "USERPROFILEID");
        columnMap.put("securityLevel", "SECURITYLEVEL");
        columnMap.put("identificationType", "IDENTIFICATIONTYPE");
        columnMap.put("status", "STATUS");
        querySet = QueryComposer.composeAll(table, sequenceName, columnMap);
    }
	
    public UserProfileIdentificationType() {
        super(querySet);
    }
    
    private String userProfileId = null;
    private String securityLevel = null;
    private String identificationType = null;
    private String status = null;
	
	public String getUserProfileId() {
		return userProfileId;
	}

	public void setUserProfileId(String userProfileId) {
		this.userProfileId = userProfileId;
	}

	public String getSecurityLevel() {
		return securityLevel;
	}

	public void setSecurityLevel(String securityLevel) {
		this.securityLevel = securityLevel;
	}

	public String getIdentificationType() {
		return identificationType;
	}

	public void setIdentificationType(String identificationType) {
		this.identificationType = identificationType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public static UserProfileIdentificationType findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileIdentificationType) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}
	
	public static UserProfileIdentificationType[] findAllByUserProfileId(final String userProfileId, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileIdentificationTypes(columnMap.get("userProfileId") + "='" + userProfileId + "'", transaction);
	}
				
	public static void removeAllByUserProfileId(String userProfileId, DBTransaction transaction) throws FinderException, Exception {
		UserProfileIdentificationType userProfileIdentificationType = new UserProfileIdentificationType();
		String cond = columnMap.get("userProfileId") + "='" + userProfileId + "'";
		userProfileIdentificationType.removeConditional(cond, transaction);			
	}
	
	public static UserProfileIdentificationType[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileIdentificationTypes("1=1", transaction);
	}

	public static UserProfileIdentificationType[] findAllUserProfileIdentificationTypes(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final UserProfileIdentificationType[] userProfileIdentificationTypes = new UserProfileIdentificationType[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				userProfileIdentificationTypes[i] = (UserProfileIdentificationType) tmp[i];
			}
			return userProfileIdentificationTypes;
		} 
		return null;
	}
	
}
