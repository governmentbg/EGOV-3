package com.ibs.myspace.portlet.dbo;

import java.util.Date;
import java.util.Hashtable;

import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.db.DBTransaction;
import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.db.PersistentObject;
import com.ibs.myspace.portlet.db.QueryComposer;
import com.ibs.myspace.portlet.db.QuerySet;
import com.ibs.myspace.portlet.utils.MySpaceUtils;


public class UserProfileInvitation extends PersistentObject {

	private static String CLASS_NAME = UserProfileInvitation.class.getName();
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "USERPROFILEINVITATION";
        sequenceName = "SEQ_USERPROFILEINVITATION";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "USERPROFILEINVITATIONID");
        columnMap.put("userProfileId", "USERPROFILEID");
        columnMap.put("profileIdType", "PROFILEIDTYPE");
        columnMap.put("identifier", "IDENTIFIER");
        columnMap.put("identifierPrefix", "IDENTIFIERPREFIX");
        columnMap.put("firstName", "FIRSTNAME");
        columnMap.put("lastName", "LASTNAME");
        columnMap.put("email", "EMAIL");
        columnMap.put("code", "CODE");
        columnMap.put("status", "status");
        columnMap.put("processed", "PROCESSED");
        columnMap.put("userUID", "USERUID");
        columnMap.put("dateCreated", "DATECREATED");
        columnMap.put("dateModified", "DATEMODIFIED");

        querySet = QueryComposer.composeAll(table, sequenceName, columnMap);
    }
	
    public UserProfileInvitation() {
        super(querySet);
    }
    
    private Long userProfileId = null;
    private Integer profileIdType = null;    
    private String identifier = null;
    private String identifierPrefix = null;
    private String firstName = null;
    private String lastName = null;
    private String email = null;
    private String code = null;
    private int status = MySpaceConstants.INVITATION_STATUS_NOT_CONFIRMED;
    private Integer processed = null;
    private String userUID = null;
    private Date dateCreated = null;
	private Date dateModified = null;

	public Long getUserProfileId() {
		return userProfileId;
	}

	public void setUserProfileId(Long userProfileId) {
		this.userProfileId = userProfileId;
	}
	
	public void setUserProfileId(String userProfileId) {
		this.userProfileId = Long.parseLong(userProfileId);
	}

	public Integer getProfileIdType() {
		return profileIdType;
	}

	public void setProfileIdType(Integer profileIdType) {
		this.profileIdType = profileIdType;
	}
	
	public void setProfileIdType(int profileIdType) {
		this.profileIdType = profileIdType;
	}
	
	public void setProfileIdType(String profileIdType) {
		if (profileIdType == null) {
			this.profileIdType = null;
			return;
		}
		try {
			this.profileIdType = Integer.parseInt(profileIdType);
		} catch (Exception e) {}
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	
	public String getIdentifierPrefix() {
		return identifierPrefix;
	}

	public void setIdentifierPrefix(String identifierPrefix) {
		this.identifierPrefix = identifierPrefix;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
	
	public void setStatus(int status) {
		this.status = status;
	}
	
	public void setStatus(String status) {
		if (status == null) {
			return; 
		}
		try {
			this.status = Integer.parseInt(status);
		} catch (Exception e) {}
		
	}

	public Integer getProcessed() {
		return processed;
	}

	public void setProcessed(Integer processed) {
		this.processed = processed;
	}
	
	public void setProcessed(int processed) {
		this.processed = processed;
	}
	
	public void setProcessed(String processed) {
		if (processed == null) {
			this.processed = null;
			return;
		}
		try {
			this.processed = Integer.parseInt(processed);
		} catch (Exception e) {}		
	}

	public String getUserUID() {
		return userUID;
	}

	public void setUserUID(String userUID) {
		this.userUID = userUID;
	}

	public Date getDateCreated() {
		return dateCreated;
	}

	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	
	public void setDateCreated(String dateCreated) {
		this.dateCreated = new Date(MySpaceUtils.date_TimestampToTimeMillis(dateCreated));
	}
	
	public Date getDateModified() {
		return dateModified;
	}

	public void setDateModified(Date dateModified) {
		this.dateModified = dateModified;
	}
	
	public void setDateModified(String dateModified) {
		this.dateModified = new Date(MySpaceUtils.date_TimestampToTimeMillis(dateModified));
	}

	public static UserProfileInvitation findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileInvitation) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}
	
	public static UserProfileInvitation[] findAllByIdentifier(final String identifier, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileInvitations(columnMap.get("identifier") + " = '" + identifier + "'", transaction);
	}	
	
	public static UserProfileInvitation findByIdentifierAndProfileId(final String identifier, final String userProfileId, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileInvitation) findSingle(columnMap.get("identifier") + " = '" + identifier + "' AND " + columnMap.get("userProfileId") + "=" + userProfileId, CLASS_NAME, transaction);
	}	
	
	public static UserProfileInvitation findByIdentifierAndProfileIdAndStatus(final String identifier, final String identifierPrefix, final String userProfileId, final int status, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileInvitation) findSingle(columnMap.get("identifier") + " = '" + identifier + "' AND " + columnMap.get("identifierPrefix") + (identifierPrefix != null ? " ='" + identifierPrefix + "'" : " IS NULL") + " AND " +columnMap.get("userProfileId") + "=" + userProfileId + " AND " + columnMap.get("status") + "=" + status, CLASS_NAME, transaction);
	}	
	
	public static UserProfileInvitation[] findAllByUserProfileId(final String userProfileId, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileInvitations(columnMap.get("userProfileId") + "=" + userProfileId + " order by " + columnMap.get("dateModified") + " desc", transaction);
	}

	public static void removeAllByUserProfileId(String userProfileId, DBTransaction transaction) throws FinderException, Exception {
		UserProfileInvitation invitation = new UserProfileInvitation();
		String cond = columnMap.get("userProfileId") + "=" + userProfileId;
		invitation.removeConditional(cond, transaction);			
	}
	
	public static void removeAllByIdentifier(String identifier, DBTransaction transaction) throws FinderException, Exception {
		UserProfileInvitation invitation = new UserProfileInvitation();
		String cond = columnMap.get("identifier") + "='" + identifier + "'";
		invitation.removeConditional(cond, transaction);			
	}

	public static UserProfileInvitation[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileInvitations("1=1", transaction);
	}

	public static UserProfileInvitation[] findAllUserProfileInvitations(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final UserProfileInvitation[] invitations = new UserProfileInvitation[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				invitations[i] = (UserProfileInvitation) tmp[i];
			}
			return invitations;
		} 
		return null;
	}
	
}
