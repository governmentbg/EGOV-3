package com.ibs.myspace.portlet.dbo;

import java.sql.Timestamp;
import java.util.Hashtable;

import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.db.DBTransaction;
import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.db.PersistentObject;
import com.ibs.myspace.portlet.db.QueryComposer;
import com.ibs.myspace.portlet.db.QuerySet;
import com.ibs.myspace.portlet.utils.MySpaceUtils;


public class UserProfileRole extends PersistentObject {

	private static String CLASS_NAME = UserProfileRole.class.getName();
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "USERPROFILEROLE";
        sequenceName = "SEQ_USERPROFILEROLE";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "USERPROFILEROLEID");
        columnMap.put("userProfileId", "USERPROFILEID");
        columnMap.put("userUID", "USERUID");
        columnMap.put("admin", "ADMIN");
        columnMap.put("editor", "EDITOR");
        columnMap.put("serviceManager", "SERVICEMANAGER");
        columnMap.put("user", "USERROLE");
        columnMap.put("dateCreated", "DATECREATED");

        querySet = QueryComposer.composeAll(table, sequenceName, columnMap);
    }
	
    public UserProfileRole() {
        super(querySet);
    }
    
    private String userProfileId = null;
    private String userUID = null;
    private String admin = null;
    private String editor = null;
    private String serviceManager = null;    
    private String user = null;    
	private String dateCreated = null;
	// For business usage only.
	private String names = null;
	private String personalIdentifier = null;
	private String email = null;
	private UserProfile userProfile = null;
	
	
	public String getUserProfileId() {
		return userProfileId;
	}

	public void setUserProfileId(String userProfileId) {
		this.userProfileId = userProfileId;
	}

	public String getUserUID() {
		return userUID;
	}

	public void setUserUID(String userUID) {
		this.userUID = userUID;
	}

	public String getAdmin() {
		return admin;
	}

	public void setAdmin(String admin) {
		this.admin = admin;
	}

	public String getEditor() {
		return editor;
	}

	public void setEditor(String editor) {
		this.editor = editor;
	}

	public String getServiceManager() {
		return serviceManager;
	}

	public void setServiceManager(String serviceManager) {
		this.serviceManager = serviceManager;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public Timestamp getDateCreated() {
		return (dateCreated != null) ? new Timestamp(Long.parseLong(dateCreated)) : null;
	}
	
	public void setDateCreated(String dateCreated) {  
		this.dateCreated = (dateCreated != null) ? String.valueOf(MySpaceUtils.date_TimestampToTimeMillis(dateCreated)) : null;
	}	
	
	public String getNames() {
		return names;
	}

	public void setNames(String names) {
		this.names = names;
	}

	public String getPersonalIdentifier() {
		return personalIdentifier;
	}

	public void setPersonalIdentifier(String personalIdentifier) {
		this.personalIdentifier = personalIdentifier;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public UserProfile getUserProfile() {
		return userProfile;
	}

	public void setUserProfile(UserProfile userProfile) {
		this.userProfile = userProfile;
	}

	public static UserProfileRole findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileRole) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}
	
	public static UserProfileRole findByIdAndProfileId(final String id, final String userProfileId, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileRole) findSingle(columnMap.get("id") + "=" + id + " AND " + columnMap.get("userProfileId") + "='" + userProfileId + "'", CLASS_NAME, transaction);
	}
	
	public static UserProfileRole findByProfileIdAndUserUID(final String userProfileId, final String userUID, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileRole) findSingle(columnMap.get("userProfileId") + "='" + userProfileId + "'" + " AND " + columnMap.get("userUID") + "='" + userUID + "'", CLASS_NAME, transaction);
	}
	
	public static UserProfileRole[] findAllByUserUID(final String userUid, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileRoles(columnMap.get("userUID") + "='" + userUid + "'", transaction);
	}
	
	public static UserProfileRole[] findAllByUserProfileId(final String userProfileId, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileRoles(columnMap.get("userProfileId") + "='" + userProfileId + "' ORDER BY " + columnMap.get("dateCreated") + " DESC", transaction);
	}
	
	public static UserProfileRole[] findAllByUserProfileIdAndAdminRole(final String userProfileId, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileRoles(columnMap.get("userProfileId") + "='" + userProfileId + "' AND ADMIN='" + MySpaceConstants.USER_PROFILE_ROLE_SELECTED + "' ORDER BY " + columnMap.get("dateCreated") + " DESC", transaction);
	}

	public static void removeAllByUserProfileId(String userProfileId, DBTransaction transaction) throws FinderException, Exception {
		UserProfileRole userProfileRequest = new UserProfileRole();
		String cond = columnMap.get("userProfileId") + "='" + userProfileId + "'";
		userProfileRequest.removeConditional(cond, transaction);			
	}

	public static UserProfileRole[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileRoles("1=1", transaction);
	}

	public static UserProfileRole[] findAllUserProfileRoles(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final UserProfileRole[] userProfileRoles = new UserProfileRole[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				userProfileRoles[i] = (UserProfileRole) tmp[i];
			}
			return userProfileRoles;
		} 
		return null;
	}
	
}
