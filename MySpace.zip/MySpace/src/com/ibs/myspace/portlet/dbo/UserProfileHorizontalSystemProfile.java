package com.ibs.myspace.portlet.dbo;

import java.util.Hashtable;

import com.ibs.myspace.portlet.db.DBTransaction;
import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.db.PersistentObject;
import com.ibs.myspace.portlet.db.QueryComposer;
import com.ibs.myspace.portlet.db.QuerySet;


public class UserProfileHorizontalSystemProfile extends PersistentObject {

	private static String CLASS_NAME = UserProfileHorizontalSystemProfile.class.getName();
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "USERPROFILEHORIZONTALSYSTEMPROFILE";
        sequenceName = "SEQ_USERPROFILEHORIZONTALSYSTEMPROFILE";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "USERPROFILEHORIZONTALSYSTEMPROFILEID");
        columnMap.put("userProfileId", "USERPROFILEID");
        columnMap.put("identificationTypeId", "IDENTIFICATIONTYPEID");
        columnMap.put("systemOID", "SYSTEMOID");
        columnMap.put("systemName", "SYSTEMNAME");
        columnMap.put("accountId", "ACCOUNTID");
        columnMap.put("status", "status");
        columnMap.put("otherData", "OTHERDATA");
        querySet = QueryComposer.composeAll(table, sequenceName, columnMap);
    }
	
    public UserProfileHorizontalSystemProfile() {
        super(querySet);
    }
    
    private String userProfileId = null;
    private String identificationTypeId = null;
    private String systemOID = null;
    private String systemName = null;
    private String accountId = null;
    private String status = null;
    private String otherData = null;
	
	
	public String getUserProfileId() {
		return userProfileId;
	}

	public void setUserProfileId(String userProfileId) {
		this.userProfileId = userProfileId;
	}

	public String getIdentificationTypeId() {
		return identificationTypeId;
	}

	public void setIdentificationTypeId(String identificationTypeId) {
		this.identificationTypeId = identificationTypeId;
	}

	public String getSystemOID() {
		return systemOID;
	}

	public void setSystemOID(String systemOID) {
		this.systemOID = systemOID;
	}

	public String getSystemName() {
		return systemName;
	}

	public void setSystemName(String systemName) {
		this.systemName = systemName;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOtherData() {
		return otherData;
	}

	public void setOtherData(String otherData) {
		this.otherData = otherData;
	}

	public static UserProfileHorizontalSystemProfile findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileHorizontalSystemProfile) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}
	
	public static UserProfileHorizontalSystemProfile[] findAllByUserProfileId(final String userProfileId, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileHorizontalSystemProfiles(columnMap.get("userProfileId") + "='" + userProfileId + "'", transaction);
	}
			
	public static void removeAllByUserProfileId(String userProfileId, DBTransaction transaction) throws FinderException, Exception {
		UserProfileHorizontalSystemProfile userProfileHorizontalSystemProfile = new UserProfileHorizontalSystemProfile();
		String cond = columnMap.get("userProfileId") + "='" + userProfileId + "'";
		userProfileHorizontalSystemProfile.removeConditional(cond, transaction);			
	}
	
	public static UserProfileHorizontalSystemProfile[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileHorizontalSystemProfiles("1=1", transaction);
	}

	public static UserProfileHorizontalSystemProfile[] findAllUserProfileHorizontalSystemProfiles(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final UserProfileHorizontalSystemProfile[] userProfileHorizontalSystemProfiles = new UserProfileHorizontalSystemProfile[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				userProfileHorizontalSystemProfiles[i] = (UserProfileHorizontalSystemProfile) tmp[i];
			}
			return userProfileHorizontalSystemProfiles;
		} 
		return null;
	}
	
}
