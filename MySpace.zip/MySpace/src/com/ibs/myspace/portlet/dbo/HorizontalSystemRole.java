package com.ibs.myspace.portlet.dbo;

import java.sql.Timestamp;
import java.util.Hashtable;

import com.ibs.myspace.portlet.db.DBTransaction;
import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.db.PersistentObject;
import com.ibs.myspace.portlet.db.QueryComposer;
import com.ibs.myspace.portlet.db.QuerySet;
import com.ibs.myspace.portlet.utils.MySpaceUtils;


public class HorizontalSystemRole extends PersistentObject {

	private static String CLASS_NAME = HorizontalSystemRole.class.getName();
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "HORIZONTALSYSTEMROLE";
        sequenceName = "SEQ_HORIZONTALSYSTEMROLE";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "HORIZONTALSYSTEMROLEID");
        columnMap.put("systemOID", "SYSTEMOID");
        columnMap.put("uid", "UID");
        columnMap.put("title", "TITLE");
        columnMap.put("dateCreated", "DATECREATED");
        columnMap.put("dateModified", "DATEMODIFIED");

        querySet = QueryComposer.composeAll(table, sequenceName, columnMap);
    }
	
    public HorizontalSystemRole() {
        super(querySet);
    }
    
    private String systemOID = null;
    private String uid = null;
    private String title = null;
    private String dateCreated = null;
	private String dateModified = null;
	
	public String getSystemOID() {
		return systemOID;
	}

	public void setSystemOID(String systemOID) {
		this.systemOID = systemOID;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Timestamp getDateCreated() {
		return (dateCreated != null) ? new Timestamp(Long.parseLong(dateCreated)) : null;
	}
	
	public void setDateCreated(String dateCreated) {  
		this.dateCreated = (dateCreated != null) ? String.valueOf(MySpaceUtils.date_TimestampToTimeMillis(dateCreated)) : null;
	}	
	
	public Timestamp getDateModified() {
		return (dateModified != null) ? new Timestamp(Long.parseLong(dateModified)) : null;
	}
	
	public void setDateModified(String dateModified) {  
		this.dateModified = (dateModified != null) ? String.valueOf(MySpaceUtils.date_TimestampToTimeMillis(dateModified)) : null;
	}	

	public static HorizontalSystemRole findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (HorizontalSystemRole) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}
	
	public static HorizontalSystemRole findBySystemOIDAndUID(final String systemOID, final String uid, final DBTransaction transaction) throws FinderException, Exception {
		return (HorizontalSystemRole) findSingle(columnMap.get("systemOID") + "='" + systemOID + "' AND " + columnMap.get("uid") + "='" + uid + "'", CLASS_NAME, transaction);
	}
	
	public static HorizontalSystemRole[] findAllBySystemOID(final String systemOID, final DBTransaction transaction) throws FinderException, Exception {
		return findAllHorizontalSystemRoles(columnMap.get("systemOID") + "='" + systemOID + "' order by " + columnMap.get("title") + " asc", transaction);
	}
		
	public static HorizontalSystemRole[] findAllOrderBySystemOID(final DBTransaction transaction) throws FinderException, Exception {
		return findAllHorizontalSystemRoles("1=1 order by " + columnMap.get("systemOID") + ", " + columnMap.get("title") + " asc", transaction);
	}
	
	public static HorizontalSystemRole[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllHorizontalSystemRoles("1=1", transaction);
	}

	public static HorizontalSystemRole[] findAllHorizontalSystemRoles(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final HorizontalSystemRole[] horizontalSystemRoles = new HorizontalSystemRole[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				horizontalSystemRoles[i] = (HorizontalSystemRole) tmp[i];
			}
			return horizontalSystemRoles;
		} 
		return null;
	}
	
}
