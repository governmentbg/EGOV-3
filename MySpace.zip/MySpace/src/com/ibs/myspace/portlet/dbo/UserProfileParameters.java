package com.ibs.myspace.portlet.dbo;

import java.util.Date;
import java.util.Hashtable;

import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.db.DBTransaction;
import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.db.PersistentObject;
import com.ibs.myspace.portlet.db.QueryComposer;
import com.ibs.myspace.portlet.db.QuerySet;
import com.ibs.myspace.portlet.utils.MySpaceUtils;


public class UserProfileParameters extends PersistentObject {

	private static String CLASS_NAME = UserProfileParameters.class.getName();
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    static {
        table = "USERPROFILEPARAMETERS";
        sequenceName = "SEQ_USERPROFILEPARAMETERS";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "USERPROFILEPARAMETERSID");
        columnMap.put("userProfileId", "USERPROFILEID");
        columnMap.put("parameterId", "REGISTERGROUPPARAMETERID");
        columnMap.put("parameterValue", "PARAMETERVALUE");
        columnMap.put("consent", "CONSENT");
        columnMap.put("userUID", "USERUID");
        columnMap.put("operationTime", "OPERATIONTIME");

        querySet = QueryComposer.composeAll(table, sequenceName, columnMap);
    }
	
    public UserProfileParameters() {
        super(querySet);
    }
    
    private Long userProfileId = null;
    private Long parameterId = null;    
    private String parameterValue = null;
    private int consent = MySpaceConstants.VALUE_NO;
    private String userUID = null;
	private Date operationTime = null;

	public Long getUserProfileId() {
		return userProfileId;
	}

	public void setUserProfileId(Long userProfileId) {
		this.userProfileId = userProfileId;
	}
	
	public void setUserProfileId(String userProfileId) {
		this.userProfileId = Long.parseLong(userProfileId);
	}

	public Long getParameterId() {
		return parameterId;
	}

	public void setParameterId(Long parameterId) {
		this.parameterId = parameterId;
	}
	
	public void setParameterId(String parameterId) {
		this.parameterId = Long.parseLong(parameterId);
	}

	public String getParameterValue() {
		return parameterValue;
	}

	public void setParameterValue(String parameterValue) {
		this.parameterValue = parameterValue;
	}

	public int getConsent() {
		return consent;
	}

	public void setConsent(int consent) {
		this.consent = consent;
	}
	
	public void setConsent(String consent) {
		this.consent = Integer.parseInt(consent);
	}

	public String getUserUID() {
		return userUID;
	}

	public void setUserUID(String userUID) {
		this.userUID = userUID;
	}

	public Date getOperationTime() {
		return operationTime;
	}

	public void setOperationTime(Date operationTime) {
		this.operationTime = operationTime;
	}
	
	public void setOperationTime(String operationTime) {
		this.operationTime = new Date(MySpaceUtils.date_TimestampToTimeMillis(operationTime));
	}

	public static UserProfileParameters findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfileParameters) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}
	
	public static UserProfileParameters[] findAllByParametersIds(final String parametersIds, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileParameters(columnMap.get("parameterId") + " IN (" + parametersIds + ")", transaction);
	}
	
	public static UserProfileParameters[] findAllByUserProfileIdAndParametersIds(final String userProfileId, final String parametersIds, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileParameters(columnMap.get("userProfileId") + "=" + userProfileId + " AND " + columnMap.get("parameterId") + " IN (" + parametersIds + ")", transaction);
	}
	
	public static UserProfileParameters[] findAllByProfileIdAndUserUID(final String userProfileId, final String userUID, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileParameters(columnMap.get("userProfileId") + "=" + userProfileId + " AND " + columnMap.get("userUID") + "='" + userUID + "'", transaction);
	}
	
	public static UserProfileParameters[] findAllByUserUID(final String userUid, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileParameters(columnMap.get("userUID") + "='" + userUid + "'", transaction);
	}
	
	public static UserProfileParameters[] findAllByUserProfileId(final String userProfileId, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileParameters(columnMap.get("userProfileId") + "=" + userProfileId, transaction);
	}

	public static void removeAllByUserProfileId(String userProfileId, DBTransaction transaction) throws FinderException, Exception {
		UserProfileParameters userProfileRequest = new UserProfileParameters();
		String cond = columnMap.get("userProfileId") + "=" + userProfileId;
		userProfileRequest.removeConditional(cond, transaction);			
	}

	public static UserProfileParameters[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfileParameters("1=1", transaction);
	}

	public static UserProfileParameters[] findAllUserProfileParameters(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final UserProfileParameters[] userProfileParameters = new UserProfileParameters[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				userProfileParameters[i] = (UserProfileParameters) tmp[i];
			}
			return userProfileParameters;
		} 
		return null;
	}
	
}
