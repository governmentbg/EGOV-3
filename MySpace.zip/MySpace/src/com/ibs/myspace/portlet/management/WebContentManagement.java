package com.ibs.myspace.portlet.management;

import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.exceptions.QueryServiceException;
import com.ibm.workplace.wcm.api.query.Query;
import com.ibm.workplace.wcm.api.query.ResultIterator;
import com.ibm.workplace.wcm.api.query.Selectors;
import com.ibm.workplace.wcm.api.query.WorkflowSelectors;

public class WebContentManagement {
	
	@SuppressWarnings("rawtypes")
	public Content getSupplier (String contentName) {
		try {
			Query query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
			// filter by library.
			query.addSelector(Selectors.libraryEquals(EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)));
			// filter by service suppliers AT ONLY.
		 	query.addSelector(
					Selectors.authoringTemplateIn(
						new DocumentId[] {
							EgovWCMCache.getATServiceProviderCentralAdministration().getId(),
							EgovWCMCache.getATServiceProviderTerritorialAdministration().getId()
						}
					)
			);
			// filter by name.
		 	query.addSelector(Selectors.nameEquals(contentName));
			// filter by published.
			query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
			query.returnObjects();
			try {
			     ResultIterator resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);
			     if (resultIterator.hasNext()) {
			    	 return (Content)resultIterator.next();
			     }
			} catch (QueryServiceException e) {
				 System.out.println("regulationtaxonomylevel1.jsp -> getRegulationRegions - error: " + e.getMessage());
			     e.printStackTrace();
			} 
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
}
