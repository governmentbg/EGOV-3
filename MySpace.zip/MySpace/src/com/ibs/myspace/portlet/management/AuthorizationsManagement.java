package com.ibs.myspace.portlet.management;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.MySpaceNotificationsManager;
import com.ibs.myspace.portlet.MySpacePortlet;
import com.ibs.myspace.portlet.MySpacePortletSessionBean;
import com.ibs.myspace.portlet.bean.AuthorizationBean;
import com.ibs.myspace.portlet.bean.Container;
import com.ibs.myspace.portlet.bean.Message;
import com.ibs.myspace.portlet.bean.UserProfileBean;
import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.db.QueryExecution;
import com.ibs.myspace.portlet.dbo.UserProfile;
import com.ibs.myspace.portlet.dbo.UserProfileRole;
import com.ibs.myspace.portlet.model.Actions;
import com.ibs.myspace.portlet.model.Authorizations;
import com.ibs.myspace.portlet.model.Systems;
import com.ibs.myspace.portlet.utils.Logger;
import com.ibs.myspace.portlet.utils.MySpaceUtils;


public class AuthorizationsManagement {
	MySpaceUtils utils = null;
	
	public AuthorizationsManagement() {
		utils = new MySpaceUtils();
	}
	
	public List<Authorizations> loadAllAuthorizationsByUserIdentifier(String userIdentifier) {
		try {
			QueryExecution qe = new QueryExecution();
			return qe.getAllAuthorizationsByUserIdentifier(userIdentifier);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public Authorizations getAuthorizationById(Long authorizationsId) {
		try {
			QueryExecution qe = new QueryExecution();
			return qe.getAuthorizationById(authorizationsId);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public Authorizations getAuthorizationAuthorizedFile(Long authorizationsId) {
		try {
			QueryExecution qe = new QueryExecution();
			return qe.getAuthorizationAuthorizedFile(authorizationsId);
		} catch (Exception e) {
			e.printStackTrace(); 
		} 
		return null;
	}
	
	public Authorizations getAuthorizationCancelFile(Long authorizationsId) {
		try {
			QueryExecution qe = new QueryExecution();
			return qe.getAuthorizationCancelFile(authorizationsId);
		} catch (Exception e) {
			e.printStackTrace(); 
		} 
		return null;
	}
	
	public List<Systems> getAllSystems() {
		try {
			QueryExecution qe = new QueryExecution();
			return qe.getAllSystems();
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public List<Systems> getAllSystemsByIds(List<Long> systemIds) {
		if (systemIds == null || systemIds.size() == 0) return null;
		try {
			QueryExecution qe = new QueryExecution();
			return qe.getAllSystemsByIds(systemIds);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public Map<Long, List<Actions>> getAllActionsSplitedBySystemsId() {
		Map<Long, List<Actions>> map = new HashMap<Long, List<Actions>>();
		try {
			QueryExecution qe = new QueryExecution();
			List<Actions> actions = qe.getAllActions();
			List<Actions> actionsPerSystem = null;
			for (int i = 0; i < actions.size(); i++) {
				actionsPerSystem = map.get(actions.get(i).getSystemsId());
				if (actionsPerSystem == null) {
					actionsPerSystem = new ArrayList<Actions>();
				}
				actionsPerSystem.add(actions.get(i));
				map.put(actions.get(i).getSystemsId(), actionsPerSystem);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return map;
	}
	
	public List<Actions> getAllActionsByIds(List<Long> actionsIds) {
		if (actionsIds == null || actionsIds.size() == 0) return null;
		try {
			QueryExecution qe = new QueryExecution();
			return qe.getAllActionsByIds(actionsIds); 
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}

	public int cancelAuthorization(MySpacePortletSessionBean sessionBean, InputStream file, String fileName, String fileContentType, long fileSize, String remoteIP, ResourceBundle bundle) throws Exception {
		UserProfileBean userProfileBean = sessionBean.getUserProfile();
		UserProfile profile = sessionBean.getProfile();
		HashMap<String, Container> sessionContainer = sessionBean.getContainer();
		Container container = sessionContainer.get(sessionBean.getCurrentPage());
		Long authorizationsId = container.getAuthorizationsId();
		Authorizations authorization = null;
		try {
			authorization = this.getAuthorizationById(authorizationsId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (authorization == null) {
			Logger.log(Logger.ERROR_LEVEL, "Овластяване с номер " + authorizationsId + " не е намерено в системата.");
			return -1;
		}
		
		String userId = userProfileBean.getCurrentUserUID();
		String userNames = profile.getNameAndLegalForm();
		
		if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(profile.getProfileType())) {
			userNames = profile.getNames();
		}
		if (userNames == null) {
			userNames = userProfileBean.getCurrentUserCN();
		}
		try {
			Date date = new Date();
			QueryExecution qe = new QueryExecution(); 
			int result = qe.cancelAuthorization(
					authorizationsId,
					userId, 
					userNames,
					file,
					fileName,
					fileSize,
					fileContentType,
					MySpaceConstants.AUTHORIZATIONS_STATUS_CANCELED,
					date);		
			if (result > 0) {
				authorization.setStatus(MySpaceConstants.AUTHORIZATIONS_STATUS_CANCELED);
				authorization.setCancelTime(date);
				AuthorizationBean bean = utils.populateAuthorizationBeanFromDB(authorization);
				/*
				 *  Send notifications.
				 */
				MySpaceNotificationsManager notificationManager = new MySpaceNotificationsManager();					
				List<Message> messages = notificationManager.notifyUsersForAuthorizationCancel(profile, userProfileBean, bean, date);
				if (messages != null) {
					List<Message> currentMessages = sessionBean.getMessages();
					if (currentMessages == null) {
						currentMessages = new ArrayList<Message>();						
					} 						
					currentMessages.addAll(messages);
					sessionBean.setMessages(currentMessages);
				}
				
				if (MySpacePortlet.logEvents) {
					// Register event in the log.
					AuditLogManagement alManagement = new AuditLogManagement();
					alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_CANCEL_AUTHORIZATION, "Оттегляне на овластяване за " + authorization.getAuthorizedNames() + " (" + authorizationsId.toString() + ")", null, remoteIP, false);
				}
			}
			return result;
		} catch (Exception e) { 
			Logger.log(Logger.ERROR_LEVEL, "AuthorizationsManagement : cancelAuthorization : " + e.getMessage());
			e.printStackTrace();			
			throw new Exception(bundle.getString("authorization.cancel.save.error"));
		}		
	}
	
	public int createAuthorization(MySpacePortletSessionBean sessionBean, InputStream file, String fileName, String fileContentType, long fileSize, String remoteIP, ResourceBundle bundle) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "AuthorizationsManagement : createAuthorization() start...");
		MySpaceUtils utils = new MySpaceUtils();
		UserProfileBean userProfileBean = sessionBean.getUserProfile();
		UserProfile profile = sessionBean.getProfile();
		HashMap<String, Container> sessionContainer = sessionBean.getContainer();
		Container container = sessionContainer.get(sessionBean.getCurrentPage());
		AuthorizationBean bean = container.getAuthorizationBean();
		String userId = userProfileBean.getCurrentUserUID();
		String userIdentifier = profile.getEik();
		int userType = Integer.parseInt(profile.getProfileType());
		String userNames = profile.getNameAndLegalForm();
		String validFrom = utils.formatDate(bean.getValidFromDate()) + " " + (bean.getValidFromTime() != null ? bean.getValidFromTime() : "00:00") + ":00";
		String validTo = utils.formatDate(bean.getValidToDate()) + " " + (bean.getValidToTime() != null ? bean.getValidToTime() + ":00" : "23:59:59");
		String systems = utils.getSystemsStringFromLoadedBean(bean.getLoadedSystemBeans());
		if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(profile.getProfileType())) {
			userNames = profile.getNames();
			userIdentifier = profile.getIdentifier();	
		}
		if (userNames == null) {
			userNames = userProfileBean.getCurrentUserCN();
		}
		if (userIdentifier == null) {
			userIdentifier = userProfileBean.getCurrentUserUID();
		}
		String orn = bean.getOrn();
		try {
			Date date = new Date();
			QueryExecution qe = new QueryExecution(); 
			int result = qe.createAuthorization(
					orn,
					userId, 
					userIdentifier,
					userType,
					userNames,
					bean.getAuthorizedType(),
					bean.getAuthorizedIdentifierType(),
					bean.getEncryptedAuthorizedIdentifier(),
					bean.getAuthorizedNames(),
					validFrom,
					validTo,
					systems,
					file,
					fileName,
					fileSize,
					fileContentType,
					MySpaceConstants.AUTHORIZATIONS_STATUS_ACTIVE,
					date);		
			if (result > 0) {		
				
				/*
				 *  Send notifications.
				 */
				MySpaceNotificationsManager notificationManager = new MySpaceNotificationsManager();					
				List<Message> messages = notificationManager.notifyUsersForAuthorizationCreated(profile, userProfileBean, bean, date);
				if (messages != null) {
					List<Message> currentMessages = sessionBean.getMessages();
					if (currentMessages == null) {
						currentMessages = new ArrayList<Message>();						
					} 						
					currentMessages.addAll(messages);
					sessionBean.setMessages(currentMessages);
				}
				
				/*
				 *  Log the event.
				 */
				if (MySpacePortlet.logEvents) {
					// Register event in the log.
					AuditLogManagement alManagement = new AuditLogManagement();
					alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_ADD_AUTHORIZATION, "Създаване на овластяване от " + userNames + " за " + bean.getAuthorizedNames(), null, remoteIP, false);
				}
			}
			return result;
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "AuthorizationsManagement : createAuthorization : " + e.getMessage());			
			e.printStackTrace();			
			throw new Exception(bundle.getString("authorization.save.error"));
		}		
	}
	
	public UserProfile[] getAdminUsersForLEProfile(String leProfileId) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "AuthorizationsManagement : getAdminUsersForLEProfile() start...");
		String profileId = leProfileId;
		UserProfileRole[] roles = null;
		try {
			// Find all users with admin roles for the authorized LE.
			roles = UserProfileRole.findAllByUserProfileIdAndAdminRole(profileId, null);
		} catch (FinderException e) {}
		if (roles != null && roles.length > 0) {
			Logger.log(Logger.DEBUG_LEVEL, "AuthorizationsManagement : getAdminUsersForLEProfile() roles.length=" + roles.length);
			String adminUserIds = "";
			for (int i = 0; i < roles.length; i++) {
				if (adminUserIds.length() > 0) {
					adminUserIds += ",";
				}
				adminUserIds += roles[i].getUserUID();
			}
			Logger.log(Logger.DEBUG_LEVEL, "AuthorizationsManagement : getAdminUsersForLEProfile() adminUserIds=" + adminUserIds);
			QueryExecution qe = new QueryExecution();
			// Load all personal profiles for the loaded admin userIds.
			return qe.loadAllProfilesAndPersonalProfilesByUserUIDProfileTypeIdentifierEik(null, MySpaceConstants.USER_PROFILE_TYPE_PERSONAL, null, null, adminUserIds, null);
		}
		return null;
	}
	
	public boolean hasDuplicateAuthorization(MySpacePortletSessionBean sessionBean, AuthorizationBean bean) {
		MySpaceUtils utils = new MySpaceUtils();
		UserProfile profile = sessionBean.getProfile();
		UserProfileBean userProfileBean = sessionBean.getUserProfile();
		String userIdentifier = profile.getEik();
		if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(profile.getProfileType())) {
			userIdentifier = profile.getIdentifier();	
		}
		if (userIdentifier == null) {
			userIdentifier = userProfileBean.getCurrentUserUID();
		}
		String validFrom = utils.formatDate(bean.getValidFromDate()) + " " + (bean.getValidFromTime() != null ? bean.getValidFromTime() : "00:00") + ":00";
		String validTo = utils.formatDate(bean.getValidToDate()) + " " + (bean.getValidToTime() != null ? bean.getValidToTime() : "00:00") + ":00";
		try {
			QueryExecution qe = new QueryExecution(); 
			return qe.hasDuplicateAuthorization(
					userIdentifier,
					bean.getEncryptedAuthorizedIdentifier(),
					validFrom,
					validTo,					
					MySpaceConstants.AUTHORIZATIONS_STATUS_ACTIVE,
					bean.getActionIds());		
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "AuthorizationsManagement : hasDuplicateAuthorization : " + e.getMessage());
			e.printStackTrace();
		}
		return false;
	}
	
}
