package com.ibs.myspace.portlet.management;

import java.util.HashMap;

import org.json.JSONException;
import org.json.JSONObject;

import com.ibs.myspace.communicator.ESBCommunicator;
import com.ibs.myspace.communicator.RegixCommunicator;
import com.ibs.myspace.portlet.bean.RegixEIKBean;
import com.ibs.myspace.portlet.bean.RegixPersonDataBean;
import com.ibs.myspace.portlet.bean.ValidUICResponse;
import com.ibs.myspace.portlet.utils.Logger;


public class RegixManagement {
	
	public ValidUICResponse loadByUIC(String eik) {
		Logger.log(Logger.DEBUG_LEVEL, "RegixManagement -> loadByUIC(" + eik + ")");
		try {
			Logger.log(Logger.DEBUG_LEVEL, "RegixManagement -> loadByUIC() call RegixCommunicator -> GetValidUICInfo(" + eik + ")...");
			RegixCommunicator communicator = new RegixCommunicator();			
			ValidUICResponse validUICResponse = communicator.GetValidUICInfo(eik);
			Logger.log(Logger.DEBUG_LEVEL, "RegixManagement -> loadByUIC() GetValidUICInfo Result: " + (validUICResponse != null ? validUICResponse.toString() : "No UIC loaded!"));	        
			return validUICResponse;
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	@Deprecated
	public RegixEIKBean loadByUICFromESB(String eik) {	
		Logger.log(Logger.DEBUG_LEVEL, "RegixManagement -> loadByUICFromESB(" + eik + ")");
		try {
			Logger.log(Logger.DEBUG_LEVEL, "RegixManagement -> loadByUICFromESB() call ESBCommunicator -> regixGetEIK(" + eik + ")...");
			ESBCommunicator communicator = new ESBCommunicator();			
			String result = communicator.regixGetEIK(eik);
			Logger.log(Logger.DEBUG_LEVEL, "RegixManagement -> loadByUICFromESB() regixGetEIK Result: " + result);	        
			try {
				if (result != null && result.trim().length() > 0) {
					JSONObject jsonObject = new JSONObject(result);
					// TODO we need a flag for NOT FOUDED UIC.	            		         
					RegixEIKBean regixEIKBean = new RegixEIKBean();
					regixEIKBean.setUic(jsonObject.get("UIC").toString());
					regixEIKBean.setCompany(jsonObject.get("Company").toString());
					regixEIKBean.setStatus(jsonObject.get("Status").toString());
					if (jsonObject.has("LegalForm")) {
						JSONObject joLegalForm = new JSONObject(jsonObject.get("LegalForm").toString()); 
						regixEIKBean.setLegalFormAbbr(joLegalForm.get("LegalFormAbbr").toString());
						regixEIKBean.setLegalFormName(joLegalForm.get("LegalFormName").toString());
					}
					return regixEIKBean;		            	
				}
			} catch (JSONException err){
				err.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public RegixPersonDataBean loadPersonDataByEGN(String egn) {	
		Logger.log(Logger.DEBUG_LEVEL, "RegixManagement -> loadByEGN(" + egn + ")");
		try {
			Logger.log(Logger.DEBUG_LEVEL, "RegixManagement -> loadByEGN() call ESBCommunicator -> regixGetPersonData(" + egn + ")...");
			ESBCommunicator communicator = new ESBCommunicator();			
	        String result = communicator.regixGetPersonData(egn);
	        Logger.log(Logger.DEBUG_LEVEL, "RegixManagement -> loadByEGN() regixGetPersonData Result: " + result);	        
	        try {
	        	if (result != null && result.trim().length() > 0) {
		        	JSONObject jsonObject = new JSONObject(result);
		        	JSONObject jo = null;
		        	HashMap<String, String> hm = null;
		        	RegixPersonDataBean regixPersonDataBean = new RegixPersonDataBean();
		        	regixPersonDataBean.setEgn(jsonObject.get("EGN").toString());
		        	regixPersonDataBean.setBirthDate(jsonObject.get("BirthDate").toString());
		        	regixPersonDataBean.setPlaceBirth(jsonObject.get("PlaceBirth").toString());
		        	if (jsonObject.has("PersonNames")) {
		        		jo = new JSONObject(jsonObject.get("PersonNames").toString()); 
		        		hm = new HashMap<>();
		        		hm.put("FirstName", jo.get("FirstName").toString());
		        		hm.put("SurName", jo.get("SurName").toString());
		        		hm.put("FamilyName", jo.get("FamilyName").toString());
		        		regixPersonDataBean.setPersonNames(hm);
		        	}
		        	if (jsonObject.has("LatinNames")) {
		        		jo = new JSONObject(jsonObject.get("LatinNames").toString()); 
		        		hm = new HashMap<>();
		        		if (jo.has("FirstName")) {
		        			hm.put("FirstName", jo.get("FirstName").toString());
		        			hm.put("SurName", jo.get("SurName").toString());
		        			hm.put("FamilyName", jo.get("FamilyName").toString());
		        			regixPersonDataBean.setLatinNames(hm);
		        		}
		        	}
	            	if (jsonObject.has("ForeignNames")) {
	            		jo = new JSONObject(jsonObject.get("ForeignNames").toString()); 
	            		hm = new HashMap<>();
	            		if (jo.has("FirstName")) {
	            			hm.put("FirstName", jo.get("FirstName").toString());
	            			hm.put("SurName", jo.get("SurName").toString());
	            			hm.put("FamilyName", jo.get("FamilyName").toString());
	            			regixPersonDataBean.setForeignNames(hm);
	            		}
	            	}
	            	if (jsonObject.has("Gender")) {
	            		jo = new JSONObject(jsonObject.get("Gender").toString()); 
	            		hm = new HashMap<>();
	            		hm.put("GenderCode", jo.get("GenderCode").toString());
	            		hm.put("GenderName", jo.get("GenderName").toString());
	            		regixPersonDataBean.setGender(hm);
	            	}
	            	if (jsonObject.has("Nationality")) {
	            		jo = new JSONObject(jsonObject.get("Nationality").toString()); 
	            		hm = new HashMap<>();
            			hm.put("NationalityCode", jo.get("NationalityCode").toString());
            			hm.put("NationalityName", jo.get("NationalityName").toString());
            			regixPersonDataBean.setNationality(hm);
	            	}
	            	return regixPersonDataBean;		            	
	        	}
	       } catch (JSONException err){
	           err.printStackTrace();
	       }
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
}
