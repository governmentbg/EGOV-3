package com.ibs.myspace.portlet.management;

import org.json.JSONException;
import org.json.JSONObject;

import com.ibs.myspace.communicator.ESBCommunicator;
import com.ibs.myspace.communicator.RegixCommunicator;
import com.ibs.myspace.portlet.bean.RegixEIKBean;
import com.ibs.myspace.portlet.bean.StateOfPlayResponse;
import com.ibs.myspace.portlet.bean.ValidPersonResponse;
import com.ibs.myspace.portlet.bean.ValidUICResponse;
import com.ibs.myspace.portlet.utils.Logger;


public class RegixManagement {
	private RegixCommunicator regixCommunicator = null;
	
	public RegixManagement() {
		regixCommunicator = new RegixCommunicator();
	}
	
	public ValidUICResponse searchByUICInTR(String eik) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "RegixManagement -> searchByUICInTR(" + eik + ") call RegixCommunicator -> GetValidUICInfo(" + eik + ")...");		
		ValidUICResponse validUICResponse = regixCommunicator.GetValidUICInfo(eik);
		Logger.log(Logger.DEBUG_LEVEL, "RegixManagement -> searchByUICInTR() GetValidUICInfo Result: " + (validUICResponse != null ? validUICResponse.toString() : "No UIC loaded!"));	        
		return validUICResponse;
	}
	
	public StateOfPlayResponse searchByUICInBulstat(String eik) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "RegixManagement -> searchByUICInBulstat(" + eik + ") call RegixCommunicator -> getStateOfPlay(" + eik + ")...");
		StateOfPlayResponse stateOfPlayResponse = regixCommunicator.getStateOfPlay(eik);
		Logger.log(Logger.DEBUG_LEVEL, "RegixManagement -> searchByUICInBulstat() getStateOfPlay Result: " + (stateOfPlayResponse != null ? stateOfPlayResponse.toString() : "No UIC loaded!"));	        
		return stateOfPlayResponse;
	}
	
	@Deprecated
	public RegixEIKBean loadByUICFromESB(String eik) {	
		Logger.log(Logger.DEBUG_LEVEL, "RegixManagement -> loadByUICFromESB(" + eik + ")");
		try {
			Logger.log(Logger.DEBUG_LEVEL, "RegixManagement -> loadByUICFromESB() call ESBCommunicator -> regixGetEIK(" + eik + ")...");
			ESBCommunicator communicator = new ESBCommunicator();			
			String result = communicator.regixGetEIK(eik);
			Logger.log(Logger.DEBUG_LEVEL, "RegixManagement -> loadByUICFromESB() regixGetEIK Result: " + result);	        
			try {
				if (result != null && result.trim().length() > 0) {
					JSONObject jsonObject = new JSONObject(result);
					// TODO we need a flag for NOT FOUDED UIC.	            		         
					RegixEIKBean regixEIKBean = new RegixEIKBean();
					regixEIKBean.setUic(jsonObject.get("UIC").toString());
					regixEIKBean.setCompany(jsonObject.get("Company").toString());
					regixEIKBean.setStatus(jsonObject.get("Status").toString());
					if (jsonObject.has("LegalForm")) {
						JSONObject joLegalForm = new JSONObject(jsonObject.get("LegalForm").toString()); 
						regixEIKBean.setLegalFormAbbr(joLegalForm.get("LegalFormAbbr").toString());
						regixEIKBean.setLegalFormName(joLegalForm.get("LegalFormName").toString());
					}
					return regixEIKBean;		            	
				}
			} catch (JSONException err){
				err.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public ValidPersonResponse getValidPersonByEGN(String egn) {	
		Logger.log(Logger.DEBUG_LEVEL, "RegixManagement -> getValidPersonByEGN(" + egn + ")");
		try {
			return regixCommunicator.getValidPersonRequest(egn);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public boolean UICisValid(ValidUICResponse validUICResponse) {
		return validUICResponse != null && validUICResponse.getUic() != null && (RegixCommunicator.UIC_STATUS_TYPE_NEW.equalsIgnoreCase(validUICResponse.getStatus()) || RegixCommunicator.UIC_STATUS_TYPE_RE_REGISTERED.equalsIgnoreCase(validUICResponse.getStatus()));
	}
	
}
