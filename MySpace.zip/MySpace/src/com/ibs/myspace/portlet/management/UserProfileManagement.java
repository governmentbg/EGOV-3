package com.ibs.myspace.portlet.management;

import java.io.InputStream;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.PortletRequest;
import javax.portlet.PortletResponse;
import javax.servlet.http.HttpServletRequest;

import com.egov.wcm.cache.EgovServiceProvider;
import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.portal.um.PumaController;
import com.ibm.portal.um.User;
import com.ibs.myspace.communicator.EJournalCommunicator;
import com.ibs.myspace.communicator.PumaCommunicator;
import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.MySpaceNotificationsManager;
import com.ibs.myspace.portlet.MySpacePortlet;
import com.ibs.myspace.portlet.MySpacePortletSessionBean;
import com.ibs.myspace.portlet.bean.Container;
import com.ibs.myspace.portlet.bean.EDeliveryProfileBean;
import com.ibs.myspace.portlet.bean.Message;
import com.ibs.myspace.portlet.bean.ProfileIdentifierBean;
import com.ibs.myspace.portlet.bean.UserProfileBean;
import com.ibs.myspace.portlet.db.DBTransaction;
import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.db.QueryExecution;
import com.ibs.myspace.portlet.dbo.HorizontalSystemRole;
import com.ibs.myspace.portlet.dbo.UserProfile;
import com.ibs.myspace.portlet.dbo.UserProfileAuditLog;
import com.ibs.myspace.portlet.dbo.UserProfileIdentifier;
import com.ibs.myspace.portlet.dbo.UserProfileInvitation;
import com.ibs.myspace.portlet.dbo.UserProfileMyFavorites;
import com.ibs.myspace.portlet.dbo.UserProfilePersonalParameters;
import com.ibs.myspace.portlet.dbo.UserProfileRef;
import com.ibs.myspace.portlet.dbo.UserProfileRequest;
import com.ibs.myspace.portlet.dbo.UserProfileRole;
import com.ibs.myspace.portlet.dbo.UserProfileXCRole;
import com.ibs.myspace.portlet.utils.AllCountries;
import com.ibs.myspace.portlet.utils.EncryptorAESGCM;
import com.ibs.myspace.portlet.utils.Logger;
import com.ibs.myspace.portlet.utils.MySpaceUtils;

public class UserProfileManagement {
	private MySpaceUtils utils = null;
	
	public UserProfileManagement() {
		utils = new MySpaceUtils();
	}
	
	public UserProfile[] loadAllProfilesByUserUID(String userUID) {
		try {
			return UserProfile.findAllByUserUID(userUID, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public UserProfile[] loadAllProfilesAndPersonalProfilesByUserUID(String userUID) {
		try {
			QueryExecution qe = new QueryExecution();
			return qe.loadAllProfilesAndPersonalProfilesByUserUIDProfileTypeIdentifierEik(userUID, null, null, null, null, null);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public int getMaxFavoriteServicesByUserUIDAndProfileType(String userUID, String type) {
		try {
			QueryExecution qe = new QueryExecution();
			return qe.getMaxFavoriteServicesByUserUIDAndProfileType(userUID, type, null);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return 0;
	}
	
	public UserProfile[] loadAllNotPersonalProfiles() {
		try {
			return UserProfile.findAllNotPersonalProfiles(MySpaceConstants.USER_PROFILE_TYPE_PERSONAL, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public UserProfile[] loadAllNotPersonalProfilesByIds(String userProfileIds) {
		try {
			return UserProfile.findAllNotPersonalProfilesByIds(userProfileIds, MySpaceConstants.USER_PROFILE_TYPE_PERSONAL, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public UserProfile[] loadAllNotPersonalProfilesByIdsAndStatus(String userProfileIds, String status) {
		try {
			return UserProfile.findAllNotPersonalProfilesByIdsAndStatus(userProfileIds, MySpaceConstants.USER_PROFILE_TYPE_PERSONAL, status, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public UserProfile[] loadAllProfilesByIds(String userProfileIds) {
		try {
			return UserProfile.findAllByIds(userProfileIds, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public UserProfile[] loadAllProfilesByIdsAndStatus(String userProfileIds, String status) {
		try {
			return UserProfile.findAllByIdsAndStatus(userProfileIds, status, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public UserProfileRequest loadNotApprovedUserProfileRequestByUserProfileIdAndEIK(String userProfileId, String eik) {
		try {
			QueryExecution qe = new QueryExecution();
			return qe.loadNotApprovedUserProfileRequestByUserProfileIdAndEIK(userProfileId, eik, null);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null; 
	}
	
	public UserProfileRequest loadNotApprovedUserProfileRequestByUserProfileIdEIKLeUserProfileIdAndName(String userProfileId, String eik, String leUserProfileId, String nameAndLegalForm) {
		try {
			QueryExecution qe = new QueryExecution();
			return qe.loadNotApprovedUserProfileRequestByUserProfileIdEIKLeUserProfileIdAndName(userProfileId, eik, leUserProfileId, nameAndLegalForm, null);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null; 
	}
	
	public UserProfileRequest[] loadAllNotApprovedUserProfileRequestsByUserProfileId(String userProfileId) {
		try {
			QueryExecution qe = new QueryExecution();
			return qe.loadAllNotApprovedUserProfileRequestsByUserProfileId(userProfileId, null);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null; 
	}
	
	public UserProfileRole[] loadAllProfileRolesAndProfilesByUserUID(String userUID) {
		try {
			QueryExecution qe = new QueryExecution();
			return qe.loadAllProfileRolesAndProfilesByUserUID(userUID, null);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null; 
	}
	
	public UserProfile loadProfileByUserUIDAndType(String userUID, String type) {
		try {
			return UserProfile.findByUserUIDAndType(userUID, type, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public UserProfile loadProfileById(String userProfileId) {
		if (userProfileId == null || userProfileId.trim().length() == 0) return null;
		try {
			return UserProfile.findById(userProfileId, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public UserProfile loadUserProfileByTypeIdentifierAndName(int type, String identifier, String name) {
		try {
			QueryExecution qe = new QueryExecution();
			return qe.loadUserProfileByTypeIdentifierAndName(type, identifier, name, null);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public UserProfile loadUserProfileByTypeIdentifierOrName(int type, String identifier, String name) {
		try {
			QueryExecution qe = new QueryExecution();
			return qe.loadUserProfileByTypeIdentifierOrName(type, identifier, name, null);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public UserProfileRole loadRolesByProfileIdAndUserUID(String userProfileId, String userUID) {
		try {
			return UserProfileRole.findByProfileIdAndUserUID(userProfileId, userUID, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public UserProfileRole loadRolesById(String id) {
		try {
			return UserProfileRole.findById(id, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public UserProfileRole[] loadAllProfileRolesByUserUID(String userUID) {
		try {
			return UserProfileRole.findAllByUserUID(userUID, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public UserProfileRole[] loadAllProfileRolesByProfileId(String profileId) {
		try {
			return UserProfileRole.findAllByUserProfileId(profileId, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public UserProfilePersonalParameters loadPersonalParametersByProfileId(String userProfileId) {
		try {
			return UserProfilePersonalParameters.findByUserProfileId(userProfileId, null);
		} catch (FinderException e) {
		} catch (Exception e) { 
			e.printStackTrace();
		} 
		return null;
	}
	
	public UserProfileInvitation loadInvitationById(String invitationId) {
		try {
			return UserProfileInvitation.findById(invitationId, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public UserProfileInvitation[] loadAllInvitationsByProfileId(String profileId) {
		try {
			return UserProfileInvitation.findAllByUserProfileId(profileId, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}

	public UserProfileIdentifier[] loadAllProfileIdentifiersByProfileId(String profileId) {
		try {
			return UserProfileIdentifier.findAllByUserProfileId(profileId, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public UserProfileIdentifier loadProfileIdentifierById(String profileIdentifierId) {
		try {
			return UserProfileIdentifier.findById(profileIdentifierId, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public UserProfileRef loadProfileRefByUserProfileId(String userProfileId) {
		try {
			return UserProfileRef.findByUserProfileId(userProfileId, null);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null; 
	}
	
	public UserProfileRef[] loadAllProfileRefsByParentUserProfileId(String userProfileId) {
		try {
			return UserProfileRef.findAllByParentUserProfileId(userProfileId, null);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null; 
	}
	
	public UserProfileRef[] loadAllProfileRefsByParentUserProfileIds(String userProfileIds) {
		try {
			return UserProfileRef.findAllByParentUserProfileIdsIn(userProfileIds, null);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null; 
	}

	
 	public UserProfile autoCreateProfile(UserProfileBean userProfileBean) {
 		long currentTime = System.currentTimeMillis(); 				
		UserProfile profile = null;
		try {
			// check for existing, if we are here - this should not found anything, but just for save.
			profile = UserProfile.findByUserUIDAndType(userProfileBean.getCurrentUserUID(), MySpaceConstants.USER_PROFILE_TYPE_PERSONAL, null);
		} catch (Exception e) {}
		if (profile == null || profile.getId() == null) {
			Logger.log(Logger.DEBUG_LEVEL, "autoCreateProfile() profile not found in db, let's create it...");
			profile = new UserProfile();
			profile.setUserUID(userProfileBean.getCurrentUserUID());				
			profile.setIdentifier(userProfileBean.getCurrentUserIdentifier());				
			profile.setNames(userProfileBean.getCurrentUserCN());
			profile.setProfileType(MySpaceConstants.USER_PROFILE_TYPE_PERSONAL);
			profile.setDateCreated(MySpaceUtils.timeMillisToTimestamp(currentTime));
			profile.setDateModified(MySpaceUtils.timeMillisToTimestamp(currentTime));
			profile.setStatus(MySpaceConstants.USER_PROFILE_STATUS_NOT_CONFIRMED);
			Logger.log(Logger.DEBUG_LEVEL, "autoCreateProfile() [new] userId=" + profile.getUserUID());
			Logger.log(Logger.DEBUG_LEVEL, "autoCreateProfile() [new] identifier=" + profile.getIdentifier());
			Logger.log(Logger.DEBUG_LEVEL, "autoCreateProfile() [new] names=" + profile.getNames());
			Logger.log(Logger.DEBUG_LEVEL, "autoCreateProfile() [new] type=" + profile.getProfileType());
			Logger.log(Logger.DEBUG_LEVEL, "autoCreateProfile() [new] status=" + profile.getStatus());
			try {
				profile.create();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
		return profile;
 	}
	
	public String[] createServiceProviderProfileRequest(MySpacePortletSessionBean sessionBean, String eik, String nameAndLegalForm, String orderNumber, InputStream orderDocument, String orderDocumentName, String orderDocumentContentType, long orderDocumentSize, String remoteIP, ResourceBundle bundle) throws Exception {
		long currentTime = System.currentTimeMillis();
		UserProfileBean userProfileBean = sessionBean.getUserProfile();
		UserProfile profile = sessionBean.getProfile();
		if (profile == null || profile.getId() == null) {
			Logger.log(Logger.DEBUG_LEVEL, "createServiceProviderProfileRequest() profile is null!");
			// Try to create profile.
			try {
				// check for existing.
				profile = UserProfile.findByUserUIDAndType(userProfileBean.getCurrentUserUID(), MySpaceConstants.USER_PROFILE_TYPE_PERSONAL, null);
			} catch (FinderException e) {}
			if (profile == null || profile.getId() == null) {
				Logger.log(Logger.DEBUG_LEVEL, "createServiceProviderProfileRequest() profile not found in db, let's create it...");
				profile = new UserProfile();
				profile.setUserUID(userProfileBean.getCurrentUserUID());				
				profile.setIdentifier(userProfileBean.getCurrentUserIdentifier());				
				profile.setNames(userProfileBean.getCurrentUserCN());
				profile.setProfileType(MySpaceConstants.USER_PROFILE_TYPE_PERSONAL);
				profile.setDateCreated(MySpaceUtils.timeMillisToTimestamp(currentTime));
				profile.setDateModified(MySpaceUtils.timeMillisToTimestamp(currentTime));
				profile.setStatus(MySpaceConstants.USER_PROFILE_STATUS_ACTIVE);
				Logger.log(Logger.DEBUG_LEVEL, "createServiceProviderProfileRequest() [new] userId=" + profile.getUserUID());
				Logger.log(Logger.DEBUG_LEVEL, "createServiceProviderProfileRequest() [new] identifier=" + profile.getIdentifier());
				Logger.log(Logger.DEBUG_LEVEL, "createServiceProviderProfileRequest() [new] names=" + profile.getNames());
				Logger.log(Logger.DEBUG_LEVEL, "createServiceProviderProfileRequest() [new] type=" + profile.getProfileType());
				Logger.log(Logger.DEBUG_LEVEL, "createServiceProviderProfileRequest() [new] status=" + profile.getStatus());
				profile.create();
				sessionBean.setProfile(profile);
				sessionBean.setUserProfileIdPersonal(profile.getId());
			}			
		} else if (!MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(profile.getProfileType())) {
			// Load "personal" profile type, as this is the type we want to refer to.
			try {
				// check for existing.
				profile = UserProfile.findByUserUIDAndType(userProfileBean.getCurrentUserUID(), MySpaceConstants.USER_PROFILE_TYPE_PERSONAL, null);
			} catch (FinderException e) {}
		}
		DBTransaction transaction = null;
		try {			
			transaction = new DBTransaction();
			//Create profile request.
			QueryExecution qe = new QueryExecution(); 
			String result = qe.createUserProfileRequest(
					profile.getId(), 
					MySpaceConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER, 
					eik, 
					nameAndLegalForm, 
					orderNumber, 
					orderDocument, 
					orderDocumentName, 
					orderDocumentContentType, 
					orderDocumentSize, 
					null, 
					MySpaceUtils.timeMillisToTimestamp(currentTime), 
					profile.getUserUID(), 
					profile.getNames(), 
					null,
					null,
					null,
					transaction
					);
			if (result == null) {
				throw new Exception(bundle.getString("profile.save.error"));
			}
			transaction.commit();			
			UserProfile[] profiles = loadAllProfilesByUserUID(userProfileBean.getCurrentUserUID());
			sessionBean.setProfiles(profiles);			
			UserProfileRequest[] requests = loadAllNotApprovedUserProfileRequestsByUserProfileId(profile.getId());
			sessionBean.setRequests(requests);
			String[] response = new String[6];
			response[0] = result;
			response[1] = profile.getId();
			response[2] = profile.getNames();
			response[3] = MySpaceUtils.timeMillisToTimestamp(currentTime);	
			response[4] = eik;	
			response[5] = nameAndLegalForm;	
			
			/*
			 * Register log event.
			 */
			if (MySpacePortlet.logEvents) {					
				AuditLogManagement alManagement = new AuditLogManagement();
				alManagement.sendEvent(sessionBean.getUserProfile().getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_REQUEST_PROFILE, "Заявка за добавяне на профил на ЮЛ - " + nameAndLegalForm + " (" + eik + ")", null, remoteIP, false);
			}
			return response;
		} catch (Exception e) {
			System.out.println("UserProfileManagement : createServiceProviderProfileRequest : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("UserProfileManagement : createServiceProviderProfileRequest : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			throw new Exception(bundle.getString("profile.save.error"));
		}		
	}
	
	public HashMap<String, UserProfile> loadIsMemberOfProfile(MySpacePortletSessionBean sessionBean) {
		UserProfileBean userProfileBean = sessionBean.getUserProfile();
		HashMap<String, UserProfile> isMemberOfProfile = new HashMap<>();
		try {
			// Load all roles, that user has been assign to.
			UserProfileRole[] userProfileRoles = UserProfileRole.findAllByUserUID(userProfileBean.getCurrentUserUID(), null);
			if (userProfileRoles != null && userProfileRoles.length > 0) {
				String userProfileIds = "";
				for (int i = 0; i < userProfileRoles.length; i++) {
					if (userProfileIds.trim().length() > 0) {
						userProfileIds += ",";
					}
					userProfileIds += userProfileRoles[i].getUserProfileId();
				}
				UserProfile[] userProfiles = loadAllNotPersonalProfilesByIds(userProfileIds);
				if (userProfiles != null) {
					for (int i = 0; i < userProfiles.length; i++) {
						isMemberOfProfile.put(userProfiles[i].getEik(), userProfiles[i]);
					}
				}
			}
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		}
		return isMemberOfProfile;
	}
	
	public ArrayList<String[]> syncEDeliveryProfiles(MySpacePortletSessionBean sessionBean, String eik, String remoteIP, ResourceBundle bundle) throws Exception {
		long currentTime = System.currentTimeMillis();
		UserProfileBean userProfileBean = sessionBean.getUserProfile();
		UserProfile profile = sessionBean.getProfile();
		EDeliveryProfileBean[] eDeliveryProfileBeans = sessionBean.geteDeliveryProfileBeans();
		boolean useMsg = false;
		HashMap<String, UserProfile> allNotPersonalProfilesHm = new HashMap<>();
		HashMap<String, UserProfile> allNotPersonalProfilesEIKHm = new HashMap<>();
		HashMap<String, String> isMemberOfProfile = new HashMap<>();
		ArrayList<String[]> auditLogs = null;
		ArrayList<String[]> requestResults = null;
		UserProfile tmpProfile = null;
		DBTransaction transaction = null;
		
		try {			
			transaction = new DBTransaction();
			UserProfileRole[] userProfileRoles = null;
			
			// Load all notPersonalProfiles in the system.
			UserProfile[] allNotPersonalProfiles = loadAllNotPersonalProfiles();
			if (allNotPersonalProfiles != null && allNotPersonalProfiles.length > 0) {				
				for (int i = 0; i < allNotPersonalProfiles.length; i++) {
					allNotPersonalProfilesHm.put(allNotPersonalProfiles[i].getId(), allNotPersonalProfiles[i]);
					allNotPersonalProfilesEIKHm.put(allNotPersonalProfiles[i].getEik(), allNotPersonalProfiles[i]);
				}
			}
			try {
				// Load all roles, that user has been assign to.
				userProfileRoles = UserProfileRole.findAllByUserUID(userProfileBean.getCurrentUserUID(), transaction);
				if (userProfileRoles != null && userProfileRoles.length > 0) {
					tmpProfile = null;
					for (int i = 0; i < userProfileRoles.length; i++) {
						tmpProfile = allNotPersonalProfilesHm.get(userProfileRoles[i].getUserProfileId());
						if (tmpProfile != null) {							
							isMemberOfProfile.put(tmpProfile.getEik(), "1");
						}
					}
				}
			} catch (FinderException e) {
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (eDeliveryProfileBeans == null || eDeliveryProfileBeans.length == 0) {
				useMsg = true;
				throw new Exception(bundle.getString("profile.no.profiles.found.to.sync.error"));
			}
			
			tmpProfile = null;
			UserProfileRole userProfileRole = null;
			QueryExecution qe = null;
			String tmpEIK = null;
			String tmpNameAndLegalForm = null;
			String[] auditData = null;
			String[] requestResponse = null;
			auditLogs = new ArrayList<>();
			String result = null;
			String email = sessionBean.getPersonalParameters() != null ? sessionBean.getPersonalParameters().getEmail() : null;
			// Loop all profiles loaded from eDelivery.
			for (int i = 0; i < eDeliveryProfileBeans.length; i++) {
				tmpEIK = eDeliveryProfileBeans[i].getEik();
				// If we have passed parameter "eik", so we are in sync "single" mode.
				if (eik != null && !eik.equals(tmpEIK)) continue;
				tmpNameAndLegalForm = eDeliveryProfileBeans[i].getName();
				auditData = new String[2];
				// If not member of existing profile, we have to add it.
				if (isMemberOfProfile.get(tmpEIK) == null) {
					tmpProfile = allNotPersonalProfilesEIKHm.get(tmpEIK);
					// If EIK exists in the system, we assign role to the user for founded profile.
					if (tmpProfile != null) {
						auditData[0] = MySpaceConstants.EVENT_LOG_PORTAL_ADD_USER_TO_PROFILE;						
						userProfileRole = new UserProfileRole();
						userProfileRole.setUserProfileId(tmpProfile.getId());
						userProfileRole.setUserUID(userProfileBean.getCurrentUserUID());
						userProfileRole.setDateCreated(MySpaceUtils.timeMillisToTimestamp(currentTime));
						// For "Service Supplier" profile type, we assign the user "service manager" role.
						if (MySpaceConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER.equals(tmpProfile.getProfileType())) {
							userProfileRole.setServiceManager(MySpaceConstants.USER_PROFILE_ROLE_SELECTED);
							auditData[1] = "Добавяне на потребител " + profile.getNames() + " към профил \"" + tmpProfile.getNameAndLegalForm() + "\" с роли: Услуги";							
						} // For "Legal Entity" profile type, we we assign the user "user" role.
						else if (MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY.equals(tmpProfile.getProfileType()) 
								|| MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY_AL2.equals(tmpProfile.getProfileType())) {							
							userProfileRole.setUser(MySpaceConstants.USER_PROFILE_ROLE_SELECTED);
							auditData[1] = "Добавяне на потребител " + profile.getNames() + " към профил \"" + tmpProfile.getNameAndLegalForm() + "\" с роли: Потребител";
						}
						userProfileRole.setEmail(email);
						userProfileRole.setConfirm(MySpaceConstants.USER_PROFILE_CHANGE_EMAIL_CONFIRMED);
						userProfileRole.create(transaction);
						if (requestResults == null) {
							requestResults = new ArrayList<String[]>();
						}
						requestResponse = new String[1];
						// We add an empty array with length 1, to flag that the profile was assigned.
						requestResults.add(requestResponse);
					} // EIK not found in the system -> we create profile request. 
					else {						
						auditData[0] = MySpaceConstants.EVENT_LOG_PORTAL_REQUEST_PROFILE;
						EgovServiceProvider provider = EgovWCMCache.getServiceProviderByEIK().get(tmpEIK);
						qe = new QueryExecution(); 
						if (requestResults == null) {
							requestResults = new ArrayList<String[]>();
						}
						requestResponse = new String[6];
						// Check we have EIK in the system - create 
						if (provider != null) {
							// Check we already have "request access" to that provider.
							String type = MySpaceConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER;
							if (provider.getAuthoringTemplateName() != null && provider.getAuthoringTemplateName().equalsIgnoreCase(EgovWCMCache.getATServiceProviderArticle1Paragraph2().getName())) {
								type = MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY_AL2;
							}
							tmpNameAndLegalForm = provider.getTitle();
							result = qe.createUserProfileRequest(profile.getId(), type, tmpEIK, tmpNameAndLegalForm, null, null, null, null, 0, null, MySpaceUtils.timeMillisToTimestamp(currentTime), profile.getUserUID(), profile.getNames(), null, null, null, transaction);
							if (result == null) {
								throw new Exception(bundle.getString("profile.sync.save.error"));
							}
							requestResponse[0] = result;
							auditData[1] = "Заявка за добавяне на профил на ЮЛ - " + tmpNameAndLegalForm +  " (" + tmpEIK + ")";
						} // Create Legal Entity Request. 
						else {
							result = qe.createUserProfileRequest(profile.getId(), MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY, tmpEIK, tmpNameAndLegalForm, null, null, null, null, 0, null, MySpaceUtils.timeMillisToTimestamp(currentTime), profile.getUserUID(), profile.getNames(), null, null, null, transaction);
							if (result == null) {
								throw new Exception(bundle.getString("profile.sync.save.error"));
							}	
							requestResponse[0] = result;
							auditData[1] = "Заявка за добавяне на профил на ЮЛ - " + tmpNameAndLegalForm + " (" + tmpEIK + ")";
						}
						requestResponse[1] = profile.getId();
						requestResponse[2] = profile.getNames();
						requestResponse[3] = MySpaceUtils.timeMillisToTimestamp(currentTime);
						requestResponse[4] = tmpEIK;
						requestResponse[5] = tmpNameAndLegalForm;
						requestResults.add(requestResponse);
					}
					auditLogs.add(auditData);
				}
			}			
			transaction.commit();			
			UserProfile[] profiles = loadAllProfilesByUserUID(userProfileBean.getCurrentUserUID());
			sessionBean.setProfiles(profiles);			
			UserProfileRequest[] requests = loadAllNotApprovedUserProfileRequestsByUserProfileId(profile.getId());
			sessionBean.setRequests(requests);

			// Register event(s) in the log.
			AuditLogManagement alManagement = new AuditLogManagement();
			if (auditLogs != null && auditLogs.size() > 0) {
				if (MySpacePortlet.logEvents) {
					for (int i = 0; i < auditLogs.size(); i++) {
						auditData = auditLogs.get(i);
						alManagement.sendEvent(userProfileBean.getCurrentUserUID(), auditData[0], auditData[1], null, remoteIP, false);
					}
				}
				auditLogs.clear();				
			}
			allNotPersonalProfilesHm.clear();
			allNotPersonalProfilesEIKHm.clear();
			isMemberOfProfile.clear();
			return requestResults;
		} catch (Exception e) {
			System.out.println("UserProfileManagement : syncEDeliveryProfiles : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("UserProfileManagement : syncEDeliveryProfiles : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			if (useMsg) {
				throw new Exception(e.getMessage());
			}
			throw new Exception(bundle.getString("profile.sync.error"));
		}		
	}
	
	public String[] createLegalEntityProfileRequest(MySpacePortletSessionBean sessionBean, UserProfile profile, String eik, String nameAndLegalForm, String profileType, InputStream document, String documentName, String documentContentType, long documentSize, String profileStructureType, String profileStructureTypeOther, String leUserProfileId, String remoteIP, ResourceBundle bundle) throws Exception {
		long currentTime = System.currentTimeMillis();
		UserProfileBean userProfileBean = sessionBean.getUserProfile();
		DBTransaction transaction = null;
		try {		
			if ("-1".equals(profileStructureType)) {
				profileStructureType = null;
			} else {
				profileStructureTypeOther = null;
			}
			transaction = new DBTransaction();
			//Create profile request.
			QueryExecution qe = new QueryExecution(); 
			String result = qe.createUserProfileRequest(
					profile.getId(), 
					profileType, 
					eik, 
					nameAndLegalForm, 
					null, 
					document, 
					documentName, 
					documentContentType,  
					documentSize, 
					null, 
					MySpaceUtils.timeMillisToTimestamp(currentTime), 
					profile.getUserUID(), 
					profile.getNames(), 
					profileStructureType,
					profileStructureTypeOther,
					leUserProfileId,
					transaction
					);
			if (result == null) {
				throw new Exception(bundle.getString("profile.save.error"));
			}
			transaction.commit();			
			UserProfile[] profiles = loadAllProfilesByUserUID(userProfileBean.getCurrentUserUID());
			sessionBean.setProfiles(profiles);			
			UserProfileRequest[] requests = loadAllNotApprovedUserProfileRequestsByUserProfileId(profile.getId());
			sessionBean.setRequests(requests);
			String[] response = new String[6];
			response[0] = result;
			response[1] = profile.getId();
			response[2] = profile.getNames();
			response[3] = MySpaceUtils.timeMillisToTimestamp(currentTime);
			response[4] = eik; 
			response[5] = nameAndLegalForm;		
			/*
			 * Register log event.
			 */
			if (MySpacePortlet.logEvents) {
				AuditLogManagement alManagement = new AuditLogManagement();
				if (leUserProfileId != null) {
					alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_REQUEST_PROFILE, "Заявка за добавяне на профил на ЮЛ с РЕИК към профил - " + nameAndLegalForm + " (" + eik + ")", null, remoteIP, false);
				} else {
					alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_REQUEST_PROFILE, "Заявка за добавяне на профил на ЮЛ - " + nameAndLegalForm + " (" + eik + ")", null, remoteIP, false);
				}
			}
			return response;
		} catch (Exception e) {
			System.out.println("UserProfileManagement : createLegalEntityProfileRequest : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("UserProfileManagement : createLegalEntityProfileRequest : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			throw new Exception(bundle.getString("profile.save.error"));
		}		
	}

	/**
	* Save profile personalization form. 
	* 
	* @param sessionBean			Portlet session bean.
	* @param userProfileBean		User profile session bean.
	* @param request				Action request.
	* @param httpServletRequest		HTTP Servlet Request.
	* @param remoteIP				Remote IP address.
	* @param bundle					resource bundle.
	* @throws Exception          	If exception occurs. 
	*
	*/
	public void saveProfilePersonalization(MySpacePortletSessionBean sessionBean, UserProfileBean userProfileBean, ActionRequest request, HttpServletRequest httpServletRequest, String remoteIP, ResourceBundle bundle) throws Exception {		
		DBTransaction transaction = null;
		String customSideNavPages = request.getParameter("customSideNavPages");		
		String maxFavouriteServices = request.getParameter("maxFavouriteServices");	
		Logger.log(Logger.DEBUG_LEVEL, "saveProfilePersonlaization() -> customSideNavPages = " + customSideNavPages);
		Logger.log(Logger.DEBUG_LEVEL, "saveProfilePersonlaization() -> maxFavouriteServices = " + maxFavouriteServices);
		long currentTime = System.currentTimeMillis();		
		try {
			transaction = new DBTransaction();
			UserProfile userProfile = sessionBean.getProfile();
			UserProfilePersonalParameters personalParameters = userProfile.getPersonalParameters();
			if (customSideNavPages != null && customSideNavPages.trim().length() == 0) {
				customSideNavPages = null;
			}
			userProfile.setCustomSideNav(customSideNavPages);
			userProfile.setDateModified(MySpaceUtils.timeMillisToTimestamp(currentTime));
			userProfile.store(transaction);
			int currentMaxFavoriteServices = 10;
			int newMaxFavoriteServices = 10;
			try {
				newMaxFavoriteServices = Integer.parseInt(maxFavouriteServices);
			} catch (Exception e) {}
			if (personalParameters != null && personalParameters.getMaxFavoriteServices() != null) {
				try {
					currentMaxFavoriteServices = Integer.parseInt(personalParameters.getMaxFavoriteServices());
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
					
			if (currentMaxFavoriteServices != newMaxFavoriteServices) {
				try {
					if (newMaxFavoriteServices < currentMaxFavoriteServices) {
						MyFavoriteServicesManagement myFavoriteServicesManagement = new MyFavoriteServicesManagement();
						myFavoriteServicesManagement.trimMyFavorites(MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equalsIgnoreCase(userProfile.getProfileType()) ? userProfile.getUserUID() : userProfile.getEik(), newMaxFavoriteServices);
						if (httpServletRequest != null) {
							if (httpServletRequest.getSession() != null) {
								// Update session object.
								ArrayList<String> myFavoritesInSession = new ArrayList<String>();
								UserProfileMyFavorites[] myFavorites = myFavoriteServicesManagement.loadAllContentUUIDsByUserUID(MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equalsIgnoreCase(userProfile.getProfileType()) ? userProfile.getUserUID() : userProfile.getEik());
								if (myFavorites != null && myFavorites.length > 0) {
									for (int i = 0; i < myFavorites.length; i++) {
										myFavoritesInSession.add(myFavorites[i].getContentUUID());
									}
								}
								Logger.log(Logger.DEBUG_LEVEL, "MyFavoriteServices -> doGet() loaded from DB = " + myFavoritesInSession.size());
								httpServletRequest.getSession().setAttribute(MySpaceConstants._USER_PROFILE_MY_FAVORITE_SERVICES_SESSION_KEY, myFavoritesInSession);
							}
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				personalParameters.setMaxFavoriteServices(maxFavouriteServices);
				personalParameters.store(transaction);
				userProfile.setPersonalParameters(personalParameters);
			}
			transaction.commit();
			
			// Update session data.
			sessionBean.setProfile(userProfile);
			sessionBean.setPersonalParameters(personalParameters);
			
			if (MySpacePortlet.logEvents) {
				// Register event in the log.
				AuditLogManagement alManagement = new AuditLogManagement();
				alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_PROFILE_PERSONALIZATION, "Персонализация на персонален профил", null, remoteIP, false);
			}
		} catch (Exception e) {
			System.out.println("UserProfileManagement : saveProfilePersonalization : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("UserProfileManagement : saveProfilePersonalization : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			throw new Exception(bundle.getString("profile.save.error"));
		}
	}

	/**
	* Save profile form. 
	* 
	* @param sessionBean			Portlet session bean.
	* @param userProfileBean		User profile session bean.
	* @param request				Action request.
	* @param remoteIP				Remote IP address.
	* @param bundle					resource bundle.
	* @throws Exception          	If exception occurs. 
	*
	*/
	public int saveProfile(MySpacePortletSessionBean sessionBean, UserProfileBean userProfileBean, ActionRequest request, ActionResponse response, String remoteIP, ResourceBundle bundle) throws Exception {		
		DBTransaction transaction = null;
		String userProfileId = request.getParameter("userProfileId");		
		String personalParametersId = request.getParameter("personalParametersId");		
		String profileType = request.getParameter("profileType");		
		long currentTime = System.currentTimeMillis();
		boolean createProfile = false;
		boolean createPersonalParameters = false;
		//boolean hasNamesChange = false;
		boolean hasEmailChange = false;
		int result = 1;
		Map<String, String> userInputMap = null;
		try {
			transaction = new DBTransaction();
			UserProfile userProfile = null;
			UserProfilePersonalParameters personalParameters = null;
			if (userProfileId != null && userProfileId.trim().length() > 0) {
				try {
					userProfile = UserProfile.findById(userProfileId, transaction);
				} catch (FinderException e) {
				} catch (Exception e) {
					e.printStackTrace();
				}
				if (userProfile == null) {
					throw new Exception(bundle.getString("profile.with.id.was.not.found") + " " + userProfileId);
				}
			}
			if (personalParametersId != null && personalParametersId.trim().length() > 0) {
				try {
					personalParameters = UserProfilePersonalParameters.findById(personalParametersId, transaction);
				} catch (FinderException e) {
				} catch (Exception e) {
					e.printStackTrace();
				}
				if (personalParameters == null) {
					throw new Exception(bundle.getString("personal.parameters.with.id.was.not.found") + " " + personalParametersId);
				}
			}
			if (userProfile == null) {
				userProfile = new UserProfile();
				createProfile = true;
			}
			if (personalParameters == null) {
				personalParameters = new UserProfilePersonalParameters();
				createPersonalParameters = true;
			}
			if (createProfile) {
				userProfile.setUserUID(userProfileBean.getCurrentUserUID());
				userProfile.setNames(userProfileBean.getCurrentUserCN());
				userProfile.setIdentifier(userProfileBean.getCurrentUserIdentifier() != null ? userProfileBean.getCurrentUserIdentifier() : request.getParameter("identifier"));				
				userProfile.setProfileType(profileType);
				userProfile.setDateCreated(MySpaceUtils.timeMillisToTimestamp(currentTime));
				userProfile.setStatus(MySpaceConstants.USER_PROFILE_STATUS_ACTIVE);
			}
			userProfile.setDateModified(MySpaceUtils.timeMillisToTimestamp(currentTime));
			
			Logger.log(Logger.DEBUG_LEVEL, "saveProfile() -> userId = " + userProfile.getUserUID());
			Logger.log(Logger.DEBUG_LEVEL, "saveProfile() -> egn = " + userProfile.getIdentifier());
			Logger.log(Logger.DEBUG_LEVEL, "saveProfile() -> type = " + userProfile.getProfileType());			
			Logger.log(Logger.DEBUG_LEVEL, "saveProfile() -> names = " + userProfile.getNames());
			Logger.log(Logger.DEBUG_LEVEL, "saveProfile() -> dateCreated = " + userProfile.getDateCreated());
			Logger.log(Logger.DEBUG_LEVEL, "saveProfile() -> dateModified = " + userProfile.getDateModified());
			Logger.log(Logger.DEBUG_LEVEL, "saveProfile() -> status = " + userProfile.getStatus());
			
			if (createProfile) {
				Logger.log(Logger.DEBUG_LEVEL, "saveProfile() -> creating profile...");
				userProfile.create(transaction);
			} else {
				Logger.log(Logger.DEBUG_LEVEL, "saveProfile() -> updating profile... [" + userProfile.getId() + "]");
				userProfile.store(transaction);
			}
			
			if (createPersonalParameters) {
				personalParameters.setUserProfileId(userProfile.getId());				
			}
			
			String generalConsent = request.getParameter("generalConsent");
			String consentToUseAddress = request.getParameter("consentToUseAddress");
			String ekatte = request.getParameter("ekatte");
			String addressDescription = request.getParameter("addressDescription");
			String mailBox = request.getParameter("mailBox");
			String zipCode = request.getParameter("zipCode");
			String consentToUsePhone = request.getParameter("consentToUsePhone");
			String phoneNumber = request.getParameter("phoneNumber");
			String consentToUseEmail = request.getParameter("consentToUseEmail");
			String personalEmail = request.getParameter("email");
			
			Logger.log(Logger.DEBUG_LEVEL, "saveProfile() -> generalConsent = " + generalConsent);
			Logger.log(Logger.DEBUG_LEVEL, "saveProfile() -> consentToUseAddress = " + consentToUseAddress);
			Logger.log(Logger.DEBUG_LEVEL, "saveProfile() -> ekatte = " + ekatte);
			Logger.log(Logger.DEBUG_LEVEL, "saveProfile() -> addressDescription = " + addressDescription);
			Logger.log(Logger.DEBUG_LEVEL, "saveProfile() -> mailBox = " + mailBox);
			Logger.log(Logger.DEBUG_LEVEL, "saveProfile() -> zipCode = " + zipCode);
			Logger.log(Logger.DEBUG_LEVEL, "saveProfile() -> consentToUsePhone = " + consentToUsePhone);
			Logger.log(Logger.DEBUG_LEVEL, "saveProfile() -> phoneNumber = " + phoneNumber);
			Logger.log(Logger.DEBUG_LEVEL, "saveProfile() -> consentToUseEmail = " + consentToUseEmail);
			Logger.log(Logger.DEBUG_LEVEL, "saveProfile() -> email = " + personalEmail);
			
			// If general consent is NO, we set all other options to NO too.
			if (MySpaceConstants.USER_PROFILE_CONSENT_NO.equals(generalConsent)) {
				consentToUseAddress = MySpaceConstants.USER_PROFILE_CONSENT_NO;
				consentToUsePhone = MySpaceConstants.USER_PROFILE_CONSENT_NO;
				consentToUseEmail = MySpaceConstants.USER_PROFILE_CONSENT_NO;
			}
			
			personalParameters.setConsentToUseAddress(consentToUseAddress);
			personalParameters.setEkatte(ekatte != null && ekatte.trim().length() > 0 ? ekatte : null);
			personalParameters.setAddressDescription(addressDescription);
			personalParameters.setMailBox(mailBox);
			personalParameters.setZipCode(zipCode);
			personalParameters.setConsentToUsePhone(consentToUsePhone);
			personalParameters.setPhoneNumber(phoneNumber);
			personalParameters.setConsentToUseEmail(consentToUseEmail);
			personalParameters.setEmail(personalEmail);
			personalParameters.setGeneralConsent(generalConsent);
			
			if (createPersonalParameters) {
				personalParameters.setMaxFavoriteServices(MySpaceConstants.MAX_FAVORITE_SERVICES + "");
				personalParameters.create(transaction);
			} else {
				personalParameters.store(transaction);
			}
			
			// Handle the 'emails' in participation in other profiles.
			boolean hasProfilesParticipation = "1".equals(request.getParameter("hasProfilesParticipation"));
			List<String> emailsToBeSend = null;
			Map<String, String> codeByEmail = null;
			if (hasProfilesParticipation) {
				UserProfileRole[] profilesParticipationRoles = this.loadAllProfileRolesByUserUID(userProfileBean.getCurrentUserUID());
				if (profilesParticipationRoles != null && profilesParticipationRoles.length > 0) {
					String userProfileIds = "";
					List<String> currentEmails = new ArrayList<String>(); 
					for (int i = 0; i < profilesParticipationRoles.length; i++) {
						if (userProfileIds.trim().length() > 0) {
							userProfileIds += ",";
						}
						userProfileIds += profilesParticipationRoles[i].getUserProfileId(); 
						if (profilesParticipationRoles[i].getEmail() != null 
								&& profilesParticipationRoles[i].getEmail().trim().length() > 0 
								&& !currentEmails.contains(profilesParticipationRoles[i].getEmail())) {
							currentEmails.add(profilesParticipationRoles[i].getEmail());
						}
					}
					if (userProfileIds.length() > 0) {
						// Load all 'Active' Not personal profiles per current user.
						UserProfile[] profilesParticipation = this.loadAllNotPersonalProfilesByIdsAndStatus(userProfileIds, MySpaceConstants.USER_PROFILE_STATUS_ACTIVE);
						if (profilesParticipation != null && profilesParticipation.length > 0) {
							String tmpCurrentEmail = null;
							String newEmail = null;		
							emailsToBeSend = new ArrayList<String>();
							codeByEmail = new HashMap<>();
							for (int i = 0; i < profilesParticipation.length; i++) {
								tmpCurrentEmail = null;
								newEmail = null;
								if (profilesParticipationRoles != null) {
									for (int j = 0; j < profilesParticipationRoles.length; j++) {
										if (profilesParticipation[i].getId().equals(profilesParticipationRoles[j].getUserProfileId())) {
											tmpCurrentEmail = profilesParticipationRoles[j].getEmail();
											newEmail = request.getParameter("email" + profilesParticipation[i].getId());
											// If something went wrong on the form.
											if (newEmail == null) {
												newEmail = tmpCurrentEmail;
											}
											// Check the email was changed.
											if ((tmpCurrentEmail == null && newEmail != null) 
													|| (newEmail != null && !newEmail.equalsIgnoreCase(tmpCurrentEmail))) {
												// update db.
												profilesParticipationRoles[j].setEmail(newEmail);
												profilesParticipationRoles[j].setConfirm(MySpaceConstants.USER_PROFILE_CHANGE_EMAIL_CONFIRMED);
												if (!currentEmails.contains(newEmail) && !personalEmail.equalsIgnoreCase(newEmail)) {													
													profilesParticipationRoles[j].setConfirm(null);
													if (!emailsToBeSend.contains(newEmail)) {														
														emailsToBeSend.add(newEmail);
														codeByEmail.put(newEmail, utils.generateChangeEmailCode());
													}
													profilesParticipationRoles[j].setCode(codeByEmail.get(newEmail));													
												}
												profilesParticipationRoles[j].store(transaction);
											}
											break;
										}
									}
								}
							}							
						}
					} 
				} 
			}
			
			transaction.commit();
			
			// Email(s) was/were changed, so we need to send confirmation link(s).
			if (emailsToBeSend != null && emailsToBeSend.size() > 0) {
				/*
				 * Notifications.
				 */
				MySpaceNotificationsManager notificationsManager = new MySpaceNotificationsManager();
				for (int i = 0; i < emailsToBeSend.size(); i++) {								
					notificationsManager.sendUserChangeEmailConfirmationLink(userProfileBean.getCurrentUserUID(), MySpaceConstants.TYPE_EMAIL_LEGAL_ENTITY, request, response, emailsToBeSend.get(i), codeByEmail.get(emailsToBeSend.get(i)), bundle);
				}
				result = emailsToBeSend.size() == 1 ? 2 : 3;
			}
								
			Logger.log(Logger.DEBUG_LEVEL, "saveProfile() -> Check bean email vs email [" + userProfileBean.getCurrentUserEmail() + "][" + personalEmail + "]");
			if ((userProfileBean.getCurrentUserEmail() == null && personalEmail != null) || userProfileBean.getCurrentUserEmail() != null && !userProfileBean.getCurrentUserEmail().equalsIgnoreCase(personalEmail)) {
				hasEmailChange = true;
				if (userInputMap == null) {
					userInputMap = new HashMap<String, String>();
				}				
				userInputMap.put(MySpaceConstants.LDAP_ATTRIBUTE_PORTAL_EMAIL, personalEmail);
			}			
			// UPDATE LDAP...
			if (userInputMap != null && userInputMap.size() > 0) {
				Logger.log(Logger.DEBUG_LEVEL, "saveProfile() -> UPDATING LDAP...");
				try {
					PumaController localPumaController = MySpacePortlet.getPumaController();
					localPumaController.setAttributes(userProfileBean.getCurrentUser(), userInputMap);
					// Update the sessionBean.					
					if (hasEmailChange) {
						userProfileBean.setCurrentUserEmail(userInputMap.get(MySpaceConstants.LDAP_ATTRIBUTE_PORTAL_EMAIL));
					}
					sessionBean.setUserProfile(userProfileBean);	
				} catch (Exception e) {
					System.out.println(e.getMessage());
					e.printStackTrace();					
				}
			}			
			// Update session data.
			sessionBean.setProfile(userProfile);
			sessionBean.setPersonalParameters(personalParameters);
			
			if (MySpacePortlet.logEvents) {
				// Register event in the log.
				AuditLogManagement alManagement = new AuditLogManagement();
				alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_EDIT_PROFILE, "Редактиране на персонален профил", null, remoteIP, false);
			}
			return result;			
		} catch (Exception e) {
			System.out.println("UserProfileManagement : saveProfile : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("UserProfileManagement : saveProfile : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			throw new Exception(bundle.getString("profile.save.error"));
		}
	}
	
	public void deactivateProfile(MySpacePortletSessionBean sessionBean, String deactivationReason, MySpacePortlet portlet, String remoteIP, ResourceBundle bundle) throws Exception {
		if (sessionBean.getProfile().getId() == null) {
			sessionBean.setDeactivation(true);
			return;
		}
		boolean success = false;
		long currentTime = System.currentTimeMillis();
		UserProfileBean userProfileBean = sessionBean.getUserProfile();
		AuditLogManagement alManagement = new AuditLogManagement();
		QueryExecution qe = new QueryExecution();		
		if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(sessionBean.getProfile().getProfileType())) {			
			int result = qe.deactivateAllProfiles(sessionBean.getProfile().getUserUID(), deactivationReason, null);
			if (MySpacePortlet.logEvents) {
				if (result > 1) {
					// Register event in the log.
					alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_DEACTIVATE_ALL_PROFILES, "Деактивиране на всички профили", null, remoteIP, false);								
				} else {
					// Register event in the log.
					alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_DEACTIVATE_PROFILE, "Деактивиране на персонален профил", null, remoteIP, false);				
				}
			}
			sessionBean.setDeactivation(true);			
		} else if (MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY.equals(sessionBean.getProfile().getProfileType())
				|| MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY_AL2.equals(sessionBean.getProfile().getProfileType())
				|| MySpaceConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER.equals(sessionBean.getProfile().getProfileType())) {
			// Load the profile.
			UserProfile profile = this.loadProfileById(sessionBean.getProfile().getId());
			if (profile != null) {			
				DBTransaction transaction = null;
				String deactivateProfileId = profile.getId();
				ArrayList<User> removedUserUIDs = null;
				UserProfile[] subProfiles = null;
				Map<String, List<UserProfileRole>> subProfileParticipationsByProfileId = null;
				PumaCommunicator communicator = null;
				try {
					UserProfile personalProfile = utils.getPersonalProfile(sessionBean.getProfiles());
					String names = personalProfile != null ? personalProfile.getNames() : profile.getNames();
					String identifier = personalProfile != null ? personalProfile.getIdentifier() : profile.getIdentifier();
					String identifierPrefix = personalProfile != null ? personalProfile.getIdentifierPrefix() : profile.getIdentifierPrefix();
					
					transaction = new DBTransaction();
					UserProfileRole[] profileParticipations = null;
					try {
						profileParticipations = UserProfileRole.findAllByUserProfileId(deactivateProfileId, transaction);
					} catch (FinderException e) {}
					
					// Remove all occurences of default profile ids.
					qe.removeAllDefaultProfileId(deactivateProfileId, transaction);
					// Remove all associations.			
					qe.removeAllProfileAssociations(deactivateProfileId, transaction);
					// Remove all XC Roles associations.
					qe.removeAllUserProfileXCRoleAssociations(deactivateProfileId, transaction);
					// Remove all invitations for profile.
					qe.removeAllInvitationsForProfile(deactivateProfileId, transaction);
					// Check we have child profiles, if so make then inactive too.
					try {					
						// ONE Level Only.
						UserProfileRef[] profileRefs = UserProfileRef.findAllByParentUserProfileId(deactivateProfileId, transaction);
						// Multiple Levels.
						//UserProfileRef[] profileRefs = UserProfileRef.findAllByParentUserProfileIdsIn(deactivateProfileId, transaction);
						if (profileRefs != null && profileRefs.length > 0) {
							String userProfileIds = "";
							for (int i = 0; i < profileRefs.length; i++) {
								if (userProfileIds.length() > 0) {
									userProfileIds += ",";
								}
								userProfileIds += profileRefs[i].getUserProfileId();
							}
							try {
								subProfiles = UserProfile.findAllByIds(userProfileIds, transaction);
							} catch (FinderException e) {}
							if (subProfiles != null && subProfiles.length > 0) {
								try {
									UserProfileRole[] subProfileParticipations = UserProfileRole.findAllByUserProfileIds(userProfileIds, transaction);
									if (subProfileParticipations != null && subProfileParticipations.length > 0) {
										subProfileParticipationsByProfileId = new HashMap<String, List<UserProfileRole>>();
										List<UserProfileRole> tmpArr = null;
										for (int i = 0; i < subProfileParticipations.length; i++) {
											tmpArr = subProfileParticipationsByProfileId.get(subProfileParticipations[i].getUserProfileId());
											if (tmpArr == null) {
												tmpArr = new ArrayList<UserProfileRole>();
											}
											tmpArr.add(subProfileParticipations[i]);
											subProfileParticipationsByProfileId.put(subProfileParticipations[i].getUserProfileId(), tmpArr);
										}
									}
								} catch (FinderException e) {}
							}
						} 
					} catch (FinderException e) {}
					
					if (subProfiles != null && subProfiles.length > 0) {
						for (int i = 0; i < subProfiles.length; i++) {
							// Remove all occurences of default profile ids.
							qe.removeAllDefaultProfileId(subProfiles[i].getId(), transaction);
							// Remove all associations.			
							qe.removeAllProfileAssociations(subProfiles[i].getId(), transaction);
							// Remove all XC Roles associations.
							qe.removeAllUserProfileXCRoleAssociations(subProfiles[i].getId(), transaction);
							// Remove all invitations for profile.
							qe.removeAllInvitationsForProfile(subProfiles[i].getId(), transaction);
							// Deactivate subprofile.
							qe.deactivateProfile(subProfiles[i].getId(), sessionBean.getUserProfile().getCurrentUserUID(), names, identifier, identifierPrefix, deactivationReason, transaction);		
						}
					}
					
					// Deactivate profile.
					qe.deactivateProfile(deactivateProfileId, sessionBean.getUserProfile().getCurrentUserUID(), names, identifier, identifierPrefix, deactivationReason, transaction);		
					
					if (MySpaceConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER.equals(sessionBean.getProfile().getProfileType())
							&& sessionBean.getProfile().getGroupId() != null) {
						if (profileParticipations != null) {
							// Remove from group.
							removedUserUIDs = new ArrayList<>();
							communicator = new PumaCommunicator();
							User user = null;
							for (int i = 0; i < profileParticipations.length; i++) {
								if (MySpaceConstants.USER_PROFILE_ROLE_SELECTED.equals(profileParticipations[i].getEditor())) {	
									user = portlet.getUserByUID(profileParticipations[i].getUserUID());
									if (user != null) {
										// Remove user from group.
										String result = communicator.removeUserFromGroups(user, new String[] {sessionBean.getProfile().getGroupId()});
										if (result != null && !"Group_Not_Found".equals(result)) {
											Logger.log(Logger.DEBUG_LEVEL, "UserProfileManagement -> deactivateProfile(" + profileParticipations[i].getUserUID() + "," + sessionBean.getProfile().getGroupId() + ") [ERROR] - result=" + result);											
											throw new Exception(bundle.getString("user.group.remove.error"));
										}
										removedUserUIDs.add(user);
									}
								}
							}	
						}
					}
					transaction.commit();				
					success = true;
					
					/*
					 * Notifications sub profiles.
					 */
					if (subProfiles != null && subProfiles.length > 0) {
						MySpaceNotificationsManager notificationsManager = new MySpaceNotificationsManager();
						List<UserProfileRole> subProfileParticipationsList = null;
						UserProfileRole[] subProfileParticipations = null;
						for (int i = 0; i < subProfiles.length; i++) {		
							subProfileParticipations = null;
							try {							
								subProfileParticipationsList = subProfileParticipationsByProfileId != null ? subProfileParticipationsByProfileId.get(subProfiles[i].getId()) : null;
								if (subProfileParticipationsList != null) {
									subProfileParticipations = (UserProfileRole[])subProfileParticipationsList.toArray(new UserProfileRole[subProfileParticipationsList.size()]);
								}
								notificationsManager.notifyUserForDeactivatingUICProfile(MySpaceConstants.MODE_EMAIL_DEACTIVATING_UIC, subProfiles[i], subProfileParticipations, MySpaceUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(currentTime), bundle);
							} catch (Exception e) {
								e.printStackTrace();
							}
							// Register event in the log.
							if (MySpacePortlet.logEvents) { 
								alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_DEACTIVATE_PROFILE, "Деактивиране на под-профил \"" + subProfiles[i].getNameAndLegalForm() + "\"", null, remoteIP, false);
							}
						}
					}
					
					/*
					 * Notifications main profile.
					 */			 
					try {
						MySpaceNotificationsManager notificationsManager = new MySpaceNotificationsManager();
						notificationsManager.notifyUserForDeactivatingUICProfile(MySpaceConstants.MODE_EMAIL_DEACTIVATING_UIC, sessionBean.getProfile(), profileParticipations, MySpaceUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(currentTime), bundle);
					} catch (Exception e) {
						e.printStackTrace();
					}			
					
					// Register event in the log.
					if (MySpacePortlet.logEvents) { 
						alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_DEACTIVATE_PROFILE, "Деактивиране на профил \"" + sessionBean.getProfile().getNameAndLegalForm() + "\"", null, remoteIP, false);
					}
				} catch (Exception e) {
					Logger.log(Logger.ERROR_LEVEL, "UserProfileManagement : deactivateProfile : " + e.getMessage());			
					e.printStackTrace();
					try {
						if (transaction != null) {
							transaction.rollback();
						}						
					} catch (SQLException e1) {
						Logger.log(Logger.ERROR_LEVEL, "UserProfileManagement : deactivateProfile : rollback transaction" + e1.getMessage());				
						e1.printStackTrace();
					}	
					if (removedUserUIDs != null && removedUserUIDs.size() > 0) {
						for (int i = 0; i < removedUserUIDs.size(); i++) {
							communicator.addUserToGroups(removedUserUIDs.get(i), new String[] {sessionBean.getProfile().getGroupId()});
						}					
					}
				}
						
				if (success) {
					// Reinit personal profile.
					UserProfile personalProfile = getPersonalProfile(sessionBean.getProfiles());
					sessionBean.setProfile(personalProfile);
					sessionBean.setCurrentPage(MySpacePortlet.INDEX_PAGE);
					UserProfilePersonalParameters personalParameters = loadPersonalParametersByProfileId(personalProfile.getId());
					sessionBean.setPersonalParameters(personalParameters);
					
					// Reinit profiles.
					UserProfile[] profiles = this.loadAllProfilesAndPersonalProfilesByUserUID(userProfileBean.getCurrentUserUID());
					sessionBean.setProfiles(profiles);
					ArrayList<String> currentProfileIds = new ArrayList<>();
					if (profiles != null && profiles.length > 0) {
						for (int i = 0; i < profiles.length; i++) {
							currentProfileIds.add(profiles[i].getId());
						}
					}
					
					// Reinit profiles participation.
					UserProfile[] profilesParticipation = null;
					// Load profiles participation through the UserProfileRole table.
					UserProfileRole[] roles = this.loadAllProfileRolesByUserUID(userProfileBean.getCurrentUserUID());
					if (roles != null && roles.length > 0) {
						String userProfileIds = "";
						for (int i = 0; i < roles.length; i++) {
							// Skip current loaded profiles.
							if (!currentProfileIds.contains(roles[i].getUserProfileId())) {
								if (userProfileIds.trim().length() > 0) {
									userProfileIds += ",";
								}
								userProfileIds += roles[i].getUserProfileId(); 
							}
						}
						if (userProfileIds.length() > 0) {
							profilesParticipation = this.loadAllProfilesByIds(userProfileIds);
							sessionBean.setProfilesParticipation(profilesParticipation);
						}
					}
					
		//			UserProfile[] profiles = sessionBean.getProfiles();
		//			boolean founded = false;
		//			if (profiles != null && profiles.length > 0) {
		//				for (int i = 0; i < profiles.length; i++) {
		//					if (profiles[i].getId().equals(deactivateProfileId)) {
		//						profiles[i].setStatus(MySpaceConstants.USER_PROFILE_STATUS_INACTIVE);
		//						profiles[i].setDeactivationReason(deactivationReason);
		//						founded = true;							
		//						break;
		//					}					
		//				}
		//			}
		//			if (founded) {
		//				sessionBean.setProfiles(profiles);
		//			} else {
		//				UserProfile[] profileParticipations = sessionBean.getProfilesParticipation();
		//				if (profileParticipations != null && profileParticipations.length > 0) {
		//					UserProfile[] tmpProfileParticipations = new UserProfile[profileParticipations.length-1];
		//					for (int i = 0; i < profileParticipations.length; i++) {
		//						if (!profileParticipations[i].getId().equals(deactivateProfileId)) {
		//							tmpProfileParticipations[tmpProfileParticipations.length] = profileParticipations[i];
		//						}	
		//					}
		//					sessionBean.setProfilesParticipation(tmpProfileParticipations);
		//				}
		//			}			
		 			sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, bundle.getString("profile.deactivated")));
				} else {
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, bundle.getString("profile.deactivated.error")));
				}
			} else {
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, bundle.getString("profile.deactivated.error")));
			}
		}				
	}
	
	@Deprecated
	public void deactivateProfileOld(MySpacePortletSessionBean sessionBean, String deactivationReason, MySpacePortlet portlet, String remoteIP, ResourceBundle bundle) throws Exception {
		if (sessionBean.getProfile().getId() == null) {
			sessionBean.setDeactivation(true);
			return;
		}
		UserProfileBean userProfileBean = sessionBean.getUserProfile();
		AuditLogManagement alManagement = new AuditLogManagement();
		QueryExecution qe = new QueryExecution();
		if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(sessionBean.getProfile().getProfileType())) {			
			int result = qe.deactivateAllProfiles(sessionBean.getProfile().getUserUID(), deactivationReason, null);
			if (MySpacePortlet.logEvents) {
				if (result > 1) {
					// Register event in the log.
					alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_DEACTIVATE_ALL_PROFILES, "Деактивиране на всички профили", null, remoteIP, false);								
				} else {
					// Register event in the log.
					alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_DEACTIVATE_PROFILE, "Деактивиране на персонален профил", null, remoteIP, false);				
				}
			}
			sessionBean.setDeactivation(true);			
		} else {
			String deactivateProfileId = sessionBean.getProfile().getId();
			DBTransaction transaction = null;
			PumaCommunicator communicator = new PumaCommunicator();
			ArrayList<User> removedUserUIDs = null;
			try {
				transaction = new DBTransaction();
				//boolean canDeactivate = false;
				boolean canRemove = false;
				if (MySpaceConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER.equals(sessionBean.getProfile().getProfileType())) {
					UserProfile[] profiles = sessionBean.getProfiles();
					boolean isProfileOwner = false;
					UserProfile profileForDeactivation = null;
					if (profiles != null && profiles.length > 0) {
						for (int i = 0; i < profiles.length; i++) {
							if (profiles[i].getId().equals(deactivateProfileId)) {
								isProfileOwner = true;	
								profileForDeactivation = profiles[i];
								break;
							}					
						}
					}
					if (!isProfileOwner) {
						UserProfile[] profileParticipations = sessionBean.getProfilesParticipation();
						if (profileParticipations != null && profileParticipations.length > 0) {
							for (int i = 0; i < profileParticipations.length; i++) {
								if (profileParticipations[i].getId().equals(deactivateProfileId)) {
									profileForDeactivation = profileParticipations[i];
									break;
								}	
							}
						}
					}
					if (profileForDeactivation != null) {
						UserProfileRole[] userProfileRoles = null;
						try {
							userProfileRoles = UserProfileRole.findAllByUserProfileId(deactivateProfileId, transaction);
						} catch (FinderException e) {}
						if (userProfileRoles != null && userProfileRoles.length > 0) {
							// Check we have at least one "administrator role" left to manage the profile.								
							for (int i = 0; i < userProfileRoles.length; i++) {
								if (!userProfileRoles[i].getUserUID().equalsIgnoreCase(sessionBean.getUserProfile().getCurrentUserUID()) && MySpaceConstants.USER_PROFILE_ROLE_SELECTED.equals(userProfileRoles[i].getAdmin())) {
									canRemove = true;
									break;
								}									
							}
							if (!canRemove) {
								Logger.log(Logger.DEBUG_LEVEL, "UserProfileManagement -> deactivateProfile(" + sessionBean.getUserProfile().getCurrentUserUID() + "," + sessionBean.getProfile().getGroupId() + ") [ERROR] - No Admin Role left to manage the profile.");											
								throw new Exception("Не може да бъдете премахнати от профила, защото сте единственият администратор!");
							}
							if (canRemove) {
								UserProfileRole role = sessionBean.getProfileRoles();
								if (MySpaceConstants.USER_PROFILE_ROLE_SELECTED.equals(role.getEditor())) {
									removedUserUIDs = new ArrayList<>();
									User user = null;
									user = portlet.getUserByUID(sessionBean.getUserProfile().getCurrentUserUID());
									if (user != null) {
										// Remove user from group.
										String result = communicator.removeUserFromGroups(user, new String[] {sessionBean.getProfile().getGroupId()});
										if (result != null) {
											Logger.log(Logger.DEBUG_LEVEL, "UserProfileManagement -> deactivateProfile(" + sessionBean.getUserProfile().getCurrentUserUID() + "," + sessionBean.getProfile().getGroupId() + ") [ERROR] - result=" + result);											
											throw new Exception(bundle.getString("user.group.remove.error"));
										}
										removedUserUIDs.add(user);
									}
								}
							}
						}
					}
				}
//				if (qe.deactivateProfile(deactivateProfileId, deactivationReason, transaction) == 1) {					
//					if (sessionBean.getProfile().getGroupId() != null && sessionBean.getProfile().getGroupId().trim().length() > 0) {
//						UserProfileRole[] userProfileRoles = null;
//						try {
//							userProfileRoles = UserProfileRole.findAllByUserProfileId(deactivateProfileId, transaction);
//						} catch (FinderException e) {
//						} catch (Exception e) {
//							e.printStackTrace();
//						}
//						if (userProfileRoles != null && userProfileRoles.length > 0) {
//							UserProfileRole userProfileRole = null;
//							removedUserUIDs = new ArrayList<>();
//							User user = null;
//							for (int i = 0; i < userProfileRoles.length; i++) {
//								userProfileRole = userProfileRoles[i];
//								if (MySpaceConstants.USER_PROFILE_ROLE_SELECTED.equals(userProfileRole.getEditor())) {									
//									user = portlet.getUserByUID(userProfileRole.getUserUID());
//									if (user != null) {
//										// Remove user from group.
//										String result = communicator.removeUserFromGroups(user, new String[] {sessionBean.getProfile().getGroupId()});
//										if (result != null) {
//											Logger.log(Logger.DEBUG_LEVEL, "UserProfileManagement -> deactivateProfile(" + userProfileRole.getUserUID() + "," + sessionBean.getProfile().getGroupId() + ") [ERROR] - result=" + result);											
//											throw new Exception(bundle.getString("user.group.remove.error"));
//										}
//										removedUserUIDs.add(user);
//									}
//								}										
//							}															
//						}
//					}					
//				} else {
//					throw new Exception(bundle.getString("profile.deactivation.error"));
//				}
				transaction.commit();
				if (MySpacePortlet.logEvents) {
					// Register event in the log.
					alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_DEACTIVATE_PROFILE, "Деактивиране на профил \"" + sessionBean.getProfile().getNameAndLegalForm() + "\"", null, remoteIP, false);
				}
				UserProfile profile = getPersonalProfile(sessionBean.getProfiles());
				sessionBean.setProfile(profile);
				sessionBean.setCurrentPage(MySpacePortlet.INDEX_PAGE);
				UserProfilePersonalParameters personalParameters = loadPersonalParametersByProfileId(profile.getId());
				sessionBean.setPersonalParameters(personalParameters);
				UserProfile[] profiles = sessionBean.getProfiles();
				boolean founded = false;
				if (profiles != null && profiles.length > 0) {
					for (int i = 0; i < profiles.length; i++) {
						if (profiles[i].getId().equals(deactivateProfileId)) {
							profiles[i].setStatus(MySpaceConstants.USER_PROFILE_STATUS_INACTIVE);
							profiles[i].setDeactivationReason(deactivationReason);
							founded = true;							
							break;
						}					
					}
				}
				if (founded) {
					sessionBean.setProfiles(profiles);
				} else {
					UserProfile[] profileParticipations = sessionBean.getProfilesParticipation();
					if (profileParticipations != null && profileParticipations.length > 0) {
						UserProfile[] tmpProfileParticipations = new UserProfile[profileParticipations.length-1];
						for (int i = 0; i < profileParticipations.length; i++) {
//							if (profileParticipations[i].getId().equals(deactivateProfileId)) {
//								profileParticipations[i].setStatus(MySpaceConstants.USER_PROFILE_STATUS_INACTIVE);
//								profileParticipations[i].setDeactivationReason(deactivationReason);												
//								break;
//							}	
							if (!profileParticipations[i].getId().equals(deactivateProfileId)) {
								tmpProfileParticipations[tmpProfileParticipations.length] = profileParticipations[i];
							}	
						}
//						sessionBean.setProfilesParticipation(profileParticipations);
						sessionBean.setProfilesParticipation(tmpProfileParticipations);
					}
				}
 				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, bundle.getString("profile.deactivated")));
			} catch (Exception e) {
				System.out.println("UserProfileManagement : deactivateProfile : " + e.getMessage());
				e.printStackTrace();
				try {
					if (transaction != null) {
						transaction.rollback();
					}
				} catch (SQLException e1) {
					System.out.println("UserProfileManagement : deactivateProfile : rollback transaction" + e1.getMessage());
					e1.printStackTrace();
				}
				if (removedUserUIDs != null && removedUserUIDs.size() > 0) {
					for (int i = 0; i < removedUserUIDs.size(); i++) {
						communicator.addUserToGroups(removedUserUIDs.get(i), new String[] {sessionBean.getProfile().getGroupId()});
					}					
				}	
			}
		}
	}

	public boolean confirmProfile(MySpacePortletSessionBean sessionBean, MySpacePortlet portlet, String remoteIP, ResourceBundle bundle) throws Exception {
		UserProfileBean userProfileBean = sessionBean.getUserProfile();
		AuditLogManagement alManagement = new AuditLogManagement();
		QueryExecution qe = new QueryExecution();
		long currentTime = System.currentTimeMillis();
		try {
			// Confirm the profile.
			if (qe.confirmProfile(sessionBean.getProfile().getId(), null) == 1) {
				sessionBean.getProfile().setStatus(MySpaceConstants.USER_PROFILE_STATUS_ACTIVE);
				UserProfile[] profiles = sessionBean.getProfiles();
				if (profiles != null && profiles.length > 0) {
					for (int i = 0; i < profiles.length; i++) {
						if (profiles[i].getId().equalsIgnoreCase(sessionBean.getProfile().getId())) {
							profiles[i].setStatus(MySpaceConstants.USER_PROFILE_STATUS_ACTIVE);	
							break;
						}
					}
					sessionBean.setProfiles(profiles);
				}
				if (MySpacePortlet.logEvents) {
					// Register event in the log.
					alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_CONFIRM_PROFILE, "Потвърждение за приемане на 'Общите Условия' и създаване на персонален профил - \"" + sessionBean.getProfile().getNames() + "\"", null, remoteIP, false);					
				}
				// Register event in eJournal.
				EJournalCommunicator eJournalCommunicator = new EJournalCommunicator();
				eJournalCommunicator.sendRNU(utils.generateRNU(), MySpaceConstants.E_JOURNAL_STAGE_INITIALIZE, MySpaceConstants.E_JOURNAL_STATUS_LOGIN_OR_CREATE_PE_PROFILE, currentTime);
				return true;
			}			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public boolean confirmGeneralTerms(MySpacePortletSessionBean sessionBean, MySpacePortlet portlet, String remoteIP, ResourceBundle bundle) throws Exception {
		UserProfileBean userProfileBean = sessionBean.getUserProfile();
		AuditLogManagement alManagement = new AuditLogManagement();
		QueryExecution qe = new QueryExecution();
		try {			
			// Confirm General Terms for the profile.
			if (qe.confirmGeneralTerms(sessionBean.getProfile().getId(), null) == 1) {				
				if (MySpacePortlet.logEvents) {
					// Register event in the log.
					alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_ACCEPT_GENERAL_TERMS, "Потвърждение за приемане на 'Общите Условия' на персонален профил - \"" + sessionBean.getProfile().getNames() + "\"", null, remoteIP, false);
				}
				return true;
			}			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public String activateProfile(MySpacePortletSessionBean sessionBean, UserProfile profile, MySpacePortlet portlet, String remoteIP, ResourceBundle bundle) throws Exception {
		UserProfileBean userProfileBean = sessionBean.getUserProfile();
		AuditLogManagement alManagement = new AuditLogManagement();
		QueryExecution qe = new QueryExecution();
		DBTransaction transaction = null;
		MySpaceUtils utils = new MySpaceUtils();
		//boolean founded = false;
		long currentTime = System.currentTimeMillis();
		try {
			if (utils.isREIK(profile.getEik())) {
				// Check parent is active.
				UserProfileRef profileRef = this.loadProfileRefByUserProfileId(profile.getId());
				if (profileRef != null) {
					UserProfile parentProfile = this.loadProfileById(profileRef.getParentUserProfileId()); 
					if (parentProfile == null || !MySpaceConstants.USER_PROFILE_STATUS_ACTIVE.equals(parentProfile.getStatus())) {
						return MessageFormat.format(bundle.getString("profile.parent.is.not.active"), parentProfile.getNameAndLegalForm());						
					}
				}
			}						
			transaction = new DBTransaction();
			UserProfile personalProfile = utils.getPersonalProfile(sessionBean.getProfiles());
			String names = personalProfile != null ? personalProfile.getNames() : profile.getNames();
			String identifier = personalProfile != null ? personalProfile.getIdentifier() : profile.getIdentifier();
			String identifierPrefix = personalProfile != null ? personalProfile.getIdentifierPrefix() : profile.getIdentifierPrefix();
			// Activate the profile.
			if (qe.activateProfile(profile.getId(), sessionBean.getUserProfile().getCurrentUserUID(), names, identifier, identifierPrefix, transaction) == 1) {					
				sessionBean.setProfileRoles(null);
				UserProfileRole role = null;
				String email = sessionBean.getPersonalParameters() != null ? sessionBean.getPersonalParameters().getEmail() : null;
				
				// Check we have sub-profiles. (One level ONLY)
				UserProfileRef[] profileRefs = this.loadAllProfileRefsByParentUserProfileId(profile.getId());
				if (profileRefs != null && profileRefs.length > 0) {
					UserProfile[] subProfiles = null;
					String subProfileIds = "";
					for (int i = 0; i < profileRefs.length; i++) {
						if (subProfileIds.length() > 0) {
							subProfileIds += ",";
						}
						subProfileIds += profileRefs[i].getUserProfileId();
					}
					// Load only 'inactive' profiles to make them 'active'.
					subProfiles = this.loadAllProfilesByIdsAndStatus(subProfileIds, MySpaceConstants.USER_PROFILE_STATUS_INACTIVE);
					if (subProfiles != null && subProfiles.length > 0) {
						for (int i = 0; i < subProfiles.length; i++) {
							// Activate sub-profile.
							if (qe.activateProfile(subProfiles[i].getId(), sessionBean.getUserProfile().getCurrentUserUID(), names, identifier, identifierPrefix, transaction) == 1) {		
								// Add current user the 'Admin' role for this profile.
								role = new UserProfileRole();
								role.setUserProfileId(subProfiles[i].getId());
								role.setUserUID(sessionBean.getUserProfile().getCurrentUserUID());
								role.setAdmin(MySpaceConstants.USER_PROFILE_ROLE_SELECTED);				
								role.setEmail(email);
								role.setConfirm(MySpaceConstants.USER_PROFILE_CHANGE_EMAIL_CONFIRMED);				
								role.setDateCreated(MySpaceUtils.timeMillisToTimestamp(currentTime));
								role.create(transaction);
								if (MySpacePortlet.logEvents) {
									// Register event in the log.
									alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_ACTIVATE_PROFILE, "Активиране на профил \"" + subProfiles[i].getNameAndLegalForm() + "\" (" + subProfiles[i].getEik() + ")", null, remoteIP, false);
								}
							}
						}
					}
				}
				
				// Add current user the 'Admin' role for this profile.
				role = new UserProfileRole();
				role.setUserProfileId(profile.getId());
				role.setUserUID(sessionBean.getUserProfile().getCurrentUserUID());
				role.setAdmin(MySpaceConstants.USER_PROFILE_ROLE_SELECTED);				
				role.setEmail(email);
				role.setConfirm(MySpaceConstants.USER_PROFILE_CHANGE_EMAIL_CONFIRMED);				
				role.setDateCreated(MySpaceUtils.timeMillisToTimestamp(currentTime));
				role.create(transaction);
				
				transaction.commit();
									
				// ReInit session data.
				sessionBean.setProfile(profile);
				sessionBean.setCurrentPage(MySpaceUtils.getDashboardPageByProfileType(profile.getProfileType()));	
				UserProfile[] profiles = this.loadAllProfilesAndPersonalProfilesByUserUID(userProfileBean.getCurrentUserUID());
				sessionBean.setProfiles(profiles);
				personalProfile = utils.getPersonalProfile(profiles);
				if (personalProfile != null) {
					UserProfilePersonalParameters personalParameters = this.loadPersonalParametersByProfileId(personalProfile.getId());
					sessionBean.setPersonalParameters(personalParameters);
				}
				// load roles.
				sessionBean.setProfileRoles(this.loadRolesByProfileIdAndUserUID(profile.getId(), userProfileBean.getCurrentUserUID()));
				UserProfile[] profileParticipations = utils.loadProfileParticipations(sessionBean.getUserProfile().getCurrentUserUID(), utils.getCurrentProfileIds(profiles));
				sessionBean.setProfilesParticipation(profileParticipations);
//					if (profiles != null && profiles.length > 0) {						
//						for (int i = 0; i < profiles.length; i++) {
//							// Switch to the activated profile.
//							if (profiles[i].getId().equalsIgnoreCase(profileId)) {
//								profiles[i].setStatus(MySpaceConstants.USER_PROFILE_STATUS_ACTIVE);							
//								sessionBean.setProfile(profiles[i]);
//								sessionBean.setCurrentPage(MySpaceUtils.getDashboardPageByProfileType(profiles[i].getProfileType()));							
//								// load extra data.
//								UserProfileManagement management = new UserProfileManagement();
//								UserProfilePersonalParameters personalParameters = management.loadPersonalParametersByProfileId(profiles[i].getId());
//								sessionBean.setPersonalParameters(personalParameters);
//								sessionBean.setProfiles(profiles);
//								// load roles.
//								sessionBean.setProfileRoles(management.loadRolesByProfileIdAndUserUID(profiles[i].getId(), userProfileBean.getCurrentUserUID()));
//								founded = true;
//								break;
//							}
//						}
//						Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> prepareRenderingData() total loaded profiles [" + profiles.length + "]");
//					}
//					if (!founded) {
//						UserProfile[] profileParticipations = sessionBean.getProfilesParticipation();
//						if (profileParticipations != null && profileParticipations.length > 0) {
//							for (int i = 0; i < profileParticipations.length; i++) {
//								if (profileParticipations[i].getId().equals(profileId)) {
//									profileParticipations[i].setStatus(MySpaceConstants.USER_PROFILE_STATUS_ACTIVE);
//									sessionBean.setProfile(profileParticipations[i]);
//									sessionBean.setCurrentPage(MySpaceUtils.getDashboardPageByProfileType(profileParticipations[i].getProfileType()));								
//									// load extra data.
//									UserProfileManagement management = new UserProfileManagement();
//									UserProfilePersonalParameters personalParameters = management.loadPersonalParametersByProfileId(profileParticipations[i].getId());
//									sessionBean.setPersonalParameters(personalParameters);								
//									// load roles.
//									sessionBean.setProfileRoles(management.loadRolesByProfileIdAndUserUID(profileParticipations[i].getId(), userProfileBean.getCurrentUserUID()));
//																	
//									break;
//								}	
//							}
//							sessionBean.setProfilesParticipation(profileParticipations);
//						}
//					}
				
				if (MySpacePortlet.logEvents) {
					// Register event in the log.
					alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_ACTIVATE_PROFILE, "Активиране на профил \"" + profile.getNameAndLegalForm() + "\" (" + profile.getEik() + ")", null, remoteIP, false);
				}
			}			
		} catch (Exception e) {
			System.out.println("UserProfileManagement : activateProfile : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("UserProfileManagement : activateProfile : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			throw new Exception(e.getMessage());
		}
		return null;
	}
	
	public void removeDefaultUserProfileId(String profileId) {
		QueryExecution qe = new QueryExecution();
		try {			
			qe.removeDefaultProfileId(profileId, null);					
		} catch (Exception e) {
			System.out.println("UserProfileManagement : removeDefaultUserProfileId : " + e.getMessage());
			e.printStackTrace();			
		}
	}
	
	public int addUser(MySpacePortletSessionBean sessionBean, UserProfileBean userProfileBean, ActionRequest request, String uid, String personalIdentifier, User user, String remoteIP, ResourceBundle bundle) throws Exception {		
		DBTransaction transaction = null;
		boolean roleAdmin = MySpaceConstants.USER_PROFILE_ROLE_SELECTED.equals(request.getParameter("admin"));
		boolean roleServices = MySpaceConstants.USER_PROFILE_ROLE_SELECTED.equals(request.getParameter("services"));
		boolean roleEditor = MySpaceConstants.USER_PROFILE_ROLE_SELECTED.equals(request.getParameter("editor"));
		boolean roleUser = MySpaceConstants.USER_PROFILE_ROLE_SELECTED.equals(request.getParameter("user"));
		long currentTime = System.currentTimeMillis();
		boolean addedToGroup = false;
		boolean friendlyMessage = false;
		PumaCommunicator communicator = new PumaCommunicator();
		try {
			transaction = new DBTransaction();
			UserProfileRole userProfileRole = null;
			try {
				userProfileRole = UserProfileRole.findByProfileIdAndUserUID(sessionBean.getProfile().getId(), uid, transaction);
			} catch (FinderException e) {
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (userProfileRole != null) {
				friendlyMessage = true;
				throw new Exception(bundle.getString("user.already.assigned.to.current.profile"));
			}
			if (roleEditor && (sessionBean.getProfile().getGroupId() == null || sessionBean.getProfile().getGroupId().trim().length() == 0)) {
				friendlyMessage = true;
				throw new Exception(bundle.getString("user.role.editor.cannot.be.assigned"));				
			}
			if (roleEditor) {
				String retVal = communicator.addUserToGroups(user, new String[] {sessionBean.getProfile().getGroupId()});
				if (retVal != null) {
					Logger.log(Logger.DEBUG_LEVEL, "UserProfileManagement -> addUser(" + uid + "," + sessionBean.getProfile().getGroupId() + ") [ERROR] - retVal=" + retVal);
					friendlyMessage = true;
					throw new Exception(bundle.getString("user.role.editor.assign.error"));
				}
				addedToGroup = true;
			}
			String email = sessionBean.getPersonalParameters() != null ? sessionBean.getPersonalParameters().getEmail() : null;
			userProfileRole = new UserProfileRole();
			userProfileRole.setUserProfileId(sessionBean.getProfile().getId());
			userProfileRole.setUserUID(uid);
			userProfileRole.setDateCreated(MySpaceUtils.timeMillisToTimestamp(currentTime));
			if (roleAdmin) {
				userProfileRole.setAdmin(MySpaceConstants.USER_PROFILE_ROLE_SELECTED);
			}
			if (roleEditor && (MySpaceConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER.equalsIgnoreCase(sessionBean.getProfile().getProfileType()) 
					|| MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY_AL2.equalsIgnoreCase(sessionBean.getProfile().getProfileType()))) {
				userProfileRole.setEditor(MySpaceConstants.USER_PROFILE_ROLE_SELECTED);
			}
			if (roleServices && MySpaceConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER.equalsIgnoreCase(sessionBean.getProfile().getProfileType())) {
				userProfileRole.setServiceManager(MySpaceConstants.USER_PROFILE_ROLE_SELECTED);
			}
			if (roleUser  && (MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY.equalsIgnoreCase(sessionBean.getProfile().getProfileType()) 
					|| MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY_AL2.equalsIgnoreCase(sessionBean.getProfile().getProfileType()))) {
				userProfileRole.setUser(MySpaceConstants.USER_PROFILE_ROLE_SELECTED);
			}
			userProfileRole.setEmail(email);
			userProfileRole.setConfirm(MySpaceConstants.USER_PROFILE_CHANGE_EMAIL_CONFIRMED);
			userProfileRole.create(transaction);	
			
			// Check for Horizontal System roles.
			HorizontalSystemRoleManagement hsRoleManagement = new HorizontalSystemRoleManagement();
			HorizontalSystemRole[] hsRoles = hsRoleManagement.loadAll();
			if (hsRoles != null && hsRoles.length > 0) {
				List<String> addXCRoles = new ArrayList<String>();
				for (int i = 0; i < hsRoles.length; i++) {
					// Check we have marked role in the user's "edit" form.
					if (MySpaceConstants.USER_PROFILE_ROLE_SELECTED.equals(request.getParameter("hsRole" + hsRoles[i].getId()))) {
						addXCRoles.add(hsRoles[i].getId());
					}
				}
				// Add XC roles to user profile.
				if (addXCRoles.size() > 0) {					
					UserProfileXCRole userProfileXCRole = null;
					for (int i = 0; i < addXCRoles.size(); i++) {
						userProfileXCRole = new UserProfileXCRole();
						userProfileXCRole.setHorizontalSystemRoleId(addXCRoles.get(i));						
						userProfileXCRole.setUserProfileId(sessionBean.getProfile().getId());
						userProfileXCRole.setUserUID(uid);
						userProfileXCRole.setDateCreated(MySpaceUtils.timeMillisToTimestamp(currentTime));
						userProfileXCRole.create(transaction);
					}
				}			
			} 			
			transaction.commit();
			
			Logger.log(Logger.DEBUG_LEVEL, "addUser() -> [OK]");
			
			String roles = (roleAdmin ? "Администратор" : "");
			if (roleEditor) {roles += ((roles.length() > 0) ? "; " : "") + "Редактор"; }
			if (roleServices) {roles += ((roles.length() > 0) ? "; " : "") + "Услуги"; }
			if (roleUser) {roles += ((roles.length() > 0) ? "; " : "") + "Потребител"; }			
			
			/*
			 * Notifications.
			 */
			MySpaceNotificationsManager notificationsManager = new MySpaceNotificationsManager();
			notificationsManager.notifyUserAddEditRemoveLEProfile(MySpaceConstants.USER_ADDED_TO_LEGAL_ENTITY, uid, roles, sessionBean.getProfile(), MySpaceUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(currentTime), bundle);
			
			// Register event in the log.
			AuditLogManagement alManagement = new AuditLogManagement();			
			if (MySpacePortlet.logEvents) {
				alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_ADD_USER_TO_PROFILE, "Добавяне на потребител с ЕГН " + personalIdentifier + " към профил \"" + sessionBean.getProfile().getNameAndLegalForm() + "\" с роли: " + roles, null, remoteIP, false);
			}
			
			// Register event in eJournal.
			EJournalCommunicator eJournalCommunicator = new EJournalCommunicator();
			eJournalCommunicator.sendRNU(utils.generateRNU(), MySpaceConstants.E_JOURNAL_STAGE_INITIALIZE, MySpaceConstants.E_JOURNAL_STATUS_ASSIGN_PE_PROFILE_TO_LE_PROFILE, currentTime);
			return 1;
		} catch (Exception e) {
			System.out.println("UserProfileManagement : addUser : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("UserProfileManagement : addUser : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			if (addedToGroup) {
				communicator.removeUserFromGroups(user, new String[] {sessionBean.getProfile().getGroupId()});
			}
			if (friendlyMessage) {
				throw new Exception(e.getMessage());
			}
			throw new Exception(bundle.getString("add.user.error"));
		}
	}

	public int editUser(MySpacePortletSessionBean sessionBean, UserProfileBean userProfileBean, ActionRequest request, String userProfileRoleId, String personalIdentifier, MySpacePortlet portlet, String remoteIP, ResourceBundle bundle) throws Exception {		
		DBTransaction transaction = null;
		boolean roleAdmin = MySpaceConstants.USER_PROFILE_ROLE_SELECTED.equals(request.getParameter("admin"));
		boolean roleServices = MySpaceConstants.USER_PROFILE_ROLE_SELECTED.equals(request.getParameter("services"));
		boolean roleEditor = MySpaceConstants.USER_PROFILE_ROLE_SELECTED.equals(request.getParameter("editor"));
		boolean roleUser = MySpaceConstants.USER_PROFILE_ROLE_SELECTED.equals(request.getParameter("user"));
		boolean addedToGroup = false;
		boolean removedFromGroup = false;
		boolean friendlyMessage = false;
		long currentTime = System.currentTimeMillis();
		PumaCommunicator communicator = new PumaCommunicator();
		User user = null;
		try {
			transaction = new DBTransaction();
			UserProfileRole userProfileRole = null;
			try {
				userProfileRole = UserProfileRole.findByIdAndProfileId(userProfileRoleId, sessionBean.getProfile().getId(), transaction);
			} catch (FinderException e) {
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (userProfileRole == null) {
				friendlyMessage = true;
				throw new Exception(bundle.getString("user.profile.role.not.found"));
			}
			// Role "Editor" was unchecked, so remove user from the group. 
			if (MySpaceConstants.USER_PROFILE_ROLE_SELECTED.equals(userProfileRole.getEditor()) &&  !roleEditor &&
					(sessionBean.getProfile().getGroupId() != null && sessionBean.getProfile().getGroupId().trim().length() > 0)) {
				user = portlet.getUserByUID(userProfileRole.getUserUID());
				if (user != null) {
					// Remove user from group.
					String result = communicator.removeUserFromGroups(user, new String[] {sessionBean.getProfile().getGroupId()});
					if (result != null) {
						Logger.log(Logger.DEBUG_LEVEL, "UserProfileManagement -> editUser(" + userProfileRole.getUserUID() + "," + sessionBean.getProfile().getGroupId() + ") [ERROR] - result=" + result);
						friendlyMessage = true;
						throw new Exception(bundle.getString("user.group.remove.error"));
					}
					removedFromGroup = true;
				}
			} else if (roleEditor && !MySpaceConstants.USER_PROFILE_ROLE_SELECTED.equals(userProfileRole.getEditor()) &&
					(sessionBean.getProfile().getGroupId() != null && sessionBean.getProfile().getGroupId().trim().length() > 0)) {
				user = portlet.getUserByUID(userProfileRole.getUserUID());
				if (user != null) {
					String result = communicator.addUserToGroups(user, new String[] {sessionBean.getProfile().getGroupId()});
					if (result != null) {
						Logger.log(Logger.DEBUG_LEVEL, "UserProfileManagement -> editUser(" + userProfileRole.getUserUID() + "," + sessionBean.getProfile().getGroupId() + ") [ERROR] - result=" + result);
						friendlyMessage = true;
						throw new Exception(bundle.getString("user.role.editor.assign.error"));
					}
					addedToGroup = true;
				}
			}
			userProfileRole.setAdmin(roleAdmin ? MySpaceConstants.USER_PROFILE_ROLE_SELECTED : null);
			if (MySpaceConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER.equalsIgnoreCase(sessionBean.getProfile().getProfileType()) 
					|| MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY_AL2.equalsIgnoreCase(sessionBean.getProfile().getProfileType())) {
				userProfileRole.setEditor(roleEditor ? MySpaceConstants.USER_PROFILE_ROLE_SELECTED : null);
			}
			if (MySpaceConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER.equalsIgnoreCase(sessionBean.getProfile().getProfileType())) {
				userProfileRole.setServiceManager(roleServices ? MySpaceConstants.USER_PROFILE_ROLE_SELECTED : null);
			}
			if (MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY.equalsIgnoreCase(sessionBean.getProfile().getProfileType()) 
					|| MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY_AL2.equalsIgnoreCase(sessionBean.getProfile().getProfileType())) {
				userProfileRole.setUser(roleUser ? MySpaceConstants.USER_PROFILE_ROLE_SELECTED : null);
			}
			userProfileRole.store(transaction);	
			
			// Check for Horizontal System roles.
			HorizontalSystemRoleManagement hsRoleManagement = new HorizontalSystemRoleManagement();
			HorizontalSystemRole[] hsRoles = hsRoleManagement.loadAll();
			UserProfileXCRoleManagement userProfileXCRoleManagement = new UserProfileXCRoleManagement(); 
			UserProfileXCRole[] userProfileXCRoles = userProfileXCRoleManagement.loadAllXCRolesByUserProfileIdAndUserUID(sessionBean.getProfile().getId(), userProfileRole.getUserUID());
			List<String> checkedRolesInForm = null;
			Map<String, List<String>> checkedRolesBySystemOID = null;
			List<String> checkedSystems = null;
			List<String> tmpArr = null;
			QueryExecution qe = new QueryExecution();
			if (hsRoles != null && hsRoles.length > 0) {
				List<String> addXCRoles = new ArrayList<String>();
				checkedRolesInForm = new ArrayList<String>();
				checkedRolesBySystemOID = new HashMap<String, List<String>>();
				checkedSystems = new ArrayList<String>();
				boolean hasRole = false;
				for (int i = 0; i < hsRoles.length; i++) {
					// Check we have marked role in the user's "edit" form.
					if (MySpaceConstants.USER_PROFILE_ROLE_SELECTED.equals(request.getParameter("hsRole" + hsRoles[i].getId()))) {
						checkedRolesInForm.add(hsRoles[i].getId());
						hasRole = false;
						if (userProfileXCRoles != null && userProfileXCRoles.length > 0) {
							for (int j = 0; j < userProfileXCRoles.length; j++) {
								if (hsRoles[i].getId().equals(userProfileXCRoles[j].getHorizontalSystemRoleId())) {
									hasRole = true;
									break;
								}
							}
						} 
						if (!hasRole) {
							addXCRoles.add(hsRoles[i].getId());
						}
						tmpArr = checkedRolesBySystemOID.get(hsRoles[i].getSystemOID());
						if (tmpArr == null) {
							tmpArr = new ArrayList<String>();
						}
						tmpArr.add(hsRoles[i].getTitle());
						checkedRolesBySystemOID.put(hsRoles[i].getSystemOID(), tmpArr);
						if (!checkedSystems.contains(hsRoles[i].getSystemOID())) {
							checkedSystems.add(hsRoles[i].getSystemOID());
						}
					}
				}
				// Add XC roles to user profile.
				if (addXCRoles.size() > 0) {					
					UserProfileXCRole userProfileXCRole = null;
					for (int i = 0; i < addXCRoles.size(); i++) {
						userProfileXCRole = new UserProfileXCRole();
						userProfileXCRole.setHorizontalSystemRoleId(addXCRoles.get(i));						
						userProfileXCRole.setUserProfileId(sessionBean.getProfile().getId());
						userProfileXCRole.setUserUID(userProfileRole.getUserUID());
						userProfileXCRole.setDateCreated(MySpaceUtils.timeMillisToTimestamp(currentTime));
						userProfileXCRole.create(transaction);
					}
				}
				// Check we have removed roles.
				if (userProfileXCRoles != null && userProfileXCRoles.length > 0) {	
					String removeXCRoleIds = "";
					for (int i = 0; i < userProfileXCRoles.length; i++) {
						if (!checkedRolesInForm.contains(userProfileXCRoles[i].getHorizontalSystemRoleId())) {
							if (removeXCRoleIds.length() > 0) {
								removeXCRoleIds += ",";
							}
							removeXCRoleIds += userProfileXCRoles[i].getId();
						}
					}
					if (removeXCRoleIds.length() > 0) {
						qe.removeAllUserProfileXCRoleByIds(removeXCRoleIds, transaction);
					}
				}
			} else {
				if (userProfileXCRoles != null && userProfileXCRoles.length > 0) {
					qe.removeAllUserProfileXCRoleAssociationsForUser(sessionBean.getProfile().getId(), userProfileRole.getUserUID(), transaction);
				}
			}
			
			transaction.commit();
			
			Logger.log(Logger.DEBUG_LEVEL, "editUser() -> [OK]");
			String roles = (roleAdmin ? "Администратор" : "");
			if (roleEditor) {roles += ((roles.length() > 0) ? "; " : "") + "Редактор"; }
			if (roleServices) {roles += ((roles.length() > 0) ? "; " : "") + "Услуги"; }
			if (roles.trim().length() > 0) {
				roles = "EGOV.BG - " + roles;
			}
			if (checkedSystems != null && checkedSystems.size() > 0) {
				if (roles.trim().length() > 0) {
					roles += "<br/>";
				}
				String systemName = "";
				String tmpRoles = "";
				for (int i = 0; i < checkedSystems.size(); i++) {
					systemName = checkedSystems.get(i);
					if ("2.16.100.1.1.292.1.5.1.3".equals(checkedSystems.get(i))) {
						systemName = "еВръчване";
					}
					tmpArr = checkedRolesBySystemOID.get(checkedSystems.get(i));
					roles += systemName + " - ";
					tmpRoles = "";
					for (int j = 0; j < tmpArr.size(); j++) {
						if (tmpRoles.trim().length() > 0) {
							tmpRoles += "; ";
						}
						tmpRoles += tmpArr.get(j);
					}
					roles += tmpRoles;
					roles += "<br/>";
				}
			}
 			/*
			 * Notifications.
			 */
			MySpaceNotificationsManager notificationsManager = new MySpaceNotificationsManager();
			notificationsManager.notifyUserAddEditRemoveLEProfile(MySpaceConstants.USER_EDIT_ROLES_TO_LEGAL_ENTITY, userProfileRole.getUserUID(), roles, sessionBean.getProfile(), MySpaceUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(currentTime), bundle);
			
			// Register event in the log.
			AuditLogManagement alManagement = new AuditLogManagement();			
			if (MySpacePortlet.logEvents) {
				alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_EDIT_USER_OF_PROFILE, "Редактиране на потребител с идентификатор " + personalIdentifier + " към профил \"" + sessionBean.getProfile().getNameAndLegalForm() + "\" с роли: " + roles, null, remoteIP, false);
			}
			return 1;
		} catch (Exception e) {
			System.out.println("UserProfileManagement : editUser : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("UserProfileManagement : editUser : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			if (addedToGroup && user != null) {
				communicator.removeUserFromGroups(user, new String[] {sessionBean.getProfile().getGroupId()});
			}
			if (removedFromGroup && user != null) {
				communicator.addUserToGroups(user, new String[] {sessionBean.getProfile().getGroupId()});
			}
			if (friendlyMessage) {
				throw new Exception(e.getMessage());
			}
			throw new Exception(bundle.getString("add.user.error"));
		}
	}
	
	public int removeUser(MySpacePortletSessionBean sessionBean, UserProfileBean userProfileBean, ActionRequest request, String userProfileRoleId, MySpacePortlet portlet, String remoteIP, ResourceBundle bundle) throws Exception {		
		DBTransaction transaction = null;
		boolean friendlyMessage = false;
		boolean removedFromGroup = false;
		PumaCommunicator communicator = new PumaCommunicator();
		User user = null;
		long currentTime = System.currentTimeMillis();
		try {
			transaction = new DBTransaction();
			UserProfileRole userProfileRole = null;
			try {
				userProfileRole = UserProfileRole.findById(userProfileRoleId, transaction);
			} catch (FinderException e) {
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (userProfileRole == null) {
				friendlyMessage = true;
				throw new Exception(bundle.getString("user.profile.role.not.found"));
			}
			if (MySpaceConstants.USER_PROFILE_ROLE_SELECTED.equals(userProfileRole.getEditor()) && 
					(sessionBean.getProfile().getGroupId() != null && sessionBean.getProfile().getGroupId().trim().length() > 0)) {
				user = portlet.getUserByUID(userProfileRole.getUserUID());
				if (user != null) {
					// Remove user from group.
					String result = communicator.removeUserFromGroups(user, new String[] {sessionBean.getProfile().getGroupId()});
					if (result != null && !"Group_Not_Found".equalsIgnoreCase(result)) {
						Logger.log(Logger.DEBUG_LEVEL, "UserProfileManagement -> editUser(" + userProfileRole.getUserUID() + "," + sessionBean.getProfile().getGroupId() + ") [ERROR] - result=" + result);
						friendlyMessage = true;
						throw new Exception(bundle.getString("user.group.remove.error"));
					}
					removedFromGroup = true;
				}
			}
			userProfileRole.remove(transaction);	
			
			// Remove XC roles.
			QueryExecution qe = new QueryExecution();
			qe.removeAllUserProfileXCRoleAssociationsForUser(userProfileRole.getUserProfileId(), userProfileRole.getUserUID(), transaction);
			
			transaction.commit();
			
			Logger.log(Logger.DEBUG_LEVEL, "removeUser() -> [OK]");
			
			/*
			 * Notifications.
			 */
			MySpaceNotificationsManager notificationsManager = new MySpaceNotificationsManager();
			notificationsManager.notifyUserAddEditRemoveLEProfile(MySpaceConstants.USER_REMOVED_FROM_LEGAL_ENTITY, userProfileRole.getUserUID(), null, sessionBean.getProfile(), MySpaceUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(currentTime), bundle);
			
			if (MySpacePortlet.logEvents) {
				// Register event in the log.
				AuditLogManagement alManagement = new AuditLogManagement();
				alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_REMOVE_USER_FROM_PROFILE, "Премахване на потребител с идентификатор " + userProfileRole.getUserUID() + " от профил \"" + sessionBean.getProfile().getNameAndLegalForm() + "\"", null, remoteIP, false);
			}
			
			// Register event in eJournal.
			EJournalCommunicator eJournalCommunicator = new EJournalCommunicator();
			eJournalCommunicator.sendRNU(utils.generateRNU(), MySpaceConstants.E_JOURNAL_STAGE_CANCEL, MySpaceConstants.E_JOURNAL_STATUS_REMOVE_PE_PROFILE_FROM_LE_PROFILE, currentTime);
			return 1;
		} catch (Exception e) {
			System.out.println("UserProfileManagement : addUser : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("UserProfileManagement : addUser : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			if (removedFromGroup && user != null) {
				communicator.addUserToGroups(user, new String[] {sessionBean.getProfile().getGroupId()});
			}
			if (friendlyMessage) {
				throw new Exception(e.getMessage());
			}
			throw new Exception(bundle.getString("add.user.error"));
		}
	}
	
	public String addIdentifier(MySpacePortletSessionBean sessionBean, InputStream file, String fileName, String fileContentType, long fileSize, String remoteIP, ResourceBundle bundle) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "UserProfileManagement : addIdentifier() start...");
		MySpaceUtils utils = new MySpaceUtils();
		UserProfileBean userProfileBean = sessionBean.getUserProfile();
		UserProfile profile = sessionBean.getProfile();
		HashMap<String, Container> sessionContainer = sessionBean.getContainer();
		Container container = sessionContainer.get(sessionBean.getCurrentPage());
		ProfileIdentifierBean bean = container.getProfileIdentifierBean();
		String userIdentifier = profile.getEik();
		String userNames = profile.getNameAndLegalForm();
		if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(profile.getProfileType())) {
			userNames = profile.getNames();
			userIdentifier = profile.getIdentifier();	
		}
		if (userNames == null) {
			userNames = userProfileBean.getCurrentUserCN();
		}
		if (userIdentifier == null) {
			userIdentifier = userProfileBean.getCurrentUserUID();
		}
		long currentTime = System.currentTimeMillis();
		String rnu = bean.getRnu();
		DBTransaction transaction = null;
		try {			
			EncryptorAESGCM aesCls = new EncryptorAESGCM();
			String encryptedPersonalIdentifier = aesCls.encryptEgovIdentifier(bean.getIdentifier());
			
			transaction = new DBTransaction();
			UserProfileIdentifier userProfileIdentifier = new UserProfileIdentifier();			
			userProfileIdentifier.setUserProfileId(profile.getId());
			userProfileIdentifier.setIdentifierType(bean.getIdentifierType());
			userProfileIdentifier.setIdentifierCountryCode(bean.getIdentifierCountryCode());
			userProfileIdentifier.setIdentifier(encryptedPersonalIdentifier);
			userProfileIdentifier.setRnu(rnu);
			userProfileIdentifier.setDateCreated(MySpaceUtils.timeMillisToTimestamp(currentTime));
			userProfileIdentifier.create(transaction);
			
			// Create log information with the signed document.
			QueryExecution qe = new QueryExecution(); 
			String result = qe.addProfileIdentifierLog(
					profile.getId(), 
					encryptedPersonalIdentifier,
					bean.getIdentifierCountryCode(),
					bean.getIdentifierType(),
					MySpaceConstants.OPERATION_TYPE_ADD_IDENTIFIER,										
					file,
					fileName,
					fileSize, 
					fileContentType,
					rnu, 
					currentTime,
					transaction);
			
			transaction.commit();
			
			if (result != null) {		 
				/*
				 *  Send notifications. SKIP FOR NOW.
				 */
//				MySpaceNotificationsManager notificationManager = new MySpaceNotificationsManager();					
//				List<Message> messages = notificationManager.notifyUserForIdentifierAdded(profile, userProfileBean, bean, currentTime);
//				if (messages != null) {
//					List<Message> currentMessages = sessionBean.getMessages();
//					if (currentMessages == null) {
//						currentMessages = new ArrayList<Message>();						
//					} 						
//					currentMessages.addAll(messages);
//					sessionBean.setMessages(currentMessages);
//				}
				
				/*
				 *  Log the event.
				 */
				if (MySpacePortlet.logEvents) {					
					// Register event in the log.
					AuditLogManagement alManagement = new AuditLogManagement();
					alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_ADD_PROFILE_IDENTIFIER, "Добавяне на идентификатор '" + utils.getIdentifierTypeName(bean.getIdentifierType(), false) +  "': " + bean.getIdentifier() + " (" + AllCountries.getCountryCodesISO3166Hm().get(bean.getIdentifierCountryCode()) + ") за потребител " + userNames, null, remoteIP, false);
				}
			}
			return result;
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "UserProfileManagement : addIdentifier : " + e.getMessage());			
			e.printStackTrace();	
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("UserProfileManagement : addIdentifier : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			throw new Exception(bundle.getString("profile.add.identifier.error"));
		}		
	}
	
	public String removeIdentifier(MySpacePortletSessionBean sessionBean, String identifierId, InputStream file, String fileName, String fileContentType, long fileSize, String remoteIP, ResourceBundle bundle) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "UserProfileManagement : removeIdentifier() start...");
		MySpaceUtils utils = new MySpaceUtils();
		UserProfileBean userProfileBean = sessionBean.getUserProfile();
		UserProfile profile = sessionBean.getProfile();
		HashMap<String, Container> sessionContainer = sessionBean.getContainer();
		Container container = sessionContainer.get(sessionBean.getCurrentPage());
		ProfileIdentifierBean bean = container.getProfileIdentifierBean();
		String userIdentifier = profile.getEik();
		String userNames = profile.getNameAndLegalForm();
		String result = null;
		if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(profile.getProfileType())) {
			userNames = profile.getNames();
			userIdentifier = profile.getIdentifier();	
		}
		if (userNames == null) {
			userNames = userProfileBean.getCurrentUserCN();
		}
		if (userIdentifier == null) {
			userIdentifier = userProfileBean.getCurrentUserUID();
		}
		long currentTime = System.currentTimeMillis();
		String rnu = bean.getRnu();
		DBTransaction transaction = null;
		try {			
			EncryptorAESGCM aesCls = new EncryptorAESGCM();
			String decryptedPersonalIdentifier = aesCls.decryptEgovIdentifier(bean.getIdentifier());
			
			transaction = new DBTransaction();
			UserProfileIdentifier userProfileIdentifier = null;
			try {
				userProfileIdentifier = UserProfileIdentifier.findById(identifierId, transaction);
			} catch (FinderException e) {
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			if (userProfileIdentifier != null) {
				userProfileIdentifier.remove(transaction);
			
				// Create log information with the signed document.
				QueryExecution qe = new QueryExecution(); 
				result = qe.addProfileIdentifierLog(
						profile.getId(), 
						bean.getIdentifier(),
						bean.getIdentifierCountryCode(),
						bean.getIdentifierType(),
						MySpaceConstants.OPERATION_TYPE_REMOVE_IDENTIFIER,										
						file,
						fileName,
						fileSize, 
						fileContentType,
						rnu, 
						currentTime,
						transaction);
				
				transaction.commit();
			
				if (result != null) {		 
					/*
					 *  Send notifications. SKIP FOR NOW.
					 */
//					MySpaceNotificationsManager notificationManager = new MySpaceNotificationsManager();					
//					List<Message> messages = notificationManager.notifyUserForIdentifierAdded(profile, userProfileBean, bean, currentTime);
//					if (messages != null) {
//						List<Message> currentMessages = sessionBean.getMessages();
//						if (currentMessages == null) {
//							currentMessages = new ArrayList<Message>();						
//						} 						
//						currentMessages.addAll(messages);
//						sessionBean.setMessages(currentMessages);
//					}
					
					/*
					 *  Log the event.
					 */
					if (MySpacePortlet.logEvents) {					
						// Register event in the log.
						AuditLogManagement alManagement = new AuditLogManagement();
						alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_REMOVE_PROFILE_IDENTIFIER, "Премахване на идентификатор '" + utils.getIdentifierTypeName(bean.getIdentifierType(), false) +  "': " + decryptedPersonalIdentifier + " (" + AllCountries.getCountryCodesISO3166Hm().get(bean.getIdentifierCountryCode()) + ") за потребител " + userNames, null, remoteIP, false);
					}
				}
			} else {
				throw new Exception(bundle.getString("profile.remove.identifier.id.not.found.error"));
			}
			return result;
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "UserProfileManagement : removeIdentifier : " + e.getMessage());			
			e.printStackTrace();	
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("UserProfileManagement : removeIdentifier : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			throw new Exception(bundle.getString("profile.remove.identifier.error"));
		}		
	}
	
	public int addInvitation(
			MySpacePortletSessionBean sessionBean, 
			UserProfileBean userProfileBean, 
			ActionRequest request, 
			String profileIdType, 
			String personalIdentifier, 			
			String firstName, 
			String lastName, 
			String email, 			
			String remoteIP, 
			ResourceBundle bundle) throws Exception {		
		DBTransaction transaction = null;
		
		EncryptorAESGCM aesCls = new EncryptorAESGCM();
		String encryptedPersonalIdentifier = aesCls.encryptEgovIdentifier(personalIdentifier);	
		
		long currentTime = System.currentTimeMillis();
		boolean friendlyMessage = false;

		try {
			transaction = new DBTransaction();
			UserProfileInvitation invitation = null;
			String identifierPrefix = MySpaceConstants.IDENTIFIER_PREFIX_EGN; 
			if (String.valueOf(MySpaceConstants.USER_PROFILE_IDENTIFIER_TYPE_LNC).equals(profileIdType)) {
				identifierPrefix = MySpaceConstants.IDENTIFIER_PREFIX_LNC; 
			}	
			// Add 'BG' locale suffix.
			identifierPrefix += "BG";
			try { 
				// Check "Not confirmed" invitation already exists.
				invitation = UserProfileInvitation.findByIdentifierAndProfileIdAndStatus(encryptedPersonalIdentifier, identifierPrefix, sessionBean.getProfile().getId(), MySpaceConstants.INVITATION_STATUS_NOT_CONFIRMED, transaction);
			} catch (FinderException e) {
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (invitation != null) {
				friendlyMessage = true;
				throw new Exception(bundle.getString("user.already.has.been.invited.for.current.profile"));
			}
			// Check user is not already a member of that legal entity.
			UserProfileRole roles[] = null;
			try {
				roles = UserProfileRole.findAllByUserProfileId(sessionBean.getProfile().getId(), transaction);
			} catch (FinderException e) {
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (roles != null && roles.length > 0) {
				Logger.log(Logger.DEBUG_LEVEL, "UserProfileManagement: addInvitation() roles=" + roles.length);
				String memberUserIds = "";
				for (int i = 0; i < roles.length; i++) {
					if (memberUserIds.length() > 0) {
						memberUserIds += "','";
					}
					memberUserIds += roles[i].getUserUID();
				}
				memberUserIds = "'" + memberUserIds + "'";
				Logger.log(Logger.DEBUG_LEVEL, "UserProfileManagement: addInvitation() memberUserIds=" + memberUserIds);
				UserProfile[] memberProfiles = UserProfile.findAllByUserUIDsAndType(memberUserIds, MySpaceConstants.USER_PROFILE_TYPE_PERSONAL, transaction);
				if (memberProfiles != null && memberProfiles.length > 0) {
					for (int i = 0; i < memberProfiles.length; i++) {
						if (encryptedPersonalIdentifier.equals(memberProfiles[i].getIdentifier())) {
							friendlyMessage = true;
							throw new Exception(bundle.getString("user.already.assigned.with.current.profile"));
						}
					}
				}
			}
			
			String code = Base64.getEncoder().encodeToString(EncryptorAESGCM.generateRandomAESKeyBase64Encoded().getBytes()); 
			invitation = new UserProfileInvitation();
			invitation.setUserProfileId(sessionBean.getProfile().getId());
			invitation.setProfileIdType(Integer.parseInt(profileIdType));			
			invitation.setIdentifier(encryptedPersonalIdentifier);
			invitation.setIdentifierPrefix(identifierPrefix);
			invitation.setFirstName(firstName);
			invitation.setLastName(lastName);
			invitation.setEmail(email);
			invitation.setCode(code);
			invitation.setStatus(MySpaceConstants.INVITATION_STATUS_NOT_CONFIRMED);
			invitation.setUserUID(userProfileBean.getCurrentUserUID());
			invitation.setDateCreated(MySpaceUtils.timeMillisToTimestamp(currentTime));
			invitation.setDateModified(MySpaceUtils.timeMillisToTimestamp(currentTime));
			invitation.create(transaction);								
			transaction.commit();
			
			Logger.log(Logger.DEBUG_LEVEL, "UserProfileManagement: addInvitation() -> [OK]");
			
			UserProfile personalProfile = utils.getPersonalProfile(sessionBean.getProfiles());
			
			if (personalProfile == null) {
				friendlyMessage = true;
				throw new Exception(bundle.getString("current.user.should.have.personal.profile"));
			}
			/*
			 * Notifications.
			 */
			try {
				MySpaceNotificationsManager notificationsManager = new MySpaceNotificationsManager();
				notificationsManager.notifyUserForInvitationPerProfile(MySpaceConstants.USER_INVITED_TO_LEGAL_ENTITY, email, code, sessionBean.getProfile(), personalProfile.getNames(), MySpaceUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(currentTime), bundle);
			} catch (Exception e) {
				friendlyMessage = true;
				throw new Exception(e.getMessage());
			}
			
			// Register event in the log.
			AuditLogManagement alManagement = new AuditLogManagement();			
			if (MySpacePortlet.logEvents) {
				alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_INVITE_USER_TO_PROFILE, "Изпращане на покана до потребител " + firstName + " " + lastName + " (" + personalIdentifier + ") за профил \"" + sessionBean.getProfile().getNameAndLegalForm(), null, remoteIP, false);
			}
			return 1;
		} catch (Exception e) {
			System.out.println("UserProfileManagement : addInvitation : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("UserProfileManagement : addInvitation : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			
			if (friendlyMessage) {
				throw new Exception(e.getMessage());
			}
			throw new Exception(bundle.getString("invite.user.error"));
		}
	}
	
	public int resendInvitation(MySpacePortletSessionBean sessionBean, UserProfileBean userProfileBean, ActionRequest request, String userProfileInvitationId, MySpacePortlet portlet, String remoteIP, ResourceBundle bundle) throws Exception {		
		DBTransaction transaction = null;
		boolean friendlyMessage = false;
		long currentTime = System.currentTimeMillis();
		try {
			transaction = new DBTransaction();
			UserProfileInvitation invitation = null;
			try {
				invitation = UserProfileInvitation.findById(userProfileInvitationId, transaction);
			} catch (FinderException e) {
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (invitation == null) {
				friendlyMessage = true;
				throw new Exception(bundle.getString("user.invitation.not.found"));
			}			
			invitation.setDateModified(MySpaceUtils.timeMillisToTimestamp(currentTime));
			invitation.store(transaction);
			transaction.commit();
			
			Logger.log(Logger.DEBUG_LEVEL, "resendInvitation() -> [OK]");
			
			UserProfile personalProfile = utils.getPersonalProfile(sessionBean.getProfiles());
			
			if (personalProfile == null) {
				friendlyMessage = true;
				throw new Exception(bundle.getString("current.user.should.have.personal.profile"));
			}

			/*
			 * Notifications.
			 */			
			try {
				MySpaceNotificationsManager notificationsManager = new MySpaceNotificationsManager();
				notificationsManager.notifyUserForInvitationPerProfile(MySpaceConstants.USER_REINVITED_TO_LEGAL_ENTITY, invitation.getEmail(), invitation.getCode(), sessionBean.getProfile(), personalProfile.getNames(), MySpaceUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(currentTime), bundle);
			} catch (Exception e) {
				friendlyMessage = true;
				throw new Exception(e.getMessage());
			}			
			
			// Register event in the log.
			AuditLogManagement alManagement = new AuditLogManagement();			
			if (MySpacePortlet.logEvents) { 
				EncryptorAESGCM aesCls = new EncryptorAESGCM();
				String personalIdentifier = aesCls.decryptEgovIdentifier(invitation.getIdentifier());
				alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_REINVITE_USER_TO_PROFILE, "Повторно изпращане на покана до потребител " + invitation.getFirstName() + " " + invitation.getLastName() + " (" + personalIdentifier + ") за профил \"" + sessionBean.getProfile().getNameAndLegalForm(), null, remoteIP, false);
			}
			return 1;
		} catch (Exception e) {
			System.out.println("UserProfileManagement : resendInvitation : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("UserProfileManagement : resendInvitation : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			if (friendlyMessage) {
				throw new Exception(e.getMessage());
			}
			throw new Exception(bundle.getString("resend.invitation.error"));
		}
	}
	
	public int removeInvitation(MySpacePortletSessionBean sessionBean, UserProfileBean userProfileBean, ActionRequest request, String userProfileInvitationId, MySpacePortlet portlet, String remoteIP, ResourceBundle bundle) throws Exception {		
		DBTransaction transaction = null;
		boolean friendlyMessage = false;
		try {
			transaction = new DBTransaction();
			UserProfileInvitation invitation = null;
			try {
				invitation = UserProfileInvitation.findById(userProfileInvitationId, transaction);
			} catch (FinderException e) {
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (invitation == null) {
				friendlyMessage = true;
				throw new Exception(bundle.getString("user.invitation.not.found"));
			}			
			invitation.remove(transaction);					
			transaction.commit();
			
			Logger.log(Logger.DEBUG_LEVEL, "removeInvitation() -> [OK]");
			
			if (MySpacePortlet.logEvents) {
				EncryptorAESGCM aesCls = new EncryptorAESGCM();
				String personalIdentifier = aesCls.decryptEgovIdentifier(invitation.getIdentifier());
				// Register event in the log.
				AuditLogManagement alManagement = new AuditLogManagement();
				alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_REMOVE_INVITATION_TO_PROFILE, "Премахване на покана до потребител с идентификатор " + personalIdentifier + " за профил \"" + sessionBean.getProfile().getNameAndLegalForm() + "\"", null, remoteIP, false);
			}
			return 1;
		} catch (Exception e) {
			System.out.println("UserProfileManagement : removeInvitation : " + e.getMessage());
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				System.out.println("UserProfileManagement : removeInvitation : rollback transaction" + e1.getMessage());
				e1.printStackTrace();
			}
			if (friendlyMessage) {
				throw new Exception(e.getMessage());
			}
			throw new Exception(bundle.getString("remove.invitation.error"));
		}
	}
	
	public int removeFromAuditLog(String userUID, String contentUUID) {
		try {
			UserProfileAuditLog.removeByUserUIDAndContentUUID(userUID, contentUUID, null);
			return 1;
		} catch (Exception e) {
			System.out.println("AuditLogManagement : removeFromAuditLog : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}
	
	public int removeAllFromAuditLog(String userUID) {
		try {
			UserProfileAuditLog.removeAllByUserUID(userUID, null);
			return 1;
		} catch (Exception e) {
			System.out.println("AuditLogManagement : removeAllFromAuditLog : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}
	
	public UserProfile getPersonalProfile(UserProfile[] userProfiles) {
		if (userProfiles != null && userProfiles.length > 0) {
			for (int i = 0; i < userProfiles.length; i++) {
				if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(userProfiles[i].getProfileType())) {
					return userProfiles[i];
				}
			}
		}
		return null;
	}
	
	public boolean resendChangeEmailConfirmationLink(String userUID, int type, PortletRequest request, PortletResponse response, String email, ResourceBundle bundle) {
		System.out.println("UserProfileManagement : resendChangeEmailConfirmationLink(" + type + "," + email + ") -> start... ");
		String code = null;
		if (MySpaceConstants.TYPE_EMAIL_LEGAL_ENTITY == type) {
			try {
				UserProfileRole[] participationProfiles = UserProfileRole.findAllByUserUIDAndEmail(userUID, email, null);
				if (participationProfiles != null && participationProfiles.length > 0) {
					for (int i = 0; i < participationProfiles.length; i++) {
						if (participationProfiles[i].getCode() != null && participationProfiles[i].getCode().trim().length() > 0) {
							code = participationProfiles[i].getCode();
							break;
						}
					}
				}
			} catch (Exception e) {
				System.out.println("UserProfileManagement : resendChangeEmailConfirmationLink : " + e.getMessage());
				e.printStackTrace();
			}
		}
		if (code != null) {
			/*
			 * Notifications.
			 */			
			try {
				MySpaceNotificationsManager notificationsManager = new MySpaceNotificationsManager();
				return notificationsManager.sendUserChangeEmailConfirmationLink(userUID, type, request, response, email, code, bundle);
			} catch (Exception e) {
				System.out.println("UserProfileManagement : resendChangeEmailConfirmationLink : " + e.getMessage());
				e.getMessage();
			}
		}
		return false;
	}
	
	public int persistDefaultProfile(String userUID, String personalUserProfileId, UserProfile profile, String remoteIP) {
		try {
			QueryExecution qe = new QueryExecution();
			if (qe.setDefaultProfileId(personalUserProfileId, profile.getId(), null) == 1) {
				if (MySpacePortlet.logEvents) {
					// Register event in the log.
					AuditLogManagement alManagement = new AuditLogManagement();
					String profileName = MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(profile.getProfileType()) ? profile.getNames() : profile.getNameAndLegalForm();
					alManagement.sendEvent(userUID, MySpaceConstants.EVENT_LOG_PORTAL_SET_DEFAULT_PROFILE, "Задаване по подразбиране на профил \"" + profileName + "\"", null, remoteIP, false);
				}
			}
			return 1;
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return 0;
	}
	
	public boolean invalidateClosedUICProfile(UserProfile profile, String userUID, String remoteIP, ResourceBundle bundle) {
		DBTransaction transaction = null;
		long currentTime = System.currentTimeMillis();
		try {
			transaction = new DBTransaction();			
			UserProfileRole[] profileParticipations = null;
			try {
				profileParticipations = UserProfileRole.findAllByUserProfileId(profile.getId(), transaction);
			} catch (Exception e) {}
			
			QueryExecution qe = new QueryExecution();
			// Remove all occurences of default profile ids.
			qe.removeAllDefaultProfileId(profile.getId(), transaction);
			// Remove all associations.			
			qe.removeAllProfileAssociations(profile.getId(), transaction);
			// Remove all XC Roles associations.
			qe.removeAllUserProfileXCRoleAssociations(profile.getId(), transaction);
			// Remove all invitations for profile.
			qe.removeAllInvitationsForProfile(profile.getId(), transaction);
			
			profile.setDateModified(MySpaceUtils.timeMillisToTimestamp(currentTime));
			// Set 'Inactive'.
			profile.setStatus(MySpaceConstants.USER_PROFILE_STATUS_INACTIVE);
			profile.setDeactivationReason("Закрита партида. (Regix)");
			profile.store(transaction);
			transaction.commit();
			
			/*
			 * Notifications.
			 */			 
			try {
				MySpaceNotificationsManager notificationsManager = new MySpaceNotificationsManager();
				notificationsManager.notifyUserForDeactivatingUICProfile(MySpaceConstants.MODE_EMAIL_REGIX_CLOSED_UIC, profile, profileParticipations, MySpaceUtils.timeMillisToYYYY_MM_DD_HH_MM_SS(currentTime), bundle);
			} catch (Exception e) {
				e.printStackTrace();
			}			
			
			// Register event in the log.
			AuditLogManagement alManagement = new AuditLogManagement();			
			if (MySpacePortlet.logEvents) { 
				alManagement.sendEvent(userUID, MySpaceConstants.EVENT_LOG_PORTAL_REGIX_UIC_CLOSED, "'" + profile.getNameAndLegalForm() + "' е със закрита партида. Деактивиране на профила и премахване на всички асоциирани потребители.", null, remoteIP, false);
			}
			
			Logger.log(Logger.DEBUG_LEVEL, "invalidateClosedUICProfile() -> [OK]");
			
			return true;
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "UserProfileManagement : invalidateClosedUICProfile : " + e.getMessage());			
			e.printStackTrace();
			try {
				if (transaction != null) {
					transaction.rollback();
				}
			} catch (SQLException e1) {
				Logger.log(Logger.ERROR_LEVEL, "UserProfileManagement : invalidateClosedUICProfile : rollback transaction" + e1.getMessage());				
				e1.printStackTrace();
			}			
		}
		return false;
	}

}
