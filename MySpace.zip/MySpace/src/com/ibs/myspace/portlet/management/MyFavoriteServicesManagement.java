package com.ibs.myspace.portlet.management;

import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.dbo.UserProfileMyFavorites;
import com.ibs.myspace.portlet.utils.MySpaceUtils;


public class MyFavoriteServicesManagement {
	
	public UserProfileMyFavorites[] loadAllContentUUIDsByUserUID(String userUID) {
		try {
			return UserProfileMyFavorites.findAllByUserUID(userUID, null);
		} catch (FinderException e) {
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	public void trimMyFavorites(String userUID, int maxFavoriteServices) {
		// Load all services per userUID.
		UserProfileMyFavorites[] currentFavoriteServices = null; 
		try {
			currentFavoriteServices = UserProfileMyFavorites.findAllByUserUID(userUID, null); 				
			if (currentFavoriteServices != null && currentFavoriteServices.length >= maxFavoriteServices) {
				String idsToDelete = "";
				for (int i = 0; i < currentFavoriteServices.length; i++) {
					if (i >= maxFavoriteServices) {
						if (idsToDelete.length() > 0) {
							idsToDelete += ",";
						}
						idsToDelete += currentFavoriteServices[i].getId();
					}
				}
				if (idsToDelete.length() > 0) {
					UserProfileMyFavorites.removeAllByIds(idsToDelete, null);
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}		
	}
	
	public int addToMyFavorites(String userUID, String contentUUID) {
		long currentTime = System.currentTimeMillis();
		try {
			// Load maxFavoriteServices from personalPersonalization table.
			UserProfileManagement profileManagement = new UserProfileManagement();
			int maxFavoriteServices = profileManagement.getMaxFavoriteServicesByUserUIDAndProfileType(userUID, MySpaceConstants.USER_PROFILE_TYPE_PERSONAL);
			if (maxFavoriteServices == 0) {
				maxFavoriteServices = 10;
			}						
			UserProfileMyFavorites userProfileMyFavorites = new UserProfileMyFavorites();
			// Load all services per userUID.
			UserProfileMyFavorites[] currentFavoriteServices = null; 
			try {
				currentFavoriteServices = UserProfileMyFavorites.findAllByUserUID(userUID, null); 				
				if (currentFavoriteServices != null && currentFavoriteServices.length >= maxFavoriteServices) {
					String idsToDelete = "";
					for (int i = 0; i < currentFavoriteServices.length; i++) {
						if (i >= maxFavoriteServices - 1) {
							if (idsToDelete.length() > 0) {
								idsToDelete += ",";
							}
							idsToDelete += currentFavoriteServices[i].getId();
						}
					}
					if (idsToDelete.length() > 0) {
						UserProfileMyFavorites.removeAllByIds(idsToDelete, null);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}					
			
			userProfileMyFavorites.setUserUID(userUID);
			userProfileMyFavorites.setContentUUID(contentUUID); 
			userProfileMyFavorites.setCreationDate(MySpaceUtils.timeMillisToTimestamp(currentTime));
			userProfileMyFavorites.create(null);
			return 1;
		} catch (Exception e) {
			System.out.println("MyFavoriteServicesManagement : addToMyFavorites : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}
	
	public int removeFromMyFavorites(String userUID, String contentUUID) {
		try {
			UserProfileMyFavorites.removeByUserUIDAndContentUUID(userUID, contentUUID, null);
			return 1;
		} catch (Exception e) {
			System.out.println("MyFavoriteServicesManagement : removeFromMyFavorites : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}
	
	public int removeAllFromMyFavorites(String userUID) {
		try {
			UserProfileMyFavorites.removeAllByUserUID(userUID, null);
			return 1;
		} catch (Exception e) {
			System.out.println("MyFavoriteServicesManagement : removeAllFromMyFavorites : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

}
