package com.ibs.myspace.portlet.management;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

import javax.net.ssl.SSLSocket;
import javax.servlet.http.HttpServletRequest;

//import java.util.Base64;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.db.DBTransaction;
import com.ibs.myspace.portlet.db.QueryExecution;
import com.ibs.myspace.portlet.dbo.ETranslationRequest;
import com.ibs.myspace.portlet.utils.Logger;
import com.ibs.myspace.portlet.utils.MySpaceUtils;


public class ETranslationRequestManagement {
	MySpaceUtils utils = null;
	
	public ETranslationRequestManagement() {
		utils = new MySpaceUtils();
	}
	
	public String createETranslationRequestText(String requestId, String sourceLanguage, String targetLanguage, long creationTime) {
		try {
			ETranslationRequest translationRequest = new ETranslationRequest();
			translationRequest.setRequestId(requestId);
			translationRequest.setSourceLanguage(sourceLanguage);
			translationRequest.setTargetLanguage(targetLanguage);
			translationRequest.setCreationDate(MySpaceUtils.timeMillisToTimestamp(creationTime));
			translationRequest.create();
			return translationRequest.getId();
		} catch (Exception e) {
			e.printStackTrace(); 
		}
		return null;
	}
	
	public void updateETranslationRequestText(String requestId, String translatedText, String targetLanguage, long responseTime) {
		ETranslationRequest translationRequest = null;
		List<ETranslationRequest> translationRequests = null;
		QueryExecution qe = new QueryExecution();
		try {
			translationRequests = qe.findETranslationRequestsNoBLOB(requestId, null, false, null);
			if (translationRequests != null && translationRequests.size() > 0) {
				translationRequest = translationRequests.get(0);
			}
		} catch (Exception e) { 
			e.printStackTrace();
		}
		if (translationRequest != null) {
			translationRequest.setTranslation(translatedText != null && translatedText.length() > 6980 ? translatedText.substring(0, 6980) : translatedText);
			if (targetLanguage != null && targetLanguage.trim().length() > 0) {
				translationRequest.setTargetLanguage(targetLanguage);
			}
			translationRequest.setResponseTime(MySpaceUtils.timeMillisToTimestamp(responseTime));
			try {
				translationRequest.store();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
		translationRequests = null;
	}
	
	public ETranslationRequest getETranslationRequestFile(long eTranslationRequestId, int type) {
		QueryExecution qe = new QueryExecution();
		try {
			return qe.findETranslationRequestFile(eTranslationRequestId, type, null);
		} catch (Exception e) { 
			e.printStackTrace();
		}
		return null;
	}
	
	public String createETranslationRequestFile(
			HttpServletRequest request, 
			String sourceLanguage, 
			String targetLanguage, 
			InputStream document, 
			long documentSize, 
			String documentName, 
			String documentContentType, 
			String userProfileId,
			String email) {
		
		boolean isProduction = "PROD".equalsIgnoreCase(System.getProperty("environment"));
		boolean isTest = !isProduction && "TEST".equalsIgnoreCase(System.getProperty("environmentType"));
		String userName = MySpaceConstants.E_TRANSLATION_USERNAME;
	    String password = MySpaceConstants.E_TRANSLATION_PASSWORD;
	    long creationTime = System.currentTimeMillis();
	    String id = null;
	     
	    try { 
	    	
	    	StringBuilder stringBuilder = new StringBuilder();
	    	InputStreamReader reader = new InputStreamReader(document, "ISO-8859-1"); 	    	
		    try (BufferedReader bufferedReader = new BufferedReader(reader)) {
		        char[] charBuffer = new char[1024];
		        int bytesRead;
		        while ((bytesRead = bufferedReader.read(charBuffer)) > 0) {
		            stringBuilder.append(charBuffer, 0, bytesRead);
		        }
		        try {
		        	reader.close();
			        bufferedReader.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
		    } 
		    
		    String fileString = stringBuilder.toString();
		    String documentToTranslateBase64 = new String(Base64.encodeBase64(fileString.getBytes("ISO-8859-1")));
		    String fileName = documentName;
		    String ext = "txt";
		    if (documentName.lastIndexOf(".") != -1) {
		    	ext = documentName.substring((documentName.lastIndexOf(".") + 1));
		    	fileName = documentName.substring(0, documentName.lastIndexOf("."));
		    }		    
		    
			//Creating the HttpClientBuilder
	        HttpClientBuilder clientbuilder = HttpClients.custom();
	        
	        int timeout = 15 * 1000;// 15 seconds.
	        // Set timeout.
	        RequestConfig config = RequestConfig.custom().setConnectTimeout(timeout).setSocketTimeout(timeout).build();	        	        
	        clientbuilder.setDefaultRequestConfig(config);
	        //Create an object of credentialsProvider
	        CredentialsProvider credentialsPovider = new BasicCredentialsProvider();
	        Credentials credentials = new UsernamePasswordCredentials(userName, password);
	        credentialsPovider.setCredentials(AuthScope.ANY,credentials);
	
	        //Setting the credentials
	        clientbuilder = clientbuilder.setDefaultCredentialsProvider(credentialsPovider);
	
	        // Setting the TLS Version Dynamicall.
	        SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(SSLContexts.createDefault()){
	            @Override
	            protected void prepareSocket(SSLSocket socket) {
	            	socket.setEnabledProtocols(new String[] {"TLSv1.2"});	                
	            }
	        };
	        CloseableHttpClient httpclient = clientbuilder.setSSLSocketFactory(sslsf).build();	      

	        // We cannot use new URL() for getting current url as we use modified request object (we are inside portlet scope)
	        String callBackURL = null;
	        String errorCallBackURL = null;
	        
	        if (isProduction) {
	        	callBackURL = "https://egov.bg/wps/PA_MySpace/etranslation-receive-file-callback";
	        	errorCallBackURL = "https://egov.bg/wps/PA_MySpace/etranslation-receive-callback-error";
	        	Logger.log(Logger.DEBUG_LEVEL, "ETranslationRequestManagement -> createETranslationRequestFile(): [prod] callBackURL=" + callBackURL);
	        } else {
	        	if (!isTest) {
	        		callBackURL = "https://egov.bg/eTranslation-dispatcher/etranslation-receive-file-callback";
	        		errorCallBackURL = "https://egov.bg/eTranslation-dispatcher/etranslation-receive-callback-error";
	        		Logger.log(Logger.DEBUG_LEVEL, "ETranslationRequestManagement -> createETranslationRequestFile(): [staging] callBackURL=" + callBackURL);
	        	} else {
	        		callBackURL = "https://egov.bg/eTranslation-dispatcher/etranslation-test-receive-file-callback";
	        		errorCallBackURL = "https://egov.bg/eTranslation-dispatcher/etranslation-test-receive-callback-error";
	        		Logger.log(Logger.DEBUG_LEVEL, "ETranslationRequestManagement -> createETranslationRequestFile(): [test] callBackURL=" + callBackURL);
	        	}
	        }
	        HttpPost post = new HttpPost(MySpaceConstants.E_TRANSLATION_URL);
	        
	        System.out.println(createTranslationRequestJSON(sourceLanguage, targetLanguage, documentToTranslateBase64, ext, fileName, callBackURL, errorCallBackURL, email).toString());
	        post.setEntity(new StringEntity(createTranslationRequestJSON(sourceLanguage, targetLanguage, documentToTranslateBase64, ext, fileName, callBackURL, errorCallBackURL, email), ContentType.APPLICATION_JSON));
	        //HttpClientParams.setRedirecting(post.getParams(), false);
	        
	        HttpResponse httpResponse = httpclient.execute(post);
	        int idRequest = Integer.parseInt(EntityUtils.toString(httpResponse.getEntity()));
	        Logger.log(Logger.DEBUG_LEVEL, "ETranslationRequestManagement -> createETranslationRequestFile(): idRequest=" + idRequest);
	        if (idRequest > 0) {	        	
				QueryExecution qe = new QueryExecution();
				id = qe.createETranslationRequestFile(
					idRequest+"", 
					sourceLanguage, 
					targetLanguage, 
					fileString.getBytes("ISO-8859-1"), 
					documentSize, 
					documentName, 
					documentContentType,
					userProfileId, 
					creationTime, 
					null);
	        } else {
	        	
	        }
		} catch (Exception e) {
			e.printStackTrace();
		}
    	return id;
	}
	
	public int updateETranslationRequestFile(String requestId, byte[] translatedDocument, String targetLanguage, long responseTime) {
		ETranslationRequest translationRequest = null;
		List<ETranslationRequest> translationRequests = null;
		QueryExecution qe = new QueryExecution();
		try {
			translationRequests = qe.findETranslationRequestsNoBLOB(requestId, null, true, null);
			if (translationRequests != null && translationRequests.size() > 0) {
				translationRequest = translationRequests.get(0);
			}
		} catch (Exception e) { 
			e.printStackTrace();
		}
		int updated = -1;
    	if (translationRequest != null) {	        		
    		try {
    			updated = qe.updateETranslationRequestFile(
    					requestId, 
    					translatedDocument, 
    					targetLanguage, 
    					MySpaceUtils.timeMillisToTimestamp(responseTime), 
    					null);
			} catch (Exception e) {
				e.printStackTrace();
			}
    	}
    	translationRequests = null;
    	return updated;
	}
	
	public void updateETranslationRequestError(String requestId, String errorCode, String errorMessage, long responseTime) {
		ETranslationRequest translationRequest = null;
		List<ETranslationRequest> translationRequests = null;
		QueryExecution qe = new QueryExecution();
		try {
			translationRequests = qe.findETranslationRequestsNoBLOB(requestId, null, true, null);
			if (translationRequests != null && translationRequests.size() > 0) {
				translationRequest = translationRequests.get(0);
			}
		} catch (Exception e) { 
			e.printStackTrace();
		}
		if (translationRequest != null) {
			translationRequest.setErrorCode(errorCode);
			translationRequest.setErrorMessage(errorMessage);
			translationRequest.setResponseTime(MySpaceUtils.timeMillisToTimestamp(responseTime));
			try {
				translationRequest.store();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}	
		translationRequests = null;
	}
	
	public List<ETranslationRequest> findAllETranslationRequestsByUserProfileId(String userProfileId) {
		QueryExecution qe = new QueryExecution();
		try {
			return qe.findETranslationRequestsNoBLOB(null, userProfileId, true, null);
		} catch (Exception e) { 
			e.printStackTrace();
		}
		return null;
	}
	
	public ETranslationRequest findETranslationRequestByRequestId(String requestId, boolean isDocument) {
		List<ETranslationRequest> translationRequests = null;
		QueryExecution qe = new QueryExecution();
		try {
			translationRequests = qe.findETranslationRequestsNoBLOB(requestId, null, isDocument, null);
			if (translationRequests != null && translationRequests.size() > 0) {
				return translationRequests.get(0);
			}
		} catch (Exception e) { 
			e.printStackTrace();
		}
    	return null;
	}
	
	public int clearExpiredETranslationRequests(long expireTime, DBTransaction transaction) {
		QueryExecution qe = new QueryExecution();
		try {
			return qe.clearExpiredETranslationRequests(MySpaceUtils.timeMillisToTimestamp(expireTime), null);
		} catch (Exception e) { 
			e.printStackTrace();
		}
		return 0;
	}
	
	public int deleteETranslationRequest(String eTranslationRequestId, DBTransaction transaction) {
		QueryExecution qe = new QueryExecution();
		try {
			return qe.deleteETranslationRequest(eTranslationRequestId, null);
		} catch (Exception e) { 
			e.printStackTrace();
		}
		return 0;
	}
	
	private String createTranslationRequestJSON(
			String sourceLanguage, 
			String targetLanguage, 
			String documentToTranslateBase64, 
			String format, 
			String fileName, 
			String callBackURL, 
			String errorCallBackURL,
			String email) {
		
		JSONObject destinations = new JSONObject();
		
		destinations.put("httpDestinations", new JSONArray().put(0, callBackURL));
		if (email != null && email.trim().length() > 0) {
			destinations.put("emailDestinations", new JSONArray().put(0, email));
		} 				
	    return new JSONObject()
	            .put("callerInformation", new JSONObject()
	                    .put("application", MySpaceConstants.E_TRANSLATION_USERNAME)
	                    .put("username", MySpaceConstants.E_TRANSLATION_PASSWORD))
	            .put("documentToTranslateBase64", new JSONObject()
	            		.put("content", documentToTranslateBase64)
	            		.put("format", format)
	            		.put("file-name", fileName))
	            //.put("output-format", format)
	            .put("sourceLanguage", sourceLanguage)
	            .put("errorCallback", errorCallBackURL)
	            .put("targetLanguages", new JSONArray().put(0, targetLanguage))
	            .put("destinations", destinations)
	            .toString();
	} 
	
}
