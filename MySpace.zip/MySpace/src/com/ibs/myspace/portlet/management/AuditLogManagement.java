package com.ibs.myspace.portlet.management;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.ibs.myspace.portlet.MySpacePortlet;
import com.ibs.myspace.portlet.bean.AuditLogBean;
import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.dbo.UserProfileAuditLog;
import com.ibs.myspace.portlet.utils.Logger;
import com.ibs.myspace.portlet.utils.MySpaceUtils;


public class AuditLogManagement {
	
	public AuditLogBean[] loadAllAuditLogs(String userUID, String activityName, String fromDate, String toDate, String order, int limit, boolean distinct) {	
		Logger.log(Logger.DEBUG_LEVEL, "AuditLogManagement -> loadAllAuditLogs(" + userUID + "," + activityName + ", " + fromDate + ", " + toDate + "," + order + ")");
		try {
			Logger.log(Logger.DEBUG_LEVEL, "AuditLogManagement -> loadAllAuditLogs() call retrieveEvent()...");
	        String result = retrieveEvent(userUID, activityName, fromDate, toDate, order, limit, distinct);
	        Logger.log(Logger.DEBUG_LEVEL, "AuditLogManagement -> loadAllAuditLogs() retrieveEvent Result: " + result);	        
	        try {
	        	if (result != null && result.trim().length() > 0) {
		        	JSONObject jsonObject = new JSONObject(result);
		            JSONObject jo = new JSONObject(result);
		            JSONArray ja = jsonObject.getJSONArray("events");
		            if (ja != null && ja.length() > 0) {
		            	Logger.log(Logger.DEBUG_LEVEL, "AuditLogManagement -> loadAllAuditLogs(): total:" + ja.length());
		            	AuditLogBean[] auditLogBeans = new AuditLogBean[ja.length()];
		            	AuditLogBean auditLogBean = null;
		            	for (int i = 0; i < ja.length(); i++) {
		            		jo = ja.getJSONObject(i);
		            		Logger.log(Logger.DEBUG_LEVEL, "AuditLogManagement -> loadAllAuditLogs():userId=" + jo.get("userId").toString());
		            		Logger.log(Logger.DEBUG_LEVEL, "AuditLogManagement -> loadAllAuditLogs():activity=" + jo.get("activity").toString());
		            		Logger.log(Logger.DEBUG_LEVEL, "AuditLogManagement -> loadAllAuditLogs():activityDetails=" + jo.get("activityDetails").toString());
		            		Logger.log(Logger.DEBUG_LEVEL, "AuditLogManagement -> loadAllAuditLogs():page=" + jo.get("page").toString());
		            		Logger.log(Logger.DEBUG_LEVEL, "AuditLogManagement -> loadAllAuditLogs():ipaddress=" + jo.get("ipAddress").toString());
		            		Logger.log(Logger.DEBUG_LEVEL, "AuditLogManagement -> loadAllAuditLogs():dateCreated=" + jo.get("dateCreated").toString());
		            		auditLogBean = new AuditLogBean();
		            		auditLogBean.setUserId(jo.get("userId").toString());
		            		auditLogBean.setActivityName(jo.get("activity").toString());
		            		auditLogBean.setActivityDescription(jo.get("activityDetails").toString());
		            		auditLogBean.setPage(!"null".equals(jo.get("page").toString()) ? jo.get("page").toString() : "");
		            		auditLogBean.setIpAddress(jo.get("ipAddress") != null && !"null".equals(jo.get("ipAddress").toString()) ? jo.get("ipAddress").toString() : null);
		            		auditLogBean.setDateCreated(jo.get("dateCreated").toString());		            		
							auditLogBeans[i] = auditLogBean;
						}
		            	return auditLogBeans;		            	
		            }
	        	}
	       } catch (JSONException err){
	           err.printStackTrace();
	       }
		} catch (Exception e) {
			e.printStackTrace();
		} 
		return null;
	}
	
	private String retrieveEvent(String userUID, String activityName, String fromDate, String toDate, String order, int limit, boolean distinct) {
		Logger.log(Logger.DEBUG_LEVEL, "AuditLogManagement -> retrieveEvent(" + userUID + "," + activityName + ", " + fromDate + ", " + toDate + "," + order + "," + limit + "," + distinct + ")");
		StringBuilder strBuf = new StringBuilder();

        HttpsURLConnection conn = null;
        BufferedReader reader = null;
        
        try {
			// Create a trust manager that does not validate certificate chains.
	        TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
	            public java.security.cert.X509Certificate[] getAcceptedIssuers() {return null;}
	            public void checkClientTrusted(X509Certificate[] certs, String authType) {}
	            public void checkServerTrusted(X509Certificate[] certs, String authType) {}
	        }
	        };
	
	        Logger.log(Logger.DEBUG_LEVEL, "AuditLogManagement -> retrieveEvent() trustAllCerts - done.");
	        // Install the all-trusting trust manager.
	        SSLContext sc = SSLContext.getInstance("SSL");
	        sc.init(null, trustAllCerts, new java.security.SecureRandom());
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
	        
	        Logger.log(Logger.DEBUG_LEVEL, "AuditLogManagement -> retrieveEvent() SSLContext init - done.");
	
	        // Create all-trusting host name verifier.
	        HostnameVerifier allHostsValid = new HostnameVerifier() {
	            public boolean verify(String hostname, SSLSession session) {
	                return true;
	            }
	        };
	
	        // Install the all-trusting host verifier.
	        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
	        
	        Logger.log(Logger.DEBUG_LEVEL, "AuditLogManagement -> retrieveEvent() allHostsValid - done.");
	        Logger.log(Logger.DEBUG_LEVEL, "AuditLogManagement -> retrieveEvent() url:" + MySpacePortlet.esbEventLogAddress + "/retrieveEvent");
	       
	        URL url = new URL(MySpacePortlet.esbEventLogAddress + "/retrieveEvent");
	        conn = (HttpsURLConnection) url.openConnection();
	        conn.setConnectTimeout(5000); //set timeout to 5 seconds
	        conn.setReadTimeout(5000); //set timeout to 5 seconds
	        
	        conn.setRequestMethod("GET");
	        conn.setRequestProperty("Content-Type", "application/json; utf-8");
	        conn.setRequestProperty("Accept", "application/json");
	        if (fromDate != null && fromDate.trim().length() > 0) {
	        	conn.setRequestProperty("fromDate", fromDate);
	        }
	        if (toDate != null && toDate.trim().length() > 0) {
	        	conn.setRequestProperty("toDate", toDate);
	        }
	        if (activityName != null && activityName.trim().length() > 0) {
	        	conn.setRequestProperty("activity", activityName);
	        }        
	        if (order == null || order.trim().length() == 0) {
	        	order = "DESC";
	        }
	        conn.setRequestProperty("order", order);
	        if (limit > 0) {
	        	conn.setRequestProperty("limit", limit + "");
	        }
	        if (distinct) {
	        	conn.setRequestProperty("distinct", "1");
	        }
	        conn.setRequestProperty("userId", userUID);	        
	        Logger.log(Logger.DEBUG_LEVEL, "AuditLogManagement -> retrieveEvent() before setDoOutput - done.");
	        conn.setDoOutput(true);
	
	        if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
	        	if (conn.getResponseCode() == HttpURLConnection.HTTP_NOT_FOUND) {
	        		return null;
	        	}
	            throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode());
	        }
	
	        Logger.log(Logger.DEBUG_LEVEL, "AuditLogManagement -> retrieveEvent() after setDoOutput, going to read response.");
	        
	        reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
	        String output = null;
	        while ((output = reader.readLine()) != null) {
	            strBuf.append(output);
	        }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
        
        Logger.log(Logger.DEBUG_LEVEL, "AuditLogManagement -> retrieveEvent() done.");

        return strBuf.toString();
	}
	
	public int sendEvent(String userUID, String activityName, String activityDetails, String page, String remoteIP, boolean isForCentralAuditLog) {
		int result = 0;
		Logger.log(Logger.ERROR_LEVEL, "sendEvent(" + userUID + "," + activityName + "," + activityDetails + "," + page + "," + remoteIP + ", " + isForCentralAuditLog + ")");
		// Create a trust manager that does not validate certificate chains
        TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
            public java.security.cert.X509Certificate[] getAcceptedIssuers() {return null;}
            public void checkClientTrusted(X509Certificate[] certs, String authType) {}
            public void checkServerTrusted(X509Certificate[] certs, String authType) {}
        }
        };

        try {
        	// Install the all-trusting trust manager
	        SSLContext sc = SSLContext.getInstance("SSL");
	        sc.init(null, trustAllCerts, new java.security.SecureRandom());
	        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

	        // Create all-trusting host name verifier
	        HostnameVerifier allHostsValid = new HostnameVerifier() {
	            public boolean verify(String hostname, SSLSession session) {
	                return true;
	            }
	        };
	        // Install the all-trusting host verifier
	        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
			StringBuilder strBuf = new StringBuilder();
	        HttpsURLConnection conn = null;
	        BufferedReader reader = null;
	        try {
	        	if (page == null) {
	        		page = "";
	        	}
	        	JSONObject jsonObject = new JSONObject();
	        	jsonObject.put("userId", userUID);
	        	jsonObject.put("activity", activityName);
	        	jsonObject.put("activityDetails", activityDetails);
	        	jsonObject.put("page", page);
	        	jsonObject.put("ipAddress", remoteIP);
	        	String json = jsonObject.toString();
	        	 
//	            String json = "{\n" +
//	                    "  \"userId\": \"" + userUID + "\",\n" +
//	                    "  \"activity\": \"" + activityName + "\",\n" +
//	                    "  \"activityDetails\": \"" + activityDetails + "\",\n" +
//	                    "  \"page\": \"" + page + "\",\n" +
//	                    "  \"ipAddress\": \"" + remoteIP + "\"\n" +
//	                    "}";
	        	
	        	// Call for addEvent.	            
	            URL url = new URL(MySpacePortlet.esbEventLogAddress + "/addEvent");
	            conn = (HttpsURLConnection) url.openConnection();
	            conn.setRequestMethod("POST");
	            conn.setRequestProperty("Content-Type", "application/json; utf-8");
	            conn.setRequestProperty("Accept", "application/json");
	            conn.setRequestProperty("isForCentralAuditLog", String.valueOf(isForCentralAuditLog));
	            conn.setConnectTimeout(5000); // 5 seconds
	            conn.setReadTimeout(5000); // 5 seconds
	            conn.setDoOutput(true);	            
	
	            try (OutputStream os = conn.getOutputStream()) {
	                byte[] input = json.getBytes("utf-8");
	                os.write(input, 0, input.length);
	            }
	
	            if (conn.getResponseCode() != 200) {
	                throw new RuntimeException("HTTP POST Request Failed with Error code : "
	                        + conn.getResponseCode());
	            }
	
	            reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
	            String output = null;
	            while ((output = reader.readLine()) != null) {
	                strBuf.append(output);
	            }
	            result = 1;
	        } catch (IOException e) {
	            e.printStackTrace();
	        } finally {
	            if (reader != null) {
	                try {
	                    reader.close();
	                } catch (IOException e) {
	                    e.printStackTrace();
	                }
	            }
	            if (conn != null) {
	                conn.disconnect();
	            }
	        }
        
        } catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public int addAuditLog(String userUID, String contentUUID, String type, String remoteIP) {
		long currentTime = System.currentTimeMillis();
		boolean create = false;
		try {
			UserProfileAuditLog userProfileAuditLog = null;
			try {
				userProfileAuditLog = UserProfileAuditLog.findByUserUIDAndContentUUIDAndType(userUID, contentUUID, type, null);
			} catch (FinderException e) {
			} catch (Exception e) {
				e.printStackTrace();
			} 
			if (userProfileAuditLog == null) {
				userProfileAuditLog = new UserProfileAuditLog();
				create = true;
			}
			userProfileAuditLog.setUserUID(userUID);
			userProfileAuditLog.setContentUUID(contentUUID); 
			userProfileAuditLog.setType(type); 
			userProfileAuditLog.setRemoteIPAddress(remoteIP);
			userProfileAuditLog.setCreationDate(MySpaceUtils.timeMillisToTimestamp(currentTime));
			if (create) {
				userProfileAuditLog.create(null);
			} else {
				userProfileAuditLog.store(null);
			}
			return 1;
		} catch (Exception e) {
			System.out.println("AuditLogManagement : addAuditLog : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}
	
	public int removeFromAuditLog(String userUID, String contentUUID) {
		try {
			UserProfileAuditLog.removeByUserUIDAndContentUUID(userUID, contentUUID, null);
			return 1;
		} catch (Exception e) {
			System.out.println("AuditLogManagement : removeFromAuditLog : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}
	
	public int removeAllFromAuditLog(String userUID) {
		try {
			UserProfileAuditLog.removeAllByUserUID(userUID, null);
			return 1;
		} catch (Exception e) {
			System.out.println("AuditLogManagement : removeAllFromAuditLog : " + e.getMessage());
			e.printStackTrace();
		}
		return -1;
	}

	public static void main(String[] args) {
		String userUID = "76782905d742d3225e56bf9fb012175116";
		String activityName = "PORTAL_SWITCH_PROFILE";
		String activityDetails = "Текущият профил \"Юлия Узунова\" беше сменен с \"Булпрос Консултинг ЕАД\"";
		String page = "";
		String remoteIP = "195.24.36.69";
		JSONObject jsonObject = new JSONObject();
    	jsonObject.put("userId", userUID);
    	jsonObject.put("activity", activityName);
    	jsonObject.put("activityDetails", activityDetails);
    	jsonObject.put("page", page);
    	jsonObject.put("ipAddress", remoteIP);
    	System.out.println(jsonObject.toString());
	}
}
