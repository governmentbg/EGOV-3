package com.ibs.myspace.portlet;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import com.ibs.myspace.portlet.db.Base;
import com.ibs.myspace.portlet.db.DBPool;
import com.ibs.myspace.portlet.db.DBResources;
import com.ibs.myspace.portlet.utils.Logger;

@WebListener
public class InitializeListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        ServletContext servletContext = sce.getServletContext();
        String realPath = servletContext.getRealPath("/");
        Base.REAL_PATH = realPath;
        Base.TEST_ENVIRONMENT = "TEST".equalsIgnoreCase(System.getProperty("environmentType"));
        Base.PRODUCTION_ENVIRONMENT = "PROD".equalsIgnoreCase(System.getProperty("environment"));
        System.out.println(MySpaceConstants._PRODUCT_NAME + " " + MySpaceConstants._PRODUCT_VERSION + " | APPLICATION IS UP!");
        DBResources.init(realPath);
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        Logger.log(Logger.DEBUG_LEVEL, "STOPPING ALL THREADS");        
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Logger.log(Logger.DEBUG_LEVEL, "SHUT DOWN DATASOURCE...");
        DBPool.shutdownDataSource();
        Logger.log(Logger.DEBUG_LEVEL, "STOP FINISHED");
    }

}