package com.ibs.myspace.portlet.servlet;

import java.io.IOException;
import java.util.Base64;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibs.myspace.portlet.db.FinderException;
import com.ibs.myspace.portlet.dbo.ETranslationRequest;
import com.ibs.myspace.portlet.utils.Logger;

@WebServlet("/etranslation-receive-callback")
public class ETranslationReceiveCallback extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Logger.log(Logger.ERROR_LEVEL, "ETranslationReceiveCallback -> doGet()");
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("ETranslationReceiveCallback -> doPost(" + request.getParameter("request-id") + ") start...");
		request.setCharacterEncoding("utf8");
		response.setHeader("Cache-Control", "no-cache");
		response.setContentType("text/plain; charset=UTF-8");
		
		String idRequest = request.getParameter("request-id");
		String targetLanguage = request.getParameter("target-language");
		String translatedText = request.getParameter("translated-text");
		boolean isProduction = "PROD".equalsIgnoreCase(System.getProperty("environment"));
		System.out.println("ETranslationReceiveCallback -> response received [" +  idRequest + "][encoded>" + translatedText + "]");
		
		// Use lines below only for STAGE.
		if (!isProduction) {
			translatedText = translatedText.replaceAll(" ", "+"); // this fix base64 encoding bug.
			translatedText = new String(Base64.getDecoder().decode(translatedText), "UTF-8");
		}
		System.out.println("ETranslationReceiveCallback -> response received [" +  idRequest + "][" + translatedText + "]");
		ETranslationRequest translationRequest = null;
		try {
			translationRequest = ETranslationRequest.findByRequestId(idRequest, null);
		} catch (FinderException fe) {
		} catch (Exception e) { 
			e.printStackTrace();
		}
    	if (translationRequest != null) {
    		translationRequest.setTranslation(translatedText);
    		translationRequest.setTargetLanguage(targetLanguage);
    		try {
				translationRequest.store();
			} catch (Exception e) {
				e.printStackTrace();
			}
    	}
	}
}
