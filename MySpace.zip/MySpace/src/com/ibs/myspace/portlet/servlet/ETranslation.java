package com.ibs.myspace.portlet.servlet;

import java.io.IOException;
import java.net.URL;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.Credentials;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.ibm.portal.um.PumaController;
import com.ibm.portal.um.PumaHome;
import com.ibm.portal.um.PumaProfile;
import com.ibm.portal.um.exceptions.PumaException;
import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.dbo.ETranslationRequest;
import com.ibs.myspace.portlet.utils.Logger;
import com.ibs.myspace.portlet.utils.MySpaceUtils;

@WebServlet("/etranslation")
public class ETranslation extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	private static final String OPERATION_SEND_FOR_TRANSLATION = "1";
	private static final String OPERATION_CHECK_RESPONSE = "2";
	
	public static boolean userLoggedIn = false;
	public static boolean debug = false;
	public static com.ibm.portal.um.User currentUser = null;
	private static PumaHome pumaHome = null;	
	public static String currentUserDN = null;
	public static String currentUserUID = null;
	public static final String LDAP_ATTRIBUTE_UID = "uid";

	
	public void init(ServletConfig config) throws ServletException {
		super.init();
		InitialContext initialcontext;
		try {
			initialcontext = new InitialContext();
			pumaHome = (PumaHome) initialcontext.lookup("portal:service/usermanagement/Puma");
		} catch (NamingException namingexception) {
			namingexception.printStackTrace();
		}
		Logger.log(Logger.ERROR_LEVEL, "ETranslation -> init() done!");
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Logger.log(Logger.ERROR_LEVEL, "ETranslation -> doGet(" + request.getParameter("op") + ")");
		request.setCharacterEncoding("utf8");	
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("ETranslation -> doPost(" + request.getParameter("op") + ") start...");
		request.setCharacterEncoding("utf8");
		response.setHeader("Cache-Control", "no-cache");
		response.setContentType("text/plain; charset=UTF-8");
		if (getPumaHome() != null) {
			PumaProfile pumaProfile = getPumaHome().getProfile();
			if (pumaProfile != null) {
				try {
					com.ibm.portal.um.User user = pumaProfile.getCurrentUser();
					if (user != null) {
						String operation =  request.getParameter("op");
						if (OPERATION_SEND_FOR_TRANSLATION.equals(operation)) {
							sendForTranslation(request, response);
						} else if (OPERATION_CHECK_RESPONSE.equals(operation)) {			
							String idRequest = request.getParameter("idRequest");
							boolean last = "1".equals(request.getParameter("last"));
							if (idRequest != null && idRequest.trim().length() > 0) {
								ETranslationRequest translationRequest = null;
								try {
									translationRequest = ETranslationRequest.findByRequestId(idRequest, null);
								} catch (Exception e) {
									e.printStackTrace();
								}
					        	if (translationRequest != null) {
									String eResponse = translationRequest.getTranslation();
									System.out.println("ETranslation -> doPost(): eResponse=" + eResponse);
									if (eResponse != null && eResponse.trim().length() > 0) {
										response.getWriter().print(eResponse != null ? eResponse : "");
										try {translationRequest.remove();} catch (Exception e) {e.printStackTrace();}										
									} else if (last){
										try {translationRequest.remove();} catch (Exception e) {e.printStackTrace();}
									}
					        	}
							}
						}
					}
				} catch (PumaException e) {
					System.out.println(e.getMessage());
					e.printStackTrace();
				}
			}
		}
		response.getWriter().flush();
		response.getWriter().close();
	}
	
	private void sendForTranslation(HttpServletRequest request, HttpServletResponse response) {
		try {     
			boolean isProduction = "PROD".equalsIgnoreCase(System.getProperty("environment"));
			boolean isTest = !isProduction && "TEST".equalsIgnoreCase(System.getProperty("environmentType"));
			String sourceLanguage = request.getParameter("sourceLanguage");
			String targetLanguage = request.getParameter("targetLanguage");
			String textToTranslate = request.getParameter("textToTranslate");
	        String userName = MySpaceConstants.E_TRANSLATION_USERNAME;
	        String password = MySpaceConstants.E_TRANSLATION_PASSWORD; 	        
	        // JSP encoding is "ISO-8859-1", so each parameter that can be text, should be converted to UTF-8;
	        textToTranslate = new String(textToTranslate.getBytes("ISO-8859-1"), "UTF-8");
	        System.out.println("textToTranslate=" + textToTranslate);
	        System.out.println("sourceLanguage=" + sourceLanguage);
	        System.out.println("targetLanguage=" + targetLanguage);
	        
	        //Creating the HttpClientBuilder
	        HttpClientBuilder clientbuilder = HttpClients.custom();
	        
	        int timeout = 15 * 1000;// 15 seconds.
	        // Set timeout.
	        RequestConfig config = RequestConfig.custom().setConnectTimeout(timeout).setSocketTimeout(timeout).build();	        	        
	        clientbuilder.setDefaultRequestConfig(config);
	        //Create an object of credentialsProvider
	        CredentialsProvider credentialsPovider = new BasicCredentialsProvider();
	        Credentials credentials = new UsernamePasswordCredentials(userName, password);
	        credentialsPovider.setCredentials(AuthScope.ANY,credentials);

	        //Setting the credentials
	        clientbuilder = clientbuilder.setDefaultCredentialsProvider(credentialsPovider);

	        //Building the CloseableHttpClient object
	        CloseableHttpClient httpclient = clientbuilder.build();

	        String callBackURL = new URL(request.getRequestURL().toString()).getProtocol() + "://" + new URL(request.getRequestURL().toString()).getHost() + (((-1 == new URL(request.getRequestURL().toString()).getPort() || (80 == new URL(request.getRequestURL().toString()).getPort()) || (443 == new URL(request.getRequestURL().toString()).getPort())) ? "" : ":" + String.valueOf(new URL(request.getRequestURL().toString()).getPort()))) + request.getContextPath();
	        callBackURL += "/etranslation-receive-callback";
	        System.out.println("[original] callBackURL=" + callBackURL);
	        
	        if (!isProduction) {
	        	if (!isTest) {
	        		callBackURL = "https://egov.bg/eTranslation-dispatcher/etranslation-receive-callback";
	        		System.out.println("[staging] callBackURL=" + callBackURL);
	        	} else {
	        		callBackURL = "https://egov.bg/eTranslation-dispatcher/etranslation-test-receive-callback";
	        		System.out.println("[test] callBackURL=" + callBackURL);
	        	}
	        }
	        HttpPost post = new HttpPost(MySpaceConstants.E_TRANSLATION_URL);
	        post.setEntity(new StringEntity(createTranslationRequest(sourceLanguage, targetLanguage, textToTranslate, callBackURL), ContentType.APPLICATION_JSON));
	        //HttpClientParams.setRedirecting(post.getParams(), false);
	        
	        HttpResponse httpResponse = httpclient.execute(post);
	        int idRequest = Integer.parseInt(EntityUtils.toString(httpResponse.getEntity()));
	        System.out.println("idRequest=" + idRequest);
	        if (idRequest > 0) {
	        	ETranslationRequest translationRequest = new ETranslationRequest();
	        	translationRequest.setRequestId(idRequest + "");
	        	translationRequest.setCreationDate(MySpaceUtils.timeMillisToTimestamp(System.currentTimeMillis()));
	        	translationRequest.create();
	        }
	        response.getWriter().print(idRequest);
	   } catch (Exception e) {
		   System.out.println(e.getMessage());
	        e.printStackTrace();
	    }
	}
	
	private String createTranslationRequest(String sourceLanguage, String targetLanguage, String textToTranslate, String callBackURL) {
	    return new JSONObject()
	            .put("callerInformation", new JSONObject()
	                    .put("application", MySpaceConstants.E_TRANSLATION_USERNAME)
	                    .put("username", MySpaceConstants.E_TRANSLATION_PASSWORD))
	            .put("textToTranslate", textToTranslate)
	            .put("sourceLanguage", sourceLanguage)
	            .put("targetLanguages", new JSONArray().put(0, targetLanguage))
	            .put("requesterCallback", callBackURL)
	            .toString();
	} 

	public static PumaHome getPumaHome() {
		return pumaHome;
	}

	public static PumaProfile getPumaProfile() {
		return pumaHome.getProfile();
	}

	public static PumaController getPumaController() {
		return pumaHome.getController();
	}
	
}
