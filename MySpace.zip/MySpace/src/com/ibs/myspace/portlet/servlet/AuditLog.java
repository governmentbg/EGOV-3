package com.ibs.myspace.portlet.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.URL;
import java.security.PrivilegedExceptionAction;
import java.security.cert.X509Certificate;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.ibm.portal.um.PumaController;
import com.ibm.portal.um.PumaEnvironment;
import com.ibm.portal.um.PumaHome;
import com.ibm.portal.um.PumaProfile;
import com.ibm.portal.um.User;
import com.ibm.portal.um.exceptions.PumaException;
import com.ibs.myspace.portlet.MySpaceConstants;
import com.ibs.myspace.portlet.MySpacePortlet;
import com.ibs.myspace.portlet.utils.Logger;

@WebServlet("/audit-log")
public class AuditLog extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	public static boolean userLoggedIn = false;
	public static boolean debug = false;
	public static com.ibm.portal.um.User currentUser = null;
	private static PumaHome pumaHome = null;	
	public static String currentUserDN = null;
	public static String currentUserUID = null;
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	public static final String LDAP_ATTRIBUTE_UID = "uid";

	
	public void init(ServletConfig config) throws ServletException {
		super.init();
		InitialContext initialcontext;
		try {
			initialcontext = new InitialContext();
			pumaHome = (PumaHome) initialcontext.lookup("portal:service/usermanagement/Puma");
		} catch (NamingException namingexception) {
			namingexception.printStackTrace();
		}
		Logger.log(Logger.ERROR_LEVEL, "AuditLog -> init() done!");
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("AuditLog -> doGet(" + request.getParameter("op") + ")");
		Logger.log(Logger.ERROR_LEVEL, "AuditLog -> doGet(" + request.getParameter("op") + ")");
		request.setCharacterEncoding("utf8");	
		// We allow doGet only for the following activities:
		// EVENT_LOG_PORTAL_LAST_VISITED_SERVICE
		// EVENT_LOG_PORTAL_LOGOUT_OPERATION
		if (MySpaceConstants.EVENT_LOG_PORTAL_LAST_VISITED_SERVICE.equals(request.getParameter("op"))
				|| MySpaceConstants.EVENT_LOG_PORTAL_LOGOUT_OPERATION.equals(request.getParameter("op"))) {
			doPost(request, response);	
		} 
	}
	
	@SuppressWarnings({ "rawtypes" })
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("AuditLog -> doPost(" + request.getParameter("op") + ")");
		debug = "true".equalsIgnoreCase(request.getParameter("debug"));
		
		boolean loginEvent = false;
		String activityName = request.getParameter("op");	
		String remoteIP = request.getHeader("X-FORWARDED-FOR");
		if (remoteIP == null) {
			remoteIP = request.getRemoteAddr();
		}
		
		Logger.log(Logger.ERROR_LEVEL, "AuditLog -> doPost() start...[" + activityName + "][" + remoteIP + "][" + InetAddress.getLocalHost() + "]");
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");		
		response.setContentType("application/json; charset=UTF-8");
		
		JSONObject json = new JSONObject();
		JSONObject ja = new JSONObject(); 	
		
		userLoggedIn = false;
		if (getPumaHome() != null) {
			PumaProfile pumaProfile = getPumaHome().getProfile();
			if (pumaProfile != null) {
				try {
					com.ibm.portal.um.User user = pumaProfile.getCurrentUser();
					if (user != null) {
						userLoggedIn = true;
						currentUser = user;
						currentUserDN = pumaProfile.getIdentifier(user);
						Object uid = getUserAttribute(user, LDAP_ATTRIBUTE_UID);
						if (uid != null) {
							currentUserUID = "";
							if (uid instanceof ArrayList && ((ArrayList)uid).size() > 0) {
								for (int i = 0; i < ((ArrayList)uid).size(); i++) {
									if (i > 0) {
										currentUserUID += " ";
									}
									currentUserUID = (String)((ArrayList)uid).get(i);
								}
							} else if (uid instanceof String) {
								currentUserUID = (String)uid;
							}									
						}
						System.out.println("userDN = " + currentUserDN);
						System.out.println("userUID = " + currentUserUID);
					}
				} catch (PumaException e) {
					System.out.println(e.getMessage());
					e.printStackTrace();
				}
			}
		}
		
		// For "Login" activity we don not have the user already registered as logged in, so we need to use the passed uid. 
		if (MySpaceConstants.EVENT_LOG_PORTAL_LOGIN_OPERATION.equals(activityName)
				&& request.getParameter("uID") != null && request.getParameter("uID").trim().length() > 0) {
			loginEvent = true;
		}
		if (userLoggedIn && currentUserUID != null || loginEvent) {					
			
			//String type = MySpaceConstants.AUDIT_LOG_OPERATION_TYPE_VISITED;
			Logger.log(Logger.ERROR_LEVEL, "AuditLog -> doPost() userLoggedIn, currentUserUID=" + currentUserUID + ", op=" + activityName + ", loginEvent=" + loginEvent);
			int result = 0;
			String message = "Възникна грешка!";
			
			
			// Create a trust manager that does not validate certificate chains
	        TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager() {
	            public java.security.cert.X509Certificate[] getAcceptedIssuers() {return null;}
	            public void checkClientTrusted(X509Certificate[] certs, String authType) {}
	            public void checkServerTrusted(X509Certificate[] certs, String authType) {}
	        }
	        };

	        try {
	        	// Install the all-trusting trust manager
		        SSLContext sc = SSLContext.getInstance("SSL");
		        sc.init(null, trustAllCerts, new java.security.SecureRandom());
		        HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

		        // Create all-trusting host name verifier
		        HostnameVerifier allHostsValid = new HostnameVerifier() {
		            public boolean verify(String hostname, SSLSession session) {
		                return true;
		            }
		        };
		        
		        // Install the all-trusting host verifier
		        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
		        boolean isForCentralAuditLog = false;

				if (MySpaceConstants.EVENT_LOG_PORTAL_LOGIN_OPERATION.equalsIgnoreCase(activityName)) {
					String userUID = request.getParameter("uID");
					if (userUID != null && userUID.trim().length() > 0) {
						result = sendEvent(userUID, activityName, "Вход в системата", "", request.getParameter("rIP"), isForCentralAuditLog);
					}
				} else if (MySpaceConstants.EVENT_LOG_PORTAL_LOGOUT_OPERATION.equalsIgnoreCase(activityName)) {
					result = sendEvent(currentUserUID, activityName, "Изход от системата", "", remoteIP, isForCentralAuditLog);
				} else if (MySpaceConstants.EVENT_LOG_PORTAL_LAST_VISITED_SERVICE.equalsIgnoreCase(activityName)) {
					String contentUUID = request.getParameter("uuid");
					if (contentUUID != null && contentUUID.trim().length() > 0) {
						String page = request.getParameter("page");
						result = sendEvent(currentUserUID, activityName, contentUUID, page != null ? page : "", remoteIP, isForCentralAuditLog);
//						AuditLogManagement management = new AuditLogManagement();
//						result = management.addAuditLog(currentUserUID, contentUUID, type, remoteIP);					
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
	        
			if (result == 1) {
				message = "";
			}
			ja.put("result", result);
			ja.put("message", message);			
		} else {
			Logger.log(Logger.ERROR_LEVEL, "AuditLog -> doPost() userLoggedIn=false, exiting with error 403!");
			ja.put("result", "403");
			ja.put("message", "Отказан достъп!");
		}
		
		json.put("data", ja);
		String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
		response.getWriter().print(jsonPrettyPrintString);
		response.getWriter().flush();
		response.getWriter().close();
		
	}
	
	private int sendEvent(String userUID, String activityName, String activityDetails, String page, String remoteIP, boolean isForCentralAuditLog) {
		Logger.log(Logger.ERROR_LEVEL, "sendEvent(" + userUID + "," + activityName + "," + activityDetails + "," + page + "," + remoteIP + ", " + isForCentralAuditLog + ")");
		int result = 0;
		StringBuilder strBuf = new StringBuilder();
        HttpsURLConnection conn = null;
        BufferedReader reader = null;
        try {
        	 // Call for addEvent
            String json = "{\n" +
                    "  \"userId\": \"" + userUID + "\",\n" +
                    "  \"activity\": \"" + activityName + "\",\n" +
                    "  \"activityDetails\": \"" + activityDetails + "\",\n" +
                    "  \"page\": \"" + page + "\",\n" +
                    "  \"ipAddress\": \"" + remoteIP + "\"\n" +
                    "}";
            Logger.log(Logger.ERROR_LEVEL, "sendEvent(): json=" + json);
//            URL url = new URL(MySpaceConstants.ESB_LOGGING_URL + "/addEvent");
            URL url = new URL(MySpacePortlet.esbEventLogAddress + "/addEvent");
            conn = (HttpsURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json; utf-8");
            conn.setRequestProperty("Accept", "application/json");
            conn.setRequestProperty("isForCentralAuditLog", String.valueOf(isForCentralAuditLog));
            conn.setDoOutput(true);

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = json.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("HTTP GET Request Failed with Error code : " + conn.getResponseCode());
            }

            reader = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
            String output = null;
            while ((output = reader.readLine()) != null) {
                strBuf.append(output);
            }
            result = 1;
            Logger.log(Logger.ERROR_LEVEL, "sendEvent() -> success!");
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (conn != null) {
                conn.disconnect();
            }
        }
        
		return result;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Object getUserAttribute(final User user, String attributeName) {
		Logger.log(Logger.DEBUG_LEVEL, "getUserAttribute(com.ibm.portal.um.User, " + attributeName + ")");
		final java.util.List<String> attributesNamesList;
		try {
			final PumaHome pumaHome = getPumaHome();
			final PumaEnvironment env = pumaHome.getEnvironment();
			final PumaProfile pumaProfile = getPumaProfile();
			attributesNamesList = getPumaProfile().getDefinedUserAttributeNames();
			Logger.log(Logger.DEBUG_LEVEL, "getUserAttribute(com.ibm.portal.um.User," + attributeName + ") -> attributesNamesList = " +  + (attributesNamesList != null ? attributesNamesList.size() : 0));
//			if (attributesNamesList != null && attributesNamesList.size() > 0) {
//				for (int i = 0; i < attributesNamesList.size(); i++) {
//					Logger.log(Logger.DEBUG_LEVEL, "getUserAttribute(com.ibm.portal.um.User," + attributeName + ") -> attributesNamesList[" + i + "] = " + attributesNamesList.get(i));
//				}
//			}
//			To use this implementation you need to defined Anonymous User access to Virtual Resource USER_GROUPS!
//			java.util.Map<String, Object> userInfo = (java.util.Map<String, Object>) getPumaProfile().getAttributes((com.ibm.portal.um.Principal) user, attributesNamesList);
			java.util.Map<String, Object> userInfo = (java.util.Map<String, Object>) env.runUnrestricted(new PrivilegedExceptionAction() {
				public Object run() throws Exception {
					return pumaProfile.getAttributes((com.ibm.portal.um.Principal) user, attributesNamesList);
				}
			});
			
			if (userInfo != null) {
				Logger.log(Logger.DEBUG_LEVEL, "getUserAttribute(com.ibm.portal.um.User, " + attributeName + ") -> userInfo.size() = " + userInfo.size());
				return userInfo.get(attributeName);
			}
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "getUserAttribute(com.ibm.portal.um.User, " + attributeName + ") -> Exception: " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}

	public static PumaHome getPumaHome() {
		return pumaHome;
	}

	public static PumaProfile getPumaProfile() {
		return pumaHome.getProfile();
	}

	public static PumaController getPumaController() {
		return pumaHome.getController();
	}
	
}
