package com.ibs.myspace.portlet.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibs.myspace.portlet.management.ETranslationRequestManagement;
import com.ibs.myspace.portlet.utils.Logger;

@WebServlet("/etranslation-receive-file-callback-error")
public class ETranslationReceiveFileCallbackError extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Logger.log(Logger.ERROR_LEVEL, "ETranslationReceiveFileCallbackError -> doGet()");
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("ETranslationReceiveFileCallbackError -> doPost() start...[" + request.getParameter("request-id") + "]");
		request.setCharacterEncoding("utf8");
		response.setHeader("Cache-Control", "no-cache");
		response.setContentType("text/plain; charset=UTF-8");
		
		String idRequest = request.getParameter("request-id");
		String errorCode = request.getParameter("error-code");
		String errorMessage = request.getParameter("error-message");
		
		ETranslationRequestManagement management = new ETranslationRequestManagement();
		management.updateETranslationRequestError(idRequest, errorCode, errorMessage, System.currentTimeMillis());
		
		System.out.println("ETranslationReceiveFileCallbackError -> response received [" +  idRequest + "][" + errorCode + "][" + errorMessage + "]");		
	}
}
