package com.ibs.myspace.portlet.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import org.apache.commons.codec.binary.Base64;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ibs.myspace.portlet.management.ETranslationRequestManagement;
import com.ibs.myspace.portlet.utils.Logger;

@WebServlet("/etranslation-receive-file-callback")
public class ETranslationReceiveFileCallback extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Logger.log(Logger.ERROR_LEVEL, "ETranslationReceiveFileCallback -> doGet()");
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("ETranslationReceiveFileCallback -> doPost() start...");
		request.setCharacterEncoding("utf8");
		response.setHeader("Cache-Control", "no-cache");
		response.setContentType("text/plain; charset=UTF-8");
		boolean isProduction = "PROD".equalsIgnoreCase(System.getProperty("environment"));
		// We populate this parameter ONLY from prod dispatcher.
		String resultBase64 = request.getParameter("resultBase64");
		
		// Use lines below only for PRODUCTION.
		if (isProduction) {
			StringBuilder stringBuilder = new StringBuilder();
		    try(BufferedReader bufferedReader = request.getReader()) {
		        char[] charBuffer = new char[1024];
		        int bytesRead;
		        while ((bytesRead = bufferedReader.read(charBuffer)) > 0) {
		            stringBuilder.append(charBuffer, 0, bytesRead);
		        }
		    } 
		    resultBase64 = stringBuilder.toString();		    
		} else {
			resultBase64 = resultBase64.replaceAll(" ", "+"); // this fix base64 encoding bug.
		}
		
	    if (resultBase64 != null) {
	    	byte[] asBytes = null;
	    	try {
	    		// Decode
		    	asBytes = Base64.decodeBase64(resultBase64.getBytes("ISO-8859-1"));
			} catch (Exception e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}	    	
	    	if (asBytes != null) {
	    		String idRequest = request.getParameter("request-id");
	    		String targetLanguage = request.getParameter("target-language");
	    		ETranslationRequestManagement management = new ETranslationRequestManagement();
	    		int updated = management.updateETranslationRequestFile(idRequest, asBytes, targetLanguage, System.currentTimeMillis());
	    		if (updated == 1) {
	    			System.out.println("ETranslationReceiveFileCallback -> doPost() -> updateETranslationRequestFile [OK]");
	    		}
	    	} 
	    }		
		String idRequest = request.getParameter("request-id");
		String targetLanguage = request.getParameter("target-language");

		System.out.println("ETranslationReceiveFileCallback -> response received [" +  idRequest + "][" + targetLanguage + "][encoded>" + resultBase64 + "]");
	}
}
