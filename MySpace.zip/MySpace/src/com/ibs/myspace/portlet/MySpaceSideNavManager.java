package com.ibs.myspace.portlet;

import java.util.Arrays;
import java.util.ResourceBundle;

import javax.portlet.PortletMode;
import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.WindowState;

/**
* Main controller for handling custom side navigation.
* 
* @author      Damyan Slavov
* @version     %I%, %G%
* @since       1.0
*/
public class MySpaceSideNavManager {
	
	/**
	* These constants (page ids) will match page names, 
	* defined in MySpacePortlet class.
	*/
	private final static String SERVICE_CATALOG = "SERVICE_CATALOG";
	private final static String MY_DATA_IN_REGIX = "MY_DATA_IN_REGIX";
	public final static String MESSAGES = "MESSAGES";
	private final static String HEALTH = "HEALTH";
	private final static String FAMILY = "FAMILY";
	private final static String PAYMENTS = "PAYMENTS";
	private final static String PROPERTY = "PROPERTY";
	private final static String CAREER = "CAREER";
	private final static String VEHICLE = "VEHICLE";
	private final static String DOCUMENTS = "DOCUMENTS";
	private final static String E_SIGN = "E_SIGN";
	private final static String TRANSLATE = "TRANSLATE";
	

	/**
	 * Builds the HTML with the selected pages for the select element. 
	 * 
	 * @param renderResponse			javax.portlet.RenderResponse.
	 * @param currentPage				current page name.
	 * @param customSideNav				string with custom selected pages, separated with comma.
	 * @param bundle					resource bundle.
	 * @return          				HTML with <option></option>..<option></option> 
	 *
	 */
	public String buildSideNavigationHTML(RenderRequest renderRequest, RenderResponse renderResponse, String currentPage, String customSideNav, ResourceBundle bundle) {
		String html = "";
		boolean active = false;
		String pageName = null;
		String pageTitle = null;
		PortletURL actionUrl = null;	
		MySpacePortletSessionBean sessionBean = (MySpacePortletSessionBean)renderRequest.getPortletSession().getAttribute(MySpacePortlet.SESSION_BEAN);
		boolean isMobile = renderRequest.getAttribute("renderSideNavForMobile") != null;
		String[] customSideNavPages = (customSideNav != null && customSideNav.trim().length() > 0) ? customSideNav.split(",") : null;
		if (customSideNavPages != null && customSideNavPages.length > 0) {
			for (int i = 0; i < customSideNavPages.length; i++) {
				actionUrl = renderResponse.createActionURL();
				try {
					pageName = getPageNameByPageId(customSideNavPages[i]);
					pageTitle = getPageTitleByPageId(customSideNavPages[i], bundle);
					active = currentPage != null && currentPage.equalsIgnoreCase(pageName);					
					actionUrl.setWindowState(WindowState.NORMAL);
					actionUrl.setPortletMode(PortletMode.VIEW);
					actionUrl.setParameter(MySpacePortlet.PARAMETER_ACTION, MySpacePortlet.ACTION_CHANGE_PAGE);
					actionUrl.setParameter(MySpacePortlet.PARAMETER_VALUE, pageName);
					if (MESSAGES.equalsIgnoreCase(customSideNavPages[i])) {
						if (sessionBean != null && sessionBean.getUnReadReceivedMessagesCount() > 0) {
							pageTitle += "<span class=\"my-space-side-nav-bubble" + (active ? "-active" : "") + "\">" + sessionBean.getUnReadReceivedMessagesCount() + "</span>";
						}
					} 
					html += "<div id=\"mySpaceSideNav_" + (isMobile ? "mobile_" : "") + customSideNavPages[i] + "\" class=\"side-nav" + (active ? "-active" : "") + "\" onclick=\"document.location.href='" + actionUrl.toString() + "';\">" + pageTitle + "</div>";					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} else {			
			String[] allPages = getAllPagesIds();
			for (int i = 0; i < allPages.length; i++) {				
				actionUrl = renderResponse.createActionURL();
				try {
					pageName = getPageNameByPageId(allPages[i]);
					pageTitle = getPageTitleByPageId(allPages[i], bundle);
					active = currentPage != null && currentPage.equalsIgnoreCase(pageName);					
					actionUrl.setWindowState(WindowState.NORMAL);
					actionUrl.setPortletMode(PortletMode.VIEW);
					actionUrl.setParameter(MySpacePortlet.PARAMETER_ACTION, MySpacePortlet.ACTION_CHANGE_PAGE);
					actionUrl.setParameter(MySpacePortlet.PARAMETER_VALUE, pageName);
					if (MESSAGES.equalsIgnoreCase(allPages[i])) {
						if (sessionBean != null && sessionBean.getUnReadReceivedMessagesCount() > 0) {
							pageTitle += "<span class=\"my-space-side-nav-bubble" + (active ? "-active" : "") + "\">" + sessionBean.getUnReadReceivedMessagesCount() + "</span>";
						}
					} 
					html += "<div id=\"mySpaceSideNav_" + (isMobile ? "mobile_" : "") + allPages[i] + "\" class=\"side-nav" + (active ? "-active" : "") + "\" onclick=\"document.location.href='" + actionUrl.toString() + "';\">" + pageTitle + "</div>";
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return html;
	}
	
	/**
	 * Builds the HTML with the selected pages for the select element. 
	 * 
	 * @param customSideNavPages		list with custom selected pages.
	 * @param bundle					resource bundle.
	 * @return          				HTML with <option></option>..<option></option> 
	 *
	 */
	public String buildSelectedPagesForSelectHTML(String[] customSideNavPages, ResourceBundle bundle) {
		String html = "";
		if (customSideNavPages != null && customSideNavPages.length > 0) {
			for (int i = 0; i < customSideNavPages.length; i++) {
				html += "<option value=\"" + customSideNavPages[i] + "\">" + getPageTitleByPageId(customSideNavPages[i], bundle) + "</option>";			
			}
		}
		return html;
	}
	
	/**
	* Builds the HTML with all pages for the select element. 
	* 
	* @param customSideNavPages		list with custom selected pages.
	* @param bundle					resource bundle.
	* @return          				HTML with <option></option>..<option></option> 
	*
	*/
	public String buildAllPagesForSelectHTML(String[] customSideNavPages, ResourceBundle bundle) {
		String html = "";
		String[] allPages = getAllPagesIds();
		for (int i = 0; i < allPages.length; i++) {
			if (customSideNavPages != null && customSideNavPages.length > 0 && Arrays.stream(customSideNavPages).anyMatch(allPages[i]::equals)) {
				continue;
			}
			html += "<option value=\"" + allPages[i] + "\">" + getPageTitleByPageId(allPages[i], bundle) + "</option>";			
		}
		return html;
	}
	
	/**
	 * Does the mapping between page id and page title. 
	 * 
	 * @param pageId	page id.
	 * @param bundle	resource bundle.
	 * @return			page title. 
	 *
	 */
	public String getPageTitleByPageId(String pageId, ResourceBundle bundle) {
		if (SERVICE_CATALOG.equalsIgnoreCase(pageId)) {
			return bundle.getString("page.catalog.services");
		} else if (MY_DATA_IN_REGIX.equalsIgnoreCase(pageId)) {
			return bundle.getString("page.regix");
		} else if (MESSAGES.equalsIgnoreCase(pageId)) {
			return bundle.getString("page.messages");
		} else if (HEALTH.equalsIgnoreCase(pageId)) {
			return bundle.getString("page.my.health");
		} else if (FAMILY.equalsIgnoreCase(pageId)) {
			return bundle.getString("page.my.family");
		} else if (PAYMENTS.equalsIgnoreCase(pageId)) {
			return bundle.getString("page.payments");
		} else if (PROPERTY.equalsIgnoreCase(pageId)) {
			return bundle.getString("page.my.property");
		} else if (CAREER.equalsIgnoreCase(pageId)) {
			return bundle.getString("page.my.career");
		} else if (VEHICLE.equalsIgnoreCase(pageId)) {
			return bundle.getString("page.my.vehicle");
		} else if (DOCUMENTS.equalsIgnoreCase(pageId)) {
			return bundle.getString("page.my.documents");
		} else if (E_SIGN.equalsIgnoreCase(pageId)) {
			return bundle.getString("page.esign");
		} else if (TRANSLATE.equalsIgnoreCase(pageId)) {
			return bundle.getString("page.translate");
		}
		return null;
	}
	
	/**
	* Does the mapping between page id and page name. 
	* 
	* @param pageId		page id.
	* @return			page name. 
	*
	*/
	public String getPageNameByPageId(String pageId) {
		if (SERVICE_CATALOG.equalsIgnoreCase(pageId)) {
			return MySpacePortlet.SERVICES_CATALOG_PAGE;
		} else if (MY_DATA_IN_REGIX.equalsIgnoreCase(pageId)) {
			return MySpacePortlet.REGIX_PAGE;
		} else if (MESSAGES.equalsIgnoreCase(pageId)) {
			return MySpacePortlet.MESSAGES_PAGE;
		} else if (HEALTH.equalsIgnoreCase(pageId)) {
			return MySpacePortlet.MY_HEALTH_PAGE;
		} else if (FAMILY.equalsIgnoreCase(pageId)) {
			return MySpacePortlet.MY_FAMILY_PAGE;
		} else if (PAYMENTS.equalsIgnoreCase(pageId)) {
			return MySpacePortlet.PAYMENTS_PAGE;
		} else if (PROPERTY.equalsIgnoreCase(pageId)) {
			return MySpacePortlet.MY_PROPERTY_PAGE;
		} else if (CAREER.equalsIgnoreCase(pageId)) {
			return MySpacePortlet.MY_CAREER_PAGE;
		} else if (VEHICLE.equalsIgnoreCase(pageId)) {
			return MySpacePortlet.MY_VEHICLE_PAGE;
		} else if (DOCUMENTS.equalsIgnoreCase(pageId)) {
			return MySpacePortlet.MY_DOCUMENTS_PAGE;
		} else if (E_SIGN.equalsIgnoreCase(pageId)) {
			return MySpacePortlet.E_SIGN_PAGE;
		} else if (TRANSLATE.equalsIgnoreCase(pageId)) {
			return MySpacePortlet.TRANSLATE_PAGE;
		}
		return null;
	}
	
	/**
	 * It returns array with the ids of all pages
	 * in the default order. 
	 * 
	 * @return	array with the ids of all pages. 
	 *
	 */
	public String[] getAllPagesIds() {	
		return new String[] {
			SERVICE_CATALOG, 
			MY_DATA_IN_REGIX, 
			MESSAGES, 
			HEALTH, 
			FAMILY, 
			PAYMENTS, 
			PROPERTY, 
			CAREER, 
			VEHICLE, 
			DOCUMENTS, 
			E_SIGN, 
			TRANSLATE
		};
	}
		
	public static void main(String[] args) {
		java.util.stream.Stream<String> stream = java.util.stream.Stream.of("one", "two", "three", "four");
		String[]customSideNavPages = new String[] {"one", "two", "three", "four"};
        boolean match = stream.anyMatch(s -> s.contains("four"));
        System.out.println(match);
        System.out.println(Arrays.stream(customSideNavPages).anyMatch("four"::equals));
	}
}
