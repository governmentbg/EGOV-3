package com.ibs.myspace.portlet;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import com.ibs.myspace.portlet.bean.AuthorizationBean;
import com.ibs.myspace.portlet.bean.Message;
import com.ibs.myspace.portlet.bean.SelectedActionBean;
import com.ibs.myspace.portlet.bean.SelectedSystemBean;
import com.ibs.myspace.portlet.bean.UserProfileBean;
import com.ibs.myspace.portlet.db.QueryExecution;
import com.ibs.myspace.portlet.dbo.UserProfile;
import com.ibs.myspace.portlet.management.AuthorizationsManagement;
import com.ibs.myspace.portlet.utils.Logger;
import com.ibs.myspace.portlet.utils.MailMessage;
import com.ibs.myspace.portlet.utils.MySpaceUtils;

public class MySpaceNotificationsManager {
	
	private AuthorizationsManagement authorizationsManagement = null;
	private MySpaceUtils utils = null;
	
	public MySpaceNotificationsManager() {
		utils = new MySpaceUtils();
		authorizationsManagement = new AuthorizationsManagement();
	}
	
	public List<Message> notifyUsersForAuthorizationCreated(UserProfile sourceProfile, UserProfileBean sourceProfileBean, AuthorizationBean bean, Date date) {
		String profileType = MySpaceConstants.USER_PROFILE_TYPE_PERSONAL;
		String identifier = bean.getEncryptedAuthorizedIdentifier();
		String eik = null;
		if (MySpaceConstants.AUTHORIZATIONS_AUTHORIZED_TYPE_LE == bean.getAuthorizedType()) {
			eik = bean.getAuthorizedIdentifier();
			identifier = null;
			profileType = null;					
		}
		List<Message> messages = null;
		QueryExecution qe = new QueryExecution();
		// Load recepient user.
		UserProfile[] loadedProfiles = qe.loadAllProfilesAndPersonalProfilesByUserUIDProfileTypeIdentifierEik(null, profileType, identifier, eik, null, null);
		if (loadedProfiles != null && loadedProfiles.length > 0) {
			Logger.log(Logger.DEBUG_LEVEL, "MySpaceNotificationsManager : notifyUsersForAuthorizationCreated() loadedProfiles.length=" + loadedProfiles.length);
			UserProfile recepient = loadedProfiles[0];
			if (recepient != null) {						
				try {
					if (MySpaceConstants.AUTHORIZATIONS_AUTHORIZED_TYPE_PERSON == bean.getAuthorizedType()) {							
						notifyUserForAuthorizationCreated(sourceProfile, sourceProfileBean, recepient, bean, date);
					} else {
						Logger.log(Logger.DEBUG_LEVEL, "MySpaceNotificationsManager : notifyUsersForAuthorizationCreated() -> LE");
						// Authorizing LE.
						UserProfile[] adminUsers = authorizationsManagement.getAdminUsersForLEProfile(recepient.getId());
						if (adminUsers != null && adminUsers.length > 0) {
							Logger.log(Logger.DEBUG_LEVEL, "AuthorizationMySpaceNotificationsManagersManagement : notifyUsersForAuthorizationCreated() -> adminUsers.length="+adminUsers.length);
							for (int i = 0; i < adminUsers.length; i++) {
								try {
									// Send notification to each admin user.
									notifyUserForAuthorizationCreated(sourceProfile, sourceProfileBean, adminUsers[i], bean, date);
								} catch (Exception e) { 
									if (messages == null) {
										messages = new ArrayList<Message>();
									}
									messages.add(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
								}
							}
						} else {
							Logger.log(Logger.DEBUG_LEVEL, "MySpaceNotificationsManager : notifyUsersForAuthorizationCreated() -> adminUsers=NULL");
						}
						
					}
				} catch (Exception e) {
					e.printStackTrace();
					if (messages == null) {
						messages = new ArrayList<Message>();
					}
					messages.add(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
				}					
			}
		} else {
			Logger.log(Logger.DEBUG_LEVEL, "MySpaceNotificationsManager : notifyUsersForAuthorizationCreated() loadedProfiles=NULL");
		}
		return messages;
	}
	
	private boolean notifyUserForAuthorizationCreated(UserProfile sender, UserProfileBean senderBean, UserProfile recepient, AuthorizationBean bean, Date date) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "MySpaceNotificationsManager : notifyUserForAuthorizationCreated() -> start...");
		if (recepient != null && recepient.getPersonalParameters() != null) {
			// Notify by email.
			String email = recepient.getPersonalParameters().getEmail();
			if (email != null && email.trim().length() > 0) {
				String senderNames = MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equalsIgnoreCase(sender.getProfileType()) ? sender.getNames() : sender.getNameAndLegalForm();
				if (senderNames == null) {
					senderNames = senderBean.getCurrentUserCN();
				}
				String subject = "Регистрирано е ново овластяване от " + senderNames;
				if (MySpaceConstants.AUTHORIZATIONS_AUTHORIZED_TYPE_LE == bean.getAuthorizedType()) {
					subject += " за " + bean.getAuthorizedNames();
				}
				String body = emailBodyAuthorization(sender, senderNames, senderBean, recepient, bean, date, MySpaceConstants.AUTHORIZATIONS_STATUS_ACTIVE);
				try {
					if (MailMessage.sendEmail(MySpacePortlet.fromAddress, email, null, subject, body, MySpacePortlet.debug)) {
						Logger.println("Mail send successfully to " + email + "!");
						return true;
					}
				} catch (Exception e) {
					e.printStackTrace();
					throw new Exception("Неуспешно изпращане на е-поща до " + email);					
				}
			}
		}		
		return false; 
	}

	public List<Message> notifyUsersForAuthorizationCancel(UserProfile sourceProfile, UserProfileBean sourceProfileBean, AuthorizationBean bean, Date date) {
		String profileType = MySpaceConstants.USER_PROFILE_TYPE_PERSONAL;
		String identifier = bean.getEncryptedAuthorizedIdentifier();
		String eik = null;
		if (MySpaceConstants.AUTHORIZATIONS_AUTHORIZED_TYPE_LE == bean.getAuthorizedType()) {
			eik = bean.getAuthorizedIdentifier();
			identifier = null;
			profileType = null;					
		}
		List<Message> messages = null;
		QueryExecution qe = new QueryExecution();
		// Load recepient user.
		UserProfile[] loadedProfiles = qe.loadAllProfilesAndPersonalProfilesByUserUIDProfileTypeIdentifierEik(null, profileType, identifier, eik, null, null);
		if (loadedProfiles != null && loadedProfiles.length > 0) {
			Logger.log(Logger.DEBUG_LEVEL, "MySpaceNotificationsManager : notifyUsersForAuthorizationCancel() loadedProfiles.length=" + loadedProfiles.length);
			UserProfile recepient = loadedProfiles[0];
			if (recepient != null) {						
				try {
					if (MySpaceConstants.AUTHORIZATIONS_AUTHORIZED_TYPE_PERSON == bean.getAuthorizedType()) {							
						notifyUserForAuthorizationCancel(sourceProfile, sourceProfileBean, recepient, bean, date);
					} else {
						Logger.log(Logger.DEBUG_LEVEL, "MySpaceNotificationsManager : notifyUsersForAuthorizationCancel() -> LE");
						// Authorizing LE.
						UserProfile[] adminUsers = authorizationsManagement.getAdminUsersForLEProfile(recepient.getId());
						if (adminUsers != null && adminUsers.length > 0) {
							Logger.log(Logger.DEBUG_LEVEL, "AuthorizationMySpaceNotificationsManagersManagement : notifyUsersForAuthorizationCancel() -> adminUsers.length="+adminUsers.length);
							for (int i = 0; i < adminUsers.length; i++) {
								try {
									// Send notification to each admin user.
									notifyUserForAuthorizationCancel(sourceProfile, sourceProfileBean, adminUsers[i], bean, date);
								} catch (Exception e) { 
									if (messages == null) {
										messages = new ArrayList<Message>();
									}
									messages.add(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
								}
							}
						} else {
							Logger.log(Logger.DEBUG_LEVEL, "MySpaceNotificationsManager : notifyUsersForAuthorizationCancel() -> adminUsers=NULL");
						}
						
					}
				} catch (Exception e) {
					e.printStackTrace();
					if (messages == null) {
						messages = new ArrayList<Message>();
					}
					messages.add(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
				}					
			}
		} else {
			Logger.log(Logger.DEBUG_LEVEL, "MySpaceNotificationsManager : notifyUsersForAuthorizationCancel() loadedProfiles=NULL");
		}
		return messages;
	}
	
	private boolean notifyUserForAuthorizationCancel(UserProfile sender, UserProfileBean senderBean, UserProfile recepient, AuthorizationBean bean, Date date) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "MySpaceNotificationsManager : notifyUserForAuthorizationCancel() -> start...");
		if (recepient != null && recepient.getPersonalParameters() != null) {
			// Notify by email.
			String email = recepient.getPersonalParameters().getEmail();
			if (email != null && email.trim().length() > 0) {
				String senderNames = MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equalsIgnoreCase(sender.getProfileType()) ? sender.getNames() : sender.getNameAndLegalForm();
				if (senderNames == null) {
					senderNames = senderBean.getCurrentUserCN();
				}
				String subject = "Оттегляне на овластяване от " + senderNames;
				if (MySpaceConstants.AUTHORIZATIONS_AUTHORIZED_TYPE_LE == bean.getAuthorizedType()) {
					subject += " за " + bean.getAuthorizedNames();
				}
				String body = emailBodyAuthorization(sender, senderNames, senderBean, recepient, bean, date, MySpaceConstants.AUTHORIZATIONS_STATUS_CANCELED);
				try {
					if (MailMessage.sendEmail(MySpacePortlet.fromAddress, email, null, subject, body, MySpacePortlet.debug)) {
						Logger.println("Mail send successfully to " + email + "!");
						return true;
					}
				} catch (Exception e) {
					e.printStackTrace();
					throw new Exception("Неуспешно изпращане на е-поща до " + email);					
				}
			}
		}		
		return false; 
	}

	
	/*
	 * result[]:
	 * 0 - request profile id
	 * 1 - profile id
	 * 2 - names
	 * 3 - time
	 * 4 - eik
	 * 5 - nameAndLegalForm
	 */
	public boolean notifyDAEUForCreatedRequestForLEProfile(String[] result, ResourceBundle bundle) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "MySpaceNotificationsManager : notifyDAEUForCreatedRequestForLEProfile() -> start...");
		if (MySpacePortlet.fromAddress != null && MySpacePortlet.toAddress != null) {			
			try {
				String subject = MessageFormat.format(bundle.getString("mail.subject.profile.request"), result[0], result[5], result[4]);
				String body = buildSendRequestMailBody(result[2], result[4], result[5], result[3]);
				if (MailMessage.sendEmail(MySpacePortlet.fromAddress, MySpacePortlet.toAddress, null, subject, body, MySpacePortlet.debug)) {
					Logger.println("Mail send successfully to " + MySpacePortlet.toAddress + "!");
					return true;
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw new Exception("Неуспешно изпращане на е-поща до " + MySpacePortlet.toAddress);	
			}
		}
		return false;
	}
	
	/*
	 * result[]:
	 * 0 - request profile id
	 * 1 - profile id
	 * 2 - names
	 * 3 - time
	 * 4 - eik
	 * 5 - nameAndLegalForm
	 */
	public boolean notifyUserForCreatedRequestForLEProfile(String[] result, UserProfile profile, ResourceBundle bundle) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "MySpaceNotificationsManager : notifyUserForCreatedRequestForLEProfile() -> start...");
		if (profile != null && profile.getPersonalParameters() != null 
				&& profile.getPersonalParameters().getEmail() != null && profile.getPersonalParameters().getEmail().trim().length() > 0) {
			String email = profile.getPersonalParameters().getEmail();
			try {
				String subject = MessageFormat.format(bundle.getString("mail.subject.profile.request"), result[0], result[5], result[4]);
				String body = buildSendRequestMailBody(result[2], result[4], result[5], result[3]);
				if (MailMessage.sendEmail(MySpacePortlet.fromAddress, email, null, subject, body, MySpacePortlet.debug)) {
					Logger.println("Mail send successfully to " + email + "!");
					return true;
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw new Exception("Неуспешно изпращане на е-поща до " + email);	
			}
		}
		return false;
	}
	
	public boolean notifyUserAddEditRemoveLEProfile(int action, String userUID, String roles, UserProfile legalEntityProfile, String date, ResourceBundle bundle) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "MySpaceNotificationsManager : notifyUserForAssignmentToLEProfile() -> start...");		
		if (MySpacePortlet.fromAddress != null) {			
			QueryExecution qe = new QueryExecution();
			UserProfile[] loadedProfiles = qe.loadAllProfilesAndPersonalProfilesByUserUIDProfileTypeIdentifierEik(userUID, MySpaceConstants.USER_PROFILE_TYPE_PERSONAL, null, null, null, null);
			if (loadedProfiles != null && loadedProfiles.length > 0) {
				Logger.log(Logger.DEBUG_LEVEL, "MySpaceNotificationsManager : notifyUserForAssignmentToLEProfile() loadedProfiles.length=" + loadedProfiles.length);
				UserProfile recepient = loadedProfiles[0];
				if (recepient != null && recepient.getPersonalParameters() != null 
						&& recepient.getPersonalParameters().getEmail() != null && recepient.getPersonalParameters().getEmail().trim().length() > 0) {
					String email = recepient.getPersonalParameters().getEmail();		
					try {									
						String subject = "Потребител " + recepient.getNames() + " беше добавен към профил на " + legalEntityProfile.getNameAndLegalForm();
						String body = emailBodyUserAddedToLEMailBody(subject, roles, date);
						if (MySpaceConstants.USER_EDIT_ROLES_TO_LEGAL_ENTITY == action) {
							subject = "Актуализация на достъпа на потребител " + recepient.getNames() + " до профил на " + legalEntityProfile.getNameAndLegalForm();
							body = emailBodyUserEditAccessToLEMailBody(subject, roles, date);
						} else if (MySpaceConstants.USER_REMOVED_FROM_LEGAL_ENTITY == action) {
							subject = "Потребител " + recepient.getNames() + " беше премахнат от профил на " + legalEntityProfile.getNameAndLegalForm();
							body = emailBodyUserRemovedFromLEMailBody(subject, date);
						}
						if (MailMessage.sendEmail(MySpacePortlet.fromAddress, email, null, subject, body, MySpacePortlet.debug)) {
							Logger.println("Mail send successfully to " + email + "!");
							return true;
						}
					} catch (Exception e) {
						e.printStackTrace();
						throw new Exception("Неуспешно изпращане на е-поща до " + email);	
					}
				}
			}
		}
		return false;
	}
	
	public boolean notifyUserForInvitationPerProfile(int action, String email, String code, UserProfile legalEntityProfile, String personName, String date, ResourceBundle bundle) throws Exception {
		Logger.log(Logger.DEBUG_LEVEL, "MySpaceNotificationsManager : notifyUserForAssignmentToLEProfile() -> start...");		
		if (MySpacePortlet.fromAddress != null) {				
			try {
				boolean isProd = "PROD".equalsIgnoreCase(System.getProperty("environment"));
				boolean testEnvironment = "TEST".equalsIgnoreCase(System.getProperty("environmentType"));
				String address = "egov.bg"; 
				if (!isProd) {
					if (testEnvironment) {
						address = "testportal.egov.bg";
					} else {
						address = "staging.egov.bg";
					}
				}				
				String confirmUrl = "https://" + address + "/UserProfileService/GetEGOVUserInvitation?code=" + code + "&action=ok";
				String cancelUrl = "https://" + address + "/UserProfileService/GetEGOVUserInvitation?code=" + code + "&action=cancel";
				String subject = "Покана за асоцииране с профил на юридическо лице";
				String body = emailBodyUserInvitedToLEMailBody(subject, confirmUrl, cancelUrl, legalEntityProfile.getNameAndLegalForm(), personName, date);
				if (MySpaceConstants.USER_REINVITED_TO_LEGAL_ENTITY == action) {
					//subject = "Покана за асоцииране с профил на юридическо лице";
					//body = emailBodyUserEditAccessToLEMailBody(subject, roles, date);
				}//				
				if (MailMessage.sendEmail(MySpacePortlet.fromAddress, email, null, subject, body, MySpacePortlet.debug)) {
					Logger.println("Mail send successfully to " + email + "!");
					return true;
				} else {
					throw new Exception("Неуспешно изпращане на покана до е-поща: " + email + "!");
				}
			} catch (Exception e) {
				System.out.println("########error sending mail: host[" + MySpacePortlet.mailSmtpHost + "]");
				System.out.println("########error sending mail: from[" + MySpacePortlet.fromAddress + "]");
				System.out.println("########error sending mail: to[" + email + "]");
				e.printStackTrace();
				throw new Exception("Неуспешно изпращане на покана до е-поща: " + email + "!");	
			}
		}
		return false;
	}
	
	private String emailBodyUserInvitedToLEMailBody(String subject, String confirmUrl, String  cancelUrl, String leName, String personName, String date) {
		String html = "";
		html += "<div>"
				+ "<h1>EGOV.BG</h1>"
				+ "<div><p style=\"font-size:16px;\">Имате покана за асоцииране с профил на " + leName + " от името на " + personName + ".</p></div>"
				+ "<div><p style=\"font-size:16px;\">С натискането на бутон \"Приемам\" ще бъдете препратени към EGOV.BG.</p></div>"
				+ "<div style=\"padding-top:10px\"><p>"
				+ "<a style=\"padding: 10px 20px;font-family: 'FiraSans-Regular', 'Fira Sans', sans-serif;font-size: 16px;font-weight: 400;color: #fff;background-color: #014f86;height: 40px;line-height: 40px;text-align: center;cursor: pointer;text-transform: uppercase;border: 1px solid #014f86;border-radius: 7px;text-decoration: none;\" target=\"_blank\" href=\"" + confirmUrl + "\">Приемам</a>"
				+ "<a style=\"margin-left:10px;padding: 10px 20px;font-family: 'FiraSans-Regular', 'Fira Sans', sans-serif;font-size: 16px;font-weight: 400;color: #014f86;background-color: #fff;height: 40px;line-height: 40px;text-align: center;cursor: pointer;text-transform: uppercase;border: 1px solid #014f86;border-radius: 7px;text-decoration: none;\" target=\"_blank\" href=\"" + cancelUrl + "\">Отказвам</a>"
				+ "</p></div>"
				+ "<br/>"
				+ "<br/>"
				+ "<div style=\"font-style: italic;color:#888;\">Моля не отговаряйте, автоматично съобщение.</div>";
		return html;
	}
	

	
	private String emailBodyUserAddedToLEMailBody(String subject, String roles, String date) {
		String html = "";
		html += "<div>"
				+ "<div><p>" + subject + "</p></div>"
				+ "<div><p>Роли за достъп:<br/><strong>" + roles + "</strong></p></div>"
				+ "<div><p>Дата на създаване:<br/><strong>" + date + "</strong></p></div>";
		return html;
	}
	
	private String emailBodyUserEditAccessToLEMailBody(String subject, String roles, String date) {
		String html = "";
		html += "<div>"
				+ "<div><p>" + subject + "</p></div>"
				+ "<div><p>Роли за достъп:<br/><strong>" + roles + "</strong></p></div>"
				+ "<div><p>Дата на последна актуализация:<br/><strong>" + date + "</strong></p></div>";
		return html;
	}
	
	private String emailBodyUserRemovedFromLEMailBody(String subject, String date) {
		String html = "";
		html += "<div>"
				+ "<div><p>" + subject + "</p></div>"
				+ "<div><p>Дата на премахване:<br/><strong>" + date + "</strong></p></div>";
		return html;
	}
	
	private String emailBodyAuthorization(UserProfile sender, String senderNames, UserProfileBean senderBean, UserProfile recepient, AuthorizationBean bean, Date date, int status) {
		List<SelectedSystemBean> selectedSystems = bean.getLoadedSystemBeans();
		String recepientNames = recepient.getNames();
		if (MySpaceConstants.AUTHORIZATIONS_AUTHORIZED_TYPE_LE == bean.getAuthorizedType()) {
			recepientNames = bean.getAuthorizedNames();
		}
		String validFrom = utils.formatDate(bean.getValidFromDate()) + " " + (bean.getValidFromTime() != null ? bean.getValidFromTime() : "00:00") + ":00";
		String validTo = utils.formatDate(bean.getValidToDate()) + " " + (bean.getValidToTime() != null ? bean.getValidToTime() + ":00" : "23:59:59");

		String html = "";
		html += "<div>"
				+ "<div><p>Аз, <strong>" + senderNames + "</strong>, овластявам <strong>" + recepientNames + "</strong>, за достъп до следните системи и действия:</p></div>"
				+ "<div>"
				+ "";
			if (selectedSystems != null && selectedSystems.size() > 0) {
				SelectedSystemBean system = null;
				SelectedActionBean action = null;
				List<SelectedActionBean> actions = null;
				for (int i = 0; i < selectedSystems.size(); i ++) {	
					system = selectedSystems.get(i);
					actions = system.getActions();
		html += "	<ul style=\"margin:0px;padding-left: 30px !important;\">"
				+ "		<li><p><strong>" + system.getTitle() + "</strong></p>"
				+ "			<ul>";
					if (actions != null && actions.size() > 0) {
						for (int j = 0; j < actions.size(); j ++) {
							action = actions.get(j);
				html += "			"
				+ "				<li><p><strong>" + action.getDescription() + "</strong></p></li>";
						}
					}
				html += "			"
				+ "			</ul>"
				+ "		</li>"
				+ "	</ul>";
				}
			}
			html += " "
				+ "</div>"
				+ "<div>"
				+ "		<p>За периода от <strong>" + validFrom + "</strong> до <strong>" + validTo + "</strong></p>"
				+ "</div>"
				+ "<div>"
				+ "		<p>Статус: <strong>" + (MySpaceConstants.AUTHORIZATIONS_STATUS_ACTIVE == status ? "Активно" : (MySpaceConstants.AUTHORIZATIONS_STATUS_CANCELED == status ? "Оттеглено" : "")) + "</strong></p>	"
				+ "</div>"				
				+ "<div>"
				+ "		<p>Дата: <strong>" + utils.dateToDD_MM_YYYY_HH_MM_SS(date) + "</strong></p>"
				+ "</div>"
				+ "<div>"
				+ "		<p>Референтен № на операцията: <strong>" + bean.getOrn()  + "</strong></p>"
				+ "</div>"
				+ "</div>"
				+ "<br/>"
				+ "<br/>"
				+ "<div style=\"font-style: italic;color:#888;\">Моля не отговаряйте, автоматично съобщение.</div>";
		return html;
	}
	
	private String buildSendRequestMailBody (String names, String eik, String nameAndLegalForm, String date) {
		String html = "<div>Регистирана е заявка за създаване на профил от <strong>" + names + "</strong>.</div><br/>";
		html += "<div>ЕИК/Код по БУЛСТАТ:</div><div><strong>" + eik + "</strong></div><br/>";
		html += "<div>Наименование и правна форма:</div><div><strong>" + nameAndLegalForm + "</strong></div><br/>";
		html += "<div>Дата на регистрация:</div><div><strong>" + date + "</strong></div><br/><br/>";
		return html;
	}

}
