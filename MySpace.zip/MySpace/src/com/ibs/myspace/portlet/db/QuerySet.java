package com.ibs.myspace.portlet.db;

import java.util.Hashtable;

public class QuerySet {
    public QuerySet(String table, Hashtable<String, String> columnMap, String[] keyArr) {
        this.table = table;
        this.columnMap = columnMap;
        this.keyArray = keyArr;
    }

    public Hashtable<String, String> columnMap;
    public String table;
    public String createQuery;
    public String loadQuery;
    public String storeQuery;
    public String removeQuery;
    public String findQuery;
    public String sequenceName;
    public String[] keyArray;
}
