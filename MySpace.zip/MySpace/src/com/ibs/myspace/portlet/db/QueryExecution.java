package com.ibs.myspace.portlet.db;


public class QueryExecution {

	
	

		
}
