package com.ibs.myspace.portlet.db;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLWarning;
import java.util.Properties;

import com.ibs.myspace.portlet.MySpaceConstants;


public class DBResources extends Base {

    private static final String DEFAULT_PROPERTIES_FILE_NAME = "DBResources.properties";
    private static Properties defaultProps = null;

    public DBResources() {}

    private static final int getValue(String field, int defaultValue) {
        try {
            return Integer.parseInt(field.trim());
        } catch (Exception e) {
        }
        return defaultValue;
    }

    private static void getDefaultProperties(String fileName) {
        defaultProps = new Properties();
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(fileName);
            defaultProps.load(fis);

        } catch (Exception e) {
            System.out.print("DBResources: Error loading properties file " + fileName + " !");
            e.printStackTrace();
        }
    }

    public static String getDefaultDBProperty(String propName) {
        return defaultProps.getProperty(propName);
    }

    public static boolean init(String realpath) {        
        return true;
    } 

    public static String checkForWarning(SQLWarning warn) {
        StringBuffer msgSB = new StringBuffer(300);

        if (warn != null) {
            msgSB.append("\n *** Warning ***\n");
            while (warn != null) {
                msgSB.append(" Warning:\n");
                msgSB.append("SQLState: " + warn.getSQLState() + "\n");
                msgSB.append("Message:  " + warn.getMessage() + "\n");
                msgSB.append("Vendor:   " + warn.getErrorCode() + "\n");
                warn = warn.getNextWarning();
            }
            return msgSB.toString();
        } else {
            return "";
        }
    } 

} 