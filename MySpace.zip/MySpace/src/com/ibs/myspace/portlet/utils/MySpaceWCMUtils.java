package com.ibs.myspace.portlet.utils;

import java.util.Date;

import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.ContentComponent;
import com.ibm.workplace.wcm.api.DateComponent;
import com.ibm.workplace.wcm.api.RichTextComponent;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.TextComponent;

public class MySpaceWCMUtils {
	
	public boolean hasComponent(Content content, String elementName) {
		for (int i = 0; i < content.getComponentNames().length; i++) {
			if (content.getComponentNames()[i].equals(elementName))
				return true;
		}
		return false;
	}
	
	public String getTextField(Content content, String componentName) {
		try {
			if (this.hasComponent(content, componentName)) {		
				ContentComponent contentComponent = content.getComponent(componentName);			
				if (contentComponent instanceof ShortTextComponent) {
					ShortTextComponent component = (ShortTextComponent)contentComponent; 
					return component.getText();
				} else if (contentComponent instanceof TextComponent) {
					TextComponent component = (TextComponent)contentComponent; 
					return component.getText();
				} else if (contentComponent instanceof RichTextComponent) {
					RichTextComponent component = (RichTextComponent)contentComponent; 
					return component.getRichText();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public Date getDateField(Content content, String componentName) {
		try {
			if (this.hasComponent(content, componentName)) {		
				ContentComponent contentComponent = content.getComponent(componentName);			
				if (contentComponent instanceof DateComponent) {
					DateComponent component = (DateComponent)contentComponent; 
					return component.getDate();
				} 
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public static void main(String[] args) {}
}
