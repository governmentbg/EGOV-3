package com.ibs.myspace.portlet.bean;

import java.util.List;

public class SelectedSystemBean {
	private Long systemsId = null;
	private String title = null;
	private String oid = null;
	private List<SelectedActionBean> actions = null;	
	private String systemsStr = null;
	
	public Long getSystemsId() {
		return systemsId;
	}
	public void setSystemsId(Long systemsId) {
		this.systemsId = systemsId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getOid() {
		return oid;
	}
	public void setOid(String oid) {
		this.oid = oid;
	}
	public List<SelectedActionBean> getActions() {
		return actions;
	}
	public void setActions(List<SelectedActionBean> actions) {
		this.actions = actions;
	}
	public String getSystemsStr() {
		return systemsStr;
	}
	public void setSystemsStr(String systemsStr) {
		this.systemsStr = systemsStr;
	}
	
}
