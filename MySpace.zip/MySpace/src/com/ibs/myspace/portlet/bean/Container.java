package com.ibs.myspace.portlet.bean;

import java.util.ArrayList;
import java.util.HashMap;

import com.ibs.myspace.portlet.dbo.UserProfile;
import com.ibs.myspace.portlet.dbo.UserProfileRole;

public class Container {
	
	private String serviceNumber = null;
	private ArrayList<String> favoriteServices = null;
	private ArrayList<String> visitedServices = null;
	private AuditLogBean[] auditLogs = null;
	private EDeliverySubjectBean eDeliverySubjectBean = null;
	private UserProfileRole[] userProfileRoles = null;
	private UserProfileRole userProfileRole = null;
	private ArrayList<Page> pages = null;
	private HashMap<String,UserProfile> isMemberOfProfileHm = null;
	private String editSupplierLink = null;
	private String editSupplierServicesLink = null;
	private String searchString = null;
	private String pageUniqueName = null;
	private String pageTitle = null;
	private String pageFriendlyUrl = null;
	private String subPageUniqueName = null;
	private String subPageTitle = null;
	private String subPageFriendlyUrl = null;
	private Long authorizationsId = null;
	private AuthorizationBean authorizationBean = null;
	private Long profileIdentifierId = null;
	private ProfileIdentifierBean profileIdentifierBean = null;
	private boolean showProfilePage = false;
	private boolean initInitalized = false;

	public String getServiceNumber() {
		return serviceNumber;
	}

	public void setServiceNumber(String serviceNumber) {
		this.serviceNumber = serviceNumber;
	}

	public ArrayList<String> getFavoriteServices() {
		return favoriteServices;
	}

	public void setFavoriteServices(ArrayList<String> favoriteServices) {
		this.favoriteServices = favoriteServices;
	}

	public ArrayList<String> getVisitedServices() {
		return visitedServices;
	}

	public void setVisitedServices(ArrayList<String> visitedServices) {
		this.visitedServices = visitedServices;
	}

	public AuditLogBean[] getAuditLogs() {
		return auditLogs;
	}

	public void setAuditLogs(AuditLogBean[] auditLogs) {
		this.auditLogs = auditLogs;
	}

	public EDeliverySubjectBean geteDeliverySubjectBean() {
		return eDeliverySubjectBean;
	}

	public void seteDeliverySubjectBean(EDeliverySubjectBean eDeliverySubjectBean) {
		this.eDeliverySubjectBean = eDeliverySubjectBean;
	}

	public UserProfileRole[] getUserProfileRoles() {
		return userProfileRoles;
	}

	public void setUserProfileRoles(UserProfileRole[] userProfileRoles) {
		this.userProfileRoles = userProfileRoles;
	}

	public UserProfileRole getUserProfileRole() {
		return userProfileRole;
	}

	public ArrayList<Page> getPages() {
		return pages;
	}

	public void setPages(ArrayList<Page> pages) {
		this.pages = pages;
	}

	public void setUserProfileRole(UserProfileRole userProfileRole) {
		this.userProfileRole = userProfileRole;
	}

	public HashMap<String, UserProfile> getIsMemberOfProfileHm() {
		return isMemberOfProfileHm != null ? isMemberOfProfileHm : new HashMap<>();
	}

	public void setIsMemberOfProfileHm(HashMap<String, UserProfile> isMemberOfProfileHm) {
		this.isMemberOfProfileHm = isMemberOfProfileHm;
	}

	public String getEditSupplierLink() {
		return editSupplierLink;
	}

	public void setEditSupplierLink(String editSupplierLink) {
		this.editSupplierLink = editSupplierLink;
	}

	public String getEditSupplierServicesLink() {
		return editSupplierServicesLink;
	}

	public void setEditSupplierServicesLink(String editSupplierServicesLink) {
		this.editSupplierServicesLink = editSupplierServicesLink;
	}

	public String getSearchString() {
		return searchString;
	}

	public void setSearchString(String searchString) {
		this.searchString = searchString;
	}

	public String getPageUniqueName() {
		return pageUniqueName;
	}

	public void setPageUniqueName(String pageUniqueName) {
		this.pageUniqueName = pageUniqueName;
	}

	public String getSubPageUniqueName() {
		return subPageUniqueName;
	}

	public void setSubPageUniqueName(String subPageUniqueName) {
		this.subPageUniqueName = subPageUniqueName;
	}

	public String getPageTitle() {
		return pageTitle;
	}

	public void setPageTitle(String pageTitle) {
		this.pageTitle = pageTitle;
	}

	public String getPageFriendlyUrl() {
		return pageFriendlyUrl;
	}

	public void setPageFriendlyUrl(String pageFriendlyUrl) {
		this.pageFriendlyUrl = pageFriendlyUrl;
	}

	public String getSubPageTitle() {
		return subPageTitle;
	}

	public void setSubPageTitle(String subPageTitle) {
		this.subPageTitle = subPageTitle;
	}

	public String getSubPageFriendlyUrl() {
		return subPageFriendlyUrl;
	}

	public void setSubPageFriendlyUrl(String subPageFriendlyUrl) {
		this.subPageFriendlyUrl = subPageFriendlyUrl;
	}
	
	public Long getAuthorizationsId() {
		return authorizationsId;
	}

	public void setAuthorizationsId(Long authorizationsId) {
		this.authorizationsId = authorizationsId;
	}

	public AuthorizationBean getAuthorizationBean() {
		return authorizationBean;
	}

	public void setAuthorizationBean(AuthorizationBean authorizationBean) {
		this.authorizationBean = authorizationBean;
	}

	public Long getProfileIdentifierId() {
		return profileIdentifierId;
	}

	public void setProfileIdentifierId(Long profileIdentifierId) {
		this.profileIdentifierId = profileIdentifierId;
	}

	public ProfileIdentifierBean getProfileIdentifierBean() {
		return profileIdentifierBean;
	}

	public void setProfileIdentifierBean(ProfileIdentifierBean profileIdentifierBean) {
		this.profileIdentifierBean = profileIdentifierBean;
	}

	public boolean isShowProfilePage() {
		return showProfilePage;
	}

	public void setShowProfilePage(boolean showProfilePage) {
		this.showProfilePage = showProfilePage;
	}

	public boolean isInitInitalized() {
		return initInitalized;
	}

	public void setInitInitalized(boolean initInitalized) {
		this.initInitalized = initInitalized;
	}
	
}

