package com.ibs.myspace.portlet.bean;

public class ESBEPaymentBean {
	private ESBEPaymentDataBean paymentData = null;	 
	private ESBEPaymentProviderInfoBean bankAccount = null;	 
	private String eserviceAisName = null;
	
	public ESBEPaymentDataBean getPaymentData() {
		return paymentData;
	}
	public void setPaymentData(ESBEPaymentDataBean paymentData) {
		this.paymentData = paymentData;
	}
	public ESBEPaymentProviderInfoBean getBankAccount() {
		return bankAccount;
	}
	public void setBankAccount(ESBEPaymentProviderInfoBean bankAccount) {
		this.bankAccount = bankAccount;
	}
	public String getEserviceAisName() {
		return eserviceAisName;
	}
	public void setEserviceAisName(String eserviceAisName) {
		this.eserviceAisName = eserviceAisName;
	}
	
}
