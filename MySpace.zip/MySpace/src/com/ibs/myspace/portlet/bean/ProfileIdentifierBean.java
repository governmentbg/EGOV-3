package com.ibs.myspace.portlet.bean;

public class ProfileIdentifierBean {
	private String id = null;
	private String identifierType = null;
	private String identifierCountryCode = null;
	private String identifier = null;
	private String xmlBase64 = null;
	private String xmlBase64FileName = null;
	private String rnu = null;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getIdentifierType() {
		return identifierType;
	}
	public void setIdentifierType(String identifierType) {
		this.identifierType = identifierType;
	}
	public String getIdentifierCountryCode() {
		return identifierCountryCode;
	}
	public void setIdentifierCountryCode(String identifierCountryCode) {
		this.identifierCountryCode = identifierCountryCode;
	}
	public String getIdentifier() {
		return identifier;
	}
	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}
	public String getXmlBase64() {
		return xmlBase64;
	}
	public void setXmlBase64(String xmlBase64) {
		this.xmlBase64 = xmlBase64;
	}
	public String getXmlBase64FileName() {
		return xmlBase64FileName;
	}
	public void setXmlBase64FileName(String xmlBase64FileName) {
		this.xmlBase64FileName = xmlBase64FileName;
	}
	public String getRnu() {
		return rnu;
	}
	public void setRnu(String rnu) {
		this.rnu = rnu;
	}
	
}
