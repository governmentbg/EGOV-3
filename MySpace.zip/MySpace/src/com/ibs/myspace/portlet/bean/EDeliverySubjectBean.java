package com.ibs.myspace.portlet.bean;

public class EDeliverySubjectBean {
	private boolean hasRegistration = false;
	private String identificator = null;
	private String electronicSubjectId = null;
	private String electronicSubjectName = null;
	private String email = null;
	private boolean isActivated = false;
	private String phoneNumber = null;
	private String profileType = null;
	
	public boolean isHasRegistration() {
		return hasRegistration;
	}
	
	public void setHasRegistration(boolean hasRegistration) {
		this.hasRegistration = hasRegistration;
	}
	
	public String getIdentificator() {
		return identificator;
	}
	
	public void setIdentificator(String identificator) {
		this.identificator = identificator;
	}
	
	public String getElectronicSubjectId() {
		return electronicSubjectId;
	}
	
	public void setElectronicSubjectId(String electronicSubjectId) {
		this.electronicSubjectId = electronicSubjectId;
	}
	
	public String getElectronicSubjectName() {
		return electronicSubjectName;
	}
	
	public void setElectronicSubjectName(String electronicSubjectName) {
		this.electronicSubjectName = electronicSubjectName;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public boolean isActivated() {
		return isActivated;
	}
	
	public void setActivated(boolean isActivated) {
		this.isActivated = isActivated;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	public String getProfileType() {
		return profileType;
	}
	
	public void setProfileType(String profileType) {
		this.profileType = profileType;
	}
	
}
