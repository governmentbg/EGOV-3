package com.ibs.myspace.portlet.bean;

import java.util.List;

public class AuthorizationBean {
	private Integer authorizedType = null;
	private Integer authorizedIdentifierType = null;
	private String authorizedIdentifier = null;
	private String encryptedAuthorizedIdentifier = null;
	private String authorizedNames = null;
	private String actionIds = null;
	private String validFromDate = null;
	private String validFromTime = null;
	private String validToDate = null;
	private String validToTime = null;
	private List<SelectedSystemBean> loadedSystemBeans = null;
	private String xmlBase64 = null;
	private String xmlBase64FileName = null;
	private String orn = null;
	
	public Integer getAuthorizedType() {
		return authorizedType;
	}
	public void setAuthorizedType(Integer authorizedType) {
		this.authorizedType = authorizedType;
	}
	public Integer getAuthorizedIdentifierType() {
		return authorizedIdentifierType;
	}
	public void setAuthorizedIdentifierType(Integer authorizedIdentifierType) {
		this.authorizedIdentifierType = authorizedIdentifierType;
	}
	public String getAuthorizedIdentifier() {
		return authorizedIdentifier;
	}
	public void setAuthorizedIdentifier(String authorizedIdentifier) {
		this.authorizedIdentifier = authorizedIdentifier;
	}	
	public String getEncryptedAuthorizedIdentifier() {
		return encryptedAuthorizedIdentifier;
	}
	public void setEncryptedAuthorizedIdentifier(String encryptedAuthorizedIdentifier) {
		this.encryptedAuthorizedIdentifier = encryptedAuthorizedIdentifier;
	}
	public String getAuthorizedNames() {
		return authorizedNames;
	}
	public void setAuthorizedNames(String authorizedNames) {
		this.authorizedNames = authorizedNames;
	}
	public String getActionIds() {
		return actionIds;
	}
	public void setActionIds(String actionIds) {
		this.actionIds = actionIds;
	}
	public String getValidFromDate() {
		return validFromDate;
	}
	public void setValidFromDate(String validFromDate) {
		this.validFromDate = validFromDate;
	}
	public String getValidFromTime() {
		return validFromTime;
	}
	public void setValidFromTime(String validFromTime) {
		this.validFromTime = validFromTime;
	}
	public String getValidToDate() {
		return validToDate;
	}
	public void setValidToDate(String validToDate) {
		this.validToDate = validToDate;
	}
	public String getValidToTime() {
		return validToTime;
	}
	public void setValidToTime(String validToTime) {
		this.validToTime = validToTime;
	}
	public List<SelectedSystemBean> getLoadedSystemBeans() {
		return loadedSystemBeans;
	}
	public void setLoadedSystemBeans(List<SelectedSystemBean> loadedSystemBeans) {
		this.loadedSystemBeans = loadedSystemBeans;
	}
	public String getXmlBase64() {
		return xmlBase64;
	}
	public void setXmlBase64(String xmlBase64) {
		this.xmlBase64 = xmlBase64;
	}
	public String getXmlBase64FileName() {
		return xmlBase64FileName;
	}
	public void setXmlBase64FileName(String xmlBase64FileName) {
		this.xmlBase64FileName = xmlBase64FileName;
	}
	public String getOrn() {
		return orn;
	}
	public void setOrn(String orn) {
		this.orn = orn;
	}	
}
