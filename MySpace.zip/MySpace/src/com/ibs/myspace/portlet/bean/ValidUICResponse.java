package com.ibs.myspace.portlet.bean;

public class ValidUICResponse {
	private String status;
	private String uic;
	private String company;
	private String legalFormAbbr;
	private String legalFormName;
	private String dataValidForDate;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getUic() {
		return uic;
	}
	public void setUic(String uic) {
		this.uic = uic;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getLegalFormAbbr() {
		return legalFormAbbr;
	}
	public void setLegalFormAbbr(String legalFormAbbr) {
		this.legalFormAbbr = legalFormAbbr;
	}
	public String getLegalFormName() {
		return legalFormName;
	}
	public void setLegalFormName(String legalFormName) {
		this.legalFormName = legalFormName;
	}
	public String getDataValidForDate() {
		return dataValidForDate;
	}
	public void setDataValidForDate(String dataValidForDate) {
		this.dataValidForDate = dataValidForDate;
	}
	@Override
	public String toString() {
		return "ValidUICResponse [status=" + status + ", uic=" + uic + ", company=" + company + ", legalFormAbbr="
				+ legalFormAbbr + ", legalFormName=" + legalFormName + ", dataValidForDate=" + dataValidForDate + "]";
	}
	
}
