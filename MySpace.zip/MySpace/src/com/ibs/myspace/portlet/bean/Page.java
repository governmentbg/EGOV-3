package com.ibs.myspace.portlet.bean;

public class Page {
	private String uniqueName;
	private String friendlyUrl;
	private String title;
	private String parentUniqueName;
	private String parentFriendlyUrl;
	
	public String getUniqueName() {
		return uniqueName;
	}
	public void setUniqueName(String uniqueName) {
		this.uniqueName = uniqueName;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getParentUniqueName() {
		return parentUniqueName;
	}
	public void setParentUniqueName(String parentUniqueName) {
		this.parentUniqueName = parentUniqueName;
	}
	public String getFriendlyUrl() {
		return friendlyUrl;
	}
	public void setFriendlyUrl(String friendlyUrl) {
		this.friendlyUrl = friendlyUrl;
	}
	public String getParentFriendlyUrl() {
		return parentFriendlyUrl;
	}
	public void setParentFriendlyUrl(String parentFriendlyUrl) {
		this.parentFriendlyUrl = parentFriendlyUrl;
	}
	
}
