package com.ibs.myspace.portlet.bean;

import java.util.HashMap;

public class RegixPersonDataBean {
	private HashMap<String, String> personNames = null;
	private HashMap<String, String> latinNames = null;
	private HashMap<String, String> foreignNames = null;
	private HashMap<String, String> gender = null;	
	private String egn = null;
	private String birthDate = null;
	private String placeBirth = null;
	private HashMap<String, String> nationality = null;
	
	public HashMap<String, String> getPersonNames() {
		return personNames != null ? personNames : new HashMap<>();
	}
	
	public void setPersonNames(HashMap<String, String> personNames) {
		this.personNames = personNames;
	}
	
	public HashMap<String, String> getLatinNames() {
		return latinNames != null ? latinNames : new HashMap<>();
	}
	
	public void setLatinNames(HashMap<String, String> latinNames) {
		this.latinNames = latinNames;
	}
	
	public HashMap<String, String> getForeignNames() {
		return foreignNames != null ? foreignNames : new HashMap<>();
	}
	
	public void setForeignNames(HashMap<String, String> foreignNames) {
		this.foreignNames = foreignNames;
	}
	
	public HashMap<String, String> getGender() {
		return gender;
	}
	
	public void setGender(HashMap<String, String> gender) {
		this.gender = gender;
	}
	
	public String getEgn() {
		return egn;
	}
	
	public void setEgn(String egn) {
		this.egn = egn;
	}
	
	public String getBirthDate() {
		return birthDate;
	}
	
	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}
	
	public String getPlaceBirth() {
		return placeBirth;
	}
	
	public void setPlaceBirth(String placeBirth) {
		this.placeBirth = placeBirth;
	}
	
	public HashMap<String, String> getNationality() {
		return nationality != null ? nationality : new HashMap<>();
	}
	
	public void setNationality(HashMap<String, String> nationality) {
		this.nationality = nationality;
	}
	
}
