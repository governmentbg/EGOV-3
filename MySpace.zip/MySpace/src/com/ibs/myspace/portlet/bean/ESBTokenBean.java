package com.ibs.myspace.portlet.bean;

public class ESBTokenBean {
	private String tokenType = null;	
	private String accessToken = null;
	private int expiresIn = 0;
	private long consentedOn = 0;
	private String scope = null;
	private String grantType = null;
	
	public String getTokenType() {
		return tokenType;
	}
	public void setTokenType(String tokenType) {
		this.tokenType = tokenType;
	}
	public String getAccessToken() {
		return accessToken;
	}
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	public int getExpiresIn() {
		return expiresIn;
	}
	public void setExpiresIn(int expiresIn) {
		this.expiresIn = expiresIn;
	}
	public long getConsentedOn() {
		return consentedOn;
	}
	public void setConsentedOn(long consentedOn) {
		this.consentedOn = consentedOn;
	}
	public String getScope() {
		return scope;
	}
	public void setScope(String scope) {
		this.scope = scope;
	}
	public String getGrantType() {
		return grantType;
	}
	public void setGrantType(String grantType) {
		this.grantType = grantType;
	}
	
	
}
