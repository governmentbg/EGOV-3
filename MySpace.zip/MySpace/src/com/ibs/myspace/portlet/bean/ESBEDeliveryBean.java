package com.ibs.myspace.portlet.bean;

public class ESBEDeliveryBean {
	private long messageId = 0;	 
	private String subject = null;
	private String dateSent = null;	
	private String dateReceived = null;	
	private String senderProfileName = null;
	private String senderLoginName = null;
	private String recipientProfileName = null;
	private String recipientLoginName = null;
	private String recipients = null;
	private String url = null;
	private String messageType = null;
	
	public long getMessageId() {
		return messageId;
	}
	public void setMessageId(long messageId) {
		this.messageId = messageId;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getDateSent() {
		return dateSent;
	}
	public void setDateSent(String dateSent) {
		this.dateSent = dateSent;
	}
	public String getDateReceived() {
		return dateReceived;
	}
	public void setDateReceived(String dateReceived) {
		this.dateReceived = dateReceived;
	}
	public String getSenderProfileName() {
		return senderProfileName;
	}
	public void setSenderProfileName(String senderProfileName) {
		this.senderProfileName = senderProfileName;
	}
	public String getSenderLoginName() {
		return senderLoginName;
	}
	public void setSenderLoginName(String senderLoginName) {
		this.senderLoginName = senderLoginName;
	}
	public String getRecipientProfileName() {
		return recipientProfileName;
	}
	public void setRecipientProfileName(String recipientProfileName) {
		this.recipientProfileName = recipientProfileName;
	}
	public String getRecipientLoginName() {
		return recipientLoginName;
	}
	public void setRecipientLoginName(String recipientLoginName) {
		this.recipientLoginName = recipientLoginName;
	}
	public String getRecipients() {
		return recipients;
	}
	public void setRecipients(String recipients) {
		this.recipients = recipients;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getMessageType() {
		return messageType;
	}
	public void setMessageType(String messageType) {
		this.messageType = messageType;
	}	
}
