package com.ibs.myspace.portlet.bean;

public class MultipartHeaderInfoBean {
	private String multipartDelimiter;

	private String originalFileName;

	private String contentType;

	public MultipartHeaderInfoBean(String _multipart_delimiter, String _original_file_name, String _content_type) {
		multipartDelimiter = _multipart_delimiter;
		originalFileName = _original_file_name;
		contentType = _content_type;
	}

	public String getMultipartDelimiter() {
		return multipartDelimiter;
	}

	public void setMultipartDelimiter(String multipartDelimiter) {
		this.multipartDelimiter = multipartDelimiter;
	}

	public String getOriginalFileName() {
		return originalFileName;
	}

	public void setOriginalFileName(String originalFileName) {
		this.originalFileName = originalFileName;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	
	
}
