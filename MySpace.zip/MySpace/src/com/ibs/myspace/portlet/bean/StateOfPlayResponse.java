package com.ibs.myspace.portlet.bean;

public class StateOfPlayResponse {
	private String uic;
	private String cyrillicFullName;
	private String cyrillicShortName;
	private String latinFullName;
	
	
	public String getUic() {
		return uic;
	}
	public void setUic(String uic) {
		this.uic = uic;
	}
	public String getCyrillicFullName() {
		return cyrillicFullName;
	}
	public void setCyrillicFullName(String cyrillicFullName) {
		this.cyrillicFullName = cyrillicFullName;
	}
	public String getCyrillicShortName() {
		return cyrillicShortName;
	}
	public void setCyrillicShortName(String cyrillicShortName) {
		this.cyrillicShortName = cyrillicShortName;
	}
	public String getLatinFullName() {
		return latinFullName;
	}
	public void setLatinFullName(String latinFullName) {
		this.latinFullName = latinFullName;
	}
	@Override
	public String toString() {
		return "StateOfPlayResponse [uic=" + uic + ", cyrillicFullName=" + cyrillicFullName + ", cyrillicShortName="
				+ cyrillicShortName + ", latinFullName=" + latinFullName + "]";
	}
	
}
