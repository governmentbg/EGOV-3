package com.ibs.myspace.portlet;

import java.util.List;

import javax.portlet.PortletMode;
import javax.portlet.PortletURL;
import javax.portlet.RenderResponse;
import javax.portlet.WindowState;

import com.egov.wcm.cache.EgovWCMCache;
import com.egov.wcm.cache.model.EgovRegisterGroup;
import com.ibs.myspace.portlet.dbo.UserProfile;
import com.ibs.myspace.portlet.management.UserProfileParametersManagement;
import com.ibs.myspace.portlet.utils.MySpaceUtils;

/**
* Main controller for handling register groups side navigation.
* 
* @author      Damyan Slavov
* @version     %I%, %G%
* @since       1.0
*/
public class MySpaceRegisterGroupsSideNavManager {
	
	/**
	 * Builds the HTML with the pages (groups) for the current profile type. 
	 * 
	 * @param renderResponse			javax.portlet.RenderResponse.
	 * @param currentProfileType		current profile type id.
	 * @param currentPage				current group name.
	 * @return          				HTML with <option></option>..<option></option> 
	 *
	 */
	public String buildSideNavigationHTML(RenderResponse renderResponse, UserProfile profile, String currentPage) {
		String html = "";
		boolean active = false;
		String pageName = null;
		PortletURL actionUrl = null;	
		EgovRegisterGroup page = null;
		UserProfileParametersManagement management = new UserProfileParametersManagement();
		MySpaceUtils utils = new MySpaceUtils();
		List<EgovRegisterGroup> allPages = EgovWCMCache.getRegisterGroupsByProfileTypeId().get(Integer.parseInt(profile.getProfileType()));
		if (allPages != null && allPages.size() > 0) {
			for (int i = 0; i < allPages.size(); i++) {
				page = allPages.get(i);
				if (!management.renderRegisterGroup(page)) {
					continue;
				}
				if (!utils.checkProfileHasGroupProfileStructureType(profile, page)) {
					continue;
				}
				actionUrl = renderResponse.createActionURL();
				try {
					pageName = page.getName();
					active = currentPage != null && currentPage.equalsIgnoreCase(pageName);					
					actionUrl.setWindowState(WindowState.NORMAL);
					actionUrl.setPortletMode(PortletMode.VIEW);
					actionUrl.setParameter(MySpacePortlet.PARAMETER_ACTION, MySpacePortlet.ACTION_CHANGE_PAGE);
					actionUrl.setParameter(MySpacePortlet.PARAMETER_VALUE, MySpacePortlet.PROFILE_PARAMETERS_PAGE);
					actionUrl.setParameter(MySpacePortlet.PARAMETER_REGISTER_GROUP_NAME, pageName);
					html += "<div class=\"side-nav" + (active ? "-active" : "") + "\" onclick=\"document.location.href='" + actionUrl.toString() + "';\">" + page.getLabel() + "</div>";
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return html;
	}
	
}
