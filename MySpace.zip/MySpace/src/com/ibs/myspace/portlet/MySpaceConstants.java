package com.ibs.myspace.portlet;

public class MySpaceConstants {	
	// Global administrator user name.

	public static final String MESSAGE_TYPE_INFORMATION = "I";
	public static final String MESSAGE_TYPE_WARNING = "W";
	public static final String MESSAGE_TYPE_ERROR = "E";
		
	public static final String LANGUAGE_BG = "bg";
	public static final String LANGUAGE_EN = "en";
	
	public static final String E_PAYMENT_URL = "";
	public static final String AHU_URL = "";
	
	public static final int USER_ADDED_TO_LEGAL_ENTITY = 1;
	public static final int USER_EDIT_ROLES_TO_LEGAL_ENTITY = 2;
	public static final int USER_INVITED_TO_LEGAL_ENTITY = 3;
	public static final int USER_REINVITED_TO_LEGAL_ENTITY = 4;
	public static final int USER_REMOVED_FROM_LEGAL_ENTITY = 9;
	
	public static final String USER_PROFILE_TYPE_PERSONAL = "1";
	public static final String USER_PROFILE_TYPE_LEGAL_ENTITY = "2";
	public static final String USER_PROFILE_TYPE_SERVICE_SUPPLIER = "3";
	public static final String USER_PROFILE_TYPE_LEGAL_ENTITY_AL2 = "4";
	
	public static final int USER_PROFILE_IDENTIFIER_TYPE_EGN = 1;
	public static final int USER_PROFILE_IDENTIFIER_TYPE_LNC = 2;
	// TODO ADD MORE...
	
	public static final String USER_PROFILE_METHOD_OF_REPRESENTATION_SEPARATELY = "1";
	public static final String USER_PROFILE_METHOD_OF_REPRESENTATION_TOGETHER = "2";
	public static final String USER_PROFILE_METHOD_OF_REPRESENTATION_OTHER_WAY = "3";
	
	public static final String USER_PROFILE_STATUS_INACTIVE = "0";
	public static final String USER_PROFILE_STATUS_ACTIVE = "1";	
	public static final String USER_PROFILE_STATUS_NOT_CONFIRMED = "2";		
	public static final String USER_PROFILE_STATUS_BLOCKED = "9";
	
	public static final String USER_PROFILE_REQUEST_STATUS_APPROVED = "1";
	public static final String USER_PROFILE_REQUEST_STATUS_NOT_APPROVED = "2";	
	public static final String USER_PROFILE_REQUEST_STATUS_CANCELED = "9";
	
	public static final String USER_PROFILE_CONSENT_YES = "1";
	public static final String USER_PROFILE_CONSENT_NO = "0";
	
	public static final String TEMP_UPLOAD_FOLDER = "/tmp";
	public static final int MAX_MEMORY_SIZE = 1024 * 1024 * 7; // 7MB
	public static final int MAX_REQUEST_SIZE = 1024 * 1024 * 6; // 6MB
	
	public static final int RESULTS_PER_PAGE = 10;
	

	public static final String EVENT_LOG_PORTAL_AUTHN_REQUEST_SENT = "PORTAL_AUTHN_REQUEST_SENT";
	public static final String EVENT_LOG_PORTAL_LOGIN_OPERATION = "PORTAL_LOGIN_OPERATION";
	public static final String EVENT_LOG_PORTAL_LOGOUT_OPERATION = "PORTAL_LOGOUT_OPERATION";
	public static final String EVENT_LOG_PORTAL_EDIT_PROFILE = "PORTAL_EDIT_PROFILE";
	public static final String EVENT_LOG_PORTAL_DEACTIVATE_PROFILE = "PORTAL_DEACTIVATE_PROFILE";
	public static final String EVENT_LOG_PORTAL_DEACTIVATE_ALL_PROFILES = "PORTAL_DEACTIVATE_ALL_PROFILES";	
	public static final String EVENT_LOG_PORTAL_ACTIVATE_PROFILE = "PORTAL_ACTIVATE_PROFILE";
	public static final String EVENT_LOG_PORTAL_CONFIRM_PROFILE = "PORTAL_CONFIRM_PROFILE";
	public static final String EVENT_LOG_PORTAL_REQUEST_PROFILE = "PORTAL_REQUEST_PROFILE";
	public static final String EVENT_LOG_PORTAL_LAST_VISITED_SERVICE = "PORTAL_LAST_VISITED_SERVICE";
	public static final String EVENT_LOG_PORTAL_ADD_USER_TO_PROFILE = "PORTAL_ADD_USER_TO_PROFILE";
	public static final String EVENT_LOG_PORTAL_EDIT_USER_OF_PROFILE = "PORTAL_EDIT_USER_OF_PROFILE";
	public static final String EVENT_LOG_PORTAL_REMOVE_USER_FROM_PROFILE = "PORTAL_REMOVE_USER_FROM_PROFILE";
	public static final String EVENT_LOG_PORTAL_INVITE_USER_TO_PROFILE = "PORTAL_INVITE_USER_TO_PROFILE";
	public static final String EVENT_LOG_PORTAL_REINVITE_USER_TO_PROFILE = "PORTAL_REINVITE_USER_TO_PROFILE";
	public static final String EVENT_LOG_PORTAL_REMOVE_INVITATION_TO_PROFILE = "PORTAL_REMOVE_INVITATION_TO_PROFILE";
	public static final String EVENT_LOG_PORTAL_SWITCH_PROFILE = "PORTAL_SWITCH_PROFILE";
	public static final String EVENT_LOG_PORTAL_ADD_FAVOURITE_SERVICE = "PORTAL_ADD_FAVOURITE_SERVICE";
	public static final String EVENT_LOG_PORTAL_REMOVE_FAVOURITE_SERVICE = "PORTAL_REMOVE_FAVOURITE_SERVICE";
	public static final String EVENT_LOG_PORTAL_PROFILE_PERSONALIZATION = "PORTAL_PROFILE_PERSONALIZATION";
	public static final String EVENT_LOG_PORTAL_EDIT_PROFILE_PARAMETERS = "PORTAL_EDIT_PROFILE_PARAMETERS";
	public static final String EVENT_LOG_PORTAL_ADD_AUTHORIZATION = "PORTAL_ADD_AUTHORIZATION";
	public static final String EVENT_LOG_PORTAL_CANCEL_AUTHORIZATION = "PORTAL_CANCEL_AUTHORIZATION";
	
	
	// Parameters types.
	public static final int PARAMETER_TYPE_TEXT = 1;
	public static final int PARAMETER_TYPE_TEXT_AREA = 2;
	public static final int PARAMETER_TYPE_NUMBER = 3;
	public static final int PARAMETER_TYPE_LIST_SINGLE = 4;
	public static final int PARAMETER_TYPE_LIST_MULTIPLE = 5;
	// Status codes.
	public static final int STATUS_INACTIVE = 0;
	public static final int STATUS_ACTIVE = 1;	
	// Parameters.
	public static final int VALUE_NO = 0;
	public static final int VALUE_YES = 1;
	
	// Authorizations - User types.
	public static final int AUTHORIZATIONS_USER_TYPE_PERSON = 1;
	public static final int AUTHORIZATIONS_USER_TYPE_LE = 2;	
	// Authorizations - Authorized types.
	public static final int AUTHORIZATIONS_AUTHORIZED_TYPE_PERSON = 1;
	public static final int AUTHORIZATIONS_AUTHORIZED_TYPE_LE = 2;
	// Authorizations - Authorized identifier types.
	public static final int AUTHORIZATIONS_AUTHORIZED_IDENTIFIER_TYPE_EGN = 1;
	public static final int AUTHORIZATIONS_AUTHORIZED_IDENTIFIER_TYPE_EIK = 3;
	
	// Authorizations - Status codes.
	public static final int AUTHORIZATIONS_STATUS_INACTIVE = 0; // virtual.
	public static final int AUTHORIZATIONS_STATUS_ACTIVE = 1;
	public static final int AUTHORIZATIONS_STATUS_CANCELED = 2;
	public static final int AUTHORIZATIONS_STATUS_BLOCKED = 3;
	public static final int AUTHORIZATIONS_STATUS_EXPIRED = 9; // virtual.
	
	public static final String AUTHORIZATION_DATE_FORMAT = "dd.MM.yyyy";
	public static final String AUTHORIZATION_DATE_TIME_FORMAT = "dd.MM.yyyy HH:mm:ss";
	
	
	// Invitation.	
	public static final int INVITATION_STATUS_NOT_CONFIRMED = 0;
	public static final int INVITATION_STATUS_CONFIRMED = 1;
	public static final int INVITATION_STATUS_CANCELED = 2;
	
	public static final int INVITATION_PROCESSED_YES = 1;

	
	public static String _PRODUCT_NAME = "MySpacePortlet";
	public static String _PRODUCT_VERSION = "1.4.5";
}
