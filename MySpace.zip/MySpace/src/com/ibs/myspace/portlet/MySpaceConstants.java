package com.ibs.myspace.portlet;

import java.util.HashMap;
import java.util.Map;

public class MySpaceConstants {
	public static String _SCHEMANAME = "EGOV.";
	// DB name for Oracle database.
	public static String _DB_ORACLE = "oracle";
	// DB name for IBM DB2 database.
	public static String _DB_DB2 = "db2";
	// DB name for PostgreSQL database.
	public static String _DB_POSTGRESQL = "postgresql";
	// Global administrator user name.
	public static String ADMIN_USER_NAME = "_REPLACED_";
	
	// Session key for storing "my favourite services" array list.
	public static String _USER_PROFILE_MY_FAVORITE_SERVICES_SESSION_KEY = "_USER_PROFILE_MY_FAVORITE_SERVICES_SESSION_KEY";

	// Configuration files.	
	public static String THREAD_CONFIG_FILE_NAME = "thread.conf";
	// Used values: 1 - execute thread, 0 - do not execute thread.
	public static String THREAD_EXECUTION_PARAMETER = "thread_execution";
	
	public static final String MESSAGE_TYPE_INFORMATION = "I";
	public static final String MESSAGE_TYPE_WARNING = "W";
	public static final String MESSAGE_TYPE_ERROR = "E";
		
	public static final String LANGUAGE_BG = "bg";
	public static final String LANGUAGE_EN = "en";
	
	public static final String HOME_PAGE_FRIENDLY_URL = "nachalo";
	public static final String E_PAYMENT_URL = "";
	public static final String AHU_URL = "";

	public static final String SEARCH_SCOPE_EGOV_ID = "_REPLACED_";
	
	public static final String LDAP_USERS_DN = "_REPLACED_";
	public static final String LDAP_GROUPS_DN = "_REPLACED_";
	
	public static final String LDAP_ATTRIBUTE_UID = "uid";
	public static final String LDAP_ATTRIBUTE_GIVEN_NAME = "givenName";
	public static final String LDAP_ATTRIBUTE_COMMON_NAME = "cn";
	public static final String LDAP_ATTRIBUTE_LAST_NAME = "sn";
	public static final String LDAP_ATTRIBUTE_PORTAL_EMAIL = "ibm-primaryEmail";
	public static final String LDAP_ATTRIBUTE_EMPLOYEE_NUMBER = "_REPLACED_";
	public static final String LDAP_ATTRIBUTE_EGOV_IDENTIFIER = "_REPLACED_";
	// we store identifier prefix.
	public static final String LDAP_ATTRIBUTE_DEPARTMENT_NUMBER = "_REPLACED_";
	// We store active profile id.
	public static final String LDAP_ATTRIBUTE_ROOM_NUMBER = "_REPLACED_";
	// We store the invitation id. (only during the request)
	public static final String LDAP_ATTRIBUTE_INVITATION_ID = "_REPLACED_";
	
	public static final String USER_PROFILE_ROLE_SELECTED = "1";
	public static final String USER_PROFILE_CHANGE_EMAIL_CONFIRMED = "1";
	public static final String USER_PROFILE_REIK_SELECTED = "1";
	
	public static final int USER_ADDED_TO_LEGAL_ENTITY = 1;
	public static final int USER_EDIT_ROLES_TO_LEGAL_ENTITY = 2;
	public static final int USER_INVITED_TO_LEGAL_ENTITY = 3;
	public static final int USER_REINVITED_TO_LEGAL_ENTITY = 4;
	public static final int USER_REMOVED_FROM_LEGAL_ENTITY = 9;
	
	public static final String USER_PROFILE_TYPE_PERSONAL = "1";
	public static final String USER_PROFILE_TYPE_LEGAL_ENTITY = "2";
	public static final String USER_PROFILE_TYPE_SERVICE_SUPPLIER = "3";
	public static final String USER_PROFILE_TYPE_LEGAL_ENTITY_AL2 = "4";
	
	public static final int USER_PROFILE_IDENTIFIER_TYPE_EGN = 1;
	public static final int USER_PROFILE_IDENTIFIER_TYPE_LNC = 2;
	// TODO ADD MORE...
	
	public static final String USER_PROFILE_METHOD_OF_REPRESENTATION_SEPARATELY = "1";
	public static final String USER_PROFILE_METHOD_OF_REPRESENTATION_TOGETHER = "2";
	public static final String USER_PROFILE_METHOD_OF_REPRESENTATION_OTHER_WAY = "3";
	
	public static final String USER_PROFILE_STATUS_INACTIVE = "0";
	public static final String USER_PROFILE_STATUS_ACTIVE = "1";	
	// This status is used for profiles created after invitation accepted for LE association.
	public static final String USER_PROFILE_STATUS_NOT_CONFIRMED = "2";		
	public static final String USER_PROFILE_STATUS_BLOCKED = "9";
	
	public static final String USER_PROFILE_REQUEST_STATUS_APPROVED = "1";
	public static final String USER_PROFILE_REQUEST_STATUS_NOT_APPROVED = "2";	
	public static final String USER_PROFILE_REQUEST_STATUS_CANCELED = "9";
	
	public static final String USER_PROFILE_CONSENT_YES = "1";
	public static final String USER_PROFILE_CONSENT_NO = "0";
	
	public static final String USER_PROFILE_SELECTOR_PERSISTS_YES = "1";
	public static final String USER_PROFILE_SELECTOR_PERSISTS_NO = "0";
	
	public static final String TEMP_UPLOAD_FOLDER = "/tmp";
	public static final int MAX_MEMORY_SIZE = 1024 * 1024 * 7; // 7MB
	public static final int MAX_REQUEST_SIZE = 1024 * 1024 * 6; // 6MB
	
	public static final int RESULTS_PER_PAGE = 10;
	
	public static final String ESB_LOGGING_URL_TEST = "_REPLACED_";
	public static final String ESB_LOGGING_URL = "_REPLACED_";
	public static final String ESB_REGIX_URL = "_REPLACED_";
	public static final String ESB_EDELIVERY_URL = "_REPLACED_";
	public static final String ORN_TEST_URL = "_REPLACED_";
	public static final String ORN_PROD_URL = "_REPLACED_";
	public static final String EVENT_LOG_PORTAL_AUTHN_REQUEST_SENT = "PORTAL_AUTHN_REQUEST_SENT";
	public static final String EVENT_LOG_PORTAL_LOGIN_OPERATION = "PORTAL_LOGIN_OPERATION";
	public static final String EVENT_LOG_PORTAL_LOGOUT_OPERATION = "PORTAL_LOGOUT_OPERATION";
	public static final String EVENT_LOG_PORTAL_EDIT_PROFILE = "PORTAL_EDIT_PROFILE";
	public static final String EVENT_LOG_PORTAL_DEACTIVATE_PROFILE = "PORTAL_DEACTIVATE_PROFILE";
	public static final String EVENT_LOG_PORTAL_DEACTIVATE_ALL_PROFILES = "PORTAL_DEACTIVATE_ALL_PROFILES";	
	public static final String EVENT_LOG_PORTAL_ACTIVATE_PROFILE = "PORTAL_ACTIVATE_PROFILE";
	public static final String EVENT_LOG_PORTAL_CONFIRM_PROFILE = "PORTAL_CONFIRM_PROFILE";
	public static final String EVENT_LOG_PORTAL_ACCEPT_GENERAL_TERMS = "PORTAL_ACCEPT_GENERAL_TERMS";
	public static final String EVENT_LOG_PORTAL_REQUEST_PROFILE = "PORTAL_REQUEST_PROFILE";
	public static final String EVENT_LOG_PORTAL_LAST_VISITED_SERVICE = "PORTAL_LAST_VISITED_SERVICE";
	public static final String EVENT_LOG_PORTAL_ADD_USER_TO_PROFILE = "PORTAL_ADD_USER_TO_PROFILE";
	public static final String EVENT_LOG_PORTAL_EDIT_USER_OF_PROFILE = "PORTAL_EDIT_USER_OF_PROFILE";
	public static final String EVENT_LOG_PORTAL_REMOVE_USER_FROM_PROFILE = "PORTAL_REMOVE_USER_FROM_PROFILE";
	public static final String EVENT_LOG_PORTAL_INVITE_USER_TO_PROFILE = "PORTAL_INVITE_USER_TO_PROFILE";
	public static final String EVENT_LOG_PORTAL_REINVITE_USER_TO_PROFILE = "PORTAL_REINVITE_USER_TO_PROFILE";
	public static final String EVENT_LOG_PORTAL_REMOVE_INVITATION_TO_PROFILE = "PORTAL_REMOVE_INVITATION_TO_PROFILE";
	public static final String EVENT_LOG_PORTAL_SWITCH_PROFILE = "PORTAL_SWITCH_PROFILE";
	public static final String EVENT_LOG_PORTAL_ADD_FAVOURITE_SERVICE = "PORTAL_ADD_FAVOURITE_SERVICE";
	public static final String EVENT_LOG_PORTAL_REMOVE_FAVOURITE_SERVICE = "PORTAL_REMOVE_FAVOURITE_SERVICE";
	public static final String EVENT_LOG_PORTAL_PROFILE_PERSONALIZATION = "PORTAL_PROFILE_PERSONALIZATION";
	public static final String EVENT_LOG_PORTAL_EDIT_PROFILE_PARAMETERS = "PORTAL_EDIT_PROFILE_PARAMETERS";
	public static final String EVENT_LOG_PORTAL_ADD_AUTHORIZATION = "PORTAL_ADD_AUTHORIZATION";
	public static final String EVENT_LOG_PORTAL_CANCEL_AUTHORIZATION = "PORTAL_CANCEL_AUTHORIZATION";
	public static final String EVENT_LOG_PORTAL_ADD_PROFILE_IDENTIFIER = "PORTAL_ADD_PROFILE_IDENTIFIER";
	public static final String EVENT_LOG_PORTAL_REMOVE_PROFILE_IDENTIFIER = "PORTAL_REMOVE_PROFILE_IDENTIFIER";
	public static final String EVENT_LOG_PORTAL_SET_DEFAULT_PROFILE = "PORTAL_SET_DEFAULT_PROFILE";
	public static final String EVENT_LOG_PORTAL_REGIX_UIC_CLOSED = "PORTAL_REGIX_UIC_CLOSED";
	
	public static final String E_TRANSLATION_URL = "_REPLACED_";
	public static final String E_TRANSLATION_USERNAME = "_REPLACED_";
	public static final String E_TRANSLATION_PASSWORD = "_REPLACED_";

	public static final String ESB_TEST_CLIENT_CERT_NAME = "egov_stating.p12";
	public static final String ESB_TEST_CLIENT_CERT_PASS = "_REPLACED_";
	public static final String ESB_CLIENT_CERT_NAME = "egov_prod.p12";
	public static final String ESB_CLIENT_CERT_PASS = "_REPLACED_";
	public static final String ESB_TOKEN_GRANT_TYPE = "_REPLACED_";
	public static final String ESB_TOKEN_CLIENT_ID = "egov.bg";
	public static final String ESB_TEST_TOKEN_CLIENT_ID = "staging.egov.bg";
	public static final String ESB_TEST_TOKEN_URL = "_REPLACED_";
	public static final String ESB_TEST_ORN_URL = "_REPLACED_";
	public static final String ESB_TOKEN_URL = "_REPLACED_";
	public static final String ESB_ORN_URL = "_REPLACED_";
	public static final String ESB_ORN_URI_SERVICE = "e-document";
	public static final String ESB_ORN_BULSTAT = "_REPLACED_";
	
	public static final String ESB_TEST_E_DELIVERY_URL = "_REPLACED_";
	public static final String ESB_E_DELIVERY_URL = "_REPLACED_";
	public static final String ESB_E_DELIVERY_DIRECTION_RECEIVED = "RECEIVED";
	public static final String ESB_E_DELIVERY_DIRECTION_SENT = "SENT";
	
	public static final String ESB_TOKEN_SCOPE_ORN = "_REPLACED_"; // new will be '_REPLACED_'
	public static final String ESB_TOKEN_SCOPE_E_DELIVERY = "_REPLACED_";
	public static final String ESB_TOKEN_SCOPE_E_PAYMENT = "_REPLACED_";
	public static final String ESB_TOKEN_SCOPE_MDT = "_REPLACED_";

	public static final String ESB_TEST_E_PAYMENT_URL = "_REPLACED_";
	public static final String ESB_E_PAYMENT_URL = "_REPLACED_";
	public static final String ESB_E_PAYMENT_STATUS_PAID = "PAID";
	public static final String ESB_E_PAYMENT_STATUS_PENDING = "PENDING";
	public static final String ESB_E_PAYMENT_STATUS_AUTHORIZED = "AUTHORIZED";
	public static final String ESB_E_PAYMENT_STATUS_ORDERED = "ORDERED";
	public static final String ESB_E_PAYMENT_STATUS_EXPIRED = "EXPIRED";
	public static final String ESB_E_PAYMENT_STATUS_CANCELED = "CANCELED";
	public static final String ESB_E_PAYMENT_STATUS_SUSPENDED = "SUSPENDED";
	
	public static final String ESB_TEST_MDT_URL = "_REPLACED_";
	public static final String ESB_MDT_URL = "_REPLACED_";
	public static final String ESB_MDT_MUNICIPALITY_STATUS_OBLIGATIONS = "OBLIGATIONS"; 			// лицето има задължения в общината
	public static final String ESB_MDT_MUNICIPALITY_STATUS_SERVICE_FAULT = "SERVICE_FAULT"; 		// грешка върната от сървиса за общината
	public static final String ESB_MDT_MUNICIPALITY_STATUS_SERVICE_TIMEOUT = "SERVICE_TIMEOUT";		// при таймаут на сървисът за община 
	public static final String ESB_MDT_MUNICIPALITY_STATUS_MISSING_DEPT = "MISSING_DEPT";			// лицето има данни в общината, но няма задължения за плащане
	public static final String ESB_MDT_MUNICIPALITY_STATUS_MISSING_OBJECT = "MISSING_OBJECT";		// лицето няма данни в общината
	public static final String ESB_MDT_MUNICIPALITY_PAYMENT_STATUS_PENDING = "PENDING";				// успешно регистрирано задължение
	public static final String ESB_MDT_MUNICIPALITY_PAYMENT_STATUS_NOTPENDING = "NOTPENDING";		// нерегистрирано задължение
	public static final String ESB_MDT_MUNICIPALITY_PAYMENT_STATUS_SERVICE_FAULT = "SERVICE_FAULT";	// грешка върната от сървиса на еПлащане
	

	public static final String ESB_TEST_REGISTER_MDT_URL = "_REPLACED_";
	public static final String ESB_REGISTER_MDT_URL = "_REPLACED_";

											 
	public static final String REGIX_TEST_URL = "_REPLACED_";
	public static final String REGIX_TEST_PASSWORD = "_REPLACED_";
	public static final String REGIX_TEST_JKS_FILENAME = "server_test.jks";
	public static final String REGIX_PROD_URL = "_REPLACED_";
	public static final String REGIX_PROD_PASSWORD = "_REPLACED_";
	public static final String REGIX_PROD_JKS_FILENAME = "server.jks";
	public static final String REGIX_STAGING_PASSWORD = "_REPLACED_";
	public static final String REGIX_STAGING_JKS_FILENAME = "server_staging.jks";
	public static final String REGIX_V2_PROD_URL = "_REPLACED_";	
	public static final String REGIX_V2_PASSWORD = "_REPLACED_";
	public static final String REGIX_V2_JKS_FILENAME = "server_staging.jks";
	
	public static final String LDAP_PROD_ADDRESS = "_REPLACED_";
	public static final String LDAP_TEST_ADDRESS = "_REPLACED_";
	public static final String COMMUNICATION_HS_VERSION_1 = "V1";
	public static final String COMMUNICATION_HS_VERSION_2 = "V2";

	public static final String E_JOURNAL_ADDRESS_PROD = "_REPLACED_";
	public static final String E_JOURNAL_ADDRESS_TEST = "_REPLACED_";
	
	public static final String E_JOURNAL_SYSTEM_OID_OWNER = "_REPLACED_";
	public static final int E_JOURNAL_ID_SERVICE_PARAM = _REPLACED_;
	
	public static final int E_JOURNAL_STAGE_INITIALIZE = 1;
	public static final int E_JOURNAL_STAGE_PAYMENT = 2;
	public static final int E_JOURNAL_STAGE_DELIVERY = 3;
	public static final int E_JOURNAL_STAGE_PROVISION = 4;
	public static final int E_JOURNAL_STAGE_CANCEL = 5;
	
	public static final int E_JOURNAL_STATUS_LOGIN_OR_CREATE_PE_PROFILE = 1;
	public static final int E_JOURNAL_STATUS_CREATE_LE_PROFILE = 2;
	public static final int E_JOURNAL_STATUS_ASSIGN_PE_PROFILE_TO_LE_PROFILE = 3;
	public static final int E_JOURNAL_STATUS_REMOVE_PE_PROFILE_FROM_LE_PROFILE = 4;
	public static final int E_JOURNAL_STATUS_CREATE_AUTHORIZATION = 5;
	public static final int E_JOURNAL_STATUS_CANCEL_AUTHORIZATION = 6;
	public static final int E_JOURNAL_STATUS_ACCESS_REGIX = 7;
	public static final int E_JOURNAL_STATUS_REQUEST_SERVICE = 8;
	public static final int E_JOURNAL_STATUS_PAYMENT_OF_OBLIGATION = 9;
	public static final int E_JOURNAL_STATUS_SEND_MESSAGE = 10;
	

	public static final String E_DELIVERY_SECRET_KEY_IN_BASE_64 = "_REPLACED_";
	public static final String E_FORMS_SECRET_KEY_IN_BASE_64 = "3 _REPLACED_";
	
	public static final String _EGOV_IDENTIFIER_KEY = "_REPLACED_";
	public static final String _EGOV_IDENTIFIER_IV_KEY = "_REPLACED_";
	
	public static final String E_DELIVERY_DOMAIN_PROD = "_REPLACED_";
	public static final String E_DELIVERY_DOMAIN_TEST = "_REPLACED_";
	
	public static final int MAX_FAVORITE_SERVICES = 10;

	public static final String XML_FILE_CONTENT_TYPE = "text/xml";
	
	public static final String PORTAL_OID = "_REPLACED_";
	
	// Parameters types.
	public static final int PARAMETER_TYPE_TEXT = 1;
	public static final int PARAMETER_TYPE_TEXT_AREA = 2;
	public static final int PARAMETER_TYPE_NUMBER = 3;
	public static final int PARAMETER_TYPE_LIST_SINGLE = 4;
	public static final int PARAMETER_TYPE_LIST_MULTIPLE = 5;
	// Status codes.
	public static final int STATUS_INACTIVE = 0;
	public static final int STATUS_ACTIVE = 1;	
	// Parameters.
	public static final int VALUE_NO = 0;
	public static final int VALUE_YES = 1;
	
	// Authorizations - User types.
	public static final int AUTHORIZATIONS_USER_TYPE_PERSON = 1;
	public static final int AUTHORIZATIONS_USER_TYPE_LE = 2;	
	// Authorizations - Authorized types.
	public static final int AUTHORIZATIONS_AUTHORIZED_TYPE_PERSON = 1;
	public static final int AUTHORIZATIONS_AUTHORIZED_TYPE_LE = 2;
	// Authorizations - Authorized identifier types.
	public static final int AUTHORIZATIONS_AUTHORIZED_IDENTIFIER_TYPE_EGN = 1;
	public static final int AUTHORIZATIONS_AUTHORIZED_IDENTIFIER_TYPE_EIK = 3;
	
	// Authorizations - Status codes.
	public static final int AUTHORIZATIONS_STATUS_INACTIVE = 0; // virtual.
	public static final int AUTHORIZATIONS_STATUS_ACTIVE = 1;
	public static final int AUTHORIZATIONS_STATUS_CANCELED = 2;
	public static final int AUTHORIZATIONS_STATUS_BLOCKED = 3;
	public static final int AUTHORIZATIONS_STATUS_EXPIRED = 9; // virtual.
	
	public static final String AUTHORIZATION_DATE_FORMAT = "dd.MM.yyyy";
	public static final String AUTHORIZATION_DATE_TIME_FORMAT = "dd.MM.yyyy HH:mm:ss";
	
	// Identifiers prefixes.
	public static final String IDENTIFIER_PREFIX_EGN = "PNO";
	public static final String IDENTIFIER_PREFIX_LNC = "PI:";	
	public static final String IDENTIFIER_PREFIX_CARD_NUMBER = "IDC";
	
	public static final String IDENTIFIER_TYPE_PERSONAL_CARD_NUMBER = "1";
	public static final String IDENTIFIER_TYPE_PASSPORT = "2";
	public static final String IDENTIFIER_TYPE_PIK_NRA = "3";
	public static final String IDENTIFIER_TYPE_PIK_NOI = "4";
	public static final String IDENTIFIER_TYPE_EORI = "5";
	public static final String IDENTIFIER_TYPE_NATIONAL_IDENTIFIER_FOREIGNER = "6";
	
	public static final int OPERATION_TYPE_REMOVE_IDENTIFIER = 0;
	public static final int OPERATION_TYPE_ADD_IDENTIFIER = 1;	
	
	public static final String COUNTRY_CODE_BG = "BG";
	
	public static final String JNDI_PORTLET_STATE = "_REPLACED_";
	public static final String EMAIL_CONFIRM_TYPE_PARM = "emailConfirmType";
	public static final String EMAIL_CONFIRM_CONFIRMATION_CODE_PARM = "emailConfirmationCode";	
	
	public static final int TYPE_EMAIL_PERSONAL = 1;
	public static final int TYPE_EMAIL_LEGAL_ENTITY = 2;

	public static final int MODE_EMAIL_REGIX_CLOSED_UIC = 1;
	public static final int MODE_EMAIL_DEACTIVATING_UIC = 2;
	
	public static final String EGOV_REGISTRATION_PAGE_CONTENT_NAME = "RegistrationInEGOV";
	public static final String EGOV_REGISTRATION_PAGE_CONTENT_ELEMENT_LEFT_COLUMN_NAME = "leftColumn";
	public static final String EGOV_REGISTRATION_PAGE_CONTENT_ELEMENT_RIGHT_COLUMN_NAME = "rightColumn";
	public static final String EGOV_TERMS_AND_CONDITIONS_CONTENT_NAME = "TermsAndConditionsInEGOV";
	public static final String EGOV_TERMS_AND_CONDITIONS_CONTENT_ELEMENT_BODY_NAME = "body";
	public static final String EGOV_TERMS_AND_CONDITIONS_CONTENT_ELEMENT_RELEASE_DATE_NAME = "releaseDate";
	
	public static final String EGOV_CACHE_UTILS_NEW_PROFILES = "NEW_PROFILES";
	public static final long MDT_CACHE_EXPIRATION_TIME = 5 * 60 * 1000; // 5 mins
	
	// Invitation.	
	public static final int INVITATION_STATUS_NOT_CONFIRMED = 0;
	public static final int INVITATION_STATUS_CONFIRMED = 1;
	public static final int INVITATION_STATUS_CANCELED = 2;
	
	public static final int INVITATION_PROCESSED_YES = 1;

	public static final int ETRANSLATION_REQUEST_ORIGINAL_FILE = 1;
	public static final int ETRANSLATION_REQUEST_TRANSLATED_FILE = 2;
	
	public static final String[] ETRANSLATION_SUPPORTED_LANGUAGES_CODES = new String[] {
		"BG","FR","IT","RO","HR","FI","LV","RU","CS","DE","LT","ES","DA","EL","MT","SK","NL","HU","NB","SL","EN","IS","PL","SV","ET","GA","PT"
	};
	
	public static Map<String, String> ETRANSLATION_SUPPORTED_LANGUAGES_NAMES = null;
	static {
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES = new HashMap<String, String>();
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("BG", "Български");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("FR", "French");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("IT", "Italian");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("RO", "Romanian");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("HR", "Croatian");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("FI", "Finnish");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("LV", "Latvian");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("RU", "Russian");                   
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("CS", "Czech");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("DE", "German");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("LT", "Lithuanian");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("ES", "Spanish");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("DA", "Danish");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("EL", "Greek");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("MT", "Maltese");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("SK", "Slovak");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("NL", "Dutch");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("HU", "Hungarian");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("NB", "Norwegian Bokmål");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("SL", "Slovenian");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("EN", "English");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("IS", "Icelandic");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("PL", "Polish");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("SV", "Swedish");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("ET", "Estonian");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("GA", "Irish");
		ETRANSLATION_SUPPORTED_LANGUAGES_NAMES.put("PT", "Portuguese");
	}
	
	public static final String EAUTH_COOKIE_NAME = "_REPLACED_";
	
	public static final String _PRODUCT_NAME = "MySpacePortlet";
	public static final String _PRODUCT_VERSION = "1.4.7";
}
