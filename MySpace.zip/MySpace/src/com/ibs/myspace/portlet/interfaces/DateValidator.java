package com.ibs.myspace.portlet.interfaces;

public interface DateValidator {
	boolean isValid(String dateStr);
}
