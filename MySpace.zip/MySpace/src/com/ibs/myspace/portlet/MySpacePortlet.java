package com.ibs.myspace.portlet;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringWriter;
import java.io.Writer;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.PrivilegedExceptionAction;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.GenericPortlet;
import javax.portlet.PortletException;
import javax.portlet.PortletMode;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequest;
import javax.portlet.PortletRequestDispatcher;
import javax.portlet.PortletResponse;
import javax.portlet.PortletSession;
import javax.portlet.ReadOnlyException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ResourceRequest;
import javax.portlet.ResourceResponse;
import javax.portlet.ValidatorException;
import javax.portlet.WindowState;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.portlet.PortletFileUpload;
import org.json.JSONArray;
import org.json.JSONObject;

import com.egov.wcm.cache.EgovService;
import com.egov.wcm.cache.EgovServiceProvider;
import com.egov.wcm.cache.EgovWCMCache;
import com.egov.wcm.cache.EgovWCMUtils;
import com.ibm.portal.Locator;
import com.ibm.portal.MetaDataProvider;
import com.ibm.portal.content.ContentNode;
import com.ibm.portal.content.ContentNodeType;
import com.ibm.portal.model.NavigationModelHome;
import com.ibm.portal.model.NavigationModelProvider;
import com.ibm.portal.model.NavigationSelectionModelHome;
import com.ibm.portal.navigation.NavigationModel;
import com.ibm.portal.navigation.NavigationNode;
import com.ibm.portal.portlet.service.PortletServiceHome;
import com.ibm.portal.resolver.friendly.service.PortletFriendlySelectionService;
import com.ibm.portal.resolver.friendly.service.PortletFriendlySelectionServiceHome;
import com.ibm.portal.um.PumaController;
import com.ibm.portal.um.PumaEnvironment;
import com.ibm.portal.um.PumaHome;
import com.ibm.portal.um.PumaLocator;
import com.ibm.portal.um.PumaProfile;
import com.ibm.portal.um.User;
import com.ibm.portal.um.exceptions.PumaException;
import com.ibm.workplace.wcm.api.Category;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentTypes;
import com.ibs.myspace.communicator.ESBCommunicator;
import com.ibs.myspace.portlet.bean.AuthorizationBean;
import com.ibs.myspace.portlet.bean.Container;
import com.ibs.myspace.portlet.bean.EDeliveryProfileBean;
import com.ibs.myspace.portlet.bean.ESBEDeliveryBean;
import com.ibs.myspace.portlet.bean.ESBEDeliveryResponseBean;
import com.ibs.myspace.portlet.bean.Message;
import com.ibs.myspace.portlet.bean.ProfileParametersContainer;
import com.ibs.myspace.portlet.bean.SelectedActionBean;
import com.ibs.myspace.portlet.bean.SelectedSystemBean;
import com.ibs.myspace.portlet.bean.UserProfileBean;
import com.ibs.myspace.portlet.bean.ValidUICResponse;
import com.ibs.myspace.portlet.dbo.UserProfile;
import com.ibs.myspace.portlet.dbo.UserProfileMyFavorites;
import com.ibs.myspace.portlet.dbo.UserProfilePersonalParameters;
import com.ibs.myspace.portlet.dbo.UserProfileRequest;
import com.ibs.myspace.portlet.dbo.UserProfileRole;
import com.ibs.myspace.portlet.management.AuditLogManagement;
import com.ibs.myspace.portlet.management.AuthorizationsManagement;
import com.ibs.myspace.portlet.management.EDeliveryManagement;
import com.ibs.myspace.portlet.management.MyFavoriteServicesManagement;
import com.ibs.myspace.portlet.management.RegixManagement;
import com.ibs.myspace.portlet.management.UserProfileManagement;
import com.ibs.myspace.portlet.management.UserProfileParametersManagement;
import com.ibs.myspace.portlet.model.Actions;
import com.ibs.myspace.portlet.model.Authorizations;
import com.ibs.myspace.portlet.model.Systems;
import com.ibs.myspace.portlet.utils.EncryptorAESGCM;
import com.ibs.myspace.portlet.utils.Logger;
import com.ibs.myspace.portlet.utils.MySpaceUtils;

public class MySpacePortlet extends GenericPortlet {

	public static final String JSP_FOLDER = "/_MySpacePortlet/jsp/"; // JSP folder name
  
	public static final String INDEX_PAGE = "index";
	public static final String DASHBOARD_SERVICE_SUPPLIER_PAGE = "dashboardSSP";
	public static final String DASHBOARD_LEGAL_ENTITY_PAGE = "dashboardLE";
	public static final String MY_FAVORITE_SERVICES_PAGE = "myFavoriteServices";
	public static final String ADD_FAVORITE_SERVICE_PAGE = "addFavoriteService";
	public static final String LEGAL_ENTITY_REQUEST_PROFILE_PAGE = "legalEntityRequestProfile";
	public static final String EDELIVERY_SYNC_PROFILE_PAGE = "eDeliverySyncProfile";
	public static final String ADD_LEGAL_ENTITY_PAGE_KEY = "addLegalEntityPageKey";
	public static final String AUTHORIZATIONS_PAGE = "authorizations";
	public static final String AUTHORIZATIONS_FOR_ME_SUB_PAGE = "authorizationsForMe";
	public static final String INACTIVE_AUTHORIZATIONS_SUB_PAGE = "inactiveAuthorizations";
	public static final String CANCELED_AUTHORIZATIONS_SUB_PAGE = "canceledAuthorizations";
	public static final String ADD_AUTHORIZATION_PAGE = "addAuthorization";
	public static final String ADD_AUTHORIZATION_PREVIEW_PAGE = "addAuthorizationPreview";
	public static final String ADD_AUTHORIZATION_SIGN_PAGE = "addAuthorizationSign";
	public static final String CANCEL_AUTHORIZATION_PAGE = "cancelAuthorization";
	public static final String AUTHORIZATION_PAGE = "authorization";
	public static final String SERVICES_CATALOG_PAGE = "servicesCatalog";
	public static final String MY_VISITED_SERVICES_PAGE = "myVisitedServices";
	public static final String MESSAGES_PAGE = "messages";	
	public static final String NOTIFICATIONS_PAGE = "notifications";	
	public static final String SERVICES_REQUEST_PAGE = "servicesRequest";
	public static final String RECEIVED_MESSAGES_PAGE = "receivedMessages";
	public static final String SENT_MESSAGES_PAGE = "sentMessages";
	public static final String NEW_MESSAGE_PAGE = "newMessage";
	public static final String INTERNAL_E_SERVICES_PAGE = "internalEServices";
	public static final String IT_SERVICES_PAGE = "itServices";
	public static final String PAYMENTS_PAGE = "payments";
	public static final String CONTENT_MANAGEMENT_PAGE = "contentManagement";
	public static final String REGIX_PAGE = "regix";	
	public static final String TRANSLATE_PAGE = "translate";
	public static final String HR_PAGE = "hr";
	public static final String MY_HEALTH_PAGE = "myHealth";
	public static final String MY_FAMILY_PAGE = "myFamily";
	public static final String MY_PROPERTY_PAGE = "myProperty";
	public static final String MY_CAREER_PAGE = "myCareer";
	public static final String MY_VEHICLE_PAGE = "myVehicle";
	public static final String MY_DOCUMENTS_PAGE = "myDocuments";
	public static final String E_SIGN_PAGE = "eSign";
	public static final String MANAGE_E_FORMS = "manageEForms";
	public static final String AUDIT_LOG_PAGE = "auditLog";
	public static final String PROFILE_PAGE = "profile";
	public static final String PROFILE_LE_PAGE = "profileLE";
	public static final String PROFILE_PARAMETERS_PAGE = "profileParameters";
	public static final String PROFILE_PERSONALIZATION_PAGE = "profilePersonalization";
	public static final String PROFILE_ADD_IDENTIFIER_PAGE = "profileAddIdentifier";
	public static final String DEACTIVATE_PROFILE_PAGE = "deactivateProfile";
	public static final String ACCESS_MANAGEMENT_PAGE = "access";
	public static final String ACCESS_ADD_USER_PAGE = "accessAddUser";	
	public static final String ACCESS_EDIT_USER_PAGE = "accessEditUser";
	public static final String ACCESS_INVITE_USER_AL2_PAGE = "accessInviteUserAL2";

	public static final String CONFIG_JSP = "config"; // JSP file name to be rendered on the configure mode
	public static final String EDIT_DEFAULTS_JSP = "editDefaults"; // JSP file name to be rendered on the configure mode

	public static final String PARAMETER_ACTION = "action";
	public static final String PARAMETER_VALUE = "value";
	public static final String PARAMETER_ID = "id";
	public static final String PARAMETER_INIT = "init";
	public static final String PARAMETER_CANCEL = "cancel";
	public static final String PARAMETER_SUB_PAGE_NAME = "subPageName";
	public static final String PARAMETER_PAGE_UNIQUE_NAME = "pageUniqueName";
	public static final String PARAMETER_SUB_PAGE_UNIQUE_NAME = "subPageUniqueName";
	public static final String PARAMETER_PAGE_FRIENDLY_UR = "pageFriendlyUrl";
	public static final String PARAMETER_PARENT_ID = "parentId";
	public static final String PARAMETER_PARENT_FRIENDLY_URL = "parentFriendlyUrl";
	public static final String PARAMETER_SEARCH_STRING = "searchString";
	public static final String PARAMETER_REGISTER_GROUP_NAME = "registerGroupName";
	
	public static final String FORM_PARAMETER_EIK_NAME = "eik";
	public static final String FORM_PARAMETER_NAME_AND_LEGAL_FORM_NAME = "nameAndLegalForm";
	public static final String FORM_PARAMETER_PROFILE_STRUCTURE_TYPE_NAME = "profileStructureType";
	public static final String FORM_PARAMETER_PROFILE_STRUCTURE_TYPE_OTHER_NAME = "profileStructureTypeOther";
	public static final String FORM_PARAMETER_ORDER_NUMBER_NAME = "orderNumber";
	public static final String FORM_PARAMETER_DOCUMENT_FILE_NAME = "documentFile";
	public static final String FORM_PARAMETER_ORDER_FILE_NAME = "orderFile";	
	public static final String FORM_PARAMETER_SIGNED_FILE_NAME = "signedFile";
	public static final String FORM_PARAMETER_ACCESS_KIND_NAME = "accessKind";
	public static final String FORM_PARAMETER_PERSONAL_IDENTIFIER_NAME = "personalIdentifier";
	public static final String FORM_PARAMETER_EMAIL_NAME = "email";
	public static final String FORM_PARAMETER_USER_NAMES_NAME = "userNames";
	public static final String FORM_PARAMETER_XML_BASE64_SIGNED = "xmlBase64Signed";
	
	public static final String ACTION_CHANGE_PAGE = "changePage";	
	public static final String ACTION_CHANGE_PROFILE = "changeProfile";
	public static final String ACTION_ACTIVATE_PROFILE = "activateProfile";
	public static final String ACTION_CONFIRM_PROFILE = "confirmProfile";
	public static final String ACTION_GET_LE_DATA = "getLegalEntityData";
	public static final String ACTION_GET_AUTHORIZED_USER_DATA = "getAuthorizedUserData";
	public static final String ACTION_GET_SERVICES_CLASSIFICATION = "getServicesClassification";
	public static final String ACTION_GET_SERVICES_FOR_CATALOG = "getServicesForCatalog";
	public static final String ACTION_GET_USER_DATA = "getUserData";	
	public static final String ACTION_GET_EDELIVERY_MESSAGES = "getEDeliveryMessages";	
	public static final String ACTION_SYNC_EDELIVERY_PROFILE = "syncEDeliveryProfile";
	public static final String ACTION_OPEN_PAGE = "openPage";	
	public static final String ACTION_DOWNLOAD_AUTHORIZATION_AUTHORIZED_FILE = "authorizationAuthorizedFile";	
	public static final String ACTION_DOWNLOAD_AUTHORIZATION_CANCEL_FILE = "authorizationCancelFile";
	public static final String ACTION_DOWNLOAD_AUTHORIZATION_AUTHORIZED_FILE_FOR_SIGN = "authorizationAuthorizedFileForSign";
	
	public static final String SESSION_BEAN = "MySpacePortletSessionBean"; // Bean name for the portlet session
	public static final String CONFIG_SUBMIT = "MySpacePortletConfigSubmit"; // Action name for submit form
	public static final String CONFIG_CANCEL = "MySpacePortletConfigCancel"; // Parameter name for the text input
	public static final String EDIT_PROFILE_SUBMIT = "MySpacePortletEditProfileSubmit";
	public static final String EDIT_PROFILE_PERSONALIZATION_SUBMIT = "MySpacePortletEditProfilePersonalSubmit";
	public static final String EDIT_PROFILE_PARAMETERS_SUBMIT = "MySpacePortletEditProfileParametersSubmit";
	public static final String DEACTIVATE_PROFILE_SUBMIT = "MySpacePortletDeactivateProfileSubmit";
	public static final String CREATE_SERVICE_SUPPLIER_REQUEST_PROFILE_SUBMIT = "MySpacePortletCreateSSRequestProfileSubmit";
	public static final String SYNC_PROFILES_FROM_EDELIVERY_SUBMIT = "MySpacePortletSyncProfilesFromEDeliverySubmit";
	public static final String CREATE_LEGAL_ENTITY_REQUEST_PROFILE_SUBMIT = "MySpacePortletCreateLERequestProfileSubmit";
	public static final String ADD_AUTHORIZATION_SUBMIT = "MySpacePortletAddAuthorizationSubmit";
	public static final String ADD_AUTHORIZATION_SIGN_SUBMIT = "MySpacePortletAddAuthorizationSignSubmit";
	public static final String CANCEL_AUTHORIZATION_SUBMIT = "MySpacePortletCancelAuthorizationSubmit";
	public static final String ADD_USER_SUBMIT = "MySpacePortletAddUserSubmit";	
	public static final String EDIT_USER_SUBMIT = "MySpacePortletEditUserSubmit";
	public static final String REMOVE_USER_SUBMIT = "MySpacePortletRemoveUserSubmit";
	public static final String INVITE_USER_AL2_SUBMIT = "MySpacePortletInviteUserAL2Submit";
	public static final String REINVITE_USER_AL2_SUBMIT = "MySpacePortletReInviteUserAL2Submit";
	public static final String RESEND_INVITATION_SUBMIT = "MySpacePortletResendInvitationSubmit";
	public static final String REMOVE_INVITATION_SUBMIT = "MySpacePortletRemoveInvitationSubmit";		
	public static final String EDIT_DEFAULTS_SUBMIT = "MySpacePortletEditDefaultsSubmit";
	public static final String EDIT_DEFAULTS_CANCEL = "MySpacePortletEditDefaultsCancel";
	
	
	
	private MySpaceNotificationsManager notificationManager;

	private static final PortletMode CUSTOM_CONFIG_MODE = new PortletMode("config");
	private static final PortletMode CUSTOM_EDIT_DEFAULTS_MODE = new PortletMode("edit_defaults");
	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.ENGLISH);
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	public static boolean portletInitialized = false;
	

	public void init() throws PortletException {
		super.init();
		InitialContext initialcontext;
		try {
			initialcontext = new InitialContext();
			pumaHome = (PumaHome) initialcontext.lookup("portal:service/usermanagement/Puma");
			navigationSelectionModelHome = (NavigationSelectionModelHome) initialcontext.lookup("portal:service/model/NavigationSelectionModel");
			navigationModelHome = (NavigationModelHome)initialcontext.lookup("portal:service/model/NavigationModel");
			PortletServiceHome portletServiceHome = (PortletServiceHome)initialcontext.lookup(PortletFriendlySelectionServiceHome.JNDI_NAME);			
			if (portletServiceHome != null) {
				portletFriendlySelectionServiceHome = portletServiceHome.getPortletService(PortletFriendlySelectionServiceHome.class);
			}			
		} catch (NamingException namingexception) {
			namingexception.printStackTrace();
		}
		notificationManager = new MySpaceNotificationsManager();
		portletInitialized = true;
	}

	public void doView(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		Logger.log(Logger.DEBUG_LEVEL, "doView() started...");
		// Set the MIME type for the render response
		response.setContentType(request.getResponseContentType());
				
		// Check if portlet session exists.
		MySpacePortletSessionBean sessionBean = getSessionBean(request);
		if (sessionBean == null) {
			response.getWriter().println("<b>NO PORTLET SESSION YET</b>");
			return;
		}
		Logger.log(Logger.DEBUG_LEVEL, "doView() has portlet session...");
		if (sessionBean.getCurrentPage() == null) {
			sessionBean.setCurrentPage(MySpacePortlet.INDEX_PAGE);
		}
		// Listen for external call.
		String action = request.getParameter(PARAMETER_ACTION);
		if (ACTION_OPEN_PAGE.equalsIgnoreCase(action)) {	
			String value = request.getParameter(PARAMETER_VALUE);
			// We catch the call and modify it by the loaded profile type.
			if (sessionBean.getProfile() != null) {
				value = MySpaceUtils.getDashboardPageByProfileType(sessionBean.getProfile().getProfileType());				
			}
			
			Logger.log(Logger.DEBUG_LEVEL, "doView() -> exteranl call registered... action[" + action + "], value[" + value + "]");
			sessionBean.setCurrentPage(value);
		}
		
		Container container = sessionBean.getContainer().get(sessionBean.getCurrentPage());
		if (container == null) {
			Logger.log(Logger.DEBUG_LEVEL, "doView() -> container is NULL ");			
			container = new Container();			
			HashMap<String, Container> containerHm = sessionBean.getContainer();
			containerHm.put(sessionBean.getCurrentPage(), container);			
			sessionBean.setContainer(containerHm);
			Logger.log(Logger.DEBUG_LEVEL, "doView() -> container was initialized with page " + sessionBean.getCurrentPage());
		}

		PortletRequestDispatcher rd = null;
		try {			
			Locale locale = new Locale(language);
			MySpaceViewEngine engine =  new MySpaceViewEngine(); 
			engine.prepareRenderingData(sessionBean, request, response, getPumaHome(), getPortletConfig().getResourceBundle(locale));				
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		String pageName = sessionBean.getRedirectToPage() != null ? sessionBean.getRedirectToPage() : sessionBean.getCurrentPage();
		sessionBean.setRedirectToPage(null);
		
		rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, pageName));
		rd.include(request, response);
	}

	protected void doDispatch(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		Logger.log(Logger.DEBUG_LEVEL, "doView() -> doDispatch()");
		if (!WindowState.MINIMIZED.equals(request.getWindowState())) {
			MySpaceUtils.loadPreferences(request);
			if (getPumaHome() != null) {
				PumaProfile pumaProfile = getPumaHome().getProfile();
				if (pumaProfile != null) {
					try {
						User user = pumaProfile.getCurrentUser();
						if (user != null) {
							MySpacePortletSessionBean sessionBean = getSessionBean(request);
							UserProfileBean userProfileBean = sessionBean.getUserProfile();
							if (userProfileBean == null) {
								Logger.log(Logger.DEBUG_LEVEL, "doView() -> doDispatch initializing userProfileBean...");
								userProfileBean = new UserProfileBean();
								userProfileBean.setCurrentUser(user);
								userProfileBean.setCurrentUserDN(pumaProfile.getIdentifier(user));
								userProfileBean = populateUserAttributesFromLDAP(userProfileBean, getPumaHome(), pumaProfile);	
								sessionBean.setUserProfile(userProfileBean);
							}
						}
					} catch (PumaException e) {
						System.out.println(e.getMessage());
						e.printStackTrace();
					}
				}
			}
			PortletMode mode = request.getPortletMode();
			if (CUSTOM_CONFIG_MODE.equals(mode)) {
				doCustomConfigure(request, response);
				return;
			} else if (CUSTOM_EDIT_DEFAULTS_MODE.equals(mode)) {
				doCustomEditDefaults(request, response);
				return;
			}
		}
		super.doDispatch(request, response);
	}

	public void processAction(ActionRequest request, ActionResponse response) throws PortletException, java.io.IOException {
		MySpacePortletSessionBean sessionBean = getSessionBean(request);
		Logger.log(Logger.DEBUG_LEVEL, "processAction() started...");
		
		// Block all actions, except saving the profile parameters form,
		// until we have all required fields populated for current profile.
		if (sessionBean.isHasNotPopulatedRequiredParameters() && (request.getParameter(EDIT_PROFILE_PARAMETERS_SUBMIT) == null)) {
			return;
		}
		
		String action = request.getParameter(PARAMETER_ACTION);
		String value = request.getParameter(PARAMETER_VALUE);
		String id = request.getParameter(PARAMETER_ID);
		String registerGroupName = request.getParameter(PARAMETER_REGISTER_GROUP_NAME);
		Logger.log(Logger.DEBUG_LEVEL, "processAction() param:action=" + action);
		Logger.log(Logger.DEBUG_LEVEL, "processAction() param:value=" + value);
		Logger.log(Logger.DEBUG_LEVEL, "processAction() param:id=" + id);
		Logger.log(Logger.DEBUG_LEVEL, "processAction() param:registerGroupName=" + registerGroupName);
		Map<String, Container> sessionContainer = sessionBean.getContainer();		
		Container container = sessionContainer.get(sessionBean.getCurrentPage());
		Locale locale = new Locale(language);
		sessionBean.setMessage(null);
		sessionBean.setMessages(null);
		UserProfileBean userProfileBean = sessionBean.getUserProfile();
		MySpaceUtils utils = new MySpaceUtils();
		
		// If container is not initialized or current user is NULL, show message.
		if (container == null || userProfileBean == null || userProfileBean.getCurrentUser() == null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> container is null!");
			// Ignore warning, if we only do navigation.
			if (!ACTION_CHANGE_PAGE.equals(action)) {
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("sesson.timeout.new.was.generated")));
			}
			return;
		}
		
		String remoteIP = "localhost";	
		HttpServletRequest httpServletRequest = null;
		try {
			httpServletRequest = (HttpServletRequest) (com.ibm.ws.portletcontainer.portlet.PortletUtils.getHttpServletRequest(request));
			remoteIP = httpServletRequest.getHeader("X-FORWARDED-FOR");
			if (remoteIP == null) {
				remoteIP = httpServletRequest.getRemoteAddr();
			}				
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (PortletFileUpload.isMultipartContent(request)) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> multipartContent found!");
			multipartContentHandler(request, sessionBean, locale, remoteIP);		
			return;
		}
				
		// SET PARAMETERS TO BE VISIBILE FOR doView()...
		response.setRenderParameters(request.getParameterMap());
		if (ACTION_CHANGE_PAGE.equals(action)) {			
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + action);
			
			// We have register a page key, so check which page to redirect to.
			if (ADD_LEGAL_ENTITY_PAGE_KEY.equalsIgnoreCase(value)) {
				if (!sessionBean.iseDeliveryProfilesLoaded()) {
					// Load profiles from eDelivery.
					EDeliveryManagement eDeliveryManagement = new EDeliveryManagement();
					EDeliveryProfileBean[] eDeliveryProfileBeans = eDeliveryManagement.loadAllProfiles(userProfileBean.getCurrentUserIdentifier());					
					if (eDeliveryProfileBeans != null && eDeliveryProfileBeans.length > 0) {
						sessionBean.seteDeliveryProfileBeans(eDeliveryProfileBeans);
					}
					sessionBean.seteDeliveryProfilesLoaded(true);
				}
				if (sessionBean.geteDeliveryProfileBeans() != null && sessionBean.geteDeliveryProfileBeans().length > 0) {
					value = EDELIVERY_SYNC_PROFILE_PAGE;
				} else {
					value = LEGAL_ENTITY_REQUEST_PROFILE_PAGE;
				}
			} else if (PROFILE_PARAMETERS_PAGE.equalsIgnoreCase(value)) {
				Map<String, ProfileParametersContainer> sessionParametersContainer = sessionBean.getProfileParametersContainer();
				ProfileParametersContainer parametersContainer = sessionParametersContainer.get(sessionBean.getProfile().getProfileType());
				if (parametersContainer == null) {
					parametersContainer = new ProfileParametersContainer();
				}
				if (registerGroupName != null && registerGroupName.trim().length() > 0) {
					parametersContainer.setCurrentRegisterGroupName(registerGroupName);
				} else {
					parametersContainer.setCurrentRegisterGroupName(null);
				}
				sessionParametersContainer.put(sessionBean.getProfile().getProfileType(), parametersContainer);
			}
			
			sessionBean.setCurrentPage(value);
			sessionBean.setCurrentSubPage(request.getParameter(PARAMETER_SUB_PAGE_NAME));			
			
			container = sessionContainer.get(value);
			if (container == null) {
				container = new Container();
			}	
					
			if ("true".equalsIgnoreCase(request.getParameter(PARAMETER_INIT))) {
				container.setInitInitalized(true);
			}
			
			if (AUTHORIZATION_PAGE.equalsIgnoreCase(value) ||
					CANCEL_AUTHORIZATION_PAGE.equalsIgnoreCase(value)) {
				if (id != null && id.trim().length() > 0) {
					try {
						container.setAuthorizationsId(Long.parseLong(id));
						// Init container for "Cancel authorization" too, if it will be needed.
						sessionContainer.put(CANCEL_AUTHORIZATION_PAGE, container);
					} catch (NumberFormatException e) {
						e.printStackTrace();
					}					
				}
			} else { // clear data.
				container.setAuthorizationsId(null);
			}
			
			
			
			sessionContainer.put(sessionBean.getCurrentPage(), container);			
		} else if (ACTION_CHANGE_PROFILE.equals(action)) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + action);
			if (value != null && value.trim().length() > 0) {
				UserProfile[] profiles = sessionBean.getProfiles();
				sessionBean.setProfileRoles(null);
				boolean founded = false;
				if (profiles != null && profiles.length > 0) {
					for (int i = 0; i < profiles.length; i++) {
						if ((MySpaceConstants.USER_PROFILE_STATUS_ACTIVE.equals(profiles[i].getStatus()) || MySpaceConstants.USER_PROFILE_STATUS_NOT_CONFIRMED.equals(profiles[i].getStatus())) 
								&& profiles[i].getId().equalsIgnoreCase(value)) {
							
							if (MySpacePortlet.logEvents) {
								// Register event in the log.
								AuditLogManagement alManagement = new AuditLogManagement();
								String currentProfileName = MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(sessionBean.getProfile().getProfileType()) ? sessionBean.getProfile().getNames() : sessionBean.getProfile().getNameAndLegalForm();
								String newProfileName = MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(profiles[i].getProfileType()) ? profiles[i].getNames() : profiles[i].getNameAndLegalForm();
								alManagement.sendEvent(userProfileBean.getCurrentUserUID(), MySpaceConstants.EVENT_LOG_PORTAL_SWITCH_PROFILE, "Текущият профил \"" + currentProfileName + "\" беше сменен с \"" + newProfileName + "\"", null, remoteIP, false);
							}
							
							sessionBean.setProfile(profiles[i]);
							founded = true;
							sessionBean.setCurrentPage(MySpaceUtils.getDashboardPageByProfileType(profiles[i].getProfileType()));
							// load extra data.
							UserProfileManagement management = new UserProfileManagement();
							UserProfilePersonalParameters personalParameters = management.loadPersonalParametersByProfileId(profiles[i].getId());
							sessionBean.setPersonalParameters(personalParameters);
							// Load roles.
							//if (MySpaceConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER.equals(profiles[i].getProfileType())) {
								sessionBean.setProfileRoles(management.loadRolesByProfileIdAndUserUID(profiles[i].getId(), userProfileBean.getCurrentUserUID()));
							//}
							break;
						}
					}
					Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> prepareRenderingData() total loaded profiles [" + profiles.length + "] founded: " + founded);
				}
				if (!founded) {
					// Search for profile's participation.
					UserProfile[] profileParticipations = sessionBean.getProfilesParticipation();
					if (profileParticipations != null && profileParticipations.length > 0) {
						for (int i = 0; i < profileParticipations.length; i++) {
							if (MySpaceConstants.USER_PROFILE_STATUS_ACTIVE.equals(profileParticipations[i].getStatus()) 
									&& profileParticipations[i].getId().equalsIgnoreCase(value)) {
								sessionBean.setProfile(profileParticipations[i]);
								founded = true;
								sessionBean.setCurrentPage(MySpaceUtils.getDashboardPageByProfileType(profileParticipations[i].getProfileType()));								
								UserProfileManagement management = new UserProfileManagement();
								// load roles.
								//if (MySpaceConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER.equals(profileParticipations[i].getProfileType())) {
									sessionBean.setProfileRoles(management.loadRolesByProfileIdAndUserUID(profileParticipations[i].getId(), userProfileBean.getCurrentUserUID()));
								//}
								break;
							}
						}
						Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> prepareRenderingData() total loaded profileParticipations [" + profileParticipations.length + "]");
					}
				}
				if (founded) {					
					// Update LDAP.
					MySpaceActiveProfileManager activeProfileManager = new MySpaceActiveProfileManager();
					activeProfileManager.registerProfileInLdap(userProfileBean, sessionBean.getProfile());
					
					// Load unRead messages count in current session.	
					ESBCommunicator esbCommunicator = new ESBCommunicator();
					sessionBean.setUnReadReceivedMessagesCount(esbCommunicator.getUnReadReceivedMessagesCounter(sessionBean));									

				}
			}
		} else if (ACTION_ACTIVATE_PROFILE.equals(action)) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + ACTION_ACTIVATE_PROFILE);
			try {
				UserProfileManagement management = new UserProfileManagement();
				management.activateProfile(sessionBean, value, this, remoteIP, getPortletConfig().getResourceBundle(locale));				
			} catch (Exception e) {
				Logger.log(Logger.ERROR_LEVEL, "processAction() -> error:" + e.getMessage());
				e.printStackTrace();
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("profile.activation.error")));
			}
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);	
		} else if (ACTION_CONFIRM_PROFILE.equals(action)) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + ACTION_CONFIRM_PROFILE);
			try {
				UserProfileManagement management = new UserProfileManagement();
				management.confirmProfile(sessionBean, this, remoteIP, getPortletConfig().getResourceBundle(locale));
				List<Message> messages = sessionBean.getMessages();
				if (messages == null) {
					messages = new ArrayList<>();
				}
				messages.add(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("profile.activated")));				
				sessionBean.setMessages(messages);
			} catch (Exception e) {
				Logger.log(Logger.ERROR_LEVEL, "processAction() -> error:" + e.getMessage());
				e.printStackTrace();
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("profile.confirm.error")));
			}
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);	
		} else if (request.getParameter(EDIT_PROFILE_SUBMIT) != null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + EDIT_PROFILE_SUBMIT);
			try {
				UserProfileManagement management = new UserProfileManagement();
				management.saveProfile(sessionBean, userProfileBean, request, remoteIP, getPortletConfig().getResourceBundle(locale));
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("profile.saved")));				
			} catch (Exception e) {
				Logger.log(Logger.ERROR_LEVEL, "processAction() -> error:" + e.getMessage());
				e.printStackTrace();
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("profile.save.error")));
			}
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);	
		} else if (request.getParameter(EDIT_PROFILE_PERSONALIZATION_SUBMIT) != null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + EDIT_PROFILE_PERSONALIZATION_SUBMIT);
			try {
				UserProfileManagement management = new UserProfileManagement();
				management.saveProfilePersonalization(sessionBean, userProfileBean, request, httpServletRequest, remoteIP, getPortletConfig().getResourceBundle(locale));
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("profile.saved")));				
			} catch (Exception e) {
				Logger.log(Logger.ERROR_LEVEL, "processAction() -> error:" + e.getMessage());
				e.printStackTrace();
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("profile.save.error")));
			}
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);	
		} else if (request.getParameter(EDIT_PROFILE_PARAMETERS_SUBMIT) != null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + EDIT_PROFILE_PARAMETERS_SUBMIT);
			// Check for multiple sessions on same browser.
			String profileId = request.getParameter("profileId");
			String pageName = request.getParameter("pageName");
			if (sessionBean.getProfile() == null || !sessionBean.getProfile().getId().equalsIgnoreCase(profileId) || !sessionBean.getCurrentPage().equalsIgnoreCase(PROFILE_PARAMETERS_PAGE)) {				
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("current.session.changed")));
				return;
			}
			ProfileParametersContainer parametersContainer = sessionBean.getProfileParametersContainer().get(sessionBean.getProfile().getProfileType());
			String currentRegisterGroupName = parametersContainer.getCurrentRegisterGroupName();
			if (currentRegisterGroupName == null || !currentRegisterGroupName.equalsIgnoreCase(pageName)) {
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("current.session.changed")));
				return;
			}
			try {
				UserProfileParametersManagement management = new UserProfileParametersManagement();
				String groupLabel = management.saveProfileParameters(sessionBean, userProfileBean, request, httpServletRequest, remoteIP, getPortletConfig().getResourceBundle(locale));
				List<Message> messages = sessionBean.getMessages();
				messages.add(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, MessageFormat.format(getPortletConfig().getResourceBundle(locale).getString("profile.parameters.saved"), groupLabel)));
				sessionBean.setMessages(messages);
				// Check if we have not populated fields, that we are ok.
				if (sessionBean.isHasNotPopulatedRequiredParameters()) {
					if (!management.checkForNotPopulatedRequiredFields(sessionBean, getPortletConfig().getResourceBundle(locale))) {						
						sessionBean.setCurrentPage(MySpaceUtils.getDashboardPageByProfileType(sessionBean.getProfile().getProfileType()));
						sessionBean.setMessages(null);
						String msgText = getPortletConfig().getResourceBundle(locale).getString("profile.parameters.save.thank.you"); 
						msgText += "<div style=\"padding-top:10px;\">" + MessageFormat.format(getPortletConfig().getResourceBundle(locale).getString("profile.parameters.saved"), groupLabel) + "</div>";
						if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equalsIgnoreCase(sessionBean.getProfile().getProfileType())) {
							msgText += "<div style=\"padding-top:10px;\">" + getPortletConfig().getResourceBundle(locale).getString("profile.parameters.save.my.space") + "</div>";
						} else {
							msgText += "<div style=\"padding-top:10px;\">" + getPortletConfig().getResourceBundle(locale).getString("profile.parameters.save.my.space.le") + "</div>";
						}
						Message message = new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, msgText);
						message.setHtml(true);
						sessionBean.setMessage(message);
					}
				}
			} catch (Exception e) {
				Logger.log(Logger.ERROR_LEVEL, "processAction() -> error:" + e.getMessage());
				e.printStackTrace();
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("profile.save.error")));
			}
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);	
		} else if (request.getParameter(DEACTIVATE_PROFILE_SUBMIT) != null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + DEACTIVATE_PROFILE_SUBMIT);
			try {
				UserProfileManagement management = new UserProfileManagement();
				management.deactivateProfile(sessionBean, request.getParameter("deactivationReason"), this, remoteIP, getPortletConfig().getResourceBundle(locale));									
			} catch (Exception e) {
				Logger.log(Logger.ERROR_LEVEL, "processAction() -> error:" + e.getMessage());
				e.printStackTrace();
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("profile.deactivation.error")));
			}
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);
//		} else if (request.getParameter(CREATE_LEGAL_ENTITY_REQUEST_PROFILE_SUBMIT) != null) {
//			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + CREATE_LEGAL_ENTITY_REQUEST_PROFILE_SUBMIT);
//			String eik = request.getParameter("eik");
//			String nameAndLegalForm = request.getParameter("name");
//			if (eik != null && eik.trim().length() > 0 && nameAndLegalForm != null && nameAndLegalForm.trim().length() > 0) {
//				UserProfileManagement management = new UserProfileManagement();
//				try {
//					// Check we have already request for this EIK.
//					UserProfileRequest userProfileRequest = management.loadNotApprovedUserProfileRequestByUserProfileIdAndEIK(sessionBean.getProfile().getId(), eik);
//					if (userProfileRequest == null) {
//						// Check user is already associated with profile with the given EIK.
//						UserProfileRole[] roles = management.loadAllProfileRolesAndProfilesByUserUID(sessionBean.getUserProfile().getCurrentUserUID());
//						boolean hasBeenAssigned = false;
//						if (roles != null && roles.length > 0) {
//							UserProfile tmpUP = null;
//							for (int i = 0; i < roles.length; i++) {
//								tmpUP = roles[i].getUserProfile();
//								if (tmpUP != null && eik.equalsIgnoreCase(tmpUP.getEik())) {
//									hasBeenAssigned = true;
//									break;
//								}
//							}
//						}
//						if (!hasBeenAssigned) {
//							String[] result = management.createLegalEntityProfileRequest(sessionBean, eik, nameAndLegalForm, remoteIP, getPortletConfig().getResourceBundle(locale));
//							sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("profile.request.was.sent")));
//							sessionBean.setCurrentPage(INDEX_PAGE);
//							Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + CREATE_LEGAL_ENTITY_REQUEST_PROFILE_SUBMIT + ": MySpacePortlet.sendEmail=" + MySpacePortlet.sendEmail);
//							Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + CREATE_LEGAL_ENTITY_REQUEST_PROFILE_SUBMIT + ": MySpacePortlet.fromAddress=" + MySpacePortlet.fromAddress);
//							Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + CREATE_LEGAL_ENTITY_REQUEST_PROFILE_SUBMIT + ": MySpacePortlet.toAddress=" + MySpacePortlet.toAddress);
//							
//							/*
//							 * Notifications.
//							 */
//							// Send email to DAEU approver(s).							
//							if (MySpacePortlet.sendEmail) {								
//								Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + CREATE_LEGAL_ENTITY_REQUEST_PROFILE_SUBMIT + ": sending mail...");
//								try {
//									notificationManager.notifyDAEUForCreatedRequestForLEProfile(result, getPortletConfig().getResourceBundle(locale));
//								} catch (Exception e) {
//									e.printStackTrace();
//								}
//							} 
//							// Send email to the user, that the request for adding new LE was registered.
//							try {
//								notificationManager.notifyUserForCreatedRequestForLEProfile(result, sessionBean.getProfile(), getPortletConfig().getResourceBundle(locale));
//							} catch (Exception e) {
//								e.printStackTrace();
//							}	
//						} else {
//							sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("profile.request.already.assigned.to.profile")));
//						}
//					} else {
//						sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("profile.request.duplicate.founded")));
//					}
//				} catch (Exception e) {
//					e.printStackTrace();
//					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("profile.request.error")));
//				}
//				
//			} else {
//				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("invalid.parameters")));
//			}
//			response.setPortletMode(PortletMode.VIEW);
//			response.setWindowState(WindowState.NORMAL);
		} else if (request.getParameter(SYNC_PROFILES_FROM_EDELIVERY_SUBMIT) != null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + SYNC_PROFILES_FROM_EDELIVERY_SUBMIT);
			UserProfileManagement management = new UserProfileManagement();
			if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(sessionBean.getProfile().getProfileType())) {
				try {
					ArrayList<String[]> requestResults = management.syncEDeliveryProfiles(sessionBean, null, remoteIP, getPortletConfig().getResourceBundle(locale));
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("profile.sync.success")));
					sessionBean.setCurrentPage(INDEX_PAGE);
					Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + SYNC_PROFILES_FROM_EDELIVERY_SUBMIT + ": MySpacePortlet.sendEmail=" + MySpacePortlet.sendEmail);
					Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + SYNC_PROFILES_FROM_EDELIVERY_SUBMIT + ": MySpacePortlet.fromAddress=" + MySpacePortlet.fromAddress);
					Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + SYNC_PROFILES_FROM_EDELIVERY_SUBMIT + ": MySpacePortlet.toAddress=" + MySpacePortlet.toAddress);
					//boolean hasRequest = false;
					// Send email to approver(s).			
					if (requestResults != null && requestResults.size() > 0 && MySpacePortlet.sendEmail) {
						Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + SYNC_PROFILES_FROM_EDELIVERY_SUBMIT + ": sending mail...");
						String[] result = null;
						for (int i = 0; i < requestResults.size(); i++) {
							result = requestResults.get(i);
							if (result.length > 5) { // Notify only new request(s). The length should be 6.
								//hasRequest = true;
								// Send email to DAEU approver(s).
								if (MySpacePortlet.sendEmail) {
									try {
										notificationManager.notifyDAEUForCreatedRequestForLEProfile(result, getPortletConfig().getResourceBundle(locale));
									} catch (Exception e) {
										e.printStackTrace();
									}
								}
								// Send email to the user, that the request for adding new LE was registered.
								try {
									notificationManager.notifyUserForCreatedRequestForLEProfile(result, sessionBean.getProfile(), getPortletConfig().getResourceBundle(locale));
								} catch (Exception e) {
									e.printStackTrace();
								}	
							}
						}
					}
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("profile.sync.with.request.success")));
				} catch (Exception e) {
					e.printStackTrace();
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("system.error")));
				}
			} else {
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("profile.should.be.personal")));
			}
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);
		}
		if (request.getParameter(ADD_USER_SUBMIT) != null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + ADD_USER_SUBMIT);
			try {
				String personalIdentifier = request.getParameter("personalIdentifier");
				boolean roleAdmin = "1".equals(request.getParameter("admin"));
				boolean roleServices = "1".equals(request.getParameter("services"));
				boolean roleEditor = "1".equals(request.getParameter("editor"));										
				boolean roleUser = "1".equals(request.getParameter("user"));										
				//User user = getUserByUID(uid);
				EncryptorAESGCM aesCls = new EncryptorAESGCM();
				String encryptedPersonalIdentifier = aesCls.encryptEgovIdentifier(personalIdentifier);
				User user = getUserByPersonalIdentifier(encryptedPersonalIdentifier);				
//				User user = getUserByPersonalIdentifier(personalIdentifier);				
				if (MySpaceConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER.equals(sessionBean.getProfile().getProfileType()) && user != null && (roleAdmin || roleEditor || roleServices)) {
					UserProfileManagement management = new UserProfileManagement();
					String uid = (String)getUserAttribute(user, MySpaceConstants.LDAP_ATTRIBUTE_UID);
					if (uid != null) {
						management.addUser(sessionBean, userProfileBean, request, uid, personalIdentifier, user, remoteIP, getPortletConfig().getResourceBundle(locale));
						sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("add.user.with.personal.identifier") +  " " + personalIdentifier + " " + getPortletConfig().getResourceBundle(locale).getString("add.user.was.added.successfully")));
						sessionBean.setCurrentPage(ACCESS_MANAGEMENT_PAGE);
					} else {
						sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("add.user.error")));
					}
				} else if (MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY_AL2.equals(sessionBean.getProfile().getProfileType()) && user != null && (roleAdmin || roleEditor || roleUser)) {
					UserProfileManagement management = new UserProfileManagement();
					String uid = (String)getUserAttribute(user, MySpaceConstants.LDAP_ATTRIBUTE_UID);
					if (uid != null) {
						management.addUser(sessionBean, userProfileBean, request, uid, personalIdentifier, user, remoteIP, getPortletConfig().getResourceBundle(locale));
						sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("add.user.with.personal.identifier") +  " " + personalIdentifier + " " + getPortletConfig().getResourceBundle(locale).getString("add.user.was.added.successfully")));
						sessionBean.setCurrentPage(ACCESS_MANAGEMENT_PAGE);
					} else {
						sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("add.user.error")));
					}
				} else if (MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY.equals(sessionBean.getProfile().getProfileType()) && user != null && (roleAdmin || roleUser)) {
					UserProfileManagement management = new UserProfileManagement();
					String uid = (String)getUserAttribute(user, MySpaceConstants.LDAP_ATTRIBUTE_UID);
					if (uid != null) {
						management.addUser(sessionBean, userProfileBean, request, uid, personalIdentifier, user, remoteIP, getPortletConfig().getResourceBundle(locale));
						sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("add.user.with.personal.identifier") +  " " + personalIdentifier + " " + getPortletConfig().getResourceBundle(locale).getString("add.user.was.added.successfully")));
						sessionBean.setCurrentPage(ACCESS_MANAGEMENT_PAGE);
					} else {
						sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("add.user.error")));
					}
				} else {
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("add.user.error")));
				}
			} catch (Exception e) {
				Logger.log(Logger.ERROR_LEVEL, "processAction() -> error:" + e.getMessage());
				e.printStackTrace();
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
			}
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);
		} else if (request.getParameter(INVITE_USER_AL2_SUBMIT) != null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + INVITE_USER_AL2_SUBMIT);
			String profileIdType = request.getParameter("profileIdType");
			String personalIdentifier = request.getParameter("personalIdentifier");
			String firstName = request.getParameter("firstName");
			String lastName = request.getParameter("lastName");
			String email = request.getParameter("email");		
			try {														
				if (profileIdType != null && profileIdType.trim().length() > 0 && 
						personalIdentifier != null && personalIdentifier.trim().length() > 0 &&
						firstName != null && firstName.trim().length() > 0 &&
						lastName != null && lastName.trim().length() > 0 &&
						email != null && email.trim().length() > 0) {										
					UserProfileManagement management = new UserProfileManagement(); 
					management.addInvitation(sessionBean, userProfileBean, request, profileIdType, personalIdentifier, firstName, lastName, email, remoteIP, getPortletConfig().getResourceBundle(locale));
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("invitation.for") +  " " + firstName + " " + lastName + " " + getPortletConfig().getResourceBundle(locale).getString("was.sent.successfully")));
					sessionBean.setCurrentPage(ACCESS_MANAGEMENT_PAGE);
					response.setPortletMode(PortletMode.VIEW);
					response.setWindowState(WindowState.NORMAL);
				} else {
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("invalid.parameters")));
				}
			} catch (Exception e) {
				Logger.log(Logger.ERROR_LEVEL, "processAction() -> error:" + e.getMessage());
				e.printStackTrace();
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
			}
		} else if (request.getParameter(REINVITE_USER_AL2_SUBMIT) != null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + REINVITE_USER_AL2_SUBMIT);
			try {
				String userProfileInvitationId = request.getParameter("id");
				String userNames = request.getParameter("names");
				if (MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY_AL2.equals(sessionBean.getProfile().getProfileType())) {
					UserProfileManagement management = new UserProfileManagement();
					management.resendInvitation(sessionBean, userProfileBean, request, userProfileInvitationId, this, remoteIP, getPortletConfig().getResourceBundle(locale));
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("invitation.for") +  " " + userNames + " " + getPortletConfig().getResourceBundle(locale).getString("invitation.was.removed.successfully")));					
					response.setPortletMode(PortletMode.VIEW);
					response.setWindowState(WindowState.NORMAL);
				} else {
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("remove.invitation.error")));
				}
			} catch (Exception e) {
				Logger.log(Logger.ERROR_LEVEL, "processAction() -> error:" + e.getMessage());
				e.printStackTrace();
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
			}

		} else if (request.getParameter(EDIT_USER_SUBMIT) != null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + EDIT_USER_SUBMIT);
			try {
				String userProfileRoleId = request.getParameter("id");
				String personalIdentifier = request.getParameter("personalIdentifier");
				String userNames = request.getParameter("names");
				boolean roleAdmin = "1".equals(request.getParameter("admin"));
				boolean roleServices = "1".equals(request.getParameter("services"));
				boolean roleEditor = "1".equals(request.getParameter("editor"));
				boolean roleUser = "1".equals(request.getParameter("user"));
				if (MySpaceConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER.equals(sessionBean.getProfile().getProfileType()) && (roleAdmin || roleEditor || roleServices)) {
					UserProfileManagement management = new UserProfileManagement();
					management.editUser(sessionBean, userProfileBean, request, userProfileRoleId, personalIdentifier, this, remoteIP, getPortletConfig().getResourceBundle(locale));
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("user") +  " " + userNames + " " + getPortletConfig().getResourceBundle(locale).getString("was.edited.successfully")));
					sessionBean.setCurrentPage(ACCESS_MANAGEMENT_PAGE);
					response.setPortletMode(PortletMode.VIEW);
					response.setWindowState(WindowState.NORMAL);
				} else if (MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY_AL2.equals(sessionBean.getProfile().getProfileType()) && (roleAdmin || roleEditor || roleUser)) {
					UserProfileManagement management = new UserProfileManagement();
					management.editUser(sessionBean, userProfileBean, request, userProfileRoleId, personalIdentifier, this, remoteIP, getPortletConfig().getResourceBundle(locale));
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("user") +  " " + userNames + " " + getPortletConfig().getResourceBundle(locale).getString("was.edited.successfully")));
					sessionBean.setCurrentPage(ACCESS_MANAGEMENT_PAGE);
					response.setPortletMode(PortletMode.VIEW);
					response.setWindowState(WindowState.NORMAL);
				} else if (MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY.equals(sessionBean.getProfile().getProfileType()) && (roleAdmin || roleUser)) {
					UserProfileManagement management = new UserProfileManagement();
					management.editUser(sessionBean, userProfileBean, request, userProfileRoleId, personalIdentifier, this, remoteIP, getPortletConfig().getResourceBundle(locale));
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("user") +  " " + userNames + " " + getPortletConfig().getResourceBundle(locale).getString("was.edited.successfully")));
					sessionBean.setCurrentPage(ACCESS_MANAGEMENT_PAGE);
					response.setPortletMode(PortletMode.VIEW);
					response.setWindowState(WindowState.NORMAL);
				} else {
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("edit.user.error")));
				}
			} catch (Exception e) {
				Logger.log(Logger.ERROR_LEVEL, "processAction() -> error:" + e.getMessage());
				e.printStackTrace();
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("edit.user.error")));
			}
		} else if (request.getParameter(REMOVE_USER_SUBMIT) != null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + REMOVE_USER_SUBMIT);
			try {
				String userProfileRoleId = request.getParameter("id");
				String userNames = request.getParameter("names");
				if (!MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(sessionBean.getProfile().getProfileType())) {
					UserProfileManagement management = new UserProfileManagement();
					management.removeUser(sessionBean, userProfileBean, request, userProfileRoleId, this, remoteIP, getPortletConfig().getResourceBundle(locale));
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("user") +  " " + userNames + " " + getPortletConfig().getResourceBundle(locale).getString("was.removed.successfully")));					
					response.setPortletMode(PortletMode.VIEW);
					response.setWindowState(WindowState.NORMAL);
				} else {
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("remove.user.error")));
				}
			} catch (Exception e) {
				Logger.log(Logger.ERROR_LEVEL, "processAction() -> error:" + e.getMessage());
				e.printStackTrace();
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("remove.user.error")));
			}
		} else if (request.getParameter(RESEND_INVITATION_SUBMIT) != null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + RESEND_INVITATION_SUBMIT);
			try {
				String userProfileInvitationId = request.getParameter("id");
				String userNames = request.getParameter("names");
				if (MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY_AL2.equals(sessionBean.getProfile().getProfileType())) {
					UserProfileManagement management = new UserProfileManagement();
					management.resendInvitation(sessionBean, userProfileBean, request, userProfileInvitationId, this, remoteIP, getPortletConfig().getResourceBundle(locale));
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("invitation.for") +  " " + userNames + " " + getPortletConfig().getResourceBundle(locale).getString("invitation.was.resent.successfully")));					
					response.setPortletMode(PortletMode.VIEW);
					response.setWindowState(WindowState.NORMAL);
				} else {
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("resend.invitation.error")));
				}
			} catch (Exception e) {
				Logger.log(Logger.ERROR_LEVEL, "processAction() -> error:" + e.getMessage());
				e.printStackTrace();
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
			}
		} else if (request.getParameter(REMOVE_INVITATION_SUBMIT) != null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + REMOVE_INVITATION_SUBMIT);
			try {
				String userProfileInvitationId = request.getParameter("id");
				String userNames = request.getParameter("names");
				if (MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY_AL2.equals(sessionBean.getProfile().getProfileType())) {
					UserProfileManagement management = new UserProfileManagement();
					management.removeInvitation(sessionBean, userProfileBean, request, userProfileInvitationId, this, remoteIP, getPortletConfig().getResourceBundle(locale));
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("invitation.for") +  " " + userNames + " " + getPortletConfig().getResourceBundle(locale).getString("invitation.was.removed.successfully")));					
					response.setPortletMode(PortletMode.VIEW);
					response.setWindowState(WindowState.NORMAL);
				} else {
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("remove.invitation.error")));
				}
			} catch (Exception e) {
				Logger.log(Logger.ERROR_LEVEL, "processAction() -> error:" + e.getMessage());
				e.printStackTrace();
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
			}
		} else if (request.getParameter(ADD_AUTHORIZATION_SIGN_SUBMIT) != null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + ADD_AUTHORIZATION_SIGN_SUBMIT);			
			try {
				String xmlSigned64Based = request.getParameter(MySpacePortlet.FORM_PARAMETER_XML_BASE64_SIGNED);
				if (xmlSigned64Based != null && xmlSigned64Based.trim().length() > 0) {
					AuthorizationBean aBean = container.getAuthorizationBean();
					if (aBean != null && aBean.getActionIds() != null && aBean.getActionIds().trim().length() > 0) {
						AuthorizationsManagement management = new AuthorizationsManagement();
						byte[] pureXmlSignedString = Base64.getDecoder().decode(xmlSigned64Based);
						InputStream inputStream = new ByteArrayInputStream(pureXmlSignedString);
						int authorizationsId = management.createAuthorization(sessionBean, inputStream, aBean.getXmlBase64FileName(), MySpaceConstants.XML_FILE_CONTENT_TYPE, pureXmlSignedString.length, remoteIP, getPortletConfig().getResourceBundle(locale));
						if (authorizationsId > 0) {
							List<Message> messages = sessionBean.getMessages();
							messages.add(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("authorization.created.successfully")));
							sessionBean.setMessages(messages);
							sessionBean.setCurrentPage(AUTHORIZATIONS_PAGE);
							clearAuthorizationBeanData(sessionBean);
							try {if (inputStream != null) inputStream.close();} catch (Exception e) {e.printStackTrace();}
							response.setPortletMode(PortletMode.VIEW);
							response.setWindowState(WindowState.NORMAL);
						} else {
							sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("authorization.creation.error")));
						}
					} else {
						sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("current.session.changed")));
					}
				} else {
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("invalid.parameters")));
				}
			} catch (Exception e) {
				Logger.log(Logger.ERROR_LEVEL, "processAction() -> error:" + e.getMessage());
				e.printStackTrace();
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("authorization.creation.error")));
			}
		} else if (request.getParameter(CANCEL_AUTHORIZATION_SUBMIT) != null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + CANCEL_AUTHORIZATION_SUBMIT);			
			try {
				String xmlSigned64Based = request.getParameter(MySpacePortlet.FORM_PARAMETER_XML_BASE64_SIGNED);
				if (xmlSigned64Based != null && xmlSigned64Based.trim().length() > 0) {
					AuthorizationBean aBean = container.getAuthorizationBean();
					if (aBean != null) {
						AuthorizationsManagement management = new AuthorizationsManagement();
						byte[] pureXmlSignedString = Base64.getDecoder().decode(xmlSigned64Based);
						InputStream inputStream = new ByteArrayInputStream(pureXmlSignedString);
						int authorizationsId = management.cancelAuthorization(sessionBean, inputStream, aBean.getXmlBase64FileName(), MySpaceConstants.XML_FILE_CONTENT_TYPE, pureXmlSignedString.length, remoteIP, getPortletConfig().getResourceBundle(locale));
						if (authorizationsId > 0) {
							List<Message> messages = sessionBean.getMessages();
							messages.add(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("authorization.cancel.successfully")));
							sessionBean.setMessages(messages);
							sessionBean.setCurrentPage(AUTHORIZATIONS_PAGE);
							clearAuthorizationBeanData(sessionBean);
							try {if (inputStream != null) inputStream.close();} catch (Exception e) {e.printStackTrace();}
							response.setPortletMode(PortletMode.VIEW);
							response.setWindowState(WindowState.NORMAL);
						} else {
							sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("authorization.cancel.error")));
						}
					} else {
						sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("current.session.changed")));
					}
				} else {
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("invalid.parameters")));
				}
			} catch (Exception e) {
				Logger.log(Logger.ERROR_LEVEL, "processAction() -> error:" + e.getMessage());
				e.printStackTrace();
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("authorization.creation.error")));
			}
		} else if (request.getParameter(ADD_AUTHORIZATION_SUBMIT) != null) {
			Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + ADD_AUTHORIZATION_SUBMIT);
			try {
				String authorizedIdentifier = request.getParameter("authorizedIdentifier");
				String actionsIds = request.getParameter("actionsIds");
				String validFromDate = request.getParameter("validFromDate");
				String validFromTime = request.getParameter("validFromTime");
				String validToDate = request.getParameter("validToDate");
				String validToTime = request.getParameter("validToTime");
				AuthorizationBean bean = container.getAuthorizationBean();
				if (bean != null) {
					Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + bean.getAuthorizedIdentifier());
					Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + actionsIds);
				}
				// Check for healthy session data.
				if (bean.getAuthorizedIdentifier() != null && bean.getAuthorizedIdentifier().equalsIgnoreCase(authorizedIdentifier)) {
					Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + ADD_AUTHORIZATION_SUBMIT + " has bean data");
					// Populate with data from request, if error occurs we will restore the form from the bean.
					bean.setActionIds(actionsIds);
					bean.setValidFromDate(validFromDate);
					bean.setValidFromTime(validFromTime);
					bean.setValidToDate(validToDate);
					bean.setValidToTime(validToTime);
					container.setAuthorizationBean(bean);
					sessionContainer.put(sessionBean.getCurrentPage(), container);
					
					if (actionsIds != null && actionsIds.trim().length() > 0 
							&& validFromDate != null && validFromDate.trim().length() > 0
							&& validToDate != null && validToDate.trim().length() > 0) {
						// Check dates are correctly formatted.
						if (utils.isValidDate(validFromDate, MySpaceConstants.AUTHORIZATION_DATE_FORMAT) 
								&& utils.isValidDate(validToDate, MySpaceConstants.AUTHORIZATION_DATE_FORMAT)) {
							if (!utils.isValidTime(validFromTime)) {
								validFromTime = null;
							}
							if (!utils.isValidTime(validToTime)) {
								validToTime = null;
							}
							if (utils.compareDates(validFromDate, validToDate, validFromTime, validToTime, MySpaceConstants.AUTHORIZATION_DATE_FORMAT)) {
								AuthorizationsManagement management = new AuthorizationsManagement();
								
								// Check for duplicate authorization.
								if (!management.hasDuplicateAuthorization(sessionBean, bean)) {
								
									bean.setActionIds(actionsIds);
									bean.setValidFromDate(validFromDate);
									bean.setValidFromTime(validFromTime);
									bean.setValidToDate(validToDate);
									bean.setValidToTime(validToTime);		
									
									Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + ADD_AUTHORIZATION_SUBMIT + ":actionsIds=" + actionsIds);
									Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + ADD_AUTHORIZATION_SUBMIT + ":validFromDate=" + validFromDate);
									Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + ADD_AUTHORIZATION_SUBMIT + ":validFromTime=" + validFromTime);
									Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + ADD_AUTHORIZATION_SUBMIT + ":validToDate=" + validToDate);
									Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + ADD_AUTHORIZATION_SUBMIT + ":validToTime=" + validToTime);
									
									List<Long> actionsIdsList = null;
									try {
										String[] ids = bean.getActionIds().split(",");
										if (ids != null && ids.length > 0) {
											actionsIdsList = new ArrayList<Long>();
											for (int i = 0; i < ids.length; i++) {
												actionsIdsList.add(Long.parseLong(ids[i]));
											}							
										}
									} catch (Exception e) {
										e.printStackTrace();
									}
									List<Actions> actions = management.getAllActionsByIds(actionsIdsList);
									if (actions != null && actions.size() > 0) {
										List<Long> systemsIds = new ArrayList<Long>();
										for (int i = 0; i < actions.size(); i++) {
											if (!systemsIds.contains(actions.get(i).getSystemsId())) {
												systemsIds.add(actions.get(i).getSystemsId());
											}
										}
										if (systemsIds.size() > 0) {
											List<Systems> systems = management.getAllSystemsByIds(systemsIds);
											if (systems != null && systems.size() > 0) {
												List<SelectedSystemBean> loadedSystemBeans = new ArrayList<>();
												SelectedSystemBean loadedSystemBean = null;
												SelectedActionBean loadedActionBean = null;
												List<SelectedActionBean> loadedActionsBean = null;
												for (int i = 0; i < systems.size(); i++) {
													loadedSystemBean = new SelectedSystemBean();
													loadedSystemBean.setSystemsId(systems.get(i).getSystemsId());
													loadedSystemBean.setTitle(systems.get(i).getTitle());
													loadedSystemBean.setOid(systems.get(i).getOid());
													loadedActionsBean = new ArrayList<SelectedActionBean>();
													for (int j = 0; j < actions.size(); j++) {
														if (systems.get(i).getSystemsId() == actions.get(j).getSystemsId()) {
															loadedActionBean = new SelectedActionBean();
															loadedActionBean.setActionsId(actions.get(j).getActionsId());
															loadedActionBean.setDescription(actions.get(j).getDescription());
															loadedActionBean.setCode(actions.get(j).getCode());
															loadedActionsBean.add(loadedActionBean);
														}										
													}
													loadedSystemBean.setActions(loadedActionsBean);
													loadedSystemBeans.add(loadedSystemBean);									
												}
												bean.setLoadedSystemBeans(loadedSystemBeans);
											}							
										}
									}
									
									container.setAuthorizationBean(bean);
									sessionContainer.put(sessionBean.getCurrentPage(), container);
									sessionContainer.put(ADD_AUTHORIZATION_PREVIEW_PAGE, container);
									sessionContainer.put(ADD_AUTHORIZATION_SIGN_PAGE, container);
									// Redirect to "Preview" page.
									sessionBean.setCurrentPage(ADD_AUTHORIZATION_PREVIEW_PAGE);			
								} else {
									sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("authorization.interval.overlap.found")));
								}
							} else {
								sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("invalid.dates.interval")));
							}
						} else {
							sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("invalid.date")));
						}												
					} else {
						sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("invalid.parameters")));
					}
				} else {
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("duplicate.session")));
				}
			} catch (Exception e) {
				Logger.log(Logger.ERROR_LEVEL, "processAction() -> error:" + e.getMessage());
				e.printStackTrace();
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, e.getMessage()));
			}
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);
		}
		if (request.getParameter(CONFIG_SUBMIT) != null) {
			String resultsPerPage = request.getParameter(SETTING_PARAMETER_RESULTS_PER_PAGE);
			PortletPreferences prefs = request.getPreferences();			
			try {   
				prefs.setValue(SETTING_PARAMETER_RESULTS_PER_PAGE, resultsPerPage);
				prefs.store();
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(new Locale("bg")).getString("settings.were.saved")));
				response.setPortletMode(PortletMode.VIEW);
				response.setWindowState(WindowState.NORMAL);				
			} catch( ReadOnlyException roe ) {
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, roe.getMessage()));
			} catch( ValidatorException ve ) { 
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, ve.getMessage()));
			}
		} else if (request.getParameter(CONFIG_CANCEL) != null) {			
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);
		} 
		if (request.getParameter(EDIT_DEFAULTS_SUBMIT) != null) {
			String mailSmtpHost = request.getParameter(SETTING_PARAMETER_MAIL_SMTP_HOST);
			String fromAddress = request.getParameter(SETTING_PARAMETER_FROM_ADDRESS);
			String toAddress = request.getParameter(SETTING_PARAMETER_TO_ADDRESS);
			String sendEmail = request.getParameter(SETTING_PARAMETER_SEND_EMAIL);
			String homePageFriendlyUrl = request.getParameter(SETTING_PARAMETER_HOME_PAGE_FRIENDLY_URL);
			String ePaymentUrl = request.getParameter(SETTING_PARAMETER_E_PAYMENT_URL);
			String regixUrl = request.getParameter(SETTING_PARAMETER_REGIX_URL);
			String ahuUrl = request.getParameter(SETTING_PARAMETER_AHU_URL);
			String esbEventLoggerAddress = request.getParameter(SETTING_PARAMETER_ESB_EVENT_LOGGER_ADDRESS);
			String esbRegixAddress = request.getParameter(SETTING_PARAMETER_ESB_REGIX_ADDRESS);
			String esbEDeliveryAddress = request.getParameter(SETTING_PARAMETER_ESB_EDELIVERY_ADDRESS);
			String ornAddress = request.getParameter(SETTING_PARAMETER_ORN_ADDRESS);
			String logEvents = request.getParameter(SETTING_PARAMETER_LOG_EVENTS);
			String searchScopeId = request.getParameter(SETTING_PARAMETER_SEARCH_SCOPE_ID);
			String resultsPerPage = request.getParameter(SETTING_PARAMETER_RESULTS_PER_PAGE);			
			String language = request.getParameter(SETTING_PARAMETER_LANGUAGE);
			String debug = request.getParameter(SETTING_PARAMETER_DEBUG);
			PortletPreferences prefs = request.getPreferences();			
			try {
				prefs.setValue(SETTING_PARAMETER_MAIL_SMTP_HOST, mailSmtpHost);
				prefs.setValue(SETTING_PARAMETER_FROM_ADDRESS, fromAddress);
				prefs.setValue(SETTING_PARAMETER_TO_ADDRESS, toAddress);
				prefs.setValue(SETTING_PARAMETER_SEND_EMAIL, sendEmail);
				prefs.setValue(SETTING_PARAMETER_HOME_PAGE_FRIENDLY_URL, homePageFriendlyUrl);
				prefs.setValue(SETTING_PARAMETER_E_PAYMENT_URL, ePaymentUrl);
				prefs.setValue(SETTING_PARAMETER_REGIX_URL, regixUrl);
				prefs.setValue(SETTING_PARAMETER_AHU_URL, ahuUrl);
				prefs.setValue(SETTING_PARAMETER_ESB_EVENT_LOGGER_ADDRESS, esbEventLoggerAddress);
				prefs.setValue(SETTING_PARAMETER_ESB_REGIX_ADDRESS, esbRegixAddress);
				prefs.setValue(SETTING_PARAMETER_ESB_EDELIVERY_ADDRESS, esbEDeliveryAddress);
				prefs.setValue(SETTING_PARAMETER_ORN_ADDRESS, ornAddress);
				prefs.setValue(SETTING_PARAMETER_LOG_EVENTS, logEvents);
				prefs.setValue(SETTING_PARAMETER_SEARCH_SCOPE_ID, searchScopeId);
				prefs.setValue(SETTING_PARAMETER_RESULTS_PER_PAGE, resultsPerPage);
				prefs.setValue(SETTING_PARAMETER_LANGUAGE, language);
				prefs.setValue(SETTING_PARAMETER_DEBUG, debug);
				prefs.store();
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(new Locale("bg")).getString("settings.were.saved")));
				response.setPortletMode(PortletMode.VIEW);
				response.setWindowState(WindowState.NORMAL);
			} catch( ReadOnlyException roe ) {
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, roe.getMessage()));
			} catch( ValidatorException ve ) { 
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, ve.getMessage()));
			}
		} else if (request.getParameter(EDIT_DEFAULTS_CANCEL) != null) {			
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);
		}
	}

	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void serveResource(ResourceRequest request, ResourceResponse response) throws PortletException, IOException {
			
		Logger.log(Logger.DEBUG_LEVEL, "serveResource() started...");
		response.setContentType("application/json; charset=UTF-8");
		JSONObject json = new JSONObject();
		
		MySpacePortletSessionBean sessionBean = getSessionBean(request);
		if (sessionBean != null && sessionBean.getUserProfile() != null) {
			String remoteIP = "localhost";	
			HttpServletRequest httpServletRequest = null;
			HttpServletResponse httpServletResponse = null;
			try {
				httpServletRequest = (HttpServletRequest) (com.ibm.ws.portletcontainer.portlet.PortletUtils.getHttpServletRequest(request));
				remoteIP = httpServletRequest.getHeader("X-FORWARDED-FOR");
				if (remoteIP == null) {
					remoteIP = httpServletRequest.getRemoteAddr();
				}				
				httpServletResponse = (HttpServletResponse) (com.ibm.ws.portletcontainer.portlet.PortletUtils.getHttpServletResponse(response));
			} catch (Exception e) {
				e.printStackTrace();
			}
			HashMap<String, Container> sessionContainer = sessionBean.getContainer();
			Container container = sessionContainer.get(sessionBean.getCurrentPage());
			Locale locale = new Locale(language);
			String action = request.getParameter(PARAMETER_ACTION);
			String value = request.getParameter(PARAMETER_VALUE);
			Logger.log(Logger.DEBUG_LEVEL, "serveResource() param:action=" + action);
			Logger.log(Logger.DEBUG_LEVEL, "serveResource() param:value=" + value);
			MySpaceUtils utils = new MySpaceUtils();
			if (ACTION_DOWNLOAD_AUTHORIZATION_AUTHORIZED_FILE_FOR_SIGN.equals(action)) {
				AuthorizationBean aBean = container.getAuthorizationBean();
				if (aBean != null && aBean.getActionIds() != null && aBean.getActionIds().trim().length() > 0) {
					String currentTime = utils.getCurrentTime();
					String xml = utils.populateXMLForSign(aBean, sessionBean, currentTime);					
					if (xml != null && xml.length() > 0) {							
						OutputStream out = null;
						try {
							String fileName = "Овластяване_на_" + aBean.getAuthorizedNames().replaceAll(" ", "_") + "_";
							String time = currentTime.replaceAll("\\.", "_").replaceAll(" ", "_").replaceAll("\\:", "_");
							fileName += time;
							fileName += ".xml";
							response.setContentType("application/xml; charset=UTF-8");
							response.setCharacterEncoding("UTF-8");
							response.setProperty("Content-disposition","attachment; filename=" + URLEncoder.encode(fileName, "UTF-8").replaceAll("\\+", " "));
							Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> filename: " + fileName);
							byte[] bytes = xml.getBytes(StandardCharsets.UTF_8);
							out = response.getPortletOutputStream();
							response.setContentLength(bytes.length);
							try {
								out.write(bytes , 0, bytes.length);
							} catch (Exception e) {
								e.printStackTrace(); 
							} 
							out.flush();
							out.close();
						} catch (Exception e) {
							if (out != null) {
								try {
									out.flush();
									out.close();
								} catch (Exception e2) {}
							}
							e.printStackTrace();
						}
					}
				} else {
					response.setContentType("application/xml");					
					response.getWriter().flush();
					response.getWriter().close();	
				}
				return;
			} else if (ACTION_DOWNLOAD_AUTHORIZATION_AUTHORIZED_FILE.equals(action)) {
				if (value != null && value.trim().length() > 0) {
					Long authorizationsId = 0l;
					try {
						authorizationsId = Long.parseLong(value);
					}catch (NumberFormatException e) {
						e.printStackTrace();
					}
					AuthorizationsManagement management = new AuthorizationsManagement(); 
					Authorizations authorization = management.getAuthorizationAuthorizedFile(authorizationsId); 
					if (authorization != null) {	
						OutputStream out = null;
						try {
							response.setContentType((authorization.getAuthorizedDocumentContentType() != null ? authorization.getAuthorizedDocumentContentType() : "text/plain") + "; charset=UTF-8");
							response.setCharacterEncoding("UTF-8");
							response.setProperty("Content-disposition","attachment; filename=" + URLEncoder.encode(authorization.getAuthorizedDocumentName(), "UTF-8").replaceAll("\\+", " "));
							Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> contentType: " + authorization.getAuthorizedDocumentContentType() != null ? authorization.getAuthorizedDocumentContentType() : "text/plain");
							Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> filename: " + authorization.getAuthorizedDocumentName());
							out = response.getPortletOutputStream();
							if (authorization.getAuthorizedDocument() != null) {
								response.setContentLength(authorization.getAuthorizedDocument().length);
								try {
									out.write(authorization.getAuthorizedDocument() , 0, authorization.getAuthorizedDocument().length);
								} catch (Exception e) {
								   e.printStackTrace(); 
								} 
							}
							out.flush();
							out.close();
						} catch (Exception e) {
							if (out != null) {
								try {
									out.flush();
									out.close();
								} catch (Exception e2) {}
							}
							e.printStackTrace();
						}
					}
				} else {
					response.setContentType("text/plain");
					response.getWriter().flush();
					response.getWriter().close();	
				}
				return;
			} else if (ACTION_DOWNLOAD_AUTHORIZATION_CANCEL_FILE.equals(action)) {
				if (value != null && value.trim().length() > 0) {
					Long authorizationsId = 0l;
					try {
						authorizationsId = Long.parseLong(value);
					}catch (NumberFormatException e) {
						e.printStackTrace();
					}
					AuthorizationsManagement management = new AuthorizationsManagement(); 
					Authorizations authorization = management.getAuthorizationCancelFile(authorizationsId); 
					if (authorization != null) {	
						OutputStream out = null;
						try {
							response.setContentType((authorization.getCancelDocumentContentType() != null ? authorization.getCancelDocumentContentType() : "text/plain") + "; charset=UTF-8");
							response.setCharacterEncoding("UTF-8");
							response.setProperty("Content-disposition","attachment; filename=" + URLEncoder.encode(authorization.getCancelDocumentName(), "UTF-8").replaceAll("\\+", " "));
							Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> contentType: " + authorization.getCancelDocumentContentType() != null ? authorization.getCancelDocumentContentType() : "text/plain");
							Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> filename: " + authorization.getCancelDocumentName());
							out = response.getPortletOutputStream();
							if (authorization.getCancelDocument() != null) {
								response.setContentLength(authorization.getCancelDocument().length);
								try {
									out.write(authorization.getCancelDocument() , 0, authorization.getCancelDocument().length);
								} catch (Exception e) {
								   e.printStackTrace(); 
								} 
							}
							out.flush();
							out.close();
						} catch (Exception e) {
							if (out != null) {
								try {
									out.flush();
									out.close();
								} catch (Exception e2) {}
							}
							e.printStackTrace();
						}
					}
				} else {
					response.setContentType("text/plain");
					response.getWriter().flush();
					response.getWriter().close();	
				}
				return;
			} else if (ACTION_GET_LE_DATA.equals(action)) {
				JSONObject ja = new JSONObject(); 
				if (value != null && value.trim().length() > 0) {
					EgovServiceProvider provider = EgovWCMCache.getServiceProviderByEIK().get(value);
					if (provider != null) {
						try {
							boolean founded = false;
							if (sessionBean.getProfiles() != null && sessionBean.getProfiles().length > 0) {
								UserProfile[] profiles = sessionBean.getProfiles();
								for (int i = 0; i < profiles.length; i++) {
									if (value.equalsIgnoreCase(profiles[i].getEik())) {
										founded = true;
										ja.put("result", "0");
										ja.put("message", "Юридическо лице с ЕИК \"" + value + "\" вече същестува във вашите профили!");
										break;
									}
								}
							}
							if (!founded) {
								UserProfile[] profiles = sessionBean.getProfilesParticipation();
								if (profiles != null && profiles.length > 0) {
									for (int i = 0; i < profiles.length; i++) {
										if (value.equalsIgnoreCase(profiles[i].getEik())) {
											founded = true;
											ja.put("result", "0");
											ja.put("message", "Юридическо лице с ЕИК \"" + value + "\" вече същестува и вие сте асоцииран към него!");
											break;
										}
									}
								}
							}
							if (!founded) {
								UserProfileRequest[] requests = sessionBean.getRequests();
								if (requests != null && requests.length > 0) {
									for (int i = 0; i < requests.length; i++) {
										if (value.equalsIgnoreCase(requests[i].getEik())) {
											founded = true;
											ja.put("result", "0");
											ja.put("message", "Вече съществува заявка за добавяне на юридическо лице с ЕИК \"" + value + "\". Моля изчакайте нейното обработване!");
											break;
										}
									}
								}
							}
							if (!founded) {
								ja.put("result", "1");								
								if (EgovWCMCache.getATServiceProviderArticle1Paragraph2().getName().equalsIgnoreCase(provider.getAuthoringTemplateName())) {
									ja.put("type", MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY_AL2);
								} else {
									ja.put("type", MySpaceConstants.USER_PROFILE_TYPE_SERVICE_SUPPLIER);
									ja.put("qualityOfPhysicalPerson", "1");
									ja.put("methodOfRepresentaion", "1");
								}
								ja.put(FORM_PARAMETER_EIK_NAME, value);
								ja.put(FORM_PARAMETER_NAME_AND_LEGAL_FORM_NAME, provider.getTitle());									
							}
						} catch (Exception e) {
							e.printStackTrace();
						}						
					} else {
						// Call Regix service.
						RegixManagement management = new RegixManagement();
						ValidUICResponse validUICResponse = management.loadByUIC(value);
						if (validUICResponse != null && validUICResponse.getUic() != null) {
							ja.put("result", "1");
							ja.put("type", MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY);
							ja.put(FORM_PARAMETER_EIK_NAME, validUICResponse.getUic());
							ja.put(FORM_PARAMETER_NAME_AND_LEGAL_FORM_NAME, validUICResponse.getCompany());
						} else {
							ja.put("result", "0");
							ja.put("message", "Юридическо лице с ЕИК \"" + value + "\" не е намерено в системата!");
						}
//						RegixEIKBean regixEIKBean = null;//management.loadByUICFromESB(value);
//						if (regixEIKBean != null) {
//							ja.put("result", "1");
//							ja.put("type", MySpaceConstants.USER_PROFILE_TYPE_LEGAL_ENTITY);
//							ja.put(FORM_PARAMETER_EIK_NAME, value);
//							ja.put(FORM_PARAMETER_NAME_AND_LEGAL_FORM_NAME, regixEIKBean.getCompany() + (regixEIKBean.getLegalFormAbbr() != null ? " " + regixEIKBean.getLegalFormAbbr() : ""));
//						} else {
//							ja.put("result", "0");
//							ja.put("message", "Юридическо лице с ЕИК \"" + value + "\" не е намерено в системата!");
//						}
					}
				}
				json.put("data", ja);
			} else if (ACTION_GET_AUTHORIZED_USER_DATA.equals(action)) {
				JSONObject ja = new JSONObject(); 
				Integer authorizedType = utils.getIntegerParameterValue(request.getParameter("authorizedType"));
				String authorizedNames = request.getParameter("authorizedNames");
				String authorizedIdentifier = request.getParameter("authorizedIdentifier");
				if (authorizedType != null
						&& authorizedNames != null && authorizedNames.trim().length() > 0
						&& authorizedIdentifier != null && authorizedIdentifier.trim().length() > 0) {
					boolean error = false; 
					boolean isPerson = MySpaceConstants.AUTHORIZATIONS_AUTHORIZED_TYPE_PERSON == authorizedType;					
					String encryptedIdentifier = authorizedIdentifier;
					
					if (isPerson) {
						EncryptorAESGCM aesCls = new EncryptorAESGCM();
						encryptedIdentifier = aesCls.encryptEgovIdentifier(authorizedIdentifier);
						// Check we do not authorized ourselves :)
						if (isPerson && MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(sessionBean.getProfile().getProfileType())) {							
							if (encryptedIdentifier.equalsIgnoreCase(sessionBean.getProfile().getIdentifier())) {
								error = true;
								ja.put("result", "0");
								String message = "Не може да овластявате \"сам себе си\".";
								ja.put("message", message);
							}
						}
					} else if (!MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(sessionBean.getProfile().getProfileType())) {
						// Check we do not authorized same legal entity.
						if (authorizedIdentifier.equalsIgnoreCase(sessionBean.getProfile().getEik())) {
							error = true;
							ja.put("result", "0");
							String message = "Не може да овластявате същотото юридическото лице от което правите овластяването.";
							ja.put("message", message);
						}
					}
					AuthorizationBean bean = null;
					if (!error) {
						UserProfileManagement management = new UserProfileManagement();
						// We do partitial match.
						UserProfile authorizedUserProfile = management.loadUserProfileByTypeIdentifierOrName(authorizedType, encryptedIdentifier, authorizedNames); 
						if (authorizedUserProfile != null) {
							String message = null;;
							if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equalsIgnoreCase(String.valueOf(authorizedType))) {
								if (authorizedUserProfile.getIdentifier().equalsIgnoreCase(encryptedIdentifier)) {
									// Name does not match.
									if (!authorizedUserProfile.getNames().equalsIgnoreCase(authorizedNames)) {
										message = "Несъществуващ потребител!";
										message += "<br/>Няма данни за регистриран потребител с имена [" + authorizedNames + "].";
										message += "<br/>За да овластите физическо лице е необходимо същото да има регистриран и активен профил в \"Моето пространство\" на eGov.bg";										
									}
								} else {
									// Identifier does not match.
									message = "Несъществуващ потребител!";
									message += "<br/>Няма данни за регистриран потребител с ЕГН/ЛНЧ [" + authorizedIdentifier + "].";
									message += "<br/>За да овластите физическо лице е необходимо същото да има регистриран и активен профил в \"Моето пространство\" на eGov.bg";
								}
							} else {
								if (authorizedUserProfile.getEik().equalsIgnoreCase(encryptedIdentifier)) {
									// Name does not match.
									if (!authorizedUserProfile.getNameAndLegalForm().equalsIgnoreCase(authorizedNames)) {
										message = "Несъществуващо ючидическо лице!";
										message += "<br/>Няма данни за регистрирано юридическо лице с наименование [" + authorizedNames + "].";
										message += "<br/>За да овластите юридическо лице е необходимо същото да има регистриран и активен профил в \"Моето пространство\" на eGov.bg";										
									}
								} else {
									// Identifier does not match.
									message = "Несъществуващо ючидическо лице!";
									message += "<br/>Няма данни за регистрирано юридическо лице с ЕИК [" + authorizedIdentifier + "].";
									message += "<br/>За да овластите юридическо лице е необходимо същото да има регистриран и активен профил в \"Моето пространство\" на eGov.bg";
								}
							}
							if (message != null) {
								ja.put("result", "0");
								ja.put("message", message);
								
							} else {
								bean = new AuthorizationBean();
								bean.setAuthorizedType(authorizedType);
								bean.setAuthorizedIdentifierType(isPerson ? MySpaceConstants.AUTHORIZATIONS_AUTHORIZED_IDENTIFIER_TYPE_EGN : MySpaceConstants.AUTHORIZATIONS_AUTHORIZED_IDENTIFIER_TYPE_EIK);
								bean.setAuthorizedIdentifier(authorizedIdentifier);
								bean.setEncryptedAuthorizedIdentifier(encryptedIdentifier);
								bean.setAuthorizedNames(isPerson ? authorizedUserProfile.getNames() : authorizedUserProfile.getNameAndLegalForm());
								ja.put("result", "1");
								ja.put("name", (isPerson) ? authorizedUserProfile.getNames() : authorizedUserProfile.getNameAndLegalForm());
								ja.put("identifier", (isPerson) ? authorizedIdentifier : authorizedUserProfile.getEik());
								// Load all systems.
								AuthorizationsManagement authorizationManagement = new AuthorizationsManagement();
								List<Systems> systems = authorizationManagement.getAllSystems();
								JSONArray jSystems = new JSONArray();
								if (systems != null && systems.size() > 0) {
									Map<Long, List<Actions>> actionsPerSystem = authorizationManagement.getAllActionsSplitedBySystemsId();
									JSONArray jActions = null;
									List<Actions> actions = null; 
									JSONObject jSystem = null;
									JSONObject jAction = null;
									for (int i = 0; i < systems.size(); i++) {
										actions = actionsPerSystem.get(systems.get(i).getSystemsId());
										if (actions != null && actions.size() > 0) {
											jActions = new JSONArray();									
											jSystem = new JSONObject();									
											jSystem.put("id", systems.get(i).getSystemsId());
											jSystem.put("title", systems.get(i).getTitle());
											for (int j = 0; j < actions.size(); j++) {
												jAction = new JSONObject();	
												jAction.put("id", actions.get(j).getActionsId());
												jAction.put("description", actions.get(j).getDescription());
												jActions.put(jAction);
											}
											jSystem.put("actions", jActions);
											jSystems.put(jSystem);
										}
									}
								}
								ja.put("systems", jSystems);
							}
						} else {
							ja.put("result", "0");
							if (isPerson) {
								String message = "Несъществуващ потребител!";
								message += "<br/>Няма данни за регистриран потребител с имена [" + authorizedNames + "] и ЕГН/ЛНЧ [" + authorizedIdentifier + "].";
								message += "<br/>За да овластите физическо лице е необходимо същото да има регистриран и активен профил в \"Моето пространство\" на eGov.bg";
								ja.put("message", message);
							} else {
								String message = "Несъществуващо юридическо лице!";
								message += "<br/>Няма данни за регистрирано юридическо лице с наименование [" + authorizedNames + "] и ЕИК [" + authorizedIdentifier + "].";
								message += "<br/>За да овластите юридическо лице е необходимо същото да има регистриран и активен профил в \"Моето пространство\" на eGov.bg";
								ja.put("message", message);
							}
						}
					}
					container.setAuthorizationBean(bean);
					sessionContainer.put(sessionBean.getCurrentPage(), container);
				}
				json.put("data", ja);				
			} else if (ACTION_GET_SERVICES_CLASSIFICATION.equals(action)) {
				container = sessionContainer.get(sessionBean.getCurrentPage());
				if (container == null) {
					container = new Container();
				}
				JSONArray ja = new JSONArray();
				// This is the "top" page unique name. 
				String currentPageUniqueName = "page.egov.uslugi";
				String pageUniqueName = request.getParameter(PARAMETER_PAGE_UNIQUE_NAME);
				String searchString = request.getParameter(PARAMETER_SEARCH_STRING);
				boolean hasPageSelected = false;
				if (pageUniqueName != null && pageUniqueName.trim().length() > 0) {
					currentPageUniqueName = pageUniqueName.trim(); 
					hasPageSelected = true;
				}
				container.setPageUniqueName(pageUniqueName);
				container.setSearchString(searchString);
				container.setSubPageUniqueName(null);
				container.setSubPageTitle(null);				
				if (MySpacePortlet.getNavigationSelectionModelHome() != null) {
					try {
						NavigationModelHome navigationModelHome = MySpacePortlet.getNavigationModelHome();
						if (navigationModelHome != null) {
							NavigationModelProvider nmProvider = navigationModelHome.getNavigationModelProvider();      			
							NavigationModel nmodel = nmProvider.getNavigationModel(httpServletRequest, httpServletResponse);
							// If you want to load children by page unique name.
							Locator locator = nmodel.getLocator();
							NavigationNode serviceCategoryPage = (NavigationNode)locator.findByUniqueName(currentPageUniqueName);
							if (serviceCategoryPage != null) {
								if (hasPageSelected) { 
									container.setPageTitle(serviceCategoryPage.getTitle(Locale.ENGLISH));
								} 
								Iterator iter = nmodel.getChildren(serviceCategoryPage);  
								com.ibm.portal.MetaData iMetaData = null;     
								Object hiddenValue = null;
								NavigationNode cNode = null;
								ContentNode contentNode = null;
								JSONArray tmpJA = null;			    				
								while (iter.hasNext()) {	    
									cNode = (NavigationNode)iter.next();			    					
									contentNode = cNode.getContentNode();
									if (contentNode instanceof MetaDataProvider) {
										iMetaData = ((com.ibm.portal.MetaDataProvider)contentNode).getMetaData();  
										hiddenValue = iMetaData.getValue("page.custom.navigator.hide");
									}					
									if (hiddenValue != null && "true".equalsIgnoreCase(hiddenValue.toString()) || contentNode.getContentNodeType().equals(ContentNodeType.LABEL)) continue;
									tmpJA = new JSONArray();
									tmpJA.put(contentNode.getObjectID().getUniqueName());
									tmpJA.put(contentNode.getTitle(Locale.ENGLISH));
									ja.put(tmpJA);	
								}
							}
						} 
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				sessionContainer.put(sessionBean.getCurrentPage(), container);
				json.put("data", ja);
			} else if (ACTION_GET_SERVICES_FOR_CATALOG.equals(action)) {
				container = sessionContainer.get(sessionBean.getCurrentPage());
				if (container == null) {
					container = new Container();
				}
				JSONObject jo = new JSONObject();				
				String subPageUniqueName = request.getParameter(PARAMETER_SUB_PAGE_UNIQUE_NAME);
				String searchString = request.getParameter(PARAMETER_SEARCH_STRING);
				container.setSubPageUniqueName(subPageUniqueName);
				container.setSearchString(searchString);				
				String currentPageUniqueName = subPageUniqueName != null ? subPageUniqueName : container.getPageUniqueName();
				List<EgovService> foundedServices = new ArrayList<EgovService>();
				EgovWCMUtils egovUtils = new EgovWCMUtils();
				// If we have category selected, so filter services by category.
				if (currentPageUniqueName != null && currentPageUniqueName.trim().length() > 0) {
					if (MySpacePortlet.getNavigationSelectionModelHome() != null) {
						try {
							NavigationModelHome navigationModelHome = MySpacePortlet.getNavigationModelHome();
							if (navigationModelHome != null) {
								NavigationModelProvider nmProvider = navigationModelHome.getNavigationModelProvider();      			
				        		NavigationModel nmodel = nmProvider.getNavigationModel(httpServletRequest, httpServletResponse);
				        		// If you want to load children by page unique name.
				        		Locator locator = nmodel.getLocator();
				        		NavigationNode serviceCategoryPage = (NavigationNode)locator.findByUniqueName(currentPageUniqueName);
				        		if (serviceCategoryPage != null) {
			        				container.setSubPageTitle(serviceCategoryPage.getTitle(Locale.ENGLISH));				        			
				        			String friendlyUrl = getPageFriendlyUrl(serviceCategoryPage, request, response);
				        			if (friendlyUrl != null) {
//				        				System.out.println("friendlyUrl=" + friendlyUrl);
				        				// Find category name match friendly URL.
				        				//EgovWCMCache.TAXONOMY_SERVICE_CLASSIFICATION
				        				DocumentIdIterator categoryIterator = EgovWCMCache.getWorkspace().findByName(DocumentTypes.Category, friendlyUrl);
				        				List<String> categoryTitles = new ArrayList<String>();
				        				if (categoryIterator.hasNext()) {			        								        					
				        					DocumentId servicesCategoryId = categoryIterator.next();
				        					Category category = (Category)EgovWCMCache.getWorkspace().getById(servicesCategoryId, true);
				        					if (category != null) {
				        						DocumentIdIterator dIt = category.getChildren();
				        						if (dIt != null && dIt.hasNext()) { // has children
				        							
				        						} else {
				        							categoryTitles.add(category.getTitle());
				        						}
				        					}
				        				}
				        				if (categoryTitles.size() > 0) {
				        					List<EgovService> allServices = null;				        					
				        					String[] classification = null;
				        					for (int z = 0; z < 2; z++) {
												if (z == 0) {
													allServices = EgovWCMCache.getServicesByProvider();
												} else {
													allServices = EgovWCMCache.getUnifiedServices();
												}
												if (allServices != null && allServices.size() > 0) {
					        						for (int i = 0; i < allServices.size(); i++) {
					        							classification = allServices.get(i).getClassification();
					        							if (classification != null) {
						        							for (int j = 0; j < classification.length; j++) {
						        								if (categoryTitles.contains(classification[j])) {
						        									foundedServices.add(allServices.get(i));
						        									break;
						        								}
															}
					        							}												
													}
					        					}
											}
				        				}
				        			}
				        		}
							} 
						} catch (Exception e) {
							e.printStackTrace();
						}					
					}					
				} else if (searchString != null && searchString.trim().length() > 0) {// no category defined. search all services. 
					List<EgovService> allServices = null;				        					
					for (int z = 0; z < 2; z++) {
						if (z == 0) {
							allServices = EgovWCMCache.getServicesByProvider();
						} else {
							allServices = EgovWCMCache.getUnifiedServices();
						}
						if (allServices != null && allServices.size() > 0) {
    						for (int i = 0; i < allServices.size(); i++) {
    							foundedServices.add(allServices.get(i));    																
							}
    					}
					}
				}
				if (foundedServices != null && foundedServices.size() > 0) {					
					if (searchString != null && searchString.trim().length() > 0) {        					
						Logger.log(Logger.DEBUG_LEVEL, "searchString != null && searchString.trim().length() > 0 -> going to filter (before=" + foundedServices.size() + ")");
						// Order by higher match.
						foundedServices = egovUtils.orderBySeachTerm(foundedServices, searchString.toLowerCase()); 
						Logger.log(Logger.DEBUG_LEVEL, "searchString != null && searchString.trim().length() > 0 -> going to filter (after=" + foundedServices.size() + ")");
					} else {
						foundedServices = egovUtils.orderByTitle(foundedServices);
					}
					if (httpServletRequest.getSession() != null) {
						Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> prepareRenderingData() hasSession");
						if ((ArrayList<String>)httpServletRequest.getSession().getAttribute(MySpaceConstants._USER_PROFILE_MY_FAVORITE_SERVICES_SESSION_KEY) == null) {
							Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> prepareRenderingData() NO SessionKey, initialize data from DB...");
							ArrayList<String> myFavoritesArrList = new ArrayList<String>();
							MyFavoriteServicesManagement management = new MyFavoriteServicesManagement();
							UserProfileMyFavorites[] myFavorites = management.loadAllContentUUIDsByUserUID(sessionBean.getUserProfile().getCurrentUserUID());
							if (myFavorites != null && myFavorites.length > 0) {
								for (int i = 0; i < myFavorites.length; i++) {
									myFavoritesArrList.add(myFavorites[i].getContentUUID());
								}
							}
							Logger.log(Logger.DEBUG_LEVEL, "MySpaceViewEngine -> prepareRenderingData() loaded \"My Favorites\" from DB = " + myFavoritesArrList.size());
							httpServletRequest.getSession().setAttribute(MySpaceConstants._USER_PROFILE_MY_FAVORITE_SERVICES_SESSION_KEY, myFavoritesArrList);
						}
						container.setFavoriteServices((ArrayList<String>)httpServletRequest.getSession().getAttribute(MySpaceConstants._USER_PROFILE_MY_FAVORITE_SERVICES_SESSION_KEY));
					}
				}
				JSONArray ja = new JSONArray();
				JSONArray tmpJA = null;
				String favoritesServicesUUIDs = "";
				if (container.getFavoriteServices() != null && container.getFavoriteServices().size() > 0) {
					for (int i = 0; i < container.getFavoriteServices().size(); i++) {
						if (favoritesServicesUUIDs.length() > 0) {
							favoritesServicesUUIDs += ",";
						}
						favoritesServicesUUIDs += container.getFavoriteServices().get(i);
					}
				} 
				jo.put("favoritesServicesUUIDs", favoritesServicesUUIDs);
				if (foundedServices != null && foundedServices.size() > 0) {
					Date date = null;							
					for (int i = 0; i < foundedServices.size(); i++) {
						tmpJA = new JSONArray();
						date = foundedServices.get(i).getModifiedDate();								
						tmpJA.put(foundedServices.get(i).getId());
						tmpJA.put(foundedServices.get(i).getTitle());
						tmpJA.put(foundedServices.get(i).getName());
						tmpJA.put(egovUtils.getSupplierName(foundedServices.get(i)));
						tmpJA.put(foundedServices.get(i).getContentPath().substring(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME.length() + 1));						
						if (date != null) {
							tmpJA.put(dateFormat.format(date));
						} else {
							tmpJA.put("");
						}
						ja.put(tmpJA);	
					}
					jo.put("servicesUUIDs", ja);
				} else {
					jo.put("servicesUUIDs", ja);
				}
				sessionContainer.put(sessionBean.getCurrentPage(), container);
				json.put("data", jo);				
			} else if (ACTION_GET_USER_DATA.equals(action)) {				
				JSONObject ja = new JSONObject(); 
				if (value != null && value.trim().length() > 0) {
					//String uid = MySpaceUtils.getMd5(value);
					//User user = getUserByUID(uid);
					EncryptorAESGCM aesCls = new EncryptorAESGCM();
					String encryptedPersonalIdentifier = aesCls.encryptEgovIdentifier(value);
					User user = getUserByPersonalIdentifier(encryptedPersonalIdentifier);
//					User user = getUserByPersonalIdentifier(value);
					boolean founded = false;
					if (user != null) {								
						java.util.Map<String, Object> userInfo = getUserAttributesInfo(user, getPumaHome(), getPumaHome().getProfile());
						if (userInfo != null) {
							String userEmail = "";
							Object attribute = userInfo.get(MySpaceConstants.LDAP_ATTRIBUTE_PORTAL_EMAIL);
							if (attribute != null) {
								if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
									for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
										if (i > 0) {
											userEmail += " ";
										}
										userEmail += (String)((ArrayList)attribute).get(i);
									}
								} else if (attribute instanceof String) {
									userEmail = (String)attribute;
								}
							}
							attribute = userInfo.get(MySpaceConstants.LDAP_ATTRIBUTE_COMMON_NAME);
							if (attribute != null) {
								String userCN = "";
								if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
									for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
										if (i > 0) {
											userCN += " ";
										}
										userCN += (String)((ArrayList)attribute).get(i);
									}
								} else if (attribute instanceof String) {
									userCN = (String)attribute;
								}
								ja.put("result", "1");
								ja.put(FORM_PARAMETER_USER_NAMES_NAME, userCN);
								ja.put(FORM_PARAMETER_PERSONAL_IDENTIFIER_NAME, value);
								ja.put(FORM_PARAMETER_EMAIL_NAME, userEmail);
								founded = true;
							}
						}																		
					}
					if (!founded) {
						ja.put("result", "0");
						ja.put("message", "Потребител с идентификатор \"" + value + "\" не е намерен!");
					}
				}
				json.put("data", ja);
				
			} else if (ACTION_GET_EDELIVERY_MESSAGES.equals(action)) {
				JSONObject ja = new JSONObject();
				try {
					String direction = request.getParameter("direction");
					if (direction != null) {
						UserProfile profile = sessionBean.getProfile();
						UserProfileBean userProfileBean = sessionBean.getUserProfile();
						EncryptorAESGCM aesCls = new EncryptorAESGCM(); 
						ESBEDeliveryResponseBean eDeliveryResponse = null;							
						direction = MySpaceConstants.ESB_E_DELIVERY_DIRECTION_SENT.equalsIgnoreCase(direction) ? direction : MySpaceConstants.ESB_E_DELIVERY_DIRECTION_RECEIVED;
						String profileID = null;
						if (!MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(profile.getProfileType())) {
							profileID = profile.getEik();
						}
						String personalIdentifier = userProfileBean.getCurrentUserIdentifier() != null ? aesCls.decryptEgovIdentifier(userProfileBean.getCurrentUserIdentifier()) : null;
						try {		
							ESBCommunicator esbCommunicator = new ESBCommunicator();							
							eDeliveryResponse = esbCommunicator.getEDelivery(sessionBean, personalIdentifier, direction, profileID, 1, 10);							
						} catch (Exception e) {
							e.printStackTrace();
						}
						int unReadMessagesCount = 0;
						if (eDeliveryResponse != null) {
							ja.put("count", eDeliveryResponse.getCount());
							ja.put("messageType", eDeliveryResponse.getMessageType());
							List<ESBEDeliveryBean> messages = eDeliveryResponse.getMessages();
							ESBEDeliveryBean message = null;
							JSONArray jMessages = new JSONArray();	
							if (messages != null) {
								JSONObject tmpJo = null;	
								for (int i = 0; i < messages.size(); i++) {
									message = messages.get(i);
									tmpJo = new JSONObject();
									tmpJo.put("subject", message.getSubject());
									tmpJo.put("dateSent", message.getDateSent() != null ? utils.getFormatedZoneDateTime(message.getDateSent()) : "");
									tmpJo.put("toFrom", MySpaceConstants.ESB_E_DELIVERY_DIRECTION_RECEIVED.equalsIgnoreCase(direction) ? message.getSenderProfileName() : message.getRecipients());
									tmpJo.put("url", message.getUrl());
									tmpJo.put("unRead", MySpaceConstants.ESB_E_DELIVERY_DIRECTION_RECEIVED.equalsIgnoreCase(direction) && message.getDateReceived() == null);					
									jMessages.put(tmpJo);	
									if (MySpaceConstants.ESB_E_DELIVERY_DIRECTION_RECEIVED.equalsIgnoreCase(direction) && message.getDateReceived() == null) {
										unReadMessagesCount++;
									}
								}
							}
							ja.put("messages", jMessages);
						} else {
							ja.put("count", 0);
							ja.put("messageType", direction);							
						}
						// Update session counter.
						if (MySpaceConstants.ESB_E_DELIVERY_DIRECTION_RECEIVED.equalsIgnoreCase(direction)) {							
							sessionBean.setUnReadReceivedMessagesCount(unReadMessagesCount);
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				json.put("data", ja);
			} else if (ACTION_SYNC_EDELIVERY_PROFILE.equals(action)) {
				JSONObject ja = new JSONObject(); 
				if (value != null && value.trim().length() > 0) {
					UserProfileManagement management = new UserProfileManagement();
					if (MySpaceConstants.USER_PROFILE_TYPE_PERSONAL.equals(sessionBean.getProfile().getProfileType())) {
						try {
							ArrayList<String[]> requestResults = management.syncEDeliveryProfiles(sessionBean, value, remoteIP, getPortletConfig().getResourceBundle(locale));
							Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> " + SYNC_PROFILES_FROM_EDELIVERY_SUBMIT + ": MySpacePortlet.sendEmail=" + MySpacePortlet.sendEmail);
							Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> " + SYNC_PROFILES_FROM_EDELIVERY_SUBMIT + ": MySpacePortlet.fromAddress=" + MySpacePortlet.fromAddress);
							Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> " + SYNC_PROFILES_FROM_EDELIVERY_SUBMIT + ": MySpacePortlet.toAddress=" + MySpacePortlet.toAddress);
							// Send email to approver(s).	
							String[] result = null;
							if (requestResults != null && requestResults.size() > 0 && MySpacePortlet.sendEmail) {
								Logger.log(Logger.DEBUG_LEVEL, "serveResource() -> " + ACTION_SYNC_EDELIVERY_PROFILE + ": sending mail...");
								if (requestResults != null && requestResults.size() > 0) {								
									result = requestResults.get(0);
									if (result.length > 5) { // Notify only new request. The length should be 6.
										// Send email to DAEU approver(s).
										if (MySpacePortlet.sendEmail) {
											try {
												notificationManager.notifyDAEUForCreatedRequestForLEProfile(result, getPortletConfig().getResourceBundle(locale));
											} catch (Exception e) {
												e.printStackTrace();
											}	
										}
										// Send email to the user, that the request for adding new LE was registered.
										try {
											notificationManager.notifyUserForCreatedRequestForLEProfile(result, sessionBean.getProfile(), getPortletConfig().getResourceBundle(locale));
										} catch (Exception e) {
											e.printStackTrace();
										}	
									}
								}
							}
							ja.put("result", "1");
							if (requestResults != null && requestResults.size() > 0) {
								result = requestResults.get(0);
								if (result.length > 5) {
									ja.put("type", "Чакащ одобрение");
								} else {
									ja.put("type", "Присъединен");
								}								
							}
							ja.put("message", getPortletConfig().getResourceBundle(locale).getString("profile.sync.success"));
						} catch (Exception e) {
							e.printStackTrace();
							ja.put("result", "0");
							ja.put("message", e.getMessage());
						}
					} else {
						ja.put("result", "0");
						ja.put("message", getPortletConfig().getResourceBundle(locale).getString("profile.should.be.personal"));
					}
				} else {
					ja.put("result", "0");
					ja.put("message", "Невалидни параметри!");
				}
				json.put("data", ja);
			}
		}
		String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
		response.getWriter().print(jsonPrettyPrintString);
		response.getWriter().flush();
		response.getWriter().close();	
	}
	
	@SuppressWarnings("rawtypes")
	private UserProfileBean populateUserAttributesFromLDAP(UserProfileBean userProfileBean, final PumaHome pumaHome, final PumaProfile pumaProfile) {
		Logger.log(Logger.DEBUG_LEVEL, "populateUserAttributesFromLDAP(userProfileBean)");
		java.util.Map<String, Object> userInfo = getUserAttributesInfo(userProfileBean.getCurrentUser(), pumaHome, pumaProfile);
		if (userInfo != null) {
			Object attribute = userInfo.get(MySpaceConstants.LDAP_ATTRIBUTE_COMMON_NAME);
			if (attribute != null) {
				String currentUserCN = "";
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							currentUserCN += " ";
						}
						currentUserCN += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					currentUserCN = (String)attribute;
				}		
				userProfileBean.setCurrentUserCN(currentUserCN);
			}
			attribute = userInfo.get(MySpaceConstants.LDAP_ATTRIBUTE_UID);
			if (attribute != null) {
				String currentUserUID = "";
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							currentUserUID += " ";
						}
						currentUserUID += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					currentUserUID = (String)attribute;
				}		
				userProfileBean.setCurrentUserUID(currentUserUID);
			}
			attribute = userInfo.get(MySpaceConstants.LDAP_ATTRIBUTE_PORTAL_EMAIL);
			if (attribute != null) {
				String currentUserEmail = "";
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							currentUserEmail += " ";
						}
						currentUserEmail += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					currentUserEmail = (String)attribute;
				}
				userProfileBean.setCurrentUserEmail(currentUserEmail);
			}
			attribute = userInfo.get(MySpaceConstants.LDAP_ATTRIBUTE_EGOV_IDENTIFIER);
			//attribute = userInfo.get(MySpaceConstants.LDAP_ATTRIBUTE_EMPLOYEE_NUMBER);
			if (attribute != null) {
				String currentUserIdentifier = "";
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							currentUserIdentifier += " ";
						}
						currentUserIdentifier += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					currentUserIdentifier = (String)attribute;
				}
				userProfileBean.setCurrentUserIdentifier(currentUserIdentifier);
			}
			attribute = userInfo.get(MySpaceConstants.LDAP_ATTRIBUTE_DEPARTMENT_NUMBER);
			if (attribute != null) {
				String currentUserIdentifierPrefix = "";
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							currentUserIdentifierPrefix += " ";
						}
						currentUserIdentifierPrefix += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					currentUserIdentifierPrefix = (String)attribute;
				}
				userProfileBean.setCurrentUserIdentifierPrefix(currentUserIdentifierPrefix);
			}
			attribute = userInfo.get(MySpaceConstants.LDAP_ATTRIBUTE_ROOM_NUMBER);
			if (attribute != null) {
				String activeProfileId = "";
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							activeProfileId += " ";
						}
						activeProfileId += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					activeProfileId = (String)attribute;
				}				
				userProfileBean.setActiveProfileId(activeProfileId != null && activeProfileId.trim().length() > 0 ? activeProfileId : null);
			}
			attribute = userInfo.get(MySpaceConstants.LDAP_ATTRIBUTE_INVITATION_ID);
			if (attribute != null) {
				String invitationId = "";
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							invitationId += " ";
						}
						invitationId += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					invitationId = (String)attribute;
				}				
				userProfileBean.setInvitationId(invitationId != null && invitationId.trim().length() > 0 ? invitationId : null);
			}
		}
		Logger.log(Logger.DEBUG_LEVEL, "populateUserAttributesFromLDAP -> userDN = " + userProfileBean.getCurrentUserDN());
		Logger.log(Logger.DEBUG_LEVEL, "populateUserAttributesFromLDAP -> userCN = " + userProfileBean.getCurrentUserCN());
		Logger.log(Logger.DEBUG_LEVEL, "populateUserAttributesFromLDAP -> userUID = " + userProfileBean.getCurrentUserUID());
		Logger.log(Logger.DEBUG_LEVEL, "populateUserAttributesFromLDAP -> userIdentifier = " + userProfileBean.getCurrentUserIdentifier());
		Logger.log(Logger.DEBUG_LEVEL, "populateUserAttributesFromLDAP -> userIdentifierPrefix = " + userProfileBean.getCurrentUserIdentifierPrefix());
		Logger.log(Logger.DEBUG_LEVEL, "populateUserAttributesFromLDAP -> userEmail = " + userProfileBean.getCurrentUserEmail());
		Logger.log(Logger.DEBUG_LEVEL, "populateUserAttributesFromLDAP -> activeProfileId = " + userProfileBean.getActiveProfileId());
		Logger.log(Logger.DEBUG_LEVEL, "populateUserAttributesFromLDAP -> invitationId = " + userProfileBean.getInvitationId());
		return userProfileBean;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private java.util.Map<String, Object> getUserAttributesInfo(final User user, final PumaHome pumaHome, final PumaProfile pumaProfile) {
		Logger.log(Logger.DEBUG_LEVEL, "getUserAttributesInfo(com.ibm.portal.um.User)");
		final java.util.List<String> attributesNamesList;
		try {
			final PumaEnvironment env = pumaHome.getEnvironment();
			attributesNamesList = pumaProfile.getDefinedUserAttributeNames();
//			To use this implementation you need to defined Anonymous User access to Virtual Resource USER_GROUPS!
//			java.util.Map<String, Object> userInfo = (java.util.Map<String, Object>) getPumaProfile().getAttributes((com.ibm.portal.um.Principal) user, attributesNamesList);
			java.util.Map<String, Object> userInfo = (java.util.Map<String, Object>) env.runUnrestricted(new PrivilegedExceptionAction() {
				public Object run() throws Exception {
					return pumaProfile.getAttributes((com.ibm.portal.um.Principal) user, attributesNamesList);
				}
			});
			return userInfo;
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "getUserAttribute(com.ibm.portal.um.User) -> Exception: " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked", "unused" })
	private Object getUserAttribute(final User user, String attributeName) {
		Logger.log(Logger.DEBUG_LEVEL, "getUserAttribute(com.ibm.portal.um.User, " + attributeName + ")");
		final java.util.List<String> attributesNamesList;
		try {
			final PumaHome pumaHome = getPumaHome();
			final PumaEnvironment env = pumaHome.getEnvironment();
			final PumaProfile pumaProfile = getPumaProfile();
			attributesNamesList = getPumaProfile().getDefinedUserAttributeNames();
			Logger.log(Logger.DEBUG_LEVEL, "getUserAttribute(com.ibm.portal.um.User," + attributeName + ") -> attributesNamesList = " +  + (attributesNamesList != null ? attributesNamesList.size() : 0));
			if (attributesNamesList != null && attributesNamesList.size() > 0) {
				for (int i = 0; i < attributesNamesList.size(); i++) {
					Logger.log(Logger.DEBUG_LEVEL, "getUserAttribute(com.ibm.portal.um.User," + attributeName + ") -> attributesNamesList[" + i + "] = " + attributesNamesList.get(i));
				}
			}
//			To use this implementation you need to defined Anonymous User access to Virtual Resource USER_GROUPS!
//			java.util.Map<String, Object> userInfo = (java.util.Map<String, Object>) getPumaProfile().getAttributes((com.ibm.portal.um.Principal) user, attributesNamesList);
			java.util.Map<String, Object> userInfo = (java.util.Map<String, Object>) env.runUnrestricted(new PrivilegedExceptionAction() {
				public Object run() throws Exception {
					return pumaProfile.getAttributes((com.ibm.portal.um.Principal) user, attributesNamesList);
				}
			});
			
			if (userInfo != null) {
				Logger.log(Logger.DEBUG_LEVEL, "getUserAttribute(com.ibm.portal.um.User, " + attributeName + ") -> userInfo.size() = " + userInfo.size());
				return userInfo.get(attributeName);
			}
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "getUserAttribute(com.ibm.portal.um.User, " + attributeName + ") -> Exception: " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}

	public User getUserByPersonalIdentifier(final String userAttribute) {
		Logger.log(Logger.DEBUG_LEVEL, "getUserByPersonalIdentifier(" + userAttribute + ")");
		User user = null;
		List<User> users = getUsersByAttribute(userAttribute, MySpaceConstants.LDAP_ATTRIBUTE_EGOV_IDENTIFIER);
//		List<User> users = getUsersByAttribute(userAttribute, MySpaceConstants.LDAP_ATTRIBUTE_EMPLOYEE_NUMBER);
		if (users != null && users.size() > 0) {
			Logger.log(Logger.DEBUG_LEVEL, "getUserByPersonalIdentifier(" + userAttribute + ") -> users.size() = " + users.size());
			if (users.size() > 1) {
				Logger.log(Logger.DEBUG_LEVEL, "getUserByPersonalIdentifier() -> " + "Warning: Using non-unique attribute for User. Attribute Name=" + MySpaceConstants.LDAP_ATTRIBUTE_EGOV_IDENTIFIER + " Value =" + userAttribute);
//				Logger.log(Logger.DEBUG_LEVEL, "getUserByPersonalIdentifier() -> " + "Warning: Using non-unique attribute for User. Attribute Name=" + MySpaceConstants.LDAP_ATTRIBUTE_EMPLOYEE_NUMBER + " Value =" + userAttribute);
			} else {
				user = (User) users.get(0);
			}
		} else {
			Logger.log(Logger.DEBUG_LEVEL, "getUserByPersonalIdentifier(" + userAttribute + ") -> No User was found!");
		}
		
		return user;
	}
	
	public User getUserByUID(final String userAttribute) {
		Logger.log(Logger.DEBUG_LEVEL, "getUserByUID(" + userAttribute + ")");
		User user = null;
		List<User> users = getUsersByAttribute(userAttribute, MySpaceConstants.LDAP_ATTRIBUTE_UID);
		if (users != null && users.size() > 0) {
			Logger.log(Logger.DEBUG_LEVEL, "getUserByUID(" + userAttribute + ") -> users.size() = " + users.size());
			if (users.size() > 1) {
				Logger.log(Logger.DEBUG_LEVEL, "getUserByUID() -> " + "Warning: Using non-unique attribute for User. Attribute Name=" + MySpaceConstants.LDAP_ATTRIBUTE_UID + " Value =" + userAttribute);
			} else {
				user = (User) users.get(0);
			}
		} else {
			Logger.log(Logger.DEBUG_LEVEL, "getUserByUID(" + userAttribute + ") -> No User was found!");
		}

		return user;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private List<User> getUsersByAttribute(final String userAttributeValue, final String searchAttribute) {
		Logger.log(Logger.DEBUG_LEVEL, "getUsersByAttribute(" + userAttributeValue + "," + searchAttribute + ")");
		List<User> users = null;
		try {
			final PumaHome pumaHome = getPumaHome();
			final PumaEnvironment env = pumaHome.getEnvironment();
			final PumaLocator locatorService = pumaHome.getLocator();
			users = (List<User>) env.runUnrestricted(new PrivilegedExceptionAction() {
				public Object run() throws Exception {
					return locatorService.findUsersByAttribute(searchAttribute, userAttributeValue);
				}
			});
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "getUsersByAttribute(" + userAttributeValue + "," + searchAttribute + ") -> Exception: " + e.getMessage());
			e.printStackTrace();
		}		
		return users;
	}
	
	private void clearAuthorizationBeanData (MySpacePortletSessionBean sessionBean) {
		HashMap<String, Container> sessionContainer = sessionBean.getContainer();
		Container container = new Container();
		sessionContainer.put(AUTHORIZATION_PAGE, container);
		sessionContainer.put(ADD_AUTHORIZATION_PAGE, container);
		sessionContainer.put(ADD_AUTHORIZATION_PREVIEW_PAGE, container);
		sessionContainer.put(ADD_AUTHORIZATION_SIGN_PAGE, container);
		sessionContainer.put(CANCEL_AUTHORIZATION_PAGE, container);
	}
	
	private void multipartContentHandler (ActionRequest request, MySpacePortletSessionBean sessionBean, Locale locale, String remoteIP) {
		Logger.log(Logger.DEBUG_LEVEL, "multipartContentHandler() started...");
		InputStream uploadedStream = null;
		boolean testEnvironment = "TEST".equalsIgnoreCase(System.getProperty("environmentType"));
		try {
			// Create a factory for disk-based file items
			DiskFileItemFactory factory = new DiskFileItemFactory();
			
			factory.setSizeThreshold(MySpaceConstants.MAX_MEMORY_SIZE);
			// Sets the directory used to temporarily store files that are larger
			// than the configured size threshold. We use temporary directory for java
			factory.setRepository(new File(System.getProperty("java.io.tmpdir")));

			// Create a new file upload handler
			PortletFileUpload upload = new PortletFileUpload(factory);

			// Set overall request size constraint
			upload.setSizeMax(MySpaceConstants.MAX_REQUEST_SIZE);

			// Parse the request			
			List<FileItem> items = upload.parseRequest(request);
			// Process the uploaded items.
			Iterator<FileItem> iter = items.iterator();
			FileItem item = null;
			String value = null;
			String fileName = null;
			String fileContentType = null;
//			String filePath = null;
			String eik = null;
			String nameAndLegalForm = null;
			String orderNumber = null;
			String profileStructureType = null;
			String profileStructureTypeOther = null;
			long fileSize = 0;
			boolean isCreateSSFormSubmit = false;
			boolean isCreateLEFormSubmit = false;
			boolean isAddAuthorizationSignFormSubmit = false;
			boolean isCancelAuthorizationFormSubmit = false;
//			String accessKind = null;			
			while (iter.hasNext()) {
			    item = iter.next();
			    // Process a regular form field
			    if (item.isFormField()) {
			    	value = new String(item.getString().getBytes("ISO-8859-1"), "UTF-8");
			    	if (FORM_PARAMETER_EIK_NAME.equalsIgnoreCase(item.getFieldName())) {
			    		eik = value;
			    	} else if (FORM_PARAMETER_NAME_AND_LEGAL_FORM_NAME.equalsIgnoreCase(item.getFieldName())) {
			    		nameAndLegalForm = value;
			    	} else if (FORM_PARAMETER_PROFILE_STRUCTURE_TYPE_NAME.equalsIgnoreCase(item.getFieldName())) {
			    		profileStructureType = value;
			    	} else if (FORM_PARAMETER_PROFILE_STRUCTURE_TYPE_OTHER_NAME.equalsIgnoreCase(item.getFieldName())) {
			    		profileStructureTypeOther = value;
			    	} else if (FORM_PARAMETER_ORDER_NUMBER_NAME.equalsIgnoreCase(item.getFieldName())) {
			    		orderNumber = value;
			    	} else if (FORM_PARAMETER_ACCESS_KIND_NAME.equalsIgnoreCase(item.getFieldName())) {
//			    		accessKind = value;
			    	} else if (CREATE_SERVICE_SUPPLIER_REQUEST_PROFILE_SUBMIT.equalsIgnoreCase(item.getFieldName())) {
			    		isCreateSSFormSubmit = true;
			    	} else if (CREATE_LEGAL_ENTITY_REQUEST_PROFILE_SUBMIT.equalsIgnoreCase(item.getFieldName())) {
			    		isCreateLEFormSubmit = true;
			    	} else if (ADD_AUTHORIZATION_SIGN_SUBMIT.equalsIgnoreCase(item.getFieldName())) {
			    		isAddAuthorizationSignFormSubmit = true;
			    	} else if (CANCEL_AUTHORIZATION_SUBMIT.equalsIgnoreCase(item.getFieldName())) {
			    		isCancelAuthorizationFormSubmit = true;
			    	}			        
			    } // Process valid file(s) upload.
			    else if (item.getName() != null && item.getName().trim().length() > 0) { 
			    	if (FORM_PARAMETER_ORDER_FILE_NAME.equals(item.getFieldName()) ||
			    			FORM_PARAMETER_DOCUMENT_FILE_NAME.equals(item.getFieldName()) ||
			    			FORM_PARAMETER_SIGNED_FILE_NAME.equals(item.getFieldName())) {
			    		// TODO add validate to file extension.
			    		Logger.log(Logger.DEBUG_LEVEL, "multipartContentHandler(): filename:" + new File(item.getName()).getName());
			    		fileName = new File(item.getName()).getName();
			    		fileContentType = item.getContentType();
//				        boolean isInMemory = item.isInMemory();
				    	fileSize = item.getSize();
				        uploadedStream = item.getInputStream();				        
			    	}
			    }
			}
			if (isCreateSSFormSubmit) {
				Logger.log(Logger.DEBUG_LEVEL, "multipartContentHandler(): eik:" + eik);
				Logger.log(Logger.DEBUG_LEVEL, "multipartContentHandler(): nameAndLegalForm:" + nameAndLegalForm);
				Logger.log(Logger.DEBUG_LEVEL, "multipartContentHandler(): orderNumber:" + orderNumber);
				Logger.log(Logger.DEBUG_LEVEL, "multipartContentHandler(): orderDocumentName:" + fileName);
				Logger.log(Logger.DEBUG_LEVEL, "multipartContentHandler(): orderDocumentContentType:" + fileContentType);
				Logger.log(Logger.DEBUG_LEVEL, "multipartContentHandler(): orderDocumentSize:" + fileSize);
				UserProfileManagement management = new UserProfileManagement();
				String[] result = management.createServiceProviderProfileRequest(sessionBean, eik, nameAndLegalForm, orderNumber, uploadedStream, fileName, fileContentType, fileSize, remoteIP, getPortletConfig().getResourceBundle(locale));
				sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("profile.request.was.sent")));
				sessionBean.setCurrentPage(INDEX_PAGE);
				Logger.log(Logger.DEBUG_LEVEL, "multipartContentHandler(): MySpacePortlet.sendEmail=" + MySpacePortlet.sendEmail);
				Logger.log(Logger.DEBUG_LEVEL, "multipartContentHandler(): MySpacePortlet.fromAddress=" + MySpacePortlet.fromAddress);
				Logger.log(Logger.DEBUG_LEVEL, "multipartContentHandler(): MySpacePortlet.toAddress=" + MySpacePortlet.toAddress);
				
				/*
				 * Notifications.
				 */
				// Send email to DAEU approver(s).							
				if (MySpacePortlet.sendEmail) {								
					Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + CREATE_LEGAL_ENTITY_REQUEST_PROFILE_SUBMIT + ": sending mail...");
					try {
						notificationManager.notifyDAEUForCreatedRequestForLEProfile(result, getPortletConfig().getResourceBundle(locale));
					} catch (Exception e) {
						e.printStackTrace();
					}
				} 
				// Send email to the user, that the request for adding new LE was registered.
				try {
					notificationManager.notifyUserForCreatedRequestForLEProfile(result, sessionBean.getProfile(), getPortletConfig().getResourceBundle(locale));
				} catch (Exception e) {
					e.printStackTrace();
				}	
				
			} else if (isCreateLEFormSubmit) {
				Logger.log(Logger.DEBUG_LEVEL, "multipartContentHandler(): eik:" + eik);
				Logger.log(Logger.DEBUG_LEVEL, "multipartContentHandler(): nameAndLegalForm:" + nameAndLegalForm);
				Logger.log(Logger.DEBUG_LEVEL, "multipartContentHandler(): documentName:" + fileName);
				Logger.log(Logger.DEBUG_LEVEL, "multipartContentHandler(): documentContentType:" + fileContentType);
				Logger.log(Logger.DEBUG_LEVEL, "multipartContentHandler(): documentSize:" + fileSize);
				if (eik != null && eik.trim().length() > 0 && nameAndLegalForm != null && nameAndLegalForm.trim().length() > 0) {
					UserProfileManagement management = new UserProfileManagement();
					try {
						// Check we have already request for this EIK.
						UserProfileRequest userProfileRequest = management.loadNotApprovedUserProfileRequestByUserProfileIdAndEIK(sessionBean.getProfile().getId(), eik);
						if (userProfileRequest == null) {
							// Check user is already associated with profile with the given EIK.
							UserProfileRole[] roles = management.loadAllProfileRolesAndProfilesByUserUID(sessionBean.getUserProfile().getCurrentUserUID());
							boolean hasBeenAssigned = false;
							if (roles != null && roles.length > 0) {
								UserProfile tmpUP = null;
								for (int i = 0; i < roles.length; i++) {
									tmpUP = roles[i].getUserProfile(); 
									if (tmpUP != null && eik.equalsIgnoreCase(tmpUP.getEik())) {
										hasBeenAssigned = true;
										break;
									}
								}
							}
							if (!hasBeenAssigned) {  
								String[] result = management.createLegalEntityProfileRequest(sessionBean, eik, nameAndLegalForm, uploadedStream, fileName, fileContentType, fileSize, profileStructureType, profileStructureTypeOther, remoteIP, getPortletConfig().getResourceBundle(locale));
								sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("profile.request.was.sent")));
								sessionBean.setCurrentPage(INDEX_PAGE);
								Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + CREATE_LEGAL_ENTITY_REQUEST_PROFILE_SUBMIT + ": MySpacePortlet.sendEmail=" + MySpacePortlet.sendEmail);
								Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + CREATE_LEGAL_ENTITY_REQUEST_PROFILE_SUBMIT + ": MySpacePortlet.fromAddress=" + MySpacePortlet.fromAddress);
								Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + CREATE_LEGAL_ENTITY_REQUEST_PROFILE_SUBMIT + ": MySpacePortlet.toAddress=" + MySpacePortlet.toAddress);
								
								/*
								 * Notifications.
								 */
								// Send email to DAEU approver(s).							
								if (MySpacePortlet.sendEmail) {								
									Logger.log(Logger.DEBUG_LEVEL, "processAction() -> " + CREATE_LEGAL_ENTITY_REQUEST_PROFILE_SUBMIT + ": sending mail...");
									try {
										notificationManager.notifyDAEUForCreatedRequestForLEProfile(result, getPortletConfig().getResourceBundle(locale));
									} catch (Exception e) {
										e.printStackTrace();
									}
								} 
								// Send email to the user, that the request for adding new LE was registered.
								try {
									notificationManager.notifyUserForCreatedRequestForLEProfile(result, sessionBean.getProfile(), getPortletConfig().getResourceBundle(locale));
								} catch (Exception e) {
									e.printStackTrace();
								}	
							} else {
								sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("profile.request.already.assigned.to.profile")));
							}
						} else {
							sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("profile.request.duplicate.founded")));
						}
					} catch (Exception e) {
						e.printStackTrace();
						sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("profile.request.error")));
					}
					
				} else {
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("invalid.parameters")));
				}
			} else if (isAddAuthorizationSignFormSubmit && testEnvironment) {				
//				This code is not used as the multipart form submit is not used anymore, just for test from admin.
				AuthorizationsManagement management = new AuthorizationsManagement();
				int authorizationsId = management.createAuthorization(sessionBean, uploadedStream, fileName, fileContentType, fileSize, remoteIP, getPortletConfig().getResourceBundle(locale));
				if (authorizationsId > 0) {
					List<Message> messages = sessionBean.getMessages();
					messages.add(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("authorization.created.successfully")));
					sessionBean.setMessages(messages);
					sessionBean.setCurrentPage(AUTHORIZATIONS_PAGE);
					clearAuthorizationBeanData(sessionBean);
				} else {
					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("authorization.creation.error")));
				}
			} else if (isCancelAuthorizationFormSubmit) {
//				This code is not used as the multipart form submit is not used anymore.
//				AuthorizationsManagement management = new AuthorizationsManagement();
//				int authorizationsId = management.cancelAuthorization(sessionBean, uploadedStream, fileName, fileContentType, fileSize, remoteIP, getPortletConfig().getResourceBundle(locale));
//				if (authorizationsId > 0) {
//					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("authorization.cancel.successfully")));
//					sessionBean.setCurrentPage(AUTHORIZATIONS_PAGE);
//				} else {
//					sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("authorization.cancel.error")));
//				}
			}
			if (uploadedStream != null) {
				try {
					uploadedStream.close();
				} catch (Exception e) {}
			}
		} catch (Exception e) {
			if (uploadedStream != null) {
				try {
					uploadedStream.close();
				} catch (Exception e2) {}
			}
			System.out.println(e.getMessage());
			Logger.log(Logger.ERROR_LEVEL, "multipartContentHandler(): exception:" + e.getMessage());			
			sessionBean.setMessage(new Message(MySpaceConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("form.processing.error")));			

		}
	}	
	
	protected void doCustomConfigure(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		MySpacePortletSessionBean sessionBean = getSessionBean(request);
		if (sessionBean != null) {
			sessionBean.setMessage(null);
		} 
		// Set the MIME type for the render response
		response.setContentType(request.getResponseContentType());
		// Invoke the JSP to render
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, CONFIG_JSP));
		rd.include(request, response);
	}
 
	protected void doCustomEditDefaults(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		MySpacePortletSessionBean sessionBean = getSessionBean(request);
		if (sessionBean != null) {
			sessionBean.setMessage(null);
		}
		// Set the MIME type for the render response
		response.setContentType(request.getResponseContentType());
		// Invoke the JSP to render
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, EDIT_DEFAULTS_JSP));
		rd.include(request, response);
	}

	private static MySpacePortletSessionBean getSessionBean(PortletRequest request) {
		PortletSession session = request.getPortletSession();
		if (session == null)
			return null;
		MySpacePortletSessionBean sessionBean = (MySpacePortletSessionBean) session.getAttribute(SESSION_BEAN);
		if (sessionBean == null) {
			sessionBean = new MySpacePortletSessionBean();
			session.setAttribute(SESSION_BEAN, sessionBean);
		}		
		return sessionBean;
	}
	
	public static PumaHome getPumaHome() {
		return pumaHome;
	}

	public static PumaProfile getPumaProfile() {
		return pumaHome.getProfile();
	}

	public static PumaController getPumaController() {
		return pumaHome.getController();
	}

	public static NavigationSelectionModelHome getNavigationSelectionModelHome() {
		return navigationSelectionModelHome;
	}

	public static NavigationModelHome getNavigationModelHome() {
		return navigationModelHome;
	}
	
	public static PortletFriendlySelectionServiceHome getPortletFriendlySelectionServiceHome() {
		return portletFriendlySelectionServiceHome;
	}

	private String getPageFriendlyUrl(NavigationNode serviceCategoryPage, PortletRequest request, PortletResponse response) {
		PortletFriendlySelectionService portletFriendlySelectionService = null;
		Writer writer = null;
		String friendlyUrl = null;
		if (MySpacePortlet.getPortletFriendlySelectionServiceHome() != null) {
			try {
				portletFriendlySelectionService = MySpacePortlet.getPortletFriendlySelectionServiceHome().getPortletFriendlySelectionService(request,response);
				if (portletFriendlySelectionService != null) {
					writer = new StringWriter();
					if (portletFriendlySelectionService.write(writer, serviceCategoryPage)) {
						if (writer != null) {
							friendlyUrl = writer.toString();
							if (friendlyUrl != null) {
								if (friendlyUrl.endsWith("/")) {
									friendlyUrl = friendlyUrl.substring(0, friendlyUrl.length()-1);
								}
								if (friendlyUrl.lastIndexOf("/") != -1) {
									friendlyUrl = friendlyUrl.substring(friendlyUrl.lastIndexOf("/") + 1);
								}	
								friendlyUrl = URLDecoder.decode(friendlyUrl, "UTF-8");
							}
						}
					}
					// We need to dispose()!
					try {portletFriendlySelectionService.dispose();} catch (Exception e2) {}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return friendlyUrl;
	}
	
	private static String getJspFilePath(RenderRequest request, String jspFile) {
		String markup = request.getProperty("wps.markup");
		if (markup == null)
			markup = getMarkup(request.getResponseContentType());
		return JSP_FOLDER + markup + "/" + jspFile + "." + getJspExtension(markup);
	}

	private static String getMarkup(String contentType) {
		if ("text/vnd.wap.wml".equals(contentType))
			return "wml";
		else
			return "html";
	}

	private static String getJspExtension(String markupName) {
		return "jsp";
	}


}