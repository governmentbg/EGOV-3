package com.egov.workflow;

import java.util.Locale;

import com.ibm.workplace.wcm.api.Document;
import com.ibm.workplace.wcm.api.custom.CustomWorkflowAction;
import com.ibm.workplace.wcm.api.custom.CustomWorkflowActionFactory;

public class WorkflowFactory implements CustomWorkflowActionFactory {

	@Override
	public String[] getActionNames() {
		String names[] = { "populateInstitutionEkatteNumber" };

		return names;
	}

	@Override
	public String getActionTitle(Locale arg0, String arg1) {		
		return "\u041F\u043E\u043F\u0443\u043B\u0438\u0440\u0430\u043D\u0435 " +
				"\u043D\u0430 \u0415\u041A\u0410\u0422\u0422\u0415 \u0437\u0430 " +
				"\u043F\u0440\u043E\u0446\u0435\u0441 \u0418\u043D\u0441\u0442\u0438\u0442\u0443\u0446\u0438\u044F";		
	}

	@Override
	public String getActionDescription(Locale arg0, String arg1) {		
		return "\u0420\u0430\u0431\u043E\u0442\u0435\u043D \u043F\u0440\u043E\u0446\u0435\u0441 " +
				"(\u0418\u043D\u0441\u0442\u0438\u0442\u0443\u0446\u0438\u044F)";	
	}

	@Override
	public CustomWorkflowAction getAction(String arg0, Document arg1) {		
		return new WorkFlowAction();		
	}

	@Override
	public String getName() {
		return "WorkflowFactory";
	}

	@Override
	public String getTitle(Locale arg0) {
		return "\u0420\u0430\u0431\u043E\u0442\u0435\u043D \u043F\u0440\u043E\u0446\u0435\u0441 " +
				"(\u0418\u043D\u0441\u0442\u0438\u0442\u0443\u0446\u0438\u044F)";
	}



}