package com.egov.search.ext;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import com.egov.search.ext.utils.EgovSearchExtUtils;
import com.egov.search.ext.utils.Logger;
import com.egov.wcm.cache.EgovSearch;
import com.egov.wcm.cache.EgovService;
import com.egov.wcm.cache.EgovWCMCache;
import com.egov.wcm.cache.EgovWCMUtils;

/*
 *	This servlet is called for list page of:
 *  - Organizations or persons providing public services (Article 1 Paragraph 2)
 */

@WebServlet("/services-by-supplier-a1-p2") 
public class ServicesBySupplierA1P2 extends HttpServlet {
	
	// path is null when we call all services.
	private static final String PARAMETER_PATH = "path";	
	private static final String PARAMETER_QUERY = "q";	
	private static final String PARAMETER_SUPPLIER_ID = "supplierId";	
	private static final String PARAMETER_RESULTS_PER_PAGE = "rPP";	
	private static final String PARAMETER_CURRENT_PAGE = "cP";	
	private static final String PARAMETER_DEBUG = "debug";	
	
	
	private static final int RESULTS_PER_PAGE = 10;
	private static final int CURRENT_PAGE = 1;
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	private static final long serialVersionUID = 1L;
	public boolean isDebug = false;

	public ServicesBySupplierA1P2() {
		super();
	}
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		getContents(request, response);
	}

	private void getContents(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");		
		response.setContentType("application/json; charset=UTF-8");
		
		// ex. egov/dostavchitsi na uslugi/organizatsii i litsa, predostavyashti obshtestveni uslugi/universiteti
		String path = request.getParameter(PARAMETER_PATH);		
		String q = request.getParameter(PARAMETER_QUERY);		
		String supplierId = request.getParameter(PARAMETER_SUPPLIER_ID);		
		int resultsPerPage = RESULTS_PER_PAGE;
		int currentPage = CURRENT_PAGE;
		isDebug = "true".equalsIgnoreCase(request.getParameter(PARAMETER_DEBUG));
		
		try {
			if (request.getParameter(PARAMETER_RESULTS_PER_PAGE) != null) {
				resultsPerPage = Integer.parseInt(request.getParameter(PARAMETER_RESULTS_PER_PAGE));
			}
		} catch (Exception e) {}
		try {
			if (request.getParameter(PARAMETER_CURRENT_PAGE) != null) {
				currentPage = Integer.parseInt(request.getParameter(PARAMETER_CURRENT_PAGE));
			}
		} catch (Exception e) {}
		
		Logger.log(isDebug, "ServicesBySupplierA1P2 -> getContents() -> path=" + path);
		Logger.log(isDebug, "ServicesBySupplierA1P2 -> getContents() -> q=" + q);
		Logger.log(isDebug, "ServicesBySupplierA1P2 -> getContents() -> supplierId=" + supplierId);
		Logger.log(isDebug, "ServicesBySupplierA1P2 -> getContents() -> resultsPerPage=" + resultsPerPage);
		Logger.log(isDebug, "ServicesBySupplierA1P2 -> getContents() -> currentPage=" + currentPage);
		Logger.log(isDebug, "ServicesBySupplierA1P2 -> getContents() -> debug=" + request.getParameter(PARAMETER_DEBUG));
		
		JSONObject json = new JSONObject();
		JSONArray ja = new JSONArray(); 	
		
//		if (path == null) {			
//			json.put("data", ja);
//			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
//			response.getWriter().print(jsonPrettyPrintString);
//			response.getWriter().flush();
//			response.getWriter().close();	
//			return;
//		} 
		if (path != null) {
			path = path.toLowerCase();
		}
		int totalPages = 0;	
		int totalResults = 0;
		try {	
			String contentPath = "";
			EgovSearch egovSearch = new EgovSearch();
			
			// This will split the section name in "организации","лица", which will return all services for article1paragraph2.
			List<EgovService> loadedServices = egovSearch.searchServicesBySectionNameAr("организации лица");
			List<EgovService> services = new ArrayList<EgovService>();
			EgovService service = null;
			if (loadedServices != null && loadedServices.size() > 0 && path != null && path.trim().length() > 0) {
				// contentPath (ex.) /eGovBG/egov/dostavchitsi na uslugi/organizatsii i litsa, predostavyashti obshtestveni uslugi/universiteti/unificirani uslugi/820001
				for (int i = 0; i < loadedServices.size(); i++) {
					service = loadedServices.get(i);
					contentPath = service.getContentPath().toLowerCase().replace("/" + EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME.toLowerCase() + "/", "");
					if (supplierId != null && supplierId.trim().length() > 0) {
						
						// contentPath (ex.) /eGovBG/egov/dostavchitsi na uslugi/organizatsii i litsa, predostavyashti obshtestveni uslugi/universiteti/unificirani uslugi/820001
						// contentPath (ex.) /eGovBG/egov/dostavchitsi na uslugi/organizatsii i litsa, predostavyashti obshtestveni uslugi/universiteti/uslugi-unwe/820001
						if (contentPath.startsWith(path + "/" + EgovWCMCache.SERVICES_SITE_AREA_NAME_UNIFIED_SERVICES + "/")
							|| contentPath.startsWith(path + "/" + EgovWCMCache.SERVICES_SITE_AREA_NAME_BY_SUPPLIER_PREFIX + supplierId + "/")) {
							services.add(service);
						}
					}
					if (contentPath.startsWith(path)) {
						services.add(service);
					}
				}
			}
			
			if (services != null && services.size() > 0) {
				EgovWCMUtils utils = new EgovWCMUtils();
				if (q != null && q.trim().length() > 0) {        					
					Logger.log(isDebug, "q != null && q.trim().length() > 0 -> going to filter (before=" + services.size() + ")");
					// Order by higher match.
					services = utils.orderBySeachTerm(services, q.toLowerCase()); 
					Logger.log(isDebug, "q != null && q.trim().length() > 0 -> going to filter (after=" + services.size() + ")");
				} else {
					services = utils.orderByTitle(services);
				}
				if (services != null && services.size() > 0) { 
					JSONArray tmpJA = null;
					Long dateTime = null;
					for (int i = (currentPage - 1) * resultsPerPage, j = 0; i < services.size(); i++, j++) {
						if (j == resultsPerPage) {break;}
						tmpJA = new JSONArray();
						service = services.get(i);
						contentPath = service.getContentPath().toLowerCase().replace("/" + EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME.toLowerCase() + "/", "");
						Logger.log(isDebug, "contentPath=" + contentPath);
						dateTime = service.getModifiedDate() != null ? service.getModifiedDate().getTime() : (service.getPublishedDate() != null ? service.getPublishedDate().getTime() : null);
						tmpJA.put(service.getId());
						tmpJA.put(service.getName()); 
						tmpJA.put(service.getTitle());
						tmpJA.put(dateTime != null ? EgovSearchExtUtils.timeMillisToDate(dateTime) : "");
						tmpJA.put(EgovWCMCache.getATUnifiedService().getName().equalsIgnoreCase(service.getAuthoringTemplateName()) ? EgovWCMCache.getATUnifiedService().getName() : EgovWCMCache.getATServiceProvidedBySupplier().getName());
						tmpJA.put(contentPath);						
						ja.put(tmpJA);
					}
					totalResults = services.size();
					totalPages = (totalResults % resultsPerPage == 0) ? totalResults / resultsPerPage : (totalResults / resultsPerPage) + 1;
					
				}
			}
		}	catch (Exception e) {
			Logger.log(isDebug, "ServicesBySupplierA1P2 -> getContents() : ERROR " + e.getMessage());
			e.printStackTrace();
		}
		json.put("totalPages", totalPages);
		json.put("totalResults", totalResults);
		json.put("data", ja);
		
		String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
		response.getWriter().print(jsonPrettyPrintString);
		response.getWriter().flush();
		response.getWriter().close();	
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	public static void main(String[] args) {
		String path = "egov/dostavchitsi na uslugi/organizatsii i litsa, predostavyashti obshtestveni uslugi/universiteti".toLowerCase();
		String contentPath = "/eGovBG/egov/dostavchitsi na uslugi/organizatsii i litsa, predostavyashti obshtestveni uslugi/universiteti/unificirani uslugi/820001";
		contentPath = contentPath.toLowerCase().replace("/" + EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME.toLowerCase() + "/", "");
		System.out.println(contentPath);
		if (contentPath.startsWith(path)) {
			System.out.println("MATCH");
		}
	}
}
