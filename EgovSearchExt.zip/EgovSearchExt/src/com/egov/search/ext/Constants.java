package com.egov.search.ext;

public class Constants {
	public static String _PRODUCT_NAME = "EGOV Search Ext ";
	public static String _PRODUCT_VERSION = "1.1";

	public static int _LOGLEVEL = 2;
}
