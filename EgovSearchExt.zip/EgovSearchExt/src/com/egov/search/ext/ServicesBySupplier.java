package com.egov.search.ext;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import com.egov.search.ext.utils.EgovSearchExtUtils;
import com.egov.search.ext.utils.Logger;
import com.egov.wcm.cache.EgovService;
import com.egov.wcm.cache.EgovWCMCache;
import com.egov.wcm.cache.EgovWCMUtils;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentIterator;
import com.ibm.workplace.wcm.api.DocumentLibrary;
import com.ibm.workplace.wcm.api.DocumentTypes;
import com.ibm.workplace.wcm.api.Workspace;
import com.ibm.workplace.wcm.api.query.Conjunction;
import com.ibm.workplace.wcm.api.query.Disjunction;
import com.ibm.workplace.wcm.api.query.PageIterator;
import com.ibm.workplace.wcm.api.query.ProfileSelectors;
import com.ibm.workplace.wcm.api.query.Query;
import com.ibm.workplace.wcm.api.query.QueryDepth;
import com.ibm.workplace.wcm.api.query.ResultIterator;
import com.ibm.workplace.wcm.api.query.Selectors;
import com.ibm.workplace.wcm.api.query.SortDirection;
import com.ibm.workplace.wcm.api.query.Sorts;
import com.ibm.workplace.wcm.api.query.WorkflowSelectors;

/*
 *	This servlet is called for list page of:
 *  - Central Administrations
 *  - Specialized Territorial
 *  - Regional
 *  - Municipality
 *  - AreaMunicipality  
 *  - AllAdministrations
 */

@WebServlet("/services-by-supplier")
public class ServicesBySupplier extends HttpServlet {
	
	private static final String PARAMETER_PATH = "path";	
	private static final String PARAMETER_TYPE = "type";	
	private static final String PARAMETER_QUERY = "q";	
	private static final String PARAMETER_SUPPLIER_ID = "supplierId";	
	private static final String PARAMETER_RESULTS_PER_PAGE = "rPP";	
	private static final String PARAMETER_CURRENT_PAGE = "cP";	
	private static final String PARAMETER_DEBUG = "debug";	
	
	private static final String TYPE_TERRITORIAL_ADMINISTRATION = "2";	
	private static final String TYPE_AREA_MUNICIPALITY_ADMINISTRATION = "3";	
	
	private static final int RESULTS_PER_PAGE = 10;
	private static final int CURRENT_PAGE = 1;
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	private static final long serialVersionUID = 1L;
	public boolean isDebug = false;

	public ServicesBySupplier() {
		super();
	}
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		getContents(request, response);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void getContents(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");		
		response.setContentType("application/json; charset=UTF-8");
		
		String path = request.getParameter(PARAMETER_PATH);		
		String type = request.getParameter(PARAMETER_TYPE);		
		String q = request.getParameter(PARAMETER_QUERY);		
		String supplierId = request.getParameter(PARAMETER_SUPPLIER_ID);		
		int resultsPerPage = RESULTS_PER_PAGE;
		int currentPage = CURRENT_PAGE;
		isDebug = "true".equalsIgnoreCase(request.getParameter(PARAMETER_DEBUG));
		
		try {
			if (request.getParameter(PARAMETER_RESULTS_PER_PAGE) != null) {
				resultsPerPage = Integer.parseInt(request.getParameter(PARAMETER_RESULTS_PER_PAGE));
			}
		} catch (Exception e) {}
		try {
			if (request.getParameter(PARAMETER_CURRENT_PAGE) != null) {
				currentPage = Integer.parseInt(request.getParameter(PARAMETER_CURRENT_PAGE));
			}
		} catch (Exception e) {}
		
		Logger.log(isDebug, "ServicesBySupplier -> getContents() -> path=" + path);
		Logger.log(isDebug, "ServicesBySupplier -> getContents() -> type=" + type);
		Logger.log(isDebug, "ServicesBySupplier -> getContents() -> q=" + q);
		Logger.log(isDebug, "ServicesBySupplier -> getContents() -> supplierId=" + supplierId);
		Logger.log(isDebug, "ServicesBySupplier -> getContents() -> resultsPerPage=" + resultsPerPage);
		Logger.log(isDebug, "ServicesBySupplier -> getContents() -> currentPage=" + currentPage);
		Logger.log(isDebug, "ServicesBySupplier -> getContents() -> debug=" + request.getParameter(PARAMETER_DEBUG));
		
		JSONObject json = new JSONObject();
		JSONArray ja = new JSONArray(); 	
		
		if (path == null && supplierId == null) {			
			json.put("data", ja);
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
			response.getWriter().print(jsonPrettyPrintString);
			response.getWriter().flush();
			response.getWriter().close();	
			return;
		} 
		
		int totalPages = 0;	
		int totalResults = 0;
		String saName = "";
		boolean hasResults = false;
		try {	
			Query query = null;
			if (supplierId != null && TYPE_TERRITORIAL_ADMINISTRATION.equals(type)) {
				Logger.log(isDebug, "if (supplierId != null && TYPE_TERRITORIAL_ADMINISTRATION.equals(type)) { : supplierId = " + supplierId);
				query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
    			query.addSelector(Selectors.nameEquals(supplierId));
    			// By default, all of them are published.
    			query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
    			// Load only others templates.
    			query.addSelector(
    				Selectors.authoringTemplateIn(
    					new DocumentId[] {
    						EgovWCMCache.getATAdditionalDataOfServiceProvidedBySupplier().getId()
    					}
    				)
    			);
//    			query.returnObjects();
    			query.returnIds();
    			ResultIterator resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);
        		if (resultIterator.hasNext()) { 
        			Logger.log(isDebug, "resultIterator.hasNext()");
        			List<String> names = new ArrayList<String>();
//        			Content content = null;
        			DocumentId docId = null;
        			String contentPath = null;
        			while (resultIterator.hasNext()) {
//        				content = (Content)resultIterator.next();
//        				names.add(content.getParentId().getName().replace(EgovWCMCache.SERVICES_SITE_AREA_NAME_UNIFIED_SERVICE_SUFFIX, ""));
        				docId = (DocumentId)resultIterator.next();
        				contentPath = EgovWCMCache.getWorkspace().getPathById(docId, false, true);
        				contentPath = contentPath.substring(0, contentPath.lastIndexOf("/"));
        				contentPath = contentPath.substring(contentPath.lastIndexOf("/") + 1);
        				contentPath = contentPath.replace(EgovWCMCache.SERVICES_SITE_AREA_NAME_UNIFIED_SERVICE_SUFFIX, "");
        				names.add(contentPath);
        				//Logger.log(isDebug, "path=" + EgovWCMCache.getWorkspace().getPathById(docId, false, true));
        			}
        			
        			// Load result from cache.
        			List<EgovService> unifiedServices = EgovWCMCache.getUnifiedServices();
        			if (unifiedServices != null && unifiedServices.size() > 0) {
        				List<EgovService> foundedServices = new ArrayList<>();
        				EgovService egovService = null;
        				for (int i = 0; i < names.size(); i++) {
        					egovService = EgovWCMCache.getServiceByName().get(names.get(i));
        					if (egovService != null) {
        						foundedServices.add(egovService);
        					} 
        				}
        				EgovWCMUtils utils = new EgovWCMUtils();
        				if (q != null && q.trim().length() > 0) {        					
        					Logger.log(isDebug, "q != null && q.trim().length() > 0 -> going to filter (before=" + foundedServices.size() + ")");
							// Order by higher match.
        					foundedServices = utils.orderBySeachTerm(foundedServices, q.toLowerCase()); 
        					Logger.log(isDebug, "q != null && q.trim().length() > 0 -> going to filter (after=" + foundedServices.size() + ")");
						} else {
							foundedServices = utils.orderByTitle(foundedServices);
						}
						if (foundedServices.size() > 0) {
							JSONArray tmpJA = null;
							EgovService service = null;		
							Long dateTime = null;
							for (int i = (currentPage - 1) * resultsPerPage, j = 0; i < foundedServices.size(); i++, j++) {
								if (j == resultsPerPage) {break;}
								tmpJA = new JSONArray();
								service = foundedServices.get(i);
								dateTime = service.getModifiedDate() != null ? service.getModifiedDate().getTime() : (service.getPublishedDate() != null ? service.getPublishedDate().getTime() : null);
								tmpJA.put(service.getId());
								tmpJA.put(service.getName()); 
								tmpJA.put(service.getTitle());
								tmpJA.put(dateTime != null ? EgovSearchExtUtils.timeMillisToDate(dateTime) : "");
								tmpJA.put(EgovWCMCache.getATUnifiedService().getName().equalsIgnoreCase(service.getAuthoringTemplateName()) ? EgovWCMCache.getATUnifiedService().getName() : EgovWCMCache.getATServiceProvidedBySupplier().getName());
								tmpJA.put(service.getParentName());
								tmpJA.put(service.getType());
								ja.put(tmpJA);
							}
							totalResults = foundedServices.size();
							totalPages = (totalResults % resultsPerPage == 0) ? totalResults / resultsPerPage : (totalResults / resultsPerPage) + 1;
						} else {
							totalResults = 0;
							totalPages = 0;
						}
						json.put("sa", saName);
						json.put("totalPages", totalPages);
						json.put("totalResults", totalResults);
						json.put("data", ja);
						
						String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
						response.getWriter().print(jsonPrettyPrintString);
						response.getWriter().flush();
						response.getWriter().close();	
						return;
        			} 
        			
        			//If we are here, no cache is loaded yet, so we query the WCM database.
        			query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
        			Conjunction and = new Conjunction();
        			and.add(Selectors.nameIn(names));
        			// By default, all of them are published.
        			and.add(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
    				// Load only others templates.
        			and.add(
    					Selectors.authoringTemplateIn(
    						new DocumentId[] {
    							EgovWCMCache.getATUnifiedService().getId()
    						}
    					)
    				);
        			// load only 'active' services.			
					Disjunction or = new Disjunction();
					or.add(ProfileSelectors.categoriesContains(EgovWCMCache.getCategoryCommonActive().getId()));
					or.add(ProfileSelectors.categoriesContains(EgovWCMCache.getCategoryServiceStatusActive().getId()));
					and.add(or);
					
					if (q != null && q.trim().length() > 0) {
						String searchTerm = q;
						if (searchTerm != null && searchTerm.trim().length() > 0) {
							// Stupid IBM function does not support case insensitive!
							or = new Disjunction();
							or.add(Selectors.titleLike("%" + searchTerm + "%"));
							or.add(Selectors.titleLike("%" + searchTerm.toLowerCase() + "%"));
							or.add(Selectors.titleLike("%" + searchTerm.toUpperCase() + "%"));
							if (searchTerm.trim().length() > 1) {
								if (!Character.isUpperCase(searchTerm.charAt(0))) {
									or.add(Selectors.titleLike("%" + searchTerm.substring(0, 1).toUpperCase() + searchTerm.substring(1) + "%"));
								}
								or.add(Selectors.titleLike("%" + EgovSearchExtUtils.capitalizeString(searchTerm.trim()) + "%"));
							}
							or.add(Selectors.nameLike("%" + searchTerm + "%"));
							and.add(or);
						}
					} else {
						query.addSort(Sorts.byTitle(SortDirection.ASCENDING));
					}					    				
    				query.addSelector(and);				    				
    				query.returnIds();  
    				hasResults = true;
        		} 
			} else if (TYPE_AREA_MUNICIPALITY_ADMINISTRATION.equals(type)) {
				// Check we have data in cache.
				List<EgovService> unifiedServices = EgovWCMCache.getUnifiedServices();
				if (unifiedServices != null && unifiedServices.size() > 0) {
					List<EgovService> areaMunicipalServices = new ArrayList<>();
					boolean hasCacheData = false;
					for (int i = 0; i < unifiedServices.size(); i++) {
						if (EgovWCMCache.CATEGORY_PROVIDER_TYPE_AREA_MUNICIPAL_NAME.equalsIgnoreCase(unifiedServices.get(i).getType())
								|| EgovWCMCache.CATEGORY_PROVIDER_TYPE_ALL_ADMINISTRATIONS_NAME.equalsIgnoreCase(unifiedServices.get(i).getType())) {
							hasCacheData = true;
							// If we have search term, filter by it too.
							if (q != null && q.trim().length() > 0) {
								if (unifiedServices.get(i).getTitle().toLowerCase().indexOf(q.toLowerCase()) != -1 
										|| unifiedServices.get(i).getName().toLowerCase().indexOf(q.toLowerCase()) != -1) {
									areaMunicipalServices.add(unifiedServices.get(i));
								}
								continue;
							}
							areaMunicipalServices.add(unifiedServices.get(i));
						}
					}
					// We have data in cache.
					if (hasCacheData) {
						EgovWCMUtils utils = new EgovWCMUtils();
						if (q != null && q.trim().length() > 0) {
							// Order by higher match.
							areaMunicipalServices = utils.orderBySeachTerm(areaMunicipalServices, q.toLowerCase()); 
						} else {
							areaMunicipalServices = utils.orderByTitle(areaMunicipalServices);
						}
						if (areaMunicipalServices.size() > 0) {
							JSONArray tmpJA = null;
							EgovService service = null;	
							Long dateTime = null;
							for (int i = (currentPage - 1) * resultsPerPage, j = 0; i < areaMunicipalServices.size(); i++, j++) {
								if (j == resultsPerPage) {break;}
								tmpJA = new JSONArray();
								service = areaMunicipalServices.get(i);
								dateTime = service.getModifiedDate() != null ? service.getModifiedDate().getTime() : (service.getPublishedDate() != null ? service.getPublishedDate().getTime() : null);
								tmpJA.put(service.getId());
								tmpJA.put(service.getName()); 
								tmpJA.put(service.getTitle());
								tmpJA.put(dateTime != null ? EgovSearchExtUtils.timeMillisToDate(dateTime) : "");
								tmpJA.put(EgovWCMCache.getATUnifiedService().getName().equalsIgnoreCase(service.getAuthoringTemplateName()) ? EgovWCMCache.getATUnifiedService().getName() : EgovWCMCache.getATServiceProvidedBySupplier().getName());
								tmpJA.put(service.getParentName());
								tmpJA.put(service.getType());
								ja.put(tmpJA);
							}
							totalResults = areaMunicipalServices.size();
							totalPages = (totalResults % resultsPerPage == 0) ? totalResults / resultsPerPage : (totalResults / resultsPerPage) + 1;
						} else {
							totalResults = 0;
							totalPages = 0;
						}
					}
					json.put("sa", saName);
					json.put("totalPages", totalPages);
					json.put("totalResults", totalResults);
					json.put("data", ja);
					
					String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
					response.getWriter().print(jsonPrettyPrintString);
					response.getWriter().flush();
					response.getWriter().close();	
					return;
				}
				
				// No data found in cache, so query WCM database.
				query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
    			query.addSelector(Selectors.nameIn(EgovWCMCache.AREA_MUNICIPALITIES_NAMES));
    			// By default, all of them are published.
    			query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
    			// Load only others templates.
    			query.addSelector(
    				Selectors.authoringTemplateIn(
    					new DocumentId[] {
    						EgovWCMCache.getATAdditionalDataOfServiceProvidedBySupplier().getId()
    					}
    				)
    			);
    			query.returnObjects();
    			ResultIterator resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);
        		if (resultIterator.hasNext()) {    			
        			List<String> names = new ArrayList<String>();
        			Content content = null;
        			while (resultIterator.hasNext()) {
        				content = (Content)resultIterator.next();
        				names.add(content.getParentId().getName().replace(EgovWCMCache.SERVICES_SITE_AREA_NAME_UNIFIED_SERVICE_SUFFIX, ""));
        			}
        			query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
        			Conjunction and = new Conjunction();
        			and.add(Selectors.nameIn(names));
        			// By default, all of them are published.
        			and.add(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
    				// Load only others templates.
        			and.add(
    					Selectors.authoringTemplateIn(
    						new DocumentId[] {
    							EgovWCMCache.getATUnifiedService().getId()
    						}
    					)
    				);
        			// load only 'active' services.			
					Disjunction or = new Disjunction();
					or.add(ProfileSelectors.categoriesContains(EgovWCMCache.getCategoryCommonActive().getId()));
					or.add(ProfileSelectors.categoriesContains(EgovWCMCache.getCategoryServiceStatusActive().getId()));
					and.add(or);
					
					if (q != null && q.trim().length() > 0) {
						String searchTerm = q;
						if (searchTerm != null && searchTerm.trim().length() > 0) {
							// Stupid IBM function does not support case insensitive!
							or = new Disjunction();
							or.add(Selectors.titleLike("%" + searchTerm + "%"));
							or.add(Selectors.titleLike("%" + searchTerm.toLowerCase() + "%"));
							or.add(Selectors.titleLike("%" + searchTerm.toUpperCase() + "%"));
							if (searchTerm.trim().length() > 1) {
								if (!Character.isUpperCase(searchTerm.charAt(0))) {
									or.add(Selectors.titleLike("%" + searchTerm.substring(0, 1).toUpperCase() + searchTerm.substring(1) + "%"));
								}
								or.add(Selectors.titleLike("%" + EgovSearchExtUtils.capitalizeString(searchTerm.trim()) + "%"));
							}
							or.add(Selectors.nameLike("%" + searchTerm + "%"));
							and.add(or);
						}
					} else {
						query.addSort(Sorts.byTitle(SortDirection.ASCENDING));
					}					    				
    				query.addSelector(and);				    				
    				query.returnIds();  
    				hasResults = true;
        		} 
			} else {
				// Check we have data in cache.
				List<EgovService> services = TYPE_TERRITORIAL_ADMINISTRATION.equals(type) ? EgovWCMCache.getUnifiedServices() : EgovWCMCache.getServicesByProvider(); 
				if (services != null && services.size() > 0) {
					List<EgovService> foundedServices = new ArrayList<>();
					boolean hasCacheData = false;
					String servicePath = null;
					boolean inAllAdministrationsPath = false;
					String suffix = (path != null && !path.endsWith("/")) ? "/" : "";
					
					/*
					 * Central Administration path (for ex. Customs Agency)
					 * path=egov/dostavchitsi na uslugi/agentsii, sazdadeni sas zakon/uslugi-199
					 * 
					 * Territorial Administration path (for ex. Baseynova Direktsia)
					 * path=egov/dostavchitsi na uslugi/spetsializirani teritorialni administratsii/baseynova direktsia
					 */
					for (int i = 0; i < services.size(); i++) {
						servicePath = services.get(i).getContentPath();
						// We should always have the services provided by "All administrations".
						if (servicePath != null && servicePath.toLowerCase().indexOf(path.toLowerCase() + suffix) != -1) {
							if (EgovWCMCache.CATEGORY_PROVIDER_TYPE_ALL_ADMINISTRATIONS_NAME.equalsIgnoreCase(services.get(i).getType())) {
								inAllAdministrationsPath = true;
							}
							Logger.log(isDebug, "servicePath = " + servicePath);
							hasCacheData = true;
							// If we have search term, filter by it too.
							if (q != null && q.trim().length() > 0) {
								if (services.get(i).getTitle().toLowerCase().indexOf(q.toLowerCase()) != -1 
										|| services.get(i).getName().toLowerCase().indexOf(q.toLowerCase()) != -1) {
									foundedServices.add(services.get(i));
								}
								continue;
							}
							foundedServices.add(services.get(i));
						}
					}
					
					if (!inAllAdministrationsPath) {
						List<EgovService> servicesByAllAdministrations = new ArrayList<>();					
						List<EgovService> unifiedServices = EgovWCMCache.getUnifiedServices();
						if (unifiedServices != null && unifiedServices.size() > 0) {
							for (int i = 0; i < unifiedServices.size(); i++) {
								if (EgovWCMCache.CATEGORY_PROVIDER_TYPE_ALL_ADMINISTRATIONS_NAME.equalsIgnoreCase(unifiedServices.get(i).getType())) {
									servicesByAllAdministrations.add(unifiedServices.get(i));
								}								
							}
						}
						if (servicesByAllAdministrations != null && servicesByAllAdministrations.size() > 0) {
							hasCacheData = true;
							for (int i = 0; i < servicesByAllAdministrations.size(); i++) {
								// If we have search term, filter by it too.
								if (q != null && q.trim().length() > 0) {
									if (servicesByAllAdministrations.get(i).getTitle().toLowerCase().indexOf(q.toLowerCase()) != -1 
											|| servicesByAllAdministrations.get(i).getName().toLowerCase().indexOf(q.toLowerCase()) != -1) {
										foundedServices.add(servicesByAllAdministrations.get(i));
									}
									continue;
								}
								foundedServices.add(servicesByAllAdministrations.get(i));
							}
							servicesByAllAdministrations.clear();
						}
					}
					
					// We have data in cache.
					if (hasCacheData) {
						EgovWCMUtils utils = new EgovWCMUtils();
						if (q != null && q.trim().length() > 0) {
							// Order by higher match.
							foundedServices = utils.orderBySeachTerm(foundedServices, q.toLowerCase()); 
						} else {
							// Order by title.  
							foundedServices = utils.orderByTitle(foundedServices); 
						}
						if (foundedServices.size() > 0) {
							JSONArray tmpJA = null;
							EgovService service = null;	
							Long dateTime = null;
							for (int i = (currentPage - 1) * resultsPerPage, j = 0; i < foundedServices.size(); i++, j++) {
								if (j == resultsPerPage) {break;}
								tmpJA = new JSONArray();
								service = foundedServices.get(i);
								dateTime = service.getModifiedDate() != null ? service.getModifiedDate().getTime() : (service.getPublishedDate() != null ? service.getPublishedDate().getTime() : null);
								tmpJA.put(service.getId());
								tmpJA.put(service.getName()); 
								tmpJA.put(service.getTitle());
								tmpJA.put(dateTime != null ? EgovSearchExtUtils.timeMillisToDate(dateTime) : "");
								tmpJA.put(EgovWCMCache.getATUnifiedService().getName().equalsIgnoreCase(service.getAuthoringTemplateName()) ? EgovWCMCache.getATUnifiedService().getName() : EgovWCMCache.getATServiceProvidedBySupplier().getName());
								tmpJA.put(service.getParentName());
								tmpJA.put(service.getType());
								ja.put(tmpJA);
							}
							totalResults = foundedServices.size();
							totalPages = (totalResults % resultsPerPage == 0) ? totalResults / resultsPerPage : (totalResults / resultsPerPage) + 1;
						} else {
							totalResults = 0;
							totalPages = 0;
						}
						foundedServices.clear();
					}
					
					json.put("sa", saName);
					json.put("totalPages", totalPages);
					json.put("totalResults", totalResults);
					json.put("data", ja);
					
					String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
					response.getWriter().print(jsonPrettyPrintString);
					response.getWriter().flush();
					response.getWriter().close();	
					return;
					
				}
				
				// No data found in cache, so query WCM database.
				
				// Get target siteArea.
				DocumentId siteArea = null;
				DocumentIdIterator iterator = EgovWCMCache.getWorkspace().findAllByPath(path, DocumentTypes.SiteArea, Workspace.WORKFLOWSTATUS_PUBLISHED, new DocumentLibrary[] { EgovWCMCache.getWorkspace().getDocumentLibrary(EgovWCMCache.EGOV_CONTENT_LIBRARY_NAME)});
				if (iterator.hasNext()) { // Site area found.									
					siteArea = iterator.next();
					saName = siteArea.getName();
					Logger.log(isDebug, "ServicesBySupplier -> getContents(): SA founded!");
				}
				
				if (siteArea == null) {
					Logger.log(true, "ServicesBySupplier -> getContents(): SA not found [" + path + "]!");
					json.put("data", ja);
					String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
					response.getWriter().print(jsonPrettyPrintString);
					response.getWriter().flush();
					response.getWriter().close();	
					return;
				}
				Conjunction and = new Conjunction();
				query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
				query.addParentId(siteArea, TYPE_TERRITORIAL_ADMINISTRATION.equals(type) ? QueryDepth.DESCENDANTS : QueryDepth.CHILDREN);
				// By default, all of them are published.
				and.add(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
				// Load only services.
				and.add(
						Selectors.authoringTemplateIn(
							new DocumentId[] {
									EgovWCMCache.getATUnifiedService().getId(),
									EgovWCMCache.getATServiceProvidedBySupplier().getId()
							}
						)
				);
				// load only 'active' services.			
				Disjunction or = new Disjunction();
				or.add(ProfileSelectors.categoriesContains(EgovWCMCache.getCategoryCommonActive().getId()));
				or.add(ProfileSelectors.categoriesContains(EgovWCMCache.getCategoryServiceStatusActive().getId()));
				and.add(or);
							
				if (q != null && q.trim().length() > 0) {
					String searchTerm = q;
					if (searchTerm != null && searchTerm.trim().length() > 0) {
						// Stupid IBM function does not support case insensitive!
						or = new Disjunction();
						or.add(Selectors.titleLike("%" + searchTerm + "%"));
						or.add(Selectors.titleLike("%" + searchTerm.toLowerCase() + "%"));
						or.add(Selectors.titleLike("%" + searchTerm.toUpperCase() + "%"));
						if (searchTerm.trim().length() > 1) {
							if (!Character.isUpperCase(searchTerm.charAt(0))) {
								or.add(Selectors.titleLike("%" + searchTerm.substring(0, 1).toUpperCase() + searchTerm.substring(1) + "%"));
							}
							or.add(Selectors.titleLike("%" + EgovSearchExtUtils.capitalizeString(searchTerm.trim()) + "%"));
						}
						or.add(Selectors.nameLike("%" + searchTerm + "%"));
						and.add(or);
					}
				} else {
					query.addSort(Sorts.byTitle(SortDirection.ASCENDING));
				}
				query.addSelector(and);
				query.returnIds(); 
				hasResults = true;
			}
			PageIterator pageIterator = hasResults ? EgovWCMCache.getWorkspace().getQueryService().execute(query, resultsPerPage, currentPage) : null;			
			ArrayList<DocumentId> tmpIdArr = new ArrayList<>();
			JSONArray tmpJA = null; 
			if (pageIterator != null && pageIterator.hasNext()) {				
				Content content = null;
				ResultIterator docIterator = null;
				DocumentId contentDocId = null;
				int page = 0;
				docIterator = (ResultIterator) pageIterator.next();								
				Logger.log(isDebug, "ServicesBySupplier -> getContents() -> page=" + page);
				while (docIterator.hasNext()) {
					contentDocId = (DocumentId)docIterator.next();
					tmpIdArr.add(contentDocId);
					Logger.log(isDebug, "ServicesBySupplier -> getContents() -> name=" + contentDocId.getName());							
				}
				DocumentId[] docIds = tmpIdArr.toArray(new DocumentId[tmpIdArr.size()]);
				DocumentIdIterator documentIdIterator = EgovWCMCache.getWorkspace().createDocumentIdIterator(docIds);
				DocumentIterator documentIterator = EgovWCMCache.getWorkspace().getByIds(documentIdIterator, true, false);
				int contents = 0;
				Long dateTime = null;
				while (documentIterator.hasNext()) {
					content = (Content) documentIterator.next();
					dateTime = content.getModifiedDate() != null ? content.getModifiedDate().getTime() : (content.getPublishedDate() != null ? content.getPublishedDate().getTime() : null);
					Logger.log(isDebug, "ServicesBySupplier -> getContents() -> title=" + content.getTitle());
					tmpJA = new JSONArray();
					tmpJA.put(content.getId().getID());
					tmpJA.put(content.getName());
					tmpJA.put(content.getTitle());
					tmpJA.put(dateTime != null ? EgovSearchExtUtils.timeMillisToDate(dateTime) : "");
					tmpJA.put(EgovWCMCache.getATUnifiedService().getId().getID().equalsIgnoreCase(content.getAuthoringTemplateID().getID()) ? EgovWCMCache.getATUnifiedService().getName() : EgovWCMCache.getATServiceProvidedBySupplier().getName());
					tmpJA.put(content.getParentId().getName());
					ja.put(tmpJA);
					contents++;
				}
				if (pageIterator.hasNext()) {
					contents = 0;
					while (pageIterator.hasNext()) {
						docIterator = (ResultIterator) pageIterator.next();
						page++;
						Logger.log(isDebug, "ServicesBySupplier -> getContents() -> page++=" + page);
					}
					while (docIterator.hasNext()) {
						Logger.log(isDebug, "ServicesBySupplier -> getContents() -> contents++=" + contents);
						docIterator.next();
						contents++;
					}					
				} 
				totalPages = currentPage + page;
				totalResults = ((totalPages * resultsPerPage) - resultsPerPage) + contents;
				Logger.log(isDebug, "ServicesBySupplier -> getContents() -> totalPages=" + totalPages);
			}
			
		} catch (Exception e) {
			Logger.log(isDebug, "ServicesBySupplier -> getContents() : ERROR " + e.getMessage());
			e.printStackTrace();
		}			
		json.put("sa", saName);
		json.put("totalPages", totalPages);
		json.put("totalResults", totalResults);
		json.put("data", ja);
		
		String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
		response.getWriter().print(jsonPrettyPrintString);
		response.getWriter().flush();
		response.getWriter().close();	
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
