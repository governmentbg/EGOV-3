package com.egov.search.ext;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import com.egov.search.ext.utils.EgovSearchExtUtils;
import com.egov.search.ext.utils.Logger;
import com.egov.wcm.cache.EgovService;
import com.egov.wcm.cache.EgovWCMCache;
import com.egov.wcm.cache.EgovWCMUtils;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentIterator;
import com.ibm.workplace.wcm.api.query.Disjunction;
import com.ibm.workplace.wcm.api.query.PageIterator;
import com.ibm.workplace.wcm.api.query.ProfileSelectors;
import com.ibm.workplace.wcm.api.query.Query;
import com.ibm.workplace.wcm.api.query.ResultIterator;
import com.ibm.workplace.wcm.api.query.Selectors;
import com.ibm.workplace.wcm.api.query.SortDirection;
import com.ibm.workplace.wcm.api.query.Sorts;
import com.ibm.workplace.wcm.api.query.WorkflowSelectors;


@WebServlet("/services-by-municipality")
public class ServicesByMunicipality extends HttpServlet {
	
	private static final String PARAMETER_MUNICIPALITY_ID = "mId";	
	private static final String PARAMETER_QUERY = "q";	
	private static final String PARAMETER_RESULTS_PER_PAGE = "rPP";	
	private static final String PARAMETER_CURRENT_PAGE = "cP";	
	private static final String PARAMETER_DEBUG = "debug";	
	
	private static final int RESULTS_PER_PAGE = 10;
	private static final int CURRENT_PAGE = 1;
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	private static final long serialVersionUID = 1L;
	public boolean isDebug = false;

	public ServicesByMunicipality() {
		super();
	}
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		getContents(request, response);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void getContents(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");		
		response.setContentType("application/json; charset=UTF-8");
		
		String municipalityId = request.getParameter(PARAMETER_MUNICIPALITY_ID);		
		String q = request.getParameter(PARAMETER_QUERY);		
		int resultsPerPage = RESULTS_PER_PAGE;
		int currentPage = CURRENT_PAGE;
		isDebug = "true".equalsIgnoreCase(request.getParameter(PARAMETER_DEBUG));
		
		try {
			if (request.getParameter(PARAMETER_RESULTS_PER_PAGE) != null) {
				resultsPerPage = Integer.parseInt(request.getParameter(PARAMETER_RESULTS_PER_PAGE));
			}
		} catch (Exception e) {}
		try {
			if (request.getParameter(PARAMETER_CURRENT_PAGE) != null) {
				currentPage = Integer.parseInt(request.getParameter(PARAMETER_CURRENT_PAGE));
			}
		} catch (Exception e) {}
		
		Logger.log(isDebug, "ServicesByMunicipality -> getContents() -> municipalityId=" + municipalityId);
		Logger.log(isDebug, "ServicesByMunicipality -> getContents() -> q=" + q);
		Logger.log(isDebug, "ServicesByMunicipality -> getContents() -> resultsPerPage=" + resultsPerPage);
		Logger.log(isDebug, "ServicesByMunicipality -> getContents() -> currentPage=" + currentPage);
		Logger.log(isDebug, "ServicesByMunicipality -> getContents() -> debug=" + request.getParameter(PARAMETER_DEBUG));
		
		JSONObject json = new JSONObject();
		JSONArray ja = new JSONArray(); 	
		
		if (municipalityId == null) {			
			json.put("data", ja);
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
			response.getWriter().print(jsonPrettyPrintString);
			response.getWriter().flush();
			response.getWriter().close();	
			return;
		} 
		
		int totalPages = 0;	
		int totalResults = 0;
		try {
			Logger.log(isDebug, "ServicesByMunicipality -> getContents() -> before first call");
			Query query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
			query.addSelector(Selectors.nameEquals(municipalityId));
			// By default, all of them are published.
			query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
			// Load only others templates.
			query.addSelector(
				Selectors.authoringTemplateIn(
					new DocumentId[] {
						EgovWCMCache.getATAdditionalDataOfServiceProvidedBySupplier().getId()
					}
				)
			);
			//query.returnObjects();
			query.returnIds();			
			Logger.log(isDebug, "ServicesByMunicipality -> getContents() -> after first call");
			ResultIterator resultIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query);
			int res = 0;
    		if (resultIterator.hasNext()) {    			
    			List<String> names = new ArrayList<String>();
    			Content content = null;
    			DocumentId docId = null;
    			String parentName = "";
    			String path = "";
    			while (resultIterator.hasNext()) {
    				res++;        			    				
//    				content = (Content)resultIterator.next();
    				docId = (DocumentId)resultIterator.next();
    				path = EgovWCMCache.getWorkspace().getPathById(docId, false, true);
//    				names.add(content.getParentId().getName().replace(EgovWCMCache.SERVICES_SITE_AREA_NAME_UNIFIED_SERVICE_SUFFIX, ""));
    				parentName = path.substring(0, path.indexOf(EgovWCMCache.SERVICES_SITE_AREA_NAME_UNIFIED_SERVICE_SUFFIX + "/"));
    				names.add(parentName.substring(parentName.lastIndexOf("/") + 1));
    				Logger.log(isDebug, "ServicesByMunicipality -> getContents() -> res=" + res);
    				
    			}
    			
    			// Load result from cache.
    			List<EgovService> unifiedServices = EgovWCMCache.getUnifiedServices();
    			if (unifiedServices != null && unifiedServices.size() > 0) {
    				List<EgovService> foundedServices = new ArrayList<>();
    				EgovService egovService = null;
    				for (int i = 0; i < names.size(); i++) {
    					egovService = EgovWCMCache.getServiceByName().get(names.get(i));
    					if (egovService != null) {
    						foundedServices.add(egovService);
    					}
    				}
    				if (q != null && q.trim().length() > 0) {
    					EgovWCMUtils utils = new EgovWCMUtils();
						// Order by higher match.
    					foundedServices = utils.orderBySeachTerm(foundedServices, q.toLowerCase()); 
					}
					if (foundedServices.size() > 0) {
						JSONArray tmpJA = null;
						EgovService service = null;						
						for (int i = (currentPage - 1) * resultsPerPage, j = 0; i < foundedServices.size(); i++, j++) {
							if (j == resultsPerPage) {break;}
							tmpJA = new JSONArray();
							service = foundedServices.get(i);
							tmpJA.put(service.getId());
							tmpJA.put(service.getName()); 
							tmpJA.put(service.getTitle());
							tmpJA.put((service.getPublishedDate() != null) ? EgovSearchExtUtils.timeMillisToDate(service.getPublishedDate().getTime()) : "");
							tmpJA.put(EgovWCMCache.getATUnifiedService().getName().equalsIgnoreCase(service.getAuthoringTemplateName()) ? EgovWCMCache.getATUnifiedService().getName() : EgovWCMCache.getATServiceProvidedBySupplier().getName());
							tmpJA.put(service.getParentName());
							ja.put(tmpJA);
						}
						totalResults = foundedServices.size();
						totalPages = (totalResults % resultsPerPage == 0) ? totalResults / resultsPerPage : (totalResults / resultsPerPage) + 1;
					} else {
						totalResults = 0;
						totalPages = 0;
					}
					json.put("totalPages", totalPages);
					json.put("totalResults", totalResults);
					json.put("data", ja);
					
					String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
					response.getWriter().print(jsonPrettyPrintString);
					response.getWriter().flush();
					response.getWriter().close();	
					return;
    			} 
    			
    			//If we are here, no cache is loaded yet, so we query the WCM database.
    			query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
    			query.addSelector(Selectors.nameIn(names));
    			// By default, all of them are published.
				query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
				// Load only others templates.
				query.addSelector(
					Selectors.authoringTemplateIn(
						new DocumentId[] {
							EgovWCMCache.getATUnifiedService().getId()
						}
					)
				);
				// load only 'active' services.
				query.addSelector(ProfileSelectors.categoriesContains(EgovWCMCache.getCategoryServiceStatusActive().getId()));
				if (q != null && q.trim().length() > 0) {
					String searchTerm = q;
					if (searchTerm != null && searchTerm.trim().length() > 0) {
						// Stupid IBM function does not support case insensitive!
						Disjunction or = new Disjunction();
						or.add(Selectors.titleLike("%" + searchTerm + "%"));
						or.add(Selectors.titleLike("%" + searchTerm.toLowerCase() + "%"));
						or.add(Selectors.titleLike("%" + searchTerm.toUpperCase() + "%"));
						if (searchTerm.trim().length() > 1) {
							if (!Character.isUpperCase(searchTerm.charAt(0))) {
								or.add(Selectors.titleLike("%" + searchTerm.substring(0, 1).toUpperCase() + searchTerm.substring(1) + "%"));
							}
							or.add(Selectors.titleLike("%" + EgovSearchExtUtils.capitalizeString(searchTerm.trim()) + "%"));
						}
						or.add(Selectors.nameLike("%" + searchTerm + "%"));
						query.addSelector(or);
					}
				} else {
					query.addSort(Sorts.byTitle(SortDirection.ASCENDING));
				}				
    			Logger.log(isDebug, "ServicesByMunicipality -> getContents() -> query 2");
				query.returnIds();
				PageIterator pageIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query, resultsPerPage, currentPage);	
				ArrayList<DocumentId> tmpIdArr = new ArrayList<>();
				JSONArray tmpJA = null; 
				if (pageIterator != null && pageIterator.hasNext()) {				
					content = null;
					ResultIterator docIterator = null;
					DocumentId contentDocId = null;
					int page = 0;
					docIterator = (ResultIterator) pageIterator.next();		
					Logger.log(isDebug, "ServicesByMunicipality -> getContents() -> page=" + page);
					while (docIterator.hasNext()) {
						contentDocId = (DocumentId)docIterator.next();
						tmpIdArr.add(contentDocId);
						Logger.log(isDebug, "ServicesByMunicipality -> getContents() -> name=" + contentDocId.getName());
					}
					DocumentId[] docIds = tmpIdArr.toArray(new DocumentId[tmpIdArr.size()]);
					DocumentIdIterator documentIdIterator = EgovWCMCache.getWorkspace().createDocumentIdIterator(docIds);
					DocumentIterator documentIterator = EgovWCMCache.getWorkspace().getByIds(documentIdIterator, true, false);
					int contents = 0;
					while (documentIterator.hasNext()) {
						content = (Content) documentIterator.next();
						Logger.log(isDebug, "ServicesByMunicipality -> getContents() -> title=" + content.getTitle());
						tmpJA = new JSONArray();
						tmpJA.put(content.getId().getID());
						tmpJA.put(content.getName());
						tmpJA.put(content.getTitle());
						tmpJA.put((content.getPublishedDate() != null) ? EgovSearchExtUtils.timeMillisToDate(content.getPublishedDate().getTime()) : "");
						ja.put(tmpJA);
						contents++;
					}
					if (pageIterator.hasNext()) {
						contents = 0;
						while (pageIterator.hasNext()) {
							docIterator = (ResultIterator) pageIterator.next();
							page++;
							Logger.log(isDebug, "ServicesByMunicipality -> getContents() -> page++=" + page);
						}
						while (docIterator.hasNext()) {
							Logger.log(isDebug, "ServicesByMunicipality -> getContents() -> contents++=" + contents);
							docIterator.next();
							contents++;
						}					
					} 
					totalPages = currentPage + page;
					totalResults = ((totalPages * resultsPerPage) - resultsPerPage) + contents;
					Logger.log(isDebug, "ServicesByMunicipality -> getContents() -> totalPages=" + totalPages);
				}						
    		}    		
		 } catch (Exception e) {
		 	System.out.println("ServicesByMunicipality -> getContents() - error: " + e.getMessage());
		    e.printStackTrace();
		 }
			
		json.put("totalPages", totalPages);
		json.put("totalResults", totalResults);
		json.put("data", ja);
		
		String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
		response.getWriter().print(jsonPrettyPrintString);
		response.getWriter().flush();
		response.getWriter().close();	
		
	}
		
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
