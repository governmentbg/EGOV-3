package com.egov.search.ext;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import com.egov.search.ext.utils.EgovSearchExtUtils;
import com.egov.search.ext.utils.Logger;
import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentIterator;
import com.ibm.workplace.wcm.api.query.PageIterator;
import com.ibm.workplace.wcm.api.query.Query;
import com.ibm.workplace.wcm.api.query.QueryDepth;
import com.ibm.workplace.wcm.api.query.ResultIterator;
import com.ibm.workplace.wcm.api.query.Selectors;
import com.ibm.workplace.wcm.api.query.SortDirection;
import com.ibm.workplace.wcm.api.query.Sorts;
import com.ibm.workplace.wcm.api.query.WorkflowSelectors;


@WebServlet("/news")
public class News extends HttpServlet {
	
	private static final String PARAMETER_PARENT_ID = "pId";	
	private static final String PARAMETER_RESULTS_PER_PAGE = "rPP";	
	private static final String PARAMETER_CURRENT_PAGE = "cP";	
	private static final String PARAMETER_DEBUG = "debug";	
	
	private static final int RESULTS_PER_PAGE = 10;
	private static final int CURRENT_PAGE = 1;
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	private static final long serialVersionUID = 1L;
	public boolean isDebug = false;

	public News() {
		super();
	}
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		getContents(request, response);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void getContents(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");		
		response.setContentType("application/json; charset=UTF-8");
		
		String parentId = request.getParameter(PARAMETER_PARENT_ID);		
		int resultsPerPage = RESULTS_PER_PAGE;
		int currentPage = CURRENT_PAGE;
		isDebug = "true".equalsIgnoreCase(request.getParameter(PARAMETER_DEBUG));
		
		try {
			if (request.getParameter(PARAMETER_RESULTS_PER_PAGE) != null) {
				resultsPerPage = Integer.parseInt(request.getParameter(PARAMETER_RESULTS_PER_PAGE));
			}
		} catch (Exception e) {}
		try {
			if (request.getParameter(PARAMETER_CURRENT_PAGE) != null) {
				currentPage = Integer.parseInt(request.getParameter(PARAMETER_CURRENT_PAGE));
			}
		} catch (Exception e) {}
		
		Logger.log(isDebug, "News -> getContents() -> parentId=" + parentId);
		Logger.log(isDebug, "News -> getContents() -> resultsPerPage=" + resultsPerPage);
		Logger.log(isDebug, "News -> getContents() -> currentPage=" + currentPage);
		Logger.log(isDebug, "News -> getContents() -> debug=" + request.getParameter(PARAMETER_DEBUG));
		
		JSONObject json = new JSONObject();
		JSONArray ja = new JSONArray(); 	
		
		if (parentId == null) {			
			json.put("data", ja);
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
			response.getWriter().print(jsonPrettyPrintString);
			response.getWriter().flush();
			response.getWriter().close();	
			return;
		} 
		
		int totalPages = 0;				
		try {			
			DocumentId tmpParentDocId = EgovWCMCache.getWorkspace().createDocumentId(parentId);
			DocumentId newATId = EgovWCMCache.getWorkspace().createDocumentId("459354e2-8817-4bde-a566-ba968e9d8273");
			Query query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
			query.addParentId(tmpParentDocId, QueryDepth.CHILDREN);
			// By default, all of them are published.
			query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
			// Load only news.
			query.addSelector(
					Selectors.authoringTemplateIn(
						new DocumentId[] {
								newATId
						}
					)
			);
			query.addSort(Sorts.byPublishDate(SortDirection.DESCENDING));
			query.returnIds(); 
			PageIterator pageIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query, resultsPerPage, currentPage);			
			ArrayList<DocumentId> tmpIdArr = new ArrayList<>();
			JSONArray tmpJA = null; 
			if (pageIterator != null && pageIterator.hasNext()) {				
				Content content = null;
				ResultIterator docIterator = null;
				DocumentId contentDocId = null;
				int page = 0;
				docIterator = (ResultIterator) pageIterator.next();								
				Logger.log(isDebug, "News -> getContents() -> page=" + page);
				while (docIterator.hasNext()) {
					contentDocId = (DocumentId)docIterator.next();
					tmpIdArr.add(contentDocId);
					Logger.log(isDebug, "News -> getContents() -> name=" + contentDocId.getName());							
				}
				DocumentId[] docIds = tmpIdArr.toArray(new DocumentId[tmpIdArr.size()]);
				DocumentIdIterator documentIdIterator = EgovWCMCache.getWorkspace().createDocumentIdIterator(docIds);
				DocumentIterator documentIterator = EgovWCMCache.getWorkspace().getByIds(documentIdIterator, true, false);
				while (documentIterator.hasNext()) {
					content = (Content) documentIterator.next();
					Logger.log(isDebug, "News -> getContents() -> title=" + content.getTitle());
					tmpJA = new JSONArray();
					tmpJA.put(content.getId().getID());
					tmpJA.put(content.getName());
					tmpJA.put(content.getTitle());
					tmpJA.put(content.getDescription() != null ? content.getDescription() : "");
					tmpJA.put((content.getPublishedDate() != null) ? EgovSearchExtUtils.timeMillisToTimestamp(content.getPublishedDate().getTime()) : "");
					ja.put(tmpJA);
				}
				if (pageIterator.hasNext()) {
					while (pageIterator.hasNext()) {
						pageIterator.next();
						page++;
					}
				}
				totalPages = currentPage + page;
				Logger.log(isDebug, "News -> getContents() -> totalPages=" + totalPages);
			}
			
		} catch (Exception e) {
			Logger.log(isDebug, "News -> getContents() : ERROR " + e.getMessage());
			e.printStackTrace();
		}			
		json.put("total", totalPages);
		json.put("data", ja);
		
		String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
		response.getWriter().print(jsonPrettyPrintString);
		response.getWriter().flush();
		response.getWriter().close();	
		
	}
		
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
