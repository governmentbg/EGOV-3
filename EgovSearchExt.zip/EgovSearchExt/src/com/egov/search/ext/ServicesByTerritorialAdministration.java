package com.egov.search.ext;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import com.egov.search.ext.utils.EgovSearchExtUtils;
import com.egov.search.ext.utils.Logger;
import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentIterator;
import com.ibm.workplace.wcm.api.Identity;
import com.ibm.workplace.wcm.api.query.Disjunction;
import com.ibm.workplace.wcm.api.query.PageIterator;
import com.ibm.workplace.wcm.api.query.ProfileSelectors;
import com.ibm.workplace.wcm.api.query.Query;
import com.ibm.workplace.wcm.api.query.ResultIterator;
import com.ibm.workplace.wcm.api.query.Selectors;
import com.ibm.workplace.wcm.api.query.SortDirection;
import com.ibm.workplace.wcm.api.query.Sorts;
import com.ibm.workplace.wcm.api.query.WorkflowSelectors;

/*
 * OLD @Deprecated
 * 
 * The call was moved to ServicesBySupplier servlet.
 *  
 * This servlet is called to serve Regional and Municipality services list page.
 * - egov/dostavchitsi na uslugi/oblastni administratsii/uslugi 
 * - egov/dostavchitsi na uslugi/obshtinski administratsii/uslugi 
 */

@WebServlet("/services-by-territorial-administration")
public class ServicesByTerritorialAdministration extends HttpServlet {
	
	private static final String PARAMETER_CATEGORY_ID = "cId";	
	private static final String PARAMETER_QUERY = "q";	
	private static final String PARAMETER_RESULTS_PER_PAGE = "rPP";	
	private static final String PARAMETER_CURRENT_PAGE = "cP";	
	private static final String PARAMETER_DEBUG = "debug";	
	
	private static final int RESULTS_PER_PAGE = 10;
	private static final int CURRENT_PAGE = 1;
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	private static final long serialVersionUID = 1L;
	public boolean isDebug = false;

	public ServicesByTerritorialAdministration() {
		super();
	}
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		getContents(request, response);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void getContents(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");		
		response.setContentType("application/json; charset=UTF-8");
		
		String categoryId = request.getParameter(PARAMETER_CATEGORY_ID);		
		String q = request.getParameter(PARAMETER_QUERY);		
		int resultsPerPage = RESULTS_PER_PAGE;
		int currentPage = CURRENT_PAGE;
		isDebug = "true".equalsIgnoreCase(request.getParameter(PARAMETER_DEBUG));
		
		try {
			if (request.getParameter(PARAMETER_RESULTS_PER_PAGE) != null) {
				resultsPerPage = Integer.parseInt(request.getParameter(PARAMETER_RESULTS_PER_PAGE));
			}
		} catch (Exception e) {}
		try {
			if (request.getParameter(PARAMETER_CURRENT_PAGE) != null) {
				currentPage = Integer.parseInt(request.getParameter(PARAMETER_CURRENT_PAGE));
			}
		} catch (Exception e) {}
		
		Logger.log(isDebug, "ServicesByTerritorialAdministration -> getContents() -> cId=" + categoryId);
		Logger.log(isDebug, "ServicesByTerritorialAdministration -> getContents() -> active=" + EgovWCMCache.getCategoryCommonActive().getId().getID());
		Logger.log(isDebug, "ServicesByTerritorialAdministration -> getContents() -> q=" + q);
		Logger.log(isDebug, "ServicesByTerritorialAdministration -> getContents() -> resultsPerPage=" + resultsPerPage);
		Logger.log(isDebug, "ServicesByTerritorialAdministration -> getContents() -> currentPage=" + currentPage);
		Logger.log(isDebug, "ServicesByTerritorialAdministration -> getContents() -> debug=" + request.getParameter(PARAMETER_DEBUG));
		
		JSONObject json = new JSONObject();
		JSONArray ja = new JSONArray(); 	
		
		if (categoryId == null) {			
			json.put("data", ja);
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
			response.getWriter().print(jsonPrettyPrintString);
			response.getWriter().flush();
			response.getWriter().close();	
			return;
		} 
		
		int totalPages = 0;	
		int totalResults = 0;
		try {			
			DocumentId[] categoryDocIdsArray = new DocumentId[2];			
			// Filter by given category.
			categoryDocIdsArray[0] = EgovWCMCache.getWorkspace().createDocumentId(categoryId);
			// Load only 'active' services.
			categoryDocIdsArray[1] = EgovWCMCache.getCategoryServiceStatusActive().getId();
			List<Identity> categoriesList = new ArrayList<Identity>(Arrays.asList(categoryDocIdsArray));
			
			Query query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
			// filter by categories.
			query.addSelector(ProfileSelectors.categoriesContains(categoriesList));
			// By default, all of them are published.
			query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
			// Load only supported service types.
			query.addSelector(
				Selectors.authoringTemplateIn(
					new DocumentId[] {
						EgovWCMCache.getATUnifiedService().getId(),
						EgovWCMCache.getATServiceProvidedBySupplier().getId()
					}
				)
			);
			if (q != null && q.trim().length() > 0) {
				String searchTerm = q;
				if (searchTerm != null && searchTerm.trim().length() > 0) {
					// Stupid IBM function does not support case insensitive!
					Disjunction or = new Disjunction();
					or.add(Selectors.titleLike("%" + searchTerm + "%"));
					or.add(Selectors.titleLike("%" + searchTerm.toLowerCase() + "%"));
					or.add(Selectors.titleLike("%" + searchTerm.toUpperCase() + "%"));
					if (searchTerm.trim().length() > 1) {
						if (!Character.isUpperCase(searchTerm.charAt(0))) {
							or.add(Selectors.titleLike("%" + searchTerm.substring(0, 1).toUpperCase() + searchTerm.substring(1) + "%"));
						}
						or.add(Selectors.titleLike("%" + EgovSearchExtUtils.capitalizeString(searchTerm.trim()) + "%"));
					}
					or.add(Selectors.nameLike("%" + searchTerm + "%"));
					query.addSelector(or);
				}
			} else {
				query.addSort(Sorts.byTitle(SortDirection.ASCENDING));
			}
			query.returnIds(); 
			PageIterator pageIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query, resultsPerPage, currentPage);			
			ArrayList<DocumentId> tmpIdArr = new ArrayList<>();
			JSONArray tmpJA = null; 
			if (pageIterator != null && pageIterator.hasNext()) {				
				Content content = null;
				ResultIterator docIterator = null;
				DocumentId contentDocId = null;
				int page = 0;
				docIterator = (ResultIterator) pageIterator.next();								
				Logger.log(isDebug, "ServicesByTerritorialAdministration -> getContents() -> page=" + page);
				while (docIterator.hasNext()) {
					contentDocId = (DocumentId)docIterator.next();
					tmpIdArr.add(contentDocId);
					Logger.log(isDebug, "ServicesByTerritorialAdministration -> getContents() -> name=" + contentDocId.getName());							
				}
				DocumentId[] docIds = tmpIdArr.toArray(new DocumentId[tmpIdArr.size()]);
				DocumentIdIterator documentIdIterator = EgovWCMCache.getWorkspace().createDocumentIdIterator(docIds);
				DocumentIterator documentIterator = EgovWCMCache.getWorkspace().getByIds(documentIdIterator, true, false);
				int contents = 0;
				while (documentIterator.hasNext()) {
					content = (Content) documentIterator.next();
					Logger.log(isDebug, "ServicesByTerritorialAdministration -> getContents() -> title=" + content.getTitle());
					tmpJA = new JSONArray();
					tmpJA.put(content.getId().getID());
					tmpJA.put(content.getName());
					tmpJA.put(content.getTitle());
					tmpJA.put((content.getPublishedDate() != null) ? EgovSearchExtUtils.timeMillisToDate(content.getPublishedDate().getTime()) : "");
					tmpJA.put(EgovWCMCache.getATUnifiedService().getId().getID().equalsIgnoreCase(content.getAuthoringTemplateID().getID()) ? EgovWCMCache.getATUnifiedService().getName() : EgovWCMCache.getATServiceProvidedBySupplier().getName());
					tmpJA.put(content.getParentId().getName());
					ja.put(tmpJA);
					contents++;
				}
				if (pageIterator.hasNext()) {
					contents = 0;
					while (pageIterator.hasNext()) {
						docIterator = (ResultIterator) pageIterator.next();
						page++;
						Logger.log(isDebug, "ServicesByTerritorialAdministration -> getContents() -> page++=" + page);
					}
					while (docIterator.hasNext()) {
						Logger.log(isDebug, "ServicesByTerritorialAdministration -> getContents() -> contents++=" + contents);
						docIterator.next();
						contents++;
					}					
				} 
				totalPages = currentPage + page;
				totalResults = ((totalPages * resultsPerPage) - resultsPerPage) + contents;
				Logger.log(isDebug, "ServicesByTerritorialAdministration -> getContents() -> totalPages=" + totalPages);
			}
		} catch (Exception e) {
			Logger.log(isDebug, "ServicesByTerritorialAdministration -> getContents() : ERROR " + e.getMessage());
			e.printStackTrace();
		}			
		json.put("totalPages", totalPages);
		json.put("totalResults", totalResults);
		json.put("data", ja);
		
		String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
		response.getWriter().print(jsonPrettyPrintString);
		response.getWriter().flush();
		response.getWriter().close();	
		
	}
		
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
