package com.egov.search.ext;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.json.XML;

import com.egov.search.ext.utils.HtmlConverter;
import com.egov.search.ext.utils.Logger;
import com.egov.wcm.cache.EgovService;
import com.egov.wcm.cache.EgovServiceProvider;
import com.egov.wcm.cache.EgovWCMCache;
import com.egov.wcm.cache.EgovWCMUtils;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.ContentComponent;
import com.ibm.workplace.wcm.api.Document;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentIterator;
import com.ibm.workplace.wcm.api.RichTextComponent;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.TextComponent;
import com.ibm.workplace.wcm.api.exceptions.ComponentNotFoundException;


@WebServlet("/get-data")
public class GetData extends HttpServlet {
	
	private static final String PARAMETER_FORMAT = "format";
	private static final String PARAMETER_TYPE_JSON = "json";	
	private static final String PARAMETER_DATA = "data";	
	private static final String PARAMETER_DEBUG = "debug";	
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	private static final long serialVersionUID = 1L;
	public boolean isDebug = false;

	public GetData() {
		super();
	}
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		getContents(request, response);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void getContents(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");		
		String data = request.getParameter(PARAMETER_DATA);		
		String format = request.getParameter(PARAMETER_FORMAT);
		isDebug = "true".equalsIgnoreCase(request.getParameter(PARAMETER_DEBUG));
		
		Logger.log(isDebug, "GetData -> getContents() -> data=" + data);
		Logger.log(isDebug, "GetData -> getContents() -> format=" + format);
		Logger.log(isDebug, "GetData -> getContents() -> debug=" + request.getParameter(PARAMETER_DEBUG));
		
		StringBuffer xml = new StringBuffer();
		xml.append("<?xml version=\"1.0\" encoding=\"utf8\" standalone=\"yes\"?>");
		xml.append("<data>");		
	
		if (data != null && data.trim().length() > 0) { // IDs
			try {
				String[] sericesIds = data.split(",");			
				HashMap<String, EgovService> servicesById = EgovWCMCache.getServiceById(); 
				
				// Use cache.
				if (servicesById != null && servicesById.size() > 0) {
					Logger.log(isDebug, "GetData -> getContents() -> Use cache.");
					ArrayList<EgovService> foundedByProvider = new ArrayList<>();
					ArrayList<EgovService> unifiedFounded = new ArrayList<>();
					EgovService service = null;
					int i,j;
					for (i = 0; i < sericesIds.length; i++) {
						service = servicesById.get(sericesIds[i]); 
						if (service != null) {
							if (EgovWCMCache.getATServiceProvidedBySupplier().getName().equalsIgnoreCase(service.getAuthoringTemplateName())) {							
								foundedByProvider.add(service);							
							} else {
								unifiedFounded.add(service);
							}
						}						
					}
					if (foundedByProvider.size() > 0 || unifiedFounded.size() > 0) {
						ArrayList<String> tmpSuppliersIdArr = new ArrayList<>();
						ArrayList<EgovService> tmpContentArr = null;
						HashMap<String, ArrayList<EgovService>> hm = new HashMap<String, ArrayList<EgovService>>();
						if (foundedByProvider.size() > 0) {
							String supplierUUID = null;
							for (i = 0; i < foundedByProvider.size(); i++) {
								service = foundedByProvider.get(i);
								supplierUUID = service.getSupplierUUID();
								if (supplierUUID != null && supplierUUID.trim().length() > 0 && hm.get(supplierUUID) == null) {
									Logger.log(isDebug, "GetData -> getContents() -> supplierUUID=" + supplierUUID);
									tmpSuppliersIdArr.add(supplierUUID);
								}
								tmpContentArr = hm.get(supplierUUID);
								if (tmpContentArr == null) {
									tmpContentArr = new ArrayList<>();
								}
								tmpContentArr.add(service);
								hm.put(supplierUUID, tmpContentArr);
							}							
						}
						if (tmpSuppliersIdArr.size() > 0) {
							EgovServiceProvider supplier = null;
							for (i = 0; i < tmpSuppliersIdArr.size(); i++) {
								supplier = EgovWCMCache.getServiceProviderById(tmpSuppliersIdArr.get(i));
								if (supplier != null) {
									tmpContentArr = hm.get(supplier.getId());
									if (tmpContentArr != null) {
										Logger.log(isDebug, "GetData -> getContents() -> tmpContentIdsArr.size()=" + tmpContentArr.size());
										for (j = 0; j < tmpContentArr.size(); j++) {
											Logger.log(isDebug, "GetData -> getContents() -> tmpContentIdsArr.get(" + j + ")=" + tmpContentArr.get(j).getId());
											xml.append(buildSupplierSiteAreaData(supplier, tmpContentArr.get(j) , format));
										}										
									}
								}
							}
						}
						if (unifiedFounded.size() > 0) {
							String[] name = null;
							EgovWCMUtils egovUtils = new EgovWCMUtils();
							for (i = 0; i < unifiedFounded.size(); i++) {
								service = unifiedFounded.get(i);
								Logger.log(isDebug, "GetData -> getContents() -> unified service=" + service.getTitle() + ",type=" + service.getType() + ",path=" + service.getContentPath());
								if (EgovWCMCache.CATEGORY_PROVIDER_TYPE_ALL_ADMINISTRATIONS_NAME.equalsIgnoreCase(service.getType())) {
									xml.append(buildUnifiedServiceSupplierData(service.getId(), "vsichki administratsii", "vsichki administratsii", "Всички администрации", format));
								} else if (EgovWCMCache.CATEGORY_PROVIDER_TYPE_REGIONAL_NAME.equalsIgnoreCase(service.getType())) {
									xml.append(buildUnifiedServiceSupplierData(service.getId(), "oblastni administratsii", "oblastni administratsii", "Областни администрации", format));
								} else if (EgovWCMCache.CATEGORY_PROVIDER_TYPE_MUNICIPAL_NAME.equalsIgnoreCase(service.getType())) {
									xml.append(buildUnifiedServiceSupplierData(service.getId(), "obshtinski administratsii", "obshtinski administratsii", "Общински администрации", format));
								} else if (EgovWCMCache.CATEGORY_PROVIDER_TYPE_AREA_MUNICIPAL_NAME.equalsIgnoreCase(service.getType())) {
									xml.append(buildUnifiedServiceSupplierData(service.getId(), "obshtinski administratsii na rayoni", "obshtinski administratsii na rayoni", "Общински администрации на райони", format));
								} else if (EgovWCMCache.CATEGORY_PROVIDER_TYPE_SPECIALIZED_LOCAL_NAME.equalsIgnoreCase(service.getType())) {
									name = egovUtils.getSpecializedTerritorialAdministrationName(service.getContentPath());
									if (name != null && name.length == 2) {
										xml.append(buildUnifiedServiceSupplierData(service.getId(), name[0], name[0], name[1], format));
										continue;
									}
								}
							}							
						}
						if (tmpSuppliersIdArr != null) {
							tmpSuppliersIdArr.clear();
						}
						if (tmpContentArr != null) {
							tmpContentArr.clear();
						}
						hm.clear();
					}										
				} else { // if cache is not loaded yet, query WCM database.		
					Logger.log(isDebug, "GetData -> getContents() -> Query WCM database.");
					
					DocumentId tmpDocId = null;
					ArrayList<DocumentId> tmpIdArr = new ArrayList<>();
					for (int i = 0; i < sericesIds.length; i++) {
						tmpDocId = EgovWCMCache.getWorkspace().createDocumentId(sericesIds[i]);
						if (tmpDocId != null) {
							tmpIdArr.add(tmpDocId);
						}
					}				
					if (tmpIdArr != null && tmpIdArr.size() > 0) {
						DocumentId[] docIds = tmpIdArr.toArray(new DocumentId[tmpIdArr.size()]);
						DocumentIdIterator documentIdIterator = EgovWCMCache.getWorkspace().createDocumentIdIterator(docIds);
						DocumentIterator documentIterator = EgovWCMCache.getWorkspace().getByIds(documentIdIterator, true); 
						if (documentIterator != null && documentIterator.hasNext()) {
							Content content = null;
							String supplierUUID = null;
							tmpIdArr = new ArrayList<>();
							ArrayList<Content> tmpContentIdsArr = null;
							HashMap<String, ArrayList<Content>> hm = new HashMap<String, ArrayList<Content>>();
							while (documentIterator.hasNext()) {
								content = (Content) documentIterator.next();
								Logger.log(isDebug, "GetData -> getContents() -> content.getId().getI()=" + content.getId().getId());
								// get from siteArea
								//tmpIdArr.add(content.getParentId());
								// get from content's field
								supplierUUID = getTextFromComponent(content, EgovWCMCache.SERVICE_FIELD_SERVICE_SUPPLIER_NAME, format);
								if (supplierUUID != null && supplierUUID.trim().length() > 0 && hm.get(supplierUUID) == null) {
									Logger.log(isDebug, "GetData -> getContents() -> supplierUUID=" + supplierUUID);
									tmpIdArr.add(EgovWCMCache.getWorkspace().createDocumentId(supplierUUID));
								}
								tmpContentIdsArr = hm.get(supplierUUID);
								if (tmpContentIdsArr == null) {
									tmpContentIdsArr = new ArrayList<>();
								}
								tmpContentIdsArr.add(content);
								hm.put(supplierUUID, tmpContentIdsArr);
							}
							Logger.log(isDebug, "GetData -> getContents() -> total.contents=" + tmpIdArr.size());						
							if (tmpIdArr != null && tmpIdArr.size() > 0) {
								docIds = tmpIdArr.toArray(new DocumentId[tmpIdArr.size()]);
								documentIdIterator = EgovWCMCache.getWorkspace().createDocumentIdIterator(docIds);
								documentIterator = EgovWCMCache.getWorkspace().getByIds(documentIdIterator, true); 
								if (documentIterator != null && documentIterator.hasNext()) {
									Document document = null;
									while (documentIterator.hasNext()) {
										document = documentIterator.next();
										Logger.log(isDebug, "GetData -> getContents() -> title =" + document.getTitle());
										tmpContentIdsArr = hm.get(document.getId().getId());
										if (tmpContentIdsArr != null) {
											Logger.log(isDebug, "GetData -> getContents() -> tmpContentIdsArr.size()=" + tmpContentIdsArr.size());
											for (int i = 0; i < tmpContentIdsArr.size(); i++) {
												Logger.log(isDebug, "GetData -> getContents() -> tmpContentIdsArr.get(" + i + ")=" + tmpContentIdsArr.get(i));
												xml.append(buildSupplierSiteAreaData(document, tmpContentIdsArr.get(i) , format));
											}
											
										}
									}
								}
							}
						}
					}
				}				
			} catch (Exception e) {
				e.printStackTrace();
			}
		} 
		xml.append("</data>");
		if (PARAMETER_TYPE_JSON.equalsIgnoreCase(request.getParameter(PARAMETER_FORMAT))) {
			response.setContentType("application/json; charset=UTF-8");
			JSONObject xmlJSONObj = XML.toJSONObject(xml.toString());
			String jsonPrettyPrintString = xmlJSONObj.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);
			response.getWriter().print(jsonPrettyPrintString);
		} else {
			response.setContentType("text/xml; charset=UTF-8");
			response.getWriter().print(xml.toString());
		}
		response.getWriter().flush();
		response.getWriter().close();
	}
	
	// This is call from cache. 
	private String buildUnifiedServiceSupplierData(String docId, String supplierId, String supplierName, String supplierTitle, String format) {
		StringBuffer xml = new StringBuffer();
		xml.append("<supplier>");
		xml.append("<docId>" + encode(docId, format) + "</docId>");
		xml.append("<id>" + encode(supplierId, format) + "</id>");			
		xml.append("<name>" + encode(supplierName, format) + "</name>");			
		xml.append("<title>" + encode(supplierTitle, format) + "</title>");					
		xml.append("</supplier>");
		return xml.toString();
	}
	
	// This is call from WCM Query.
	private String buildSupplierSiteAreaData(EgovServiceProvider supplier, EgovService service, String format) {
		StringBuffer xml = new StringBuffer();
		xml.append("<supplier>");
		xml.append("<docId>" + encode(service.getId(), format) + "</docId>");
		xml.append("<id>" + encode(supplier.getId(), format) + "</id>");			
		xml.append("<name>" + encode(supplier.getName(), format) + "</name>");			
		xml.append("<title>" + encode(supplier.getTitle(), format) + "</title>");					
		xml.append("</supplier>");
		return xml.toString();
	}
	
	private String buildSupplierSiteAreaData(Document document, Content content, String format) {
		StringBuffer xml = new StringBuffer();
		xml.append("<supplier>");
		xml.append("<docId>" + encode(content.getId().getId(), format) + "</docId>");
		xml.append("<id>" + encode(document.getId().getId(), format) + "</id>");			
		xml.append("<name>" + encode(document.getName(), format) + "</name>");			
		xml.append("<title>" + encode(document.getTitle(), format) + "</title>");					
		xml.append("</supplier>");
		return xml.toString();
	}
	
	private String getTextFromComponent(Content content, String componentName, String format) {
		try {
			if (!content.hasComponent(componentName)) return "";
			ContentComponent contentComponent = content.getComponentByReference(componentName);
			if (contentComponent instanceof ShortTextComponent) {
				return ((ShortTextComponent)contentComponent).getText();
			} else if (contentComponent instanceof TextComponent) {
				return ((TextComponent)contentComponent).getText();
			} else if (contentComponent instanceof RichTextComponent) {
				if (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) {
					return HtmlConverter.escape(((RichTextComponent)contentComponent).getRichText());				
				}
				return ((RichTextComponent)contentComponent).getRichText();
			}
		} catch (ComponentNotFoundException e) {
			e.printStackTrace();
		}
		return "";
	}
	

	private String encode(String string, String format) {
		return (PARAMETER_TYPE_JSON.equalsIgnoreCase(format)) ? (string != null) ? string : "" : "<![CDATA[" + ((string != null) ? string : "") + "]]>";
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
