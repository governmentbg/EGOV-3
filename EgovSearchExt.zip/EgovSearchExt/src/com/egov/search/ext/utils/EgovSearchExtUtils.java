package com.egov.search.ext.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.ContentComponent;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.OptionSelectionComponent;
import com.ibm.workplace.wcm.api.RichTextComponent;
import com.ibm.workplace.wcm.api.ShortTextComponent;
import com.ibm.workplace.wcm.api.TextComponent;
import com.ibm.workplace.wcm.api.exceptions.ComponentNotFoundException;

public class EgovSearchExtUtils {
	
	private static SimpleDateFormat dateTimeFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.ENGLISH);
	private static SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.ENGLISH);

	public static String timeMillisToTimestamp(final long millis) {
		try { 
			return dateTimeFormat.format(new Date(millis));
		} catch (final Exception e) {
			System.out.println("Utils : timeMillisToTimestamp : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}
	
	public static String timeMillisToDate(final long millis) {
		try { 
			return dateFormat.format(new Date(millis));
		} catch (final Exception e) {
			System.out.println("Utils : timeMillisToDate : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}

	public static boolean hasComponent(Content content, String elementName) {
		for (int i = 0; i < content.getComponentNames().length; i++) {
			if (content.getComponentNames()[i].equals(elementName))
				return true;
		}
		return false;
	}

	public static String getTextField(Content content, String componentName) {
		if (hasComponent(content, componentName)) {		
			ContentComponent contentComponent;
			try {
				contentComponent = content.getComponent(componentName);
				if (contentComponent instanceof ShortTextComponent) {
					ShortTextComponent component = (ShortTextComponent)contentComponent; 
					return component.getText();
				} else if (contentComponent instanceof TextComponent) {
					TextComponent component = (TextComponent)contentComponent; 
					return component.getText();
				} else if (contentComponent instanceof RichTextComponent) {
					RichTextComponent component = (RichTextComponent)contentComponent; 
					return component.getRichText();
				}
			} catch (ComponentNotFoundException e) {
				e.printStackTrace();
			}			
			
		}
		return "";
	}
	
	@SuppressWarnings({ "rawtypes"})
	public static DocumentId[] getOptionSelectionField(Content content, String componentName) throws Exception {
		if (hasComponent(content, componentName)) {
			OptionSelectionComponent component = (OptionSelectionComponent) content.getComponent(componentName);
			return component.getCategorySelections();
		}
		return null;
	}
	
	public static String capitalizeString(String string) {
		char[] chars = string.toLowerCase().toCharArray();
		boolean found = false;
		for (int i = 0; i < chars.length; i++) {
			if (!found && Character.isLetter(chars[i])) {
				chars[i] = Character.toUpperCase(chars[i]);
				found = true;
			} else if (Character.isWhitespace(chars[i]) || chars[i] == '.' || chars[i] == '\'') { // You can add other
																									// chars here
				found = false;
			}
		}
		return String.valueOf(chars);
	} 
	
}
