package com.egov.search.ext.utils;

import com.egov.search.ext.Constants;


public class Logger extends Constants {
	
	public final static int ERROR_LEVEL = 0;
	public final static int DEBUG_LEVEL = 2;

    public synchronized static void log(String logMessage) {
        System.err.println(logMessage);
    }

    public synchronized static void log(boolean log, String logMessage) {

        if (log) {
            String message = Constants._PRODUCT_NAME + Constants._PRODUCT_VERSION + " | ";
            System.out.println(message + logMessage);
        }
    }
}
