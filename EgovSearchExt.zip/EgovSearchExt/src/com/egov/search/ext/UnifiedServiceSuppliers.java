package com.egov.search.ext;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;
import org.json.JSONObject;

import com.egov.search.ext.utils.EgovSearchExtUtils;
import com.egov.search.ext.utils.Logger;
import com.egov.wcm.cache.EgovWCMCache;
import com.ibm.workplace.wcm.api.Category;
import com.ibm.workplace.wcm.api.Content;
import com.ibm.workplace.wcm.api.DocumentId;
import com.ibm.workplace.wcm.api.DocumentIdIterator;
import com.ibm.workplace.wcm.api.DocumentIterator;
import com.ibm.workplace.wcm.api.query.Disjunction;
import com.ibm.workplace.wcm.api.query.PageIterator;
import com.ibm.workplace.wcm.api.query.Query;
import com.ibm.workplace.wcm.api.query.QueryDepth;
import com.ibm.workplace.wcm.api.query.ResultIterator;
import com.ibm.workplace.wcm.api.query.Selectors;
import com.ibm.workplace.wcm.api.query.SortDirection;
import com.ibm.workplace.wcm.api.query.Sorts;


@WebServlet("/unified-service-suppliers")
public class UnifiedServiceSuppliers extends HttpServlet {
	
	private static final String PARAMETER_PARENT_ID = "pId";
	private static final String PARAMETER_SUPPLIER_ID = "sId";
	private static final String PARAMETER_SEARCH = "search";
	private static final String PARAMETER_RESULTS_PER_PAGE = "rPP";	
	private static final String PARAMETER_CURRENT_PAGE = "cP";	
	private static final String PARAMETER_DEBUG = "debug";	
	
	private static final int RESULTS_PER_PAGE = 10;
	private static final int CURRENT_PAGE = 1;
	private static final int JSON_PRETTY_PRINT_INDENT_FACTOR = 4;
	private static final long serialVersionUID = 1L;
	public boolean isDebug = false;

	public UnifiedServiceSuppliers() {
		super();
	}
 
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		getContents(request, response);
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void getContents(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setHeader("Cache-Control", "no-cache");
		request.setCharacterEncoding("utf8");		
		response.setContentType("application/json; charset=UTF-8");
		
		String parentId = request.getParameter(PARAMETER_PARENT_ID);		
		String supplierId = request.getParameter(PARAMETER_SUPPLIER_ID);		
		String searchTerm = request.getParameter(PARAMETER_SEARCH);		
		int resultsPerPage = RESULTS_PER_PAGE;
		int currentPage = CURRENT_PAGE;
		isDebug = "true".equalsIgnoreCase(request.getParameter(PARAMETER_DEBUG));
		
		try {
			if (request.getParameter(PARAMETER_RESULTS_PER_PAGE) != null) {
				resultsPerPage = Integer.parseInt(request.getParameter(PARAMETER_RESULTS_PER_PAGE));
			}
		} catch (Exception e) {}
		try {
			if (request.getParameter(PARAMETER_CURRENT_PAGE) != null) {
				currentPage = Integer.parseInt(request.getParameter(PARAMETER_CURRENT_PAGE));
			}
		} catch (Exception e) {}
		
		Logger.log(isDebug, "UnifiedServiceSuppliers -> getContents() -> parentId=" + parentId);
		Logger.log(isDebug, "UnifiedServiceSuppliers -> getContents() -> resultsPerPage=" + resultsPerPage);
		Logger.log(isDebug, "UnifiedServiceSuppliers -> getContents() -> currentPage=" + currentPage);
		Logger.log(isDebug, "UnifiedServiceSuppliers -> getContents() -> debug=" + request.getParameter(PARAMETER_DEBUG));
		
		JSONObject json = new JSONObject();
		JSONArray ja = new JSONArray(); 	
		
		if (parentId == null && supplierId == null) {			
			json.put("data", ja);
			String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
			response.getWriter().print(jsonPrettyPrintString);
			response.getWriter().flush();
			response.getWriter().close();	
			return;
		} 
		
		if (supplierId != null) {
			JSONObject jo = new JSONObject(); 
			try {
				DocumentId tmpSupplierDocId = EgovWCMCache.getWorkspace().createDocumentId(supplierId);
				Content content = (Content)EgovWCMCache.getWorkspace().getById(tmpSupplierDocId, true);
				if (content != null) {
					DocumentId[] paymentMethods = EgovSearchExtUtils.getOptionSelectionField(content, "paymentMethods");
					String paymentMethodsList = "";
					if (paymentMethods != null && paymentMethods.length > 0) {
						DocumentIterator dIt = EgovWCMCache.getWorkspace().getByIds(EgovWCMCache.getWorkspace().createDocumentIdIterator(paymentMethods), true);
						if (dIt != null && dIt.hasNext()) {
							Category category = null;
							while (dIt.hasNext()) {
								if (paymentMethodsList.length() > 0) {
									paymentMethodsList += "^";
								}
								category = (Category)dIt.next();
								paymentMethodsList += category.getTitle();
							}
						}
					}
					jo.put("terms", EgovSearchExtUtils.getTextField(content, "terms"));
					jo.put("administrationUnitForInformation", EgovSearchExtUtils.getTextField(content, "administrationUnitForInformation"));
					jo.put("paymentInfo", EgovSearchExtUtils.getTextField(content, "paymentInfo"));
					jo.put("paymentMethods", paymentMethodsList);
					jo.put("provisionEAddress", EgovSearchExtUtils.getTextField(content, "provisionEAddress"));					
					
				}
			} catch (Exception e) {
				Logger.log(isDebug, "UnifiedServiceSuppliers -> getContents() : supplierId = " + supplierId + ": ERROR " + e.getMessage());
				e.printStackTrace();
			}
			json.put("data", jo);
		} else {
			int totalPages = 0;				
			try {			
				DocumentId tmpParentDocId = EgovWCMCache.getWorkspace().createDocumentId(parentId);
				Query query = EgovWCMCache.getWorkspace().getQueryService().createQuery(Content.class);
				query.addParentId(tmpParentDocId, QueryDepth.CHILDREN);
				// By default, all of them are published.
				//query.addSelector(WorkflowSelectors.statusEquals(WorkflowSelectors.Status.PUBLISHED));
				if (searchTerm != null && searchTerm.trim().length() > 0) {
					Disjunction or = new Disjunction();
					or.add(Selectors.titleLike("%" + searchTerm + "%"));
					or.add(Selectors.titleLike("%" + searchTerm.toLowerCase() + "%"));
					or.add(Selectors.titleLike("%" + searchTerm.toUpperCase() + "%"));
					if (searchTerm.trim().length() > 1) {
						if (!Character.isUpperCase(searchTerm.charAt(0))) {
							or.add(Selectors.titleLike("%" + searchTerm.substring(0, 1).toUpperCase() + searchTerm.substring(1) + "%"));
						}
						or.add(Selectors.titleLike("%" + capitalizeString(searchTerm.trim()) + "%"));
					}
					query.addSelector(or);
				}
				query.addSort(Sorts.byTitle(SortDirection.ASCENDING));
				query.returnIds(); 
				PageIterator pageIterator = EgovWCMCache.getWorkspace().getQueryService().execute(query, resultsPerPage, currentPage);			
				ArrayList<DocumentId> tmpIdArr = new ArrayList<>();
				JSONArray tmpJA = null; 
				if (pageIterator != null && pageIterator.hasNext()) {				
					Content content = null;
					ResultIterator docIterator = null;
					DocumentId contentDocId = null;
					int page = 0;
					String suffix = "";
					while (pageIterator.hasNext()) {
						page++;
						if (currentPage == 1 && page != currentPage) {
							pageIterator.next();
							continue;
						}					
						docIterator = (ResultIterator) pageIterator.next();								
						Logger.log(isDebug, "UnifiedServiceSuppliers -> getContents() -> page=" + page);
						while (docIterator.hasNext()) {
							contentDocId = (DocumentId)docIterator.next();
							tmpIdArr.add(contentDocId);
							Logger.log(isDebug, "UnifiedServiceSuppliers -> getContents() -> name=" + contentDocId.getName());							
						}
						DocumentId[] docIds = tmpIdArr.toArray(new DocumentId[tmpIdArr.size()]);
						DocumentIdIterator documentIdIterator = EgovWCMCache.getWorkspace().createDocumentIdIterator(docIds);
						DocumentIterator documentIterator = EgovWCMCache.getWorkspace().getByIds(documentIdIterator, true, false);
						while (documentIterator.hasNext()) {
							suffix = "";
							content = (Content) documentIterator.next();
							Logger.log(isDebug, "UnifiedServiceSuppliers -> getContents() -> title=" + content.getTitle());
							tmpJA = new JSONArray();
							tmpJA.put(content.getId().getID());
							tmpJA.put(content.getName());
							if ("513".equals(content.getName())) {
								suffix = " (Варна)";
							} else if ("536".equals(content.getName())) {
								suffix = " (София)";
							}  
							tmpJA.put(content.getTitle() + suffix);
							ja.put(tmpJA);
						}
						if (currentPage != 1) {
							break;
						}
					}
					totalPages = page;
					Logger.log(isDebug, "UnifiedServiceSuppliers -> getContents() -> totalPages=" + totalPages);
				}
				
			} catch (Exception e) {
				Logger.log(isDebug, "UnifiedServiceSuppliers -> getContents() : ERROR " + e.getMessage());
				e.printStackTrace();
			}			
			json.put("total", totalPages);
			json.put("data", ja);
		}
		
		String jsonPrettyPrintString = json.toString(JSON_PRETTY_PRINT_INDENT_FACTOR);	
		response.getWriter().print(jsonPrettyPrintString);
		response.getWriter().flush();
		response.getWriter().close();	
		
	}
		
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	private String capitalizeString(String string) {
		char[] chars = string.toLowerCase().toCharArray();
		boolean found = false;
		for (int i = 0; i < chars.length; i++) {
			if (!found && Character.isLetter(chars[i])) {
				chars[i] = Character.toUpperCase(chars[i]);
				found = true;
			} else if (Character.isWhitespace(chars[i]) || chars[i] == '.' || chars[i] == '\'') { // You can add other
																									// chars here
				found = false;
			}
		}
		return String.valueOf(chars);
	}


}
