package com.ibs.myspace.confirmation.portlet;

import java.io.IOException;
import java.security.PrivilegedExceptionAction;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.portlet.ActionRequest;
import javax.portlet.ActionResponse;
import javax.portlet.GenericPortlet;
import javax.portlet.PortletException;
import javax.portlet.PortletMode;
import javax.portlet.PortletPreferences;
import javax.portlet.PortletRequest;
import javax.portlet.PortletRequestDispatcher;
import javax.portlet.PortletResponse;
import javax.portlet.PortletSession;
import javax.portlet.ReadOnlyException;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;
import javax.portlet.ValidatorException;
import javax.portlet.WindowState;

import com.ibm.portal.portlet.service.PortletServiceHome;
import com.ibm.portal.state.EngineURL;
import com.ibm.portal.state.PortletStateManager;
import com.ibm.portal.state.URLFactory;
import com.ibm.portal.state.accessors.portlet.PortletAccessorController;
import com.ibm.portal.state.accessors.portlet.PortletAccessorFactory;
import com.ibm.portal.state.service.PortletStateManagerService;
import com.ibm.portal.um.PumaController;
import com.ibm.portal.um.PumaEnvironment;
import com.ibm.portal.um.PumaHome;
import com.ibm.portal.um.PumaLocator;
import com.ibm.portal.um.PumaProfile;
import com.ibm.portal.um.User;
import com.ibm.portal.um.exceptions.PumaException;
import com.ibs.myspace.confirmation.portlet.bean.Message;
import com.ibs.myspace.confirmation.portlet.bean.UserProfileBean;
import com.ibs.myspace.confirmation.portlet.db.QueryExecution;
import com.ibs.myspace.confirmation.portlet.dbo.UserProfileRole;
import com.ibs.myspace.confirmation.portlet.utils.Logger;
import com.ibs.myspace.confirmation.portlet.utils.MySpaceConfirmationUtils;

public class MySpaceConfirmationPortlet extends GenericPortlet {

	public static final String JSP_FOLDER = "/_MySpaceConfirmationPortlet/jsp/"; // JSP folder name
  
	public static final String INDEX_PAGE = "index";

	public static final String CONFIG_JSP = "config"; // JSP file name to be rendered on the configure mode
	public static final String EDIT_DEFAULTS_JSP = "editDefaults"; // JSP file name to be rendered on the configure mode

	public static final String SESSION_BEAN = "MySpaceConfirmationPortletSessionBean"; // Bean name for the portlet session
	public static final String CONFIG_SUBMIT = "MySpaceConfirmationPortletConfigSubmit"; // Action name for submit form
	public static final String CONFIG_CANCEL = "MySpaceConfirmationPortletConfigCancel"; // Parameter name for the text input
	public static final String EDIT_DEFAULTS_SUBMIT = "MySpaceConfirmationPortletEditDefaultsSubmit"; // Action name for submit form
	public static final String EDIT_DEFAULTS_CANCEL = "MySpaceConfirmationPortletEditDefaultsCancel"; // Action name for submit form
	
	public static final String SETTING_PARAMETER_LANGUAGE = "language";
	public static final String SETTING_PARAMETER_DEBUG = "debug";
	
	private static final PortletMode CUSTOM_CONFIG_MODE = new PortletMode("config");
	private static final PortletMode CUSTOM_EDIT_DEFAULTS_MODE = new PortletMode("edit_defaults");
	
	private static PumaHome pumaHome = null;
	public static boolean preferencesLoaded = false;
	public static String language = MySpaceConfirmationConstants.LANGUAGE_BG;
	public static boolean debug = false;

	public void init() throws PortletException {
		super.init();
		InitialContext initialcontext;
		try {
			initialcontext = new InitialContext();
			pumaHome = (PumaHome) initialcontext.lookup("portal:service/usermanagement/Puma");
		} catch (NamingException namingexception) {
			namingexception.printStackTrace();
		}
	}

	public void doView(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		// Set the MIME type for the render response
		response.setContentType(request.getResponseContentType());

		// Check if portlet session exists
		MySpaceConfirmationPortletSessionBean sessionBean = getSessionBean(request);
		if (sessionBean == null) {
			response.getWriter().println("<b>NO PORTLET SESSION YET</b>");
			return;
		}

		Locale locale = new Locale(language);
		String typeParam = null;
		String confirmationCodeParam = null;
		int type = MySpaceConfirmationConstants.TYPE_EMAIL_LEGAL_ENTITY;
		try {
			typeParam = getUrlParameter(request, response, MySpaceConfirmationConstants.EMAIL_CONFIRM_TYPE_PARAM, MySpaceConfirmationConstants.MY_SPACE_CONFIRMATION_PORTLET_WINDOW_ID);
			confirmationCodeParam = getUrlParameter(request, response, MySpaceConfirmationConstants.EMAIL_CONFIRM_CONFIRMATION_CODE_PARAM, MySpaceConfirmationConstants.MY_SPACE_CONFIRMATION_PORTLET_WINDOW_ID);
			if (typeParam != null) {
				try {
					type = Integer.parseInt(typeParam);
				} catch (NumberFormatException e) {
					System.out.println(e.getMessage());
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if (typeParam != null && typeParam.trim().length() > 0 && confirmationCodeParam != null && confirmationCodeParam.trim().length() > 0) {
			if (MySpaceConfirmationConstants.TYPE_EMAIL_LEGAL_ENTITY == type) {
				try {
					QueryExecution qe = new QueryExecution();
					UserProfileRole[] participationProfiles = qe.loadAllUserProfileRolesByCode(confirmationCodeParam, null);
					if (participationProfiles != null && participationProfiles.length > 0) {
						String userUID = participationProfiles[0].getUserUID();
						String email = participationProfiles[0].getEmail();
						// Update DB with status 'confirmed'.
						int updated = qe.confirmChangeEmail(userUID, email, null);
						if (updated > 0) {
							sessionBean.setMessage(new Message(MySpaceConfirmationConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(locale).getString("confirm.email.prefix") + " '" + email + "' " +getPortletConfig().getResourceBundle(locale).getString("confirm.email.success")));
						} else {
							// No records updated with email & userUID.
							sessionBean.setMessage(new Message(MySpaceConfirmationConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("confirm.email.error")));							
						}
					} else {
						// No records found with given confirmation code.
						sessionBean.setMessage(new Message(MySpaceConfirmationConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("confirm.email.no.code.match.error")));
					}
				} catch (Exception e) {
					System.out.println(e.getMessage());
					e.printStackTrace();
					sessionBean.setMessage(new Message(MySpaceConfirmationConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("confirm.email.error")));
				}
			}
		} else {
			// Invalid parameters passed.
			sessionBean.setMessage(new Message(MySpaceConfirmationConstants.MESSAGE_TYPE_ERROR, getPortletConfig().getResourceBundle(locale).getString("confirm.email.invalid.parameters")));
		}
		
		PortletRequestDispatcher rd = null;
		rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, INDEX_PAGE));
		rd.include(request, response);
	}

	protected void doDispatch(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		if (!WindowState.MINIMIZED.equals(request.getWindowState())) {
			MySpaceConfirmationUtils.loadPreferences(request);
			if (getPumaHome() != null) {
				PumaProfile pumaProfile = getPumaHome().getProfile();
				if (pumaProfile != null) {
					try {
						User user = pumaProfile.getCurrentUser();
						if (user != null) {
							MySpaceConfirmationPortletSessionBean sessionBean = getSessionBean(request);
							UserProfileBean userProfileBean = sessionBean.getUserProfile();
							if (userProfileBean == null) {
								Logger.log(Logger.DEBUG_LEVEL, "doView() -> doDispatch initializing userProfileBean...");
								userProfileBean = new UserProfileBean();
								userProfileBean.setCurrentUser(user);
								userProfileBean.setCurrentUserDN(pumaProfile.getIdentifier(user));
								userProfileBean = populateUserAttributesFromLDAP(userProfileBean, getPumaHome(), pumaProfile);	
								sessionBean.setUserProfile(userProfileBean);
							}
						}
					} catch (PumaException e) {
						System.out.println(e.getMessage());
						e.printStackTrace();
					}
				}
			}
			PortletMode mode = request.getPortletMode();
			if (CUSTOM_CONFIG_MODE.equals(mode)) {
				doCustomConfigure(request, response);
				return;
			} else if (CUSTOM_EDIT_DEFAULTS_MODE.equals(mode)) {
				doCustomEditDefaults(request, response);
				return;
			}
		}
		super.doDispatch(request, response);
	}

	public void processAction(ActionRequest request, ActionResponse response) throws PortletException, java.io.IOException {
		MySpaceConfirmationPortletSessionBean sessionBean = getSessionBean(request);
		
		if (request.getParameter(CONFIG_SUBMIT) != null) {
		} else if (request.getParameter(CONFIG_CANCEL) != null) {			
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);
		} if (request.getParameter(EDIT_DEFAULTS_SUBMIT) != null) {
			String language = request.getParameter(SETTING_PARAMETER_LANGUAGE);
			String debug = request.getParameter(SETTING_PARAMETER_DEBUG);
			PortletPreferences prefs = request.getPreferences();			
			try {
				prefs.setValue(SETTING_PARAMETER_LANGUAGE, language);
				prefs.setValue(SETTING_PARAMETER_DEBUG, debug);
				prefs.store();
				sessionBean.setMessage(new Message(MySpaceConfirmationConstants.MESSAGE_TYPE_INFORMATION, getPortletConfig().getResourceBundle(new Locale("bg")).getString("settings.were.saved")));
				response.setPortletMode(PortletMode.VIEW);
				response.setWindowState(WindowState.NORMAL);
			} catch( ReadOnlyException roe ) {
				sessionBean.setMessage(new Message(MySpaceConfirmationConstants.MESSAGE_TYPE_ERROR, roe.getMessage()));
			} catch( ValidatorException ve ) { 
				sessionBean.setMessage(new Message(MySpaceConfirmationConstants.MESSAGE_TYPE_ERROR, ve.getMessage()));
			}
		} else if (request.getParameter(EDIT_DEFAULTS_CANCEL) != null) {			
			response.setPortletMode(PortletMode.VIEW);
			response.setWindowState(WindowState.NORMAL);
		}
	}

	@SuppressWarnings("rawtypes")
	private String getUrlParameter(PortletRequest portletRequest, PortletResponse portletResponse, final String parmName, final String portletID) throws Exception {
		System.out.println("getUrlParameter - get parameters from confirmation url. parm name=" + parmName + " portlet id=" + portletID);
		final Context ctx = new InitialContext();
		PortletServiceHome serviceHome = (PortletServiceHome) ctx.lookup(MySpaceConfirmationConstants.JNDI_PORTLET_STATE);
		PortletStateManagerService service = (PortletStateManagerService) serviceHome.getPortletService(PortletStateManagerService.class);

		final PortletStateManager mgr = service.getPortletStateManager(portletRequest, portletResponse);
		final URLFactory urlFactory = mgr.getURLFactory();
		String parmValue = null;
		try {
			final EngineURL url = urlFactory.newURL(null);
			if (portletID != null) {
				final PortletAccessorFactory portletAccessorFactory = (PortletAccessorFactory) mgr.getAccessorFactory(PortletAccessorFactory.class);
				// Get the portlet controller to get render parameters; pass in the state associated with r created URL
				final PortletAccessorController portletCtrl = portletAccessorFactory.getPortletAccessorController(portletID, url.getState());
				java.util.Map map = portletCtrl.getParameters();
				Object aMapObject = map.get(parmName);
				if (aMapObject instanceof String[] && ((String[]) aMapObject).length > 0)
					parmValue = ((String[]) aMapObject)[0];
				else
					parmValue = aMapObject == null ? null : aMapObject.toString();

				portletCtrl.dispose();
				url.dispose();
			}
		} finally {
			urlFactory.dispose();
			mgr.dispose();
			ctx.close();
		}
		System.out.println("Confirmation parameters - " + parmName + "=" + parmValue);
		return parmValue;
	}

	protected void doCustomConfigure(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		MySpaceConfirmationPortletSessionBean sessionBean = getSessionBean(request);
		if (sessionBean != null) {
			sessionBean.setMessage(null);
		} 
		// Set the MIME type for the render response
		response.setContentType(request.getResponseContentType());
		// Invoke the JSP to render
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, CONFIG_JSP));
		rd.include(request, response);
	}
 
	protected void doCustomEditDefaults(RenderRequest request, RenderResponse response) throws PortletException, IOException {
		MySpaceConfirmationPortletSessionBean sessionBean = getSessionBean(request);
		if (sessionBean != null) {
			sessionBean.setMessage(null);
		}
		// Set the MIME type for the render response
		response.setContentType(request.getResponseContentType());
		// Invoke the JSP to render
		PortletRequestDispatcher rd = getPortletContext().getRequestDispatcher(getJspFilePath(request, EDIT_DEFAULTS_JSP));
		rd.include(request, response);
	}
	
	@SuppressWarnings("rawtypes")
	private UserProfileBean populateUserAttributesFromLDAP(UserProfileBean userProfileBean, final PumaHome pumaHome, final PumaProfile pumaProfile) {
		Logger.log(Logger.DEBUG_LEVEL, "populateUserAttributesFromLDAP(userProfileBean)");
		java.util.Map<String, Object> userInfo = getUserAttributesInfo(userProfileBean.getCurrentUser(), pumaHome, pumaProfile);
		if (userInfo != null) {
			Object attribute = userInfo.get(MySpaceConfirmationConstants.LDAP_ATTRIBUTE_COMMON_NAME);
			if (attribute != null) {
				String currentUserCN = "";
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							currentUserCN += " ";
						}
						currentUserCN += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					currentUserCN = (String)attribute;
				}		
				userProfileBean.setCurrentUserCN(currentUserCN);
			}
			attribute = userInfo.get(MySpaceConfirmationConstants.LDAP_ATTRIBUTE_UID);
			if (attribute != null) {
				String currentUserUID = "";
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							currentUserUID += " ";
						}
						currentUserUID += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					currentUserUID = (String)attribute;
				}		
				userProfileBean.setCurrentUserUID(currentUserUID);
			}
			attribute = userInfo.get(MySpaceConfirmationConstants.LDAP_ATTRIBUTE_PORTAL_EMAIL);
			if (attribute != null) {
				String currentUserEmail = "";
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							currentUserEmail += " ";
						}
						currentUserEmail += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					currentUserEmail = (String)attribute;
				}
				userProfileBean.setCurrentUserEmail(currentUserEmail);
			}
			attribute = userInfo.get(MySpaceConfirmationConstants.LDAP_ATTRIBUTE_EGOV_IDENTIFIER);
			//attribute = userInfo.get(MySpaceConfirmationConstants.LDAP_ATTRIBUTE_EMPLOYEE_NUMBER);
			if (attribute != null) {
				String currentUserIdentifier = "";
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							currentUserIdentifier += " ";
						}
						currentUserIdentifier += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					currentUserIdentifier = (String)attribute;
				}
				userProfileBean.setCurrentUserIdentifier(currentUserIdentifier);
			}
			attribute = userInfo.get(MySpaceConfirmationConstants.LDAP_ATTRIBUTE_DEPARTMENT_NUMBER);
			if (attribute != null) {
				String currentUserIdentifierPrefix = "";
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							currentUserIdentifierPrefix += " ";
						}
						currentUserIdentifierPrefix += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					currentUserIdentifierPrefix = (String)attribute;
				}
				userProfileBean.setCurrentUserIdentifierPrefix(currentUserIdentifierPrefix);
			}
			attribute = userInfo.get(MySpaceConfirmationConstants.LDAP_ATTRIBUTE_ROOM_NUMBER);
			if (attribute != null) {
				String activeProfileId = "";
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							activeProfileId += " ";
						}
						activeProfileId += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					activeProfileId = (String)attribute;
				}				
				userProfileBean.setActiveProfileId(activeProfileId != null && activeProfileId.trim().length() > 0 ? activeProfileId : null);
			}
			attribute = userInfo.get(MySpaceConfirmationConstants.LDAP_ATTRIBUTE_INVITATION_ID);
			if (attribute != null) {
				String invitationId = "";
				if (attribute instanceof ArrayList && ((ArrayList)attribute).size() > 0) {
					for (int i = 0; i < ((ArrayList)attribute).size(); i++) {
						if (i > 0) {
							invitationId += " ";
						}
						invitationId += (String)((ArrayList)attribute).get(i);
					}
				} else if (attribute instanceof String) {
					invitationId = (String)attribute;
				}				
				userProfileBean.setInvitationId(invitationId != null && invitationId.trim().length() > 0 ? invitationId : null);
			}
		}
		Logger.log(Logger.DEBUG_LEVEL, "populateUserAttributesFromLDAP -> userDN = " + userProfileBean.getCurrentUserDN());
		Logger.log(Logger.DEBUG_LEVEL, "populateUserAttributesFromLDAP -> userCN = " + userProfileBean.getCurrentUserCN());
		Logger.log(Logger.DEBUG_LEVEL, "populateUserAttributesFromLDAP -> userUID = " + userProfileBean.getCurrentUserUID());
		Logger.log(Logger.DEBUG_LEVEL, "populateUserAttributesFromLDAP -> userIdentifier = " + userProfileBean.getCurrentUserIdentifier());
		Logger.log(Logger.DEBUG_LEVEL, "populateUserAttributesFromLDAP -> userIdentifierPrefix = " + userProfileBean.getCurrentUserIdentifierPrefix());
		Logger.log(Logger.DEBUG_LEVEL, "populateUserAttributesFromLDAP -> userEmail = " + userProfileBean.getCurrentUserEmail());
		Logger.log(Logger.DEBUG_LEVEL, "populateUserAttributesFromLDAP -> activeProfileId = " + userProfileBean.getActiveProfileId());
		Logger.log(Logger.DEBUG_LEVEL, "populateUserAttributesFromLDAP -> invitationId = " + userProfileBean.getInvitationId());
		return userProfileBean;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private java.util.Map<String, Object> getUserAttributesInfo(final User user, final PumaHome pumaHome, final PumaProfile pumaProfile) {
		Logger.log(Logger.DEBUG_LEVEL, "getUserAttributesInfo(com.ibm.portal.um.User)");
		final java.util.List<String> attributesNamesList;
		try {
			final PumaEnvironment env = pumaHome.getEnvironment();
			attributesNamesList = pumaProfile.getDefinedUserAttributeNames();
//			To use this implementation you need to defined Anonymous User access to Virtual Resource USER_GROUPS!
//			java.util.Map<String, Object> userInfo = (java.util.Map<String, Object>) getPumaProfile().getAttributes((com.ibm.portal.um.Principal) user, attributesNamesList);
			java.util.Map<String, Object> userInfo = (java.util.Map<String, Object>) env.runUnrestricted(new PrivilegedExceptionAction() {
				public Object run() throws Exception {
					return pumaProfile.getAttributes((com.ibm.portal.um.Principal) user, attributesNamesList);
				}
			});
			return userInfo;
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "getUserAttribute(com.ibm.portal.um.User) -> Exception: " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked", "unused" })
	private Object getUserAttribute(final User user, String attributeName) {
		Logger.log(Logger.DEBUG_LEVEL, "getUserAttribute(com.ibm.portal.um.User, " + attributeName + ")");
		final java.util.List<String> attributesNamesList;
		try {
			final PumaHome pumaHome = getPumaHome();
			final PumaEnvironment env = pumaHome.getEnvironment();
			final PumaProfile pumaProfile = getPumaProfile();
			attributesNamesList = getPumaProfile().getDefinedUserAttributeNames();
			Logger.log(Logger.DEBUG_LEVEL, "getUserAttribute(com.ibm.portal.um.User," + attributeName + ") -> attributesNamesList = " +  + (attributesNamesList != null ? attributesNamesList.size() : 0));
			if (attributesNamesList != null && attributesNamesList.size() > 0) {
				for (int i = 0; i < attributesNamesList.size(); i++) {
					Logger.log(Logger.DEBUG_LEVEL, "getUserAttribute(com.ibm.portal.um.User," + attributeName + ") -> attributesNamesList[" + i + "] = " + attributesNamesList.get(i));
				}
			}
//			To use this implementation you need to defined Anonymous User access to Virtual Resource USER_GROUPS!
//			java.util.Map<String, Object> userInfo = (java.util.Map<String, Object>) getPumaProfile().getAttributes((com.ibm.portal.um.Principal) user, attributesNamesList);
			java.util.Map<String, Object> userInfo = (java.util.Map<String, Object>) env.runUnrestricted(new PrivilegedExceptionAction() {
				public Object run() throws Exception {
					return pumaProfile.getAttributes((com.ibm.portal.um.Principal) user, attributesNamesList);
				}
			});
			
			if (userInfo != null) {
				Logger.log(Logger.DEBUG_LEVEL, "getUserAttribute(com.ibm.portal.um.User, " + attributeName + ") -> userInfo.size() = " + userInfo.size());
				return userInfo.get(attributeName);
			}
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "getUserAttribute(com.ibm.portal.um.User, " + attributeName + ") -> Exception: " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}

	public User getUserByPersonalIdentifier(final String userAttribute) {
		Logger.log(Logger.DEBUG_LEVEL, "getUserByPersonalIdentifier(" + userAttribute + ")");
		User user = null;
		List<User> users = getUsersByAttribute(userAttribute, MySpaceConfirmationConstants.LDAP_ATTRIBUTE_EGOV_IDENTIFIER);
//		List<User> users = getUsersByAttribute(userAttribute, MySpaceConfirmationConstants.LDAP_ATTRIBUTE_EMPLOYEE_NUMBER);
		if (users != null && users.size() > 0) {
			Logger.log(Logger.DEBUG_LEVEL, "getUserByPersonalIdentifier(" + userAttribute + ") -> users.size() = " + users.size());
			if (users.size() > 1) {
				Logger.log(Logger.DEBUG_LEVEL, "getUserByPersonalIdentifier() -> " + "Warning: Using non-unique attribute for User. Attribute Name=" + MySpaceConfirmationConstants.LDAP_ATTRIBUTE_EGOV_IDENTIFIER + " Value =" + userAttribute);
//				Logger.log(Logger.DEBUG_LEVEL, "getUserByPersonalIdentifier() -> " + "Warning: Using non-unique attribute for User. Attribute Name=" + MySpaceConfirmationConstants.LDAP_ATTRIBUTE_EMPLOYEE_NUMBER + " Value =" + userAttribute);
			} else {
				user = (User) users.get(0);
			}
		} else {
			Logger.log(Logger.DEBUG_LEVEL, "getUserByPersonalIdentifier(" + userAttribute + ") -> No User was found!");
		}
		
		return user;
	}
	
	public User getUserByUID(final String userAttribute) {
		Logger.log(Logger.DEBUG_LEVEL, "getUserByUID(" + userAttribute + ")");
		User user = null;
		List<User> users = getUsersByAttribute(userAttribute, MySpaceConfirmationConstants.LDAP_ATTRIBUTE_UID);
		if (users != null && users.size() > 0) {
			Logger.log(Logger.DEBUG_LEVEL, "getUserByUID(" + userAttribute + ") -> users.size() = " + users.size());
			if (users.size() > 1) {
				Logger.log(Logger.DEBUG_LEVEL, "getUserByUID() -> " + "Warning: Using non-unique attribute for User. Attribute Name=" + MySpaceConfirmationConstants.LDAP_ATTRIBUTE_UID + " Value =" + userAttribute);
			} else {
				user = (User) users.get(0);
			}
		} else {
			Logger.log(Logger.DEBUG_LEVEL, "getUserByUID(" + userAttribute + ") -> No User was found!");
		}

		return user;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private List<User> getUsersByAttribute(final String userAttributeValue, final String searchAttribute) {
		Logger.log(Logger.DEBUG_LEVEL, "getUsersByAttribute(" + userAttributeValue + "," + searchAttribute + ")");
		List<User> users = null;
		try {
			final PumaHome pumaHome = getPumaHome();
			final PumaEnvironment env = pumaHome.getEnvironment();
			final PumaLocator locatorService = pumaHome.getLocator();
			users = (List<User>) env.runUnrestricted(new PrivilegedExceptionAction() {
				public Object run() throws Exception {
					return locatorService.findUsersByAttribute(searchAttribute, userAttributeValue);
				}
			});
		} catch (Exception e) {
			Logger.log(Logger.ERROR_LEVEL, "getUsersByAttribute(" + userAttributeValue + "," + searchAttribute + ") -> Exception: " + e.getMessage());
			e.printStackTrace();
		}		
		return users;
	}

	private static MySpaceConfirmationPortletSessionBean getSessionBean(PortletRequest request) {
		PortletSession session = request.getPortletSession();
		if (session == null)
			return null;
		MySpaceConfirmationPortletSessionBean sessionBean = (MySpaceConfirmationPortletSessionBean) session.getAttribute(SESSION_BEAN);
		if (sessionBean == null) {
			sessionBean = new MySpaceConfirmationPortletSessionBean();
			session.setAttribute(SESSION_BEAN, sessionBean);
		}
		return sessionBean;
	}
	
	public static PumaHome getPumaHome() {
		return pumaHome;
	}

	public static PumaProfile getPumaProfile() {
		return pumaHome.getProfile();
	}

	public static PumaController getPumaController() {
		return pumaHome.getController();
	}

	private static String getJspFilePath(RenderRequest request, String jspFile) {
		String markup = request.getProperty("wps.markup");
		if (markup == null)
			markup = getMarkup(request.getResponseContentType());
		return JSP_FOLDER + markup + "/" + jspFile + "." + getJspExtension(markup);
	}

	private static String getMarkup(String contentType) {
		if ("text/vnd.wap.wml".equals(contentType))
			return "wml";
		else
			return "html";
	}

	private static String getJspExtension(String markupName) {
		return "jsp";
	}


}