package com.ibs.myspace.confirmation.portlet.db;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.SQLWarning;
import java.util.Properties;

import com.ibs.myspace.confirmation.portlet.MySpaceConfirmationConstants;


public class DBResources extends Base {

    private static final String DEFAULT_PROPERTIES_FILE_NAME = "DBResources.properties";
    private static Properties defaultProps = null;

    public DBResources() {}

    private static final int getValue(String field, int defaultValue) {
        try {
            return Integer.parseInt(field.trim());
        } catch (Exception e) {
        }
        return defaultValue;
    }

    private static void getDefaultProperties(String fileName) {
        defaultProps = new Properties();
        FileInputStream fis = null;
        try {
            fis = new FileInputStream(fileName);
            defaultProps.load(fis);

        } catch (Exception e) {
            System.out.print("DBResources: Error loading properties file " + fileName + " !");
            e.printStackTrace();
        }
    }

    public static String getDefaultDBProperty(String propName) {
        return defaultProps.getProperty(propName);
    }

    public static boolean init(String realpath) {
        boolean result = false;
        File file = null;
        File dir1 = new File(".");
        File dir2 = new File("..");
        try {
            System.out.println("Current dir : " + dir1.getCanonicalPath());
            System.out.println("Parent  dir : " + dir2.getCanonicalPath());
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        String configPath = realpath + File.separator + "WEB-INF" + File.separator + "config" + File.separator + DEFAULT_PROPERTIES_FILE_NAME;
        CONFIG_FILE_LOCATION = realpath + File.separator + "WEB-INF" + File.separator + "config" + File.separator;
        System.err.println("Configuration path is " + configPath);
        file = new File(configPath);
        if (file.exists()) {
        	System.out.println("Loading Properties from file : " + file.getAbsolutePath() + "... ");
            getDefaultProperties(configPath);
            System.out.println("DB SETTINGS LOADING... [OK]");
            if (defaultProps != null) {
                _SEQUENCES = defaultProps.getProperty("sequences","");
                _SCHEMANAME = defaultProps.getProperty("schema","") + ".";
                _DB = defaultProps.getProperty("db","db2").trim();
                _URL = defaultProps.getProperty("url").trim();
                _DRIVERCLASS = defaultProps.getProperty("driverClass");
                _USER = defaultProps.getProperty("user").trim();
                _PASSWORD = defaultProps.getProperty("password").trim();
                _MARIADB_URL = defaultProps.getProperty("mariaDBUrl").trim();
                _MARIADB_DRIVERCLASS = defaultProps.getProperty("mariaDBDriverClass");
                _MARIADB_USER = defaultProps.getProperty("mariaDBUser").trim();
                _MARIADB_PASSWORD = defaultProps.getProperty("mariaDBPassword").trim();
                _MARIADB_TEST_URL = defaultProps.getProperty("mariaDBTestUrl").trim();
                _MARIADB_TEST_USER = defaultProps.getProperty("mariaDBTestUser").trim();
                _MARIADB_TEST_PASSWORD = defaultProps.getProperty("mariaDBTestPassword").trim();
            	if (MySpaceConfirmationConstants._DB_DB2.equalsIgnoreCase(_DB)) {                
            		_DB2 = true;
            	} else if (MySpaceConfirmationConstants._DB_POSTGRESQL.equalsIgnoreCase(_DB)) {
            		_POSTRGRE = true;
            	} else if (MySpaceConfirmationConstants._DB_ORACLE.equalsIgnoreCase(_DB)) {
            		_ORACLE = true;
            	}
                _POOLING = getValue(defaultProps.getProperty("pooling"), 0);
                if (_POOLING == 0) {
                	System.out.println("Connection pooling: SET TO STAY OFF");
                } else {
                	System.out.println("Connection pooling: SET TO TURN ON");
                    _POOLNAME = defaultProps.getProperty("poolName");
                    if (_POOLNAME == null) {
                        _POOLNAME = "DBCP";
                    }
                    _INITIALCONNECTIONS = getValue(defaultProps.getProperty("initialConnections"), 3);
                    _MINIDLECONNECTIONS = getValue(defaultProps.getProperty("minIdleConnections"), 0);
                    _MAXIDLECONNECTIONS = getValue(defaultProps.getProperty("maxIdleConnections"), 2);
                    _MAXACTIVECONNECTIONS = getValue(defaultProps.getProperty("maxActiveConnections"), 20);
                    _MAXWAITFORPOOLEDCONNECTION = getValue(defaultProps.getProperty("maxWaitForPooledConnecton"), 5000);
                    _TESTBEFORE = "true" == defaultProps.getProperty("testConnectionBefore", "false");
                    _TESTAFTER = "true" == defaultProps.getProperty("testConnectionAfter", "false");
                    _SQLVALIDATIONSTRING = defaultProps.getProperty("sqlValidationString", "");
                    _CONNECTIONMONITOR = getValue(defaultProps.getProperty("connectionMonitor"), 30000);
                } 
 
                _LOGON = "1".equals(defaultProps.getProperty("logOn"));
                _LOGLEVEL = getValue(defaultProps.getProperty("logLevel"), 0);
                _SHOWTIMESTAMP = "1".equals(defaultProps.getProperty("showTimeStamp"));

            }

            _DO_POOLING = _POOLING == 1;

            //defaultProps.list(System.err);
            result = true;
        }
        return result;
    } 

    public static String checkForWarning(SQLWarning warn) {
        StringBuffer msgSB = new StringBuffer(300);

        if (warn != null) {
            msgSB.append("\n *** Warning ***\n");
            while (warn != null) {
                msgSB.append(" Warning:\n");
                msgSB.append("SQLState: " + warn.getSQLState() + "\n");
                msgSB.append("Message:  " + warn.getMessage() + "\n");
                msgSB.append("Vendor:   " + warn.getErrorCode() + "\n");
                warn = warn.getNextWarning();
            }
            return msgSB.toString();
        } else {
            return "";
        }
    } 

} 