package com.ibs.myspace.confirmation.portlet.db;

import java.sql.Connection;
import java.sql.SQLException;

public class DBTransaction {
private Connection con;

    public DBTransaction() {
        try {
            con = DBPool.getConnection();
            con.setAutoCommit(false);
        } catch (Exception e) {
        	System.out.println("DBTransaction : DBTransaction : " + e.getMessage());
        	e.printStackTrace();
        }
    }
    
    public Connection getConnection() {
        return con;
    }

    private void releaseConnection() throws SQLException {
        try {
        	if (con != null) {
        		con.close();
        	}
        } catch (SQLException e) {
        	System.out.println("DBTransaction : releaseConnection : " + e.getMessage());
            throw new SQLException(e.getMessage());
        }
    }

    public void rollback() throws SQLException {
        try {
            con.rollback();
            releaseConnection();
        } catch (SQLException e) {
        	System.out.println("DBTransaction : rollback : " + e.getMessage());
            throw new SQLException();
        }
    }

    public void commit() throws SQLException {

        try {
            con.commit();
            releaseConnection();
        } catch (SQLException e) {
        	System.out.println("DBTransaction : commit : " + e.getMessage());
            throw new SQLException();
        }
    }

	public void setTransactionIsolation(int level) throws SQLException {
        if (con != null) con.setTransactionIsolation(level);
    }

    public int getTransactionIsolation() throws SQLException {
        if (con != null) return con.getTransactionIsolation();
        return -1;
    }
}
