package com.ibs.myspace.confirmation.portlet.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import javax.portlet.PortletPreferences;
import javax.portlet.RenderRequest;

import com.ibs.myspace.confirmation.portlet.MySpaceConfirmationConstants;
import com.ibs.myspace.confirmation.portlet.MySpaceConfirmationPortlet;


public class MySpaceConfirmationUtils {

	private final static SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH);
    
    public static void loadPreferences(RenderRequest request) {
		PortletPreferences portletPreferences = request.getPreferences(); 
		
		if (portletPreferences != null) {	
			MySpaceConfirmationPortlet.language = portletPreferences.getValue(MySpaceConfirmationPortlet.SETTING_PARAMETER_LANGUAGE, MySpaceConfirmationConstants.LANGUAGE_BG);				
			MySpaceConfirmationPortlet.debug = "true".equals(portletPreferences.getValue(MySpaceConfirmationPortlet.SETTING_PARAMETER_DEBUG, "false"));	
			MySpaceConfirmationPortlet.preferencesLoaded = true;
			return;
		}
		MySpaceConfirmationPortlet.preferencesLoaded = false;
	}
    
	public static long date_TimestampToTimeMillis(final String s) {
		if (s != null) {
			try {
				return dateTimeFormat.parse(s).getTime();
			} catch (final Exception e) {
				System.out.println("date_TimestampToTimeMillis = " + e.getMessage());
			}
		}
		return 0;
	}
	
	public static String timeMillisToTimestamp(final long millis) {
		try {

			return dateTimeFormat.format(new Date(millis));
		} catch (final Exception e) {
			System.out.println("Utils : timeMillisToTimestamp : " + e.getMessage());
			e.printStackTrace();
		}
		return "no date";
	}
	
}
