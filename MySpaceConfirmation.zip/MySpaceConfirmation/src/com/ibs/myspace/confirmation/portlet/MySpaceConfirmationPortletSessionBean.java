package com.ibs.myspace.confirmation.portlet;

import java.util.ArrayList;
import java.util.List;

import com.ibs.myspace.confirmation.portlet.bean.Message;
import com.ibs.myspace.confirmation.portlet.bean.UserProfileBean;

public class MySpaceConfirmationPortletSessionBean {
	
	private UserProfileBean userProfile = null;
	Message message = null;
	private List<Message> messages = null;
	private boolean persistMessage = false;
	
	public UserProfileBean getUserProfile() {
		return userProfile;
	}

	public void setUserProfile(UserProfileBean userProfile) {
		this.userProfile = userProfile;
	}

	public Message getMessage() {
		return message;
	}

	public void setMessage(Message message) {
		this.message = message;
	}
	
	public List<Message> getMessages() {
		return messages != null ? messages : new ArrayList<Message>();
	}

	public void setMessages(List<Message> messages) {
		this.messages = messages;
	}
	
	public boolean isPersistMessage() {
		return persistMessage;
	}

	public void setPersistMessage(boolean persistMessage) {
		this.persistMessage = persistMessage;
	}
}
