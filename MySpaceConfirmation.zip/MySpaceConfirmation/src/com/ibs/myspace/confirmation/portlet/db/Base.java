package com.ibs.myspace.confirmation.portlet.db;

public class Base {

	public static String _SCHEMANAME = "EGOV.";
	public static String _URL = null;
	public static String _DRIVERCLASS = null;    
	public static String _USER = null;
	public static String _PASSWORD = null;
	public static String _MARIADB_URL = null;
	public static String _MARIADB_DRIVERCLASS = null;    
	public static String _MARIADB_USER = null;
	public static String _MARIADB_PASSWORD = null;
    public static String _MARIADB_TEST_URL = null;
    public static String _MARIADB_TEST_USER = null;
    public static String _MARIADB_TEST_PASSWORD = null;
	public static String _SEQUENCES = null;
	public static String _DB = null;
    public static boolean _ORACLE = false;
    public static boolean _POSTRGRE = false;
    public static boolean _DB2 = false;

    public static String _POOLNAME = null;
    public static int _POOLING;
    public static int _INITIALCONNECTIONS;
    public static int _MAXACTIVECONNECTIONS;
    public static int _MINIDLECONNECTIONS;
    public static int _MAXIDLECONNECTIONS;
    public static int _MAXWAITFORPOOLEDCONNECTION;
    public static boolean _TESTBEFORE;
    public static boolean _TESTAFTER;
    public static String _SQLVALIDATIONSTRING;
    public static int _CONNECTIONMONITOR;

    public static boolean _LOGON = false;
    public static int _LOGLEVEL = 0;
    /*
        0 - log errors only
        1 - log errors and queries
        2 - log errors, queries and developers' messages - System.err
    */
    public static boolean _SHOWTIMESTAMP = false;

    public static boolean _DO_POOLING = true;

    public static String CONFIG_FILE_LOCATION = null;
    public static String REAL_PATH = null;
    public static boolean TEST_ENVIRONMENT = false;
    public static boolean STAGING_ENVIRONMENT = false;
    public static boolean PRODUCTION_ENVIRONMENT = false;
}