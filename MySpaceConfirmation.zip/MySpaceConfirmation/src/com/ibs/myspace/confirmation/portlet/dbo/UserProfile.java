package com.ibs.myspace.confirmation.portlet.dbo;

import java.sql.Timestamp;
import java.util.Hashtable;

import com.ibs.myspace.confirmation.portlet.db.DBTransaction;
import com.ibs.myspace.confirmation.portlet.db.FinderException;
import com.ibs.myspace.confirmation.portlet.db.PersistentObject;
import com.ibs.myspace.confirmation.portlet.db.QueryComposer;
import com.ibs.myspace.confirmation.portlet.db.QuerySet;
import com.ibs.myspace.confirmation.portlet.utils.MySpaceConfirmationUtils;


public class UserProfile extends PersistentObject {

	private static String CLASS_NAME = UserProfile.class.getName();
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    // If change is needed, change also method in QueryExecution -> loadAllProfilesAndPersonalProfilesByUserUID().
    static {
        table = "USERPROFILE";
        sequenceName = "SEQ_USERPROFILE";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "USERPROFILEID");
        columnMap.put("userUID", "USERUID");
        columnMap.put("identifier", "IDENTIFIER");        
        columnMap.put("names", "NAMES");
        columnMap.put("status", "STATUS");
        columnMap.put("deactivationReason", "DEACTIVATIONREASON");
        columnMap.put("eik", "EIK");
        columnMap.put("nameAndLegalForm", "NAMEANDLEGALFORM");
        columnMap.put("qualityOfPhysicalPerson", "QUALITYOFPHYSICALPERSON");
        columnMap.put("methodOfRepresentation", "METHODOFREPRESENTATION");
        columnMap.put("profileType", "PROFILETYPE");
        columnMap.put("profileStructureType", "PROFILESTRUCTURETYPE");
        columnMap.put("dateCreated", "DATECREATED");
        columnMap.put("dateModified", "DATEMODIFIED");
        columnMap.put("groupId", "GROUPID");
        columnMap.put("samlResponse", "SAMLRESPONSE");
        columnMap.put("customSideNav", "CUSTOMSIDENAV");
        columnMap.put("identifierPrefix", "IDENTIFIERPREFIX");
        querySet = QueryComposer.composeAll(table, sequenceName, columnMap);
    }
	
    public UserProfile() {
        super(querySet);
    }
    
    private String userUID = null;
    private String identifier = null;
    private String names = null;
    private String status = null;
    private String deactivationReason = null;
    private String eik = null;
    private String nameAndLegalForm = null;
    private String qualityOfPhysicalPerson = null;
    private String methodOfRepresentation = null;
    private String profileType = null;
    private String profileStructureType = null;
    private String dateCreated = null;
    private String dateModified = null;	
    private String groupId = null;	
	private String samlResponse = null;	
	private String customSideNav = null;
	private String identifierPrefix = null;
	// for business purpose only.
	private UserProfilePersonalParameters personalParameters = null;
	
	public String getUserUID() {
		return userUID;
	}

	public void setUserUID(String userUID) {
		this.userUID = userUID;
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public String getNames() {
		return names;
	}

	public void setNames(String names) {
		this.names = names;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDeactivationReason() {
		return deactivationReason;
	}

	public void setDeactivationReason(String deactivationReason) {
		this.deactivationReason = deactivationReason;
	}

	public String getEik() {
		return eik;
	}

	public void setEik(String eik) {
		this.eik = eik;
	}

	public String getNameAndLegalForm() {
		return nameAndLegalForm;
	}

	public void setNameAndLegalForm(String nameAndLegalForm) {
		this.nameAndLegalForm = nameAndLegalForm;
	}

	public String getQualityOfPhysicalPerson() {
		return qualityOfPhysicalPerson;
	}

	public void setQualityOfPhysicalPerson(String qualityOfPhysicalPerson) {
		this.qualityOfPhysicalPerson = qualityOfPhysicalPerson;
	}

	public String getMethodOfRepresentation() {
		return methodOfRepresentation;
	}

	public void setMethodOfRepresentation(String methodOfRepresentation) {
		this.methodOfRepresentation = methodOfRepresentation;
	}

	public String getProfileType() {
		return profileType;
	}

	public void setProfileType(String profileType) {
		this.profileType = profileType;
	}

	public String getProfileStructureType() {
		return profileStructureType;
	}

	public void setProfileStructureType(String profileStructureType) {
		this.profileStructureType = profileStructureType;
	}

	public Timestamp getDateCreated() {
		return (dateCreated != null) ? new Timestamp(Long.parseLong(dateCreated)) : null;
	}
	
	public void setDateCreated(String dateCreated) {  
		this.dateCreated = (dateCreated != null) ? String.valueOf(MySpaceConfirmationUtils.date_TimestampToTimeMillis(dateCreated)) : null;
	}	
	
	public Timestamp getDateModified() {
		return (dateModified != null) ? new Timestamp(Long.parseLong(dateModified)) : null;
	}
	
	public void setDateModified(String dateModified) {  
		this.dateModified = (dateModified != null) ? String.valueOf(MySpaceConfirmationUtils.date_TimestampToTimeMillis(dateModified)) : null;
	}	
	
	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getSamlResponse() {
		return samlResponse;
	}

	public void setSamlResponse(String samlResponse) {
		this.samlResponse = samlResponse;
	}
			
	public String getCustomSideNav() {
		return customSideNav;
	}

	public void setCustomSideNav(String customSideNav) {
		this.customSideNav = customSideNav;
	}

	public String getIdentifierPrefix() {
		return identifierPrefix;
	}

	public void setIdentifierPrefix(String identifierPrefix) {
		this.identifierPrefix = identifierPrefix;
	}
	
	public UserProfilePersonalParameters getPersonalParameters() {
		return personalParameters;
	}

	public void setPersonalParameters(UserProfilePersonalParameters personalParameters) {
		this.personalParameters = personalParameters;
	}

	public static UserProfile findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfile) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}
	
	public static UserProfile[] findAllByIds(final String ids, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfiles(columnMap.get("id") + " IN (" + ids + ")", transaction);
	}
	
	public static UserProfile[] findAllByIdsAndStatus(final String ids, final String status, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfiles(columnMap.get("id") + " IN (" + ids + ") AND " + columnMap.get("status") + "='" + status + "'", transaction);
	}
	
	public static UserProfile[] findAllNotPersonalProfilesByIds(final String ids, final String profileType, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfiles(columnMap.get("id") + " IN (" + ids + ") AND " + columnMap.get("profileType") + " <> '" + profileType + "'", transaction);
	}
	
	public static UserProfile[] findAllNotPersonalProfilesByIdsAndStatus(final String ids, final String profileType, final String status, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfiles(columnMap.get("id") + " IN (" + ids + ") AND " + columnMap.get("profileType") + " <> '" + profileType + "' AND " + columnMap.get("status") + "='" + status + "'", transaction);
	}
	
	public static UserProfile[] findAllNotPersonalProfiles(final String profileType, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfiles(columnMap.get("profileType") + " <> '" + profileType + "'", transaction);
	}
	
	public static UserProfile findByUserUIDAndType(final String userUID, final String type, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfile) findSingle(columnMap.get("userUID") + "='" + userUID + "' AND " + columnMap.get("profileType") + "='" + type +  "'", CLASS_NAME, transaction);
	}
	
	public static UserProfile[] findAllByUserUIDsAndType(final String userUIDs, final String type, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfiles(columnMap.get("userUID") + " IN (" + userUIDs + ") AND " + columnMap.get("profileType") + "='" + type +  "'", transaction);
	}
	
	public static UserProfile[] findAllByUserUID(final String userUID, final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfiles(columnMap.get("userUID") + "='" + userUID + "'", transaction);
	}
			
	public static void removeAllByUserUID(String userUID, DBTransaction transaction) throws FinderException, Exception {
		UserProfile userProfile = new UserProfile();
		String cond = columnMap.get("userUID") + "='" + userUID + "'";
		userProfile.removeConditional(cond, transaction);			
	}
	
	public static void removeByUserUIDAndType(String userUID, String type, DBTransaction transaction) throws FinderException, Exception {
		UserProfile userProfile = new UserProfile();
		String cond = columnMap.get("userUID") + "='" + userUID + "' AND " + columnMap.get("profileType") + "='" + type + "'";
		userProfile.removeConditional(cond, transaction);			
	}

	public static UserProfile[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfiles("1=1", transaction);
	}

	public static UserProfile[] findAllUserProfiles(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final UserProfile[] userProfiles = new UserProfile[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				userProfiles[i] = (UserProfile) tmp[i];
			}
			return userProfiles;
		} 
		return null;
	}
	
}
