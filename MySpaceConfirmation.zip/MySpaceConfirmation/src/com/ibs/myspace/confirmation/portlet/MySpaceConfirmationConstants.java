package com.ibs.myspace.confirmation.portlet;

public class MySpaceConfirmationConstants {
	public static String _SCHEMANAME = "EGOV.";
	// DB name for Oracle database.
	public static String _DB_ORACLE = "oracle";
	// DB name for IBM DB2 database.
	public static String _DB_DB2 = "db2";
	// DB name for PostgreSQL database.
	public static String _DB_POSTGRESQL = "postgresql";
	public static final String MESSAGE_TYPE_INFORMATION = "I";
	public static final String MESSAGE_TYPE_WARNING = "W";
	public static final String MESSAGE_TYPE_ERROR = "E";
		
	public static final String LANGUAGE_BG = "bg";
	public static final String LANGUAGE_EN = "en";
	
	public static final String LDAP_USERS_DN = "cn=users,o=egov";
	public static final String LDAP_GROUPS_DN = "cn=groups,o=egov";
	
	public static final String LDAP_ATTRIBUTE_UID = "uid";
	public static final String LDAP_ATTRIBUTE_GIVEN_NAME = "givenName";
	public static final String LDAP_ATTRIBUTE_COMMON_NAME = "cn";
	public static final String LDAP_ATTRIBUTE_LAST_NAME = "sn";
	public static final String LDAP_ATTRIBUTE_PORTAL_EMAIL = "ibm-primaryEmail";
	public static final String LDAP_ATTRIBUTE_EMPLOYEE_NUMBER = "employeeNumber";
	public static final String LDAP_ATTRIBUTE_EGOV_IDENTIFIER = "egovIdentifier";
	// we store identifier prefix.
	public static final String LDAP_ATTRIBUTE_DEPARTMENT_NUMBER = "departmentNumber";
	// We store active profile id.
	public static final String LDAP_ATTRIBUTE_ROOM_NUMBER = "roomNumber";
	// We store the invitation id. (only during the request)
	public static final String LDAP_ATTRIBUTE_INVITATION_ID = "carLicense";
	
	public static final String JNDI_PORTLET_STATE = "portletservice/com.ibm.portal.state.service.PortletStateManagerService";
	public static final String EMAIL_CONFIRM_TYPE_PARAM = "emailConfirmType";
	public static final String EMAIL_CONFIRM_CONFIRMATION_CODE_PARAM = "emailConfirmationCode";
	
	public static final String MY_SPACE_CONFIRMATION_PORTLET_WINDOW_ID = "wps.portlet.mySpaceConfirmation";
	
	public static final String USER_PROFILE_ROLE_SELECTED = "1";

	public static final String USER_PROFILE_CHANGE_EMAIL_CONFIRMED = "1";
	
	public static final String USER_PROFILE_STATUS_INACTIVE = "0";
	public static final String USER_PROFILE_STATUS_ACTIVE = "1";	
	public static final String USER_PROFILE_STATUS_NOT_CONFIRMED = "2";		
	public static final String USER_PROFILE_STATUS_BLOCKED = "9";
	
	public static final int TYPE_EMAIL_PERSONAL = 1;
	public static final int TYPE_EMAIL_LEGAL_ENTITY = 2;
	
	public static String _PRODUCT_NAME = "MySpaceConfirmationPortlet";
	public static String _PRODUCT_VERSION = "1.0";
	public static String _OFFICIALMAILSENDER = null;
}
