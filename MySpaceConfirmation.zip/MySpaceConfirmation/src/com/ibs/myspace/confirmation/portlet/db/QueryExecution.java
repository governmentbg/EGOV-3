package com.ibs.myspace.confirmation.portlet.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.ibs.myspace.confirmation.portlet.MySpaceConfirmationConstants;
import com.ibs.myspace.confirmation.portlet.dbo.UserProfileRole;
import com.ibs.myspace.confirmation.portlet.utils.Logger;

public class QueryExecution {

	private static Connection getConnection() throws SQLException {
		
		Connection con = DBPool.getConnection();
		if (con == null) {
			throw new SQLException("Connection is NULL");
		}
		return con;
		
	} 
	
	public UserProfileRole[] loadAllUserProfileRolesByCode(final String code, final DBTransaction transaction) {
		ArrayList<UserProfileRole> userProfileRolesArr = null;
		Connection connection = null;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "SELECT";
				query += " " + DBResources._SCHEMANAME + "USERPROFILEROLE.USERPROFILEROLEID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEROLE.USERPROFILEID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEROLE.USERUID";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEROLE.ADMIN";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEROLE.EDITOR";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEROLE.SERVICEMANAGER";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEROLE.USERROLE";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEROLE.DATECREATED";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEROLE.EMAIL";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEROLE.CONFIRM";
				query += "," + DBResources._SCHEMANAME + "USERPROFILEROLE.CODE";
				query += " FROM " + DBResources._SCHEMANAME + "USERPROFILEROLE";
				query += " WHERE ";
				query += DBResources._SCHEMANAME + "USERPROFILEROLE.CODE = ?";				
				Logger.log(Logger.DEBUG_LEVEL, "query=" + query);
				
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, code);
				
				ResultSet rs = preparedStatement.executeQuery();
				UserProfileRole userProfileRole = null;
				
				userProfileRolesArr = new ArrayList<>();				
				int col = 1;
				while (rs.next()) { 
					col = 1;
					userProfileRole = new UserProfileRole();
					userProfileRole.setId(rs.getString(col++));
					userProfileRole.setUserProfileId(rs.getString(col++));
					userProfileRole.setUserUID(rs.getString(col++));
					userProfileRole.setAdmin(rs.getString(col++));
					userProfileRole.setEditor(rs.getString(col++));
					userProfileRole.setServiceManager(rs.getString(col++));
					userProfileRole.setUser(rs.getString(col++));
					userProfileRole.setDateCreated(rs.getString(col++));
					userProfileRole.setEmail(rs.getString(col++));
					userProfileRole.setConfirm(rs.getString(col++));
					userProfileRole.setCode(rs.getString(col++));
					userProfileRolesArr.add(userProfileRole);
				}	
				Logger.log(Logger.DEBUG_LEVEL, "QE -> loadAllUserProfileRolesByCode(" + code + ") size=" + userProfileRolesArr.size());
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		}
		return userProfileRolesArr != null && userProfileRolesArr.size() > 0 ? userProfileRolesArr.toArray(new UserProfileRole[userProfileRolesArr.size()]) : null;
	}

	public int confirmChangeEmail(final String userUID, final String email, final DBTransaction transaction) {
		Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> confirmChangeEmail(" + userUID  + ", " + email + ") start...");	
		Connection connection = null;
		int result = 0;
		try {
			if (transaction != null) {
				connection = transaction.getConnection();
			} else {
				connection = getConnection();
			}
			if (connection != null) {
				String query = "UPDATE " + DBResources._SCHEMANAME + "USERPROFILEROLE SET CONFIRM=?,CODE=? WHERE USERUID=? AND EMAIL =?";
				PreparedStatement preparedStatement = connection.prepareStatement(query);
				preparedStatement.setString(1, MySpaceConfirmationConstants.USER_PROFILE_CHANGE_EMAIL_CONFIRMED);
				preparedStatement.setString(2, null);
				preparedStatement.setString(3, userUID);
				preparedStatement.setString(4, email);
				result = preparedStatement.executeUpdate();				
				Logger.log(Logger.DEBUG_LEVEL, "QueryExecution() -> confirmChangeEmail(): UPDATE RESULT = " + result);
				preparedStatement.close();				
			}			
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			if (transaction == null) {
				try {
					connection.close();
				} catch (SQLException e) {}
			}
		} 	
		return result;
	}

		
}
