package com.ibs.myspace.confirmation.portlet.utils;

import com.ibs.myspace.confirmation.portlet.MySpaceConfirmationConstants;
import com.ibs.myspace.confirmation.portlet.MySpaceConfirmationPortlet;

public class Logger {

    public final static int ERROR_LEVEL = 0;
    public final static int DEBUG_LEVEL = 2;

    public synchronized static void log(String logMessage) {
        System.err.println(logMessage); 
    }

    public synchronized static void log(int logLevel, String logMessage) {
        String message = MySpaceConfirmationConstants._PRODUCT_NAME + " " + MySpaceConfirmationConstants._PRODUCT_VERSION + " | ";
        if (logLevel == ERROR_LEVEL || (MySpaceConfirmationPortlet.debug && logLevel == DEBUG_LEVEL)) {
             message += logMessage;
             System.err.println(message);
        }        
    }
    
    public synchronized static void println(String message) {
    	log(ERROR_LEVEL, message);
    }
}
