package com.ibs.myspace.confirmation.portlet.db;

import java.util.Enumeration;
import java.util.Hashtable;

public class QueryComposer {

    public static QuerySet composeAll(String table, String sequenceName, Hashtable<String, String> columnMap) {

        String[] keyArray = getKeyArray(table, columnMap);
        QuerySet qs = new QuerySet(table, columnMap, keyArray);

        qs.createQuery = composeCreateQuery(table, columnMap, keyArray);
        qs.loadQuery = composeLoadQuery(table, columnMap, keyArray);
        qs.storeQuery = composeStoreQuery(table, columnMap, keyArray);
        qs.removeQuery = composeRemoveQuery(table);
        qs.findQuery = composeFindQuery(table, columnMap, keyArray);
        qs.sequenceName = sequenceName;
        return qs;
    }

    public static String[] getKeyArray(String table, Hashtable<String, String> columnMap) {
        Enumeration<String> keys = columnMap.keys();
        String[] keyArray = new String[columnMap.size()];
        int counter = 0;
        while (keys.hasMoreElements()) {
            keyArray[counter] = (String) keys.nextElement();
            counter++;
        }
        return keyArray;
    }

    public static String composeCreateQuery(String table, Hashtable<String, String> columnMap, String[] keyArray) {
        StringBuffer query = new StringBuffer();
        query.append("INSERT INTO " + DBResources._SCHEMANAME + table + "(");
        for (int i = 0; i < keyArray.length; i++) {
            query.append(columnMap.get(keyArray[i]) + ", ");
        }
        query.deleteCharAt(query.length() - 2);
        query.append(") VALUES(");

        for (int i = 0; i < keyArray.length; i++) {
            query.append("?, ");
        }
        return query.substring(0, query.length() - 2) + ")";
    }

    public static String composeCreateQuery(String table, Hashtable<String, String> columnMap) {
        String[] keyArray = getKeyArray(table, columnMap);
        return composeCreateQuery(table, columnMap, keyArray);
    }

    public static String composeLoadQuery(String table, Hashtable<String, String> columnMap, String[] keyArray) {
        StringBuffer query = new StringBuffer();
        query.append("SELECT ");

        for (int i = 0; i < keyArray.length; i++) {
            query.append(columnMap.get(keyArray[i]) + ", ");
        }
        return query.substring(0, query.length() - 2) + " FROM " + DBResources._SCHEMANAME + table + " WHERE ";
    }

    public static String composeLoadQuery(String table, Hashtable<String, String> columnMap) {
        String[] keyArray = getKeyArray(table, columnMap);
        return composeLoadQuery(table, columnMap, keyArray);
    }

    public static String composeStoreQuery(String table, Hashtable<String, String> columnMap, String[] keyArray) {
        //compose store query
        StringBuffer query = new StringBuffer();
        query.append("UPDATE " + DBResources._SCHEMANAME + table + " SET ");
        //add parameters to query
        for (int i = 0; i < keyArray.length; i++) {
            query.append(columnMap.get(keyArray[i]) + " = ?, ");
        }
        return query.substring(0, query.length() - 2) + " WHERE ";
    }

    public static String composeStoreQuery(String table, Hashtable<String, String> columnMap) {
        String[] keyArray = getKeyArray(table, columnMap);
        return composeStoreQuery(table, columnMap, keyArray);
    }

    public static String composeRemoveQuery(String table) {
        return "DELETE FROM " + DBResources._SCHEMANAME + table + " WHERE ";
    }

    public static String composeFindQuery(String table, Hashtable<String, String> columnMap, String[] keyArray) {
        StringBuffer query = new StringBuffer();
        query.append("SELECT ");
        for (int i = 0; i < keyArray.length; i++) {
            query.append(columnMap.get(keyArray[i]) + ", ");
        }
        query.deleteCharAt(query.length() - 2);
        query.append(" FROM " + DBResources._SCHEMANAME + table + " WHERE ");

        return query.toString();
    }

    public static String composeFindQuery(String table, Hashtable<String, String> columnMap) {
        String[] keyArray = getKeyArray(table, columnMap);
        return composeFindQuery(table, columnMap, keyArray);
    }

}
