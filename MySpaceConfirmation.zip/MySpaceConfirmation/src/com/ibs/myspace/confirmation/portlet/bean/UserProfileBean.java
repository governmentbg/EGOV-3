package com.ibs.myspace.confirmation.portlet.bean;

public class UserProfileBean {
	private String currentUserDN = null;
	private String currentUserCN = null;
	private String currentUserSN = null;
	private String currentUserIdentifier = null;
	private String currentUserIdentifierPrefix = null;
	private String currentUserUID = null;
	private String currentUserEmail = null;
	private String activeProfileId = null;
	private String invitationId = null;
	private com.ibm.portal.um.User currentUser = null;
	private boolean hasEDeliveryRegistration = false;
	
	
	public UserProfileBean() {}

	public String getCurrentUserDN() {
		return currentUserDN;
	}

	public void setCurrentUserDN(String currentUserDN) {
		this.currentUserDN = currentUserDN;
	}

	public String getCurrentUserCN() {
		return currentUserCN;
	}

	public void setCurrentUserCN(String currentUserCN) {
		this.currentUserCN = currentUserCN;
	}

	public String getCurrentUserSN() {
		return currentUserSN;
	}

	public void setCurrentUserSN(String currentUserSN) {
		this.currentUserSN = currentUserSN;
	}

	public String getCurrentUserIdentifier() {
		return currentUserIdentifier;
	}

	public void setCurrentUserIdentifier(String currentUserIdentifier) {
		this.currentUserIdentifier = currentUserIdentifier;
	}

	public String getCurrentUserIdentifierPrefix() {
		return currentUserIdentifierPrefix;
	}

	public void setCurrentUserIdentifierPrefix(String currentUserIdentifierPrefix) {
		this.currentUserIdentifierPrefix = currentUserIdentifierPrefix;
	}

	public String getCurrentUserUID() {
		return currentUserUID;
	}

	public void setCurrentUserUID(String currentUserUID) {
		this.currentUserUID = currentUserUID;
	}

	public String getCurrentUserEmail() {
		return currentUserEmail;
	}

	public void setCurrentUserEmail(String currentUserEmail) {
		this.currentUserEmail = currentUserEmail;
	}
	
	public String getActiveProfileId() {
		return activeProfileId;
	}

	public void setActiveProfileId(String activeProfileId) {
		this.activeProfileId = activeProfileId;
	}

	public String getInvitationId() {
		return invitationId;
	}

	public void setInvitationId(String invitationId) {
		this.invitationId = invitationId;
	}

	public com.ibm.portal.um.User getCurrentUser() {
		return currentUser;
	}

	public void setCurrentUser(com.ibm.portal.um.User currentUser) {
		this.currentUser = currentUser;
	}

	public boolean isHasEDeliveryRegistration() {
		return hasEDeliveryRegistration;
	}

	public void setHasEDeliveryRegistration(boolean hasEDeliveryRegistration) {
		this.hasEDeliveryRegistration = hasEDeliveryRegistration;
	}
	
}
