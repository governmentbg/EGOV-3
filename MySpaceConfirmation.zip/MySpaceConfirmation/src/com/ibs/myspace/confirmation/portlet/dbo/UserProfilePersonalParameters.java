package com.ibs.myspace.confirmation.portlet.dbo;

import java.util.Hashtable;

import com.ibs.myspace.confirmation.portlet.db.DBTransaction;
import com.ibs.myspace.confirmation.portlet.db.FinderException;
import com.ibs.myspace.confirmation.portlet.db.PersistentObject;
import com.ibs.myspace.confirmation.portlet.db.QueryComposer;
import com.ibs.myspace.confirmation.portlet.db.QuerySet;


public class UserProfilePersonalParameters extends PersistentObject {

	private static String CLASS_NAME = UserProfilePersonalParameters.class.getName();
    protected static String table;
    protected static Hashtable<String, String> columnMap;
    protected static String[] keyArray;
    protected static String sequenceName;
    public static QuerySet querySet;
	
    // If change is needed, change also method in QueryExecution -> loadAllProfilesAndPersonalProfilesByUserUID().
    static {
        table = "USERPROFILEPERSONALPARAMETERS";
        sequenceName = "SEQ_USERPROFILEPERSONALPARAMETERS";
        columnMap = new Hashtable<String, String>();
        columnMap.put("id", "USERPROFILEPERSONALPARAMETERSID");
        columnMap.put("userProfileId", "USERPROFILEID");
        columnMap.put("securityLevel", "SECURITYLEVEL");
        columnMap.put("consentToUseAddress", "CONSENTTOUSEADDRESS");
        columnMap.put("ekatte", "EKATTE");
        columnMap.put("addressDescription", "ADDRESSDESCRIPTION");
        columnMap.put("mailBox", "MAILBOX");
        columnMap.put("zipCode", "ZIPCODE");
        columnMap.put("consentToUsePhone", "CONSENTTOUSEPHONE");
        columnMap.put("phoneNumber", "PHONENUMBER");
        columnMap.put("consentToUseEmail", "CONSENTTOUSEEMAIL");
        columnMap.put("email", "EMAIL");
//        columnMap.put("consentToUseRequestChannel", "CONSENTTOUSEREQUESTCHANNEL");
//        columnMap.put("preferredRequestChannel", "PREFERREDREQUESTCHANNEL");
//        columnMap.put("consentToUseResponseChannel", "CONSENTTOUSERESPONSECHANNEL");
//        columnMap.put("preferredResponseChannel", "PREFERREDRESPONSECHANNEL");
//        columnMap.put("consentToUsePaymentChannel", "CONSENTTOUSEPAYMENTCHANNEL");
//        columnMap.put("preferredPaymentChannel", "PREFERREDPAYMENTCHANNEL");
        columnMap.put("maxFavoriteServices", "MAXFAVORITESERVICES");        
        columnMap.put("generalConsent", "GENERALCONSENT");        
        querySet = QueryComposer.composeAll(table, sequenceName, columnMap);
    }
	
    public UserProfilePersonalParameters() {
        super(querySet);
    }
    
    private String userProfileId = null;
    private String securityLevel = null;
    private String consentToUseAddress = null;
    private String ekatte = null;
    private String addressDescription = null;
    private String mailBox = null;
    private String zipCode = null;
    private String consentToUsePhone = null;
    private String phoneNumber = null;
    private String consentToUseEmail = null;
    private String email = null;
//    private String consentToUseRequestChannel = null;
//    private String preferredRequestChannel = null;
//    private String consentToUseResponseChannel = null;
//    private String preferredResponseChannel = null;
//    private String consentToUsePaymentChannel = null;
//    private String preferredPaymentChannel = null;
    private String maxFavoriteServices = null;
    private String generalConsent = null;
	
	public String getUserProfileId() {
		return userProfileId;
	}

	public void setUserProfileId(String userProfileId) {
		this.userProfileId = userProfileId;
	}

	public String getSecurityLevel() {
		return securityLevel;
	}

	public void setSecurityLevel(String securityLevel) {
		this.securityLevel = securityLevel;
	}

	public String getConsentToUseAddress() {
		return consentToUseAddress;
	}

	public void setConsentToUseAddress(String consentToUseAddress) {
		this.consentToUseAddress = consentToUseAddress;
	}
	
	public String getEkatte() {
		return ekatte;
	}

	public void setEkatte(String ekatte) {
		this.ekatte = ekatte;
	}

	public String getAddressDescription() {
		return addressDescription;
	}

	public void setAddressDescription(String addressDescription) {
		this.addressDescription = addressDescription;
	}

	public String getMailBox() {
		return mailBox;
	}

	public void setMailBox(String mailBox) {
		this.mailBox = mailBox;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getConsentToUsePhone() {
		return consentToUsePhone;
	}

	public void setConsentToUsePhone(String consentToUsePhone) {
		this.consentToUsePhone = consentToUsePhone;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getConsentToUseEmail() {
		return consentToUseEmail;
	}

	public void setConsentToUseEmail(String consentToUseEmail) {
		this.consentToUseEmail = consentToUseEmail;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

//	public String getConsentToUseRequestChannel() {
//		return consentToUseRequestChannel;
//	}
//
//	public void setConsentToUseRequestChannel(String consentToUseRequestChannel) {
//		this.consentToUseRequestChannel = consentToUseRequestChannel;
//	}
//
//	public String getPreferredRequestChannel() {
//		return preferredRequestChannel;
//	}
//
//	public void setPreferredRequestChannel(String preferredRequestChannel) {
//		this.preferredRequestChannel = preferredRequestChannel;
//	}
//
//	public String getConsentToUseResponseChannel() {
//		return consentToUseResponseChannel;
//	}
//
//	public void setConsentToUseResponseChannel(String consentToUseResponseChannel) {
//		this.consentToUseResponseChannel = consentToUseResponseChannel;
//	}
//
//	public String getPreferredResponseChannel() {
//		return preferredResponseChannel;
//	}
//
//	public void setPreferredResponseChannel(String preferredResponseChannel) {
//		this.preferredResponseChannel = preferredResponseChannel;
//	}
//
//	public String getConsentToUsePaymentChannel() {
//		return consentToUsePaymentChannel;
//	}
//
//	public void setConsentToUsePaymentChannel(String consentToUsePaymentChannel) {
//		this.consentToUsePaymentChannel = consentToUsePaymentChannel;
//	}
//
//	public String getPreferredPaymentChannel() {
//		return preferredPaymentChannel;
//	}
//
//	public void setPreferredPaymentChannel(String preferredPaymentChannel) {
//		this.preferredPaymentChannel = preferredPaymentChannel;
//	}

	public String getMaxFavoriteServices() {
		return maxFavoriteServices;
	}

	public void setMaxFavoriteServices(String maxFavoriteServices) {
		this.maxFavoriteServices = maxFavoriteServices;
	}

	public String getGeneralConsent() {
		return generalConsent;
	}

	public void setGeneralConsent(String generalConsent) {
		this.generalConsent = generalConsent;
	}

	public static UserProfilePersonalParameters findById(final String id, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfilePersonalParameters) findSingle(columnMap.get("id") + "=" + id, CLASS_NAME, transaction);
	}
	
	public static UserProfilePersonalParameters findByUserProfileId(final String userProfileId, final DBTransaction transaction) throws FinderException, Exception {
		return (UserProfilePersonalParameters) findSingle(columnMap.get("userProfileId") + "='" + userProfileId + "'", CLASS_NAME, transaction);
	}
				
	public static void removeAllByUserProfileId(String userProfileId, DBTransaction transaction) throws FinderException, Exception {
		UserProfilePersonalParameters userProfilePersonalParameters = new UserProfilePersonalParameters();
		String cond = columnMap.get("userProfileId") + "='" + userProfileId + "'";
		userProfilePersonalParameters.removeConditional(cond, transaction);			
	}
	
	public static UserProfilePersonalParameters[] findAll(final DBTransaction transaction) throws FinderException, Exception {
		return findAllUserProfilePersonalParameters("1=1", transaction);
	}

	public static UserProfilePersonalParameters[] findAllUserProfilePersonalParameters(final String cond, final DBTransaction transaction) throws FinderException, Exception {
		final Object[] tmp = findMultiple(cond, CLASS_NAME, transaction);
		if (tmp != null) {
			final UserProfilePersonalParameters[] userProfilePersonalParameters = new UserProfilePersonalParameters[tmp.length];
			for (int i = 0; i < tmp.length; i++) {
				userProfilePersonalParameters[i] = (UserProfilePersonalParameters) tmp[i];
			}
			return userProfilePersonalParameters;
		} 
		return null;
	}
	
}
